<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-18 07:22:53 --> Config Class Initialized
INFO - 2018-01-18 07:22:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:22:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:22:53 --> Utf8 Class Initialized
INFO - 2018-01-18 07:22:53 --> URI Class Initialized
DEBUG - 2018-01-18 07:22:53 --> No URI present. Default controller set.
INFO - 2018-01-18 07:22:53 --> Router Class Initialized
INFO - 2018-01-18 07:22:53 --> Output Class Initialized
INFO - 2018-01-18 07:22:53 --> Security Class Initialized
DEBUG - 2018-01-18 07:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:22:53 --> Input Class Initialized
INFO - 2018-01-18 07:22:53 --> Language Class Initialized
INFO - 2018-01-18 07:22:53 --> Loader Class Initialized
INFO - 2018-01-18 07:22:53 --> Helper loaded: url_helper
INFO - 2018-01-18 07:22:53 --> Helper loaded: form_helper
INFO - 2018-01-18 07:22:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:22:53 --> Form Validation Class Initialized
INFO - 2018-01-18 07:22:53 --> Model Class Initialized
INFO - 2018-01-18 07:22:53 --> Controller Class Initialized
INFO - 2018-01-18 07:22:54 --> Config Class Initialized
INFO - 2018-01-18 07:22:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:22:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:22:54 --> Utf8 Class Initialized
INFO - 2018-01-18 07:22:54 --> URI Class Initialized
INFO - 2018-01-18 07:22:54 --> Router Class Initialized
INFO - 2018-01-18 07:22:54 --> Output Class Initialized
INFO - 2018-01-18 07:22:54 --> Security Class Initialized
DEBUG - 2018-01-18 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:22:54 --> Input Class Initialized
INFO - 2018-01-18 07:22:54 --> Language Class Initialized
INFO - 2018-01-18 07:22:54 --> Loader Class Initialized
INFO - 2018-01-18 07:22:54 --> Helper loaded: url_helper
INFO - 2018-01-18 07:22:54 --> Helper loaded: form_helper
INFO - 2018-01-18 07:22:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:22:54 --> Form Validation Class Initialized
INFO - 2018-01-18 07:22:54 --> Model Class Initialized
INFO - 2018-01-18 07:22:54 --> Controller Class Initialized
INFO - 2018-01-18 07:22:54 --> Model Class Initialized
DEBUG - 2018-01-18 07:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:22:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:22:54 --> Final output sent to browser
DEBUG - 2018-01-18 07:22:54 --> Total execution time: 0.0403
INFO - 2018-01-18 07:23:39 --> Config Class Initialized
INFO - 2018-01-18 07:23:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:23:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:23:39 --> Utf8 Class Initialized
INFO - 2018-01-18 07:23:39 --> URI Class Initialized
INFO - 2018-01-18 07:23:39 --> Router Class Initialized
INFO - 2018-01-18 07:23:39 --> Output Class Initialized
INFO - 2018-01-18 07:23:39 --> Security Class Initialized
DEBUG - 2018-01-18 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:23:39 --> Input Class Initialized
INFO - 2018-01-18 07:23:39 --> Language Class Initialized
INFO - 2018-01-18 07:23:39 --> Loader Class Initialized
INFO - 2018-01-18 07:23:39 --> Helper loaded: url_helper
INFO - 2018-01-18 07:23:39 --> Helper loaded: form_helper
INFO - 2018-01-18 07:23:39 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:23:39 --> Form Validation Class Initialized
INFO - 2018-01-18 07:23:39 --> Model Class Initialized
INFO - 2018-01-18 07:23:39 --> Controller Class Initialized
INFO - 2018-01-18 07:23:39 --> Model Class Initialized
DEBUG - 2018-01-18 07:23:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 07:23:40 --> Config Class Initialized
INFO - 2018-01-18 07:23:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:23:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:23:40 --> Utf8 Class Initialized
INFO - 2018-01-18 07:23:40 --> URI Class Initialized
DEBUG - 2018-01-18 07:23:40 --> No URI present. Default controller set.
INFO - 2018-01-18 07:23:40 --> Router Class Initialized
INFO - 2018-01-18 07:23:40 --> Output Class Initialized
INFO - 2018-01-18 07:23:40 --> Security Class Initialized
DEBUG - 2018-01-18 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:23:40 --> Input Class Initialized
INFO - 2018-01-18 07:23:40 --> Language Class Initialized
INFO - 2018-01-18 07:23:40 --> Loader Class Initialized
INFO - 2018-01-18 07:23:40 --> Helper loaded: url_helper
INFO - 2018-01-18 07:23:40 --> Helper loaded: form_helper
INFO - 2018-01-18 07:23:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:23:40 --> Form Validation Class Initialized
INFO - 2018-01-18 07:23:40 --> Model Class Initialized
INFO - 2018-01-18 07:23:40 --> Controller Class Initialized
INFO - 2018-01-18 07:23:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:23:40 --> Final output sent to browser
DEBUG - 2018-01-18 07:23:40 --> Total execution time: 0.0342
INFO - 2018-01-18 07:24:54 --> Config Class Initialized
INFO - 2018-01-18 07:24:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:24:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:24:54 --> Utf8 Class Initialized
INFO - 2018-01-18 07:24:54 --> URI Class Initialized
INFO - 2018-01-18 07:24:54 --> Router Class Initialized
INFO - 2018-01-18 07:24:54 --> Output Class Initialized
INFO - 2018-01-18 07:24:54 --> Security Class Initialized
DEBUG - 2018-01-18 07:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:24:54 --> Input Class Initialized
INFO - 2018-01-18 07:24:54 --> Language Class Initialized
INFO - 2018-01-18 07:24:54 --> Loader Class Initialized
INFO - 2018-01-18 07:24:54 --> Helper loaded: url_helper
INFO - 2018-01-18 07:24:54 --> Helper loaded: form_helper
INFO - 2018-01-18 07:24:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:24:54 --> Form Validation Class Initialized
INFO - 2018-01-18 07:24:54 --> Model Class Initialized
INFO - 2018-01-18 07:24:54 --> Controller Class Initialized
INFO - 2018-01-18 07:24:54 --> Model Class Initialized
INFO - 2018-01-18 07:24:54 --> Model Class Initialized
INFO - 2018-01-18 07:24:54 --> Model Class Initialized
INFO - 2018-01-18 07:24:54 --> Model Class Initialized
DEBUG - 2018-01-18 07:24:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 07:24:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 47
ERROR - 2018-01-18 07:24:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 07:24:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:24:55 --> Final output sent to browser
DEBUG - 2018-01-18 07:24:55 --> Total execution time: 1.1678
INFO - 2018-01-18 07:25:11 --> Config Class Initialized
INFO - 2018-01-18 07:25:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:25:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:25:11 --> Utf8 Class Initialized
INFO - 2018-01-18 07:25:11 --> URI Class Initialized
INFO - 2018-01-18 07:25:11 --> Router Class Initialized
INFO - 2018-01-18 07:25:11 --> Output Class Initialized
INFO - 2018-01-18 07:25:11 --> Security Class Initialized
DEBUG - 2018-01-18 07:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:25:11 --> Input Class Initialized
INFO - 2018-01-18 07:25:11 --> Language Class Initialized
INFO - 2018-01-18 07:25:11 --> Loader Class Initialized
INFO - 2018-01-18 07:25:11 --> Helper loaded: url_helper
INFO - 2018-01-18 07:25:11 --> Helper loaded: form_helper
INFO - 2018-01-18 07:25:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:25:11 --> Form Validation Class Initialized
INFO - 2018-01-18 07:25:11 --> Model Class Initialized
INFO - 2018-01-18 07:25:11 --> Controller Class Initialized
INFO - 2018-01-18 07:25:11 --> Model Class Initialized
INFO - 2018-01-18 07:25:11 --> Model Class Initialized
DEBUG - 2018-01-18 07:25:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:25:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:25:11 --> Final output sent to browser
DEBUG - 2018-01-18 07:25:11 --> Total execution time: 0.0423
INFO - 2018-01-18 07:25:16 --> Config Class Initialized
INFO - 2018-01-18 07:25:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:25:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:25:16 --> Utf8 Class Initialized
INFO - 2018-01-18 07:25:16 --> URI Class Initialized
INFO - 2018-01-18 07:25:16 --> Router Class Initialized
INFO - 2018-01-18 07:25:16 --> Output Class Initialized
INFO - 2018-01-18 07:25:16 --> Security Class Initialized
DEBUG - 2018-01-18 07:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:25:16 --> Input Class Initialized
INFO - 2018-01-18 07:25:16 --> Language Class Initialized
INFO - 2018-01-18 07:25:16 --> Loader Class Initialized
INFO - 2018-01-18 07:25:16 --> Helper loaded: url_helper
INFO - 2018-01-18 07:25:16 --> Helper loaded: form_helper
INFO - 2018-01-18 07:25:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:25:16 --> Form Validation Class Initialized
INFO - 2018-01-18 07:25:16 --> Model Class Initialized
INFO - 2018-01-18 07:25:16 --> Controller Class Initialized
INFO - 2018-01-18 07:25:16 --> Model Class Initialized
INFO - 2018-01-18 07:25:16 --> Model Class Initialized
DEBUG - 2018-01-18 07:25:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:25:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:25:16 --> Final output sent to browser
DEBUG - 2018-01-18 07:25:16 --> Total execution time: 0.0398
INFO - 2018-01-18 07:26:07 --> Config Class Initialized
INFO - 2018-01-18 07:26:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:26:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:26:07 --> Utf8 Class Initialized
INFO - 2018-01-18 07:26:07 --> URI Class Initialized
INFO - 2018-01-18 07:26:07 --> Router Class Initialized
INFO - 2018-01-18 07:26:07 --> Output Class Initialized
INFO - 2018-01-18 07:26:07 --> Security Class Initialized
DEBUG - 2018-01-18 07:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:26:07 --> Input Class Initialized
INFO - 2018-01-18 07:26:07 --> Language Class Initialized
INFO - 2018-01-18 07:26:07 --> Loader Class Initialized
INFO - 2018-01-18 07:26:07 --> Helper loaded: url_helper
INFO - 2018-01-18 07:26:07 --> Helper loaded: form_helper
INFO - 2018-01-18 07:26:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:26:07 --> Form Validation Class Initialized
INFO - 2018-01-18 07:26:07 --> Model Class Initialized
INFO - 2018-01-18 07:26:07 --> Controller Class Initialized
INFO - 2018-01-18 07:26:07 --> Model Class Initialized
INFO - 2018-01-18 07:26:07 --> Model Class Initialized
INFO - 2018-01-18 07:26:07 --> Model Class Initialized
INFO - 2018-01-18 07:26:07 --> Model Class Initialized
DEBUG - 2018-01-18 07:26:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 07:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 45
ERROR - 2018-01-18 07:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 07:26:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:26:07 --> Final output sent to browser
DEBUG - 2018-01-18 07:26:07 --> Total execution time: 0.0476
INFO - 2018-01-18 07:26:09 --> Config Class Initialized
INFO - 2018-01-18 07:26:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:26:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:26:09 --> Utf8 Class Initialized
INFO - 2018-01-18 07:26:09 --> URI Class Initialized
INFO - 2018-01-18 07:26:09 --> Router Class Initialized
INFO - 2018-01-18 07:26:09 --> Output Class Initialized
INFO - 2018-01-18 07:26:09 --> Security Class Initialized
DEBUG - 2018-01-18 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:26:09 --> Input Class Initialized
INFO - 2018-01-18 07:26:09 --> Language Class Initialized
INFO - 2018-01-18 07:26:09 --> Loader Class Initialized
INFO - 2018-01-18 07:26:09 --> Helper loaded: url_helper
INFO - 2018-01-18 07:26:09 --> Helper loaded: form_helper
INFO - 2018-01-18 07:26:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:26:09 --> Form Validation Class Initialized
INFO - 2018-01-18 07:26:09 --> Model Class Initialized
INFO - 2018-01-18 07:26:09 --> Controller Class Initialized
INFO - 2018-01-18 07:26:09 --> Model Class Initialized
INFO - 2018-01-18 07:26:09 --> Model Class Initialized
INFO - 2018-01-18 07:26:09 --> Model Class Initialized
INFO - 2018-01-18 07:26:09 --> Model Class Initialized
DEBUG - 2018-01-18 07:26:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 07:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 47
ERROR - 2018-01-18 07:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 07:26:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:26:09 --> Final output sent to browser
DEBUG - 2018-01-18 07:26:09 --> Total execution time: 0.0466
INFO - 2018-01-18 07:32:23 --> Config Class Initialized
INFO - 2018-01-18 07:32:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:32:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:32:23 --> Utf8 Class Initialized
INFO - 2018-01-18 07:32:23 --> URI Class Initialized
INFO - 2018-01-18 07:32:23 --> Router Class Initialized
INFO - 2018-01-18 07:32:23 --> Output Class Initialized
INFO - 2018-01-18 07:32:23 --> Security Class Initialized
DEBUG - 2018-01-18 07:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:32:23 --> Input Class Initialized
INFO - 2018-01-18 07:32:23 --> Language Class Initialized
INFO - 2018-01-18 07:32:23 --> Loader Class Initialized
INFO - 2018-01-18 07:32:23 --> Helper loaded: url_helper
INFO - 2018-01-18 07:32:23 --> Helper loaded: form_helper
INFO - 2018-01-18 07:32:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:32:23 --> Form Validation Class Initialized
INFO - 2018-01-18 07:32:23 --> Model Class Initialized
INFO - 2018-01-18 07:32:23 --> Controller Class Initialized
INFO - 2018-01-18 07:32:23 --> Model Class Initialized
INFO - 2018-01-18 07:32:23 --> Model Class Initialized
DEBUG - 2018-01-18 07:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:32:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:32:23 --> Final output sent to browser
DEBUG - 2018-01-18 07:32:23 --> Total execution time: 0.0397
INFO - 2018-01-18 07:32:26 --> Config Class Initialized
INFO - 2018-01-18 07:32:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:32:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:32:26 --> Utf8 Class Initialized
INFO - 2018-01-18 07:32:26 --> URI Class Initialized
INFO - 2018-01-18 07:32:26 --> Router Class Initialized
INFO - 2018-01-18 07:32:26 --> Output Class Initialized
INFO - 2018-01-18 07:32:26 --> Security Class Initialized
DEBUG - 2018-01-18 07:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:32:26 --> Input Class Initialized
INFO - 2018-01-18 07:32:26 --> Language Class Initialized
INFO - 2018-01-18 07:32:26 --> Loader Class Initialized
INFO - 2018-01-18 07:32:26 --> Helper loaded: url_helper
INFO - 2018-01-18 07:32:26 --> Helper loaded: form_helper
INFO - 2018-01-18 07:32:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:32:26 --> Form Validation Class Initialized
INFO - 2018-01-18 07:32:26 --> Model Class Initialized
INFO - 2018-01-18 07:32:26 --> Controller Class Initialized
INFO - 2018-01-18 07:32:26 --> Model Class Initialized
INFO - 2018-01-18 07:32:26 --> Model Class Initialized
DEBUG - 2018-01-18 07:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:32:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:32:26 --> Final output sent to browser
DEBUG - 2018-01-18 07:32:26 --> Total execution time: 0.0480
INFO - 2018-01-18 07:34:24 --> Config Class Initialized
INFO - 2018-01-18 07:34:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:34:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:34:24 --> Utf8 Class Initialized
INFO - 2018-01-18 07:34:24 --> URI Class Initialized
INFO - 2018-01-18 07:34:24 --> Router Class Initialized
INFO - 2018-01-18 07:34:24 --> Output Class Initialized
INFO - 2018-01-18 07:34:24 --> Security Class Initialized
DEBUG - 2018-01-18 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:34:24 --> Input Class Initialized
INFO - 2018-01-18 07:34:24 --> Language Class Initialized
INFO - 2018-01-18 07:34:24 --> Loader Class Initialized
INFO - 2018-01-18 07:34:24 --> Helper loaded: url_helper
INFO - 2018-01-18 07:34:24 --> Helper loaded: form_helper
INFO - 2018-01-18 07:34:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:34:24 --> Form Validation Class Initialized
INFO - 2018-01-18 07:34:24 --> Model Class Initialized
INFO - 2018-01-18 07:34:24 --> Controller Class Initialized
INFO - 2018-01-18 07:34:24 --> Model Class Initialized
INFO - 2018-01-18 07:34:24 --> Model Class Initialized
DEBUG - 2018-01-18 07:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:34:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:34:24 --> Final output sent to browser
DEBUG - 2018-01-18 07:34:24 --> Total execution time: 0.0630
INFO - 2018-01-18 07:36:45 --> Config Class Initialized
INFO - 2018-01-18 07:36:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:36:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:36:45 --> Utf8 Class Initialized
INFO - 2018-01-18 07:36:45 --> URI Class Initialized
INFO - 2018-01-18 07:36:45 --> Router Class Initialized
INFO - 2018-01-18 07:36:45 --> Output Class Initialized
INFO - 2018-01-18 07:36:45 --> Security Class Initialized
DEBUG - 2018-01-18 07:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:36:45 --> Input Class Initialized
INFO - 2018-01-18 07:36:45 --> Language Class Initialized
INFO - 2018-01-18 07:36:45 --> Loader Class Initialized
INFO - 2018-01-18 07:36:45 --> Helper loaded: url_helper
INFO - 2018-01-18 07:36:45 --> Helper loaded: form_helper
INFO - 2018-01-18 07:36:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:36:45 --> Form Validation Class Initialized
INFO - 2018-01-18 07:36:45 --> Model Class Initialized
INFO - 2018-01-18 07:36:45 --> Controller Class Initialized
INFO - 2018-01-18 07:36:45 --> Model Class Initialized
INFO - 2018-01-18 07:36:45 --> Model Class Initialized
DEBUG - 2018-01-18 07:36:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:36:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:36:45 --> Final output sent to browser
DEBUG - 2018-01-18 07:36:45 --> Total execution time: 0.0551
INFO - 2018-01-18 07:38:38 --> Config Class Initialized
INFO - 2018-01-18 07:38:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:38:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:38:38 --> Utf8 Class Initialized
INFO - 2018-01-18 07:38:38 --> URI Class Initialized
INFO - 2018-01-18 07:38:38 --> Router Class Initialized
INFO - 2018-01-18 07:38:38 --> Output Class Initialized
INFO - 2018-01-18 07:38:38 --> Security Class Initialized
DEBUG - 2018-01-18 07:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:38:38 --> Input Class Initialized
INFO - 2018-01-18 07:38:38 --> Language Class Initialized
INFO - 2018-01-18 07:38:38 --> Loader Class Initialized
INFO - 2018-01-18 07:38:38 --> Helper loaded: url_helper
INFO - 2018-01-18 07:38:38 --> Helper loaded: form_helper
INFO - 2018-01-18 07:38:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:38:38 --> Form Validation Class Initialized
INFO - 2018-01-18 07:38:38 --> Model Class Initialized
INFO - 2018-01-18 07:38:38 --> Controller Class Initialized
INFO - 2018-01-18 07:38:38 --> Model Class Initialized
INFO - 2018-01-18 07:38:38 --> Model Class Initialized
DEBUG - 2018-01-18 07:38:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 07:38:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:38:38 --> Final output sent to browser
DEBUG - 2018-01-18 07:38:38 --> Total execution time: 0.0673
INFO - 2018-01-18 07:38:42 --> Config Class Initialized
INFO - 2018-01-18 07:38:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:38:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:38:42 --> Utf8 Class Initialized
INFO - 2018-01-18 07:38:42 --> URI Class Initialized
INFO - 2018-01-18 07:38:42 --> Router Class Initialized
INFO - 2018-01-18 07:38:42 --> Output Class Initialized
INFO - 2018-01-18 07:38:42 --> Security Class Initialized
DEBUG - 2018-01-18 07:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:38:42 --> Input Class Initialized
INFO - 2018-01-18 07:38:42 --> Language Class Initialized
INFO - 2018-01-18 07:38:42 --> Loader Class Initialized
INFO - 2018-01-18 07:38:42 --> Helper loaded: url_helper
INFO - 2018-01-18 07:38:42 --> Helper loaded: form_helper
INFO - 2018-01-18 07:38:42 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:38:42 --> Form Validation Class Initialized
INFO - 2018-01-18 07:38:42 --> Model Class Initialized
INFO - 2018-01-18 07:38:42 --> Controller Class Initialized
INFO - 2018-01-18 07:38:42 --> Model Class Initialized
INFO - 2018-01-18 07:38:42 --> Model Class Initialized
INFO - 2018-01-18 07:38:42 --> Model Class Initialized
INFO - 2018-01-18 07:38:42 --> Model Class Initialized
DEBUG - 2018-01-18 07:38:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 07:38:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 07:38:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:38:42 --> Final output sent to browser
DEBUG - 2018-01-18 07:38:42 --> Total execution time: 0.0529
INFO - 2018-01-18 07:38:45 --> Config Class Initialized
INFO - 2018-01-18 07:38:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 07:38:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 07:38:45 --> Utf8 Class Initialized
INFO - 2018-01-18 07:38:45 --> URI Class Initialized
INFO - 2018-01-18 07:38:45 --> Router Class Initialized
INFO - 2018-01-18 07:38:45 --> Output Class Initialized
INFO - 2018-01-18 07:38:45 --> Security Class Initialized
DEBUG - 2018-01-18 07:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 07:38:45 --> Input Class Initialized
INFO - 2018-01-18 07:38:45 --> Language Class Initialized
INFO - 2018-01-18 07:38:45 --> Loader Class Initialized
INFO - 2018-01-18 07:38:45 --> Helper loaded: url_helper
INFO - 2018-01-18 07:38:45 --> Helper loaded: form_helper
INFO - 2018-01-18 07:38:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 07:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 07:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 07:38:45 --> Form Validation Class Initialized
INFO - 2018-01-18 07:38:45 --> Model Class Initialized
INFO - 2018-01-18 07:38:45 --> Controller Class Initialized
INFO - 2018-01-18 07:38:45 --> Model Class Initialized
INFO - 2018-01-18 07:38:45 --> Model Class Initialized
INFO - 2018-01-18 07:38:45 --> Model Class Initialized
INFO - 2018-01-18 07:38:45 --> Model Class Initialized
DEBUG - 2018-01-18 07:38:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 07:38:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 07:38:47 --> Final output sent to browser
DEBUG - 2018-01-18 07:38:47 --> Total execution time: 2.0478
INFO - 2018-01-18 09:32:17 --> Config Class Initialized
INFO - 2018-01-18 09:32:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:32:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:32:17 --> Utf8 Class Initialized
INFO - 2018-01-18 09:32:17 --> URI Class Initialized
INFO - 2018-01-18 09:32:17 --> Router Class Initialized
INFO - 2018-01-18 09:32:17 --> Output Class Initialized
INFO - 2018-01-18 09:32:17 --> Security Class Initialized
DEBUG - 2018-01-18 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:32:17 --> Input Class Initialized
INFO - 2018-01-18 09:32:17 --> Language Class Initialized
INFO - 2018-01-18 09:32:17 --> Loader Class Initialized
INFO - 2018-01-18 09:32:17 --> Helper loaded: url_helper
INFO - 2018-01-18 09:32:17 --> Helper loaded: form_helper
INFO - 2018-01-18 09:32:17 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:32:17 --> Form Validation Class Initialized
INFO - 2018-01-18 09:32:17 --> Model Class Initialized
INFO - 2018-01-18 09:32:17 --> Controller Class Initialized
INFO - 2018-01-18 09:32:17 --> Model Class Initialized
INFO - 2018-01-18 09:32:17 --> Model Class Initialized
INFO - 2018-01-18 09:32:17 --> Model Class Initialized
INFO - 2018-01-18 09:32:17 --> Model Class Initialized
DEBUG - 2018-01-18 09:32:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 09:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 09:32:17 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:32:17 --> Final output sent to browser
DEBUG - 2018-01-18 09:32:17 --> Total execution time: 0.0504
INFO - 2018-01-18 09:32:23 --> Config Class Initialized
INFO - 2018-01-18 09:32:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:32:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:32:23 --> Utf8 Class Initialized
INFO - 2018-01-18 09:32:23 --> URI Class Initialized
INFO - 2018-01-18 09:32:23 --> Router Class Initialized
INFO - 2018-01-18 09:32:23 --> Output Class Initialized
INFO - 2018-01-18 09:32:23 --> Security Class Initialized
DEBUG - 2018-01-18 09:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:32:23 --> Input Class Initialized
INFO - 2018-01-18 09:32:23 --> Language Class Initialized
INFO - 2018-01-18 09:32:23 --> Loader Class Initialized
INFO - 2018-01-18 09:32:23 --> Helper loaded: url_helper
INFO - 2018-01-18 09:32:23 --> Helper loaded: form_helper
INFO - 2018-01-18 09:32:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:32:23 --> Form Validation Class Initialized
INFO - 2018-01-18 09:32:23 --> Model Class Initialized
INFO - 2018-01-18 09:32:23 --> Controller Class Initialized
INFO - 2018-01-18 09:32:23 --> Model Class Initialized
INFO - 2018-01-18 09:32:23 --> Model Class Initialized
DEBUG - 2018-01-18 09:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:32:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:32:23 --> Final output sent to browser
DEBUG - 2018-01-18 09:32:23 --> Total execution time: 0.0375
INFO - 2018-01-18 09:34:00 --> Config Class Initialized
INFO - 2018-01-18 09:34:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:34:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:34:00 --> Utf8 Class Initialized
INFO - 2018-01-18 09:34:00 --> URI Class Initialized
INFO - 2018-01-18 09:34:00 --> Router Class Initialized
INFO - 2018-01-18 09:34:00 --> Output Class Initialized
INFO - 2018-01-18 09:34:00 --> Security Class Initialized
DEBUG - 2018-01-18 09:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:34:00 --> Input Class Initialized
INFO - 2018-01-18 09:34:00 --> Language Class Initialized
INFO - 2018-01-18 09:34:00 --> Loader Class Initialized
INFO - 2018-01-18 09:34:00 --> Helper loaded: url_helper
INFO - 2018-01-18 09:34:00 --> Helper loaded: form_helper
INFO - 2018-01-18 09:34:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:34:00 --> Form Validation Class Initialized
INFO - 2018-01-18 09:34:00 --> Model Class Initialized
INFO - 2018-01-18 09:34:00 --> Controller Class Initialized
INFO - 2018-01-18 09:34:00 --> Model Class Initialized
INFO - 2018-01-18 09:34:00 --> Model Class Initialized
DEBUG - 2018-01-18 09:34:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:34:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:34:00 --> Final output sent to browser
DEBUG - 2018-01-18 09:34:00 --> Total execution time: 0.0446
INFO - 2018-01-18 09:34:04 --> Config Class Initialized
INFO - 2018-01-18 09:34:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:34:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:34:04 --> Utf8 Class Initialized
INFO - 2018-01-18 09:34:04 --> URI Class Initialized
INFO - 2018-01-18 09:34:04 --> Router Class Initialized
INFO - 2018-01-18 09:34:04 --> Output Class Initialized
INFO - 2018-01-18 09:34:04 --> Security Class Initialized
DEBUG - 2018-01-18 09:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:34:04 --> Input Class Initialized
INFO - 2018-01-18 09:34:04 --> Language Class Initialized
INFO - 2018-01-18 09:34:04 --> Loader Class Initialized
INFO - 2018-01-18 09:34:04 --> Helper loaded: url_helper
INFO - 2018-01-18 09:34:04 --> Helper loaded: form_helper
INFO - 2018-01-18 09:34:04 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:34:04 --> Form Validation Class Initialized
INFO - 2018-01-18 09:34:04 --> Model Class Initialized
INFO - 2018-01-18 09:34:04 --> Controller Class Initialized
INFO - 2018-01-18 09:34:04 --> Model Class Initialized
INFO - 2018-01-18 09:34:04 --> Model Class Initialized
DEBUG - 2018-01-18 09:34:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:34:04 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:34:04 --> Final output sent to browser
DEBUG - 2018-01-18 09:34:04 --> Total execution time: 0.0406
INFO - 2018-01-18 09:34:55 --> Config Class Initialized
INFO - 2018-01-18 09:34:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:34:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:34:55 --> Utf8 Class Initialized
INFO - 2018-01-18 09:34:55 --> URI Class Initialized
INFO - 2018-01-18 09:34:55 --> Router Class Initialized
INFO - 2018-01-18 09:34:55 --> Output Class Initialized
INFO - 2018-01-18 09:34:55 --> Security Class Initialized
DEBUG - 2018-01-18 09:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:34:55 --> Input Class Initialized
INFO - 2018-01-18 09:34:55 --> Language Class Initialized
INFO - 2018-01-18 09:34:55 --> Loader Class Initialized
INFO - 2018-01-18 09:34:55 --> Helper loaded: url_helper
INFO - 2018-01-18 09:34:55 --> Helper loaded: form_helper
INFO - 2018-01-18 09:34:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:34:55 --> Form Validation Class Initialized
INFO - 2018-01-18 09:34:55 --> Model Class Initialized
INFO - 2018-01-18 09:34:55 --> Controller Class Initialized
INFO - 2018-01-18 09:34:55 --> Model Class Initialized
INFO - 2018-01-18 09:34:55 --> Model Class Initialized
INFO - 2018-01-18 09:34:55 --> Model Class Initialized
INFO - 2018-01-18 09:34:55 --> Model Class Initialized
DEBUG - 2018-01-18 09:34:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 09:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 09:34:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:34:55 --> Final output sent to browser
DEBUG - 2018-01-18 09:34:55 --> Total execution time: 0.0469
INFO - 2018-01-18 09:34:58 --> Config Class Initialized
INFO - 2018-01-18 09:34:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:34:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:34:58 --> Utf8 Class Initialized
INFO - 2018-01-18 09:34:58 --> URI Class Initialized
INFO - 2018-01-18 09:34:58 --> Router Class Initialized
INFO - 2018-01-18 09:34:58 --> Output Class Initialized
INFO - 2018-01-18 09:34:58 --> Security Class Initialized
DEBUG - 2018-01-18 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:34:58 --> Input Class Initialized
INFO - 2018-01-18 09:34:58 --> Language Class Initialized
INFO - 2018-01-18 09:34:58 --> Loader Class Initialized
INFO - 2018-01-18 09:34:58 --> Helper loaded: url_helper
INFO - 2018-01-18 09:34:58 --> Helper loaded: form_helper
INFO - 2018-01-18 09:34:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:34:58 --> Form Validation Class Initialized
INFO - 2018-01-18 09:34:58 --> Model Class Initialized
INFO - 2018-01-18 09:34:58 --> Controller Class Initialized
INFO - 2018-01-18 09:34:58 --> Model Class Initialized
INFO - 2018-01-18 09:34:58 --> Model Class Initialized
INFO - 2018-01-18 09:34:58 --> Model Class Initialized
INFO - 2018-01-18 09:34:58 --> Model Class Initialized
DEBUG - 2018-01-18 09:34:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 09:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 09:34:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:34:58 --> Final output sent to browser
DEBUG - 2018-01-18 09:34:58 --> Total execution time: 0.0452
INFO - 2018-01-18 09:35:08 --> Config Class Initialized
INFO - 2018-01-18 09:35:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:35:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:35:08 --> Utf8 Class Initialized
INFO - 2018-01-18 09:35:08 --> URI Class Initialized
INFO - 2018-01-18 09:35:08 --> Router Class Initialized
INFO - 2018-01-18 09:35:08 --> Output Class Initialized
INFO - 2018-01-18 09:35:08 --> Security Class Initialized
DEBUG - 2018-01-18 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:35:08 --> Input Class Initialized
INFO - 2018-01-18 09:35:08 --> Language Class Initialized
INFO - 2018-01-18 09:35:08 --> Loader Class Initialized
INFO - 2018-01-18 09:35:08 --> Helper loaded: url_helper
INFO - 2018-01-18 09:35:08 --> Helper loaded: form_helper
INFO - 2018-01-18 09:35:08 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:35:08 --> Form Validation Class Initialized
INFO - 2018-01-18 09:35:08 --> Model Class Initialized
INFO - 2018-01-18 09:35:08 --> Controller Class Initialized
INFO - 2018-01-18 09:35:08 --> Model Class Initialized
INFO - 2018-01-18 09:35:08 --> Model Class Initialized
INFO - 2018-01-18 09:35:08 --> Model Class Initialized
INFO - 2018-01-18 09:35:08 --> Model Class Initialized
DEBUG - 2018-01-18 09:35:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 09:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 09:35:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:35:08 --> Final output sent to browser
DEBUG - 2018-01-18 09:35:08 --> Total execution time: 0.0610
INFO - 2018-01-18 09:35:12 --> Config Class Initialized
INFO - 2018-01-18 09:35:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:35:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:35:12 --> Utf8 Class Initialized
INFO - 2018-01-18 09:35:12 --> URI Class Initialized
INFO - 2018-01-18 09:35:12 --> Router Class Initialized
INFO - 2018-01-18 09:35:12 --> Output Class Initialized
INFO - 2018-01-18 09:35:12 --> Security Class Initialized
DEBUG - 2018-01-18 09:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:35:12 --> Input Class Initialized
INFO - 2018-01-18 09:35:12 --> Language Class Initialized
INFO - 2018-01-18 09:35:12 --> Loader Class Initialized
INFO - 2018-01-18 09:35:12 --> Helper loaded: url_helper
INFO - 2018-01-18 09:35:12 --> Helper loaded: form_helper
INFO - 2018-01-18 09:35:12 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:35:12 --> Form Validation Class Initialized
INFO - 2018-01-18 09:35:12 --> Model Class Initialized
INFO - 2018-01-18 09:35:12 --> Controller Class Initialized
INFO - 2018-01-18 09:35:12 --> Model Class Initialized
INFO - 2018-01-18 09:35:12 --> Model Class Initialized
INFO - 2018-01-18 09:35:12 --> Model Class Initialized
INFO - 2018-01-18 09:35:12 --> Model Class Initialized
DEBUG - 2018-01-18 09:35:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 09:35:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 09:35:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:35:12 --> Final output sent to browser
DEBUG - 2018-01-18 09:35:12 --> Total execution time: 0.0463
INFO - 2018-01-18 09:38:05 --> Config Class Initialized
INFO - 2018-01-18 09:38:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:38:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:38:05 --> Utf8 Class Initialized
INFO - 2018-01-18 09:38:05 --> URI Class Initialized
INFO - 2018-01-18 09:38:05 --> Router Class Initialized
INFO - 2018-01-18 09:38:05 --> Output Class Initialized
INFO - 2018-01-18 09:38:05 --> Security Class Initialized
DEBUG - 2018-01-18 09:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:38:05 --> Input Class Initialized
INFO - 2018-01-18 09:38:05 --> Language Class Initialized
INFO - 2018-01-18 09:38:05 --> Loader Class Initialized
INFO - 2018-01-18 09:38:05 --> Helper loaded: url_helper
INFO - 2018-01-18 09:38:05 --> Helper loaded: form_helper
INFO - 2018-01-18 09:38:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:38:05 --> Form Validation Class Initialized
INFO - 2018-01-18 09:38:05 --> Model Class Initialized
INFO - 2018-01-18 09:38:05 --> Controller Class Initialized
INFO - 2018-01-18 09:38:05 --> Model Class Initialized
INFO - 2018-01-18 09:38:05 --> Model Class Initialized
INFO - 2018-01-18 09:38:05 --> Model Class Initialized
INFO - 2018-01-18 09:38:05 --> Model Class Initialized
DEBUG - 2018-01-18 09:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:38:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:38:05 --> Final output sent to browser
DEBUG - 2018-01-18 09:38:05 --> Total execution time: 0.0759
INFO - 2018-01-18 09:38:27 --> Config Class Initialized
INFO - 2018-01-18 09:38:27 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:38:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:38:27 --> Utf8 Class Initialized
INFO - 2018-01-18 09:38:27 --> URI Class Initialized
DEBUG - 2018-01-18 09:38:27 --> No URI present. Default controller set.
INFO - 2018-01-18 09:38:27 --> Router Class Initialized
INFO - 2018-01-18 09:38:27 --> Output Class Initialized
INFO - 2018-01-18 09:38:27 --> Security Class Initialized
DEBUG - 2018-01-18 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:38:27 --> Input Class Initialized
INFO - 2018-01-18 09:38:27 --> Language Class Initialized
INFO - 2018-01-18 09:38:27 --> Loader Class Initialized
INFO - 2018-01-18 09:38:27 --> Helper loaded: url_helper
INFO - 2018-01-18 09:38:27 --> Helper loaded: form_helper
INFO - 2018-01-18 09:38:27 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:38:27 --> Form Validation Class Initialized
INFO - 2018-01-18 09:38:27 --> Model Class Initialized
INFO - 2018-01-18 09:38:27 --> Controller Class Initialized
INFO - 2018-01-18 09:38:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:38:27 --> Final output sent to browser
DEBUG - 2018-01-18 09:38:27 --> Total execution time: 0.0368
INFO - 2018-01-18 09:38:34 --> Config Class Initialized
INFO - 2018-01-18 09:38:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:38:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:38:34 --> Utf8 Class Initialized
INFO - 2018-01-18 09:38:34 --> URI Class Initialized
INFO - 2018-01-18 09:38:34 --> Router Class Initialized
INFO - 2018-01-18 09:38:34 --> Output Class Initialized
INFO - 2018-01-18 09:38:34 --> Security Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:38:34 --> Input Class Initialized
INFO - 2018-01-18 09:38:34 --> Language Class Initialized
INFO - 2018-01-18 09:38:34 --> Loader Class Initialized
INFO - 2018-01-18 09:38:34 --> Helper loaded: url_helper
INFO - 2018-01-18 09:38:34 --> Helper loaded: form_helper
INFO - 2018-01-18 09:38:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:38:34 --> Form Validation Class Initialized
INFO - 2018-01-18 09:38:34 --> Model Class Initialized
INFO - 2018-01-18 09:38:34 --> Controller Class Initialized
INFO - 2018-01-18 09:38:34 --> Model Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:38:34 --> Config Class Initialized
INFO - 2018-01-18 09:38:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:38:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:38:34 --> Utf8 Class Initialized
INFO - 2018-01-18 09:38:34 --> URI Class Initialized
INFO - 2018-01-18 09:38:34 --> Router Class Initialized
INFO - 2018-01-18 09:38:34 --> Output Class Initialized
INFO - 2018-01-18 09:38:34 --> Security Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:38:34 --> Input Class Initialized
INFO - 2018-01-18 09:38:34 --> Language Class Initialized
INFO - 2018-01-18 09:38:34 --> Loader Class Initialized
INFO - 2018-01-18 09:38:34 --> Helper loaded: url_helper
INFO - 2018-01-18 09:38:34 --> Helper loaded: form_helper
INFO - 2018-01-18 09:38:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:38:34 --> Form Validation Class Initialized
INFO - 2018-01-18 09:38:34 --> Model Class Initialized
INFO - 2018-01-18 09:38:34 --> Controller Class Initialized
INFO - 2018-01-18 09:38:34 --> Model Class Initialized
DEBUG - 2018-01-18 09:38:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:38:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:38:34 --> Final output sent to browser
DEBUG - 2018-01-18 09:38:34 --> Total execution time: 0.0422
INFO - 2018-01-18 09:43:37 --> Config Class Initialized
INFO - 2018-01-18 09:43:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:43:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:43:37 --> Utf8 Class Initialized
INFO - 2018-01-18 09:43:37 --> URI Class Initialized
INFO - 2018-01-18 09:43:37 --> Router Class Initialized
INFO - 2018-01-18 09:43:37 --> Output Class Initialized
INFO - 2018-01-18 09:43:37 --> Security Class Initialized
DEBUG - 2018-01-18 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:43:37 --> Input Class Initialized
INFO - 2018-01-18 09:43:37 --> Language Class Initialized
INFO - 2018-01-18 09:43:37 --> Loader Class Initialized
INFO - 2018-01-18 09:43:37 --> Helper loaded: url_helper
INFO - 2018-01-18 09:43:37 --> Helper loaded: form_helper
INFO - 2018-01-18 09:43:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:43:37 --> Form Validation Class Initialized
INFO - 2018-01-18 09:43:37 --> Model Class Initialized
INFO - 2018-01-18 09:43:37 --> Controller Class Initialized
INFO - 2018-01-18 09:43:37 --> Model Class Initialized
DEBUG - 2018-01-18 09:43:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 09:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 09:43:37 --> Config Class Initialized
INFO - 2018-01-18 09:43:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 09:43:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 09:43:37 --> Utf8 Class Initialized
INFO - 2018-01-18 09:43:37 --> URI Class Initialized
DEBUG - 2018-01-18 09:43:37 --> No URI present. Default controller set.
INFO - 2018-01-18 09:43:37 --> Router Class Initialized
INFO - 2018-01-18 09:43:37 --> Output Class Initialized
INFO - 2018-01-18 09:43:37 --> Security Class Initialized
DEBUG - 2018-01-18 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 09:43:37 --> Input Class Initialized
INFO - 2018-01-18 09:43:37 --> Language Class Initialized
INFO - 2018-01-18 09:43:37 --> Loader Class Initialized
INFO - 2018-01-18 09:43:37 --> Helper loaded: url_helper
INFO - 2018-01-18 09:43:37 --> Helper loaded: form_helper
INFO - 2018-01-18 09:43:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 09:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 09:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 09:43:37 --> Form Validation Class Initialized
INFO - 2018-01-18 09:43:37 --> Model Class Initialized
INFO - 2018-01-18 09:43:37 --> Controller Class Initialized
INFO - 2018-01-18 09:43:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 09:43:37 --> Final output sent to browser
DEBUG - 2018-01-18 09:43:37 --> Total execution time: 0.0392
INFO - 2018-01-18 10:18:46 --> Config Class Initialized
INFO - 2018-01-18 10:18:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:18:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:18:46 --> Utf8 Class Initialized
INFO - 2018-01-18 10:18:46 --> URI Class Initialized
INFO - 2018-01-18 10:18:46 --> Router Class Initialized
INFO - 2018-01-18 10:18:46 --> Output Class Initialized
INFO - 2018-01-18 10:18:46 --> Security Class Initialized
DEBUG - 2018-01-18 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:18:47 --> Input Class Initialized
INFO - 2018-01-18 10:18:47 --> Language Class Initialized
INFO - 2018-01-18 10:18:47 --> Loader Class Initialized
INFO - 2018-01-18 10:18:47 --> Helper loaded: url_helper
INFO - 2018-01-18 10:18:47 --> Helper loaded: form_helper
INFO - 2018-01-18 10:18:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:18:47 --> Form Validation Class Initialized
INFO - 2018-01-18 10:18:47 --> Model Class Initialized
INFO - 2018-01-18 10:18:47 --> Controller Class Initialized
INFO - 2018-01-18 10:18:47 --> Model Class Initialized
INFO - 2018-01-18 10:18:47 --> Model Class Initialized
INFO - 2018-01-18 10:18:47 --> Model Class Initialized
INFO - 2018-01-18 10:18:47 --> Model Class Initialized
DEBUG - 2018-01-18 10:18:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 10:18:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 10:18:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:18:47 --> Final output sent to browser
DEBUG - 2018-01-18 10:18:47 --> Total execution time: 0.0485
INFO - 2018-01-18 10:18:53 --> Config Class Initialized
INFO - 2018-01-18 10:18:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:18:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:18:53 --> Utf8 Class Initialized
INFO - 2018-01-18 10:18:53 --> URI Class Initialized
INFO - 2018-01-18 10:18:53 --> Router Class Initialized
INFO - 2018-01-18 10:18:53 --> Output Class Initialized
INFO - 2018-01-18 10:18:53 --> Security Class Initialized
DEBUG - 2018-01-18 10:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:18:53 --> Input Class Initialized
INFO - 2018-01-18 10:18:53 --> Language Class Initialized
INFO - 2018-01-18 10:18:53 --> Loader Class Initialized
INFO - 2018-01-18 10:18:53 --> Helper loaded: url_helper
INFO - 2018-01-18 10:18:53 --> Helper loaded: form_helper
INFO - 2018-01-18 10:18:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:18:53 --> Form Validation Class Initialized
INFO - 2018-01-18 10:18:53 --> Model Class Initialized
INFO - 2018-01-18 10:18:53 --> Controller Class Initialized
INFO - 2018-01-18 10:18:53 --> Model Class Initialized
INFO - 2018-01-18 10:18:53 --> Model Class Initialized
INFO - 2018-01-18 10:18:53 --> Model Class Initialized
INFO - 2018-01-18 10:18:53 --> Model Class Initialized
DEBUG - 2018-01-18 10:18:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 10:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 10:18:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:18:53 --> Final output sent to browser
DEBUG - 2018-01-18 10:18:53 --> Total execution time: 0.0561
INFO - 2018-01-18 10:19:37 --> Config Class Initialized
INFO - 2018-01-18 10:19:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:19:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:19:37 --> Utf8 Class Initialized
INFO - 2018-01-18 10:19:37 --> URI Class Initialized
INFO - 2018-01-18 10:19:37 --> Router Class Initialized
INFO - 2018-01-18 10:19:37 --> Output Class Initialized
INFO - 2018-01-18 10:19:37 --> Security Class Initialized
DEBUG - 2018-01-18 10:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:19:37 --> Input Class Initialized
INFO - 2018-01-18 10:19:37 --> Language Class Initialized
INFO - 2018-01-18 10:19:37 --> Loader Class Initialized
INFO - 2018-01-18 10:19:37 --> Helper loaded: url_helper
INFO - 2018-01-18 10:19:37 --> Helper loaded: form_helper
INFO - 2018-01-18 10:19:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:19:37 --> Form Validation Class Initialized
INFO - 2018-01-18 10:19:37 --> Model Class Initialized
INFO - 2018-01-18 10:19:37 --> Controller Class Initialized
INFO - 2018-01-18 10:19:37 --> Model Class Initialized
DEBUG - 2018-01-18 10:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 10:19:38 --> Config Class Initialized
INFO - 2018-01-18 10:19:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:19:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:19:38 --> Utf8 Class Initialized
INFO - 2018-01-18 10:19:38 --> URI Class Initialized
INFO - 2018-01-18 10:19:38 --> Router Class Initialized
INFO - 2018-01-18 10:19:38 --> Output Class Initialized
INFO - 2018-01-18 10:19:38 --> Security Class Initialized
DEBUG - 2018-01-18 10:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:19:38 --> Input Class Initialized
INFO - 2018-01-18 10:19:38 --> Language Class Initialized
INFO - 2018-01-18 10:19:38 --> Loader Class Initialized
INFO - 2018-01-18 10:19:38 --> Helper loaded: url_helper
INFO - 2018-01-18 10:19:38 --> Helper loaded: form_helper
INFO - 2018-01-18 10:19:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:19:38 --> Form Validation Class Initialized
INFO - 2018-01-18 10:19:38 --> Model Class Initialized
INFO - 2018-01-18 10:19:38 --> Controller Class Initialized
INFO - 2018-01-18 10:19:38 --> Model Class Initialized
DEBUG - 2018-01-18 10:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 10:19:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:19:38 --> Final output sent to browser
DEBUG - 2018-01-18 10:19:38 --> Total execution time: 0.0357
INFO - 2018-01-18 10:19:53 --> Config Class Initialized
INFO - 2018-01-18 10:19:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:19:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:19:53 --> Utf8 Class Initialized
INFO - 2018-01-18 10:19:53 --> URI Class Initialized
INFO - 2018-01-18 10:19:53 --> Router Class Initialized
INFO - 2018-01-18 10:19:53 --> Output Class Initialized
INFO - 2018-01-18 10:19:53 --> Security Class Initialized
DEBUG - 2018-01-18 10:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:19:53 --> Input Class Initialized
INFO - 2018-01-18 10:19:53 --> Language Class Initialized
INFO - 2018-01-18 10:19:53 --> Loader Class Initialized
INFO - 2018-01-18 10:19:53 --> Helper loaded: url_helper
INFO - 2018-01-18 10:19:53 --> Helper loaded: form_helper
INFO - 2018-01-18 10:19:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:19:53 --> Form Validation Class Initialized
INFO - 2018-01-18 10:19:53 --> Model Class Initialized
INFO - 2018-01-18 10:19:53 --> Controller Class Initialized
INFO - 2018-01-18 10:19:53 --> Model Class Initialized
DEBUG - 2018-01-18 10:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 10:19:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:19:53 --> Final output sent to browser
DEBUG - 2018-01-18 10:19:53 --> Total execution time: 0.0351
INFO - 2018-01-18 10:20:26 --> Config Class Initialized
INFO - 2018-01-18 10:20:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:20:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:20:26 --> Utf8 Class Initialized
INFO - 2018-01-18 10:20:26 --> URI Class Initialized
INFO - 2018-01-18 10:20:26 --> Router Class Initialized
INFO - 2018-01-18 10:20:26 --> Output Class Initialized
INFO - 2018-01-18 10:20:26 --> Security Class Initialized
DEBUG - 2018-01-18 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:20:26 --> Input Class Initialized
INFO - 2018-01-18 10:20:26 --> Language Class Initialized
INFO - 2018-01-18 10:20:26 --> Loader Class Initialized
INFO - 2018-01-18 10:20:26 --> Helper loaded: url_helper
INFO - 2018-01-18 10:20:26 --> Helper loaded: form_helper
INFO - 2018-01-18 10:20:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:20:26 --> Form Validation Class Initialized
INFO - 2018-01-18 10:20:26 --> Model Class Initialized
INFO - 2018-01-18 10:20:26 --> Controller Class Initialized
INFO - 2018-01-18 10:20:26 --> Model Class Initialized
DEBUG - 2018-01-18 10:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 10:20:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 10:20:27 --> Config Class Initialized
INFO - 2018-01-18 10:20:27 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:20:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:20:27 --> Utf8 Class Initialized
INFO - 2018-01-18 10:20:27 --> URI Class Initialized
DEBUG - 2018-01-18 10:20:27 --> No URI present. Default controller set.
INFO - 2018-01-18 10:20:27 --> Router Class Initialized
INFO - 2018-01-18 10:20:27 --> Output Class Initialized
INFO - 2018-01-18 10:20:27 --> Security Class Initialized
DEBUG - 2018-01-18 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:20:27 --> Input Class Initialized
INFO - 2018-01-18 10:20:27 --> Language Class Initialized
INFO - 2018-01-18 10:20:27 --> Loader Class Initialized
INFO - 2018-01-18 10:20:27 --> Helper loaded: url_helper
INFO - 2018-01-18 10:20:27 --> Helper loaded: form_helper
INFO - 2018-01-18 10:20:27 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:20:27 --> Form Validation Class Initialized
INFO - 2018-01-18 10:20:27 --> Model Class Initialized
INFO - 2018-01-18 10:20:27 --> Controller Class Initialized
INFO - 2018-01-18 10:20:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:20:27 --> Final output sent to browser
DEBUG - 2018-01-18 10:20:27 --> Total execution time: 0.0357
INFO - 2018-01-18 10:20:34 --> Config Class Initialized
INFO - 2018-01-18 10:20:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 10:20:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 10:20:34 --> Utf8 Class Initialized
INFO - 2018-01-18 10:20:34 --> URI Class Initialized
INFO - 2018-01-18 10:20:34 --> Router Class Initialized
INFO - 2018-01-18 10:20:34 --> Output Class Initialized
INFO - 2018-01-18 10:20:34 --> Security Class Initialized
DEBUG - 2018-01-18 10:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 10:20:34 --> Input Class Initialized
INFO - 2018-01-18 10:20:34 --> Language Class Initialized
INFO - 2018-01-18 10:20:34 --> Loader Class Initialized
INFO - 2018-01-18 10:20:34 --> Helper loaded: url_helper
INFO - 2018-01-18 10:20:34 --> Helper loaded: form_helper
INFO - 2018-01-18 10:20:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 10:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 10:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 10:20:34 --> Form Validation Class Initialized
INFO - 2018-01-18 10:20:34 --> Model Class Initialized
INFO - 2018-01-18 10:20:34 --> Controller Class Initialized
INFO - 2018-01-18 10:20:34 --> Model Class Initialized
INFO - 2018-01-18 10:20:34 --> Model Class Initialized
INFO - 2018-01-18 10:20:34 --> Model Class Initialized
INFO - 2018-01-18 10:20:34 --> Model Class Initialized
DEBUG - 2018-01-18 10:20:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 10:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 10:20:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 10:20:34 --> Final output sent to browser
DEBUG - 2018-01-18 10:20:34 --> Total execution time: 0.0465
INFO - 2018-01-18 11:22:26 --> Config Class Initialized
INFO - 2018-01-18 11:22:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:22:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:22:26 --> Utf8 Class Initialized
INFO - 2018-01-18 11:22:26 --> URI Class Initialized
DEBUG - 2018-01-18 11:22:26 --> No URI present. Default controller set.
INFO - 2018-01-18 11:22:26 --> Router Class Initialized
INFO - 2018-01-18 11:22:26 --> Output Class Initialized
INFO - 2018-01-18 11:22:26 --> Security Class Initialized
DEBUG - 2018-01-18 11:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:22:26 --> Input Class Initialized
INFO - 2018-01-18 11:22:26 --> Language Class Initialized
INFO - 2018-01-18 11:22:26 --> Loader Class Initialized
INFO - 2018-01-18 11:22:26 --> Helper loaded: url_helper
INFO - 2018-01-18 11:22:26 --> Helper loaded: form_helper
INFO - 2018-01-18 11:22:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:22:27 --> Form Validation Class Initialized
INFO - 2018-01-18 11:22:27 --> Model Class Initialized
INFO - 2018-01-18 11:22:27 --> Controller Class Initialized
INFO - 2018-01-18 11:22:27 --> Config Class Initialized
INFO - 2018-01-18 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:22:27 --> Utf8 Class Initialized
INFO - 2018-01-18 11:22:27 --> URI Class Initialized
INFO - 2018-01-18 11:22:27 --> Router Class Initialized
INFO - 2018-01-18 11:22:27 --> Output Class Initialized
INFO - 2018-01-18 11:22:27 --> Security Class Initialized
DEBUG - 2018-01-18 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:22:27 --> Input Class Initialized
INFO - 2018-01-18 11:22:27 --> Language Class Initialized
INFO - 2018-01-18 11:22:27 --> Loader Class Initialized
INFO - 2018-01-18 11:22:27 --> Helper loaded: url_helper
INFO - 2018-01-18 11:22:27 --> Helper loaded: form_helper
INFO - 2018-01-18 11:22:27 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:22:27 --> Form Validation Class Initialized
INFO - 2018-01-18 11:22:27 --> Model Class Initialized
INFO - 2018-01-18 11:22:27 --> Controller Class Initialized
INFO - 2018-01-18 11:22:27 --> Model Class Initialized
DEBUG - 2018-01-18 11:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:22:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:22:27 --> Final output sent to browser
DEBUG - 2018-01-18 11:22:27 --> Total execution time: 0.0384
INFO - 2018-01-18 11:23:15 --> Config Class Initialized
INFO - 2018-01-18 11:23:15 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:15 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:15 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:15 --> URI Class Initialized
INFO - 2018-01-18 11:23:15 --> Router Class Initialized
INFO - 2018-01-18 11:23:15 --> Output Class Initialized
INFO - 2018-01-18 11:23:15 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:15 --> Input Class Initialized
INFO - 2018-01-18 11:23:15 --> Language Class Initialized
INFO - 2018-01-18 11:23:15 --> Loader Class Initialized
INFO - 2018-01-18 11:23:15 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:15 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:15 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:15 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:15 --> Model Class Initialized
INFO - 2018-01-18 11:23:15 --> Controller Class Initialized
INFO - 2018-01-18 11:23:15 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:23:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 11:23:16 --> Config Class Initialized
INFO - 2018-01-18 11:23:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:16 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:16 --> URI Class Initialized
DEBUG - 2018-01-18 11:23:16 --> No URI present. Default controller set.
INFO - 2018-01-18 11:23:16 --> Router Class Initialized
INFO - 2018-01-18 11:23:16 --> Output Class Initialized
INFO - 2018-01-18 11:23:16 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:16 --> Input Class Initialized
INFO - 2018-01-18 11:23:16 --> Language Class Initialized
INFO - 2018-01-18 11:23:16 --> Loader Class Initialized
INFO - 2018-01-18 11:23:16 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:16 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:16 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:16 --> Model Class Initialized
INFO - 2018-01-18 11:23:16 --> Controller Class Initialized
INFO - 2018-01-18 11:23:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:16 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:16 --> Total execution time: 0.0450
INFO - 2018-01-18 11:23:28 --> Config Class Initialized
INFO - 2018-01-18 11:23:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:28 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:28 --> URI Class Initialized
INFO - 2018-01-18 11:23:28 --> Router Class Initialized
INFO - 2018-01-18 11:23:28 --> Output Class Initialized
INFO - 2018-01-18 11:23:28 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:28 --> Input Class Initialized
INFO - 2018-01-18 11:23:28 --> Language Class Initialized
INFO - 2018-01-18 11:23:28 --> Loader Class Initialized
INFO - 2018-01-18 11:23:28 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:28 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:28 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:28 --> Model Class Initialized
INFO - 2018-01-18 11:23:28 --> Controller Class Initialized
INFO - 2018-01-18 11:23:28 --> Model Class Initialized
INFO - 2018-01-18 11:23:28 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:23:28 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:28 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:28 --> Total execution time: 0.0548
INFO - 2018-01-18 11:23:29 --> Config Class Initialized
INFO - 2018-01-18 11:23:29 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:29 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:29 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:29 --> URI Class Initialized
INFO - 2018-01-18 11:23:29 --> Router Class Initialized
INFO - 2018-01-18 11:23:29 --> Output Class Initialized
INFO - 2018-01-18 11:23:29 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:29 --> Input Class Initialized
INFO - 2018-01-18 11:23:29 --> Language Class Initialized
INFO - 2018-01-18 11:23:29 --> Loader Class Initialized
INFO - 2018-01-18 11:23:29 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:29 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:29 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:29 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:29 --> Model Class Initialized
INFO - 2018-01-18 11:23:29 --> Controller Class Initialized
INFO - 2018-01-18 11:23:29 --> Model Class Initialized
INFO - 2018-01-18 11:23:29 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:23:29 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:29 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:29 --> Total execution time: 0.0415
INFO - 2018-01-18 11:23:31 --> Config Class Initialized
INFO - 2018-01-18 11:23:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:31 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:31 --> URI Class Initialized
INFO - 2018-01-18 11:23:31 --> Router Class Initialized
INFO - 2018-01-18 11:23:31 --> Output Class Initialized
INFO - 2018-01-18 11:23:31 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:31 --> Input Class Initialized
INFO - 2018-01-18 11:23:31 --> Language Class Initialized
INFO - 2018-01-18 11:23:31 --> Loader Class Initialized
INFO - 2018-01-18 11:23:31 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:31 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:31 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:31 --> Model Class Initialized
INFO - 2018-01-18 11:23:31 --> Controller Class Initialized
INFO - 2018-01-18 11:23:31 --> Model Class Initialized
INFO - 2018-01-18 11:23:31 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:23:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:31 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:31 --> Total execution time: 0.0394
INFO - 2018-01-18 11:23:35 --> Config Class Initialized
INFO - 2018-01-18 11:23:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:35 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:35 --> URI Class Initialized
INFO - 2018-01-18 11:23:35 --> Router Class Initialized
INFO - 2018-01-18 11:23:35 --> Output Class Initialized
INFO - 2018-01-18 11:23:35 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:35 --> Input Class Initialized
INFO - 2018-01-18 11:23:35 --> Language Class Initialized
INFO - 2018-01-18 11:23:35 --> Loader Class Initialized
INFO - 2018-01-18 11:23:35 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:35 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:35 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:35 --> Model Class Initialized
INFO - 2018-01-18 11:23:35 --> Controller Class Initialized
INFO - 2018-01-18 11:23:35 --> Model Class Initialized
INFO - 2018-01-18 11:23:35 --> Model Class Initialized
INFO - 2018-01-18 11:23:35 --> Model Class Initialized
INFO - 2018-01-18 11:23:35 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:23:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 11:23:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:35 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:35 --> Total execution time: 0.0623
INFO - 2018-01-18 11:23:37 --> Config Class Initialized
INFO - 2018-01-18 11:23:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:37 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:37 --> URI Class Initialized
INFO - 2018-01-18 11:23:37 --> Router Class Initialized
INFO - 2018-01-18 11:23:37 --> Output Class Initialized
INFO - 2018-01-18 11:23:37 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:37 --> Input Class Initialized
INFO - 2018-01-18 11:23:37 --> Language Class Initialized
INFO - 2018-01-18 11:23:37 --> Loader Class Initialized
INFO - 2018-01-18 11:23:37 --> Helper loaded: url_helper
INFO - 2018-01-18 11:23:37 --> Helper loaded: form_helper
INFO - 2018-01-18 11:23:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:23:37 --> Form Validation Class Initialized
INFO - 2018-01-18 11:23:37 --> Model Class Initialized
INFO - 2018-01-18 11:23:37 --> Controller Class Initialized
INFO - 2018-01-18 11:23:37 --> Model Class Initialized
INFO - 2018-01-18 11:23:37 --> Model Class Initialized
INFO - 2018-01-18 11:23:37 --> Model Class Initialized
INFO - 2018-01-18 11:23:37 --> Model Class Initialized
DEBUG - 2018-01-18 11:23:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:23:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 11:23:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:23:37 --> Final output sent to browser
DEBUG - 2018-01-18 11:23:37 --> Total execution time: 0.0464
INFO - 2018-01-18 11:23:53 --> Config Class Initialized
INFO - 2018-01-18 11:23:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:53 --> URI Class Initialized
INFO - 2018-01-18 11:23:53 --> Router Class Initialized
INFO - 2018-01-18 11:23:53 --> Output Class Initialized
INFO - 2018-01-18 11:23:53 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:53 --> Input Class Initialized
INFO - 2018-01-18 11:23:53 --> Language Class Initialized
ERROR - 2018-01-18 11:23:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:23:53 --> Config Class Initialized
INFO - 2018-01-18 11:23:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:23:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:23:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:23:53 --> URI Class Initialized
INFO - 2018-01-18 11:23:53 --> Router Class Initialized
INFO - 2018-01-18 11:23:53 --> Output Class Initialized
INFO - 2018-01-18 11:23:53 --> Security Class Initialized
DEBUG - 2018-01-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:23:53 --> Input Class Initialized
INFO - 2018-01-18 11:23:53 --> Language Class Initialized
ERROR - 2018-01-18 11:23:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:24:07 --> Config Class Initialized
INFO - 2018-01-18 11:24:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:07 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:07 --> URI Class Initialized
INFO - 2018-01-18 11:24:07 --> Router Class Initialized
INFO - 2018-01-18 11:24:07 --> Output Class Initialized
INFO - 2018-01-18 11:24:07 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:07 --> Input Class Initialized
INFO - 2018-01-18 11:24:07 --> Language Class Initialized
INFO - 2018-01-18 11:24:07 --> Loader Class Initialized
INFO - 2018-01-18 11:24:07 --> Helper loaded: url_helper
INFO - 2018-01-18 11:24:07 --> Helper loaded: form_helper
INFO - 2018-01-18 11:24:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:24:07 --> Form Validation Class Initialized
INFO - 2018-01-18 11:24:07 --> Model Class Initialized
INFO - 2018-01-18 11:24:07 --> Controller Class Initialized
INFO - 2018-01-18 11:24:07 --> Model Class Initialized
INFO - 2018-01-18 11:24:07 --> Model Class Initialized
DEBUG - 2018-01-18 11:24:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:24:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:24:07 --> Final output sent to browser
DEBUG - 2018-01-18 11:24:07 --> Total execution time: 0.0451
INFO - 2018-01-18 11:24:08 --> Config Class Initialized
INFO - 2018-01-18 11:24:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:08 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:08 --> URI Class Initialized
INFO - 2018-01-18 11:24:08 --> Router Class Initialized
INFO - 2018-01-18 11:24:08 --> Config Class Initialized
INFO - 2018-01-18 11:24:08 --> Hooks Class Initialized
INFO - 2018-01-18 11:24:08 --> Output Class Initialized
DEBUG - 2018-01-18 11:24:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:08 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:08 --> URI Class Initialized
INFO - 2018-01-18 11:24:08 --> Security Class Initialized
INFO - 2018-01-18 11:24:08 --> Router Class Initialized
DEBUG - 2018-01-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:08 --> Input Class Initialized
INFO - 2018-01-18 11:24:08 --> Language Class Initialized
INFO - 2018-01-18 11:24:08 --> Output Class Initialized
ERROR - 2018-01-18 11:24:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:24:08 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:08 --> Input Class Initialized
INFO - 2018-01-18 11:24:08 --> Language Class Initialized
ERROR - 2018-01-18 11:24:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:24:08 --> Config Class Initialized
INFO - 2018-01-18 11:24:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:08 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:08 --> URI Class Initialized
INFO - 2018-01-18 11:24:08 --> Router Class Initialized
INFO - 2018-01-18 11:24:08 --> Output Class Initialized
INFO - 2018-01-18 11:24:08 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:08 --> Input Class Initialized
INFO - 2018-01-18 11:24:08 --> Language Class Initialized
ERROR - 2018-01-18 11:24:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:24:14 --> Config Class Initialized
INFO - 2018-01-18 11:24:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:14 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:14 --> URI Class Initialized
INFO - 2018-01-18 11:24:14 --> Router Class Initialized
INFO - 2018-01-18 11:24:14 --> Output Class Initialized
INFO - 2018-01-18 11:24:14 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:14 --> Input Class Initialized
INFO - 2018-01-18 11:24:14 --> Language Class Initialized
INFO - 2018-01-18 11:24:14 --> Loader Class Initialized
INFO - 2018-01-18 11:24:14 --> Helper loaded: url_helper
INFO - 2018-01-18 11:24:14 --> Helper loaded: form_helper
INFO - 2018-01-18 11:24:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:24:14 --> Form Validation Class Initialized
INFO - 2018-01-18 11:24:14 --> Model Class Initialized
INFO - 2018-01-18 11:24:14 --> Controller Class Initialized
INFO - 2018-01-18 11:24:14 --> Model Class Initialized
INFO - 2018-01-18 11:24:14 --> Model Class Initialized
DEBUG - 2018-01-18 11:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:24:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:24:14 --> Final output sent to browser
DEBUG - 2018-01-18 11:24:14 --> Total execution time: 0.0401
INFO - 2018-01-18 11:24:18 --> Config Class Initialized
INFO - 2018-01-18 11:24:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:18 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:18 --> URI Class Initialized
INFO - 2018-01-18 11:24:18 --> Router Class Initialized
INFO - 2018-01-18 11:24:18 --> Output Class Initialized
INFO - 2018-01-18 11:24:18 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:18 --> Input Class Initialized
INFO - 2018-01-18 11:24:18 --> Language Class Initialized
ERROR - 2018-01-18 11:24:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:24:18 --> Config Class Initialized
INFO - 2018-01-18 11:24:18 --> Hooks Class Initialized
INFO - 2018-01-18 11:24:18 --> Config Class Initialized
INFO - 2018-01-18 11:24:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:18 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:18 --> URI Class Initialized
DEBUG - 2018-01-18 11:24:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:18 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:18 --> Router Class Initialized
INFO - 2018-01-18 11:24:18 --> URI Class Initialized
INFO - 2018-01-18 11:24:18 --> Router Class Initialized
INFO - 2018-01-18 11:24:18 --> Output Class Initialized
INFO - 2018-01-18 11:24:18 --> Config Class Initialized
INFO - 2018-01-18 11:24:18 --> Hooks Class Initialized
INFO - 2018-01-18 11:24:18 --> Security Class Initialized
INFO - 2018-01-18 11:24:18 --> Output Class Initialized
DEBUG - 2018-01-18 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2018-01-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:18 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:18 --> Input Class Initialized
INFO - 2018-01-18 11:24:18 --> Security Class Initialized
INFO - 2018-01-18 11:24:18 --> Language Class Initialized
ERROR - 2018-01-18 11:24:18 --> 404 Page Not Found: Clientes/cliente
DEBUG - 2018-01-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:18 --> Input Class Initialized
INFO - 2018-01-18 11:24:18 --> URI Class Initialized
INFO - 2018-01-18 11:24:18 --> Language Class Initialized
ERROR - 2018-01-18 11:24:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:24:18 --> Router Class Initialized
INFO - 2018-01-18 11:24:18 --> Output Class Initialized
INFO - 2018-01-18 11:24:18 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:18 --> Input Class Initialized
INFO - 2018-01-18 11:24:18 --> Language Class Initialized
ERROR - 2018-01-18 11:24:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:24:50 --> Config Class Initialized
INFO - 2018-01-18 11:24:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:50 --> URI Class Initialized
INFO - 2018-01-18 11:24:50 --> Router Class Initialized
INFO - 2018-01-18 11:24:50 --> Output Class Initialized
INFO - 2018-01-18 11:24:50 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:50 --> Input Class Initialized
INFO - 2018-01-18 11:24:50 --> Language Class Initialized
INFO - 2018-01-18 11:24:50 --> Loader Class Initialized
INFO - 2018-01-18 11:24:50 --> Helper loaded: url_helper
INFO - 2018-01-18 11:24:50 --> Helper loaded: form_helper
INFO - 2018-01-18 11:24:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:24:50 --> Form Validation Class Initialized
INFO - 2018-01-18 11:24:50 --> Model Class Initialized
INFO - 2018-01-18 11:24:50 --> Controller Class Initialized
INFO - 2018-01-18 11:24:50 --> Model Class Initialized
INFO - 2018-01-18 11:24:50 --> Model Class Initialized
DEBUG - 2018-01-18 11:24:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:24:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:24:50 --> Final output sent to browser
DEBUG - 2018-01-18 11:24:50 --> Total execution time: 0.0398
INFO - 2018-01-18 11:24:53 --> Config Class Initialized
INFO - 2018-01-18 11:24:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:53 --> URI Class Initialized
INFO - 2018-01-18 11:24:53 --> Router Class Initialized
INFO - 2018-01-18 11:24:53 --> Output Class Initialized
INFO - 2018-01-18 11:24:53 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:53 --> Input Class Initialized
INFO - 2018-01-18 11:24:53 --> Language Class Initialized
ERROR - 2018-01-18 11:24:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:24:53 --> Config Class Initialized
INFO - 2018-01-18 11:24:53 --> Config Class Initialized
INFO - 2018-01-18 11:24:53 --> Hooks Class Initialized
INFO - 2018-01-18 11:24:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-01-18 11:24:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:53 --> URI Class Initialized
INFO - 2018-01-18 11:24:53 --> URI Class Initialized
INFO - 2018-01-18 11:24:53 --> Router Class Initialized
INFO - 2018-01-18 11:24:53 --> Router Class Initialized
INFO - 2018-01-18 11:24:53 --> Config Class Initialized
INFO - 2018-01-18 11:24:53 --> Hooks Class Initialized
INFO - 2018-01-18 11:24:53 --> Output Class Initialized
INFO - 2018-01-18 11:24:53 --> Output Class Initialized
INFO - 2018-01-18 11:24:53 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:24:53 --> Utf8 Class Initialized
INFO - 2018-01-18 11:24:53 --> Security Class Initialized
INFO - 2018-01-18 11:24:53 --> URI Class Initialized
DEBUG - 2018-01-18 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:53 --> Input Class Initialized
DEBUG - 2018-01-18 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:53 --> Input Class Initialized
INFO - 2018-01-18 11:24:53 --> Language Class Initialized
INFO - 2018-01-18 11:24:53 --> Language Class Initialized
INFO - 2018-01-18 11:24:53 --> Router Class Initialized
ERROR - 2018-01-18 11:24:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 11:24:53 --> 404 Page Not Found: Clientes/cliente
INFO - 2018-01-18 11:24:53 --> Output Class Initialized
INFO - 2018-01-18 11:24:53 --> Security Class Initialized
DEBUG - 2018-01-18 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:24:53 --> Input Class Initialized
INFO - 2018-01-18 11:24:53 --> Language Class Initialized
ERROR - 2018-01-18 11:24:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:25:07 --> Config Class Initialized
INFO - 2018-01-18 11:25:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:07 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:07 --> URI Class Initialized
INFO - 2018-01-18 11:25:07 --> Router Class Initialized
INFO - 2018-01-18 11:25:07 --> Output Class Initialized
INFO - 2018-01-18 11:25:07 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:07 --> Input Class Initialized
INFO - 2018-01-18 11:25:07 --> Language Class Initialized
INFO - 2018-01-18 11:25:07 --> Loader Class Initialized
INFO - 2018-01-18 11:25:07 --> Helper loaded: url_helper
INFO - 2018-01-18 11:25:07 --> Helper loaded: form_helper
INFO - 2018-01-18 11:25:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:25:07 --> Form Validation Class Initialized
INFO - 2018-01-18 11:25:07 --> Model Class Initialized
INFO - 2018-01-18 11:25:07 --> Controller Class Initialized
INFO - 2018-01-18 11:25:07 --> Model Class Initialized
INFO - 2018-01-18 11:25:07 --> Model Class Initialized
DEBUG - 2018-01-18 11:25:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:25:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:25:07 --> Final output sent to browser
DEBUG - 2018-01-18 11:25:07 --> Total execution time: 0.0470
INFO - 2018-01-18 11:25:09 --> Config Class Initialized
INFO - 2018-01-18 11:25:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:09 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:09 --> URI Class Initialized
INFO - 2018-01-18 11:25:09 --> Router Class Initialized
INFO - 2018-01-18 11:25:09 --> Output Class Initialized
INFO - 2018-01-18 11:25:09 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:09 --> Input Class Initialized
INFO - 2018-01-18 11:25:09 --> Language Class Initialized
ERROR - 2018-01-18 11:25:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:25:09 --> Config Class Initialized
INFO - 2018-01-18 11:25:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:09 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:09 --> URI Class Initialized
INFO - 2018-01-18 11:25:09 --> Config Class Initialized
INFO - 2018-01-18 11:25:09 --> Hooks Class Initialized
INFO - 2018-01-18 11:25:09 --> Router Class Initialized
INFO - 2018-01-18 11:25:09 --> Config Class Initialized
INFO - 2018-01-18 11:25:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:09 --> Output Class Initialized
INFO - 2018-01-18 11:25:09 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:25:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:09 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:09 --> Security Class Initialized
INFO - 2018-01-18 11:25:09 --> URI Class Initialized
DEBUG - 2018-01-18 11:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:09 --> URI Class Initialized
INFO - 2018-01-18 11:25:09 --> Input Class Initialized
INFO - 2018-01-18 11:25:09 --> Language Class Initialized
INFO - 2018-01-18 11:25:09 --> Router Class Initialized
INFO - 2018-01-18 11:25:09 --> Router Class Initialized
INFO - 2018-01-18 11:25:09 --> Output Class Initialized
INFO - 2018-01-18 11:25:09 --> Loader Class Initialized
INFO - 2018-01-18 11:25:09 --> Output Class Initialized
INFO - 2018-01-18 11:25:09 --> Helper loaded: url_helper
INFO - 2018-01-18 11:25:09 --> Security Class Initialized
INFO - 2018-01-18 11:25:09 --> Security Class Initialized
INFO - 2018-01-18 11:25:09 --> Helper loaded: form_helper
DEBUG - 2018-01-18 11:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:09 --> Input Class Initialized
INFO - 2018-01-18 11:25:09 --> Language Class Initialized
DEBUG - 2018-01-18 11:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-01-18 11:25:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:25:09 --> Input Class Initialized
INFO - 2018-01-18 11:25:09 --> Language Class Initialized
ERROR - 2018-01-18 11:25:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:25:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:25:09 --> Form Validation Class Initialized
INFO - 2018-01-18 11:25:09 --> Model Class Initialized
INFO - 2018-01-18 11:25:09 --> Controller Class Initialized
INFO - 2018-01-18 11:25:09 --> Model Class Initialized
INFO - 2018-01-18 11:25:09 --> Model Class Initialized
DEBUG - 2018-01-18 11:25:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:25:13 --> Config Class Initialized
INFO - 2018-01-18 11:25:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:13 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:13 --> URI Class Initialized
INFO - 2018-01-18 11:25:13 --> Router Class Initialized
INFO - 2018-01-18 11:25:13 --> Output Class Initialized
INFO - 2018-01-18 11:25:13 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:13 --> Input Class Initialized
INFO - 2018-01-18 11:25:13 --> Language Class Initialized
INFO - 2018-01-18 11:25:13 --> Loader Class Initialized
INFO - 2018-01-18 11:25:13 --> Helper loaded: url_helper
INFO - 2018-01-18 11:25:13 --> Helper loaded: form_helper
INFO - 2018-01-18 11:25:13 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:25:13 --> Form Validation Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
INFO - 2018-01-18 11:25:13 --> Controller Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:25:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:25:13 --> Final output sent to browser
DEBUG - 2018-01-18 11:25:13 --> Total execution time: 0.0391
INFO - 2018-01-18 11:25:13 --> Config Class Initialized
INFO - 2018-01-18 11:25:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:13 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:13 --> URI Class Initialized
INFO - 2018-01-18 11:25:13 --> Router Class Initialized
INFO - 2018-01-18 11:25:13 --> Output Class Initialized
INFO - 2018-01-18 11:25:13 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:13 --> Input Class Initialized
INFO - 2018-01-18 11:25:13 --> Language Class Initialized
ERROR - 2018-01-18 11:25:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:25:13 --> Config Class Initialized
INFO - 2018-01-18 11:25:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:13 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:13 --> URI Class Initialized
INFO - 2018-01-18 11:25:13 --> Router Class Initialized
INFO - 2018-01-18 11:25:13 --> Output Class Initialized
INFO - 2018-01-18 11:25:13 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:13 --> Input Class Initialized
INFO - 2018-01-18 11:25:13 --> Language Class Initialized
INFO - 2018-01-18 11:25:13 --> Loader Class Initialized
INFO - 2018-01-18 11:25:13 --> Helper loaded: url_helper
INFO - 2018-01-18 11:25:13 --> Helper loaded: form_helper
INFO - 2018-01-18 11:25:13 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:25:13 --> Form Validation Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
INFO - 2018-01-18 11:25:13 --> Controller Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
INFO - 2018-01-18 11:25:13 --> Model Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:25:13 --> Config Class Initialized
INFO - 2018-01-18 11:25:13 --> Hooks Class Initialized
INFO - 2018-01-18 11:25:13 --> Config Class Initialized
INFO - 2018-01-18 11:25:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:25:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:13 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:25:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:25:13 --> Utf8 Class Initialized
INFO - 2018-01-18 11:25:13 --> URI Class Initialized
INFO - 2018-01-18 11:25:13 --> URI Class Initialized
INFO - 2018-01-18 11:25:13 --> Router Class Initialized
INFO - 2018-01-18 11:25:13 --> Router Class Initialized
INFO - 2018-01-18 11:25:13 --> Output Class Initialized
INFO - 2018-01-18 11:25:13 --> Output Class Initialized
INFO - 2018-01-18 11:25:13 --> Security Class Initialized
INFO - 2018-01-18 11:25:13 --> Security Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:13 --> Input Class Initialized
DEBUG - 2018-01-18 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:25:13 --> Input Class Initialized
INFO - 2018-01-18 11:25:13 --> Language Class Initialized
INFO - 2018-01-18 11:25:13 --> Language Class Initialized
ERROR - 2018-01-18 11:25:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 11:25:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:26:58 --> Config Class Initialized
INFO - 2018-01-18 11:26:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:26:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:26:58 --> Utf8 Class Initialized
INFO - 2018-01-18 11:26:58 --> URI Class Initialized
INFO - 2018-01-18 11:26:58 --> Router Class Initialized
INFO - 2018-01-18 11:26:58 --> Output Class Initialized
INFO - 2018-01-18 11:26:58 --> Security Class Initialized
DEBUG - 2018-01-18 11:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:26:58 --> Input Class Initialized
INFO - 2018-01-18 11:26:58 --> Language Class Initialized
INFO - 2018-01-18 11:26:58 --> Loader Class Initialized
INFO - 2018-01-18 11:26:58 --> Helper loaded: url_helper
INFO - 2018-01-18 11:26:58 --> Helper loaded: form_helper
INFO - 2018-01-18 11:26:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:26:58 --> Form Validation Class Initialized
INFO - 2018-01-18 11:26:58 --> Model Class Initialized
INFO - 2018-01-18 11:26:58 --> Controller Class Initialized
INFO - 2018-01-18 11:26:58 --> Model Class Initialized
INFO - 2018-01-18 11:26:58 --> Model Class Initialized
INFO - 2018-01-18 11:26:58 --> Model Class Initialized
INFO - 2018-01-18 11:26:58 --> Model Class Initialized
DEBUG - 2018-01-18 11:26:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 11:26:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:26:58 --> Final output sent to browser
DEBUG - 2018-01-18 11:26:58 --> Total execution time: 0.0477
INFO - 2018-01-18 11:26:59 --> Config Class Initialized
INFO - 2018-01-18 11:26:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:26:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:26:59 --> Utf8 Class Initialized
INFO - 2018-01-18 11:26:59 --> URI Class Initialized
INFO - 2018-01-18 11:26:59 --> Router Class Initialized
INFO - 2018-01-18 11:26:59 --> Output Class Initialized
INFO - 2018-01-18 11:26:59 --> Security Class Initialized
INFO - 2018-01-18 11:26:59 --> Config Class Initialized
DEBUG - 2018-01-18 11:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:26:59 --> Hooks Class Initialized
INFO - 2018-01-18 11:26:59 --> Input Class Initialized
INFO - 2018-01-18 11:26:59 --> Language Class Initialized
ERROR - 2018-01-18 11:26:59 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-01-18 11:26:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:26:59 --> Utf8 Class Initialized
INFO - 2018-01-18 11:26:59 --> URI Class Initialized
INFO - 2018-01-18 11:26:59 --> Router Class Initialized
INFO - 2018-01-18 11:26:59 --> Output Class Initialized
INFO - 2018-01-18 11:26:59 --> Security Class Initialized
DEBUG - 2018-01-18 11:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:26:59 --> Input Class Initialized
INFO - 2018-01-18 11:26:59 --> Language Class Initialized
ERROR - 2018-01-18 11:26:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:26:59 --> Config Class Initialized
INFO - 2018-01-18 11:26:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:26:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:26:59 --> Utf8 Class Initialized
INFO - 2018-01-18 11:26:59 --> URI Class Initialized
INFO - 2018-01-18 11:26:59 --> Router Class Initialized
INFO - 2018-01-18 11:26:59 --> Output Class Initialized
INFO - 2018-01-18 11:26:59 --> Security Class Initialized
DEBUG - 2018-01-18 11:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:26:59 --> Input Class Initialized
INFO - 2018-01-18 11:26:59 --> Language Class Initialized
ERROR - 2018-01-18 11:26:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:27:00 --> Config Class Initialized
INFO - 2018-01-18 11:27:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:00 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:00 --> URI Class Initialized
INFO - 2018-01-18 11:27:00 --> Router Class Initialized
INFO - 2018-01-18 11:27:00 --> Output Class Initialized
INFO - 2018-01-18 11:27:00 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:00 --> Input Class Initialized
INFO - 2018-01-18 11:27:00 --> Language Class Initialized
INFO - 2018-01-18 11:27:00 --> Loader Class Initialized
INFO - 2018-01-18 11:27:00 --> Helper loaded: url_helper
INFO - 2018-01-18 11:27:00 --> Helper loaded: form_helper
INFO - 2018-01-18 11:27:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:27:00 --> Form Validation Class Initialized
INFO - 2018-01-18 11:27:00 --> Model Class Initialized
INFO - 2018-01-18 11:27:00 --> Controller Class Initialized
INFO - 2018-01-18 11:27:00 --> Model Class Initialized
INFO - 2018-01-18 11:27:00 --> Model Class Initialized
INFO - 2018-01-18 11:27:00 --> Model Class Initialized
INFO - 2018-01-18 11:27:00 --> Model Class Initialized
DEBUG - 2018-01-18 11:27:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 11:27:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:27:00 --> Final output sent to browser
DEBUG - 2018-01-18 11:27:00 --> Total execution time: 0.0528
INFO - 2018-01-18 11:27:01 --> Config Class Initialized
INFO - 2018-01-18 11:27:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:01 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:01 --> URI Class Initialized
INFO - 2018-01-18 11:27:01 --> Router Class Initialized
INFO - 2018-01-18 11:27:01 --> Output Class Initialized
INFO - 2018-01-18 11:27:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:01 --> Input Class Initialized
INFO - 2018-01-18 11:27:01 --> Language Class Initialized
ERROR - 2018-01-18 11:27:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:27:01 --> Config Class Initialized
INFO - 2018-01-18 11:27:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:01 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:01 --> URI Class Initialized
INFO - 2018-01-18 11:27:01 --> Router Class Initialized
INFO - 2018-01-18 11:27:01 --> Config Class Initialized
INFO - 2018-01-18 11:27:01 --> Hooks Class Initialized
INFO - 2018-01-18 11:27:01 --> Output Class Initialized
INFO - 2018-01-18 11:27:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:01 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:01 --> Input Class Initialized
INFO - 2018-01-18 11:27:01 --> Language Class Initialized
INFO - 2018-01-18 11:27:01 --> URI Class Initialized
ERROR - 2018-01-18 11:27:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:27:01 --> Router Class Initialized
INFO - 2018-01-18 11:27:01 --> Output Class Initialized
INFO - 2018-01-18 11:27:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:01 --> Input Class Initialized
INFO - 2018-01-18 11:27:01 --> Language Class Initialized
ERROR - 2018-01-18 11:27:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:27:05 --> Config Class Initialized
INFO - 2018-01-18 11:27:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:05 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:05 --> URI Class Initialized
INFO - 2018-01-18 11:27:05 --> Router Class Initialized
INFO - 2018-01-18 11:27:05 --> Output Class Initialized
INFO - 2018-01-18 11:27:05 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:05 --> Input Class Initialized
INFO - 2018-01-18 11:27:05 --> Language Class Initialized
INFO - 2018-01-18 11:27:05 --> Loader Class Initialized
INFO - 2018-01-18 11:27:05 --> Helper loaded: url_helper
INFO - 2018-01-18 11:27:05 --> Helper loaded: form_helper
INFO - 2018-01-18 11:27:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:27:05 --> Form Validation Class Initialized
INFO - 2018-01-18 11:27:05 --> Model Class Initialized
INFO - 2018-01-18 11:27:05 --> Controller Class Initialized
INFO - 2018-01-18 11:27:05 --> Model Class Initialized
INFO - 2018-01-18 11:27:05 --> Model Class Initialized
INFO - 2018-01-18 11:27:05 --> Model Class Initialized
INFO - 2018-01-18 11:27:05 --> Model Class Initialized
DEBUG - 2018-01-18 11:27:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 11:27:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:27:05 --> Final output sent to browser
DEBUG - 2018-01-18 11:27:05 --> Total execution time: 0.0485
INFO - 2018-01-18 11:27:07 --> Config Class Initialized
INFO - 2018-01-18 11:27:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:07 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:07 --> URI Class Initialized
INFO - 2018-01-18 11:27:07 --> Router Class Initialized
INFO - 2018-01-18 11:27:07 --> Output Class Initialized
INFO - 2018-01-18 11:27:07 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:07 --> Input Class Initialized
INFO - 2018-01-18 11:27:07 --> Language Class Initialized
ERROR - 2018-01-18 11:27:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:27:07 --> Config Class Initialized
INFO - 2018-01-18 11:27:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:07 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:07 --> URI Class Initialized
INFO - 2018-01-18 11:27:07 --> Router Class Initialized
INFO - 2018-01-18 11:27:07 --> Config Class Initialized
INFO - 2018-01-18 11:27:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:07 --> Output Class Initialized
INFO - 2018-01-18 11:27:07 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:07 --> Security Class Initialized
INFO - 2018-01-18 11:27:07 --> URI Class Initialized
DEBUG - 2018-01-18 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:07 --> Input Class Initialized
INFO - 2018-01-18 11:27:07 --> Language Class Initialized
INFO - 2018-01-18 11:27:07 --> Router Class Initialized
ERROR - 2018-01-18 11:27:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:27:07 --> Output Class Initialized
INFO - 2018-01-18 11:27:07 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:07 --> Input Class Initialized
INFO - 2018-01-18 11:27:07 --> Language Class Initialized
ERROR - 2018-01-18 11:27:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:27:09 --> Config Class Initialized
INFO - 2018-01-18 11:27:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:09 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:09 --> URI Class Initialized
INFO - 2018-01-18 11:27:09 --> Router Class Initialized
INFO - 2018-01-18 11:27:09 --> Output Class Initialized
INFO - 2018-01-18 11:27:09 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:09 --> Input Class Initialized
INFO - 2018-01-18 11:27:09 --> Language Class Initialized
ERROR - 2018-01-18 11:27:09 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 11:27:11 --> Config Class Initialized
INFO - 2018-01-18 11:27:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:11 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:11 --> URI Class Initialized
INFO - 2018-01-18 11:27:11 --> Router Class Initialized
INFO - 2018-01-18 11:27:11 --> Output Class Initialized
INFO - 2018-01-18 11:27:11 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:11 --> Input Class Initialized
INFO - 2018-01-18 11:27:11 --> Language Class Initialized
ERROR - 2018-01-18 11:27:11 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 11:27:12 --> Config Class Initialized
INFO - 2018-01-18 11:27:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:27:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:27:12 --> Utf8 Class Initialized
INFO - 2018-01-18 11:27:12 --> URI Class Initialized
INFO - 2018-01-18 11:27:12 --> Router Class Initialized
INFO - 2018-01-18 11:27:12 --> Output Class Initialized
INFO - 2018-01-18 11:27:12 --> Security Class Initialized
DEBUG - 2018-01-18 11:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:27:12 --> Input Class Initialized
INFO - 2018-01-18 11:27:12 --> Language Class Initialized
ERROR - 2018-01-18 11:27:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 11:29:25 --> Config Class Initialized
INFO - 2018-01-18 11:29:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:25 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:25 --> URI Class Initialized
INFO - 2018-01-18 11:29:25 --> Router Class Initialized
INFO - 2018-01-18 11:29:25 --> Output Class Initialized
INFO - 2018-01-18 11:29:25 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:25 --> Input Class Initialized
INFO - 2018-01-18 11:29:25 --> Language Class Initialized
INFO - 2018-01-18 11:29:25 --> Loader Class Initialized
INFO - 2018-01-18 11:29:25 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:25 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:25 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:25 --> Model Class Initialized
INFO - 2018-01-18 11:29:25 --> Controller Class Initialized
INFO - 2018-01-18 11:29:25 --> Model Class Initialized
INFO - 2018-01-18 11:29:25 --> Model Class Initialized
INFO - 2018-01-18 11:29:25 --> Model Class Initialized
INFO - 2018-01-18 11:29:25 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/agregarProyecto.php 84
INFO - 2018-01-18 11:29:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:29:25 --> Final output sent to browser
DEBUG - 2018-01-18 11:29:25 --> Total execution time: 0.0498
INFO - 2018-01-18 11:29:27 --> Config Class Initialized
INFO - 2018-01-18 11:29:27 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:27 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:27 --> URI Class Initialized
INFO - 2018-01-18 11:29:27 --> Router Class Initialized
INFO - 2018-01-18 11:29:27 --> Output Class Initialized
INFO - 2018-01-18 11:29:27 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:27 --> Input Class Initialized
INFO - 2018-01-18 11:29:27 --> Language Class Initialized
ERROR - 2018-01-18 11:29:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:29:27 --> Config Class Initialized
INFO - 2018-01-18 11:29:27 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:27 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:27 --> URI Class Initialized
INFO - 2018-01-18 11:29:27 --> Config Class Initialized
INFO - 2018-01-18 11:29:27 --> Hooks Class Initialized
INFO - 2018-01-18 11:29:27 --> Router Class Initialized
INFO - 2018-01-18 11:29:27 --> Output Class Initialized
DEBUG - 2018-01-18 11:29:27 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:27 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:27 --> Security Class Initialized
INFO - 2018-01-18 11:29:27 --> URI Class Initialized
DEBUG - 2018-01-18 11:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:27 --> Input Class Initialized
INFO - 2018-01-18 11:29:27 --> Router Class Initialized
INFO - 2018-01-18 11:29:27 --> Language Class Initialized
ERROR - 2018-01-18 11:29:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:29:27 --> Output Class Initialized
INFO - 2018-01-18 11:29:27 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:27 --> Input Class Initialized
INFO - 2018-01-18 11:29:27 --> Language Class Initialized
ERROR - 2018-01-18 11:29:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:29:28 --> Config Class Initialized
INFO - 2018-01-18 11:29:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:28 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:28 --> URI Class Initialized
INFO - 2018-01-18 11:29:28 --> Router Class Initialized
INFO - 2018-01-18 11:29:28 --> Output Class Initialized
INFO - 2018-01-18 11:29:28 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:28 --> Input Class Initialized
INFO - 2018-01-18 11:29:28 --> Language Class Initialized
INFO - 2018-01-18 11:29:28 --> Loader Class Initialized
INFO - 2018-01-18 11:29:28 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:28 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:28 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:28 --> Model Class Initialized
INFO - 2018-01-18 11:29:28 --> Controller Class Initialized
INFO - 2018-01-18 11:29:28 --> Model Class Initialized
INFO - 2018-01-18 11:29:28 --> Model Class Initialized
INFO - 2018-01-18 11:29:28 --> Model Class Initialized
INFO - 2018-01-18 11:29:28 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:28 --> Final output sent to browser
DEBUG - 2018-01-18 11:29:28 --> Total execution time: 0.0475
INFO - 2018-01-18 11:29:29 --> Config Class Initialized
INFO - 2018-01-18 11:29:29 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:29 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:29 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:29 --> URI Class Initialized
INFO - 2018-01-18 11:29:29 --> Router Class Initialized
INFO - 2018-01-18 11:29:29 --> Output Class Initialized
INFO - 2018-01-18 11:29:29 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:29 --> Input Class Initialized
INFO - 2018-01-18 11:29:29 --> Language Class Initialized
INFO - 2018-01-18 11:29:29 --> Loader Class Initialized
INFO - 2018-01-18 11:29:29 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:29 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:29 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:29 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:29 --> Model Class Initialized
INFO - 2018-01-18 11:29:29 --> Controller Class Initialized
INFO - 2018-01-18 11:29:29 --> Model Class Initialized
INFO - 2018-01-18 11:29:29 --> Model Class Initialized
INFO - 2018-01-18 11:29:29 --> Model Class Initialized
INFO - 2018-01-18 11:29:29 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:30 --> Config Class Initialized
INFO - 2018-01-18 11:29:30 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:30 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:30 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:30 --> URI Class Initialized
INFO - 2018-01-18 11:29:30 --> Router Class Initialized
INFO - 2018-01-18 11:29:30 --> Output Class Initialized
INFO - 2018-01-18 11:29:30 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:30 --> Input Class Initialized
INFO - 2018-01-18 11:29:30 --> Language Class Initialized
INFO - 2018-01-18 11:29:30 --> Loader Class Initialized
INFO - 2018-01-18 11:29:30 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:30 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:30 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:30 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:30 --> Model Class Initialized
INFO - 2018-01-18 11:29:30 --> Controller Class Initialized
INFO - 2018-01-18 11:29:30 --> Model Class Initialized
INFO - 2018-01-18 11:29:30 --> Model Class Initialized
INFO - 2018-01-18 11:29:30 --> Model Class Initialized
INFO - 2018-01-18 11:29:30 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:31 --> Config Class Initialized
INFO - 2018-01-18 11:29:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:31 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:31 --> URI Class Initialized
INFO - 2018-01-18 11:29:31 --> Router Class Initialized
INFO - 2018-01-18 11:29:31 --> Output Class Initialized
INFO - 2018-01-18 11:29:31 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:31 --> Input Class Initialized
INFO - 2018-01-18 11:29:31 --> Language Class Initialized
INFO - 2018-01-18 11:29:31 --> Loader Class Initialized
INFO - 2018-01-18 11:29:31 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:31 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:31 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:31 --> Model Class Initialized
INFO - 2018-01-18 11:29:31 --> Controller Class Initialized
INFO - 2018-01-18 11:29:31 --> Model Class Initialized
INFO - 2018-01-18 11:29:31 --> Model Class Initialized
INFO - 2018-01-18 11:29:31 --> Model Class Initialized
INFO - 2018-01-18 11:29:31 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:35 --> Config Class Initialized
INFO - 2018-01-18 11:29:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:35 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:35 --> URI Class Initialized
INFO - 2018-01-18 11:29:35 --> Router Class Initialized
INFO - 2018-01-18 11:29:35 --> Output Class Initialized
INFO - 2018-01-18 11:29:35 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:35 --> Input Class Initialized
INFO - 2018-01-18 11:29:35 --> Language Class Initialized
INFO - 2018-01-18 11:29:35 --> Loader Class Initialized
INFO - 2018-01-18 11:29:35 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:35 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:35 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:35 --> Model Class Initialized
INFO - 2018-01-18 11:29:35 --> Controller Class Initialized
INFO - 2018-01-18 11:29:35 --> Model Class Initialized
INFO - 2018-01-18 11:29:35 --> Model Class Initialized
INFO - 2018-01-18 11:29:35 --> Model Class Initialized
INFO - 2018-01-18 11:29:35 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 11:29:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:29:35 --> Final output sent to browser
DEBUG - 2018-01-18 11:29:35 --> Total execution time: 0.0455
INFO - 2018-01-18 11:29:36 --> Config Class Initialized
INFO - 2018-01-18 11:29:36 --> Hooks Class Initialized
INFO - 2018-01-18 11:29:36 --> Config Class Initialized
INFO - 2018-01-18 11:29:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:36 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:36 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:36 --> URI Class Initialized
INFO - 2018-01-18 11:29:36 --> URI Class Initialized
INFO - 2018-01-18 11:29:36 --> Router Class Initialized
INFO - 2018-01-18 11:29:36 --> Router Class Initialized
INFO - 2018-01-18 11:29:36 --> Output Class Initialized
INFO - 2018-01-18 11:29:36 --> Output Class Initialized
INFO - 2018-01-18 11:29:36 --> Security Class Initialized
INFO - 2018-01-18 11:29:36 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:36 --> Input Class Initialized
INFO - 2018-01-18 11:29:36 --> Language Class Initialized
DEBUG - 2018-01-18 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:36 --> Input Class Initialized
ERROR - 2018-01-18 11:29:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:29:36 --> Language Class Initialized
ERROR - 2018-01-18 11:29:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:29:36 --> Config Class Initialized
INFO - 2018-01-18 11:29:36 --> Config Class Initialized
INFO - 2018-01-18 11:29:36 --> Hooks Class Initialized
INFO - 2018-01-18 11:29:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:36 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:36 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:36 --> URI Class Initialized
INFO - 2018-01-18 11:29:36 --> URI Class Initialized
INFO - 2018-01-18 11:29:36 --> Router Class Initialized
INFO - 2018-01-18 11:29:36 --> Router Class Initialized
INFO - 2018-01-18 11:29:36 --> Output Class Initialized
INFO - 2018-01-18 11:29:36 --> Output Class Initialized
INFO - 2018-01-18 11:29:36 --> Security Class Initialized
INFO - 2018-01-18 11:29:36 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-01-18 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:36 --> Input Class Initialized
INFO - 2018-01-18 11:29:36 --> Input Class Initialized
INFO - 2018-01-18 11:29:36 --> Language Class Initialized
INFO - 2018-01-18 11:29:36 --> Language Class Initialized
ERROR - 2018-01-18 11:29:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:29:36 --> Loader Class Initialized
INFO - 2018-01-18 11:29:36 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:36 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:36 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:36 --> Model Class Initialized
INFO - 2018-01-18 11:29:36 --> Controller Class Initialized
INFO - 2018-01-18 11:29:36 --> Model Class Initialized
INFO - 2018-01-18 11:29:36 --> Model Class Initialized
INFO - 2018-01-18 11:29:36 --> Model Class Initialized
INFO - 2018-01-18 11:29:36 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:41 --> Config Class Initialized
INFO - 2018-01-18 11:29:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:41 --> URI Class Initialized
INFO - 2018-01-18 11:29:41 --> Router Class Initialized
INFO - 2018-01-18 11:29:41 --> Output Class Initialized
INFO - 2018-01-18 11:29:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:41 --> Input Class Initialized
INFO - 2018-01-18 11:29:41 --> Language Class Initialized
INFO - 2018-01-18 11:29:41 --> Loader Class Initialized
INFO - 2018-01-18 11:29:41 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:41 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:41 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:41 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:41 --> Model Class Initialized
INFO - 2018-01-18 11:29:41 --> Controller Class Initialized
INFO - 2018-01-18 11:29:41 --> Model Class Initialized
INFO - 2018-01-18 11:29:41 --> Model Class Initialized
INFO - 2018-01-18 11:29:41 --> Model Class Initialized
INFO - 2018-01-18 11:29:41 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:41 --> Final output sent to browser
DEBUG - 2018-01-18 11:29:41 --> Total execution time: 0.0422
INFO - 2018-01-18 11:29:42 --> Config Class Initialized
INFO - 2018-01-18 11:29:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:42 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:42 --> URI Class Initialized
INFO - 2018-01-18 11:29:42 --> Router Class Initialized
INFO - 2018-01-18 11:29:42 --> Output Class Initialized
INFO - 2018-01-18 11:29:42 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:42 --> Input Class Initialized
INFO - 2018-01-18 11:29:42 --> Language Class Initialized
INFO - 2018-01-18 11:29:42 --> Loader Class Initialized
INFO - 2018-01-18 11:29:42 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:42 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:42 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:42 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:42 --> Model Class Initialized
INFO - 2018-01-18 11:29:42 --> Controller Class Initialized
INFO - 2018-01-18 11:29:42 --> Model Class Initialized
INFO - 2018-01-18 11:29:42 --> Model Class Initialized
INFO - 2018-01-18 11:29:42 --> Model Class Initialized
INFO - 2018-01-18 11:29:42 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:43 --> Config Class Initialized
INFO - 2018-01-18 11:29:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:43 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:43 --> URI Class Initialized
INFO - 2018-01-18 11:29:43 --> Router Class Initialized
INFO - 2018-01-18 11:29:43 --> Output Class Initialized
INFO - 2018-01-18 11:29:43 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:43 --> Input Class Initialized
INFO - 2018-01-18 11:29:43 --> Language Class Initialized
INFO - 2018-01-18 11:29:43 --> Loader Class Initialized
INFO - 2018-01-18 11:29:43 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:43 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:43 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:43 --> Model Class Initialized
INFO - 2018-01-18 11:29:43 --> Controller Class Initialized
INFO - 2018-01-18 11:29:43 --> Model Class Initialized
INFO - 2018-01-18 11:29:43 --> Model Class Initialized
INFO - 2018-01-18 11:29:43 --> Model Class Initialized
INFO - 2018-01-18 11:29:43 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:44 --> Config Class Initialized
INFO - 2018-01-18 11:29:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:44 --> URI Class Initialized
INFO - 2018-01-18 11:29:44 --> Router Class Initialized
INFO - 2018-01-18 11:29:44 --> Output Class Initialized
INFO - 2018-01-18 11:29:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:44 --> Input Class Initialized
INFO - 2018-01-18 11:29:44 --> Language Class Initialized
INFO - 2018-01-18 11:29:44 --> Loader Class Initialized
INFO - 2018-01-18 11:29:44 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:44 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:44 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Controller Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:44 --> Config Class Initialized
INFO - 2018-01-18 11:29:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:44 --> URI Class Initialized
INFO - 2018-01-18 11:29:44 --> Router Class Initialized
INFO - 2018-01-18 11:29:44 --> Output Class Initialized
INFO - 2018-01-18 11:29:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:44 --> Input Class Initialized
INFO - 2018-01-18 11:29:44 --> Language Class Initialized
INFO - 2018-01-18 11:29:44 --> Loader Class Initialized
INFO - 2018-01-18 11:29:44 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:44 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:44 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Controller Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
INFO - 2018-01-18 11:29:44 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:45 --> Config Class Initialized
INFO - 2018-01-18 11:29:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:45 --> URI Class Initialized
INFO - 2018-01-18 11:29:45 --> Router Class Initialized
INFO - 2018-01-18 11:29:45 --> Output Class Initialized
INFO - 2018-01-18 11:29:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:45 --> Input Class Initialized
INFO - 2018-01-18 11:29:45 --> Language Class Initialized
INFO - 2018-01-18 11:29:45 --> Loader Class Initialized
INFO - 2018-01-18 11:29:45 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:45 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:45 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Controller Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:29:45 --> Config Class Initialized
INFO - 2018-01-18 11:29:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:29:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:29:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:29:45 --> URI Class Initialized
INFO - 2018-01-18 11:29:45 --> Router Class Initialized
INFO - 2018-01-18 11:29:45 --> Output Class Initialized
INFO - 2018-01-18 11:29:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:29:45 --> Input Class Initialized
INFO - 2018-01-18 11:29:45 --> Language Class Initialized
INFO - 2018-01-18 11:29:45 --> Loader Class Initialized
INFO - 2018-01-18 11:29:45 --> Helper loaded: url_helper
INFO - 2018-01-18 11:29:45 --> Helper loaded: form_helper
INFO - 2018-01-18 11:29:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:29:45 --> Form Validation Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Controller Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:45 --> Model Class Initialized
INFO - 2018-01-18 11:29:46 --> Model Class Initialized
INFO - 2018-01-18 11:29:46 --> Model Class Initialized
DEBUG - 2018-01-18 11:29:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:21 --> Config Class Initialized
INFO - 2018-01-18 11:30:21 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:21 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:21 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:21 --> URI Class Initialized
INFO - 2018-01-18 11:30:21 --> Router Class Initialized
INFO - 2018-01-18 11:30:21 --> Output Class Initialized
INFO - 2018-01-18 11:30:21 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:21 --> Input Class Initialized
INFO - 2018-01-18 11:30:21 --> Language Class Initialized
INFO - 2018-01-18 11:30:21 --> Loader Class Initialized
INFO - 2018-01-18 11:30:21 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:21 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:21 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:21 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:21 --> Model Class Initialized
INFO - 2018-01-18 11:30:21 --> Controller Class Initialized
INFO - 2018-01-18 11:30:21 --> Model Class Initialized
INFO - 2018-01-18 11:30:21 --> Model Class Initialized
INFO - 2018-01-18 11:30:21 --> Model Class Initialized
INFO - 2018-01-18 11:30:21 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:40 --> Config Class Initialized
INFO - 2018-01-18 11:30:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:40 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:40 --> URI Class Initialized
INFO - 2018-01-18 11:30:40 --> Router Class Initialized
INFO - 2018-01-18 11:30:40 --> Output Class Initialized
INFO - 2018-01-18 11:30:40 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:40 --> Input Class Initialized
INFO - 2018-01-18 11:30:40 --> Language Class Initialized
INFO - 2018-01-18 11:30:40 --> Loader Class Initialized
INFO - 2018-01-18 11:30:40 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:40 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:40 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:40 --> Model Class Initialized
INFO - 2018-01-18 11:30:40 --> Controller Class Initialized
INFO - 2018-01-18 11:30:40 --> Model Class Initialized
INFO - 2018-01-18 11:30:40 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:40 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:40 --> Total execution time: 0.0383
INFO - 2018-01-18 11:30:41 --> Config Class Initialized
INFO - 2018-01-18 11:30:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:41 --> Config Class Initialized
INFO - 2018-01-18 11:30:41 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:41 --> URI Class Initialized
INFO - 2018-01-18 11:30:41 --> Router Class Initialized
DEBUG - 2018-01-18 11:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:41 --> URI Class Initialized
INFO - 2018-01-18 11:30:41 --> Output Class Initialized
INFO - 2018-01-18 11:30:41 --> Router Class Initialized
INFO - 2018-01-18 11:30:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:41 --> Input Class Initialized
INFO - 2018-01-18 11:30:41 --> Output Class Initialized
INFO - 2018-01-18 11:30:41 --> Language Class Initialized
INFO - 2018-01-18 11:30:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:41 --> Input Class Initialized
INFO - 2018-01-18 11:30:41 --> Loader Class Initialized
INFO - 2018-01-18 11:30:41 --> Language Class Initialized
ERROR - 2018-01-18 11:30:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:41 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:41 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:41 --> Database Driver Class Initialized
INFO - 2018-01-18 11:30:41 --> Config Class Initialized
INFO - 2018-01-18 11:30:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-18 11:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:41 --> Config Class Initialized
INFO - 2018-01-18 11:30:41 --> URI Class Initialized
INFO - 2018-01-18 11:30:41 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:41 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:41 --> Model Class Initialized
INFO - 2018-01-18 11:30:41 --> Controller Class Initialized
INFO - 2018-01-18 11:30:41 --> Router Class Initialized
INFO - 2018-01-18 11:30:41 --> Model Class Initialized
INFO - 2018-01-18 11:30:41 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-18 11:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:41 --> URI Class Initialized
INFO - 2018-01-18 11:30:41 --> Output Class Initialized
INFO - 2018-01-18 11:30:41 --> Router Class Initialized
INFO - 2018-01-18 11:30:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:41 --> Input Class Initialized
INFO - 2018-01-18 11:30:41 --> Language Class Initialized
INFO - 2018-01-18 11:30:41 --> Output Class Initialized
ERROR - 2018-01-18 11:30:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:41 --> Input Class Initialized
INFO - 2018-01-18 11:30:41 --> Language Class Initialized
ERROR - 2018-01-18 11:30:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:43 --> Config Class Initialized
INFO - 2018-01-18 11:30:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:43 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:43 --> URI Class Initialized
INFO - 2018-01-18 11:30:43 --> Router Class Initialized
INFO - 2018-01-18 11:30:43 --> Output Class Initialized
INFO - 2018-01-18 11:30:43 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:43 --> Input Class Initialized
INFO - 2018-01-18 11:30:43 --> Language Class Initialized
INFO - 2018-01-18 11:30:43 --> Loader Class Initialized
INFO - 2018-01-18 11:30:43 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:43 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:43 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:43 --> Model Class Initialized
INFO - 2018-01-18 11:30:43 --> Controller Class Initialized
INFO - 2018-01-18 11:30:43 --> Model Class Initialized
INFO - 2018-01-18 11:30:43 --> Model Class Initialized
INFO - 2018-01-18 11:30:43 --> Model Class Initialized
INFO - 2018-01-18 11:30:43 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:30:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 11:30:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:43 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:43 --> Total execution time: 0.0459
INFO - 2018-01-18 11:30:44 --> Config Class Initialized
INFO - 2018-01-18 11:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:44 --> URI Class Initialized
INFO - 2018-01-18 11:30:44 --> Router Class Initialized
INFO - 2018-01-18 11:30:44 --> Output Class Initialized
INFO - 2018-01-18 11:30:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:44 --> Input Class Initialized
INFO - 2018-01-18 11:30:44 --> Language Class Initialized
ERROR - 2018-01-18 11:30:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:44 --> Config Class Initialized
INFO - 2018-01-18 11:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:44 --> URI Class Initialized
INFO - 2018-01-18 11:30:44 --> Router Class Initialized
INFO - 2018-01-18 11:30:44 --> Output Class Initialized
INFO - 2018-01-18 11:30:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:44 --> Input Class Initialized
INFO - 2018-01-18 11:30:44 --> Language Class Initialized
INFO - 2018-01-18 11:30:44 --> Loader Class Initialized
INFO - 2018-01-18 11:30:44 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:44 --> Config Class Initialized
INFO - 2018-01-18 11:30:44 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:44 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:44 --> Config Class Initialized
INFO - 2018-01-18 11:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:44 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:44 --> URI Class Initialized
INFO - 2018-01-18 11:30:44 --> Router Class Initialized
INFO - 2018-01-18 11:30:44 --> URI Class Initialized
INFO - 2018-01-18 11:30:44 --> Output Class Initialized
INFO - 2018-01-18 11:30:44 --> Router Class Initialized
INFO - 2018-01-18 11:30:44 --> Security Class Initialized
INFO - 2018-01-18 11:30:44 --> Database Driver Class Initialized
INFO - 2018-01-18 11:30:44 --> Output Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:44 --> Input Class Initialized
INFO - 2018-01-18 11:30:44 --> Language Class Initialized
ERROR - 2018-01-18 11:30:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-18 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:44 --> Input Class Initialized
INFO - 2018-01-18 11:30:44 --> Language Class Initialized
ERROR - 2018-01-18 11:30:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:44 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Controller Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:44 --> Config Class Initialized
INFO - 2018-01-18 11:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:44 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:44 --> URI Class Initialized
INFO - 2018-01-18 11:30:44 --> Router Class Initialized
INFO - 2018-01-18 11:30:44 --> Output Class Initialized
INFO - 2018-01-18 11:30:44 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:44 --> Input Class Initialized
INFO - 2018-01-18 11:30:44 --> Language Class Initialized
INFO - 2018-01-18 11:30:44 --> Loader Class Initialized
INFO - 2018-01-18 11:30:44 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:44 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:44 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Controller Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
INFO - 2018-01-18 11:30:44 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:44 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:44 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:44 --> Total execution time: 0.0410
INFO - 2018-01-18 11:30:45 --> Config Class Initialized
INFO - 2018-01-18 11:30:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:45 --> URI Class Initialized
INFO - 2018-01-18 11:30:45 --> Router Class Initialized
INFO - 2018-01-18 11:30:45 --> Output Class Initialized
INFO - 2018-01-18 11:30:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:45 --> Input Class Initialized
INFO - 2018-01-18 11:30:45 --> Language Class Initialized
ERROR - 2018-01-18 11:30:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:45 --> Config Class Initialized
INFO - 2018-01-18 11:30:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:45 --> URI Class Initialized
INFO - 2018-01-18 11:30:45 --> Router Class Initialized
INFO - 2018-01-18 11:30:45 --> Output Class Initialized
INFO - 2018-01-18 11:30:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:45 --> Input Class Initialized
INFO - 2018-01-18 11:30:45 --> Language Class Initialized
INFO - 2018-01-18 11:30:45 --> Loader Class Initialized
INFO - 2018-01-18 11:30:45 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:45 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:45 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:45 --> Model Class Initialized
INFO - 2018-01-18 11:30:45 --> Controller Class Initialized
INFO - 2018-01-18 11:30:45 --> Model Class Initialized
INFO - 2018-01-18 11:30:45 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:45 --> Config Class Initialized
INFO - 2018-01-18 11:30:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:45 --> URI Class Initialized
INFO - 2018-01-18 11:30:45 --> Router Class Initialized
INFO - 2018-01-18 11:30:45 --> Output Class Initialized
INFO - 2018-01-18 11:30:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:45 --> Input Class Initialized
INFO - 2018-01-18 11:30:45 --> Language Class Initialized
ERROR - 2018-01-18 11:30:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:45 --> Config Class Initialized
INFO - 2018-01-18 11:30:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:45 --> URI Class Initialized
INFO - 2018-01-18 11:30:45 --> Router Class Initialized
INFO - 2018-01-18 11:30:45 --> Output Class Initialized
INFO - 2018-01-18 11:30:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:45 --> Input Class Initialized
INFO - 2018-01-18 11:30:45 --> Language Class Initialized
ERROR - 2018-01-18 11:30:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:47 --> Config Class Initialized
INFO - 2018-01-18 11:30:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:47 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:47 --> URI Class Initialized
INFO - 2018-01-18 11:30:47 --> Router Class Initialized
INFO - 2018-01-18 11:30:47 --> Output Class Initialized
INFO - 2018-01-18 11:30:47 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:47 --> Input Class Initialized
INFO - 2018-01-18 11:30:47 --> Language Class Initialized
INFO - 2018-01-18 11:30:47 --> Loader Class Initialized
INFO - 2018-01-18 11:30:47 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:47 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:47 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:47 --> Model Class Initialized
INFO - 2018-01-18 11:30:47 --> Controller Class Initialized
INFO - 2018-01-18 11:30:47 --> Model Class Initialized
INFO - 2018-01-18 11:30:47 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:47 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:47 --> Total execution time: 0.0397
INFO - 2018-01-18 11:30:47 --> Config Class Initialized
INFO - 2018-01-18 11:30:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:47 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:47 --> URI Class Initialized
INFO - 2018-01-18 11:30:47 --> Router Class Initialized
INFO - 2018-01-18 11:30:47 --> Output Class Initialized
INFO - 2018-01-18 11:30:47 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:47 --> Input Class Initialized
INFO - 2018-01-18 11:30:47 --> Language Class Initialized
ERROR - 2018-01-18 11:30:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:47 --> Config Class Initialized
INFO - 2018-01-18 11:30:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:47 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:47 --> Config Class Initialized
INFO - 2018-01-18 11:30:47 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:47 --> URI Class Initialized
DEBUG - 2018-01-18 11:30:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:47 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:47 --> Router Class Initialized
INFO - 2018-01-18 11:30:47 --> URI Class Initialized
INFO - 2018-01-18 11:30:47 --> Output Class Initialized
INFO - 2018-01-18 11:30:47 --> Router Class Initialized
INFO - 2018-01-18 11:30:47 --> Security Class Initialized
INFO - 2018-01-18 11:30:47 --> Output Class Initialized
DEBUG - 2018-01-18 11:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:47 --> Input Class Initialized
INFO - 2018-01-18 11:30:47 --> Language Class Initialized
INFO - 2018-01-18 11:30:47 --> Security Class Initialized
ERROR - 2018-01-18 11:30:47 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-01-18 11:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:47 --> Input Class Initialized
INFO - 2018-01-18 11:30:47 --> Language Class Initialized
ERROR - 2018-01-18 11:30:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:49 --> Config Class Initialized
INFO - 2018-01-18 11:30:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:49 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:49 --> URI Class Initialized
INFO - 2018-01-18 11:30:49 --> Router Class Initialized
INFO - 2018-01-18 11:30:49 --> Output Class Initialized
INFO - 2018-01-18 11:30:49 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:49 --> Input Class Initialized
INFO - 2018-01-18 11:30:49 --> Language Class Initialized
INFO - 2018-01-18 11:30:49 --> Loader Class Initialized
INFO - 2018-01-18 11:30:49 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:49 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:49 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
INFO - 2018-01-18 11:30:49 --> Controller Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:49 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:49 --> Total execution time: 0.0391
INFO - 2018-01-18 11:30:49 --> Config Class Initialized
INFO - 2018-01-18 11:30:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:49 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:49 --> URI Class Initialized
INFO - 2018-01-18 11:30:49 --> Router Class Initialized
INFO - 2018-01-18 11:30:49 --> Output Class Initialized
INFO - 2018-01-18 11:30:49 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:49 --> Input Class Initialized
INFO - 2018-01-18 11:30:49 --> Language Class Initialized
ERROR - 2018-01-18 11:30:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:49 --> Config Class Initialized
INFO - 2018-01-18 11:30:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:49 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:49 --> URI Class Initialized
INFO - 2018-01-18 11:30:49 --> Router Class Initialized
INFO - 2018-01-18 11:30:49 --> Output Class Initialized
INFO - 2018-01-18 11:30:49 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:49 --> Input Class Initialized
INFO - 2018-01-18 11:30:49 --> Language Class Initialized
INFO - 2018-01-18 11:30:49 --> Loader Class Initialized
INFO - 2018-01-18 11:30:49 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:49 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:49 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
INFO - 2018-01-18 11:30:49 --> Controller Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
INFO - 2018-01-18 11:30:49 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:30:49 --> Config Class Initialized
INFO - 2018-01-18 11:30:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:49 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:49 --> Config Class Initialized
INFO - 2018-01-18 11:30:49 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:49 --> URI Class Initialized
DEBUG - 2018-01-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:49 --> Router Class Initialized
INFO - 2018-01-18 11:30:49 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:49 --> URI Class Initialized
INFO - 2018-01-18 11:30:49 --> Output Class Initialized
INFO - 2018-01-18 11:30:49 --> Router Class Initialized
INFO - 2018-01-18 11:30:49 --> Security Class Initialized
INFO - 2018-01-18 11:30:49 --> Output Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:49 --> Input Class Initialized
INFO - 2018-01-18 11:30:49 --> Language Class Initialized
ERROR - 2018-01-18 11:30:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:49 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:49 --> Input Class Initialized
INFO - 2018-01-18 11:30:49 --> Language Class Initialized
ERROR - 2018-01-18 11:30:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:50 --> Config Class Initialized
INFO - 2018-01-18 11:30:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:50 --> URI Class Initialized
INFO - 2018-01-18 11:30:50 --> Router Class Initialized
INFO - 2018-01-18 11:30:50 --> Output Class Initialized
INFO - 2018-01-18 11:30:50 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:50 --> Input Class Initialized
INFO - 2018-01-18 11:30:50 --> Language Class Initialized
INFO - 2018-01-18 11:30:50 --> Loader Class Initialized
INFO - 2018-01-18 11:30:50 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:50 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:50 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Controller Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 11:30:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-18 11:30:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:30:50 --> Final output sent to browser
DEBUG - 2018-01-18 11:30:50 --> Total execution time: 0.0475
INFO - 2018-01-18 11:30:50 --> Config Class Initialized
INFO - 2018-01-18 11:30:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:50 --> URI Class Initialized
INFO - 2018-01-18 11:30:50 --> Router Class Initialized
INFO - 2018-01-18 11:30:50 --> Output Class Initialized
INFO - 2018-01-18 11:30:50 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:50 --> Input Class Initialized
INFO - 2018-01-18 11:30:50 --> Language Class Initialized
ERROR - 2018-01-18 11:30:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:30:50 --> Config Class Initialized
INFO - 2018-01-18 11:30:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:50 --> URI Class Initialized
INFO - 2018-01-18 11:30:50 --> Router Class Initialized
INFO - 2018-01-18 11:30:50 --> Output Class Initialized
INFO - 2018-01-18 11:30:50 --> Security Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:50 --> Input Class Initialized
INFO - 2018-01-18 11:30:50 --> Language Class Initialized
INFO - 2018-01-18 11:30:50 --> Loader Class Initialized
INFO - 2018-01-18 11:30:50 --> Helper loaded: url_helper
INFO - 2018-01-18 11:30:50 --> Helper loaded: form_helper
INFO - 2018-01-18 11:30:50 --> Config Class Initialized
INFO - 2018-01-18 11:30:50 --> Hooks Class Initialized
INFO - 2018-01-18 11:30:50 --> Config Class Initialized
INFO - 2018-01-18 11:30:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:50 --> Database Driver Class Initialized
INFO - 2018-01-18 11:30:50 --> URI Class Initialized
DEBUG - 2018-01-18 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:30:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:30:50 --> URI Class Initialized
INFO - 2018-01-18 11:30:50 --> Router Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:30:50 --> Router Class Initialized
INFO - 2018-01-18 11:30:50 --> Output Class Initialized
INFO - 2018-01-18 11:30:50 --> Form Validation Class Initialized
INFO - 2018-01-18 11:30:50 --> Output Class Initialized
INFO - 2018-01-18 11:30:50 --> Security Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Controller Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:50 --> Security Class Initialized
INFO - 2018-01-18 11:30:50 --> Input Class Initialized
INFO - 2018-01-18 11:30:50 --> Language Class Initialized
ERROR - 2018-01-18 11:30:50 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-01-18 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:30:50 --> Input Class Initialized
INFO - 2018-01-18 11:30:50 --> Language Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
ERROR - 2018-01-18 11:30:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
INFO - 2018-01-18 11:30:50 --> Model Class Initialized
DEBUG - 2018-01-18 11:30:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:40 --> Config Class Initialized
INFO - 2018-01-18 11:31:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:40 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:40 --> URI Class Initialized
INFO - 2018-01-18 11:31:40 --> Router Class Initialized
INFO - 2018-01-18 11:31:40 --> Output Class Initialized
INFO - 2018-01-18 11:31:40 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:40 --> Input Class Initialized
INFO - 2018-01-18 11:31:40 --> Language Class Initialized
INFO - 2018-01-18 11:31:40 --> Loader Class Initialized
INFO - 2018-01-18 11:31:40 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:40 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:40 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:40 --> Model Class Initialized
INFO - 2018-01-18 11:31:40 --> Controller Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:31:41 --> Final output sent to browser
DEBUG - 2018-01-18 11:31:41 --> Total execution time: 0.0464
INFO - 2018-01-18 11:31:41 --> Config Class Initialized
INFO - 2018-01-18 11:31:41 --> Hooks Class Initialized
INFO - 2018-01-18 11:31:41 --> Config Class Initialized
INFO - 2018-01-18 11:31:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:41 --> Utf8 Class Initialized
DEBUG - 2018-01-18 11:31:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:41 --> URI Class Initialized
INFO - 2018-01-18 11:31:41 --> URI Class Initialized
INFO - 2018-01-18 11:31:41 --> Router Class Initialized
INFO - 2018-01-18 11:31:41 --> Router Class Initialized
INFO - 2018-01-18 11:31:41 --> Output Class Initialized
INFO - 2018-01-18 11:31:41 --> Output Class Initialized
INFO - 2018-01-18 11:31:41 --> Security Class Initialized
INFO - 2018-01-18 11:31:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-01-18 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:41 --> Input Class Initialized
INFO - 2018-01-18 11:31:41 --> Input Class Initialized
INFO - 2018-01-18 11:31:41 --> Language Class Initialized
INFO - 2018-01-18 11:31:41 --> Language Class Initialized
ERROR - 2018-01-18 11:31:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-01-18 11:31:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:31:41 --> Config Class Initialized
INFO - 2018-01-18 11:31:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:41 --> URI Class Initialized
INFO - 2018-01-18 11:31:41 --> Router Class Initialized
INFO - 2018-01-18 11:31:41 --> Output Class Initialized
INFO - 2018-01-18 11:31:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:41 --> Input Class Initialized
INFO - 2018-01-18 11:31:41 --> Language Class Initialized
INFO - 2018-01-18 11:31:41 --> Loader Class Initialized
INFO - 2018-01-18 11:31:41 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:41 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:41 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:41 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Controller Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
INFO - 2018-01-18 11:31:41 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:41 --> Config Class Initialized
INFO - 2018-01-18 11:31:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:41 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:41 --> URI Class Initialized
INFO - 2018-01-18 11:31:41 --> Router Class Initialized
INFO - 2018-01-18 11:31:41 --> Output Class Initialized
INFO - 2018-01-18 11:31:41 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:41 --> Input Class Initialized
INFO - 2018-01-18 11:31:41 --> Language Class Initialized
ERROR - 2018-01-18 11:31:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:31:46 --> Config Class Initialized
INFO - 2018-01-18 11:31:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:46 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:46 --> URI Class Initialized
INFO - 2018-01-18 11:31:46 --> Router Class Initialized
INFO - 2018-01-18 11:31:46 --> Output Class Initialized
INFO - 2018-01-18 11:31:46 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:46 --> Input Class Initialized
INFO - 2018-01-18 11:31:46 --> Language Class Initialized
INFO - 2018-01-18 11:31:46 --> Loader Class Initialized
INFO - 2018-01-18 11:31:46 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:46 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:46 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:46 --> Model Class Initialized
INFO - 2018-01-18 11:31:46 --> Controller Class Initialized
INFO - 2018-01-18 11:31:46 --> Model Class Initialized
INFO - 2018-01-18 11:31:46 --> Model Class Initialized
INFO - 2018-01-18 11:31:46 --> Model Class Initialized
INFO - 2018-01-18 11:31:46 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:46 --> Final output sent to browser
DEBUG - 2018-01-18 11:31:46 --> Total execution time: 0.0458
INFO - 2018-01-18 11:31:47 --> Config Class Initialized
INFO - 2018-01-18 11:31:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:47 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:47 --> URI Class Initialized
INFO - 2018-01-18 11:31:47 --> Router Class Initialized
INFO - 2018-01-18 11:31:47 --> Output Class Initialized
INFO - 2018-01-18 11:31:47 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:47 --> Input Class Initialized
INFO - 2018-01-18 11:31:47 --> Language Class Initialized
INFO - 2018-01-18 11:31:47 --> Loader Class Initialized
INFO - 2018-01-18 11:31:47 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:47 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:47 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:47 --> Model Class Initialized
INFO - 2018-01-18 11:31:47 --> Controller Class Initialized
INFO - 2018-01-18 11:31:47 --> Model Class Initialized
INFO - 2018-01-18 11:31:47 --> Model Class Initialized
INFO - 2018-01-18 11:31:47 --> Model Class Initialized
INFO - 2018-01-18 11:31:47 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:48 --> Config Class Initialized
INFO - 2018-01-18 11:31:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:48 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:48 --> URI Class Initialized
INFO - 2018-01-18 11:31:48 --> Router Class Initialized
INFO - 2018-01-18 11:31:48 --> Output Class Initialized
INFO - 2018-01-18 11:31:48 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:48 --> Input Class Initialized
INFO - 2018-01-18 11:31:48 --> Language Class Initialized
INFO - 2018-01-18 11:31:48 --> Loader Class Initialized
INFO - 2018-01-18 11:31:48 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:48 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:48 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:48 --> Model Class Initialized
INFO - 2018-01-18 11:31:48 --> Controller Class Initialized
INFO - 2018-01-18 11:31:48 --> Model Class Initialized
INFO - 2018-01-18 11:31:48 --> Model Class Initialized
INFO - 2018-01-18 11:31:48 --> Model Class Initialized
INFO - 2018-01-18 11:31:48 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:31:48 --> Final output sent to browser
DEBUG - 2018-01-18 11:31:48 --> Total execution time: 0.0470
INFO - 2018-01-18 11:31:48 --> Config Class Initialized
INFO - 2018-01-18 11:31:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:48 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:48 --> Config Class Initialized
INFO - 2018-01-18 11:31:48 --> Hooks Class Initialized
INFO - 2018-01-18 11:31:48 --> URI Class Initialized
INFO - 2018-01-18 11:31:48 --> Router Class Initialized
DEBUG - 2018-01-18 11:31:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:48 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:48 --> Output Class Initialized
INFO - 2018-01-18 11:31:48 --> URI Class Initialized
INFO - 2018-01-18 11:31:48 --> Config Class Initialized
INFO - 2018-01-18 11:31:48 --> Security Class Initialized
INFO - 2018-01-18 11:31:48 --> Hooks Class Initialized
INFO - 2018-01-18 11:31:48 --> Router Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:48 --> Input Class Initialized
INFO - 2018-01-18 11:31:48 --> Language Class Initialized
DEBUG - 2018-01-18 11:31:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:48 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:48 --> Output Class Initialized
ERROR - 2018-01-18 11:31:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:31:48 --> URI Class Initialized
INFO - 2018-01-18 11:31:48 --> Security Class Initialized
INFO - 2018-01-18 11:31:48 --> Router Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:48 --> Input Class Initialized
INFO - 2018-01-18 11:31:48 --> Language Class Initialized
ERROR - 2018-01-18 11:31:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:31:48 --> Output Class Initialized
INFO - 2018-01-18 11:31:48 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:48 --> Input Class Initialized
INFO - 2018-01-18 11:31:48 --> Language Class Initialized
ERROR - 2018-01-18 11:31:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:31:54 --> Config Class Initialized
INFO - 2018-01-18 11:31:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:54 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:54 --> URI Class Initialized
INFO - 2018-01-18 11:31:54 --> Router Class Initialized
INFO - 2018-01-18 11:31:54 --> Output Class Initialized
INFO - 2018-01-18 11:31:54 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:54 --> Input Class Initialized
INFO - 2018-01-18 11:31:54 --> Language Class Initialized
INFO - 2018-01-18 11:31:54 --> Loader Class Initialized
INFO - 2018-01-18 11:31:54 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:54 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:54 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:54 --> Model Class Initialized
INFO - 2018-01-18 11:31:54 --> Controller Class Initialized
INFO - 2018-01-18 11:31:54 --> Model Class Initialized
INFO - 2018-01-18 11:31:54 --> Model Class Initialized
INFO - 2018-01-18 11:31:54 --> Model Class Initialized
INFO - 2018-01-18 11:31:54 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:54 --> Final output sent to browser
DEBUG - 2018-01-18 11:31:54 --> Total execution time: 0.0437
INFO - 2018-01-18 11:31:55 --> Config Class Initialized
INFO - 2018-01-18 11:31:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:55 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:55 --> URI Class Initialized
INFO - 2018-01-18 11:31:55 --> Router Class Initialized
INFO - 2018-01-18 11:31:55 --> Output Class Initialized
INFO - 2018-01-18 11:31:55 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:55 --> Input Class Initialized
INFO - 2018-01-18 11:31:55 --> Language Class Initialized
INFO - 2018-01-18 11:31:55 --> Loader Class Initialized
INFO - 2018-01-18 11:31:55 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:55 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:55 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:55 --> Model Class Initialized
INFO - 2018-01-18 11:31:55 --> Controller Class Initialized
INFO - 2018-01-18 11:31:55 --> Model Class Initialized
INFO - 2018-01-18 11:31:55 --> Model Class Initialized
INFO - 2018-01-18 11:31:55 --> Model Class Initialized
INFO - 2018-01-18 11:31:55 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:56 --> Config Class Initialized
INFO - 2018-01-18 11:31:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:56 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:56 --> URI Class Initialized
INFO - 2018-01-18 11:31:56 --> Router Class Initialized
INFO - 2018-01-18 11:31:56 --> Output Class Initialized
INFO - 2018-01-18 11:31:56 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:56 --> Input Class Initialized
INFO - 2018-01-18 11:31:56 --> Language Class Initialized
INFO - 2018-01-18 11:31:56 --> Loader Class Initialized
INFO - 2018-01-18 11:31:56 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:56 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:56 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:56 --> Model Class Initialized
INFO - 2018-01-18 11:31:56 --> Controller Class Initialized
INFO - 2018-01-18 11:31:56 --> Model Class Initialized
INFO - 2018-01-18 11:31:56 --> Model Class Initialized
INFO - 2018-01-18 11:31:56 --> Model Class Initialized
INFO - 2018-01-18 11:31:56 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:57 --> Config Class Initialized
INFO - 2018-01-18 11:31:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:57 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:57 --> URI Class Initialized
INFO - 2018-01-18 11:31:57 --> Router Class Initialized
INFO - 2018-01-18 11:31:57 --> Output Class Initialized
INFO - 2018-01-18 11:31:57 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:57 --> Input Class Initialized
INFO - 2018-01-18 11:31:57 --> Language Class Initialized
INFO - 2018-01-18 11:31:57 --> Loader Class Initialized
INFO - 2018-01-18 11:31:57 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:57 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:57 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Controller Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:57 --> Final output sent to browser
DEBUG - 2018-01-18 11:31:57 --> Total execution time: 0.0435
INFO - 2018-01-18 11:31:57 --> Config Class Initialized
INFO - 2018-01-18 11:31:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:57 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:57 --> URI Class Initialized
INFO - 2018-01-18 11:31:57 --> Router Class Initialized
INFO - 2018-01-18 11:31:57 --> Output Class Initialized
INFO - 2018-01-18 11:31:57 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:57 --> Input Class Initialized
INFO - 2018-01-18 11:31:57 --> Language Class Initialized
INFO - 2018-01-18 11:31:57 --> Loader Class Initialized
INFO - 2018-01-18 11:31:57 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:57 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:57 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Controller Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:57 --> Config Class Initialized
INFO - 2018-01-18 11:31:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:57 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:57 --> URI Class Initialized
INFO - 2018-01-18 11:31:57 --> Router Class Initialized
INFO - 2018-01-18 11:31:57 --> Output Class Initialized
INFO - 2018-01-18 11:31:57 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:57 --> Input Class Initialized
INFO - 2018-01-18 11:31:57 --> Language Class Initialized
INFO - 2018-01-18 11:31:57 --> Loader Class Initialized
INFO - 2018-01-18 11:31:57 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:57 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:57 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Controller Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
INFO - 2018-01-18 11:31:57 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:31:59 --> Config Class Initialized
INFO - 2018-01-18 11:31:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:31:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:31:59 --> Utf8 Class Initialized
INFO - 2018-01-18 11:31:59 --> URI Class Initialized
INFO - 2018-01-18 11:31:59 --> Router Class Initialized
INFO - 2018-01-18 11:31:59 --> Output Class Initialized
INFO - 2018-01-18 11:31:59 --> Security Class Initialized
DEBUG - 2018-01-18 11:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:31:59 --> Input Class Initialized
INFO - 2018-01-18 11:31:59 --> Language Class Initialized
INFO - 2018-01-18 11:31:59 --> Loader Class Initialized
INFO - 2018-01-18 11:31:59 --> Helper loaded: url_helper
INFO - 2018-01-18 11:31:59 --> Helper loaded: form_helper
INFO - 2018-01-18 11:31:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:31:59 --> Form Validation Class Initialized
INFO - 2018-01-18 11:31:59 --> Model Class Initialized
INFO - 2018-01-18 11:31:59 --> Controller Class Initialized
INFO - 2018-01-18 11:31:59 --> Model Class Initialized
INFO - 2018-01-18 11:31:59 --> Model Class Initialized
INFO - 2018-01-18 11:31:59 --> Model Class Initialized
INFO - 2018-01-18 11:31:59 --> Model Class Initialized
DEBUG - 2018-01-18 11:31:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:00 --> Config Class Initialized
INFO - 2018-01-18 11:32:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:00 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:00 --> URI Class Initialized
INFO - 2018-01-18 11:32:00 --> Router Class Initialized
INFO - 2018-01-18 11:32:00 --> Output Class Initialized
INFO - 2018-01-18 11:32:00 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:00 --> Input Class Initialized
INFO - 2018-01-18 11:32:00 --> Language Class Initialized
INFO - 2018-01-18 11:32:00 --> Loader Class Initialized
INFO - 2018-01-18 11:32:00 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:00 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:00 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:00 --> Model Class Initialized
INFO - 2018-01-18 11:32:00 --> Controller Class Initialized
INFO - 2018-01-18 11:32:00 --> Model Class Initialized
INFO - 2018-01-18 11:32:00 --> Model Class Initialized
INFO - 2018-01-18 11:32:00 --> Model Class Initialized
INFO - 2018-01-18 11:32:00 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:01 --> Config Class Initialized
INFO - 2018-01-18 11:32:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:01 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:01 --> URI Class Initialized
INFO - 2018-01-18 11:32:01 --> Router Class Initialized
INFO - 2018-01-18 11:32:01 --> Output Class Initialized
INFO - 2018-01-18 11:32:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:01 --> Input Class Initialized
INFO - 2018-01-18 11:32:01 --> Language Class Initialized
INFO - 2018-01-18 11:32:01 --> Loader Class Initialized
INFO - 2018-01-18 11:32:01 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:01 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:01 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Controller Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:01 --> Config Class Initialized
INFO - 2018-01-18 11:32:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:01 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:01 --> URI Class Initialized
INFO - 2018-01-18 11:32:01 --> Router Class Initialized
INFO - 2018-01-18 11:32:01 --> Output Class Initialized
INFO - 2018-01-18 11:32:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:01 --> Input Class Initialized
INFO - 2018-01-18 11:32:01 --> Language Class Initialized
INFO - 2018-01-18 11:32:01 --> Loader Class Initialized
INFO - 2018-01-18 11:32:01 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:01 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:01 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Controller Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
INFO - 2018-01-18 11:32:01 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:02 --> Config Class Initialized
INFO - 2018-01-18 11:32:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:02 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:02 --> URI Class Initialized
INFO - 2018-01-18 11:32:02 --> Router Class Initialized
INFO - 2018-01-18 11:32:02 --> Output Class Initialized
INFO - 2018-01-18 11:32:02 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:02 --> Input Class Initialized
INFO - 2018-01-18 11:32:02 --> Language Class Initialized
INFO - 2018-01-18 11:32:02 --> Loader Class Initialized
INFO - 2018-01-18 11:32:02 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:02 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:02 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Controller Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:02 --> Config Class Initialized
INFO - 2018-01-18 11:32:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:02 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:02 --> URI Class Initialized
INFO - 2018-01-18 11:32:02 --> Router Class Initialized
INFO - 2018-01-18 11:32:02 --> Output Class Initialized
INFO - 2018-01-18 11:32:02 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:02 --> Input Class Initialized
INFO - 2018-01-18 11:32:02 --> Language Class Initialized
INFO - 2018-01-18 11:32:02 --> Loader Class Initialized
INFO - 2018-01-18 11:32:02 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:02 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:02 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Controller Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
INFO - 2018-01-18 11:32:02 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:04 --> Config Class Initialized
INFO - 2018-01-18 11:32:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:04 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:04 --> URI Class Initialized
INFO - 2018-01-18 11:32:04 --> Router Class Initialized
INFO - 2018-01-18 11:32:04 --> Output Class Initialized
INFO - 2018-01-18 11:32:04 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:04 --> Input Class Initialized
INFO - 2018-01-18 11:32:04 --> Language Class Initialized
INFO - 2018-01-18 11:32:04 --> Loader Class Initialized
INFO - 2018-01-18 11:32:04 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:04 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:04 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:04 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:04 --> Model Class Initialized
INFO - 2018-01-18 11:32:04 --> Controller Class Initialized
INFO - 2018-01-18 11:32:04 --> Model Class Initialized
INFO - 2018-01-18 11:32:04 --> Model Class Initialized
INFO - 2018-01-18 11:32:04 --> Model Class Initialized
INFO - 2018-01-18 11:32:04 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:05 --> Config Class Initialized
INFO - 2018-01-18 11:32:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:05 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:05 --> URI Class Initialized
INFO - 2018-01-18 11:32:05 --> Router Class Initialized
INFO - 2018-01-18 11:32:05 --> Output Class Initialized
INFO - 2018-01-18 11:32:05 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:05 --> Input Class Initialized
INFO - 2018-01-18 11:32:05 --> Language Class Initialized
INFO - 2018-01-18 11:32:05 --> Loader Class Initialized
INFO - 2018-01-18 11:32:05 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:05 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:05 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:05 --> Model Class Initialized
INFO - 2018-01-18 11:32:05 --> Controller Class Initialized
INFO - 2018-01-18 11:32:05 --> Model Class Initialized
INFO - 2018-01-18 11:32:05 --> Model Class Initialized
INFO - 2018-01-18 11:32:05 --> Model Class Initialized
INFO - 2018-01-18 11:32:05 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:10 --> Config Class Initialized
INFO - 2018-01-18 11:32:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:10 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:10 --> URI Class Initialized
INFO - 2018-01-18 11:32:10 --> Router Class Initialized
INFO - 2018-01-18 11:32:10 --> Output Class Initialized
INFO - 2018-01-18 11:32:10 --> Security Class Initialized
DEBUG - 2018-01-18 11:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:10 --> Input Class Initialized
INFO - 2018-01-18 11:32:10 --> Language Class Initialized
INFO - 2018-01-18 11:32:10 --> Loader Class Initialized
INFO - 2018-01-18 11:32:10 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:10 --> Helper loaded: form_helper
INFO - 2018-01-18 11:32:10 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:10 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:10 --> Model Class Initialized
INFO - 2018-01-18 11:32:10 --> Controller Class Initialized
INFO - 2018-01-18 11:32:10 --> Model Class Initialized
INFO - 2018-01-18 11:32:10 --> Model Class Initialized
INFO - 2018-01-18 11:32:10 --> Model Class Initialized
INFO - 2018-01-18 11:32:10 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:32:10 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:32:10 --> Final output sent to browser
DEBUG - 2018-01-18 11:32:10 --> Total execution time: 0.0473
INFO - 2018-01-18 11:32:11 --> Config Class Initialized
INFO - 2018-01-18 11:32:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:11 --> Config Class Initialized
INFO - 2018-01-18 11:32:11 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:11 --> Hooks Class Initialized
INFO - 2018-01-18 11:32:11 --> URI Class Initialized
DEBUG - 2018-01-18 11:32:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:11 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:11 --> Router Class Initialized
INFO - 2018-01-18 11:32:11 --> URI Class Initialized
INFO - 2018-01-18 11:32:11 --> Output Class Initialized
INFO - 2018-01-18 11:32:11 --> Router Class Initialized
INFO - 2018-01-18 11:32:11 --> Security Class Initialized
INFO - 2018-01-18 11:32:11 --> Output Class Initialized
DEBUG - 2018-01-18 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:11 --> Input Class Initialized
INFO - 2018-01-18 11:32:11 --> Language Class Initialized
INFO - 2018-01-18 11:32:11 --> Security Class Initialized
ERROR - 2018-01-18 11:32:11 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-01-18 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:11 --> Input Class Initialized
INFO - 2018-01-18 11:32:11 --> Language Class Initialized
ERROR - 2018-01-18 11:32:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 11:32:11 --> Config Class Initialized
INFO - 2018-01-18 11:32:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:32:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:11 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:11 --> URI Class Initialized
INFO - 2018-01-18 11:32:11 --> Config Class Initialized
INFO - 2018-01-18 11:32:11 --> Hooks Class Initialized
INFO - 2018-01-18 11:32:11 --> Router Class Initialized
INFO - 2018-01-18 11:32:11 --> Output Class Initialized
DEBUG - 2018-01-18 11:32:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:32:11 --> Utf8 Class Initialized
INFO - 2018-01-18 11:32:11 --> Security Class Initialized
INFO - 2018-01-18 11:32:11 --> URI Class Initialized
DEBUG - 2018-01-18 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:11 --> Input Class Initialized
INFO - 2018-01-18 11:32:11 --> Language Class Initialized
INFO - 2018-01-18 11:32:11 --> Router Class Initialized
INFO - 2018-01-18 11:32:11 --> Loader Class Initialized
INFO - 2018-01-18 11:32:11 --> Output Class Initialized
INFO - 2018-01-18 11:32:11 --> Helper loaded: url_helper
INFO - 2018-01-18 11:32:11 --> Security Class Initialized
INFO - 2018-01-18 11:32:11 --> Helper loaded: form_helper
DEBUG - 2018-01-18 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:32:11 --> Input Class Initialized
INFO - 2018-01-18 11:32:11 --> Language Class Initialized
ERROR - 2018-01-18 11:32:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 11:32:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:32:11 --> Form Validation Class Initialized
INFO - 2018-01-18 11:32:11 --> Model Class Initialized
INFO - 2018-01-18 11:32:11 --> Controller Class Initialized
INFO - 2018-01-18 11:32:11 --> Model Class Initialized
INFO - 2018-01-18 11:32:11 --> Model Class Initialized
INFO - 2018-01-18 11:32:11 --> Model Class Initialized
INFO - 2018-01-18 11:32:11 --> Model Class Initialized
DEBUG - 2018-01-18 11:32:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:55:20 --> Config Class Initialized
INFO - 2018-01-18 11:55:20 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:20 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:20 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:20 --> URI Class Initialized
DEBUG - 2018-01-18 11:55:20 --> No URI present. Default controller set.
INFO - 2018-01-18 11:55:20 --> Router Class Initialized
INFO - 2018-01-18 11:55:20 --> Output Class Initialized
INFO - 2018-01-18 11:55:20 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:20 --> Input Class Initialized
INFO - 2018-01-18 11:55:20 --> Language Class Initialized
INFO - 2018-01-18 11:55:20 --> Loader Class Initialized
INFO - 2018-01-18 11:55:20 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:20 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:20 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:20 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:20 --> Model Class Initialized
INFO - 2018-01-18 11:55:20 --> Controller Class Initialized
INFO - 2018-01-18 11:55:21 --> Config Class Initialized
INFO - 2018-01-18 11:55:21 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:21 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:21 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:21 --> URI Class Initialized
INFO - 2018-01-18 11:55:21 --> Router Class Initialized
INFO - 2018-01-18 11:55:21 --> Output Class Initialized
INFO - 2018-01-18 11:55:21 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:21 --> Input Class Initialized
INFO - 2018-01-18 11:55:21 --> Language Class Initialized
INFO - 2018-01-18 11:55:21 --> Loader Class Initialized
INFO - 2018-01-18 11:55:21 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:21 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:21 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:21 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:21 --> Model Class Initialized
INFO - 2018-01-18 11:55:21 --> Controller Class Initialized
INFO - 2018-01-18 11:55:21 --> Model Class Initialized
DEBUG - 2018-01-18 11:55:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:55:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:55:21 --> Final output sent to browser
DEBUG - 2018-01-18 11:55:21 --> Total execution time: 0.0355
INFO - 2018-01-18 11:55:42 --> Config Class Initialized
INFO - 2018-01-18 11:55:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:42 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:42 --> URI Class Initialized
INFO - 2018-01-18 11:55:42 --> Router Class Initialized
INFO - 2018-01-18 11:55:42 --> Output Class Initialized
INFO - 2018-01-18 11:55:42 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:42 --> Input Class Initialized
INFO - 2018-01-18 11:55:42 --> Language Class Initialized
INFO - 2018-01-18 11:55:42 --> Loader Class Initialized
INFO - 2018-01-18 11:55:42 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:42 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:42 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:42 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:42 --> Model Class Initialized
INFO - 2018-01-18 11:55:42 --> Controller Class Initialized
INFO - 2018-01-18 11:55:42 --> Model Class Initialized
DEBUG - 2018-01-18 11:55:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:55:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 11:55:45 --> Config Class Initialized
INFO - 2018-01-18 11:55:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:45 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:45 --> URI Class Initialized
DEBUG - 2018-01-18 11:55:45 --> No URI present. Default controller set.
INFO - 2018-01-18 11:55:45 --> Router Class Initialized
INFO - 2018-01-18 11:55:45 --> Output Class Initialized
INFO - 2018-01-18 11:55:45 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:45 --> Input Class Initialized
INFO - 2018-01-18 11:55:45 --> Language Class Initialized
INFO - 2018-01-18 11:55:45 --> Loader Class Initialized
INFO - 2018-01-18 11:55:45 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:45 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:45 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:45 --> Model Class Initialized
INFO - 2018-01-18 11:55:45 --> Controller Class Initialized
INFO - 2018-01-18 11:55:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:55:45 --> Final output sent to browser
DEBUG - 2018-01-18 11:55:45 --> Total execution time: 0.0372
INFO - 2018-01-18 11:55:54 --> Config Class Initialized
INFO - 2018-01-18 11:55:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:54 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:54 --> URI Class Initialized
INFO - 2018-01-18 11:55:54 --> Router Class Initialized
INFO - 2018-01-18 11:55:54 --> Output Class Initialized
INFO - 2018-01-18 11:55:54 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:54 --> Input Class Initialized
INFO - 2018-01-18 11:55:54 --> Language Class Initialized
INFO - 2018-01-18 11:55:54 --> Loader Class Initialized
INFO - 2018-01-18 11:55:54 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:54 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:54 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:54 --> Model Class Initialized
INFO - 2018-01-18 11:55:54 --> Controller Class Initialized
INFO - 2018-01-18 11:55:54 --> Model Class Initialized
INFO - 2018-01-18 11:55:54 --> Model Class Initialized
INFO - 2018-01-18 11:55:54 --> Model Class Initialized
INFO - 2018-01-18 11:55:54 --> Model Class Initialized
DEBUG - 2018-01-18 11:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:55:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:55:54 --> Final output sent to browser
DEBUG - 2018-01-18 11:55:54 --> Total execution time: 0.0601
INFO - 2018-01-18 11:55:55 --> Config Class Initialized
INFO - 2018-01-18 11:55:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:55 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:55 --> URI Class Initialized
INFO - 2018-01-18 11:55:55 --> Router Class Initialized
INFO - 2018-01-18 11:55:55 --> Output Class Initialized
INFO - 2018-01-18 11:55:55 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:55 --> Input Class Initialized
INFO - 2018-01-18 11:55:55 --> Language Class Initialized
INFO - 2018-01-18 11:55:55 --> Loader Class Initialized
INFO - 2018-01-18 11:55:55 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:55 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:55 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:55 --> Model Class Initialized
INFO - 2018-01-18 11:55:55 --> Controller Class Initialized
INFO - 2018-01-18 11:55:55 --> Model Class Initialized
INFO - 2018-01-18 11:55:55 --> Model Class Initialized
INFO - 2018-01-18 11:55:55 --> Model Class Initialized
INFO - 2018-01-18 11:55:55 --> Model Class Initialized
DEBUG - 2018-01-18 11:55:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:55:58 --> Config Class Initialized
INFO - 2018-01-18 11:55:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:55:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:55:58 --> Utf8 Class Initialized
INFO - 2018-01-18 11:55:58 --> URI Class Initialized
DEBUG - 2018-01-18 11:55:58 --> No URI present. Default controller set.
INFO - 2018-01-18 11:55:58 --> Router Class Initialized
INFO - 2018-01-18 11:55:58 --> Output Class Initialized
INFO - 2018-01-18 11:55:58 --> Security Class Initialized
DEBUG - 2018-01-18 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:55:58 --> Input Class Initialized
INFO - 2018-01-18 11:55:58 --> Language Class Initialized
INFO - 2018-01-18 11:55:58 --> Loader Class Initialized
INFO - 2018-01-18 11:55:58 --> Helper loaded: url_helper
INFO - 2018-01-18 11:55:58 --> Helper loaded: form_helper
INFO - 2018-01-18 11:55:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:55:58 --> Form Validation Class Initialized
INFO - 2018-01-18 11:55:58 --> Model Class Initialized
INFO - 2018-01-18 11:55:58 --> Controller Class Initialized
INFO - 2018-01-18 11:55:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:55:58 --> Final output sent to browser
DEBUG - 2018-01-18 11:55:58 --> Total execution time: 0.0348
INFO - 2018-01-18 11:56:02 --> Config Class Initialized
INFO - 2018-01-18 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:56:02 --> Utf8 Class Initialized
INFO - 2018-01-18 11:56:02 --> URI Class Initialized
INFO - 2018-01-18 11:56:02 --> Router Class Initialized
INFO - 2018-01-18 11:56:02 --> Output Class Initialized
INFO - 2018-01-18 11:56:02 --> Security Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:56:02 --> Input Class Initialized
INFO - 2018-01-18 11:56:02 --> Language Class Initialized
INFO - 2018-01-18 11:56:02 --> Loader Class Initialized
INFO - 2018-01-18 11:56:02 --> Helper loaded: url_helper
INFO - 2018-01-18 11:56:02 --> Helper loaded: form_helper
INFO - 2018-01-18 11:56:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:56:02 --> Form Validation Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Controller Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:56:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:56:02 --> Final output sent to browser
DEBUG - 2018-01-18 11:56:02 --> Total execution time: 0.0465
INFO - 2018-01-18 11:56:02 --> Config Class Initialized
INFO - 2018-01-18 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:56:02 --> Utf8 Class Initialized
INFO - 2018-01-18 11:56:02 --> URI Class Initialized
INFO - 2018-01-18 11:56:02 --> Router Class Initialized
INFO - 2018-01-18 11:56:02 --> Output Class Initialized
INFO - 2018-01-18 11:56:02 --> Security Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:56:02 --> Input Class Initialized
INFO - 2018-01-18 11:56:02 --> Language Class Initialized
INFO - 2018-01-18 11:56:02 --> Loader Class Initialized
INFO - 2018-01-18 11:56:02 --> Helper loaded: url_helper
INFO - 2018-01-18 11:56:02 --> Helper loaded: form_helper
INFO - 2018-01-18 11:56:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:56:02 --> Form Validation Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Controller Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
INFO - 2018-01-18 11:56:02 --> Model Class Initialized
DEBUG - 2018-01-18 11:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:56:04 --> Config Class Initialized
INFO - 2018-01-18 11:56:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:56:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:56:04 --> Utf8 Class Initialized
INFO - 2018-01-18 11:56:05 --> URI Class Initialized
INFO - 2018-01-18 11:56:05 --> Router Class Initialized
INFO - 2018-01-18 11:56:05 --> Output Class Initialized
INFO - 2018-01-18 11:56:05 --> Security Class Initialized
DEBUG - 2018-01-18 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:56:05 --> Input Class Initialized
INFO - 2018-01-18 11:56:05 --> Language Class Initialized
INFO - 2018-01-18 11:56:05 --> Loader Class Initialized
INFO - 2018-01-18 11:56:05 --> Helper loaded: url_helper
INFO - 2018-01-18 11:56:05 --> Helper loaded: form_helper
INFO - 2018-01-18 11:56:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:56:05 --> Form Validation Class Initialized
INFO - 2018-01-18 11:56:05 --> Model Class Initialized
INFO - 2018-01-18 11:56:05 --> Controller Class Initialized
INFO - 2018-01-18 11:56:05 --> Model Class Initialized
INFO - 2018-01-18 11:56:05 --> Model Class Initialized
INFO - 2018-01-18 11:56:05 --> Model Class Initialized
INFO - 2018-01-18 11:56:05 --> Model Class Initialized
DEBUG - 2018-01-18 11:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:56:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 11:56:05 --> Final output sent to browser
DEBUG - 2018-01-18 11:56:05 --> Total execution time: 0.0464
INFO - 2018-01-18 11:57:00 --> Config Class Initialized
INFO - 2018-01-18 11:57:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:00 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:00 --> URI Class Initialized
INFO - 2018-01-18 11:57:00 --> Router Class Initialized
INFO - 2018-01-18 11:57:00 --> Output Class Initialized
INFO - 2018-01-18 11:57:00 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:00 --> Input Class Initialized
INFO - 2018-01-18 11:57:00 --> Language Class Initialized
INFO - 2018-01-18 11:57:00 --> Loader Class Initialized
INFO - 2018-01-18 11:57:00 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:00 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:00 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:00 --> Model Class Initialized
INFO - 2018-01-18 11:57:00 --> Controller Class Initialized
INFO - 2018-01-18 11:57:00 --> Model Class Initialized
INFO - 2018-01-18 11:57:00 --> Model Class Initialized
INFO - 2018-01-18 11:57:00 --> Model Class Initialized
INFO - 2018-01-18 11:57:00 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:00 --> Final output sent to browser
DEBUG - 2018-01-18 11:57:00 --> Total execution time: 0.0447
INFO - 2018-01-18 11:57:01 --> Config Class Initialized
INFO - 2018-01-18 11:57:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:01 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:01 --> URI Class Initialized
INFO - 2018-01-18 11:57:01 --> Router Class Initialized
INFO - 2018-01-18 11:57:01 --> Output Class Initialized
INFO - 2018-01-18 11:57:01 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:01 --> Input Class Initialized
INFO - 2018-01-18 11:57:01 --> Language Class Initialized
INFO - 2018-01-18 11:57:01 --> Loader Class Initialized
INFO - 2018-01-18 11:57:01 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:01 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:01 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:01 --> Model Class Initialized
INFO - 2018-01-18 11:57:01 --> Controller Class Initialized
INFO - 2018-01-18 11:57:01 --> Model Class Initialized
INFO - 2018-01-18 11:57:01 --> Model Class Initialized
INFO - 2018-01-18 11:57:01 --> Model Class Initialized
INFO - 2018-01-18 11:57:01 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:02 --> Config Class Initialized
INFO - 2018-01-18 11:57:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:02 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:02 --> URI Class Initialized
INFO - 2018-01-18 11:57:02 --> Router Class Initialized
INFO - 2018-01-18 11:57:02 --> Output Class Initialized
INFO - 2018-01-18 11:57:02 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:02 --> Input Class Initialized
INFO - 2018-01-18 11:57:02 --> Language Class Initialized
INFO - 2018-01-18 11:57:02 --> Loader Class Initialized
INFO - 2018-01-18 11:57:02 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:02 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:02 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:02 --> Model Class Initialized
INFO - 2018-01-18 11:57:02 --> Controller Class Initialized
INFO - 2018-01-18 11:57:02 --> Model Class Initialized
INFO - 2018-01-18 11:57:02 --> Model Class Initialized
INFO - 2018-01-18 11:57:02 --> Model Class Initialized
INFO - 2018-01-18 11:57:02 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:06 --> Config Class Initialized
INFO - 2018-01-18 11:57:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:06 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:06 --> URI Class Initialized
INFO - 2018-01-18 11:57:06 --> Router Class Initialized
INFO - 2018-01-18 11:57:06 --> Output Class Initialized
INFO - 2018-01-18 11:57:06 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:06 --> Input Class Initialized
INFO - 2018-01-18 11:57:06 --> Language Class Initialized
INFO - 2018-01-18 11:57:06 --> Loader Class Initialized
INFO - 2018-01-18 11:57:06 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:06 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:06 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:06 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:06 --> Model Class Initialized
INFO - 2018-01-18 11:57:06 --> Controller Class Initialized
INFO - 2018-01-18 11:57:06 --> Model Class Initialized
INFO - 2018-01-18 11:57:06 --> Model Class Initialized
INFO - 2018-01-18 11:57:06 --> Model Class Initialized
INFO - 2018-01-18 11:57:06 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:43 --> Config Class Initialized
INFO - 2018-01-18 11:57:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:43 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:43 --> URI Class Initialized
INFO - 2018-01-18 11:57:43 --> Router Class Initialized
INFO - 2018-01-18 11:57:43 --> Output Class Initialized
INFO - 2018-01-18 11:57:43 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:43 --> Input Class Initialized
INFO - 2018-01-18 11:57:43 --> Language Class Initialized
INFO - 2018-01-18 11:57:43 --> Loader Class Initialized
INFO - 2018-01-18 11:57:43 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:43 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:43 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:43 --> Model Class Initialized
INFO - 2018-01-18 11:57:43 --> Controller Class Initialized
INFO - 2018-01-18 11:57:43 --> Model Class Initialized
INFO - 2018-01-18 11:57:43 --> Model Class Initialized
INFO - 2018-01-18 11:57:43 --> Model Class Initialized
INFO - 2018-01-18 11:57:43 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:46 --> Config Class Initialized
INFO - 2018-01-18 11:57:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:46 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:46 --> URI Class Initialized
INFO - 2018-01-18 11:57:46 --> Router Class Initialized
INFO - 2018-01-18 11:57:46 --> Output Class Initialized
INFO - 2018-01-18 11:57:46 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:46 --> Input Class Initialized
INFO - 2018-01-18 11:57:46 --> Language Class Initialized
INFO - 2018-01-18 11:57:46 --> Loader Class Initialized
INFO - 2018-01-18 11:57:46 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:46 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:46 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:46 --> Model Class Initialized
INFO - 2018-01-18 11:57:46 --> Controller Class Initialized
INFO - 2018-01-18 11:57:46 --> Model Class Initialized
INFO - 2018-01-18 11:57:46 --> Model Class Initialized
INFO - 2018-01-18 11:57:46 --> Model Class Initialized
INFO - 2018-01-18 11:57:46 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:48 --> Config Class Initialized
INFO - 2018-01-18 11:57:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:48 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:48 --> URI Class Initialized
INFO - 2018-01-18 11:57:48 --> Router Class Initialized
INFO - 2018-01-18 11:57:48 --> Output Class Initialized
INFO - 2018-01-18 11:57:48 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:48 --> Input Class Initialized
INFO - 2018-01-18 11:57:48 --> Language Class Initialized
INFO - 2018-01-18 11:57:48 --> Loader Class Initialized
INFO - 2018-01-18 11:57:48 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:48 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:48 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:48 --> Model Class Initialized
INFO - 2018-01-18 11:57:48 --> Controller Class Initialized
INFO - 2018-01-18 11:57:48 --> Model Class Initialized
INFO - 2018-01-18 11:57:48 --> Model Class Initialized
INFO - 2018-01-18 11:57:48 --> Model Class Initialized
INFO - 2018-01-18 11:57:48 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 11:57:50 --> Config Class Initialized
INFO - 2018-01-18 11:57:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 11:57:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 11:57:50 --> Utf8 Class Initialized
INFO - 2018-01-18 11:57:50 --> URI Class Initialized
INFO - 2018-01-18 11:57:50 --> Router Class Initialized
INFO - 2018-01-18 11:57:50 --> Output Class Initialized
INFO - 2018-01-18 11:57:50 --> Security Class Initialized
DEBUG - 2018-01-18 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 11:57:50 --> Input Class Initialized
INFO - 2018-01-18 11:57:50 --> Language Class Initialized
INFO - 2018-01-18 11:57:50 --> Loader Class Initialized
INFO - 2018-01-18 11:57:50 --> Helper loaded: url_helper
INFO - 2018-01-18 11:57:50 --> Helper loaded: form_helper
INFO - 2018-01-18 11:57:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 11:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 11:57:50 --> Form Validation Class Initialized
INFO - 2018-01-18 11:57:50 --> Model Class Initialized
INFO - 2018-01-18 11:57:50 --> Controller Class Initialized
INFO - 2018-01-18 11:57:50 --> Model Class Initialized
INFO - 2018-01-18 11:57:50 --> Model Class Initialized
INFO - 2018-01-18 11:57:50 --> Model Class Initialized
INFO - 2018-01-18 11:57:50 --> Model Class Initialized
DEBUG - 2018-01-18 11:57:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:00:38 --> Config Class Initialized
INFO - 2018-01-18 12:00:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:38 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:38 --> URI Class Initialized
INFO - 2018-01-18 12:00:38 --> Router Class Initialized
INFO - 2018-01-18 12:00:38 --> Output Class Initialized
INFO - 2018-01-18 12:00:38 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:38 --> Input Class Initialized
INFO - 2018-01-18 12:00:38 --> Language Class Initialized
INFO - 2018-01-18 12:00:38 --> Loader Class Initialized
INFO - 2018-01-18 12:00:38 --> Helper loaded: url_helper
INFO - 2018-01-18 12:00:38 --> Helper loaded: form_helper
INFO - 2018-01-18 12:00:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:00:38 --> Form Validation Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Controller Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:00:38 --> Config Class Initialized
INFO - 2018-01-18 12:00:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:38 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:38 --> URI Class Initialized
INFO - 2018-01-18 12:00:38 --> Router Class Initialized
INFO - 2018-01-18 12:00:38 --> Output Class Initialized
INFO - 2018-01-18 12:00:38 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:38 --> Input Class Initialized
INFO - 2018-01-18 12:00:38 --> Language Class Initialized
INFO - 2018-01-18 12:00:38 --> Loader Class Initialized
INFO - 2018-01-18 12:00:38 --> Helper loaded: url_helper
INFO - 2018-01-18 12:00:38 --> Helper loaded: form_helper
INFO - 2018-01-18 12:00:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:00:38 --> Form Validation Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Controller Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
INFO - 2018-01-18 12:00:38 --> Model Class Initialized
DEBUG - 2018-01-18 12:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:00:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:00:38 --> Final output sent to browser
DEBUG - 2018-01-18 12:00:38 --> Total execution time: 0.0883
INFO - 2018-01-18 12:00:39 --> Config Class Initialized
INFO - 2018-01-18 12:00:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:39 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:39 --> URI Class Initialized
INFO - 2018-01-18 12:00:39 --> Router Class Initialized
INFO - 2018-01-18 12:00:39 --> Output Class Initialized
INFO - 2018-01-18 12:00:39 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:39 --> Input Class Initialized
INFO - 2018-01-18 12:00:39 --> Language Class Initialized
ERROR - 2018-01-18 12:00:39 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:00:51 --> Config Class Initialized
INFO - 2018-01-18 12:00:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:51 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:51 --> URI Class Initialized
INFO - 2018-01-18 12:00:51 --> Router Class Initialized
INFO - 2018-01-18 12:00:51 --> Output Class Initialized
INFO - 2018-01-18 12:00:51 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:51 --> Input Class Initialized
INFO - 2018-01-18 12:00:51 --> Language Class Initialized
INFO - 2018-01-18 12:00:51 --> Loader Class Initialized
INFO - 2018-01-18 12:00:51 --> Helper loaded: url_helper
INFO - 2018-01-18 12:00:51 --> Helper loaded: form_helper
INFO - 2018-01-18 12:00:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:00:51 --> Form Validation Class Initialized
INFO - 2018-01-18 12:00:51 --> Model Class Initialized
INFO - 2018-01-18 12:00:51 --> Controller Class Initialized
INFO - 2018-01-18 12:00:51 --> Model Class Initialized
INFO - 2018-01-18 12:00:51 --> Model Class Initialized
INFO - 2018-01-18 12:00:51 --> Model Class Initialized
INFO - 2018-01-18 12:00:51 --> Model Class Initialized
DEBUG - 2018-01-18 12:00:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:00:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:00:51 --> Final output sent to browser
DEBUG - 2018-01-18 12:00:51 --> Total execution time: 0.0660
INFO - 2018-01-18 12:00:52 --> Config Class Initialized
INFO - 2018-01-18 12:00:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:52 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:52 --> URI Class Initialized
INFO - 2018-01-18 12:00:52 --> Router Class Initialized
INFO - 2018-01-18 12:00:52 --> Output Class Initialized
INFO - 2018-01-18 12:00:52 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:52 --> Input Class Initialized
INFO - 2018-01-18 12:00:52 --> Language Class Initialized
ERROR - 2018-01-18 12:00:52 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:00:52 --> Config Class Initialized
INFO - 2018-01-18 12:00:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:00:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:00:52 --> Utf8 Class Initialized
INFO - 2018-01-18 12:00:52 --> URI Class Initialized
INFO - 2018-01-18 12:00:52 --> Router Class Initialized
INFO - 2018-01-18 12:00:52 --> Output Class Initialized
INFO - 2018-01-18 12:00:52 --> Security Class Initialized
DEBUG - 2018-01-18 12:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:00:52 --> Input Class Initialized
INFO - 2018-01-18 12:00:52 --> Language Class Initialized
ERROR - 2018-01-18 12:00:52 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:01:44 --> Config Class Initialized
INFO - 2018-01-18 12:01:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:01:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:01:44 --> Utf8 Class Initialized
INFO - 2018-01-18 12:01:44 --> URI Class Initialized
INFO - 2018-01-18 12:01:44 --> Router Class Initialized
INFO - 2018-01-18 12:01:44 --> Output Class Initialized
INFO - 2018-01-18 12:01:44 --> Security Class Initialized
DEBUG - 2018-01-18 12:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:01:44 --> Input Class Initialized
INFO - 2018-01-18 12:01:44 --> Language Class Initialized
INFO - 2018-01-18 12:01:44 --> Loader Class Initialized
INFO - 2018-01-18 12:01:44 --> Helper loaded: url_helper
INFO - 2018-01-18 12:01:44 --> Helper loaded: form_helper
INFO - 2018-01-18 12:01:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:01:44 --> Form Validation Class Initialized
INFO - 2018-01-18 12:01:44 --> Model Class Initialized
INFO - 2018-01-18 12:01:44 --> Controller Class Initialized
INFO - 2018-01-18 12:01:44 --> Model Class Initialized
INFO - 2018-01-18 12:01:44 --> Model Class Initialized
INFO - 2018-01-18 12:01:44 --> Model Class Initialized
INFO - 2018-01-18 12:01:44 --> Model Class Initialized
DEBUG - 2018-01-18 12:01:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:01:44 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:01:44 --> Final output sent to browser
DEBUG - 2018-01-18 12:01:44 --> Total execution time: 0.1257
INFO - 2018-01-18 12:01:45 --> Config Class Initialized
INFO - 2018-01-18 12:01:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:01:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:01:45 --> Utf8 Class Initialized
INFO - 2018-01-18 12:01:45 --> URI Class Initialized
INFO - 2018-01-18 12:01:45 --> Router Class Initialized
INFO - 2018-01-18 12:01:45 --> Output Class Initialized
INFO - 2018-01-18 12:01:45 --> Security Class Initialized
DEBUG - 2018-01-18 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:01:45 --> Input Class Initialized
INFO - 2018-01-18 12:01:45 --> Language Class Initialized
ERROR - 2018-01-18 12:01:45 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:01:45 --> Config Class Initialized
INFO - 2018-01-18 12:01:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:01:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:01:45 --> Utf8 Class Initialized
INFO - 2018-01-18 12:01:45 --> URI Class Initialized
INFO - 2018-01-18 12:01:45 --> Router Class Initialized
INFO - 2018-01-18 12:01:45 --> Output Class Initialized
INFO - 2018-01-18 12:01:45 --> Security Class Initialized
DEBUG - 2018-01-18 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:01:45 --> Input Class Initialized
INFO - 2018-01-18 12:01:45 --> Language Class Initialized
ERROR - 2018-01-18 12:01:45 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:08 --> Config Class Initialized
INFO - 2018-01-18 12:02:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:08 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:08 --> URI Class Initialized
INFO - 2018-01-18 12:02:08 --> Router Class Initialized
INFO - 2018-01-18 12:02:08 --> Output Class Initialized
INFO - 2018-01-18 12:02:08 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:08 --> Input Class Initialized
INFO - 2018-01-18 12:02:08 --> Language Class Initialized
ERROR - 2018-01-18 12:02:08 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:17 --> Config Class Initialized
INFO - 2018-01-18 12:02:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:17 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:17 --> URI Class Initialized
INFO - 2018-01-18 12:02:17 --> Router Class Initialized
INFO - 2018-01-18 12:02:17 --> Output Class Initialized
INFO - 2018-01-18 12:02:17 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:17 --> Input Class Initialized
INFO - 2018-01-18 12:02:17 --> Language Class Initialized
ERROR - 2018-01-18 12:02:17 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:22 --> Config Class Initialized
INFO - 2018-01-18 12:02:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:22 --> URI Class Initialized
INFO - 2018-01-18 12:02:22 --> Router Class Initialized
INFO - 2018-01-18 12:02:22 --> Output Class Initialized
INFO - 2018-01-18 12:02:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:22 --> Input Class Initialized
INFO - 2018-01-18 12:02:22 --> Language Class Initialized
INFO - 2018-01-18 12:02:22 --> Loader Class Initialized
INFO - 2018-01-18 12:02:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Controller Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:22 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:22 --> Total execution time: 0.0483
INFO - 2018-01-18 12:02:22 --> Config Class Initialized
INFO - 2018-01-18 12:02:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:22 --> URI Class Initialized
INFO - 2018-01-18 12:02:22 --> Router Class Initialized
INFO - 2018-01-18 12:02:22 --> Output Class Initialized
INFO - 2018-01-18 12:02:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:22 --> Input Class Initialized
INFO - 2018-01-18 12:02:22 --> Language Class Initialized
INFO - 2018-01-18 12:02:22 --> Loader Class Initialized
INFO - 2018-01-18 12:02:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Controller Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
INFO - 2018-01-18 12:02:22 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:25 --> Config Class Initialized
INFO - 2018-01-18 12:02:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:25 --> URI Class Initialized
INFO - 2018-01-18 12:02:25 --> Router Class Initialized
INFO - 2018-01-18 12:02:25 --> Output Class Initialized
INFO - 2018-01-18 12:02:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:25 --> Input Class Initialized
INFO - 2018-01-18 12:02:25 --> Language Class Initialized
INFO - 2018-01-18 12:02:25 --> Loader Class Initialized
INFO - 2018-01-18 12:02:25 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:25 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:25 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:25 --> Model Class Initialized
INFO - 2018-01-18 12:02:25 --> Controller Class Initialized
INFO - 2018-01-18 12:02:25 --> Model Class Initialized
INFO - 2018-01-18 12:02:25 --> Model Class Initialized
INFO - 2018-01-18 12:02:25 --> Model Class Initialized
INFO - 2018-01-18 12:02:25 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:26 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:26 --> Total execution time: 0.0531
INFO - 2018-01-18 12:02:26 --> Config Class Initialized
INFO - 2018-01-18 12:02:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:26 --> URI Class Initialized
INFO - 2018-01-18 12:02:26 --> Router Class Initialized
INFO - 2018-01-18 12:02:26 --> Output Class Initialized
INFO - 2018-01-18 12:02:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:26 --> Input Class Initialized
INFO - 2018-01-18 12:02:26 --> Language Class Initialized
ERROR - 2018-01-18 12:02:26 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:36 --> Config Class Initialized
INFO - 2018-01-18 12:02:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:36 --> URI Class Initialized
INFO - 2018-01-18 12:02:36 --> Router Class Initialized
INFO - 2018-01-18 12:02:36 --> Output Class Initialized
INFO - 2018-01-18 12:02:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:36 --> Input Class Initialized
INFO - 2018-01-18 12:02:36 --> Language Class Initialized
INFO - 2018-01-18 12:02:36 --> Loader Class Initialized
INFO - 2018-01-18 12:02:36 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:36 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:36 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:36 --> Model Class Initialized
INFO - 2018-01-18 12:02:36 --> Controller Class Initialized
INFO - 2018-01-18 12:02:36 --> Model Class Initialized
INFO - 2018-01-18 12:02:36 --> Model Class Initialized
INFO - 2018-01-18 12:02:36 --> Model Class Initialized
INFO - 2018-01-18 12:02:36 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:02:36 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:36 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:36 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:02:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:36 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:36 --> Total execution time: 0.0571
INFO - 2018-01-18 12:02:37 --> Config Class Initialized
INFO - 2018-01-18 12:02:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:37 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:37 --> URI Class Initialized
INFO - 2018-01-18 12:02:37 --> Router Class Initialized
INFO - 2018-01-18 12:02:37 --> Output Class Initialized
INFO - 2018-01-18 12:02:37 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:37 --> Input Class Initialized
INFO - 2018-01-18 12:02:37 --> Language Class Initialized
ERROR - 2018-01-18 12:02:37 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:40 --> Config Class Initialized
INFO - 2018-01-18 12:02:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:40 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:40 --> URI Class Initialized
INFO - 2018-01-18 12:02:40 --> Router Class Initialized
INFO - 2018-01-18 12:02:40 --> Output Class Initialized
INFO - 2018-01-18 12:02:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:40 --> Input Class Initialized
INFO - 2018-01-18 12:02:40 --> Language Class Initialized
INFO - 2018-01-18 12:02:40 --> Loader Class Initialized
INFO - 2018-01-18 12:02:40 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:40 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:41 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:41 --> Model Class Initialized
INFO - 2018-01-18 12:02:41 --> Controller Class Initialized
INFO - 2018-01-18 12:02:41 --> Model Class Initialized
INFO - 2018-01-18 12:02:41 --> Model Class Initialized
INFO - 2018-01-18 12:02:41 --> Model Class Initialized
INFO - 2018-01-18 12:02:41 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:41 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:41 --> Total execution time: 0.0526
INFO - 2018-01-18 12:02:51 --> Config Class Initialized
INFO - 2018-01-18 12:02:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:51 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:51 --> URI Class Initialized
INFO - 2018-01-18 12:02:51 --> Router Class Initialized
INFO - 2018-01-18 12:02:51 --> Output Class Initialized
INFO - 2018-01-18 12:02:51 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:51 --> Input Class Initialized
INFO - 2018-01-18 12:02:51 --> Language Class Initialized
INFO - 2018-01-18 12:02:51 --> Loader Class Initialized
INFO - 2018-01-18 12:02:51 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:51 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:51 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:51 --> Model Class Initialized
INFO - 2018-01-18 12:02:51 --> Controller Class Initialized
INFO - 2018-01-18 12:02:51 --> Model Class Initialized
INFO - 2018-01-18 12:02:51 --> Model Class Initialized
INFO - 2018-01-18 12:02:51 --> Model Class Initialized
INFO - 2018-01-18 12:02:51 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:02:51 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:51 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:51 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:02:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:51 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:51 --> Total execution time: 0.0572
INFO - 2018-01-18 12:02:52 --> Config Class Initialized
INFO - 2018-01-18 12:02:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:52 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:52 --> URI Class Initialized
INFO - 2018-01-18 12:02:52 --> Router Class Initialized
INFO - 2018-01-18 12:02:52 --> Output Class Initialized
INFO - 2018-01-18 12:02:52 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:52 --> Input Class Initialized
INFO - 2018-01-18 12:02:52 --> Language Class Initialized
ERROR - 2018-01-18 12:02:52 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:55 --> Config Class Initialized
INFO - 2018-01-18 12:02:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:55 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:55 --> URI Class Initialized
INFO - 2018-01-18 12:02:55 --> Router Class Initialized
INFO - 2018-01-18 12:02:55 --> Output Class Initialized
INFO - 2018-01-18 12:02:55 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:55 --> Input Class Initialized
INFO - 2018-01-18 12:02:55 --> Language Class Initialized
INFO - 2018-01-18 12:02:55 --> Loader Class Initialized
INFO - 2018-01-18 12:02:55 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:55 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:55 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:55 --> Model Class Initialized
INFO - 2018-01-18 12:02:55 --> Controller Class Initialized
INFO - 2018-01-18 12:02:55 --> Model Class Initialized
INFO - 2018-01-18 12:02:55 --> Model Class Initialized
INFO - 2018-01-18 12:02:55 --> Model Class Initialized
INFO - 2018-01-18 12:02:55 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:55 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:55 --> Total execution time: 0.0512
INFO - 2018-01-18 12:02:56 --> Config Class Initialized
INFO - 2018-01-18 12:02:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:56 --> URI Class Initialized
INFO - 2018-01-18 12:02:56 --> Router Class Initialized
INFO - 2018-01-18 12:02:56 --> Output Class Initialized
INFO - 2018-01-18 12:02:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:56 --> Input Class Initialized
INFO - 2018-01-18 12:02:56 --> Language Class Initialized
INFO - 2018-01-18 12:02:56 --> Loader Class Initialized
INFO - 2018-01-18 12:02:56 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:56 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:56 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:56 --> Model Class Initialized
INFO - 2018-01-18 12:02:56 --> Controller Class Initialized
INFO - 2018-01-18 12:02:56 --> Model Class Initialized
INFO - 2018-01-18 12:02:56 --> Model Class Initialized
INFO - 2018-01-18 12:02:56 --> Model Class Initialized
INFO - 2018-01-18 12:02:56 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:02:56 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:02:56 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:02:56 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:02:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:56 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:56 --> Total execution time: 0.0517
INFO - 2018-01-18 12:02:57 --> Config Class Initialized
INFO - 2018-01-18 12:02:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:57 --> URI Class Initialized
INFO - 2018-01-18 12:02:57 --> Router Class Initialized
INFO - 2018-01-18 12:02:57 --> Output Class Initialized
INFO - 2018-01-18 12:02:57 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:57 --> Input Class Initialized
INFO - 2018-01-18 12:02:57 --> Language Class Initialized
ERROR - 2018-01-18 12:02:57 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:02:59 --> Config Class Initialized
INFO - 2018-01-18 12:02:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:02:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:02:59 --> Utf8 Class Initialized
INFO - 2018-01-18 12:02:59 --> URI Class Initialized
INFO - 2018-01-18 12:02:59 --> Router Class Initialized
INFO - 2018-01-18 12:02:59 --> Output Class Initialized
INFO - 2018-01-18 12:02:59 --> Security Class Initialized
DEBUG - 2018-01-18 12:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:02:59 --> Input Class Initialized
INFO - 2018-01-18 12:02:59 --> Language Class Initialized
INFO - 2018-01-18 12:02:59 --> Loader Class Initialized
INFO - 2018-01-18 12:02:59 --> Helper loaded: url_helper
INFO - 2018-01-18 12:02:59 --> Helper loaded: form_helper
INFO - 2018-01-18 12:02:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:02:59 --> Form Validation Class Initialized
INFO - 2018-01-18 12:02:59 --> Model Class Initialized
INFO - 2018-01-18 12:02:59 --> Controller Class Initialized
INFO - 2018-01-18 12:02:59 --> Model Class Initialized
INFO - 2018-01-18 12:02:59 --> Model Class Initialized
INFO - 2018-01-18 12:02:59 --> Model Class Initialized
INFO - 2018-01-18 12:02:59 --> Model Class Initialized
DEBUG - 2018-01-18 12:02:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:02:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:02:59 --> Final output sent to browser
DEBUG - 2018-01-18 12:02:59 --> Total execution time: 0.0525
INFO - 2018-01-18 12:03:00 --> Config Class Initialized
INFO - 2018-01-18 12:03:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:00 --> URI Class Initialized
INFO - 2018-01-18 12:03:00 --> Router Class Initialized
INFO - 2018-01-18 12:03:00 --> Output Class Initialized
INFO - 2018-01-18 12:03:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:00 --> Input Class Initialized
INFO - 2018-01-18 12:03:00 --> Language Class Initialized
ERROR - 2018-01-18 12:03:00 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:03:10 --> Config Class Initialized
INFO - 2018-01-18 12:03:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:10 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:10 --> URI Class Initialized
INFO - 2018-01-18 12:03:10 --> Router Class Initialized
INFO - 2018-01-18 12:03:10 --> Output Class Initialized
INFO - 2018-01-18 12:03:10 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:10 --> Input Class Initialized
INFO - 2018-01-18 12:03:10 --> Language Class Initialized
ERROR - 2018-01-18 12:03:10 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:03:13 --> Config Class Initialized
INFO - 2018-01-18 12:03:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:13 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:13 --> URI Class Initialized
INFO - 2018-01-18 12:03:13 --> Router Class Initialized
INFO - 2018-01-18 12:03:13 --> Output Class Initialized
INFO - 2018-01-18 12:03:13 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:13 --> Input Class Initialized
INFO - 2018-01-18 12:03:13 --> Language Class Initialized
ERROR - 2018-01-18 12:03:13 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:03:24 --> Config Class Initialized
INFO - 2018-01-18 12:03:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:24 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:24 --> URI Class Initialized
DEBUG - 2018-01-18 12:03:24 --> No URI present. Default controller set.
INFO - 2018-01-18 12:03:24 --> Router Class Initialized
INFO - 2018-01-18 12:03:24 --> Output Class Initialized
INFO - 2018-01-18 12:03:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:24 --> Input Class Initialized
INFO - 2018-01-18 12:03:24 --> Language Class Initialized
INFO - 2018-01-18 12:03:24 --> Loader Class Initialized
INFO - 2018-01-18 12:03:24 --> Helper loaded: url_helper
INFO - 2018-01-18 12:03:24 --> Helper loaded: form_helper
INFO - 2018-01-18 12:03:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:03:24 --> Form Validation Class Initialized
INFO - 2018-01-18 12:03:24 --> Model Class Initialized
INFO - 2018-01-18 12:03:24 --> Controller Class Initialized
INFO - 2018-01-18 12:03:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:03:24 --> Final output sent to browser
DEBUG - 2018-01-18 12:03:24 --> Total execution time: 0.0346
INFO - 2018-01-18 12:03:26 --> Config Class Initialized
INFO - 2018-01-18 12:03:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:26 --> URI Class Initialized
INFO - 2018-01-18 12:03:26 --> Router Class Initialized
INFO - 2018-01-18 12:03:26 --> Output Class Initialized
INFO - 2018-01-18 12:03:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:26 --> Input Class Initialized
INFO - 2018-01-18 12:03:26 --> Language Class Initialized
INFO - 2018-01-18 12:03:26 --> Loader Class Initialized
INFO - 2018-01-18 12:03:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:03:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:03:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:03:26 --> Form Validation Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Controller Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:03:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:03:26 --> Final output sent to browser
DEBUG - 2018-01-18 12:03:26 --> Total execution time: 0.0471
INFO - 2018-01-18 12:03:26 --> Config Class Initialized
INFO - 2018-01-18 12:03:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:26 --> URI Class Initialized
INFO - 2018-01-18 12:03:26 --> Router Class Initialized
INFO - 2018-01-18 12:03:26 --> Output Class Initialized
INFO - 2018-01-18 12:03:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:26 --> Input Class Initialized
INFO - 2018-01-18 12:03:26 --> Language Class Initialized
INFO - 2018-01-18 12:03:26 --> Loader Class Initialized
INFO - 2018-01-18 12:03:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:03:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:03:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:03:26 --> Form Validation Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Controller Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
INFO - 2018-01-18 12:03:26 --> Model Class Initialized
DEBUG - 2018-01-18 12:03:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:03:35 --> Config Class Initialized
INFO - 2018-01-18 12:03:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:35 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:35 --> URI Class Initialized
INFO - 2018-01-18 12:03:35 --> Router Class Initialized
INFO - 2018-01-18 12:03:35 --> Output Class Initialized
INFO - 2018-01-18 12:03:35 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:35 --> Input Class Initialized
INFO - 2018-01-18 12:03:35 --> Language Class Initialized
INFO - 2018-01-18 12:03:35 --> Loader Class Initialized
INFO - 2018-01-18 12:03:35 --> Helper loaded: url_helper
INFO - 2018-01-18 12:03:35 --> Helper loaded: form_helper
INFO - 2018-01-18 12:03:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:03:35 --> Form Validation Class Initialized
INFO - 2018-01-18 12:03:35 --> Model Class Initialized
INFO - 2018-01-18 12:03:35 --> Controller Class Initialized
INFO - 2018-01-18 12:03:35 --> Model Class Initialized
INFO - 2018-01-18 12:03:35 --> Model Class Initialized
INFO - 2018-01-18 12:03:35 --> Model Class Initialized
INFO - 2018-01-18 12:03:35 --> Model Class Initialized
DEBUG - 2018-01-18 12:03:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:03:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:03:35 --> Final output sent to browser
DEBUG - 2018-01-18 12:03:35 --> Total execution time: 0.0554
INFO - 2018-01-18 12:03:36 --> Config Class Initialized
INFO - 2018-01-18 12:03:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:36 --> URI Class Initialized
INFO - 2018-01-18 12:03:36 --> Router Class Initialized
INFO - 2018-01-18 12:03:36 --> Output Class Initialized
INFO - 2018-01-18 12:03:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:36 --> Input Class Initialized
INFO - 2018-01-18 12:03:36 --> Language Class Initialized
ERROR - 2018-01-18 12:03:36 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:03:36 --> Config Class Initialized
INFO - 2018-01-18 12:03:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:36 --> URI Class Initialized
INFO - 2018-01-18 12:03:36 --> Router Class Initialized
INFO - 2018-01-18 12:03:36 --> Output Class Initialized
INFO - 2018-01-18 12:03:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:36 --> Input Class Initialized
INFO - 2018-01-18 12:03:36 --> Language Class Initialized
ERROR - 2018-01-18 12:03:36 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:03:42 --> Config Class Initialized
INFO - 2018-01-18 12:03:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:03:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:03:42 --> Utf8 Class Initialized
INFO - 2018-01-18 12:03:42 --> URI Class Initialized
INFO - 2018-01-18 12:03:42 --> Router Class Initialized
INFO - 2018-01-18 12:03:42 --> Output Class Initialized
INFO - 2018-01-18 12:03:42 --> Security Class Initialized
DEBUG - 2018-01-18 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:03:42 --> Input Class Initialized
INFO - 2018-01-18 12:03:42 --> Language Class Initialized
ERROR - 2018-01-18 12:03:42 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:04:00 --> Config Class Initialized
INFO - 2018-01-18 12:04:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:00 --> URI Class Initialized
DEBUG - 2018-01-18 12:04:00 --> No URI present. Default controller set.
INFO - 2018-01-18 12:04:00 --> Router Class Initialized
INFO - 2018-01-18 12:04:00 --> Output Class Initialized
INFO - 2018-01-18 12:04:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:00 --> Input Class Initialized
INFO - 2018-01-18 12:04:00 --> Language Class Initialized
INFO - 2018-01-18 12:04:00 --> Loader Class Initialized
INFO - 2018-01-18 12:04:00 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:00 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:00 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:00 --> Model Class Initialized
INFO - 2018-01-18 12:04:00 --> Controller Class Initialized
INFO - 2018-01-18 12:04:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:04:00 --> Final output sent to browser
DEBUG - 2018-01-18 12:04:00 --> Total execution time: 0.0403
INFO - 2018-01-18 12:04:03 --> Config Class Initialized
INFO - 2018-01-18 12:04:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:03 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:03 --> URI Class Initialized
INFO - 2018-01-18 12:04:03 --> Router Class Initialized
INFO - 2018-01-18 12:04:03 --> Output Class Initialized
INFO - 2018-01-18 12:04:03 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:03 --> Input Class Initialized
INFO - 2018-01-18 12:04:03 --> Language Class Initialized
INFO - 2018-01-18 12:04:03 --> Loader Class Initialized
INFO - 2018-01-18 12:04:03 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:03 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:03 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:03 --> Model Class Initialized
INFO - 2018-01-18 12:04:03 --> Controller Class Initialized
INFO - 2018-01-18 12:04:03 --> Model Class Initialized
INFO - 2018-01-18 12:04:03 --> Model Class Initialized
INFO - 2018-01-18 12:04:03 --> Model Class Initialized
INFO - 2018-01-18 12:04:03 --> Model Class Initialized
DEBUG - 2018-01-18 12:04:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:04:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:04:03 --> Final output sent to browser
DEBUG - 2018-01-18 12:04:03 --> Total execution time: 0.0486
INFO - 2018-01-18 12:04:45 --> Config Class Initialized
INFO - 2018-01-18 12:04:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:45 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:45 --> URI Class Initialized
INFO - 2018-01-18 12:04:45 --> Router Class Initialized
INFO - 2018-01-18 12:04:45 --> Output Class Initialized
INFO - 2018-01-18 12:04:45 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:45 --> Input Class Initialized
INFO - 2018-01-18 12:04:45 --> Language Class Initialized
INFO - 2018-01-18 12:04:45 --> Loader Class Initialized
INFO - 2018-01-18 12:04:45 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:45 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:45 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:45 --> Model Class Initialized
INFO - 2018-01-18 12:04:45 --> Controller Class Initialized
INFO - 2018-01-18 12:04:45 --> Model Class Initialized
INFO - 2018-01-18 12:04:45 --> Model Class Initialized
INFO - 2018-01-18 12:04:45 --> Model Class Initialized
INFO - 2018-01-18 12:04:45 --> Model Class Initialized
DEBUG - 2018-01-18 12:04:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:04:45 --> Final output sent to browser
DEBUG - 2018-01-18 12:04:45 --> Total execution time: 0.0442
INFO - 2018-01-18 12:04:46 --> Config Class Initialized
INFO - 2018-01-18 12:04:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:46 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:46 --> URI Class Initialized
INFO - 2018-01-18 12:04:46 --> Router Class Initialized
INFO - 2018-01-18 12:04:46 --> Output Class Initialized
INFO - 2018-01-18 12:04:46 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:46 --> Input Class Initialized
INFO - 2018-01-18 12:04:46 --> Language Class Initialized
INFO - 2018-01-18 12:04:46 --> Loader Class Initialized
INFO - 2018-01-18 12:04:46 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:46 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:46 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:46 --> Model Class Initialized
INFO - 2018-01-18 12:04:46 --> Controller Class Initialized
INFO - 2018-01-18 12:04:46 --> Model Class Initialized
INFO - 2018-01-18 12:04:46 --> Model Class Initialized
INFO - 2018-01-18 12:04:46 --> Model Class Initialized
INFO - 2018-01-18 12:04:46 --> Model Class Initialized
DEBUG - 2018-01-18 12:04:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:04:47 --> Config Class Initialized
INFO - 2018-01-18 12:04:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:47 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:47 --> URI Class Initialized
INFO - 2018-01-18 12:04:47 --> Router Class Initialized
INFO - 2018-01-18 12:04:47 --> Output Class Initialized
INFO - 2018-01-18 12:04:47 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:47 --> Input Class Initialized
INFO - 2018-01-18 12:04:47 --> Language Class Initialized
INFO - 2018-01-18 12:04:47 --> Loader Class Initialized
INFO - 2018-01-18 12:04:47 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:47 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:47 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:47 --> Model Class Initialized
INFO - 2018-01-18 12:04:47 --> Controller Class Initialized
INFO - 2018-01-18 12:04:47 --> Model Class Initialized
INFO - 2018-01-18 12:04:47 --> Model Class Initialized
INFO - 2018-01-18 12:04:47 --> Model Class Initialized
INFO - 2018-01-18 12:04:47 --> Model Class Initialized
DEBUG - 2018-01-18 12:04:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:04:52 --> Config Class Initialized
INFO - 2018-01-18 12:04:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:04:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:04:52 --> Utf8 Class Initialized
INFO - 2018-01-18 12:04:52 --> URI Class Initialized
INFO - 2018-01-18 12:04:52 --> Router Class Initialized
INFO - 2018-01-18 12:04:52 --> Output Class Initialized
INFO - 2018-01-18 12:04:52 --> Security Class Initialized
DEBUG - 2018-01-18 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:04:52 --> Input Class Initialized
INFO - 2018-01-18 12:04:52 --> Language Class Initialized
INFO - 2018-01-18 12:04:52 --> Loader Class Initialized
INFO - 2018-01-18 12:04:52 --> Helper loaded: url_helper
INFO - 2018-01-18 12:04:52 --> Helper loaded: form_helper
INFO - 2018-01-18 12:04:52 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:04:52 --> Form Validation Class Initialized
INFO - 2018-01-18 12:04:52 --> Model Class Initialized
INFO - 2018-01-18 12:04:52 --> Controller Class Initialized
INFO - 2018-01-18 12:04:52 --> Model Class Initialized
INFO - 2018-01-18 12:04:52 --> Model Class Initialized
INFO - 2018-01-18 12:04:52 --> Model Class Initialized
INFO - 2018-01-18 12:04:52 --> Model Class Initialized
DEBUG - 2018-01-18 12:04:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:00 --> Config Class Initialized
INFO - 2018-01-18 12:05:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:00 --> URI Class Initialized
INFO - 2018-01-18 12:05:00 --> Router Class Initialized
INFO - 2018-01-18 12:05:00 --> Output Class Initialized
INFO - 2018-01-18 12:05:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:00 --> Input Class Initialized
INFO - 2018-01-18 12:05:00 --> Language Class Initialized
INFO - 2018-01-18 12:05:00 --> Loader Class Initialized
INFO - 2018-01-18 12:05:00 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:00 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:00 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:00 --> Model Class Initialized
INFO - 2018-01-18 12:05:00 --> Controller Class Initialized
INFO - 2018-01-18 12:05:00 --> Model Class Initialized
INFO - 2018-01-18 12:05:00 --> Model Class Initialized
INFO - 2018-01-18 12:05:00 --> Model Class Initialized
INFO - 2018-01-18 12:05:00 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:04 --> Config Class Initialized
INFO - 2018-01-18 12:05:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:04 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:04 --> URI Class Initialized
INFO - 2018-01-18 12:05:04 --> Router Class Initialized
INFO - 2018-01-18 12:05:04 --> Output Class Initialized
INFO - 2018-01-18 12:05:04 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:04 --> Input Class Initialized
INFO - 2018-01-18 12:05:04 --> Language Class Initialized
INFO - 2018-01-18 12:05:04 --> Loader Class Initialized
INFO - 2018-01-18 12:05:04 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:04 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:04 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:04 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:04 --> Model Class Initialized
INFO - 2018-01-18 12:05:04 --> Controller Class Initialized
INFO - 2018-01-18 12:05:04 --> Model Class Initialized
INFO - 2018-01-18 12:05:04 --> Model Class Initialized
INFO - 2018-01-18 12:05:04 --> Model Class Initialized
INFO - 2018-01-18 12:05:04 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:11 --> Config Class Initialized
INFO - 2018-01-18 12:05:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:11 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:11 --> URI Class Initialized
INFO - 2018-01-18 12:05:11 --> Router Class Initialized
INFO - 2018-01-18 12:05:11 --> Output Class Initialized
INFO - 2018-01-18 12:05:11 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:11 --> Input Class Initialized
INFO - 2018-01-18 12:05:11 --> Language Class Initialized
INFO - 2018-01-18 12:05:11 --> Loader Class Initialized
INFO - 2018-01-18 12:05:11 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:11 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:11 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:11 --> Model Class Initialized
INFO - 2018-01-18 12:05:11 --> Controller Class Initialized
INFO - 2018-01-18 12:05:11 --> Model Class Initialized
INFO - 2018-01-18 12:05:11 --> Model Class Initialized
INFO - 2018-01-18 12:05:11 --> Model Class Initialized
INFO - 2018-01-18 12:05:11 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:14 --> Config Class Initialized
INFO - 2018-01-18 12:05:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:14 --> URI Class Initialized
INFO - 2018-01-18 12:05:14 --> Router Class Initialized
INFO - 2018-01-18 12:05:14 --> Output Class Initialized
INFO - 2018-01-18 12:05:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:14 --> Input Class Initialized
INFO - 2018-01-18 12:05:14 --> Language Class Initialized
INFO - 2018-01-18 12:05:14 --> Loader Class Initialized
INFO - 2018-01-18 12:05:14 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:14 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:14 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:14 --> Model Class Initialized
INFO - 2018-01-18 12:05:14 --> Controller Class Initialized
INFO - 2018-01-18 12:05:14 --> Model Class Initialized
INFO - 2018-01-18 12:05:14 --> Model Class Initialized
INFO - 2018-01-18 12:05:14 --> Model Class Initialized
INFO - 2018-01-18 12:05:14 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:18 --> Config Class Initialized
INFO - 2018-01-18 12:05:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:18 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:18 --> URI Class Initialized
INFO - 2018-01-18 12:05:18 --> Router Class Initialized
INFO - 2018-01-18 12:05:18 --> Output Class Initialized
INFO - 2018-01-18 12:05:18 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:18 --> Input Class Initialized
INFO - 2018-01-18 12:05:18 --> Language Class Initialized
INFO - 2018-01-18 12:05:18 --> Loader Class Initialized
INFO - 2018-01-18 12:05:18 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:18 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:18 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:18 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:18 --> Model Class Initialized
INFO - 2018-01-18 12:05:18 --> Controller Class Initialized
INFO - 2018-01-18 12:05:18 --> Model Class Initialized
INFO - 2018-01-18 12:05:18 --> Model Class Initialized
INFO - 2018-01-18 12:05:18 --> Model Class Initialized
INFO - 2018-01-18 12:05:18 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:05:19 --> Config Class Initialized
INFO - 2018-01-18 12:05:19 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:05:19 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:05:19 --> Utf8 Class Initialized
INFO - 2018-01-18 12:05:19 --> URI Class Initialized
INFO - 2018-01-18 12:05:19 --> Router Class Initialized
INFO - 2018-01-18 12:05:19 --> Output Class Initialized
INFO - 2018-01-18 12:05:19 --> Security Class Initialized
DEBUG - 2018-01-18 12:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:05:19 --> Input Class Initialized
INFO - 2018-01-18 12:05:19 --> Language Class Initialized
INFO - 2018-01-18 12:05:19 --> Loader Class Initialized
INFO - 2018-01-18 12:05:19 --> Helper loaded: url_helper
INFO - 2018-01-18 12:05:19 --> Helper loaded: form_helper
INFO - 2018-01-18 12:05:19 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:05:19 --> Form Validation Class Initialized
INFO - 2018-01-18 12:05:19 --> Model Class Initialized
INFO - 2018-01-18 12:05:19 --> Controller Class Initialized
INFO - 2018-01-18 12:05:19 --> Model Class Initialized
INFO - 2018-01-18 12:05:19 --> Model Class Initialized
INFO - 2018-01-18 12:05:19 --> Model Class Initialized
INFO - 2018-01-18 12:05:19 --> Model Class Initialized
DEBUG - 2018-01-18 12:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:06:55 --> Config Class Initialized
INFO - 2018-01-18 12:06:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:06:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:06:55 --> Utf8 Class Initialized
INFO - 2018-01-18 12:06:55 --> URI Class Initialized
INFO - 2018-01-18 12:06:55 --> Router Class Initialized
INFO - 2018-01-18 12:06:55 --> Output Class Initialized
INFO - 2018-01-18 12:06:55 --> Security Class Initialized
DEBUG - 2018-01-18 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:06:55 --> Input Class Initialized
INFO - 2018-01-18 12:06:55 --> Language Class Initialized
INFO - 2018-01-18 12:06:55 --> Loader Class Initialized
INFO - 2018-01-18 12:06:55 --> Helper loaded: url_helper
INFO - 2018-01-18 12:06:55 --> Helper loaded: form_helper
INFO - 2018-01-18 12:06:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:06:55 --> Form Validation Class Initialized
INFO - 2018-01-18 12:06:55 --> Model Class Initialized
INFO - 2018-01-18 12:06:55 --> Controller Class Initialized
INFO - 2018-01-18 12:06:55 --> Model Class Initialized
INFO - 2018-01-18 12:06:55 --> Model Class Initialized
INFO - 2018-01-18 12:06:55 --> Model Class Initialized
INFO - 2018-01-18 12:06:55 --> Model Class Initialized
DEBUG - 2018-01-18 12:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:06:56 --> Config Class Initialized
INFO - 2018-01-18 12:06:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:06:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:06:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:06:56 --> URI Class Initialized
INFO - 2018-01-18 12:06:56 --> Router Class Initialized
INFO - 2018-01-18 12:06:56 --> Output Class Initialized
INFO - 2018-01-18 12:06:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:06:56 --> Input Class Initialized
INFO - 2018-01-18 12:06:56 --> Language Class Initialized
INFO - 2018-01-18 12:06:56 --> Loader Class Initialized
INFO - 2018-01-18 12:06:56 --> Helper loaded: url_helper
INFO - 2018-01-18 12:06:56 --> Helper loaded: form_helper
INFO - 2018-01-18 12:06:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:06:56 --> Form Validation Class Initialized
INFO - 2018-01-18 12:06:56 --> Model Class Initialized
INFO - 2018-01-18 12:06:56 --> Controller Class Initialized
INFO - 2018-01-18 12:06:56 --> Model Class Initialized
INFO - 2018-01-18 12:06:56 --> Model Class Initialized
INFO - 2018-01-18 12:06:56 --> Model Class Initialized
INFO - 2018-01-18 12:06:56 --> Model Class Initialized
DEBUG - 2018-01-18 12:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:06:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:06:56 --> Final output sent to browser
DEBUG - 2018-01-18 12:06:56 --> Total execution time: 0.0544
INFO - 2018-01-18 12:06:56 --> Config Class Initialized
INFO - 2018-01-18 12:06:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:06:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:06:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:06:56 --> URI Class Initialized
INFO - 2018-01-18 12:06:56 --> Router Class Initialized
INFO - 2018-01-18 12:06:56 --> Output Class Initialized
INFO - 2018-01-18 12:06:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:06:56 --> Input Class Initialized
INFO - 2018-01-18 12:06:56 --> Language Class Initialized
ERROR - 2018-01-18 12:06:56 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:07:07 --> Config Class Initialized
INFO - 2018-01-18 12:07:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:07:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:07:07 --> Utf8 Class Initialized
INFO - 2018-01-18 12:07:07 --> URI Class Initialized
INFO - 2018-01-18 12:07:07 --> Router Class Initialized
INFO - 2018-01-18 12:07:07 --> Output Class Initialized
INFO - 2018-01-18 12:07:07 --> Security Class Initialized
DEBUG - 2018-01-18 12:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:07:07 --> Input Class Initialized
INFO - 2018-01-18 12:07:07 --> Language Class Initialized
INFO - 2018-01-18 12:07:07 --> Loader Class Initialized
INFO - 2018-01-18 12:07:07 --> Helper loaded: url_helper
INFO - 2018-01-18 12:07:07 --> Helper loaded: form_helper
INFO - 2018-01-18 12:07:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:07:07 --> Form Validation Class Initialized
INFO - 2018-01-18 12:07:07 --> Model Class Initialized
INFO - 2018-01-18 12:07:07 --> Controller Class Initialized
INFO - 2018-01-18 12:07:07 --> Model Class Initialized
INFO - 2018-01-18 12:07:07 --> Model Class Initialized
INFO - 2018-01-18 12:07:07 --> Model Class Initialized
INFO - 2018-01-18 12:07:07 --> Model Class Initialized
DEBUG - 2018-01-18 12:07:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:07:07 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:07:07 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:07:07 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:07:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:07:07 --> Final output sent to browser
DEBUG - 2018-01-18 12:07:07 --> Total execution time: 0.0568
INFO - 2018-01-18 12:07:08 --> Config Class Initialized
INFO - 2018-01-18 12:07:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:07:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:07:08 --> Utf8 Class Initialized
INFO - 2018-01-18 12:07:08 --> URI Class Initialized
INFO - 2018-01-18 12:07:08 --> Router Class Initialized
INFO - 2018-01-18 12:07:08 --> Output Class Initialized
INFO - 2018-01-18 12:07:08 --> Security Class Initialized
DEBUG - 2018-01-18 12:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:07:08 --> Input Class Initialized
INFO - 2018-01-18 12:07:08 --> Language Class Initialized
ERROR - 2018-01-18 12:07:08 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:07:59 --> Config Class Initialized
INFO - 2018-01-18 12:07:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:07:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:07:59 --> Utf8 Class Initialized
INFO - 2018-01-18 12:07:59 --> URI Class Initialized
DEBUG - 2018-01-18 12:07:59 --> No URI present. Default controller set.
INFO - 2018-01-18 12:07:59 --> Router Class Initialized
INFO - 2018-01-18 12:07:59 --> Output Class Initialized
INFO - 2018-01-18 12:07:59 --> Security Class Initialized
DEBUG - 2018-01-18 12:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:07:59 --> Input Class Initialized
INFO - 2018-01-18 12:07:59 --> Language Class Initialized
INFO - 2018-01-18 12:07:59 --> Loader Class Initialized
INFO - 2018-01-18 12:07:59 --> Helper loaded: url_helper
INFO - 2018-01-18 12:07:59 --> Helper loaded: form_helper
INFO - 2018-01-18 12:07:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:07:59 --> Form Validation Class Initialized
INFO - 2018-01-18 12:07:59 --> Model Class Initialized
INFO - 2018-01-18 12:07:59 --> Controller Class Initialized
INFO - 2018-01-18 12:07:59 --> Config Class Initialized
INFO - 2018-01-18 12:07:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:07:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:07:59 --> Utf8 Class Initialized
INFO - 2018-01-18 12:07:59 --> URI Class Initialized
INFO - 2018-01-18 12:07:59 --> Router Class Initialized
INFO - 2018-01-18 12:07:59 --> Output Class Initialized
INFO - 2018-01-18 12:07:59 --> Security Class Initialized
DEBUG - 2018-01-18 12:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:07:59 --> Input Class Initialized
INFO - 2018-01-18 12:07:59 --> Language Class Initialized
INFO - 2018-01-18 12:07:59 --> Loader Class Initialized
INFO - 2018-01-18 12:07:59 --> Helper loaded: url_helper
INFO - 2018-01-18 12:07:59 --> Helper loaded: form_helper
INFO - 2018-01-18 12:07:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:07:59 --> Form Validation Class Initialized
INFO - 2018-01-18 12:07:59 --> Model Class Initialized
INFO - 2018-01-18 12:07:59 --> Controller Class Initialized
INFO - 2018-01-18 12:07:59 --> Model Class Initialized
DEBUG - 2018-01-18 12:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:07:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:07:59 --> Final output sent to browser
DEBUG - 2018-01-18 12:07:59 --> Total execution time: 0.0350
INFO - 2018-01-18 12:10:07 --> Config Class Initialized
INFO - 2018-01-18 12:10:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:07 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:07 --> URI Class Initialized
INFO - 2018-01-18 12:10:07 --> Router Class Initialized
INFO - 2018-01-18 12:10:07 --> Output Class Initialized
INFO - 2018-01-18 12:10:07 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:07 --> Input Class Initialized
INFO - 2018-01-18 12:10:07 --> Language Class Initialized
INFO - 2018-01-18 12:10:07 --> Loader Class Initialized
INFO - 2018-01-18 12:10:07 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:07 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:07 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:07 --> Model Class Initialized
INFO - 2018-01-18 12:10:07 --> Controller Class Initialized
INFO - 2018-01-18 12:10:07 --> Model Class Initialized
DEBUG - 2018-01-18 12:10:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:10:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 12:10:08 --> Config Class Initialized
INFO - 2018-01-18 12:10:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:08 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:08 --> URI Class Initialized
DEBUG - 2018-01-18 12:10:08 --> No URI present. Default controller set.
INFO - 2018-01-18 12:10:08 --> Router Class Initialized
INFO - 2018-01-18 12:10:08 --> Output Class Initialized
INFO - 2018-01-18 12:10:08 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:08 --> Input Class Initialized
INFO - 2018-01-18 12:10:08 --> Language Class Initialized
INFO - 2018-01-18 12:10:08 --> Loader Class Initialized
INFO - 2018-01-18 12:10:08 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:08 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:08 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:08 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:08 --> Model Class Initialized
INFO - 2018-01-18 12:10:08 --> Controller Class Initialized
INFO - 2018-01-18 12:10:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:10:08 --> Final output sent to browser
DEBUG - 2018-01-18 12:10:08 --> Total execution time: 0.0372
INFO - 2018-01-18 12:10:23 --> Config Class Initialized
INFO - 2018-01-18 12:10:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:23 --> URI Class Initialized
INFO - 2018-01-18 12:10:23 --> Router Class Initialized
INFO - 2018-01-18 12:10:23 --> Output Class Initialized
INFO - 2018-01-18 12:10:23 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:23 --> Input Class Initialized
INFO - 2018-01-18 12:10:23 --> Language Class Initialized
INFO - 2018-01-18 12:10:23 --> Loader Class Initialized
INFO - 2018-01-18 12:10:23 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:23 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:23 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:23 --> Model Class Initialized
INFO - 2018-01-18 12:10:23 --> Controller Class Initialized
INFO - 2018-01-18 12:10:23 --> Model Class Initialized
INFO - 2018-01-18 12:10:23 --> Model Class Initialized
INFO - 2018-01-18 12:10:23 --> Model Class Initialized
INFO - 2018-01-18 12:10:23 --> Model Class Initialized
DEBUG - 2018-01-18 12:10:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:10:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:10:23 --> Final output sent to browser
DEBUG - 2018-01-18 12:10:23 --> Total execution time: 0.0470
INFO - 2018-01-18 12:10:24 --> Config Class Initialized
INFO - 2018-01-18 12:10:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:24 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:24 --> URI Class Initialized
INFO - 2018-01-18 12:10:24 --> Router Class Initialized
INFO - 2018-01-18 12:10:24 --> Output Class Initialized
INFO - 2018-01-18 12:10:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:24 --> Input Class Initialized
INFO - 2018-01-18 12:10:24 --> Language Class Initialized
INFO - 2018-01-18 12:10:24 --> Loader Class Initialized
INFO - 2018-01-18 12:10:24 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:24 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:24 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:24 --> Model Class Initialized
INFO - 2018-01-18 12:10:24 --> Controller Class Initialized
INFO - 2018-01-18 12:10:24 --> Model Class Initialized
INFO - 2018-01-18 12:10:24 --> Model Class Initialized
INFO - 2018-01-18 12:10:24 --> Model Class Initialized
INFO - 2018-01-18 12:10:24 --> Model Class Initialized
DEBUG - 2018-01-18 12:10:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:10:40 --> Config Class Initialized
INFO - 2018-01-18 12:10:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:40 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:40 --> URI Class Initialized
INFO - 2018-01-18 12:10:40 --> Router Class Initialized
INFO - 2018-01-18 12:10:40 --> Output Class Initialized
INFO - 2018-01-18 12:10:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:40 --> Input Class Initialized
INFO - 2018-01-18 12:10:40 --> Language Class Initialized
INFO - 2018-01-18 12:10:40 --> Loader Class Initialized
INFO - 2018-01-18 12:10:40 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:40 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:40 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:40 --> Model Class Initialized
INFO - 2018-01-18 12:10:40 --> Controller Class Initialized
INFO - 2018-01-18 12:10:40 --> Model Class Initialized
INFO - 2018-01-18 12:10:40 --> Model Class Initialized
INFO - 2018-01-18 12:10:40 --> Model Class Initialized
INFO - 2018-01-18 12:10:40 --> Model Class Initialized
DEBUG - 2018-01-18 12:10:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:10:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:10:40 --> Final output sent to browser
DEBUG - 2018-01-18 12:10:40 --> Total execution time: 0.0581
INFO - 2018-01-18 12:10:41 --> Config Class Initialized
INFO - 2018-01-18 12:10:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:41 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:41 --> URI Class Initialized
INFO - 2018-01-18 12:10:41 --> Router Class Initialized
INFO - 2018-01-18 12:10:41 --> Output Class Initialized
INFO - 2018-01-18 12:10:41 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:41 --> Input Class Initialized
INFO - 2018-01-18 12:10:41 --> Language Class Initialized
ERROR - 2018-01-18 12:10:41 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:10:56 --> Config Class Initialized
INFO - 2018-01-18 12:10:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:56 --> URI Class Initialized
INFO - 2018-01-18 12:10:56 --> Router Class Initialized
INFO - 2018-01-18 12:10:56 --> Output Class Initialized
INFO - 2018-01-18 12:10:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:56 --> Input Class Initialized
INFO - 2018-01-18 12:10:56 --> Language Class Initialized
INFO - 2018-01-18 12:10:56 --> Loader Class Initialized
INFO - 2018-01-18 12:10:56 --> Helper loaded: url_helper
INFO - 2018-01-18 12:10:56 --> Helper loaded: form_helper
INFO - 2018-01-18 12:10:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:10:56 --> Form Validation Class Initialized
INFO - 2018-01-18 12:10:56 --> Model Class Initialized
INFO - 2018-01-18 12:10:56 --> Controller Class Initialized
INFO - 2018-01-18 12:10:56 --> Model Class Initialized
INFO - 2018-01-18 12:10:56 --> Model Class Initialized
INFO - 2018-01-18 12:10:56 --> Model Class Initialized
INFO - 2018-01-18 12:10:56 --> Model Class Initialized
DEBUG - 2018-01-18 12:10:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:10:56 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:10:56 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:10:56 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:10:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:10:56 --> Final output sent to browser
DEBUG - 2018-01-18 12:10:56 --> Total execution time: 0.0533
INFO - 2018-01-18 12:10:58 --> Config Class Initialized
INFO - 2018-01-18 12:10:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:10:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:10:58 --> Utf8 Class Initialized
INFO - 2018-01-18 12:10:58 --> URI Class Initialized
INFO - 2018-01-18 12:10:58 --> Router Class Initialized
INFO - 2018-01-18 12:10:58 --> Output Class Initialized
INFO - 2018-01-18 12:10:58 --> Security Class Initialized
DEBUG - 2018-01-18 12:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:10:58 --> Input Class Initialized
INFO - 2018-01-18 12:10:58 --> Language Class Initialized
ERROR - 2018-01-18 12:10:58 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:11:25 --> Config Class Initialized
INFO - 2018-01-18 12:11:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:11:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:11:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:11:25 --> URI Class Initialized
INFO - 2018-01-18 12:11:25 --> Router Class Initialized
INFO - 2018-01-18 12:11:25 --> Output Class Initialized
INFO - 2018-01-18 12:11:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:11:25 --> Input Class Initialized
INFO - 2018-01-18 12:11:25 --> Language Class Initialized
INFO - 2018-01-18 12:11:25 --> Loader Class Initialized
INFO - 2018-01-18 12:11:25 --> Helper loaded: url_helper
INFO - 2018-01-18 12:11:25 --> Helper loaded: form_helper
INFO - 2018-01-18 12:11:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:11:25 --> Form Validation Class Initialized
INFO - 2018-01-18 12:11:25 --> Model Class Initialized
INFO - 2018-01-18 12:11:25 --> Controller Class Initialized
INFO - 2018-01-18 12:11:25 --> Model Class Initialized
INFO - 2018-01-18 12:11:25 --> Model Class Initialized
INFO - 2018-01-18 12:11:25 --> Model Class Initialized
INFO - 2018-01-18 12:11:25 --> Model Class Initialized
DEBUG - 2018-01-18 12:11:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:11:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:11:25 --> Final output sent to browser
DEBUG - 2018-01-18 12:11:25 --> Total execution time: 0.0553
INFO - 2018-01-18 12:11:26 --> Config Class Initialized
INFO - 2018-01-18 12:11:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:11:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:11:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:11:26 --> URI Class Initialized
INFO - 2018-01-18 12:11:26 --> Router Class Initialized
INFO - 2018-01-18 12:11:26 --> Output Class Initialized
INFO - 2018-01-18 12:11:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:11:26 --> Input Class Initialized
INFO - 2018-01-18 12:11:26 --> Language Class Initialized
ERROR - 2018-01-18 12:11:26 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:11:26 --> Config Class Initialized
INFO - 2018-01-18 12:11:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:11:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:11:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:11:26 --> URI Class Initialized
INFO - 2018-01-18 12:11:26 --> Router Class Initialized
INFO - 2018-01-18 12:11:26 --> Output Class Initialized
INFO - 2018-01-18 12:11:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:11:26 --> Input Class Initialized
INFO - 2018-01-18 12:11:26 --> Language Class Initialized
ERROR - 2018-01-18 12:11:26 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:11:33 --> Config Class Initialized
INFO - 2018-01-18 12:11:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:11:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:11:33 --> Utf8 Class Initialized
INFO - 2018-01-18 12:11:33 --> URI Class Initialized
INFO - 2018-01-18 12:11:33 --> Router Class Initialized
INFO - 2018-01-18 12:11:33 --> Output Class Initialized
INFO - 2018-01-18 12:11:33 --> Security Class Initialized
DEBUG - 2018-01-18 12:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:11:33 --> Input Class Initialized
INFO - 2018-01-18 12:11:33 --> Language Class Initialized
ERROR - 2018-01-18 12:11:33 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:12:13 --> Config Class Initialized
INFO - 2018-01-18 12:12:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:12:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:12:13 --> Utf8 Class Initialized
INFO - 2018-01-18 12:12:13 --> URI Class Initialized
INFO - 2018-01-18 12:12:13 --> Router Class Initialized
INFO - 2018-01-18 12:12:13 --> Output Class Initialized
INFO - 2018-01-18 12:12:13 --> Security Class Initialized
DEBUG - 2018-01-18 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:12:13 --> Input Class Initialized
INFO - 2018-01-18 12:12:13 --> Language Class Initialized
INFO - 2018-01-18 12:12:13 --> Loader Class Initialized
INFO - 2018-01-18 12:12:13 --> Helper loaded: url_helper
INFO - 2018-01-18 12:12:13 --> Helper loaded: form_helper
INFO - 2018-01-18 12:12:13 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:12:13 --> Form Validation Class Initialized
INFO - 2018-01-18 12:12:13 --> Model Class Initialized
INFO - 2018-01-18 12:12:13 --> Controller Class Initialized
INFO - 2018-01-18 12:12:13 --> Model Class Initialized
INFO - 2018-01-18 12:12:13 --> Model Class Initialized
INFO - 2018-01-18 12:12:13 --> Model Class Initialized
INFO - 2018-01-18 12:12:13 --> Model Class Initialized
DEBUG - 2018-01-18 12:12:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:12:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:12:13 --> Final output sent to browser
DEBUG - 2018-01-18 12:12:13 --> Total execution time: 0.0499
INFO - 2018-01-18 12:12:14 --> Config Class Initialized
INFO - 2018-01-18 12:12:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:12:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:12:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:12:14 --> URI Class Initialized
INFO - 2018-01-18 12:12:14 --> Router Class Initialized
INFO - 2018-01-18 12:12:14 --> Output Class Initialized
INFO - 2018-01-18 12:12:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:12:14 --> Input Class Initialized
INFO - 2018-01-18 12:12:14 --> Language Class Initialized
INFO - 2018-01-18 12:12:14 --> Loader Class Initialized
INFO - 2018-01-18 12:12:14 --> Helper loaded: url_helper
INFO - 2018-01-18 12:12:14 --> Helper loaded: form_helper
INFO - 2018-01-18 12:12:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:12:14 --> Form Validation Class Initialized
INFO - 2018-01-18 12:12:14 --> Model Class Initialized
INFO - 2018-01-18 12:12:14 --> Controller Class Initialized
INFO - 2018-01-18 12:12:14 --> Model Class Initialized
INFO - 2018-01-18 12:12:14 --> Model Class Initialized
INFO - 2018-01-18 12:12:14 --> Model Class Initialized
INFO - 2018-01-18 12:12:14 --> Model Class Initialized
DEBUG - 2018-01-18 12:12:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:12:23 --> Config Class Initialized
INFO - 2018-01-18 12:12:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:12:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:12:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:12:23 --> URI Class Initialized
INFO - 2018-01-18 12:12:23 --> Router Class Initialized
INFO - 2018-01-18 12:12:23 --> Output Class Initialized
INFO - 2018-01-18 12:12:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:12:24 --> Input Class Initialized
INFO - 2018-01-18 12:12:24 --> Language Class Initialized
INFO - 2018-01-18 12:12:24 --> Loader Class Initialized
INFO - 2018-01-18 12:12:24 --> Helper loaded: url_helper
INFO - 2018-01-18 12:12:24 --> Helper loaded: form_helper
INFO - 2018-01-18 12:12:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:12:24 --> Form Validation Class Initialized
INFO - 2018-01-18 12:12:24 --> Model Class Initialized
INFO - 2018-01-18 12:12:24 --> Controller Class Initialized
INFO - 2018-01-18 12:12:24 --> Model Class Initialized
INFO - 2018-01-18 12:12:24 --> Model Class Initialized
INFO - 2018-01-18 12:12:24 --> Model Class Initialized
INFO - 2018-01-18 12:12:24 --> Model Class Initialized
DEBUG - 2018-01-18 12:12:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:12:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:12:24 --> Final output sent to browser
DEBUG - 2018-01-18 12:12:24 --> Total execution time: 0.0699
INFO - 2018-01-18 12:12:33 --> Config Class Initialized
INFO - 2018-01-18 12:12:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:12:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:12:33 --> Utf8 Class Initialized
INFO - 2018-01-18 12:12:33 --> URI Class Initialized
INFO - 2018-01-18 12:12:33 --> Router Class Initialized
INFO - 2018-01-18 12:12:33 --> Output Class Initialized
INFO - 2018-01-18 12:12:33 --> Security Class Initialized
DEBUG - 2018-01-18 12:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:12:33 --> Input Class Initialized
INFO - 2018-01-18 12:12:33 --> Language Class Initialized
INFO - 2018-01-18 12:12:33 --> Loader Class Initialized
INFO - 2018-01-18 12:12:33 --> Helper loaded: url_helper
INFO - 2018-01-18 12:12:33 --> Helper loaded: form_helper
INFO - 2018-01-18 12:12:33 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:12:33 --> Form Validation Class Initialized
INFO - 2018-01-18 12:12:33 --> Model Class Initialized
INFO - 2018-01-18 12:12:33 --> Controller Class Initialized
INFO - 2018-01-18 12:12:33 --> Model Class Initialized
INFO - 2018-01-18 12:12:33 --> Model Class Initialized
INFO - 2018-01-18 12:12:33 --> Model Class Initialized
INFO - 2018-01-18 12:12:33 --> Model Class Initialized
DEBUG - 2018-01-18 12:12:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:12:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:12:33 --> Final output sent to browser
DEBUG - 2018-01-18 12:12:33 --> Total execution time: 0.0512
INFO - 2018-01-18 12:13:01 --> Config Class Initialized
INFO - 2018-01-18 12:13:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:01 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:01 --> URI Class Initialized
INFO - 2018-01-18 12:13:01 --> Router Class Initialized
INFO - 2018-01-18 12:13:01 --> Output Class Initialized
INFO - 2018-01-18 12:13:01 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:01 --> Input Class Initialized
INFO - 2018-01-18 12:13:01 --> Language Class Initialized
INFO - 2018-01-18 12:13:01 --> Loader Class Initialized
INFO - 2018-01-18 12:13:01 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:01 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:01 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:01 --> Model Class Initialized
INFO - 2018-01-18 12:13:01 --> Controller Class Initialized
INFO - 2018-01-18 12:13:01 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:02 --> Config Class Initialized
INFO - 2018-01-18 12:13:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:02 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:02 --> URI Class Initialized
INFO - 2018-01-18 12:13:02 --> Router Class Initialized
INFO - 2018-01-18 12:13:02 --> Output Class Initialized
INFO - 2018-01-18 12:13:02 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:02 --> Input Class Initialized
INFO - 2018-01-18 12:13:02 --> Language Class Initialized
INFO - 2018-01-18 12:13:02 --> Loader Class Initialized
INFO - 2018-01-18 12:13:02 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:02 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:02 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:02 --> Model Class Initialized
INFO - 2018-01-18 12:13:02 --> Controller Class Initialized
INFO - 2018-01-18 12:13:02 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:02 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:02 --> Total execution time: 0.0454
INFO - 2018-01-18 12:13:21 --> Config Class Initialized
INFO - 2018-01-18 12:13:21 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:21 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:21 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:21 --> URI Class Initialized
INFO - 2018-01-18 12:13:21 --> Router Class Initialized
INFO - 2018-01-18 12:13:21 --> Output Class Initialized
INFO - 2018-01-18 12:13:21 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:21 --> Input Class Initialized
INFO - 2018-01-18 12:13:21 --> Language Class Initialized
INFO - 2018-01-18 12:13:21 --> Loader Class Initialized
INFO - 2018-01-18 12:13:21 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:21 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:21 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:21 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:21 --> Model Class Initialized
INFO - 2018-01-18 12:13:21 --> Controller Class Initialized
INFO - 2018-01-18 12:13:21 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 12:13:22 --> Config Class Initialized
INFO - 2018-01-18 12:13:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:22 --> URI Class Initialized
DEBUG - 2018-01-18 12:13:22 --> No URI present. Default controller set.
INFO - 2018-01-18 12:13:22 --> Router Class Initialized
INFO - 2018-01-18 12:13:22 --> Output Class Initialized
INFO - 2018-01-18 12:13:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:22 --> Input Class Initialized
INFO - 2018-01-18 12:13:22 --> Language Class Initialized
INFO - 2018-01-18 12:13:22 --> Loader Class Initialized
INFO - 2018-01-18 12:13:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:22 --> Model Class Initialized
INFO - 2018-01-18 12:13:22 --> Controller Class Initialized
INFO - 2018-01-18 12:13:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:22 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:22 --> Total execution time: 0.0374
INFO - 2018-01-18 12:13:25 --> Config Class Initialized
INFO - 2018-01-18 12:13:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:25 --> URI Class Initialized
INFO - 2018-01-18 12:13:25 --> Router Class Initialized
INFO - 2018-01-18 12:13:25 --> Output Class Initialized
INFO - 2018-01-18 12:13:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:25 --> Input Class Initialized
INFO - 2018-01-18 12:13:25 --> Language Class Initialized
INFO - 2018-01-18 12:13:25 --> Loader Class Initialized
INFO - 2018-01-18 12:13:25 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:25 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:25 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:25 --> Model Class Initialized
INFO - 2018-01-18 12:13:25 --> Controller Class Initialized
INFO - 2018-01-18 12:13:25 --> Model Class Initialized
INFO - 2018-01-18 12:13:25 --> Model Class Initialized
INFO - 2018-01-18 12:13:25 --> Model Class Initialized
INFO - 2018-01-18 12:13:25 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:25 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:25 --> Total execution time: 0.0460
INFO - 2018-01-18 12:13:29 --> Config Class Initialized
INFO - 2018-01-18 12:13:29 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:29 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:29 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:29 --> URI Class Initialized
INFO - 2018-01-18 12:13:29 --> Router Class Initialized
INFO - 2018-01-18 12:13:29 --> Output Class Initialized
INFO - 2018-01-18 12:13:29 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:29 --> Input Class Initialized
INFO - 2018-01-18 12:13:29 --> Language Class Initialized
INFO - 2018-01-18 12:13:29 --> Loader Class Initialized
INFO - 2018-01-18 12:13:29 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:29 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:29 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:29 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:29 --> Model Class Initialized
INFO - 2018-01-18 12:13:29 --> Controller Class Initialized
INFO - 2018-01-18 12:13:29 --> Model Class Initialized
INFO - 2018-01-18 12:13:29 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:29 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:29 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:29 --> Total execution time: 0.0404
INFO - 2018-01-18 12:13:30 --> Config Class Initialized
INFO - 2018-01-18 12:13:30 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:30 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:30 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:30 --> URI Class Initialized
INFO - 2018-01-18 12:13:30 --> Router Class Initialized
INFO - 2018-01-18 12:13:30 --> Output Class Initialized
INFO - 2018-01-18 12:13:30 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:30 --> Input Class Initialized
INFO - 2018-01-18 12:13:30 --> Language Class Initialized
INFO - 2018-01-18 12:13:30 --> Loader Class Initialized
INFO - 2018-01-18 12:13:30 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:30 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:30 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:30 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:30 --> Model Class Initialized
INFO - 2018-01-18 12:13:30 --> Controller Class Initialized
INFO - 2018-01-18 12:13:30 --> Model Class Initialized
INFO - 2018-01-18 12:13:30 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:32 --> Config Class Initialized
INFO - 2018-01-18 12:13:32 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:32 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:32 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:32 --> URI Class Initialized
INFO - 2018-01-18 12:13:32 --> Router Class Initialized
INFO - 2018-01-18 12:13:32 --> Output Class Initialized
INFO - 2018-01-18 12:13:32 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:32 --> Input Class Initialized
INFO - 2018-01-18 12:13:32 --> Language Class Initialized
INFO - 2018-01-18 12:13:32 --> Loader Class Initialized
INFO - 2018-01-18 12:13:32 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:32 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:32 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:32 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:32 --> Model Class Initialized
INFO - 2018-01-18 12:13:32 --> Controller Class Initialized
INFO - 2018-01-18 12:13:32 --> Model Class Initialized
INFO - 2018-01-18 12:13:32 --> Model Class Initialized
INFO - 2018-01-18 12:13:32 --> Model Class Initialized
INFO - 2018-01-18 12:13:32 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:32 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:32 --> Total execution time: 0.0481
INFO - 2018-01-18 12:13:34 --> Config Class Initialized
INFO - 2018-01-18 12:13:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:34 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:34 --> URI Class Initialized
INFO - 2018-01-18 12:13:34 --> Router Class Initialized
INFO - 2018-01-18 12:13:34 --> Output Class Initialized
INFO - 2018-01-18 12:13:34 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:34 --> Input Class Initialized
INFO - 2018-01-18 12:13:34 --> Language Class Initialized
INFO - 2018-01-18 12:13:34 --> Loader Class Initialized
INFO - 2018-01-18 12:13:34 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:34 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:34 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
INFO - 2018-01-18 12:13:34 --> Controller Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:34 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:34 --> Total execution time: 0.0426
INFO - 2018-01-18 12:13:34 --> Config Class Initialized
INFO - 2018-01-18 12:13:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:34 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:34 --> URI Class Initialized
INFO - 2018-01-18 12:13:34 --> Router Class Initialized
INFO - 2018-01-18 12:13:34 --> Output Class Initialized
INFO - 2018-01-18 12:13:34 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:34 --> Input Class Initialized
INFO - 2018-01-18 12:13:34 --> Language Class Initialized
INFO - 2018-01-18 12:13:34 --> Loader Class Initialized
INFO - 2018-01-18 12:13:34 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:34 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:34 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
INFO - 2018-01-18 12:13:34 --> Controller Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
INFO - 2018-01-18 12:13:34 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:51 --> Config Class Initialized
INFO - 2018-01-18 12:13:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:51 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:51 --> URI Class Initialized
INFO - 2018-01-18 12:13:51 --> Router Class Initialized
INFO - 2018-01-18 12:13:51 --> Output Class Initialized
INFO - 2018-01-18 12:13:51 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:51 --> Input Class Initialized
INFO - 2018-01-18 12:13:51 --> Language Class Initialized
INFO - 2018-01-18 12:13:51 --> Loader Class Initialized
INFO - 2018-01-18 12:13:51 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:51 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:51 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
INFO - 2018-01-18 12:13:51 --> Controller Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:51 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:51 --> Total execution time: 0.0514
INFO - 2018-01-18 12:13:51 --> Config Class Initialized
INFO - 2018-01-18 12:13:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:51 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:51 --> URI Class Initialized
INFO - 2018-01-18 12:13:51 --> Router Class Initialized
INFO - 2018-01-18 12:13:51 --> Output Class Initialized
INFO - 2018-01-18 12:13:51 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:51 --> Input Class Initialized
INFO - 2018-01-18 12:13:51 --> Language Class Initialized
INFO - 2018-01-18 12:13:51 --> Loader Class Initialized
INFO - 2018-01-18 12:13:51 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:51 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:51 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
INFO - 2018-01-18 12:13:51 --> Controller Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
INFO - 2018-01-18 12:13:51 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:54 --> Config Class Initialized
INFO - 2018-01-18 12:13:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:54 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:54 --> URI Class Initialized
INFO - 2018-01-18 12:13:54 --> Router Class Initialized
INFO - 2018-01-18 12:13:54 --> Output Class Initialized
INFO - 2018-01-18 12:13:54 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:54 --> Input Class Initialized
INFO - 2018-01-18 12:13:54 --> Language Class Initialized
INFO - 2018-01-18 12:13:54 --> Loader Class Initialized
INFO - 2018-01-18 12:13:54 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:54 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:54 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:54 --> Model Class Initialized
INFO - 2018-01-18 12:13:54 --> Controller Class Initialized
INFO - 2018-01-18 12:13:54 --> Model Class Initialized
INFO - 2018-01-18 12:13:54 --> Model Class Initialized
INFO - 2018-01-18 12:13:54 --> Model Class Initialized
INFO - 2018-01-18 12:13:54 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:54 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:54 --> Total execution time: 0.0503
INFO - 2018-01-18 12:13:57 --> Config Class Initialized
INFO - 2018-01-18 12:13:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:13:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:13:57 --> Utf8 Class Initialized
INFO - 2018-01-18 12:13:57 --> URI Class Initialized
INFO - 2018-01-18 12:13:57 --> Router Class Initialized
INFO - 2018-01-18 12:13:57 --> Output Class Initialized
INFO - 2018-01-18 12:13:57 --> Security Class Initialized
DEBUG - 2018-01-18 12:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:13:57 --> Input Class Initialized
INFO - 2018-01-18 12:13:57 --> Language Class Initialized
INFO - 2018-01-18 12:13:57 --> Loader Class Initialized
INFO - 2018-01-18 12:13:57 --> Helper loaded: url_helper
INFO - 2018-01-18 12:13:57 --> Helper loaded: form_helper
INFO - 2018-01-18 12:13:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:13:57 --> Form Validation Class Initialized
INFO - 2018-01-18 12:13:57 --> Model Class Initialized
INFO - 2018-01-18 12:13:57 --> Controller Class Initialized
INFO - 2018-01-18 12:13:57 --> Model Class Initialized
INFO - 2018-01-18 12:13:57 --> Model Class Initialized
INFO - 2018-01-18 12:13:57 --> Model Class Initialized
INFO - 2018-01-18 12:13:57 --> Model Class Initialized
DEBUG - 2018-01-18 12:13:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:13:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:13:57 --> Final output sent to browser
DEBUG - 2018-01-18 12:13:57 --> Total execution time: 0.0450
INFO - 2018-01-18 12:14:11 --> Config Class Initialized
INFO - 2018-01-18 12:14:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:14:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:14:11 --> Utf8 Class Initialized
INFO - 2018-01-18 12:14:11 --> URI Class Initialized
INFO - 2018-01-18 12:14:11 --> Router Class Initialized
INFO - 2018-01-18 12:14:11 --> Output Class Initialized
INFO - 2018-01-18 12:14:11 --> Security Class Initialized
DEBUG - 2018-01-18 12:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:14:11 --> Input Class Initialized
INFO - 2018-01-18 12:14:11 --> Language Class Initialized
INFO - 2018-01-18 12:14:11 --> Loader Class Initialized
INFO - 2018-01-18 12:14:11 --> Helper loaded: url_helper
INFO - 2018-01-18 12:14:11 --> Helper loaded: form_helper
INFO - 2018-01-18 12:14:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:14:11 --> Form Validation Class Initialized
INFO - 2018-01-18 12:14:11 --> Model Class Initialized
INFO - 2018-01-18 12:14:11 --> Controller Class Initialized
INFO - 2018-01-18 12:14:11 --> Model Class Initialized
DEBUG - 2018-01-18 12:14:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:14:15 --> Config Class Initialized
INFO - 2018-01-18 12:14:15 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:14:15 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:14:15 --> Utf8 Class Initialized
INFO - 2018-01-18 12:14:15 --> URI Class Initialized
INFO - 2018-01-18 12:14:15 --> Router Class Initialized
INFO - 2018-01-18 12:14:15 --> Output Class Initialized
INFO - 2018-01-18 12:14:15 --> Security Class Initialized
DEBUG - 2018-01-18 12:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:14:15 --> Input Class Initialized
INFO - 2018-01-18 12:14:15 --> Language Class Initialized
INFO - 2018-01-18 12:14:15 --> Loader Class Initialized
INFO - 2018-01-18 12:14:15 --> Helper loaded: url_helper
INFO - 2018-01-18 12:14:15 --> Helper loaded: form_helper
INFO - 2018-01-18 12:14:15 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:14:15 --> Form Validation Class Initialized
INFO - 2018-01-18 12:14:15 --> Model Class Initialized
INFO - 2018-01-18 12:14:15 --> Controller Class Initialized
INFO - 2018-01-18 12:14:15 --> Model Class Initialized
DEBUG - 2018-01-18 12:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:14:15 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:14:15 --> Final output sent to browser
DEBUG - 2018-01-18 12:14:15 --> Total execution time: 0.0383
INFO - 2018-01-18 12:15:11 --> Config Class Initialized
INFO - 2018-01-18 12:15:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:11 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:11 --> URI Class Initialized
INFO - 2018-01-18 12:15:11 --> Router Class Initialized
INFO - 2018-01-18 12:15:11 --> Output Class Initialized
INFO - 2018-01-18 12:15:11 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:11 --> Input Class Initialized
INFO - 2018-01-18 12:15:11 --> Language Class Initialized
INFO - 2018-01-18 12:15:11 --> Loader Class Initialized
INFO - 2018-01-18 12:15:11 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:11 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:11 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:11 --> Model Class Initialized
INFO - 2018-01-18 12:15:11 --> Controller Class Initialized
INFO - 2018-01-18 12:15:11 --> Model Class Initialized
INFO - 2018-01-18 12:15:11 --> Model Class Initialized
INFO - 2018-01-18 12:15:11 --> Model Class Initialized
INFO - 2018-01-18 12:15:11 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:15:11 --> Final output sent to browser
DEBUG - 2018-01-18 12:15:11 --> Total execution time: 0.0639
INFO - 2018-01-18 12:15:12 --> Config Class Initialized
INFO - 2018-01-18 12:15:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:12 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:12 --> URI Class Initialized
INFO - 2018-01-18 12:15:12 --> Router Class Initialized
INFO - 2018-01-18 12:15:12 --> Output Class Initialized
INFO - 2018-01-18 12:15:12 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:12 --> Input Class Initialized
INFO - 2018-01-18 12:15:12 --> Language Class Initialized
INFO - 2018-01-18 12:15:12 --> Loader Class Initialized
INFO - 2018-01-18 12:15:12 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:12 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:12 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:12 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:12 --> Model Class Initialized
INFO - 2018-01-18 12:15:12 --> Controller Class Initialized
INFO - 2018-01-18 12:15:12 --> Model Class Initialized
INFO - 2018-01-18 12:15:12 --> Model Class Initialized
INFO - 2018-01-18 12:15:12 --> Model Class Initialized
INFO - 2018-01-18 12:15:12 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:26 --> Config Class Initialized
INFO - 2018-01-18 12:15:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:26 --> URI Class Initialized
INFO - 2018-01-18 12:15:26 --> Router Class Initialized
INFO - 2018-01-18 12:15:26 --> Output Class Initialized
INFO - 2018-01-18 12:15:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:26 --> Input Class Initialized
INFO - 2018-01-18 12:15:26 --> Language Class Initialized
INFO - 2018-01-18 12:15:26 --> Loader Class Initialized
INFO - 2018-01-18 12:15:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:26 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:26 --> Model Class Initialized
INFO - 2018-01-18 12:15:26 --> Controller Class Initialized
INFO - 2018-01-18 12:15:26 --> Model Class Initialized
INFO - 2018-01-18 12:15:26 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:15:26 --> Final output sent to browser
DEBUG - 2018-01-18 12:15:26 --> Total execution time: 0.0389
INFO - 2018-01-18 12:15:26 --> Config Class Initialized
INFO - 2018-01-18 12:15:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:26 --> URI Class Initialized
INFO - 2018-01-18 12:15:26 --> Router Class Initialized
INFO - 2018-01-18 12:15:26 --> Output Class Initialized
INFO - 2018-01-18 12:15:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:26 --> Input Class Initialized
INFO - 2018-01-18 12:15:26 --> Language Class Initialized
INFO - 2018-01-18 12:15:26 --> Loader Class Initialized
INFO - 2018-01-18 12:15:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:27 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:27 --> Model Class Initialized
INFO - 2018-01-18 12:15:27 --> Controller Class Initialized
INFO - 2018-01-18 12:15:27 --> Model Class Initialized
INFO - 2018-01-18 12:15:27 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:32 --> Config Class Initialized
INFO - 2018-01-18 12:15:32 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:32 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:32 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:32 --> URI Class Initialized
INFO - 2018-01-18 12:15:32 --> Router Class Initialized
INFO - 2018-01-18 12:15:32 --> Output Class Initialized
INFO - 2018-01-18 12:15:32 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:32 --> Input Class Initialized
INFO - 2018-01-18 12:15:32 --> Language Class Initialized
INFO - 2018-01-18 12:15:32 --> Loader Class Initialized
INFO - 2018-01-18 12:15:32 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:32 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:32 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:32 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:32 --> Model Class Initialized
INFO - 2018-01-18 12:15:32 --> Controller Class Initialized
INFO - 2018-01-18 12:15:32 --> Model Class Initialized
INFO - 2018-01-18 12:15:32 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:15:32 --> Final output sent to browser
DEBUG - 2018-01-18 12:15:32 --> Total execution time: 0.0408
INFO - 2018-01-18 12:15:33 --> Config Class Initialized
INFO - 2018-01-18 12:15:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:33 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:33 --> URI Class Initialized
INFO - 2018-01-18 12:15:33 --> Router Class Initialized
INFO - 2018-01-18 12:15:33 --> Output Class Initialized
INFO - 2018-01-18 12:15:33 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:33 --> Input Class Initialized
INFO - 2018-01-18 12:15:33 --> Language Class Initialized
INFO - 2018-01-18 12:15:33 --> Loader Class Initialized
INFO - 2018-01-18 12:15:33 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:33 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:33 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:33 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:33 --> Model Class Initialized
INFO - 2018-01-18 12:15:33 --> Controller Class Initialized
INFO - 2018-01-18 12:15:33 --> Model Class Initialized
INFO - 2018-01-18 12:15:33 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:33 --> Config Class Initialized
INFO - 2018-01-18 12:15:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:33 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:33 --> URI Class Initialized
INFO - 2018-01-18 12:15:33 --> Router Class Initialized
INFO - 2018-01-18 12:15:33 --> Output Class Initialized
INFO - 2018-01-18 12:15:33 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:33 --> Input Class Initialized
INFO - 2018-01-18 12:15:33 --> Language Class Initialized
INFO - 2018-01-18 12:15:34 --> Loader Class Initialized
INFO - 2018-01-18 12:15:34 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:34 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:34 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
INFO - 2018-01-18 12:15:34 --> Controller Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:15:34 --> Final output sent to browser
DEBUG - 2018-01-18 12:15:34 --> Total execution time: 0.0417
INFO - 2018-01-18 12:15:34 --> Config Class Initialized
INFO - 2018-01-18 12:15:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:34 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:34 --> URI Class Initialized
INFO - 2018-01-18 12:15:34 --> Router Class Initialized
INFO - 2018-01-18 12:15:34 --> Output Class Initialized
INFO - 2018-01-18 12:15:34 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:34 --> Input Class Initialized
INFO - 2018-01-18 12:15:34 --> Language Class Initialized
INFO - 2018-01-18 12:15:34 --> Loader Class Initialized
INFO - 2018-01-18 12:15:34 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:34 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:34 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:34 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
INFO - 2018-01-18 12:15:34 --> Controller Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
INFO - 2018-01-18 12:15:34 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:35 --> Config Class Initialized
INFO - 2018-01-18 12:15:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:35 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:35 --> URI Class Initialized
INFO - 2018-01-18 12:15:35 --> Router Class Initialized
INFO - 2018-01-18 12:15:35 --> Output Class Initialized
INFO - 2018-01-18 12:15:35 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:35 --> Input Class Initialized
INFO - 2018-01-18 12:15:35 --> Language Class Initialized
INFO - 2018-01-18 12:15:35 --> Loader Class Initialized
INFO - 2018-01-18 12:15:35 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:35 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:35 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Controller Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:15:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:15:35 --> Final output sent to browser
DEBUG - 2018-01-18 12:15:35 --> Total execution time: 0.0508
INFO - 2018-01-18 12:15:35 --> Config Class Initialized
INFO - 2018-01-18 12:15:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:15:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:15:35 --> Utf8 Class Initialized
INFO - 2018-01-18 12:15:35 --> URI Class Initialized
INFO - 2018-01-18 12:15:35 --> Router Class Initialized
INFO - 2018-01-18 12:15:35 --> Output Class Initialized
INFO - 2018-01-18 12:15:35 --> Security Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:15:35 --> Input Class Initialized
INFO - 2018-01-18 12:15:35 --> Language Class Initialized
INFO - 2018-01-18 12:15:35 --> Loader Class Initialized
INFO - 2018-01-18 12:15:35 --> Helper loaded: url_helper
INFO - 2018-01-18 12:15:35 --> Helper loaded: form_helper
INFO - 2018-01-18 12:15:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:15:35 --> Form Validation Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Controller Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
INFO - 2018-01-18 12:15:35 --> Model Class Initialized
DEBUG - 2018-01-18 12:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:16:13 --> Config Class Initialized
INFO - 2018-01-18 12:16:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:16:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:16:13 --> Utf8 Class Initialized
INFO - 2018-01-18 12:16:13 --> URI Class Initialized
INFO - 2018-01-18 12:16:13 --> Router Class Initialized
INFO - 2018-01-18 12:16:13 --> Output Class Initialized
INFO - 2018-01-18 12:16:13 --> Security Class Initialized
DEBUG - 2018-01-18 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:16:13 --> Input Class Initialized
INFO - 2018-01-18 12:16:13 --> Language Class Initialized
INFO - 2018-01-18 12:16:13 --> Loader Class Initialized
INFO - 2018-01-18 12:16:13 --> Helper loaded: url_helper
INFO - 2018-01-18 12:16:13 --> Helper loaded: form_helper
INFO - 2018-01-18 12:16:13 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:16:13 --> Form Validation Class Initialized
INFO - 2018-01-18 12:16:13 --> Model Class Initialized
INFO - 2018-01-18 12:16:13 --> Controller Class Initialized
INFO - 2018-01-18 12:16:13 --> Model Class Initialized
INFO - 2018-01-18 12:16:13 --> Model Class Initialized
INFO - 2018-01-18 12:16:13 --> Model Class Initialized
INFO - 2018-01-18 12:16:13 --> Model Class Initialized
DEBUG - 2018-01-18 12:16:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:16:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:16:13 --> Final output sent to browser
DEBUG - 2018-01-18 12:16:13 --> Total execution time: 0.0470
INFO - 2018-01-18 12:16:14 --> Config Class Initialized
INFO - 2018-01-18 12:16:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:16:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:16:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:16:14 --> URI Class Initialized
INFO - 2018-01-18 12:16:14 --> Router Class Initialized
INFO - 2018-01-18 12:16:14 --> Output Class Initialized
INFO - 2018-01-18 12:16:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:16:14 --> Input Class Initialized
INFO - 2018-01-18 12:16:14 --> Language Class Initialized
INFO - 2018-01-18 12:16:14 --> Loader Class Initialized
INFO - 2018-01-18 12:16:14 --> Helper loaded: url_helper
INFO - 2018-01-18 12:16:14 --> Helper loaded: form_helper
INFO - 2018-01-18 12:16:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:16:14 --> Form Validation Class Initialized
INFO - 2018-01-18 12:16:14 --> Model Class Initialized
INFO - 2018-01-18 12:16:14 --> Controller Class Initialized
INFO - 2018-01-18 12:16:14 --> Model Class Initialized
INFO - 2018-01-18 12:16:14 --> Model Class Initialized
INFO - 2018-01-18 12:16:14 --> Model Class Initialized
INFO - 2018-01-18 12:16:14 --> Model Class Initialized
DEBUG - 2018-01-18 12:16:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:16:16 --> Config Class Initialized
INFO - 2018-01-18 12:16:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:16:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:16:16 --> Utf8 Class Initialized
INFO - 2018-01-18 12:16:16 --> URI Class Initialized
INFO - 2018-01-18 12:16:16 --> Router Class Initialized
INFO - 2018-01-18 12:16:16 --> Output Class Initialized
INFO - 2018-01-18 12:16:16 --> Security Class Initialized
DEBUG - 2018-01-18 12:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:16:16 --> Input Class Initialized
INFO - 2018-01-18 12:16:16 --> Language Class Initialized
INFO - 2018-01-18 12:16:16 --> Loader Class Initialized
INFO - 2018-01-18 12:16:16 --> Helper loaded: url_helper
INFO - 2018-01-18 12:16:16 --> Helper loaded: form_helper
INFO - 2018-01-18 12:16:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:16:16 --> Form Validation Class Initialized
INFO - 2018-01-18 12:16:16 --> Model Class Initialized
INFO - 2018-01-18 12:16:16 --> Controller Class Initialized
INFO - 2018-01-18 12:16:16 --> Model Class Initialized
INFO - 2018-01-18 12:16:16 --> Model Class Initialized
INFO - 2018-01-18 12:16:16 --> Model Class Initialized
INFO - 2018-01-18 12:16:16 --> Model Class Initialized
DEBUG - 2018-01-18 12:16:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:16:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:16:16 --> Final output sent to browser
DEBUG - 2018-01-18 12:16:16 --> Total execution time: 0.0455
INFO - 2018-01-18 12:17:00 --> Config Class Initialized
INFO - 2018-01-18 12:17:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:00 --> URI Class Initialized
INFO - 2018-01-18 12:17:00 --> Router Class Initialized
INFO - 2018-01-18 12:17:00 --> Output Class Initialized
INFO - 2018-01-18 12:17:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:00 --> Input Class Initialized
INFO - 2018-01-18 12:17:00 --> Language Class Initialized
INFO - 2018-01-18 12:17:00 --> Loader Class Initialized
INFO - 2018-01-18 12:17:00 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:00 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:00 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:01 --> Model Class Initialized
INFO - 2018-01-18 12:17:01 --> Controller Class Initialized
INFO - 2018-01-18 12:17:01 --> Model Class Initialized
INFO - 2018-01-18 12:17:01 --> Model Class Initialized
INFO - 2018-01-18 12:17:01 --> Model Class Initialized
INFO - 2018-01-18 12:17:01 --> Model Class Initialized
DEBUG - 2018-01-18 12:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:17:01 --> Final output sent to browser
DEBUG - 2018-01-18 12:17:01 --> Total execution time: 0.0439
INFO - 2018-01-18 12:17:03 --> Config Class Initialized
INFO - 2018-01-18 12:17:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:03 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:03 --> URI Class Initialized
INFO - 2018-01-18 12:17:03 --> Router Class Initialized
INFO - 2018-01-18 12:17:03 --> Output Class Initialized
INFO - 2018-01-18 12:17:03 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:03 --> Input Class Initialized
INFO - 2018-01-18 12:17:03 --> Language Class Initialized
INFO - 2018-01-18 12:17:03 --> Loader Class Initialized
INFO - 2018-01-18 12:17:03 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:03 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:03 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:03 --> Model Class Initialized
INFO - 2018-01-18 12:17:03 --> Controller Class Initialized
INFO - 2018-01-18 12:17:03 --> Model Class Initialized
INFO - 2018-01-18 12:17:03 --> Model Class Initialized
INFO - 2018-01-18 12:17:03 --> Model Class Initialized
INFO - 2018-01-18 12:17:03 --> Model Class Initialized
DEBUG - 2018-01-18 12:17:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:17:04 --> Config Class Initialized
INFO - 2018-01-18 12:17:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:04 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:04 --> URI Class Initialized
INFO - 2018-01-18 12:17:04 --> Router Class Initialized
INFO - 2018-01-18 12:17:04 --> Output Class Initialized
INFO - 2018-01-18 12:17:04 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:04 --> Input Class Initialized
INFO - 2018-01-18 12:17:04 --> Language Class Initialized
INFO - 2018-01-18 12:17:04 --> Loader Class Initialized
INFO - 2018-01-18 12:17:04 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:04 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:04 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:04 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:04 --> Model Class Initialized
INFO - 2018-01-18 12:17:04 --> Controller Class Initialized
INFO - 2018-01-18 12:17:04 --> Model Class Initialized
INFO - 2018-01-18 12:17:04 --> Model Class Initialized
INFO - 2018-01-18 12:17:04 --> Model Class Initialized
INFO - 2018-01-18 12:17:04 --> Model Class Initialized
DEBUG - 2018-01-18 12:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:17:14 --> Config Class Initialized
INFO - 2018-01-18 12:17:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:14 --> URI Class Initialized
INFO - 2018-01-18 12:17:14 --> Router Class Initialized
INFO - 2018-01-18 12:17:14 --> Output Class Initialized
INFO - 2018-01-18 12:17:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:14 --> Input Class Initialized
INFO - 2018-01-18 12:17:14 --> Language Class Initialized
INFO - 2018-01-18 12:17:14 --> Loader Class Initialized
INFO - 2018-01-18 12:17:14 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:14 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:14 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:14 --> Model Class Initialized
INFO - 2018-01-18 12:17:14 --> Controller Class Initialized
INFO - 2018-01-18 12:17:14 --> Model Class Initialized
INFO - 2018-01-18 12:17:14 --> Model Class Initialized
INFO - 2018-01-18 12:17:14 --> Model Class Initialized
INFO - 2018-01-18 12:17:14 --> Model Class Initialized
DEBUG - 2018-01-18 12:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:17:25 --> Config Class Initialized
INFO - 2018-01-18 12:17:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:25 --> URI Class Initialized
INFO - 2018-01-18 12:17:25 --> Router Class Initialized
INFO - 2018-01-18 12:17:25 --> Output Class Initialized
INFO - 2018-01-18 12:17:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:25 --> Input Class Initialized
INFO - 2018-01-18 12:17:25 --> Language Class Initialized
INFO - 2018-01-18 12:17:25 --> Loader Class Initialized
INFO - 2018-01-18 12:17:25 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:25 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:25 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:25 --> Model Class Initialized
INFO - 2018-01-18 12:17:25 --> Controller Class Initialized
INFO - 2018-01-18 12:17:25 --> Model Class Initialized
DEBUG - 2018-01-18 12:17:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:17:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 12:17:26 --> Config Class Initialized
INFO - 2018-01-18 12:17:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:17:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:17:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:17:26 --> URI Class Initialized
DEBUG - 2018-01-18 12:17:26 --> No URI present. Default controller set.
INFO - 2018-01-18 12:17:26 --> Router Class Initialized
INFO - 2018-01-18 12:17:26 --> Output Class Initialized
INFO - 2018-01-18 12:17:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:17:26 --> Input Class Initialized
INFO - 2018-01-18 12:17:26 --> Language Class Initialized
INFO - 2018-01-18 12:17:26 --> Loader Class Initialized
INFO - 2018-01-18 12:17:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:17:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:17:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:17:26 --> Form Validation Class Initialized
INFO - 2018-01-18 12:17:26 --> Model Class Initialized
INFO - 2018-01-18 12:17:26 --> Controller Class Initialized
INFO - 2018-01-18 12:17:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:17:26 --> Final output sent to browser
DEBUG - 2018-01-18 12:17:26 --> Total execution time: 0.0387
INFO - 2018-01-18 12:18:22 --> Config Class Initialized
INFO - 2018-01-18 12:18:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:22 --> URI Class Initialized
INFO - 2018-01-18 12:18:22 --> Router Class Initialized
INFO - 2018-01-18 12:18:22 --> Output Class Initialized
INFO - 2018-01-18 12:18:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:22 --> Input Class Initialized
INFO - 2018-01-18 12:18:22 --> Language Class Initialized
INFO - 2018-01-18 12:18:22 --> Loader Class Initialized
INFO - 2018-01-18 12:18:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:22 --> Model Class Initialized
INFO - 2018-01-18 12:18:22 --> Controller Class Initialized
INFO - 2018-01-18 12:18:22 --> Model Class Initialized
INFO - 2018-01-18 12:18:22 --> Model Class Initialized
INFO - 2018-01-18 12:18:22 --> Model Class Initialized
INFO - 2018-01-18 12:18:22 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:23 --> Config Class Initialized
INFO - 2018-01-18 12:18:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:23 --> URI Class Initialized
INFO - 2018-01-18 12:18:23 --> Router Class Initialized
INFO - 2018-01-18 12:18:23 --> Output Class Initialized
INFO - 2018-01-18 12:18:23 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:23 --> Input Class Initialized
INFO - 2018-01-18 12:18:23 --> Language Class Initialized
INFO - 2018-01-18 12:18:23 --> Loader Class Initialized
INFO - 2018-01-18 12:18:23 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:23 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:23 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:23 --> Model Class Initialized
INFO - 2018-01-18 12:18:23 --> Controller Class Initialized
INFO - 2018-01-18 12:18:23 --> Model Class Initialized
INFO - 2018-01-18 12:18:23 --> Model Class Initialized
INFO - 2018-01-18 12:18:23 --> Model Class Initialized
INFO - 2018-01-18 12:18:23 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:18:23 --> Final output sent to browser
DEBUG - 2018-01-18 12:18:23 --> Total execution time: 0.0521
INFO - 2018-01-18 12:18:23 --> Config Class Initialized
INFO - 2018-01-18 12:18:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:23 --> URI Class Initialized
INFO - 2018-01-18 12:18:23 --> Router Class Initialized
INFO - 2018-01-18 12:18:23 --> Output Class Initialized
INFO - 2018-01-18 12:18:23 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:23 --> Input Class Initialized
INFO - 2018-01-18 12:18:23 --> Language Class Initialized
ERROR - 2018-01-18 12:18:23 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:18:43 --> Config Class Initialized
INFO - 2018-01-18 12:18:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:43 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:43 --> URI Class Initialized
INFO - 2018-01-18 12:18:43 --> Router Class Initialized
INFO - 2018-01-18 12:18:43 --> Output Class Initialized
INFO - 2018-01-18 12:18:43 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:43 --> Input Class Initialized
INFO - 2018-01-18 12:18:43 --> Language Class Initialized
INFO - 2018-01-18 12:18:43 --> Loader Class Initialized
INFO - 2018-01-18 12:18:43 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:43 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:43 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:43 --> Model Class Initialized
INFO - 2018-01-18 12:18:43 --> Controller Class Initialized
INFO - 2018-01-18 12:18:43 --> Model Class Initialized
INFO - 2018-01-18 12:18:43 --> Model Class Initialized
INFO - 2018-01-18 12:18:43 --> Model Class Initialized
INFO - 2018-01-18 12:18:43 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:18:43 --> Final output sent to browser
DEBUG - 2018-01-18 12:18:43 --> Total execution time: 0.0541
INFO - 2018-01-18 12:18:44 --> Config Class Initialized
INFO - 2018-01-18 12:18:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:44 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:44 --> URI Class Initialized
INFO - 2018-01-18 12:18:44 --> Router Class Initialized
INFO - 2018-01-18 12:18:44 --> Output Class Initialized
INFO - 2018-01-18 12:18:44 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:44 --> Input Class Initialized
INFO - 2018-01-18 12:18:44 --> Language Class Initialized
INFO - 2018-01-18 12:18:44 --> Loader Class Initialized
INFO - 2018-01-18 12:18:44 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:44 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:44 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:44 --> Model Class Initialized
INFO - 2018-01-18 12:18:44 --> Controller Class Initialized
INFO - 2018-01-18 12:18:44 --> Model Class Initialized
INFO - 2018-01-18 12:18:44 --> Model Class Initialized
INFO - 2018-01-18 12:18:44 --> Model Class Initialized
INFO - 2018-01-18 12:18:44 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:51 --> Config Class Initialized
INFO - 2018-01-18 12:18:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:51 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:51 --> URI Class Initialized
INFO - 2018-01-18 12:18:51 --> Router Class Initialized
INFO - 2018-01-18 12:18:51 --> Output Class Initialized
INFO - 2018-01-18 12:18:51 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:51 --> Input Class Initialized
INFO - 2018-01-18 12:18:51 --> Language Class Initialized
INFO - 2018-01-18 12:18:51 --> Loader Class Initialized
INFO - 2018-01-18 12:18:51 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:51 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:51 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:51 --> Model Class Initialized
INFO - 2018-01-18 12:18:51 --> Controller Class Initialized
INFO - 2018-01-18 12:18:51 --> Model Class Initialized
INFO - 2018-01-18 12:18:51 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:18:51 --> Final output sent to browser
DEBUG - 2018-01-18 12:18:51 --> Total execution time: 0.0404
INFO - 2018-01-18 12:18:52 --> Config Class Initialized
INFO - 2018-01-18 12:18:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:52 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:52 --> URI Class Initialized
INFO - 2018-01-18 12:18:52 --> Router Class Initialized
INFO - 2018-01-18 12:18:52 --> Output Class Initialized
INFO - 2018-01-18 12:18:52 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:52 --> Input Class Initialized
INFO - 2018-01-18 12:18:52 --> Language Class Initialized
INFO - 2018-01-18 12:18:52 --> Loader Class Initialized
INFO - 2018-01-18 12:18:52 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:52 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:52 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:52 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:52 --> Model Class Initialized
INFO - 2018-01-18 12:18:52 --> Controller Class Initialized
INFO - 2018-01-18 12:18:52 --> Model Class Initialized
INFO - 2018-01-18 12:18:52 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:53 --> Config Class Initialized
INFO - 2018-01-18 12:18:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:53 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:53 --> URI Class Initialized
INFO - 2018-01-18 12:18:53 --> Router Class Initialized
INFO - 2018-01-18 12:18:53 --> Output Class Initialized
INFO - 2018-01-18 12:18:53 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:53 --> Input Class Initialized
INFO - 2018-01-18 12:18:53 --> Language Class Initialized
INFO - 2018-01-18 12:18:53 --> Loader Class Initialized
INFO - 2018-01-18 12:18:53 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:53 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:53 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:53 --> Model Class Initialized
INFO - 2018-01-18 12:18:53 --> Controller Class Initialized
INFO - 2018-01-18 12:18:53 --> Model Class Initialized
INFO - 2018-01-18 12:18:53 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:18:53 --> Final output sent to browser
DEBUG - 2018-01-18 12:18:53 --> Total execution time: 0.0382
INFO - 2018-01-18 12:18:54 --> Config Class Initialized
INFO - 2018-01-18 12:18:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:54 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:54 --> URI Class Initialized
INFO - 2018-01-18 12:18:54 --> Router Class Initialized
INFO - 2018-01-18 12:18:54 --> Output Class Initialized
INFO - 2018-01-18 12:18:54 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:54 --> Input Class Initialized
INFO - 2018-01-18 12:18:54 --> Language Class Initialized
INFO - 2018-01-18 12:18:54 --> Loader Class Initialized
INFO - 2018-01-18 12:18:54 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:54 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:54 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:54 --> Model Class Initialized
INFO - 2018-01-18 12:18:54 --> Controller Class Initialized
INFO - 2018-01-18 12:18:54 --> Model Class Initialized
INFO - 2018-01-18 12:18:54 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:58 --> Config Class Initialized
INFO - 2018-01-18 12:18:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:18:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:18:58 --> Utf8 Class Initialized
INFO - 2018-01-18 12:18:58 --> URI Class Initialized
INFO - 2018-01-18 12:18:58 --> Router Class Initialized
INFO - 2018-01-18 12:18:58 --> Output Class Initialized
INFO - 2018-01-18 12:18:58 --> Security Class Initialized
DEBUG - 2018-01-18 12:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:18:58 --> Input Class Initialized
INFO - 2018-01-18 12:18:58 --> Language Class Initialized
INFO - 2018-01-18 12:18:58 --> Loader Class Initialized
INFO - 2018-01-18 12:18:58 --> Helper loaded: url_helper
INFO - 2018-01-18 12:18:58 --> Helper loaded: form_helper
INFO - 2018-01-18 12:18:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:18:58 --> Form Validation Class Initialized
INFO - 2018-01-18 12:18:58 --> Model Class Initialized
INFO - 2018-01-18 12:18:58 --> Controller Class Initialized
INFO - 2018-01-18 12:18:58 --> Model Class Initialized
INFO - 2018-01-18 12:18:58 --> Model Class Initialized
DEBUG - 2018-01-18 12:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:18:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:18:58 --> Final output sent to browser
DEBUG - 2018-01-18 12:18:58 --> Total execution time: 0.0383
INFO - 2018-01-18 12:19:39 --> Config Class Initialized
INFO - 2018-01-18 12:19:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:19:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:19:39 --> Utf8 Class Initialized
INFO - 2018-01-18 12:19:39 --> URI Class Initialized
INFO - 2018-01-18 12:19:39 --> Router Class Initialized
INFO - 2018-01-18 12:19:39 --> Output Class Initialized
INFO - 2018-01-18 12:19:39 --> Security Class Initialized
DEBUG - 2018-01-18 12:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:19:39 --> Input Class Initialized
INFO - 2018-01-18 12:19:39 --> Language Class Initialized
INFO - 2018-01-18 12:19:39 --> Loader Class Initialized
INFO - 2018-01-18 12:19:39 --> Helper loaded: url_helper
INFO - 2018-01-18 12:19:39 --> Helper loaded: form_helper
INFO - 2018-01-18 12:19:39 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:19:39 --> Form Validation Class Initialized
INFO - 2018-01-18 12:19:39 --> Model Class Initialized
INFO - 2018-01-18 12:19:39 --> Controller Class Initialized
INFO - 2018-01-18 12:19:39 --> Model Class Initialized
INFO - 2018-01-18 12:19:39 --> Model Class Initialized
DEBUG - 2018-01-18 12:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:19:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:19:41 --> Final output sent to browser
DEBUG - 2018-01-18 12:19:41 --> Total execution time: 1.8282
INFO - 2018-01-18 12:19:46 --> Config Class Initialized
INFO - 2018-01-18 12:19:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:19:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:19:46 --> Utf8 Class Initialized
INFO - 2018-01-18 12:19:46 --> URI Class Initialized
INFO - 2018-01-18 12:19:46 --> Router Class Initialized
INFO - 2018-01-18 12:19:46 --> Output Class Initialized
INFO - 2018-01-18 12:19:46 --> Security Class Initialized
DEBUG - 2018-01-18 12:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:19:46 --> Input Class Initialized
INFO - 2018-01-18 12:19:46 --> Language Class Initialized
INFO - 2018-01-18 12:19:46 --> Loader Class Initialized
INFO - 2018-01-18 12:19:46 --> Helper loaded: url_helper
INFO - 2018-01-18 12:19:46 --> Helper loaded: form_helper
INFO - 2018-01-18 12:19:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:19:46 --> Form Validation Class Initialized
INFO - 2018-01-18 12:19:46 --> Model Class Initialized
INFO - 2018-01-18 12:19:46 --> Controller Class Initialized
INFO - 2018-01-18 12:19:46 --> Model Class Initialized
INFO - 2018-01-18 12:19:46 --> Model Class Initialized
INFO - 2018-01-18 12:19:46 --> Model Class Initialized
INFO - 2018-01-18 12:19:46 --> Model Class Initialized
DEBUG - 2018-01-18 12:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:19:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:19:46 --> Final output sent to browser
DEBUG - 2018-01-18 12:19:46 --> Total execution time: 0.0466
INFO - 2018-01-18 12:19:48 --> Config Class Initialized
INFO - 2018-01-18 12:19:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:19:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:19:48 --> Utf8 Class Initialized
INFO - 2018-01-18 12:19:48 --> URI Class Initialized
INFO - 2018-01-18 12:19:48 --> Router Class Initialized
INFO - 2018-01-18 12:19:48 --> Output Class Initialized
INFO - 2018-01-18 12:19:48 --> Security Class Initialized
DEBUG - 2018-01-18 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:19:48 --> Input Class Initialized
INFO - 2018-01-18 12:19:48 --> Language Class Initialized
INFO - 2018-01-18 12:19:48 --> Loader Class Initialized
INFO - 2018-01-18 12:19:48 --> Helper loaded: url_helper
INFO - 2018-01-18 12:19:48 --> Helper loaded: form_helper
INFO - 2018-01-18 12:19:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:19:48 --> Form Validation Class Initialized
INFO - 2018-01-18 12:19:48 --> Model Class Initialized
INFO - 2018-01-18 12:19:48 --> Controller Class Initialized
INFO - 2018-01-18 12:19:48 --> Model Class Initialized
INFO - 2018-01-18 12:19:48 --> Model Class Initialized
DEBUG - 2018-01-18 12:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:19:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:19:48 --> Final output sent to browser
DEBUG - 2018-01-18 12:19:48 --> Total execution time: 0.0378
INFO - 2018-01-18 12:19:49 --> Config Class Initialized
INFO - 2018-01-18 12:19:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:19:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:19:49 --> Utf8 Class Initialized
INFO - 2018-01-18 12:19:49 --> URI Class Initialized
INFO - 2018-01-18 12:19:49 --> Router Class Initialized
INFO - 2018-01-18 12:19:49 --> Output Class Initialized
INFO - 2018-01-18 12:19:49 --> Security Class Initialized
DEBUG - 2018-01-18 12:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:19:49 --> Input Class Initialized
INFO - 2018-01-18 12:19:49 --> Language Class Initialized
INFO - 2018-01-18 12:19:49 --> Loader Class Initialized
INFO - 2018-01-18 12:19:49 --> Helper loaded: url_helper
INFO - 2018-01-18 12:19:49 --> Helper loaded: form_helper
INFO - 2018-01-18 12:19:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:19:49 --> Form Validation Class Initialized
INFO - 2018-01-18 12:19:49 --> Model Class Initialized
INFO - 2018-01-18 12:19:49 --> Controller Class Initialized
INFO - 2018-01-18 12:19:49 --> Model Class Initialized
INFO - 2018-01-18 12:19:49 --> Model Class Initialized
DEBUG - 2018-01-18 12:19:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:19:55 --> Config Class Initialized
INFO - 2018-01-18 12:19:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:19:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:19:55 --> Utf8 Class Initialized
INFO - 2018-01-18 12:19:55 --> URI Class Initialized
INFO - 2018-01-18 12:19:55 --> Router Class Initialized
INFO - 2018-01-18 12:19:55 --> Output Class Initialized
INFO - 2018-01-18 12:19:55 --> Security Class Initialized
DEBUG - 2018-01-18 12:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:19:55 --> Input Class Initialized
INFO - 2018-01-18 12:19:55 --> Language Class Initialized
INFO - 2018-01-18 12:19:55 --> Loader Class Initialized
INFO - 2018-01-18 12:19:55 --> Helper loaded: url_helper
INFO - 2018-01-18 12:19:55 --> Helper loaded: form_helper
INFO - 2018-01-18 12:19:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:19:55 --> Form Validation Class Initialized
INFO - 2018-01-18 12:19:55 --> Model Class Initialized
INFO - 2018-01-18 12:19:55 --> Controller Class Initialized
INFO - 2018-01-18 12:19:55 --> Model Class Initialized
INFO - 2018-01-18 12:19:55 --> Model Class Initialized
INFO - 2018-01-18 12:19:55 --> Model Class Initialized
INFO - 2018-01-18 12:19:55 --> Model Class Initialized
DEBUG - 2018-01-18 12:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:19:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:19:55 --> Final output sent to browser
DEBUG - 2018-01-18 12:19:55 --> Total execution time: 0.0470
INFO - 2018-01-18 12:20:02 --> Config Class Initialized
INFO - 2018-01-18 12:20:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:02 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:02 --> URI Class Initialized
INFO - 2018-01-18 12:20:02 --> Router Class Initialized
INFO - 2018-01-18 12:20:02 --> Output Class Initialized
INFO - 2018-01-18 12:20:02 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:02 --> Input Class Initialized
INFO - 2018-01-18 12:20:02 --> Language Class Initialized
INFO - 2018-01-18 12:20:02 --> Loader Class Initialized
INFO - 2018-01-18 12:20:02 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:02 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:02 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:02 --> Model Class Initialized
INFO - 2018-01-18 12:20:02 --> Controller Class Initialized
INFO - 2018-01-18 12:20:02 --> Model Class Initialized
INFO - 2018-01-18 12:20:02 --> Model Class Initialized
INFO - 2018-01-18 12:20:02 --> Model Class Initialized
INFO - 2018-01-18 12:20:02 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:02 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:02 --> Total execution time: 0.0481
INFO - 2018-01-18 12:20:03 --> Config Class Initialized
INFO - 2018-01-18 12:20:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:03 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:03 --> URI Class Initialized
INFO - 2018-01-18 12:20:03 --> Router Class Initialized
INFO - 2018-01-18 12:20:03 --> Output Class Initialized
INFO - 2018-01-18 12:20:03 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:03 --> Input Class Initialized
INFO - 2018-01-18 12:20:03 --> Language Class Initialized
INFO - 2018-01-18 12:20:03 --> Loader Class Initialized
INFO - 2018-01-18 12:20:03 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:03 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:03 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:03 --> Model Class Initialized
INFO - 2018-01-18 12:20:03 --> Controller Class Initialized
INFO - 2018-01-18 12:20:03 --> Model Class Initialized
INFO - 2018-01-18 12:20:03 --> Model Class Initialized
INFO - 2018-01-18 12:20:03 --> Model Class Initialized
INFO - 2018-01-18 12:20:03 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:09 --> Config Class Initialized
INFO - 2018-01-18 12:20:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:09 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:09 --> URI Class Initialized
INFO - 2018-01-18 12:20:09 --> Router Class Initialized
INFO - 2018-01-18 12:20:09 --> Output Class Initialized
INFO - 2018-01-18 12:20:09 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:09 --> Input Class Initialized
INFO - 2018-01-18 12:20:09 --> Language Class Initialized
INFO - 2018-01-18 12:20:09 --> Loader Class Initialized
INFO - 2018-01-18 12:20:09 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:09 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:09 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
INFO - 2018-01-18 12:20:09 --> Controller Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:09 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:09 --> Total execution time: 0.0513
INFO - 2018-01-18 12:20:09 --> Config Class Initialized
INFO - 2018-01-18 12:20:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:09 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:09 --> URI Class Initialized
INFO - 2018-01-18 12:20:09 --> Router Class Initialized
INFO - 2018-01-18 12:20:09 --> Output Class Initialized
INFO - 2018-01-18 12:20:09 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:09 --> Input Class Initialized
INFO - 2018-01-18 12:20:09 --> Language Class Initialized
INFO - 2018-01-18 12:20:09 --> Loader Class Initialized
INFO - 2018-01-18 12:20:09 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:09 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:09 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
INFO - 2018-01-18 12:20:09 --> Controller Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
INFO - 2018-01-18 12:20:09 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:12 --> Config Class Initialized
INFO - 2018-01-18 12:20:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:12 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:12 --> URI Class Initialized
INFO - 2018-01-18 12:20:12 --> Router Class Initialized
INFO - 2018-01-18 12:20:12 --> Output Class Initialized
INFO - 2018-01-18 12:20:12 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:12 --> Input Class Initialized
INFO - 2018-01-18 12:20:12 --> Language Class Initialized
INFO - 2018-01-18 12:20:12 --> Loader Class Initialized
INFO - 2018-01-18 12:20:12 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:12 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:12 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:12 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:12 --> Model Class Initialized
INFO - 2018-01-18 12:20:12 --> Controller Class Initialized
INFO - 2018-01-18 12:20:12 --> Model Class Initialized
INFO - 2018-01-18 12:20:12 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:12 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:12 --> Total execution time: 0.0419
INFO - 2018-01-18 12:20:19 --> Config Class Initialized
INFO - 2018-01-18 12:20:19 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:19 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:19 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:19 --> URI Class Initialized
INFO - 2018-01-18 12:20:19 --> Router Class Initialized
INFO - 2018-01-18 12:20:19 --> Output Class Initialized
INFO - 2018-01-18 12:20:19 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:19 --> Input Class Initialized
INFO - 2018-01-18 12:20:19 --> Language Class Initialized
INFO - 2018-01-18 12:20:19 --> Loader Class Initialized
INFO - 2018-01-18 12:20:19 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:19 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:19 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:19 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:19 --> Model Class Initialized
INFO - 2018-01-18 12:20:19 --> Controller Class Initialized
INFO - 2018-01-18 12:20:19 --> Model Class Initialized
INFO - 2018-01-18 12:20:19 --> Model Class Initialized
INFO - 2018-01-18 12:20:19 --> Model Class Initialized
INFO - 2018-01-18 12:20:19 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:22 --> Config Class Initialized
INFO - 2018-01-18 12:20:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:22 --> URI Class Initialized
INFO - 2018-01-18 12:20:22 --> Router Class Initialized
INFO - 2018-01-18 12:20:22 --> Output Class Initialized
INFO - 2018-01-18 12:20:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:22 --> Input Class Initialized
INFO - 2018-01-18 12:20:22 --> Language Class Initialized
INFO - 2018-01-18 12:20:22 --> Loader Class Initialized
INFO - 2018-01-18 12:20:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:22 --> Model Class Initialized
INFO - 2018-01-18 12:20:22 --> Controller Class Initialized
INFO - 2018-01-18 12:20:22 --> Model Class Initialized
INFO - 2018-01-18 12:20:22 --> Model Class Initialized
INFO - 2018-01-18 12:20:22 --> Model Class Initialized
INFO - 2018-01-18 12:20:22 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:32 --> Config Class Initialized
INFO - 2018-01-18 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:32 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:32 --> URI Class Initialized
INFO - 2018-01-18 12:20:32 --> Router Class Initialized
INFO - 2018-01-18 12:20:32 --> Output Class Initialized
INFO - 2018-01-18 12:20:32 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:32 --> Input Class Initialized
INFO - 2018-01-18 12:20:32 --> Language Class Initialized
INFO - 2018-01-18 12:20:32 --> Loader Class Initialized
INFO - 2018-01-18 12:20:32 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:32 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:32 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:32 --> Model Class Initialized
INFO - 2018-01-18 12:20:32 --> Controller Class Initialized
INFO - 2018-01-18 12:20:32 --> Model Class Initialized
INFO - 2018-01-18 12:20:32 --> Model Class Initialized
INFO - 2018-01-18 12:20:32 --> Model Class Initialized
INFO - 2018-01-18 12:20:32 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:36 --> Config Class Initialized
INFO - 2018-01-18 12:20:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:36 --> URI Class Initialized
INFO - 2018-01-18 12:20:36 --> Router Class Initialized
INFO - 2018-01-18 12:20:36 --> Output Class Initialized
INFO - 2018-01-18 12:20:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:36 --> Input Class Initialized
INFO - 2018-01-18 12:20:36 --> Language Class Initialized
INFO - 2018-01-18 12:20:36 --> Loader Class Initialized
INFO - 2018-01-18 12:20:36 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:36 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:36 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Controller Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:36 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:36 --> Total execution time: 0.0448
INFO - 2018-01-18 12:20:36 --> Config Class Initialized
INFO - 2018-01-18 12:20:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:36 --> URI Class Initialized
INFO - 2018-01-18 12:20:36 --> Router Class Initialized
INFO - 2018-01-18 12:20:36 --> Output Class Initialized
INFO - 2018-01-18 12:20:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:36 --> Input Class Initialized
INFO - 2018-01-18 12:20:36 --> Language Class Initialized
INFO - 2018-01-18 12:20:36 --> Loader Class Initialized
INFO - 2018-01-18 12:20:36 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:36 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:36 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Controller Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
INFO - 2018-01-18 12:20:36 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:56 --> Config Class Initialized
INFO - 2018-01-18 12:20:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:56 --> URI Class Initialized
INFO - 2018-01-18 12:20:56 --> Router Class Initialized
INFO - 2018-01-18 12:20:56 --> Output Class Initialized
INFO - 2018-01-18 12:20:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:56 --> Input Class Initialized
INFO - 2018-01-18 12:20:56 --> Language Class Initialized
INFO - 2018-01-18 12:20:56 --> Loader Class Initialized
INFO - 2018-01-18 12:20:56 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:56 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:56 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:56 --> Model Class Initialized
INFO - 2018-01-18 12:20:56 --> Controller Class Initialized
INFO - 2018-01-18 12:20:56 --> Model Class Initialized
INFO - 2018-01-18 12:20:56 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:56 --> Config Class Initialized
INFO - 2018-01-18 12:20:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:20:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:20:56 --> Utf8 Class Initialized
INFO - 2018-01-18 12:20:56 --> URI Class Initialized
INFO - 2018-01-18 12:20:56 --> Router Class Initialized
INFO - 2018-01-18 12:20:56 --> Output Class Initialized
INFO - 2018-01-18 12:20:56 --> Security Class Initialized
DEBUG - 2018-01-18 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:20:56 --> Input Class Initialized
INFO - 2018-01-18 12:20:56 --> Language Class Initialized
INFO - 2018-01-18 12:20:56 --> Loader Class Initialized
INFO - 2018-01-18 12:20:56 --> Helper loaded: url_helper
INFO - 2018-01-18 12:20:56 --> Helper loaded: form_helper
INFO - 2018-01-18 12:20:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:20:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:57 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:57 --> Total execution time: 1.1633
INFO - 2018-01-18 12:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:20:57 --> Form Validation Class Initialized
INFO - 2018-01-18 12:20:57 --> Model Class Initialized
INFO - 2018-01-18 12:20:57 --> Controller Class Initialized
INFO - 2018-01-18 12:20:57 --> Model Class Initialized
INFO - 2018-01-18 12:20:57 --> Model Class Initialized
DEBUG - 2018-01-18 12:20:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:20:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:20:57 --> Final output sent to browser
DEBUG - 2018-01-18 12:20:57 --> Total execution time: 1.0272
INFO - 2018-01-18 12:21:05 --> Config Class Initialized
INFO - 2018-01-18 12:21:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:05 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:05 --> URI Class Initialized
INFO - 2018-01-18 12:21:05 --> Router Class Initialized
INFO - 2018-01-18 12:21:05 --> Output Class Initialized
INFO - 2018-01-18 12:21:05 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:05 --> Input Class Initialized
INFO - 2018-01-18 12:21:05 --> Language Class Initialized
INFO - 2018-01-18 12:21:05 --> Loader Class Initialized
INFO - 2018-01-18 12:21:05 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:05 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:05 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
INFO - 2018-01-18 12:21:05 --> Controller Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:05 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:05 --> Total execution time: 0.0442
INFO - 2018-01-18 12:21:05 --> Config Class Initialized
INFO - 2018-01-18 12:21:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:05 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:05 --> URI Class Initialized
INFO - 2018-01-18 12:21:05 --> Router Class Initialized
INFO - 2018-01-18 12:21:05 --> Output Class Initialized
INFO - 2018-01-18 12:21:05 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:05 --> Input Class Initialized
INFO - 2018-01-18 12:21:05 --> Language Class Initialized
INFO - 2018-01-18 12:21:05 --> Loader Class Initialized
INFO - 2018-01-18 12:21:05 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:05 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:05 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
INFO - 2018-01-18 12:21:05 --> Controller Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
INFO - 2018-01-18 12:21:05 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:20 --> Config Class Initialized
INFO - 2018-01-18 12:21:20 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:20 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:20 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:20 --> URI Class Initialized
INFO - 2018-01-18 12:21:20 --> Router Class Initialized
INFO - 2018-01-18 12:21:20 --> Output Class Initialized
INFO - 2018-01-18 12:21:20 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:20 --> Input Class Initialized
INFO - 2018-01-18 12:21:20 --> Language Class Initialized
INFO - 2018-01-18 12:21:20 --> Loader Class Initialized
INFO - 2018-01-18 12:21:20 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:20 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:20 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:20 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:20 --> Model Class Initialized
INFO - 2018-01-18 12:21:20 --> Controller Class Initialized
INFO - 2018-01-18 12:21:20 --> Model Class Initialized
INFO - 2018-01-18 12:21:20 --> Model Class Initialized
INFO - 2018-01-18 12:21:20 --> Model Class Initialized
INFO - 2018-01-18 12:21:20 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:20 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:20 --> Total execution time: 0.0466
INFO - 2018-01-18 12:21:23 --> Config Class Initialized
INFO - 2018-01-18 12:21:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:23 --> URI Class Initialized
INFO - 2018-01-18 12:21:23 --> Router Class Initialized
INFO - 2018-01-18 12:21:23 --> Output Class Initialized
INFO - 2018-01-18 12:21:23 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:23 --> Input Class Initialized
INFO - 2018-01-18 12:21:23 --> Language Class Initialized
INFO - 2018-01-18 12:21:23 --> Loader Class Initialized
INFO - 2018-01-18 12:21:23 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:23 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:23 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
INFO - 2018-01-18 12:21:23 --> Controller Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:23 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:23 --> Total execution time: 0.0386
INFO - 2018-01-18 12:21:23 --> Config Class Initialized
INFO - 2018-01-18 12:21:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:23 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:23 --> URI Class Initialized
INFO - 2018-01-18 12:21:23 --> Router Class Initialized
INFO - 2018-01-18 12:21:23 --> Output Class Initialized
INFO - 2018-01-18 12:21:23 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:23 --> Input Class Initialized
INFO - 2018-01-18 12:21:23 --> Language Class Initialized
INFO - 2018-01-18 12:21:23 --> Loader Class Initialized
INFO - 2018-01-18 12:21:23 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:23 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:23 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
INFO - 2018-01-18 12:21:23 --> Controller Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
INFO - 2018-01-18 12:21:23 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:25 --> Config Class Initialized
INFO - 2018-01-18 12:21:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:25 --> URI Class Initialized
INFO - 2018-01-18 12:21:25 --> Router Class Initialized
INFO - 2018-01-18 12:21:25 --> Output Class Initialized
INFO - 2018-01-18 12:21:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:25 --> Input Class Initialized
INFO - 2018-01-18 12:21:25 --> Language Class Initialized
INFO - 2018-01-18 12:21:25 --> Loader Class Initialized
INFO - 2018-01-18 12:21:25 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:25 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:25 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:25 --> Model Class Initialized
INFO - 2018-01-18 12:21:25 --> Controller Class Initialized
INFO - 2018-01-18 12:21:25 --> Model Class Initialized
INFO - 2018-01-18 12:21:25 --> Model Class Initialized
INFO - 2018-01-18 12:21:25 --> Model Class Initialized
INFO - 2018-01-18 12:21:25 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:25 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:25 --> Total execution time: 0.0572
INFO - 2018-01-18 12:21:28 --> Config Class Initialized
INFO - 2018-01-18 12:21:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:28 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:28 --> URI Class Initialized
INFO - 2018-01-18 12:21:28 --> Router Class Initialized
INFO - 2018-01-18 12:21:28 --> Output Class Initialized
INFO - 2018-01-18 12:21:28 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:28 --> Input Class Initialized
INFO - 2018-01-18 12:21:28 --> Language Class Initialized
INFO - 2018-01-18 12:21:28 --> Loader Class Initialized
INFO - 2018-01-18 12:21:28 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:28 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:28 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
INFO - 2018-01-18 12:21:28 --> Controller Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:28 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:28 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:28 --> Total execution time: 0.0495
INFO - 2018-01-18 12:21:28 --> Config Class Initialized
INFO - 2018-01-18 12:21:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:28 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:28 --> URI Class Initialized
INFO - 2018-01-18 12:21:28 --> Router Class Initialized
INFO - 2018-01-18 12:21:28 --> Output Class Initialized
INFO - 2018-01-18 12:21:28 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:28 --> Input Class Initialized
INFO - 2018-01-18 12:21:28 --> Language Class Initialized
INFO - 2018-01-18 12:21:28 --> Loader Class Initialized
INFO - 2018-01-18 12:21:28 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:28 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:28 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
INFO - 2018-01-18 12:21:28 --> Controller Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
INFO - 2018-01-18 12:21:28 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:30 --> Config Class Initialized
INFO - 2018-01-18 12:21:30 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:30 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:30 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:30 --> URI Class Initialized
INFO - 2018-01-18 12:21:30 --> Router Class Initialized
INFO - 2018-01-18 12:21:30 --> Output Class Initialized
INFO - 2018-01-18 12:21:30 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:30 --> Input Class Initialized
INFO - 2018-01-18 12:21:30 --> Language Class Initialized
INFO - 2018-01-18 12:21:30 --> Loader Class Initialized
INFO - 2018-01-18 12:21:30 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:30 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:30 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:30 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:30 --> Model Class Initialized
INFO - 2018-01-18 12:21:30 --> Controller Class Initialized
INFO - 2018-01-18 12:21:30 --> Model Class Initialized
INFO - 2018-01-18 12:21:30 --> Model Class Initialized
INFO - 2018-01-18 12:21:30 --> Model Class Initialized
INFO - 2018-01-18 12:21:30 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:30 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:30 --> Total execution time: 0.0550
INFO - 2018-01-18 12:21:35 --> Config Class Initialized
INFO - 2018-01-18 12:21:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:35 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:35 --> URI Class Initialized
INFO - 2018-01-18 12:21:35 --> Router Class Initialized
INFO - 2018-01-18 12:21:35 --> Output Class Initialized
INFO - 2018-01-18 12:21:35 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:35 --> Input Class Initialized
INFO - 2018-01-18 12:21:35 --> Language Class Initialized
INFO - 2018-01-18 12:21:35 --> Loader Class Initialized
INFO - 2018-01-18 12:21:35 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:35 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:35 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:35 --> Model Class Initialized
INFO - 2018-01-18 12:21:35 --> Controller Class Initialized
INFO - 2018-01-18 12:21:35 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:35 --> Config Class Initialized
INFO - 2018-01-18 12:21:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:35 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:35 --> URI Class Initialized
INFO - 2018-01-18 12:21:35 --> Router Class Initialized
INFO - 2018-01-18 12:21:35 --> Output Class Initialized
INFO - 2018-01-18 12:21:35 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:35 --> Input Class Initialized
INFO - 2018-01-18 12:21:35 --> Language Class Initialized
INFO - 2018-01-18 12:21:35 --> Loader Class Initialized
INFO - 2018-01-18 12:21:35 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:35 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:35 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:35 --> Model Class Initialized
INFO - 2018-01-18 12:21:35 --> Controller Class Initialized
INFO - 2018-01-18 12:21:35 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:35 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:35 --> Total execution time: 0.0419
INFO - 2018-01-18 12:21:46 --> Config Class Initialized
INFO - 2018-01-18 12:21:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:46 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:46 --> URI Class Initialized
INFO - 2018-01-18 12:21:46 --> Router Class Initialized
INFO - 2018-01-18 12:21:46 --> Output Class Initialized
INFO - 2018-01-18 12:21:46 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:46 --> Input Class Initialized
INFO - 2018-01-18 12:21:46 --> Language Class Initialized
INFO - 2018-01-18 12:21:46 --> Loader Class Initialized
INFO - 2018-01-18 12:21:46 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:46 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:46 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:46 --> Model Class Initialized
INFO - 2018-01-18 12:21:46 --> Controller Class Initialized
INFO - 2018-01-18 12:21:46 --> Model Class Initialized
INFO - 2018-01-18 12:21:46 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:21:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:21:46 --> Final output sent to browser
DEBUG - 2018-01-18 12:21:46 --> Total execution time: 0.0393
INFO - 2018-01-18 12:21:47 --> Config Class Initialized
INFO - 2018-01-18 12:21:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:21:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:21:47 --> Utf8 Class Initialized
INFO - 2018-01-18 12:21:47 --> URI Class Initialized
INFO - 2018-01-18 12:21:47 --> Router Class Initialized
INFO - 2018-01-18 12:21:47 --> Output Class Initialized
INFO - 2018-01-18 12:21:47 --> Security Class Initialized
DEBUG - 2018-01-18 12:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:21:47 --> Input Class Initialized
INFO - 2018-01-18 12:21:47 --> Language Class Initialized
INFO - 2018-01-18 12:21:47 --> Loader Class Initialized
INFO - 2018-01-18 12:21:47 --> Helper loaded: url_helper
INFO - 2018-01-18 12:21:47 --> Helper loaded: form_helper
INFO - 2018-01-18 12:21:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:21:47 --> Form Validation Class Initialized
INFO - 2018-01-18 12:21:47 --> Model Class Initialized
INFO - 2018-01-18 12:21:47 --> Controller Class Initialized
INFO - 2018-01-18 12:21:47 --> Model Class Initialized
INFO - 2018-01-18 12:21:47 --> Model Class Initialized
DEBUG - 2018-01-18 12:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:01 --> Config Class Initialized
INFO - 2018-01-18 12:22:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:01 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:01 --> URI Class Initialized
INFO - 2018-01-18 12:22:01 --> Router Class Initialized
INFO - 2018-01-18 12:22:01 --> Output Class Initialized
INFO - 2018-01-18 12:22:01 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:01 --> Input Class Initialized
INFO - 2018-01-18 12:22:01 --> Language Class Initialized
INFO - 2018-01-18 12:22:01 --> Loader Class Initialized
INFO - 2018-01-18 12:22:01 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:01 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:01 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
INFO - 2018-01-18 12:22:01 --> Controller Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:01 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:01 --> Total execution time: 0.0413
INFO - 2018-01-18 12:22:01 --> Config Class Initialized
INFO - 2018-01-18 12:22:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:01 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:01 --> URI Class Initialized
INFO - 2018-01-18 12:22:01 --> Router Class Initialized
INFO - 2018-01-18 12:22:01 --> Output Class Initialized
INFO - 2018-01-18 12:22:01 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:01 --> Input Class Initialized
INFO - 2018-01-18 12:22:01 --> Language Class Initialized
INFO - 2018-01-18 12:22:01 --> Loader Class Initialized
INFO - 2018-01-18 12:22:01 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:01 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:01 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
INFO - 2018-01-18 12:22:01 --> Controller Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
INFO - 2018-01-18 12:22:01 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:06 --> Config Class Initialized
INFO - 2018-01-18 12:22:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:06 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:06 --> URI Class Initialized
INFO - 2018-01-18 12:22:06 --> Router Class Initialized
INFO - 2018-01-18 12:22:06 --> Output Class Initialized
INFO - 2018-01-18 12:22:06 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:06 --> Input Class Initialized
INFO - 2018-01-18 12:22:06 --> Language Class Initialized
INFO - 2018-01-18 12:22:06 --> Loader Class Initialized
INFO - 2018-01-18 12:22:06 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:07 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:07 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:07 --> Model Class Initialized
INFO - 2018-01-18 12:22:07 --> Controller Class Initialized
INFO - 2018-01-18 12:22:07 --> Model Class Initialized
INFO - 2018-01-18 12:22:07 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:07 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:07 --> Total execution time: 0.0448
INFO - 2018-01-18 12:22:09 --> Config Class Initialized
INFO - 2018-01-18 12:22:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:09 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:09 --> URI Class Initialized
INFO - 2018-01-18 12:22:09 --> Router Class Initialized
INFO - 2018-01-18 12:22:09 --> Output Class Initialized
INFO - 2018-01-18 12:22:09 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:09 --> Input Class Initialized
INFO - 2018-01-18 12:22:09 --> Language Class Initialized
INFO - 2018-01-18 12:22:09 --> Loader Class Initialized
INFO - 2018-01-18 12:22:09 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:09 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:09 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:09 --> Model Class Initialized
INFO - 2018-01-18 12:22:09 --> Controller Class Initialized
INFO - 2018-01-18 12:22:09 --> Model Class Initialized
INFO - 2018-01-18 12:22:09 --> Model Class Initialized
INFO - 2018-01-18 12:22:09 --> Model Class Initialized
INFO - 2018-01-18 12:22:09 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:09 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:09 --> Total execution time: 0.0487
INFO - 2018-01-18 12:22:10 --> Config Class Initialized
INFO - 2018-01-18 12:22:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:10 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:10 --> URI Class Initialized
INFO - 2018-01-18 12:22:10 --> Router Class Initialized
INFO - 2018-01-18 12:22:10 --> Output Class Initialized
INFO - 2018-01-18 12:22:10 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:10 --> Input Class Initialized
INFO - 2018-01-18 12:22:10 --> Language Class Initialized
INFO - 2018-01-18 12:22:10 --> Loader Class Initialized
INFO - 2018-01-18 12:22:10 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:10 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:10 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:10 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:10 --> Model Class Initialized
INFO - 2018-01-18 12:22:10 --> Controller Class Initialized
INFO - 2018-01-18 12:22:10 --> Model Class Initialized
INFO - 2018-01-18 12:22:10 --> Model Class Initialized
INFO - 2018-01-18 12:22:10 --> Model Class Initialized
INFO - 2018-01-18 12:22:10 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:14 --> Config Class Initialized
INFO - 2018-01-18 12:22:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:14 --> URI Class Initialized
INFO - 2018-01-18 12:22:14 --> Router Class Initialized
INFO - 2018-01-18 12:22:14 --> Output Class Initialized
INFO - 2018-01-18 12:22:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:14 --> Input Class Initialized
INFO - 2018-01-18 12:22:14 --> Language Class Initialized
INFO - 2018-01-18 12:22:14 --> Loader Class Initialized
INFO - 2018-01-18 12:22:14 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:14 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:14 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:14 --> Model Class Initialized
INFO - 2018-01-18 12:22:14 --> Controller Class Initialized
INFO - 2018-01-18 12:22:14 --> Model Class Initialized
INFO - 2018-01-18 12:22:14 --> Model Class Initialized
INFO - 2018-01-18 12:22:14 --> Model Class Initialized
INFO - 2018-01-18 12:22:14 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:14 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:14 --> Total execution time: 0.0529
INFO - 2018-01-18 12:22:15 --> Config Class Initialized
INFO - 2018-01-18 12:22:15 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:15 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:15 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:15 --> URI Class Initialized
INFO - 2018-01-18 12:22:15 --> Router Class Initialized
INFO - 2018-01-18 12:22:15 --> Output Class Initialized
INFO - 2018-01-18 12:22:15 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:15 --> Input Class Initialized
INFO - 2018-01-18 12:22:15 --> Language Class Initialized
ERROR - 2018-01-18 12:22:15 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:24 --> Config Class Initialized
INFO - 2018-01-18 12:22:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:24 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:24 --> URI Class Initialized
INFO - 2018-01-18 12:22:24 --> Router Class Initialized
INFO - 2018-01-18 12:22:24 --> Output Class Initialized
INFO - 2018-01-18 12:22:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:24 --> Input Class Initialized
INFO - 2018-01-18 12:22:24 --> Language Class Initialized
INFO - 2018-01-18 12:22:24 --> Loader Class Initialized
INFO - 2018-01-18 12:22:24 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:24 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:24 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:24 --> Model Class Initialized
INFO - 2018-01-18 12:22:24 --> Controller Class Initialized
INFO - 2018-01-18 12:22:24 --> Model Class Initialized
INFO - 2018-01-18 12:22:24 --> Model Class Initialized
INFO - 2018-01-18 12:22:24 --> Model Class Initialized
INFO - 2018-01-18 12:22:24 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:22:24 --> Severity: Notice --> Undefined variable: extensiones_tipos /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verExtensionesProyecto.php 50
ERROR - 2018-01-18 12:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verExtensionesProyecto.php 50
INFO - 2018-01-18 12:22:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:24 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:24 --> Total execution time: 0.0626
INFO - 2018-01-18 12:22:25 --> Config Class Initialized
INFO - 2018-01-18 12:22:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:25 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:25 --> URI Class Initialized
INFO - 2018-01-18 12:22:25 --> Router Class Initialized
INFO - 2018-01-18 12:22:25 --> Output Class Initialized
INFO - 2018-01-18 12:22:25 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:25 --> Input Class Initialized
INFO - 2018-01-18 12:22:25 --> Language Class Initialized
ERROR - 2018-01-18 12:22:25 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:33 --> Config Class Initialized
INFO - 2018-01-18 12:22:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:33 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:33 --> URI Class Initialized
INFO - 2018-01-18 12:22:33 --> Router Class Initialized
INFO - 2018-01-18 12:22:33 --> Output Class Initialized
INFO - 2018-01-18 12:22:33 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:33 --> Input Class Initialized
INFO - 2018-01-18 12:22:33 --> Language Class Initialized
INFO - 2018-01-18 12:22:33 --> Loader Class Initialized
INFO - 2018-01-18 12:22:33 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:33 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:33 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:33 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:33 --> Model Class Initialized
INFO - 2018-01-18 12:22:33 --> Controller Class Initialized
INFO - 2018-01-18 12:22:33 --> Model Class Initialized
INFO - 2018-01-18 12:22:33 --> Model Class Initialized
INFO - 2018-01-18 12:22:33 --> Model Class Initialized
INFO - 2018-01-18 12:22:33 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:33 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:33 --> Total execution time: 0.0537
INFO - 2018-01-18 12:22:34 --> Config Class Initialized
INFO - 2018-01-18 12:22:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:34 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:34 --> URI Class Initialized
INFO - 2018-01-18 12:22:34 --> Router Class Initialized
INFO - 2018-01-18 12:22:34 --> Output Class Initialized
INFO - 2018-01-18 12:22:34 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:34 --> Input Class Initialized
INFO - 2018-01-18 12:22:34 --> Language Class Initialized
ERROR - 2018-01-18 12:22:34 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:37 --> Config Class Initialized
INFO - 2018-01-18 12:22:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:37 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:37 --> URI Class Initialized
INFO - 2018-01-18 12:22:37 --> Router Class Initialized
INFO - 2018-01-18 12:22:37 --> Output Class Initialized
INFO - 2018-01-18 12:22:37 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:37 --> Input Class Initialized
INFO - 2018-01-18 12:22:37 --> Language Class Initialized
INFO - 2018-01-18 12:22:37 --> Loader Class Initialized
INFO - 2018-01-18 12:22:37 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:37 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:37 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:37 --> Model Class Initialized
INFO - 2018-01-18 12:22:37 --> Controller Class Initialized
INFO - 2018-01-18 12:22:37 --> Model Class Initialized
INFO - 2018-01-18 12:22:37 --> Model Class Initialized
INFO - 2018-01-18 12:22:37 --> Model Class Initialized
INFO - 2018-01-18 12:22:37 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:22:37 --> Severity: Notice --> Undefined variable: extensiones_tipos /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verExtensionesProyecto.php 50
ERROR - 2018-01-18 12:22:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verExtensionesProyecto.php 50
INFO - 2018-01-18 12:22:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:37 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:37 --> Total execution time: 0.0540
INFO - 2018-01-18 12:22:37 --> Config Class Initialized
INFO - 2018-01-18 12:22:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:37 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:37 --> URI Class Initialized
INFO - 2018-01-18 12:22:37 --> Router Class Initialized
INFO - 2018-01-18 12:22:37 --> Output Class Initialized
INFO - 2018-01-18 12:22:37 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:37 --> Input Class Initialized
INFO - 2018-01-18 12:22:37 --> Language Class Initialized
ERROR - 2018-01-18 12:22:37 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:39 --> Config Class Initialized
INFO - 2018-01-18 12:22:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:39 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:40 --> URI Class Initialized
INFO - 2018-01-18 12:22:40 --> Router Class Initialized
INFO - 2018-01-18 12:22:40 --> Output Class Initialized
INFO - 2018-01-18 12:22:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:40 --> Input Class Initialized
INFO - 2018-01-18 12:22:40 --> Language Class Initialized
INFO - 2018-01-18 12:22:40 --> Loader Class Initialized
INFO - 2018-01-18 12:22:40 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:40 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:40 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:40 --> Model Class Initialized
INFO - 2018-01-18 12:22:40 --> Controller Class Initialized
INFO - 2018-01-18 12:22:40 --> Model Class Initialized
INFO - 2018-01-18 12:22:40 --> Model Class Initialized
INFO - 2018-01-18 12:22:40 --> Model Class Initialized
INFO - 2018-01-18 12:22:40 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:40 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:40 --> Total execution time: 0.0519
INFO - 2018-01-18 12:22:40 --> Config Class Initialized
INFO - 2018-01-18 12:22:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:40 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:40 --> URI Class Initialized
INFO - 2018-01-18 12:22:40 --> Router Class Initialized
INFO - 2018-01-18 12:22:40 --> Output Class Initialized
INFO - 2018-01-18 12:22:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:40 --> Input Class Initialized
INFO - 2018-01-18 12:22:40 --> Language Class Initialized
ERROR - 2018-01-18 12:22:40 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:41 --> Config Class Initialized
INFO - 2018-01-18 12:22:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:41 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:41 --> URI Class Initialized
INFO - 2018-01-18 12:22:41 --> Router Class Initialized
INFO - 2018-01-18 12:22:41 --> Output Class Initialized
INFO - 2018-01-18 12:22:41 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:41 --> Input Class Initialized
INFO - 2018-01-18 12:22:41 --> Language Class Initialized
INFO - 2018-01-18 12:22:41 --> Loader Class Initialized
INFO - 2018-01-18 12:22:41 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:41 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:41 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:41 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:41 --> Model Class Initialized
INFO - 2018-01-18 12:22:41 --> Controller Class Initialized
INFO - 2018-01-18 12:22:41 --> Model Class Initialized
INFO - 2018-01-18 12:22:41 --> Model Class Initialized
INFO - 2018-01-18 12:22:41 --> Model Class Initialized
INFO - 2018-01-18 12:22:41 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:22:41 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:22:41 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:22:41 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:22:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:41 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:41 --> Total execution time: 0.0546
INFO - 2018-01-18 12:22:42 --> Config Class Initialized
INFO - 2018-01-18 12:22:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:42 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:42 --> URI Class Initialized
INFO - 2018-01-18 12:22:42 --> Router Class Initialized
INFO - 2018-01-18 12:22:42 --> Output Class Initialized
INFO - 2018-01-18 12:22:42 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:42 --> Input Class Initialized
INFO - 2018-01-18 12:22:42 --> Language Class Initialized
ERROR - 2018-01-18 12:22:42 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:22:45 --> Config Class Initialized
INFO - 2018-01-18 12:22:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:22:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:22:45 --> Utf8 Class Initialized
INFO - 2018-01-18 12:22:45 --> URI Class Initialized
INFO - 2018-01-18 12:22:45 --> Router Class Initialized
INFO - 2018-01-18 12:22:45 --> Output Class Initialized
INFO - 2018-01-18 12:22:45 --> Security Class Initialized
DEBUG - 2018-01-18 12:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:22:45 --> Input Class Initialized
INFO - 2018-01-18 12:22:45 --> Language Class Initialized
INFO - 2018-01-18 12:22:45 --> Loader Class Initialized
INFO - 2018-01-18 12:22:45 --> Helper loaded: url_helper
INFO - 2018-01-18 12:22:45 --> Helper loaded: form_helper
INFO - 2018-01-18 12:22:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:22:45 --> Form Validation Class Initialized
INFO - 2018-01-18 12:22:45 --> Model Class Initialized
INFO - 2018-01-18 12:22:45 --> Controller Class Initialized
INFO - 2018-01-18 12:22:45 --> Model Class Initialized
INFO - 2018-01-18 12:22:45 --> Model Class Initialized
INFO - 2018-01-18 12:22:45 --> Model Class Initialized
INFO - 2018-01-18 12:22:45 --> Model Class Initialized
DEBUG - 2018-01-18 12:22:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:22:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:22:45 --> Final output sent to browser
DEBUG - 2018-01-18 12:22:45 --> Total execution time: 0.0543
INFO - 2018-01-18 12:23:22 --> Config Class Initialized
INFO - 2018-01-18 12:23:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:22 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:22 --> URI Class Initialized
INFO - 2018-01-18 12:23:22 --> Router Class Initialized
INFO - 2018-01-18 12:23:22 --> Output Class Initialized
INFO - 2018-01-18 12:23:22 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:22 --> Input Class Initialized
INFO - 2018-01-18 12:23:22 --> Language Class Initialized
INFO - 2018-01-18 12:23:22 --> Loader Class Initialized
INFO - 2018-01-18 12:23:22 --> Helper loaded: url_helper
INFO - 2018-01-18 12:23:22 --> Helper loaded: form_helper
INFO - 2018-01-18 12:23:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:23:22 --> Form Validation Class Initialized
INFO - 2018-01-18 12:23:22 --> Model Class Initialized
INFO - 2018-01-18 12:23:22 --> Controller Class Initialized
INFO - 2018-01-18 12:23:22 --> Model Class Initialized
INFO - 2018-01-18 12:23:22 --> Model Class Initialized
INFO - 2018-01-18 12:23:22 --> Model Class Initialized
INFO - 2018-01-18 12:23:22 --> Model Class Initialized
DEBUG - 2018-01-18 12:23:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:23:24 --> Config Class Initialized
INFO - 2018-01-18 12:23:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:24 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:24 --> URI Class Initialized
INFO - 2018-01-18 12:23:24 --> Router Class Initialized
INFO - 2018-01-18 12:23:24 --> Output Class Initialized
INFO - 2018-01-18 12:23:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:24 --> Input Class Initialized
INFO - 2018-01-18 12:23:24 --> Language Class Initialized
INFO - 2018-01-18 12:23:24 --> Loader Class Initialized
INFO - 2018-01-18 12:23:24 --> Helper loaded: url_helper
INFO - 2018-01-18 12:23:24 --> Helper loaded: form_helper
INFO - 2018-01-18 12:23:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:23:24 --> Form Validation Class Initialized
INFO - 2018-01-18 12:23:24 --> Model Class Initialized
INFO - 2018-01-18 12:23:24 --> Controller Class Initialized
INFO - 2018-01-18 12:23:24 --> Model Class Initialized
INFO - 2018-01-18 12:23:24 --> Model Class Initialized
INFO - 2018-01-18 12:23:24 --> Model Class Initialized
INFO - 2018-01-18 12:23:24 --> Model Class Initialized
DEBUG - 2018-01-18 12:23:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:23:24 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:23:24 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:23:24 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:23:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:23:24 --> Final output sent to browser
DEBUG - 2018-01-18 12:23:24 --> Total execution time: 0.0561
INFO - 2018-01-18 12:23:24 --> Config Class Initialized
INFO - 2018-01-18 12:23:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:24 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:24 --> URI Class Initialized
INFO - 2018-01-18 12:23:24 --> Router Class Initialized
INFO - 2018-01-18 12:23:24 --> Output Class Initialized
INFO - 2018-01-18 12:23:24 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:24 --> Input Class Initialized
INFO - 2018-01-18 12:23:24 --> Language Class Initialized
ERROR - 2018-01-18 12:23:24 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:23:36 --> Config Class Initialized
INFO - 2018-01-18 12:23:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:36 --> URI Class Initialized
INFO - 2018-01-18 12:23:36 --> Router Class Initialized
INFO - 2018-01-18 12:23:36 --> Output Class Initialized
INFO - 2018-01-18 12:23:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:36 --> Input Class Initialized
INFO - 2018-01-18 12:23:36 --> Language Class Initialized
INFO - 2018-01-18 12:23:36 --> Loader Class Initialized
INFO - 2018-01-18 12:23:36 --> Helper loaded: url_helper
INFO - 2018-01-18 12:23:36 --> Helper loaded: form_helper
INFO - 2018-01-18 12:23:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:23:36 --> Form Validation Class Initialized
INFO - 2018-01-18 12:23:36 --> Model Class Initialized
INFO - 2018-01-18 12:23:36 --> Controller Class Initialized
INFO - 2018-01-18 12:23:36 --> Model Class Initialized
INFO - 2018-01-18 12:23:36 --> Model Class Initialized
INFO - 2018-01-18 12:23:36 --> Model Class Initialized
INFO - 2018-01-18 12:23:36 --> Model Class Initialized
DEBUG - 2018-01-18 12:23:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:23:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:23:36 --> Final output sent to browser
DEBUG - 2018-01-18 12:23:36 --> Total execution time: 0.0525
INFO - 2018-01-18 12:23:36 --> Config Class Initialized
INFO - 2018-01-18 12:23:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:36 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:36 --> URI Class Initialized
INFO - 2018-01-18 12:23:36 --> Router Class Initialized
INFO - 2018-01-18 12:23:36 --> Output Class Initialized
INFO - 2018-01-18 12:23:36 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:36 --> Input Class Initialized
INFO - 2018-01-18 12:23:36 --> Language Class Initialized
ERROR - 2018-01-18 12:23:36 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:23:47 --> Config Class Initialized
INFO - 2018-01-18 12:23:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:47 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:47 --> URI Class Initialized
INFO - 2018-01-18 12:23:47 --> Router Class Initialized
INFO - 2018-01-18 12:23:47 --> Output Class Initialized
INFO - 2018-01-18 12:23:47 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:47 --> Input Class Initialized
INFO - 2018-01-18 12:23:47 --> Language Class Initialized
INFO - 2018-01-18 12:23:47 --> Loader Class Initialized
INFO - 2018-01-18 12:23:47 --> Helper loaded: url_helper
INFO - 2018-01-18 12:23:47 --> Helper loaded: form_helper
INFO - 2018-01-18 12:23:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:23:47 --> Form Validation Class Initialized
INFO - 2018-01-18 12:23:47 --> Model Class Initialized
INFO - 2018-01-18 12:23:47 --> Controller Class Initialized
INFO - 2018-01-18 12:23:47 --> Model Class Initialized
INFO - 2018-01-18 12:23:47 --> Model Class Initialized
INFO - 2018-01-18 12:23:47 --> Model Class Initialized
INFO - 2018-01-18 12:23:47 --> Model Class Initialized
DEBUG - 2018-01-18 12:23:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:23:47 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:23:47 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:23:47 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:23:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:23:47 --> Final output sent to browser
DEBUG - 2018-01-18 12:23:47 --> Total execution time: 0.0520
INFO - 2018-01-18 12:23:47 --> Config Class Initialized
INFO - 2018-01-18 12:23:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:47 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:47 --> URI Class Initialized
INFO - 2018-01-18 12:23:47 --> Router Class Initialized
INFO - 2018-01-18 12:23:47 --> Output Class Initialized
INFO - 2018-01-18 12:23:47 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:47 --> Input Class Initialized
INFO - 2018-01-18 12:23:47 --> Language Class Initialized
ERROR - 2018-01-18 12:23:47 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:23:55 --> Config Class Initialized
INFO - 2018-01-18 12:23:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:55 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:55 --> URI Class Initialized
INFO - 2018-01-18 12:23:55 --> Router Class Initialized
INFO - 2018-01-18 12:23:55 --> Output Class Initialized
INFO - 2018-01-18 12:23:55 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:55 --> Input Class Initialized
INFO - 2018-01-18 12:23:55 --> Language Class Initialized
INFO - 2018-01-18 12:23:55 --> Loader Class Initialized
INFO - 2018-01-18 12:23:55 --> Helper loaded: url_helper
INFO - 2018-01-18 12:23:55 --> Helper loaded: form_helper
INFO - 2018-01-18 12:23:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:23:55 --> Form Validation Class Initialized
INFO - 2018-01-18 12:23:55 --> Model Class Initialized
INFO - 2018-01-18 12:23:55 --> Controller Class Initialized
INFO - 2018-01-18 12:23:55 --> Model Class Initialized
INFO - 2018-01-18 12:23:55 --> Model Class Initialized
INFO - 2018-01-18 12:23:55 --> Model Class Initialized
INFO - 2018-01-18 12:23:55 --> Model Class Initialized
DEBUG - 2018-01-18 12:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:23:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:23:55 --> Final output sent to browser
DEBUG - 2018-01-18 12:23:55 --> Total execution time: 0.0518
INFO - 2018-01-18 12:23:55 --> Config Class Initialized
INFO - 2018-01-18 12:23:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:23:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:23:55 --> Utf8 Class Initialized
INFO - 2018-01-18 12:23:55 --> URI Class Initialized
INFO - 2018-01-18 12:23:55 --> Router Class Initialized
INFO - 2018-01-18 12:23:55 --> Output Class Initialized
INFO - 2018-01-18 12:23:55 --> Security Class Initialized
DEBUG - 2018-01-18 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:23:55 --> Input Class Initialized
INFO - 2018-01-18 12:23:55 --> Language Class Initialized
ERROR - 2018-01-18 12:23:55 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:24:00 --> Config Class Initialized
INFO - 2018-01-18 12:24:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:00 --> URI Class Initialized
INFO - 2018-01-18 12:24:00 --> Router Class Initialized
INFO - 2018-01-18 12:24:00 --> Output Class Initialized
INFO - 2018-01-18 12:24:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:00 --> Input Class Initialized
INFO - 2018-01-18 12:24:00 --> Language Class Initialized
INFO - 2018-01-18 12:24:00 --> Loader Class Initialized
INFO - 2018-01-18 12:24:00 --> Helper loaded: url_helper
INFO - 2018-01-18 12:24:00 --> Helper loaded: form_helper
INFO - 2018-01-18 12:24:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:24:00 --> Form Validation Class Initialized
INFO - 2018-01-18 12:24:00 --> Model Class Initialized
INFO - 2018-01-18 12:24:00 --> Controller Class Initialized
INFO - 2018-01-18 12:24:00 --> Model Class Initialized
INFO - 2018-01-18 12:24:00 --> Model Class Initialized
INFO - 2018-01-18 12:24:00 --> Model Class Initialized
INFO - 2018-01-18 12:24:00 --> Model Class Initialized
DEBUG - 2018-01-18 12:24:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:24:00 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:24:00 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:24:00 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:24:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:24:00 --> Final output sent to browser
DEBUG - 2018-01-18 12:24:00 --> Total execution time: 0.0622
INFO - 2018-01-18 12:24:00 --> Config Class Initialized
INFO - 2018-01-18 12:24:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:00 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:00 --> URI Class Initialized
INFO - 2018-01-18 12:24:00 --> Router Class Initialized
INFO - 2018-01-18 12:24:00 --> Output Class Initialized
INFO - 2018-01-18 12:24:00 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:00 --> Input Class Initialized
INFO - 2018-01-18 12:24:00 --> Language Class Initialized
ERROR - 2018-01-18 12:24:00 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:24:13 --> Config Class Initialized
INFO - 2018-01-18 12:24:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:13 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:13 --> URI Class Initialized
INFO - 2018-01-18 12:24:13 --> Router Class Initialized
INFO - 2018-01-18 12:24:13 --> Output Class Initialized
INFO - 2018-01-18 12:24:13 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:13 --> Input Class Initialized
INFO - 2018-01-18 12:24:13 --> Language Class Initialized
INFO - 2018-01-18 12:24:13 --> Loader Class Initialized
INFO - 2018-01-18 12:24:13 --> Helper loaded: url_helper
INFO - 2018-01-18 12:24:13 --> Helper loaded: form_helper
INFO - 2018-01-18 12:24:13 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:24:13 --> Form Validation Class Initialized
INFO - 2018-01-18 12:24:13 --> Model Class Initialized
INFO - 2018-01-18 12:24:13 --> Controller Class Initialized
INFO - 2018-01-18 12:24:13 --> Model Class Initialized
INFO - 2018-01-18 12:24:13 --> Model Class Initialized
INFO - 2018-01-18 12:24:13 --> Model Class Initialized
INFO - 2018-01-18 12:24:13 --> Model Class Initialized
DEBUG - 2018-01-18 12:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:24:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:24:13 --> Final output sent to browser
DEBUG - 2018-01-18 12:24:13 --> Total execution time: 0.0502
INFO - 2018-01-18 12:24:14 --> Config Class Initialized
INFO - 2018-01-18 12:24:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:14 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:14 --> URI Class Initialized
INFO - 2018-01-18 12:24:14 --> Router Class Initialized
INFO - 2018-01-18 12:24:14 --> Output Class Initialized
INFO - 2018-01-18 12:24:14 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:14 --> Input Class Initialized
INFO - 2018-01-18 12:24:14 --> Language Class Initialized
ERROR - 2018-01-18 12:24:14 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:24:16 --> Config Class Initialized
INFO - 2018-01-18 12:24:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:16 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:16 --> URI Class Initialized
INFO - 2018-01-18 12:24:16 --> Router Class Initialized
INFO - 2018-01-18 12:24:16 --> Output Class Initialized
INFO - 2018-01-18 12:24:16 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:16 --> Input Class Initialized
INFO - 2018-01-18 12:24:16 --> Language Class Initialized
INFO - 2018-01-18 12:24:16 --> Loader Class Initialized
INFO - 2018-01-18 12:24:16 --> Helper loaded: url_helper
INFO - 2018-01-18 12:24:16 --> Helper loaded: form_helper
INFO - 2018-01-18 12:24:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:24:16 --> Form Validation Class Initialized
INFO - 2018-01-18 12:24:16 --> Model Class Initialized
INFO - 2018-01-18 12:24:16 --> Controller Class Initialized
INFO - 2018-01-18 12:24:16 --> Model Class Initialized
INFO - 2018-01-18 12:24:16 --> Model Class Initialized
INFO - 2018-01-18 12:24:16 --> Model Class Initialized
INFO - 2018-01-18 12:24:16 --> Model Class Initialized
DEBUG - 2018-01-18 12:24:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:24:16 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:24:16 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:24:16 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:24:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:24:16 --> Final output sent to browser
DEBUG - 2018-01-18 12:24:16 --> Total execution time: 0.0571
INFO - 2018-01-18 12:24:16 --> Config Class Initialized
INFO - 2018-01-18 12:24:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:24:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:24:16 --> Utf8 Class Initialized
INFO - 2018-01-18 12:24:16 --> URI Class Initialized
INFO - 2018-01-18 12:24:16 --> Router Class Initialized
INFO - 2018-01-18 12:24:16 --> Output Class Initialized
INFO - 2018-01-18 12:24:16 --> Security Class Initialized
DEBUG - 2018-01-18 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:24:16 --> Input Class Initialized
INFO - 2018-01-18 12:24:16 --> Language Class Initialized
ERROR - 2018-01-18 12:24:16 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:29:48 --> Config Class Initialized
INFO - 2018-01-18 12:29:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:29:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:29:48 --> Utf8 Class Initialized
INFO - 2018-01-18 12:29:48 --> URI Class Initialized
INFO - 2018-01-18 12:29:48 --> Router Class Initialized
INFO - 2018-01-18 12:29:48 --> Output Class Initialized
INFO - 2018-01-18 12:29:48 --> Security Class Initialized
DEBUG - 2018-01-18 12:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:29:48 --> Input Class Initialized
INFO - 2018-01-18 12:29:48 --> Language Class Initialized
INFO - 2018-01-18 12:29:48 --> Loader Class Initialized
INFO - 2018-01-18 12:29:48 --> Helper loaded: url_helper
INFO - 2018-01-18 12:29:48 --> Helper loaded: form_helper
INFO - 2018-01-18 12:29:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:29:48 --> Form Validation Class Initialized
INFO - 2018-01-18 12:29:48 --> Model Class Initialized
INFO - 2018-01-18 12:29:48 --> Controller Class Initialized
INFO - 2018-01-18 12:29:48 --> Model Class Initialized
INFO - 2018-01-18 12:29:48 --> Model Class Initialized
INFO - 2018-01-18 12:29:48 --> Model Class Initialized
INFO - 2018-01-18 12:29:48 --> Model Class Initialized
DEBUG - 2018-01-18 12:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:29:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:29:48 --> Final output sent to browser
DEBUG - 2018-01-18 12:29:48 --> Total execution time: 0.0555
INFO - 2018-01-18 12:29:49 --> Config Class Initialized
INFO - 2018-01-18 12:29:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:29:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:29:49 --> Utf8 Class Initialized
INFO - 2018-01-18 12:29:49 --> URI Class Initialized
INFO - 2018-01-18 12:29:49 --> Router Class Initialized
INFO - 2018-01-18 12:29:49 --> Output Class Initialized
INFO - 2018-01-18 12:29:49 --> Security Class Initialized
DEBUG - 2018-01-18 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:29:49 --> Input Class Initialized
INFO - 2018-01-18 12:29:49 --> Language Class Initialized
ERROR - 2018-01-18 12:29:49 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:30:06 --> Config Class Initialized
INFO - 2018-01-18 12:30:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:06 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:06 --> URI Class Initialized
INFO - 2018-01-18 12:30:06 --> Router Class Initialized
INFO - 2018-01-18 12:30:06 --> Output Class Initialized
INFO - 2018-01-18 12:30:06 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:06 --> Input Class Initialized
INFO - 2018-01-18 12:30:06 --> Language Class Initialized
INFO - 2018-01-18 12:30:06 --> Loader Class Initialized
INFO - 2018-01-18 12:30:06 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:06 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:06 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:06 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:06 --> Model Class Initialized
INFO - 2018-01-18 12:30:06 --> Controller Class Initialized
INFO - 2018-01-18 12:30:06 --> Model Class Initialized
INFO - 2018-01-18 12:30:06 --> Model Class Initialized
INFO - 2018-01-18 12:30:06 --> Model Class Initialized
INFO - 2018-01-18 12:30:06 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 12:30:06 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 12:30:06 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 12:30:06 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 12:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 12:30:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:06 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:06 --> Total execution time: 0.0767
INFO - 2018-01-18 12:30:06 --> Config Class Initialized
INFO - 2018-01-18 12:30:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:06 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:06 --> URI Class Initialized
INFO - 2018-01-18 12:30:06 --> Router Class Initialized
INFO - 2018-01-18 12:30:06 --> Output Class Initialized
INFO - 2018-01-18 12:30:06 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:06 --> Input Class Initialized
INFO - 2018-01-18 12:30:06 --> Language Class Initialized
ERROR - 2018-01-18 12:30:06 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:30:09 --> Config Class Initialized
INFO - 2018-01-18 12:30:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:09 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:09 --> URI Class Initialized
INFO - 2018-01-18 12:30:09 --> Router Class Initialized
INFO - 2018-01-18 12:30:09 --> Output Class Initialized
INFO - 2018-01-18 12:30:09 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:09 --> Input Class Initialized
INFO - 2018-01-18 12:30:09 --> Language Class Initialized
INFO - 2018-01-18 12:30:09 --> Loader Class Initialized
INFO - 2018-01-18 12:30:09 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:09 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:09 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:09 --> Model Class Initialized
INFO - 2018-01-18 12:30:09 --> Controller Class Initialized
INFO - 2018-01-18 12:30:09 --> Model Class Initialized
INFO - 2018-01-18 12:30:09 --> Model Class Initialized
INFO - 2018-01-18 12:30:09 --> Model Class Initialized
INFO - 2018-01-18 12:30:09 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:09 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:09 --> Total execution time: 0.0777
INFO - 2018-01-18 12:30:21 --> Config Class Initialized
INFO - 2018-01-18 12:30:21 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:21 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:21 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:21 --> URI Class Initialized
INFO - 2018-01-18 12:30:21 --> Router Class Initialized
INFO - 2018-01-18 12:30:21 --> Output Class Initialized
INFO - 2018-01-18 12:30:21 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:21 --> Input Class Initialized
INFO - 2018-01-18 12:30:21 --> Language Class Initialized
INFO - 2018-01-18 12:30:21 --> Loader Class Initialized
INFO - 2018-01-18 12:30:21 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:21 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:21 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:21 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:21 --> Model Class Initialized
INFO - 2018-01-18 12:30:21 --> Controller Class Initialized
INFO - 2018-01-18 12:30:21 --> Model Class Initialized
INFO - 2018-01-18 12:30:21 --> Model Class Initialized
INFO - 2018-01-18 12:30:21 --> Model Class Initialized
INFO - 2018-01-18 12:30:21 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:21 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:21 --> Total execution time: 0.0576
INFO - 2018-01-18 12:30:26 --> Config Class Initialized
INFO - 2018-01-18 12:30:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:26 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:26 --> URI Class Initialized
INFO - 2018-01-18 12:30:26 --> Router Class Initialized
INFO - 2018-01-18 12:30:26 --> Output Class Initialized
INFO - 2018-01-18 12:30:26 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:26 --> Input Class Initialized
INFO - 2018-01-18 12:30:26 --> Language Class Initialized
INFO - 2018-01-18 12:30:26 --> Loader Class Initialized
INFO - 2018-01-18 12:30:26 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:26 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:26 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:26 --> Model Class Initialized
INFO - 2018-01-18 12:30:26 --> Controller Class Initialized
INFO - 2018-01-18 12:30:26 --> Model Class Initialized
INFO - 2018-01-18 12:30:26 --> Model Class Initialized
INFO - 2018-01-18 12:30:26 --> Model Class Initialized
INFO - 2018-01-18 12:30:26 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:26 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:26 --> Total execution time: 0.6468
INFO - 2018-01-18 12:30:44 --> Config Class Initialized
INFO - 2018-01-18 12:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:44 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:44 --> URI Class Initialized
DEBUG - 2018-01-18 12:30:44 --> No URI present. Default controller set.
INFO - 2018-01-18 12:30:44 --> Router Class Initialized
INFO - 2018-01-18 12:30:44 --> Output Class Initialized
INFO - 2018-01-18 12:30:44 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:44 --> Input Class Initialized
INFO - 2018-01-18 12:30:44 --> Language Class Initialized
INFO - 2018-01-18 12:30:44 --> Loader Class Initialized
INFO - 2018-01-18 12:30:44 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:44 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:44 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:44 --> Model Class Initialized
INFO - 2018-01-18 12:30:44 --> Controller Class Initialized
INFO - 2018-01-18 12:30:44 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:44 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:44 --> Total execution time: 0.0351
INFO - 2018-01-18 12:30:46 --> Config Class Initialized
INFO - 2018-01-18 12:30:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:46 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:46 --> URI Class Initialized
INFO - 2018-01-18 12:30:46 --> Router Class Initialized
INFO - 2018-01-18 12:30:46 --> Output Class Initialized
INFO - 2018-01-18 12:30:46 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:46 --> Input Class Initialized
INFO - 2018-01-18 12:30:46 --> Language Class Initialized
INFO - 2018-01-18 12:30:46 --> Loader Class Initialized
INFO - 2018-01-18 12:30:46 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:46 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:46 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:46 --> Model Class Initialized
INFO - 2018-01-18 12:30:46 --> Controller Class Initialized
INFO - 2018-01-18 12:30:46 --> Model Class Initialized
INFO - 2018-01-18 12:30:46 --> Model Class Initialized
INFO - 2018-01-18 12:30:46 --> Model Class Initialized
INFO - 2018-01-18 12:30:46 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:46 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:46 --> Total execution time: 0.0504
INFO - 2018-01-18 12:30:47 --> Config Class Initialized
INFO - 2018-01-18 12:30:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:47 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:47 --> URI Class Initialized
INFO - 2018-01-18 12:30:47 --> Router Class Initialized
INFO - 2018-01-18 12:30:47 --> Output Class Initialized
INFO - 2018-01-18 12:30:47 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:47 --> Input Class Initialized
INFO - 2018-01-18 12:30:47 --> Language Class Initialized
INFO - 2018-01-18 12:30:47 --> Loader Class Initialized
INFO - 2018-01-18 12:30:47 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:47 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:47 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:47 --> Model Class Initialized
INFO - 2018-01-18 12:30:47 --> Controller Class Initialized
INFO - 2018-01-18 12:30:47 --> Model Class Initialized
INFO - 2018-01-18 12:30:47 --> Model Class Initialized
INFO - 2018-01-18 12:30:47 --> Model Class Initialized
INFO - 2018-01-18 12:30:47 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:53 --> Config Class Initialized
INFO - 2018-01-18 12:30:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:53 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:53 --> URI Class Initialized
INFO - 2018-01-18 12:30:53 --> Router Class Initialized
INFO - 2018-01-18 12:30:53 --> Output Class Initialized
INFO - 2018-01-18 12:30:53 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:53 --> Input Class Initialized
INFO - 2018-01-18 12:30:53 --> Language Class Initialized
INFO - 2018-01-18 12:30:53 --> Loader Class Initialized
INFO - 2018-01-18 12:30:53 --> Helper loaded: url_helper
INFO - 2018-01-18 12:30:53 --> Helper loaded: form_helper
INFO - 2018-01-18 12:30:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:30:53 --> Form Validation Class Initialized
INFO - 2018-01-18 12:30:53 --> Model Class Initialized
INFO - 2018-01-18 12:30:53 --> Controller Class Initialized
INFO - 2018-01-18 12:30:53 --> Model Class Initialized
INFO - 2018-01-18 12:30:53 --> Model Class Initialized
INFO - 2018-01-18 12:30:53 --> Model Class Initialized
INFO - 2018-01-18 12:30:53 --> Model Class Initialized
DEBUG - 2018-01-18 12:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:30:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:30:53 --> Final output sent to browser
DEBUG - 2018-01-18 12:30:53 --> Total execution time: 0.2582
INFO - 2018-01-18 12:30:54 --> Config Class Initialized
INFO - 2018-01-18 12:30:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:30:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:30:54 --> Utf8 Class Initialized
INFO - 2018-01-18 12:30:54 --> URI Class Initialized
INFO - 2018-01-18 12:30:54 --> Router Class Initialized
INFO - 2018-01-18 12:30:54 --> Output Class Initialized
INFO - 2018-01-18 12:30:54 --> Security Class Initialized
DEBUG - 2018-01-18 12:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:30:54 --> Input Class Initialized
INFO - 2018-01-18 12:30:54 --> Language Class Initialized
ERROR - 2018-01-18 12:30:54 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 12:34:40 --> Config Class Initialized
INFO - 2018-01-18 12:34:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:34:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:34:40 --> Utf8 Class Initialized
INFO - 2018-01-18 12:34:40 --> URI Class Initialized
INFO - 2018-01-18 12:34:40 --> Router Class Initialized
INFO - 2018-01-18 12:34:40 --> Output Class Initialized
INFO - 2018-01-18 12:34:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:34:40 --> Input Class Initialized
INFO - 2018-01-18 12:34:40 --> Language Class Initialized
INFO - 2018-01-18 12:34:40 --> Loader Class Initialized
INFO - 2018-01-18 12:34:40 --> Helper loaded: url_helper
INFO - 2018-01-18 12:34:40 --> Helper loaded: form_helper
INFO - 2018-01-18 12:34:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:34:40 --> Form Validation Class Initialized
INFO - 2018-01-18 12:34:40 --> Model Class Initialized
INFO - 2018-01-18 12:34:40 --> Controller Class Initialized
INFO - 2018-01-18 12:34:40 --> Model Class Initialized
DEBUG - 2018-01-18 12:34:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:34:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 12:34:40 --> Config Class Initialized
INFO - 2018-01-18 12:34:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:34:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:34:40 --> Utf8 Class Initialized
INFO - 2018-01-18 12:34:40 --> URI Class Initialized
DEBUG - 2018-01-18 12:34:40 --> No URI present. Default controller set.
INFO - 2018-01-18 12:34:40 --> Router Class Initialized
INFO - 2018-01-18 12:34:40 --> Output Class Initialized
INFO - 2018-01-18 12:34:40 --> Security Class Initialized
DEBUG - 2018-01-18 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:34:40 --> Input Class Initialized
INFO - 2018-01-18 12:34:40 --> Language Class Initialized
INFO - 2018-01-18 12:34:40 --> Loader Class Initialized
INFO - 2018-01-18 12:34:40 --> Helper loaded: url_helper
INFO - 2018-01-18 12:34:40 --> Helper loaded: form_helper
INFO - 2018-01-18 12:34:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:34:40 --> Form Validation Class Initialized
INFO - 2018-01-18 12:34:40 --> Model Class Initialized
INFO - 2018-01-18 12:34:40 --> Controller Class Initialized
INFO - 2018-01-18 12:34:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:34:40 --> Final output sent to browser
DEBUG - 2018-01-18 12:34:40 --> Total execution time: 0.0367
INFO - 2018-01-18 12:34:43 --> Config Class Initialized
INFO - 2018-01-18 12:34:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:34:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:34:43 --> Utf8 Class Initialized
INFO - 2018-01-18 12:34:43 --> URI Class Initialized
INFO - 2018-01-18 12:34:43 --> Router Class Initialized
INFO - 2018-01-18 12:34:43 --> Output Class Initialized
INFO - 2018-01-18 12:34:43 --> Security Class Initialized
DEBUG - 2018-01-18 12:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:34:43 --> Input Class Initialized
INFO - 2018-01-18 12:34:43 --> Language Class Initialized
INFO - 2018-01-18 12:34:43 --> Loader Class Initialized
INFO - 2018-01-18 12:34:43 --> Helper loaded: url_helper
INFO - 2018-01-18 12:34:43 --> Helper loaded: form_helper
INFO - 2018-01-18 12:34:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:34:43 --> Form Validation Class Initialized
INFO - 2018-01-18 12:34:43 --> Model Class Initialized
INFO - 2018-01-18 12:34:43 --> Controller Class Initialized
INFO - 2018-01-18 12:34:43 --> Model Class Initialized
INFO - 2018-01-18 12:34:43 --> Model Class Initialized
DEBUG - 2018-01-18 12:34:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:34:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:34:43 --> Final output sent to browser
DEBUG - 2018-01-18 12:34:43 --> Total execution time: 0.0474
INFO - 2018-01-18 12:34:44 --> Config Class Initialized
INFO - 2018-01-18 12:34:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:34:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:34:44 --> Utf8 Class Initialized
INFO - 2018-01-18 12:34:44 --> URI Class Initialized
INFO - 2018-01-18 12:34:44 --> Router Class Initialized
INFO - 2018-01-18 12:34:44 --> Output Class Initialized
INFO - 2018-01-18 12:34:44 --> Security Class Initialized
DEBUG - 2018-01-18 12:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:34:44 --> Input Class Initialized
INFO - 2018-01-18 12:34:44 --> Language Class Initialized
INFO - 2018-01-18 12:34:44 --> Loader Class Initialized
INFO - 2018-01-18 12:34:44 --> Helper loaded: url_helper
INFO - 2018-01-18 12:34:44 --> Helper loaded: form_helper
INFO - 2018-01-18 12:34:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:34:44 --> Form Validation Class Initialized
INFO - 2018-01-18 12:34:44 --> Model Class Initialized
INFO - 2018-01-18 12:34:44 --> Controller Class Initialized
INFO - 2018-01-18 12:34:44 --> Model Class Initialized
INFO - 2018-01-18 12:34:44 --> Model Class Initialized
DEBUG - 2018-01-18 12:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:34:54 --> Config Class Initialized
INFO - 2018-01-18 12:34:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 12:34:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 12:34:54 --> Utf8 Class Initialized
INFO - 2018-01-18 12:34:54 --> URI Class Initialized
INFO - 2018-01-18 12:34:54 --> Router Class Initialized
INFO - 2018-01-18 12:34:54 --> Output Class Initialized
INFO - 2018-01-18 12:34:54 --> Security Class Initialized
DEBUG - 2018-01-18 12:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 12:34:54 --> Input Class Initialized
INFO - 2018-01-18 12:34:54 --> Language Class Initialized
INFO - 2018-01-18 12:34:54 --> Loader Class Initialized
INFO - 2018-01-18 12:34:54 --> Helper loaded: url_helper
INFO - 2018-01-18 12:34:54 --> Helper loaded: form_helper
INFO - 2018-01-18 12:34:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 12:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 12:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 12:34:54 --> Form Validation Class Initialized
INFO - 2018-01-18 12:34:54 --> Model Class Initialized
INFO - 2018-01-18 12:34:54 --> Controller Class Initialized
INFO - 2018-01-18 12:34:54 --> Model Class Initialized
INFO - 2018-01-18 12:34:54 --> Model Class Initialized
INFO - 2018-01-18 12:34:54 --> Model Class Initialized
INFO - 2018-01-18 12:34:54 --> Model Class Initialized
DEBUG - 2018-01-18 12:34:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 12:34:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 12:34:54 --> Final output sent to browser
DEBUG - 2018-01-18 12:34:54 --> Total execution time: 0.0442
INFO - 2018-01-18 13:20:38 --> Config Class Initialized
INFO - 2018-01-18 13:20:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:20:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:20:38 --> Utf8 Class Initialized
INFO - 2018-01-18 13:20:38 --> URI Class Initialized
DEBUG - 2018-01-18 13:20:38 --> No URI present. Default controller set.
INFO - 2018-01-18 13:20:38 --> Router Class Initialized
INFO - 2018-01-18 13:20:38 --> Output Class Initialized
INFO - 2018-01-18 13:20:38 --> Security Class Initialized
DEBUG - 2018-01-18 13:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:20:38 --> Input Class Initialized
INFO - 2018-01-18 13:20:38 --> Language Class Initialized
INFO - 2018-01-18 13:20:38 --> Loader Class Initialized
INFO - 2018-01-18 13:20:38 --> Helper loaded: url_helper
INFO - 2018-01-18 13:20:38 --> Helper loaded: form_helper
INFO - 2018-01-18 13:20:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:20:38 --> Form Validation Class Initialized
INFO - 2018-01-18 13:20:38 --> Model Class Initialized
INFO - 2018-01-18 13:20:38 --> Controller Class Initialized
INFO - 2018-01-18 13:20:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:20:38 --> Final output sent to browser
DEBUG - 2018-01-18 13:20:38 --> Total execution time: 0.0353
INFO - 2018-01-18 13:20:50 --> Config Class Initialized
INFO - 2018-01-18 13:20:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:20:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:20:50 --> Utf8 Class Initialized
INFO - 2018-01-18 13:20:50 --> URI Class Initialized
INFO - 2018-01-18 13:20:50 --> Router Class Initialized
INFO - 2018-01-18 13:20:50 --> Output Class Initialized
INFO - 2018-01-18 13:20:50 --> Security Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:20:50 --> Input Class Initialized
INFO - 2018-01-18 13:20:50 --> Language Class Initialized
INFO - 2018-01-18 13:20:50 --> Loader Class Initialized
INFO - 2018-01-18 13:20:50 --> Helper loaded: url_helper
INFO - 2018-01-18 13:20:50 --> Helper loaded: form_helper
INFO - 2018-01-18 13:20:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:20:50 --> Form Validation Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Controller Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:20:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:20:50 --> Final output sent to browser
DEBUG - 2018-01-18 13:20:50 --> Total execution time: 0.0464
INFO - 2018-01-18 13:20:50 --> Config Class Initialized
INFO - 2018-01-18 13:20:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:20:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:20:50 --> Utf8 Class Initialized
INFO - 2018-01-18 13:20:50 --> URI Class Initialized
INFO - 2018-01-18 13:20:50 --> Router Class Initialized
INFO - 2018-01-18 13:20:50 --> Output Class Initialized
INFO - 2018-01-18 13:20:50 --> Security Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:20:50 --> Input Class Initialized
INFO - 2018-01-18 13:20:50 --> Language Class Initialized
INFO - 2018-01-18 13:20:50 --> Loader Class Initialized
INFO - 2018-01-18 13:20:50 --> Helper loaded: url_helper
INFO - 2018-01-18 13:20:50 --> Helper loaded: form_helper
INFO - 2018-01-18 13:20:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:20:50 --> Form Validation Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Controller Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
INFO - 2018-01-18 13:20:50 --> Model Class Initialized
DEBUG - 2018-01-18 13:20:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:21:09 --> Config Class Initialized
INFO - 2018-01-18 13:21:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:21:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:21:09 --> Utf8 Class Initialized
INFO - 2018-01-18 13:21:09 --> URI Class Initialized
INFO - 2018-01-18 13:21:09 --> Router Class Initialized
INFO - 2018-01-18 13:21:09 --> Output Class Initialized
INFO - 2018-01-18 13:21:09 --> Security Class Initialized
DEBUG - 2018-01-18 13:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:21:09 --> Input Class Initialized
INFO - 2018-01-18 13:21:09 --> Language Class Initialized
INFO - 2018-01-18 13:21:09 --> Loader Class Initialized
INFO - 2018-01-18 13:21:09 --> Helper loaded: url_helper
INFO - 2018-01-18 13:21:09 --> Helper loaded: form_helper
INFO - 2018-01-18 13:21:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:21:09 --> Form Validation Class Initialized
INFO - 2018-01-18 13:21:09 --> Model Class Initialized
INFO - 2018-01-18 13:21:09 --> Controller Class Initialized
INFO - 2018-01-18 13:21:09 --> Model Class Initialized
INFO - 2018-01-18 13:21:09 --> Model Class Initialized
INFO - 2018-01-18 13:21:09 --> Model Class Initialized
INFO - 2018-01-18 13:21:09 --> Model Class Initialized
DEBUG - 2018-01-18 13:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:21:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:21:09 --> Final output sent to browser
DEBUG - 2018-01-18 13:21:09 --> Total execution time: 0.0462
INFO - 2018-01-18 13:27:38 --> Config Class Initialized
INFO - 2018-01-18 13:27:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:27:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:27:38 --> Utf8 Class Initialized
INFO - 2018-01-18 13:27:38 --> URI Class Initialized
INFO - 2018-01-18 13:27:38 --> Router Class Initialized
INFO - 2018-01-18 13:27:38 --> Output Class Initialized
INFO - 2018-01-18 13:27:38 --> Security Class Initialized
DEBUG - 2018-01-18 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:27:38 --> Input Class Initialized
INFO - 2018-01-18 13:27:38 --> Language Class Initialized
INFO - 2018-01-18 13:27:38 --> Loader Class Initialized
INFO - 2018-01-18 13:27:38 --> Helper loaded: url_helper
INFO - 2018-01-18 13:27:38 --> Helper loaded: form_helper
INFO - 2018-01-18 13:27:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:27:38 --> Form Validation Class Initialized
INFO - 2018-01-18 13:27:38 --> Model Class Initialized
INFO - 2018-01-18 13:27:38 --> Controller Class Initialized
INFO - 2018-01-18 13:27:38 --> Model Class Initialized
INFO - 2018-01-18 13:27:38 --> Model Class Initialized
INFO - 2018-01-18 13:27:38 --> Model Class Initialized
INFO - 2018-01-18 13:27:38 --> Model Class Initialized
DEBUG - 2018-01-18 13:27:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:27:38 --> Final output sent to browser
DEBUG - 2018-01-18 13:27:38 --> Total execution time: 0.0436
INFO - 2018-01-18 13:27:44 --> Config Class Initialized
INFO - 2018-01-18 13:27:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:27:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:27:44 --> Utf8 Class Initialized
INFO - 2018-01-18 13:27:44 --> URI Class Initialized
INFO - 2018-01-18 13:27:44 --> Router Class Initialized
INFO - 2018-01-18 13:27:44 --> Output Class Initialized
INFO - 2018-01-18 13:27:44 --> Security Class Initialized
DEBUG - 2018-01-18 13:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:27:44 --> Input Class Initialized
INFO - 2018-01-18 13:27:44 --> Language Class Initialized
INFO - 2018-01-18 13:27:44 --> Loader Class Initialized
INFO - 2018-01-18 13:27:44 --> Helper loaded: url_helper
INFO - 2018-01-18 13:27:44 --> Helper loaded: form_helper
INFO - 2018-01-18 13:27:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:27:44 --> Form Validation Class Initialized
INFO - 2018-01-18 13:27:44 --> Model Class Initialized
INFO - 2018-01-18 13:27:44 --> Controller Class Initialized
INFO - 2018-01-18 13:27:44 --> Model Class Initialized
INFO - 2018-01-18 13:27:44 --> Model Class Initialized
INFO - 2018-01-18 13:27:44 --> Model Class Initialized
INFO - 2018-01-18 13:27:44 --> Model Class Initialized
DEBUG - 2018-01-18 13:27:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:33:41 --> Config Class Initialized
INFO - 2018-01-18 13:33:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:33:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:33:41 --> Utf8 Class Initialized
INFO - 2018-01-18 13:33:41 --> URI Class Initialized
INFO - 2018-01-18 13:33:41 --> Router Class Initialized
INFO - 2018-01-18 13:33:41 --> Output Class Initialized
INFO - 2018-01-18 13:33:41 --> Security Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:33:41 --> Input Class Initialized
INFO - 2018-01-18 13:33:41 --> Language Class Initialized
INFO - 2018-01-18 13:33:41 --> Loader Class Initialized
INFO - 2018-01-18 13:33:41 --> Helper loaded: url_helper
INFO - 2018-01-18 13:33:41 --> Helper loaded: form_helper
INFO - 2018-01-18 13:33:41 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:33:41 --> Form Validation Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Controller Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:33:41 --> Config Class Initialized
INFO - 2018-01-18 13:33:41 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:33:41 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:33:41 --> Utf8 Class Initialized
INFO - 2018-01-18 13:33:41 --> URI Class Initialized
INFO - 2018-01-18 13:33:41 --> Router Class Initialized
INFO - 2018-01-18 13:33:41 --> Output Class Initialized
INFO - 2018-01-18 13:33:41 --> Security Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:33:41 --> Input Class Initialized
INFO - 2018-01-18 13:33:41 --> Language Class Initialized
INFO - 2018-01-18 13:33:41 --> Loader Class Initialized
INFO - 2018-01-18 13:33:41 --> Helper loaded: url_helper
INFO - 2018-01-18 13:33:41 --> Helper loaded: form_helper
INFO - 2018-01-18 13:33:41 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:33:41 --> Form Validation Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Controller Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
INFO - 2018-01-18 13:33:41 --> Model Class Initialized
DEBUG - 2018-01-18 13:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:33:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:33:41 --> Final output sent to browser
DEBUG - 2018-01-18 13:33:41 --> Total execution time: 0.0689
INFO - 2018-01-18 13:33:42 --> Config Class Initialized
INFO - 2018-01-18 13:33:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:33:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:33:42 --> Utf8 Class Initialized
INFO - 2018-01-18 13:33:42 --> URI Class Initialized
INFO - 2018-01-18 13:33:42 --> Router Class Initialized
INFO - 2018-01-18 13:33:42 --> Output Class Initialized
INFO - 2018-01-18 13:33:42 --> Security Class Initialized
DEBUG - 2018-01-18 13:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:33:42 --> Input Class Initialized
INFO - 2018-01-18 13:33:42 --> Language Class Initialized
ERROR - 2018-01-18 13:33:42 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:34:31 --> Config Class Initialized
INFO - 2018-01-18 13:34:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:34:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:34:31 --> Utf8 Class Initialized
INFO - 2018-01-18 13:34:31 --> URI Class Initialized
INFO - 2018-01-18 13:34:31 --> Router Class Initialized
INFO - 2018-01-18 13:34:31 --> Output Class Initialized
INFO - 2018-01-18 13:34:31 --> Security Class Initialized
DEBUG - 2018-01-18 13:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:34:31 --> Input Class Initialized
INFO - 2018-01-18 13:34:31 --> Language Class Initialized
INFO - 2018-01-18 13:34:31 --> Loader Class Initialized
INFO - 2018-01-18 13:34:31 --> Helper loaded: url_helper
INFO - 2018-01-18 13:34:31 --> Helper loaded: form_helper
INFO - 2018-01-18 13:34:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:34:31 --> Form Validation Class Initialized
INFO - 2018-01-18 13:34:31 --> Model Class Initialized
INFO - 2018-01-18 13:34:31 --> Controller Class Initialized
INFO - 2018-01-18 13:34:31 --> Model Class Initialized
INFO - 2018-01-18 13:34:31 --> Model Class Initialized
INFO - 2018-01-18 13:34:31 --> Model Class Initialized
INFO - 2018-01-18 13:34:31 --> Model Class Initialized
DEBUG - 2018-01-18 13:34:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:34:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:34:31 --> Final output sent to browser
DEBUG - 2018-01-18 13:34:31 --> Total execution time: 0.0564
INFO - 2018-01-18 13:34:32 --> Config Class Initialized
INFO - 2018-01-18 13:34:32 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:34:32 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:34:32 --> Utf8 Class Initialized
INFO - 2018-01-18 13:34:32 --> URI Class Initialized
INFO - 2018-01-18 13:34:32 --> Router Class Initialized
INFO - 2018-01-18 13:34:32 --> Output Class Initialized
INFO - 2018-01-18 13:34:32 --> Security Class Initialized
DEBUG - 2018-01-18 13:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:34:32 --> Input Class Initialized
INFO - 2018-01-18 13:34:32 --> Language Class Initialized
ERROR - 2018-01-18 13:34:32 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:34:32 --> Config Class Initialized
INFO - 2018-01-18 13:34:32 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:34:32 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:34:32 --> Utf8 Class Initialized
INFO - 2018-01-18 13:34:32 --> URI Class Initialized
INFO - 2018-01-18 13:34:32 --> Router Class Initialized
INFO - 2018-01-18 13:34:32 --> Output Class Initialized
INFO - 2018-01-18 13:34:32 --> Security Class Initialized
DEBUG - 2018-01-18 13:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:34:32 --> Input Class Initialized
INFO - 2018-01-18 13:34:32 --> Language Class Initialized
ERROR - 2018-01-18 13:34:32 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:38:48 --> Config Class Initialized
INFO - 2018-01-18 13:38:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:38:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:38:48 --> Utf8 Class Initialized
INFO - 2018-01-18 13:38:48 --> URI Class Initialized
INFO - 2018-01-18 13:38:48 --> Router Class Initialized
INFO - 2018-01-18 13:38:48 --> Output Class Initialized
INFO - 2018-01-18 13:38:48 --> Security Class Initialized
DEBUG - 2018-01-18 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:38:48 --> Input Class Initialized
INFO - 2018-01-18 13:38:48 --> Language Class Initialized
INFO - 2018-01-18 13:38:48 --> Loader Class Initialized
INFO - 2018-01-18 13:38:48 --> Helper loaded: url_helper
INFO - 2018-01-18 13:38:48 --> Helper loaded: form_helper
INFO - 2018-01-18 13:38:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:38:48 --> Form Validation Class Initialized
INFO - 2018-01-18 13:38:48 --> Model Class Initialized
INFO - 2018-01-18 13:38:48 --> Controller Class Initialized
INFO - 2018-01-18 13:38:48 --> Model Class Initialized
INFO - 2018-01-18 13:38:48 --> Model Class Initialized
INFO - 2018-01-18 13:38:48 --> Model Class Initialized
INFO - 2018-01-18 13:38:48 --> Model Class Initialized
DEBUG - 2018-01-18 13:38:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:38:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:38:48 --> Final output sent to browser
DEBUG - 2018-01-18 13:38:48 --> Total execution time: 0.1062
INFO - 2018-01-18 13:38:49 --> Config Class Initialized
INFO - 2018-01-18 13:38:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:38:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:38:49 --> Utf8 Class Initialized
INFO - 2018-01-18 13:38:49 --> URI Class Initialized
INFO - 2018-01-18 13:38:49 --> Router Class Initialized
INFO - 2018-01-18 13:38:49 --> Output Class Initialized
INFO - 2018-01-18 13:38:49 --> Security Class Initialized
DEBUG - 2018-01-18 13:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:38:49 --> Input Class Initialized
INFO - 2018-01-18 13:38:49 --> Language Class Initialized
ERROR - 2018-01-18 13:38:49 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:38:50 --> Config Class Initialized
INFO - 2018-01-18 13:38:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:38:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:38:50 --> Utf8 Class Initialized
INFO - 2018-01-18 13:38:50 --> URI Class Initialized
INFO - 2018-01-18 13:38:50 --> Router Class Initialized
INFO - 2018-01-18 13:38:50 --> Output Class Initialized
INFO - 2018-01-18 13:38:50 --> Security Class Initialized
DEBUG - 2018-01-18 13:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:38:50 --> Input Class Initialized
INFO - 2018-01-18 13:38:50 --> Language Class Initialized
ERROR - 2018-01-18 13:38:50 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:41:18 --> Config Class Initialized
INFO - 2018-01-18 13:41:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:18 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:18 --> URI Class Initialized
INFO - 2018-01-18 13:41:18 --> Router Class Initialized
INFO - 2018-01-18 13:41:18 --> Output Class Initialized
INFO - 2018-01-18 13:41:18 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:18 --> Input Class Initialized
INFO - 2018-01-18 13:41:18 --> Language Class Initialized
INFO - 2018-01-18 13:41:18 --> Loader Class Initialized
INFO - 2018-01-18 13:41:18 --> Helper loaded: url_helper
INFO - 2018-01-18 13:41:18 --> Helper loaded: form_helper
INFO - 2018-01-18 13:41:18 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:41:18 --> Form Validation Class Initialized
INFO - 2018-01-18 13:41:18 --> Model Class Initialized
INFO - 2018-01-18 13:41:18 --> Controller Class Initialized
INFO - 2018-01-18 13:41:18 --> Model Class Initialized
INFO - 2018-01-18 13:41:18 --> Model Class Initialized
INFO - 2018-01-18 13:41:18 --> Model Class Initialized
INFO - 2018-01-18 13:41:18 --> Model Class Initialized
DEBUG - 2018-01-18 13:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:41:18 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:41:18 --> Final output sent to browser
DEBUG - 2018-01-18 13:41:18 --> Total execution time: 0.0615
INFO - 2018-01-18 13:41:19 --> Config Class Initialized
INFO - 2018-01-18 13:41:19 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:19 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:19 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:19 --> URI Class Initialized
INFO - 2018-01-18 13:41:19 --> Router Class Initialized
INFO - 2018-01-18 13:41:19 --> Output Class Initialized
INFO - 2018-01-18 13:41:19 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:19 --> Input Class Initialized
INFO - 2018-01-18 13:41:19 --> Language Class Initialized
INFO - 2018-01-18 13:41:19 --> Loader Class Initialized
INFO - 2018-01-18 13:41:19 --> Helper loaded: url_helper
INFO - 2018-01-18 13:41:19 --> Helper loaded: form_helper
INFO - 2018-01-18 13:41:19 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:41:19 --> Form Validation Class Initialized
INFO - 2018-01-18 13:41:19 --> Model Class Initialized
INFO - 2018-01-18 13:41:19 --> Controller Class Initialized
INFO - 2018-01-18 13:41:19 --> Model Class Initialized
INFO - 2018-01-18 13:41:19 --> Model Class Initialized
INFO - 2018-01-18 13:41:19 --> Model Class Initialized
INFO - 2018-01-18 13:41:19 --> Model Class Initialized
DEBUG - 2018-01-18 13:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:41:24 --> Config Class Initialized
INFO - 2018-01-18 13:41:24 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:24 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:24 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:24 --> URI Class Initialized
INFO - 2018-01-18 13:41:24 --> Router Class Initialized
INFO - 2018-01-18 13:41:24 --> Output Class Initialized
INFO - 2018-01-18 13:41:24 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:24 --> Input Class Initialized
INFO - 2018-01-18 13:41:24 --> Language Class Initialized
INFO - 2018-01-18 13:41:24 --> Loader Class Initialized
INFO - 2018-01-18 13:41:24 --> Helper loaded: url_helper
INFO - 2018-01-18 13:41:24 --> Helper loaded: form_helper
INFO - 2018-01-18 13:41:24 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:41:24 --> Form Validation Class Initialized
INFO - 2018-01-18 13:41:24 --> Model Class Initialized
INFO - 2018-01-18 13:41:24 --> Controller Class Initialized
INFO - 2018-01-18 13:41:24 --> Model Class Initialized
INFO - 2018-01-18 13:41:24 --> Model Class Initialized
INFO - 2018-01-18 13:41:24 --> Model Class Initialized
INFO - 2018-01-18 13:41:24 --> Model Class Initialized
DEBUG - 2018-01-18 13:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:41:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:41:24 --> Final output sent to browser
DEBUG - 2018-01-18 13:41:24 --> Total execution time: 0.1025
INFO - 2018-01-18 13:41:25 --> Config Class Initialized
INFO - 2018-01-18 13:41:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:25 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:25 --> URI Class Initialized
INFO - 2018-01-18 13:41:25 --> Router Class Initialized
INFO - 2018-01-18 13:41:25 --> Output Class Initialized
INFO - 2018-01-18 13:41:25 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:25 --> Input Class Initialized
INFO - 2018-01-18 13:41:25 --> Language Class Initialized
ERROR - 2018-01-18 13:41:25 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:41:30 --> Config Class Initialized
INFO - 2018-01-18 13:41:30 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:30 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:30 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:30 --> URI Class Initialized
INFO - 2018-01-18 13:41:30 --> Router Class Initialized
INFO - 2018-01-18 13:41:30 --> Output Class Initialized
INFO - 2018-01-18 13:41:30 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:30 --> Input Class Initialized
INFO - 2018-01-18 13:41:30 --> Language Class Initialized
INFO - 2018-01-18 13:41:30 --> Loader Class Initialized
INFO - 2018-01-18 13:41:30 --> Helper loaded: url_helper
INFO - 2018-01-18 13:41:30 --> Helper loaded: form_helper
INFO - 2018-01-18 13:41:30 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:41:30 --> Form Validation Class Initialized
INFO - 2018-01-18 13:41:30 --> Model Class Initialized
INFO - 2018-01-18 13:41:30 --> Controller Class Initialized
INFO - 2018-01-18 13:41:30 --> Model Class Initialized
INFO - 2018-01-18 13:41:30 --> Model Class Initialized
INFO - 2018-01-18 13:41:30 --> Model Class Initialized
INFO - 2018-01-18 13:41:30 --> Model Class Initialized
DEBUG - 2018-01-18 13:41:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:41:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:41:30 --> Final output sent to browser
DEBUG - 2018-01-18 13:41:30 --> Total execution time: 0.0554
INFO - 2018-01-18 13:41:30 --> Config Class Initialized
INFO - 2018-01-18 13:41:30 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:41:30 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:41:30 --> Utf8 Class Initialized
INFO - 2018-01-18 13:41:30 --> URI Class Initialized
INFO - 2018-01-18 13:41:30 --> Router Class Initialized
INFO - 2018-01-18 13:41:30 --> Output Class Initialized
INFO - 2018-01-18 13:41:30 --> Security Class Initialized
DEBUG - 2018-01-18 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:41:30 --> Input Class Initialized
INFO - 2018-01-18 13:41:30 --> Language Class Initialized
ERROR - 2018-01-18 13:41:30 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:42:26 --> Config Class Initialized
INFO - 2018-01-18 13:42:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:26 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:26 --> URI Class Initialized
INFO - 2018-01-18 13:42:26 --> Router Class Initialized
INFO - 2018-01-18 13:42:26 --> Output Class Initialized
INFO - 2018-01-18 13:42:26 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:26 --> Input Class Initialized
INFO - 2018-01-18 13:42:26 --> Language Class Initialized
INFO - 2018-01-18 13:42:26 --> Loader Class Initialized
INFO - 2018-01-18 13:42:26 --> Helper loaded: url_helper
INFO - 2018-01-18 13:42:26 --> Helper loaded: form_helper
INFO - 2018-01-18 13:42:26 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:42:26 --> Form Validation Class Initialized
INFO - 2018-01-18 13:42:26 --> Model Class Initialized
INFO - 2018-01-18 13:42:26 --> Controller Class Initialized
INFO - 2018-01-18 13:42:26 --> Model Class Initialized
INFO - 2018-01-18 13:42:26 --> Model Class Initialized
INFO - 2018-01-18 13:42:26 --> Model Class Initialized
INFO - 2018-01-18 13:42:26 --> Model Class Initialized
DEBUG - 2018-01-18 13:42:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 13:42:26 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:42:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:42:26 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:42:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:42:26 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 13:42:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 13:42:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:42:26 --> Final output sent to browser
DEBUG - 2018-01-18 13:42:26 --> Total execution time: 0.0570
INFO - 2018-01-18 13:42:26 --> Config Class Initialized
INFO - 2018-01-18 13:42:26 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:26 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:26 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:26 --> URI Class Initialized
INFO - 2018-01-18 13:42:26 --> Router Class Initialized
INFO - 2018-01-18 13:42:26 --> Output Class Initialized
INFO - 2018-01-18 13:42:26 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:26 --> Input Class Initialized
INFO - 2018-01-18 13:42:26 --> Language Class Initialized
ERROR - 2018-01-18 13:42:26 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:42:38 --> Config Class Initialized
INFO - 2018-01-18 13:42:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:38 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:38 --> URI Class Initialized
INFO - 2018-01-18 13:42:38 --> Router Class Initialized
INFO - 2018-01-18 13:42:38 --> Output Class Initialized
INFO - 2018-01-18 13:42:38 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:38 --> Input Class Initialized
INFO - 2018-01-18 13:42:38 --> Language Class Initialized
INFO - 2018-01-18 13:42:38 --> Loader Class Initialized
INFO - 2018-01-18 13:42:38 --> Helper loaded: url_helper
INFO - 2018-01-18 13:42:38 --> Helper loaded: form_helper
INFO - 2018-01-18 13:42:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:42:38 --> Form Validation Class Initialized
INFO - 2018-01-18 13:42:38 --> Model Class Initialized
INFO - 2018-01-18 13:42:38 --> Controller Class Initialized
INFO - 2018-01-18 13:42:38 --> Model Class Initialized
INFO - 2018-01-18 13:42:38 --> Model Class Initialized
INFO - 2018-01-18 13:42:38 --> Model Class Initialized
INFO - 2018-01-18 13:42:38 --> Model Class Initialized
DEBUG - 2018-01-18 13:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:42:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:42:38 --> Final output sent to browser
DEBUG - 2018-01-18 13:42:38 --> Total execution time: 0.0647
INFO - 2018-01-18 13:42:39 --> Config Class Initialized
INFO - 2018-01-18 13:42:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:39 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:39 --> URI Class Initialized
INFO - 2018-01-18 13:42:39 --> Router Class Initialized
INFO - 2018-01-18 13:42:39 --> Output Class Initialized
INFO - 2018-01-18 13:42:39 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:39 --> Input Class Initialized
INFO - 2018-01-18 13:42:39 --> Language Class Initialized
ERROR - 2018-01-18 13:42:39 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:42:49 --> Config Class Initialized
INFO - 2018-01-18 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:49 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:49 --> URI Class Initialized
INFO - 2018-01-18 13:42:49 --> Router Class Initialized
INFO - 2018-01-18 13:42:49 --> Output Class Initialized
INFO - 2018-01-18 13:42:49 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:49 --> Input Class Initialized
INFO - 2018-01-18 13:42:49 --> Language Class Initialized
INFO - 2018-01-18 13:42:49 --> Loader Class Initialized
INFO - 2018-01-18 13:42:49 --> Helper loaded: url_helper
INFO - 2018-01-18 13:42:49 --> Helper loaded: form_helper
INFO - 2018-01-18 13:42:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:42:49 --> Form Validation Class Initialized
INFO - 2018-01-18 13:42:49 --> Model Class Initialized
INFO - 2018-01-18 13:42:49 --> Controller Class Initialized
INFO - 2018-01-18 13:42:49 --> Model Class Initialized
INFO - 2018-01-18 13:42:49 --> Model Class Initialized
INFO - 2018-01-18 13:42:49 --> Model Class Initialized
INFO - 2018-01-18 13:42:49 --> Model Class Initialized
DEBUG - 2018-01-18 13:42:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 13:42:49 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:42:49 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:42:49 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 13:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 13:42:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:42:49 --> Final output sent to browser
DEBUG - 2018-01-18 13:42:49 --> Total execution time: 0.0744
INFO - 2018-01-18 13:42:49 --> Config Class Initialized
INFO - 2018-01-18 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:49 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:49 --> URI Class Initialized
INFO - 2018-01-18 13:42:49 --> Router Class Initialized
INFO - 2018-01-18 13:42:49 --> Output Class Initialized
INFO - 2018-01-18 13:42:49 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:49 --> Input Class Initialized
INFO - 2018-01-18 13:42:49 --> Language Class Initialized
ERROR - 2018-01-18 13:42:49 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:42:56 --> Config Class Initialized
INFO - 2018-01-18 13:42:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:42:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:42:56 --> Utf8 Class Initialized
INFO - 2018-01-18 13:42:56 --> URI Class Initialized
INFO - 2018-01-18 13:42:56 --> Router Class Initialized
INFO - 2018-01-18 13:42:56 --> Output Class Initialized
INFO - 2018-01-18 13:42:56 --> Security Class Initialized
DEBUG - 2018-01-18 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:42:56 --> Input Class Initialized
INFO - 2018-01-18 13:42:56 --> Language Class Initialized
INFO - 2018-01-18 13:42:56 --> Loader Class Initialized
INFO - 2018-01-18 13:42:56 --> Helper loaded: url_helper
INFO - 2018-01-18 13:42:56 --> Helper loaded: form_helper
INFO - 2018-01-18 13:42:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:42:56 --> Form Validation Class Initialized
INFO - 2018-01-18 13:42:56 --> Model Class Initialized
INFO - 2018-01-18 13:42:56 --> Controller Class Initialized
INFO - 2018-01-18 13:42:56 --> Model Class Initialized
INFO - 2018-01-18 13:42:56 --> Model Class Initialized
INFO - 2018-01-18 13:42:56 --> Model Class Initialized
INFO - 2018-01-18 13:42:56 --> Model Class Initialized
DEBUG - 2018-01-18 13:42:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:42:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:42:56 --> Final output sent to browser
DEBUG - 2018-01-18 13:42:56 --> Total execution time: 0.0753
INFO - 2018-01-18 13:43:36 --> Config Class Initialized
INFO - 2018-01-18 13:43:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:43:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:43:36 --> Utf8 Class Initialized
INFO - 2018-01-18 13:43:36 --> URI Class Initialized
INFO - 2018-01-18 13:43:36 --> Router Class Initialized
INFO - 2018-01-18 13:43:36 --> Output Class Initialized
INFO - 2018-01-18 13:43:36 --> Security Class Initialized
DEBUG - 2018-01-18 13:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:43:36 --> Input Class Initialized
INFO - 2018-01-18 13:43:36 --> Language Class Initialized
INFO - 2018-01-18 13:43:36 --> Loader Class Initialized
INFO - 2018-01-18 13:43:36 --> Helper loaded: url_helper
INFO - 2018-01-18 13:43:36 --> Helper loaded: form_helper
INFO - 2018-01-18 13:43:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:43:36 --> Form Validation Class Initialized
INFO - 2018-01-18 13:43:36 --> Model Class Initialized
INFO - 2018-01-18 13:43:36 --> Controller Class Initialized
INFO - 2018-01-18 13:43:36 --> Model Class Initialized
INFO - 2018-01-18 13:43:36 --> Model Class Initialized
INFO - 2018-01-18 13:43:36 --> Model Class Initialized
INFO - 2018-01-18 13:43:36 --> Model Class Initialized
DEBUG - 2018-01-18 13:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:43:37 --> Config Class Initialized
INFO - 2018-01-18 13:43:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:43:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:43:37 --> Utf8 Class Initialized
INFO - 2018-01-18 13:43:37 --> URI Class Initialized
INFO - 2018-01-18 13:43:37 --> Router Class Initialized
INFO - 2018-01-18 13:43:37 --> Output Class Initialized
INFO - 2018-01-18 13:43:37 --> Security Class Initialized
DEBUG - 2018-01-18 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:43:37 --> Input Class Initialized
INFO - 2018-01-18 13:43:37 --> Language Class Initialized
INFO - 2018-01-18 13:43:37 --> Loader Class Initialized
INFO - 2018-01-18 13:43:37 --> Helper loaded: url_helper
INFO - 2018-01-18 13:43:37 --> Helper loaded: form_helper
INFO - 2018-01-18 13:43:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:43:37 --> Form Validation Class Initialized
INFO - 2018-01-18 13:43:37 --> Model Class Initialized
INFO - 2018-01-18 13:43:37 --> Controller Class Initialized
INFO - 2018-01-18 13:43:37 --> Model Class Initialized
INFO - 2018-01-18 13:43:37 --> Model Class Initialized
INFO - 2018-01-18 13:43:37 --> Model Class Initialized
INFO - 2018-01-18 13:43:37 --> Model Class Initialized
DEBUG - 2018-01-18 13:43:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 13:43:37 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 13:43:37 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 13:43:37 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 13:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 13:43:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:43:37 --> Final output sent to browser
DEBUG - 2018-01-18 13:43:37 --> Total execution time: 0.0610
INFO - 2018-01-18 13:43:37 --> Config Class Initialized
INFO - 2018-01-18 13:43:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:43:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:43:37 --> Utf8 Class Initialized
INFO - 2018-01-18 13:43:37 --> URI Class Initialized
INFO - 2018-01-18 13:43:37 --> Router Class Initialized
INFO - 2018-01-18 13:43:37 --> Output Class Initialized
INFO - 2018-01-18 13:43:37 --> Security Class Initialized
DEBUG - 2018-01-18 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:43:37 --> Input Class Initialized
INFO - 2018-01-18 13:43:37 --> Language Class Initialized
ERROR - 2018-01-18 13:43:37 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:43:50 --> Config Class Initialized
INFO - 2018-01-18 13:43:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:43:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:43:50 --> Utf8 Class Initialized
INFO - 2018-01-18 13:43:50 --> URI Class Initialized
INFO - 2018-01-18 13:43:50 --> Router Class Initialized
INFO - 2018-01-18 13:43:50 --> Output Class Initialized
INFO - 2018-01-18 13:43:50 --> Security Class Initialized
DEBUG - 2018-01-18 13:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:43:50 --> Input Class Initialized
INFO - 2018-01-18 13:43:50 --> Language Class Initialized
INFO - 2018-01-18 13:43:50 --> Loader Class Initialized
INFO - 2018-01-18 13:43:50 --> Helper loaded: url_helper
INFO - 2018-01-18 13:43:50 --> Helper loaded: form_helper
INFO - 2018-01-18 13:43:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:43:50 --> Form Validation Class Initialized
INFO - 2018-01-18 13:43:50 --> Model Class Initialized
INFO - 2018-01-18 13:43:50 --> Controller Class Initialized
INFO - 2018-01-18 13:43:50 --> Model Class Initialized
INFO - 2018-01-18 13:43:50 --> Model Class Initialized
INFO - 2018-01-18 13:43:50 --> Model Class Initialized
INFO - 2018-01-18 13:43:50 --> Model Class Initialized
DEBUG - 2018-01-18 13:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:43:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:43:50 --> Final output sent to browser
DEBUG - 2018-01-18 13:43:50 --> Total execution time: 0.0507
INFO - 2018-01-18 13:43:50 --> Config Class Initialized
INFO - 2018-01-18 13:43:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:43:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:43:50 --> Utf8 Class Initialized
INFO - 2018-01-18 13:43:50 --> URI Class Initialized
INFO - 2018-01-18 13:43:50 --> Router Class Initialized
INFO - 2018-01-18 13:43:50 --> Output Class Initialized
INFO - 2018-01-18 13:43:50 --> Security Class Initialized
DEBUG - 2018-01-18 13:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:43:50 --> Input Class Initialized
INFO - 2018-01-18 13:43:50 --> Language Class Initialized
ERROR - 2018-01-18 13:43:50 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:44:48 --> Config Class Initialized
INFO - 2018-01-18 13:44:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:44:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:44:48 --> Utf8 Class Initialized
INFO - 2018-01-18 13:44:48 --> URI Class Initialized
DEBUG - 2018-01-18 13:44:48 --> No URI present. Default controller set.
INFO - 2018-01-18 13:44:48 --> Router Class Initialized
INFO - 2018-01-18 13:44:48 --> Output Class Initialized
INFO - 2018-01-18 13:44:48 --> Security Class Initialized
DEBUG - 2018-01-18 13:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:44:48 --> Input Class Initialized
INFO - 2018-01-18 13:44:48 --> Language Class Initialized
INFO - 2018-01-18 13:44:48 --> Loader Class Initialized
INFO - 2018-01-18 13:44:48 --> Helper loaded: url_helper
INFO - 2018-01-18 13:44:48 --> Helper loaded: form_helper
INFO - 2018-01-18 13:44:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:44:48 --> Form Validation Class Initialized
INFO - 2018-01-18 13:44:48 --> Model Class Initialized
INFO - 2018-01-18 13:44:48 --> Controller Class Initialized
INFO - 2018-01-18 13:44:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:44:48 --> Final output sent to browser
DEBUG - 2018-01-18 13:44:48 --> Total execution time: 0.0373
INFO - 2018-01-18 13:44:57 --> Config Class Initialized
INFO - 2018-01-18 13:44:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:44:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:44:57 --> Utf8 Class Initialized
INFO - 2018-01-18 13:44:57 --> URI Class Initialized
INFO - 2018-01-18 13:44:57 --> Router Class Initialized
INFO - 2018-01-18 13:44:57 --> Output Class Initialized
INFO - 2018-01-18 13:44:57 --> Security Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:44:57 --> Input Class Initialized
INFO - 2018-01-18 13:44:57 --> Language Class Initialized
INFO - 2018-01-18 13:44:57 --> Loader Class Initialized
INFO - 2018-01-18 13:44:57 --> Helper loaded: url_helper
INFO - 2018-01-18 13:44:57 --> Helper loaded: form_helper
INFO - 2018-01-18 13:44:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:44:57 --> Form Validation Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Controller Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:44:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:44:57 --> Final output sent to browser
DEBUG - 2018-01-18 13:44:57 --> Total execution time: 0.0476
INFO - 2018-01-18 13:44:57 --> Config Class Initialized
INFO - 2018-01-18 13:44:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:44:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:44:57 --> Utf8 Class Initialized
INFO - 2018-01-18 13:44:57 --> URI Class Initialized
INFO - 2018-01-18 13:44:57 --> Router Class Initialized
INFO - 2018-01-18 13:44:57 --> Output Class Initialized
INFO - 2018-01-18 13:44:57 --> Security Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:44:57 --> Input Class Initialized
INFO - 2018-01-18 13:44:57 --> Language Class Initialized
INFO - 2018-01-18 13:44:57 --> Loader Class Initialized
INFO - 2018-01-18 13:44:57 --> Helper loaded: url_helper
INFO - 2018-01-18 13:44:57 --> Helper loaded: form_helper
INFO - 2018-01-18 13:44:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:44:57 --> Form Validation Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Controller Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
INFO - 2018-01-18 13:44:57 --> Model Class Initialized
DEBUG - 2018-01-18 13:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:45:05 --> Config Class Initialized
INFO - 2018-01-18 13:45:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:45:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:45:05 --> Utf8 Class Initialized
INFO - 2018-01-18 13:45:05 --> URI Class Initialized
INFO - 2018-01-18 13:45:05 --> Router Class Initialized
INFO - 2018-01-18 13:45:05 --> Output Class Initialized
INFO - 2018-01-18 13:45:05 --> Security Class Initialized
DEBUG - 2018-01-18 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:45:05 --> Input Class Initialized
INFO - 2018-01-18 13:45:05 --> Language Class Initialized
INFO - 2018-01-18 13:45:05 --> Loader Class Initialized
INFO - 2018-01-18 13:45:05 --> Helper loaded: url_helper
INFO - 2018-01-18 13:45:05 --> Helper loaded: form_helper
INFO - 2018-01-18 13:45:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:45:05 --> Form Validation Class Initialized
INFO - 2018-01-18 13:45:05 --> Model Class Initialized
INFO - 2018-01-18 13:45:05 --> Controller Class Initialized
INFO - 2018-01-18 13:45:05 --> Model Class Initialized
INFO - 2018-01-18 13:45:05 --> Model Class Initialized
INFO - 2018-01-18 13:45:05 --> Model Class Initialized
INFO - 2018-01-18 13:45:05 --> Model Class Initialized
DEBUG - 2018-01-18 13:45:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:45:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:45:05 --> Final output sent to browser
DEBUG - 2018-01-18 13:45:05 --> Total execution time: 0.0602
INFO - 2018-01-18 13:45:05 --> Config Class Initialized
INFO - 2018-01-18 13:45:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:45:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:45:05 --> Utf8 Class Initialized
INFO - 2018-01-18 13:45:05 --> URI Class Initialized
INFO - 2018-01-18 13:45:05 --> Router Class Initialized
INFO - 2018-01-18 13:45:05 --> Output Class Initialized
INFO - 2018-01-18 13:45:05 --> Security Class Initialized
DEBUG - 2018-01-18 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:45:05 --> Input Class Initialized
INFO - 2018-01-18 13:45:05 --> Language Class Initialized
ERROR - 2018-01-18 13:45:05 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:59:05 --> Config Class Initialized
INFO - 2018-01-18 13:59:05 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:59:05 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:59:05 --> Utf8 Class Initialized
INFO - 2018-01-18 13:59:05 --> URI Class Initialized
INFO - 2018-01-18 13:59:05 --> Router Class Initialized
INFO - 2018-01-18 13:59:05 --> Output Class Initialized
INFO - 2018-01-18 13:59:05 --> Security Class Initialized
DEBUG - 2018-01-18 13:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:59:05 --> Input Class Initialized
INFO - 2018-01-18 13:59:05 --> Language Class Initialized
INFO - 2018-01-18 13:59:05 --> Loader Class Initialized
INFO - 2018-01-18 13:59:05 --> Helper loaded: url_helper
INFO - 2018-01-18 13:59:05 --> Helper loaded: form_helper
INFO - 2018-01-18 13:59:05 --> Database Driver Class Initialized
DEBUG - 2018-01-18 13:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 13:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 13:59:05 --> Form Validation Class Initialized
INFO - 2018-01-18 13:59:05 --> Model Class Initialized
INFO - 2018-01-18 13:59:05 --> Controller Class Initialized
INFO - 2018-01-18 13:59:05 --> Model Class Initialized
INFO - 2018-01-18 13:59:05 --> Model Class Initialized
INFO - 2018-01-18 13:59:05 --> Model Class Initialized
INFO - 2018-01-18 13:59:05 --> Model Class Initialized
DEBUG - 2018-01-18 13:59:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 13:59:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 13:59:05 --> Final output sent to browser
DEBUG - 2018-01-18 13:59:05 --> Total execution time: 0.0558
INFO - 2018-01-18 13:59:06 --> Config Class Initialized
INFO - 2018-01-18 13:59:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 13:59:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:59:06 --> Utf8 Class Initialized
INFO - 2018-01-18 13:59:06 --> URI Class Initialized
INFO - 2018-01-18 13:59:06 --> Config Class Initialized
INFO - 2018-01-18 13:59:06 --> Hooks Class Initialized
INFO - 2018-01-18 13:59:06 --> Router Class Initialized
DEBUG - 2018-01-18 13:59:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 13:59:06 --> Utf8 Class Initialized
INFO - 2018-01-18 13:59:06 --> Output Class Initialized
INFO - 2018-01-18 13:59:06 --> URI Class Initialized
INFO - 2018-01-18 13:59:06 --> Security Class Initialized
INFO - 2018-01-18 13:59:06 --> Router Class Initialized
DEBUG - 2018-01-18 13:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:59:06 --> Input Class Initialized
INFO - 2018-01-18 13:59:06 --> Language Class Initialized
ERROR - 2018-01-18 13:59:06 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 13:59:06 --> Output Class Initialized
INFO - 2018-01-18 13:59:06 --> Security Class Initialized
DEBUG - 2018-01-18 13:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 13:59:06 --> Input Class Initialized
INFO - 2018-01-18 13:59:06 --> Language Class Initialized
ERROR - 2018-01-18 13:59:06 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 14:03:48 --> Config Class Initialized
INFO - 2018-01-18 14:03:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 14:03:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 14:03:48 --> Utf8 Class Initialized
INFO - 2018-01-18 14:03:48 --> URI Class Initialized
DEBUG - 2018-01-18 14:03:48 --> No URI present. Default controller set.
INFO - 2018-01-18 14:03:48 --> Router Class Initialized
INFO - 2018-01-18 14:03:48 --> Output Class Initialized
INFO - 2018-01-18 14:03:48 --> Security Class Initialized
DEBUG - 2018-01-18 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 14:03:48 --> Input Class Initialized
INFO - 2018-01-18 14:03:48 --> Language Class Initialized
INFO - 2018-01-18 14:03:48 --> Loader Class Initialized
INFO - 2018-01-18 14:03:48 --> Helper loaded: url_helper
INFO - 2018-01-18 14:03:48 --> Helper loaded: form_helper
INFO - 2018-01-18 14:03:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 14:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 14:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 14:03:48 --> Form Validation Class Initialized
INFO - 2018-01-18 14:03:48 --> Model Class Initialized
INFO - 2018-01-18 14:03:48 --> Controller Class Initialized
INFO - 2018-01-18 14:03:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 14:03:48 --> Final output sent to browser
DEBUG - 2018-01-18 14:03:48 --> Total execution time: 0.0357
INFO - 2018-01-18 15:50:38 --> Config Class Initialized
INFO - 2018-01-18 15:50:38 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:50:38 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:50:38 --> Utf8 Class Initialized
INFO - 2018-01-18 15:50:38 --> URI Class Initialized
DEBUG - 2018-01-18 15:50:38 --> No URI present. Default controller set.
INFO - 2018-01-18 15:50:38 --> Router Class Initialized
INFO - 2018-01-18 15:50:38 --> Output Class Initialized
INFO - 2018-01-18 15:50:38 --> Security Class Initialized
DEBUG - 2018-01-18 15:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:50:38 --> Input Class Initialized
INFO - 2018-01-18 15:50:38 --> Language Class Initialized
INFO - 2018-01-18 15:50:38 --> Loader Class Initialized
INFO - 2018-01-18 15:50:38 --> Helper loaded: url_helper
INFO - 2018-01-18 15:50:38 --> Helper loaded: form_helper
INFO - 2018-01-18 15:50:38 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:50:38 --> Form Validation Class Initialized
INFO - 2018-01-18 15:50:38 --> Model Class Initialized
INFO - 2018-01-18 15:50:38 --> Controller Class Initialized
INFO - 2018-01-18 15:50:39 --> Config Class Initialized
INFO - 2018-01-18 15:50:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:50:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:50:39 --> Utf8 Class Initialized
INFO - 2018-01-18 15:50:39 --> URI Class Initialized
INFO - 2018-01-18 15:50:39 --> Router Class Initialized
INFO - 2018-01-18 15:50:39 --> Output Class Initialized
INFO - 2018-01-18 15:50:39 --> Security Class Initialized
DEBUG - 2018-01-18 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:50:39 --> Input Class Initialized
INFO - 2018-01-18 15:50:39 --> Language Class Initialized
INFO - 2018-01-18 15:50:39 --> Loader Class Initialized
INFO - 2018-01-18 15:50:39 --> Helper loaded: url_helper
INFO - 2018-01-18 15:50:39 --> Helper loaded: form_helper
INFO - 2018-01-18 15:50:39 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:50:39 --> Form Validation Class Initialized
INFO - 2018-01-18 15:50:39 --> Model Class Initialized
INFO - 2018-01-18 15:50:39 --> Controller Class Initialized
INFO - 2018-01-18 15:50:39 --> Model Class Initialized
DEBUG - 2018-01-18 15:50:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:50:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:50:39 --> Final output sent to browser
DEBUG - 2018-01-18 15:50:39 --> Total execution time: 0.0405
INFO - 2018-01-18 15:51:47 --> Config Class Initialized
INFO - 2018-01-18 15:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 15:51:47 --> URI Class Initialized
INFO - 2018-01-18 15:51:47 --> Router Class Initialized
INFO - 2018-01-18 15:51:47 --> Output Class Initialized
INFO - 2018-01-18 15:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:51:47 --> Input Class Initialized
INFO - 2018-01-18 15:51:47 --> Language Class Initialized
INFO - 2018-01-18 15:51:47 --> Loader Class Initialized
INFO - 2018-01-18 15:51:47 --> Helper loaded: url_helper
INFO - 2018-01-18 15:51:47 --> Helper loaded: form_helper
INFO - 2018-01-18 15:51:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:51:47 --> Form Validation Class Initialized
INFO - 2018-01-18 15:51:47 --> Model Class Initialized
INFO - 2018-01-18 15:51:47 --> Controller Class Initialized
INFO - 2018-01-18 15:51:47 --> Model Class Initialized
DEBUG - 2018-01-18 15:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:51:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 15:51:47 --> Config Class Initialized
INFO - 2018-01-18 15:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 15:51:47 --> URI Class Initialized
DEBUG - 2018-01-18 15:51:47 --> No URI present. Default controller set.
INFO - 2018-01-18 15:51:47 --> Router Class Initialized
INFO - 2018-01-18 15:51:47 --> Output Class Initialized
INFO - 2018-01-18 15:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:51:47 --> Input Class Initialized
INFO - 2018-01-18 15:51:47 --> Language Class Initialized
INFO - 2018-01-18 15:51:47 --> Loader Class Initialized
INFO - 2018-01-18 15:51:47 --> Helper loaded: url_helper
INFO - 2018-01-18 15:51:47 --> Helper loaded: form_helper
INFO - 2018-01-18 15:51:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:51:47 --> Form Validation Class Initialized
INFO - 2018-01-18 15:51:47 --> Model Class Initialized
INFO - 2018-01-18 15:51:47 --> Controller Class Initialized
INFO - 2018-01-18 15:51:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:51:47 --> Final output sent to browser
DEBUG - 2018-01-18 15:51:47 --> Total execution time: 0.0389
INFO - 2018-01-18 15:52:00 --> Config Class Initialized
INFO - 2018-01-18 15:52:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:00 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:00 --> URI Class Initialized
INFO - 2018-01-18 15:52:00 --> Router Class Initialized
INFO - 2018-01-18 15:52:00 --> Output Class Initialized
INFO - 2018-01-18 15:52:00 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:00 --> Input Class Initialized
INFO - 2018-01-18 15:52:00 --> Language Class Initialized
INFO - 2018-01-18 15:52:00 --> Loader Class Initialized
INFO - 2018-01-18 15:52:00 --> Helper loaded: url_helper
INFO - 2018-01-18 15:52:00 --> Helper loaded: form_helper
INFO - 2018-01-18 15:52:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:52:00 --> Form Validation Class Initialized
INFO - 2018-01-18 15:52:00 --> Model Class Initialized
INFO - 2018-01-18 15:52:00 --> Controller Class Initialized
INFO - 2018-01-18 15:52:00 --> Model Class Initialized
INFO - 2018-01-18 15:52:00 --> Model Class Initialized
INFO - 2018-01-18 15:52:00 --> Model Class Initialized
INFO - 2018-01-18 15:52:00 --> Model Class Initialized
DEBUG - 2018-01-18 15:52:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:52:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:52:00 --> Final output sent to browser
DEBUG - 2018-01-18 15:52:00 --> Total execution time: 0.0574
INFO - 2018-01-18 15:52:01 --> Config Class Initialized
INFO - 2018-01-18 15:52:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:01 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:01 --> URI Class Initialized
INFO - 2018-01-18 15:52:01 --> Router Class Initialized
INFO - 2018-01-18 15:52:01 --> Output Class Initialized
INFO - 2018-01-18 15:52:01 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:01 --> Input Class Initialized
INFO - 2018-01-18 15:52:01 --> Language Class Initialized
INFO - 2018-01-18 15:52:01 --> Loader Class Initialized
INFO - 2018-01-18 15:52:01 --> Helper loaded: url_helper
INFO - 2018-01-18 15:52:01 --> Helper loaded: form_helper
INFO - 2018-01-18 15:52:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:52:01 --> Form Validation Class Initialized
INFO - 2018-01-18 15:52:01 --> Model Class Initialized
INFO - 2018-01-18 15:52:01 --> Controller Class Initialized
INFO - 2018-01-18 15:52:01 --> Model Class Initialized
INFO - 2018-01-18 15:52:01 --> Model Class Initialized
INFO - 2018-01-18 15:52:01 --> Model Class Initialized
INFO - 2018-01-18 15:52:01 --> Model Class Initialized
DEBUG - 2018-01-18 15:52:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:52:07 --> Config Class Initialized
INFO - 2018-01-18 15:52:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:07 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:07 --> URI Class Initialized
INFO - 2018-01-18 15:52:07 --> Router Class Initialized
INFO - 2018-01-18 15:52:07 --> Output Class Initialized
INFO - 2018-01-18 15:52:07 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:07 --> Input Class Initialized
INFO - 2018-01-18 15:52:07 --> Language Class Initialized
INFO - 2018-01-18 15:52:07 --> Loader Class Initialized
INFO - 2018-01-18 15:52:07 --> Helper loaded: url_helper
INFO - 2018-01-18 15:52:07 --> Helper loaded: form_helper
INFO - 2018-01-18 15:52:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:52:07 --> Form Validation Class Initialized
INFO - 2018-01-18 15:52:07 --> Model Class Initialized
INFO - 2018-01-18 15:52:07 --> Controller Class Initialized
INFO - 2018-01-18 15:52:07 --> Model Class Initialized
INFO - 2018-01-18 15:52:07 --> Model Class Initialized
INFO - 2018-01-18 15:52:07 --> Model Class Initialized
INFO - 2018-01-18 15:52:07 --> Model Class Initialized
DEBUG - 2018-01-18 15:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:52:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:52:07 --> Final output sent to browser
DEBUG - 2018-01-18 15:52:07 --> Total execution time: 0.0578
INFO - 2018-01-18 15:52:09 --> Config Class Initialized
INFO - 2018-01-18 15:52:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:09 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:09 --> URI Class Initialized
INFO - 2018-01-18 15:52:09 --> Router Class Initialized
INFO - 2018-01-18 15:52:09 --> Output Class Initialized
INFO - 2018-01-18 15:52:09 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:09 --> Input Class Initialized
INFO - 2018-01-18 15:52:09 --> Language Class Initialized
ERROR - 2018-01-18 15:52:09 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:52:11 --> Config Class Initialized
INFO - 2018-01-18 15:52:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:11 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:11 --> URI Class Initialized
INFO - 2018-01-18 15:52:11 --> Router Class Initialized
INFO - 2018-01-18 15:52:11 --> Output Class Initialized
INFO - 2018-01-18 15:52:11 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:11 --> Input Class Initialized
INFO - 2018-01-18 15:52:11 --> Language Class Initialized
INFO - 2018-01-18 15:52:11 --> Loader Class Initialized
INFO - 2018-01-18 15:52:11 --> Helper loaded: url_helper
INFO - 2018-01-18 15:52:11 --> Helper loaded: form_helper
INFO - 2018-01-18 15:52:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:52:11 --> Form Validation Class Initialized
INFO - 2018-01-18 15:52:11 --> Model Class Initialized
INFO - 2018-01-18 15:52:11 --> Controller Class Initialized
INFO - 2018-01-18 15:52:11 --> Model Class Initialized
INFO - 2018-01-18 15:52:11 --> Model Class Initialized
INFO - 2018-01-18 15:52:11 --> Model Class Initialized
INFO - 2018-01-18 15:52:11 --> Model Class Initialized
DEBUG - 2018-01-18 15:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:52:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:52:12 --> Final output sent to browser
DEBUG - 2018-01-18 15:52:12 --> Total execution time: 0.0545
INFO - 2018-01-18 15:52:12 --> Config Class Initialized
INFO - 2018-01-18 15:52:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:12 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:12 --> URI Class Initialized
INFO - 2018-01-18 15:52:12 --> Router Class Initialized
INFO - 2018-01-18 15:52:12 --> Output Class Initialized
INFO - 2018-01-18 15:52:12 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:12 --> Input Class Initialized
INFO - 2018-01-18 15:52:12 --> Language Class Initialized
ERROR - 2018-01-18 15:52:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:52:13 --> Config Class Initialized
INFO - 2018-01-18 15:52:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:13 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:13 --> URI Class Initialized
INFO - 2018-01-18 15:52:13 --> Router Class Initialized
INFO - 2018-01-18 15:52:13 --> Output Class Initialized
INFO - 2018-01-18 15:52:13 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:13 --> Input Class Initialized
INFO - 2018-01-18 15:52:13 --> Language Class Initialized
ERROR - 2018-01-18 15:52:13 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:52:23 --> Config Class Initialized
INFO - 2018-01-18 15:52:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:52:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:52:23 --> Utf8 Class Initialized
INFO - 2018-01-18 15:52:23 --> URI Class Initialized
INFO - 2018-01-18 15:52:23 --> Router Class Initialized
INFO - 2018-01-18 15:52:23 --> Output Class Initialized
INFO - 2018-01-18 15:52:23 --> Security Class Initialized
DEBUG - 2018-01-18 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:52:23 --> Input Class Initialized
INFO - 2018-01-18 15:52:23 --> Language Class Initialized
ERROR - 2018-01-18 15:52:23 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:53:49 --> Config Class Initialized
INFO - 2018-01-18 15:53:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:53:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:53:49 --> Utf8 Class Initialized
INFO - 2018-01-18 15:53:49 --> URI Class Initialized
INFO - 2018-01-18 15:53:49 --> Router Class Initialized
INFO - 2018-01-18 15:53:49 --> Output Class Initialized
INFO - 2018-01-18 15:53:49 --> Security Class Initialized
DEBUG - 2018-01-18 15:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:53:49 --> Input Class Initialized
INFO - 2018-01-18 15:53:49 --> Language Class Initialized
INFO - 2018-01-18 15:53:49 --> Loader Class Initialized
INFO - 2018-01-18 15:53:49 --> Helper loaded: url_helper
INFO - 2018-01-18 15:53:49 --> Helper loaded: form_helper
INFO - 2018-01-18 15:53:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:53:49 --> Form Validation Class Initialized
INFO - 2018-01-18 15:53:49 --> Model Class Initialized
INFO - 2018-01-18 15:53:49 --> Controller Class Initialized
INFO - 2018-01-18 15:53:49 --> Model Class Initialized
INFO - 2018-01-18 15:53:49 --> Model Class Initialized
INFO - 2018-01-18 15:53:49 --> Model Class Initialized
INFO - 2018-01-18 15:53:49 --> Model Class Initialized
DEBUG - 2018-01-18 15:53:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:53:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:53:49 --> Final output sent to browser
DEBUG - 2018-01-18 15:53:49 --> Total execution time: 0.1105
INFO - 2018-01-18 15:53:50 --> Config Class Initialized
INFO - 2018-01-18 15:53:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:53:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:53:50 --> Utf8 Class Initialized
INFO - 2018-01-18 15:53:50 --> URI Class Initialized
INFO - 2018-01-18 15:53:50 --> Router Class Initialized
INFO - 2018-01-18 15:53:50 --> Output Class Initialized
INFO - 2018-01-18 15:53:50 --> Security Class Initialized
DEBUG - 2018-01-18 15:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:53:50 --> Input Class Initialized
INFO - 2018-01-18 15:53:50 --> Language Class Initialized
ERROR - 2018-01-18 15:53:50 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:53:50 --> Config Class Initialized
INFO - 2018-01-18 15:53:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:53:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:53:50 --> Utf8 Class Initialized
INFO - 2018-01-18 15:53:50 --> URI Class Initialized
INFO - 2018-01-18 15:53:50 --> Router Class Initialized
INFO - 2018-01-18 15:53:50 --> Output Class Initialized
INFO - 2018-01-18 15:53:50 --> Security Class Initialized
DEBUG - 2018-01-18 15:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:53:50 --> Input Class Initialized
INFO - 2018-01-18 15:53:50 --> Language Class Initialized
ERROR - 2018-01-18 15:53:50 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:54:11 --> Config Class Initialized
INFO - 2018-01-18 15:54:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:11 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:11 --> URI Class Initialized
INFO - 2018-01-18 15:54:11 --> Router Class Initialized
INFO - 2018-01-18 15:54:11 --> Output Class Initialized
INFO - 2018-01-18 15:54:11 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:11 --> Input Class Initialized
INFO - 2018-01-18 15:54:11 --> Language Class Initialized
INFO - 2018-01-18 15:54:11 --> Loader Class Initialized
INFO - 2018-01-18 15:54:11 --> Helper loaded: url_helper
INFO - 2018-01-18 15:54:11 --> Helper loaded: form_helper
INFO - 2018-01-18 15:54:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:54:11 --> Form Validation Class Initialized
INFO - 2018-01-18 15:54:11 --> Model Class Initialized
INFO - 2018-01-18 15:54:11 --> Controller Class Initialized
INFO - 2018-01-18 15:54:11 --> Model Class Initialized
INFO - 2018-01-18 15:54:11 --> Model Class Initialized
INFO - 2018-01-18 15:54:11 --> Model Class Initialized
INFO - 2018-01-18 15:54:11 --> Model Class Initialized
DEBUG - 2018-01-18 15:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:54:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:54:11 --> Final output sent to browser
DEBUG - 2018-01-18 15:54:11 --> Total execution time: 0.0555
INFO - 2018-01-18 15:54:12 --> Config Class Initialized
INFO - 2018-01-18 15:54:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:12 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:12 --> URI Class Initialized
INFO - 2018-01-18 15:54:12 --> Router Class Initialized
INFO - 2018-01-18 15:54:12 --> Output Class Initialized
INFO - 2018-01-18 15:54:12 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:12 --> Input Class Initialized
INFO - 2018-01-18 15:54:12 --> Language Class Initialized
ERROR - 2018-01-18 15:54:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:54:17 --> Config Class Initialized
INFO - 2018-01-18 15:54:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:17 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:17 --> URI Class Initialized
INFO - 2018-01-18 15:54:17 --> Router Class Initialized
INFO - 2018-01-18 15:54:17 --> Output Class Initialized
INFO - 2018-01-18 15:54:17 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:17 --> Input Class Initialized
INFO - 2018-01-18 15:54:17 --> Language Class Initialized
INFO - 2018-01-18 15:54:17 --> Loader Class Initialized
INFO - 2018-01-18 15:54:17 --> Helper loaded: url_helper
INFO - 2018-01-18 15:54:17 --> Helper loaded: form_helper
INFO - 2018-01-18 15:54:17 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:54:17 --> Form Validation Class Initialized
INFO - 2018-01-18 15:54:17 --> Model Class Initialized
INFO - 2018-01-18 15:54:17 --> Controller Class Initialized
INFO - 2018-01-18 15:54:17 --> Model Class Initialized
INFO - 2018-01-18 15:54:17 --> Model Class Initialized
INFO - 2018-01-18 15:54:17 --> Model Class Initialized
INFO - 2018-01-18 15:54:17 --> Model Class Initialized
DEBUG - 2018-01-18 15:54:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 15:54:17 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:54:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:54:17 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:54:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:54:17 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 15:54:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 15:54:17 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:54:17 --> Final output sent to browser
DEBUG - 2018-01-18 15:54:17 --> Total execution time: 0.0575
INFO - 2018-01-18 15:54:18 --> Config Class Initialized
INFO - 2018-01-18 15:54:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:18 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:18 --> URI Class Initialized
INFO - 2018-01-18 15:54:18 --> Router Class Initialized
INFO - 2018-01-18 15:54:18 --> Output Class Initialized
INFO - 2018-01-18 15:54:18 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:18 --> Input Class Initialized
INFO - 2018-01-18 15:54:18 --> Language Class Initialized
ERROR - 2018-01-18 15:54:18 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:54:21 --> Config Class Initialized
INFO - 2018-01-18 15:54:21 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:21 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:21 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:21 --> URI Class Initialized
INFO - 2018-01-18 15:54:21 --> Router Class Initialized
INFO - 2018-01-18 15:54:21 --> Output Class Initialized
INFO - 2018-01-18 15:54:21 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:21 --> Input Class Initialized
INFO - 2018-01-18 15:54:21 --> Language Class Initialized
INFO - 2018-01-18 15:54:21 --> Loader Class Initialized
INFO - 2018-01-18 15:54:21 --> Helper loaded: url_helper
INFO - 2018-01-18 15:54:21 --> Helper loaded: form_helper
INFO - 2018-01-18 15:54:21 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:54:21 --> Form Validation Class Initialized
INFO - 2018-01-18 15:54:21 --> Model Class Initialized
INFO - 2018-01-18 15:54:21 --> Controller Class Initialized
INFO - 2018-01-18 15:54:21 --> Model Class Initialized
INFO - 2018-01-18 15:54:21 --> Model Class Initialized
INFO - 2018-01-18 15:54:21 --> Model Class Initialized
INFO - 2018-01-18 15:54:21 --> Model Class Initialized
DEBUG - 2018-01-18 15:54:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:54:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:54:21 --> Final output sent to browser
DEBUG - 2018-01-18 15:54:21 --> Total execution time: 0.0556
INFO - 2018-01-18 15:54:49 --> Config Class Initialized
INFO - 2018-01-18 15:54:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:49 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:49 --> URI Class Initialized
INFO - 2018-01-18 15:54:49 --> Router Class Initialized
INFO - 2018-01-18 15:54:49 --> Output Class Initialized
INFO - 2018-01-18 15:54:49 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:49 --> Input Class Initialized
INFO - 2018-01-18 15:54:49 --> Language Class Initialized
INFO - 2018-01-18 15:54:49 --> Loader Class Initialized
INFO - 2018-01-18 15:54:49 --> Helper loaded: url_helper
INFO - 2018-01-18 15:54:49 --> Helper loaded: form_helper
INFO - 2018-01-18 15:54:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:54:49 --> Form Validation Class Initialized
INFO - 2018-01-18 15:54:49 --> Model Class Initialized
INFO - 2018-01-18 15:54:49 --> Controller Class Initialized
INFO - 2018-01-18 15:54:49 --> Model Class Initialized
INFO - 2018-01-18 15:54:49 --> Model Class Initialized
INFO - 2018-01-18 15:54:49 --> Model Class Initialized
INFO - 2018-01-18 15:54:49 --> Model Class Initialized
DEBUG - 2018-01-18 15:54:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 15:54:49 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:54:49 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:54:49 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 15:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 15:54:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:54:49 --> Final output sent to browser
DEBUG - 2018-01-18 15:54:49 --> Total execution time: 0.0548
INFO - 2018-01-18 15:54:50 --> Config Class Initialized
INFO - 2018-01-18 15:54:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:50 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:50 --> URI Class Initialized
INFO - 2018-01-18 15:54:50 --> Router Class Initialized
INFO - 2018-01-18 15:54:50 --> Output Class Initialized
INFO - 2018-01-18 15:54:50 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:50 --> Input Class Initialized
INFO - 2018-01-18 15:54:50 --> Language Class Initialized
ERROR - 2018-01-18 15:54:50 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:54:55 --> Config Class Initialized
INFO - 2018-01-18 15:54:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:55 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:55 --> URI Class Initialized
INFO - 2018-01-18 15:54:55 --> Router Class Initialized
INFO - 2018-01-18 15:54:55 --> Output Class Initialized
INFO - 2018-01-18 15:54:55 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:55 --> Input Class Initialized
INFO - 2018-01-18 15:54:55 --> Language Class Initialized
INFO - 2018-01-18 15:54:55 --> Loader Class Initialized
INFO - 2018-01-18 15:54:55 --> Helper loaded: url_helper
INFO - 2018-01-18 15:54:55 --> Helper loaded: form_helper
INFO - 2018-01-18 15:54:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:54:55 --> Form Validation Class Initialized
INFO - 2018-01-18 15:54:55 --> Model Class Initialized
INFO - 2018-01-18 15:54:55 --> Controller Class Initialized
INFO - 2018-01-18 15:54:55 --> Model Class Initialized
INFO - 2018-01-18 15:54:55 --> Model Class Initialized
INFO - 2018-01-18 15:54:55 --> Model Class Initialized
INFO - 2018-01-18 15:54:55 --> Model Class Initialized
DEBUG - 2018-01-18 15:54:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 15:54:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:54:55 --> Final output sent to browser
DEBUG - 2018-01-18 15:54:55 --> Total execution time: 0.0503
INFO - 2018-01-18 15:54:55 --> Config Class Initialized
INFO - 2018-01-18 15:54:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:54:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:54:55 --> Utf8 Class Initialized
INFO - 2018-01-18 15:54:55 --> URI Class Initialized
INFO - 2018-01-18 15:54:55 --> Router Class Initialized
INFO - 2018-01-18 15:54:55 --> Output Class Initialized
INFO - 2018-01-18 15:54:55 --> Security Class Initialized
DEBUG - 2018-01-18 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:54:55 --> Input Class Initialized
INFO - 2018-01-18 15:54:55 --> Language Class Initialized
ERROR - 2018-01-18 15:54:55 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 15:55:23 --> Config Class Initialized
INFO - 2018-01-18 15:55:23 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:55:23 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:55:23 --> Utf8 Class Initialized
INFO - 2018-01-18 15:55:23 --> URI Class Initialized
INFO - 2018-01-18 15:55:23 --> Router Class Initialized
INFO - 2018-01-18 15:55:23 --> Output Class Initialized
INFO - 2018-01-18 15:55:23 --> Security Class Initialized
DEBUG - 2018-01-18 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:55:23 --> Input Class Initialized
INFO - 2018-01-18 15:55:23 --> Language Class Initialized
INFO - 2018-01-18 15:55:23 --> Loader Class Initialized
INFO - 2018-01-18 15:55:23 --> Helper loaded: url_helper
INFO - 2018-01-18 15:55:23 --> Helper loaded: form_helper
INFO - 2018-01-18 15:55:23 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:55:23 --> Form Validation Class Initialized
INFO - 2018-01-18 15:55:23 --> Model Class Initialized
INFO - 2018-01-18 15:55:23 --> Controller Class Initialized
INFO - 2018-01-18 15:55:23 --> Model Class Initialized
INFO - 2018-01-18 15:55:23 --> Model Class Initialized
INFO - 2018-01-18 15:55:23 --> Model Class Initialized
INFO - 2018-01-18 15:55:23 --> Model Class Initialized
DEBUG - 2018-01-18 15:55:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 15:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-18 15:55:24 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-18 15:55:47 --> Config Class Initialized
INFO - 2018-01-18 15:55:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 15:55:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 15:55:47 --> Utf8 Class Initialized
INFO - 2018-01-18 15:55:47 --> URI Class Initialized
INFO - 2018-01-18 15:55:47 --> Router Class Initialized
INFO - 2018-01-18 15:55:47 --> Output Class Initialized
INFO - 2018-01-18 15:55:47 --> Security Class Initialized
DEBUG - 2018-01-18 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 15:55:47 --> Input Class Initialized
INFO - 2018-01-18 15:55:47 --> Language Class Initialized
INFO - 2018-01-18 15:55:47 --> Loader Class Initialized
INFO - 2018-01-18 15:55:47 --> Helper loaded: url_helper
INFO - 2018-01-18 15:55:47 --> Helper loaded: form_helper
INFO - 2018-01-18 15:55:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 15:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 15:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 15:55:47 --> Form Validation Class Initialized
INFO - 2018-01-18 15:55:47 --> Model Class Initialized
INFO - 2018-01-18 15:55:47 --> Controller Class Initialized
INFO - 2018-01-18 15:55:47 --> Model Class Initialized
INFO - 2018-01-18 15:55:47 --> Model Class Initialized
INFO - 2018-01-18 15:55:47 --> Model Class Initialized
INFO - 2018-01-18 15:55:47 --> Model Class Initialized
DEBUG - 2018-01-18 15:55:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 15:55:50 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 15:55:50 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 15:55:50 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 15:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 15:55:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 15:55:50 --> Final output sent to browser
DEBUG - 2018-01-18 15:55:50 --> Total execution time: 3.0833
INFO - 2018-01-18 16:28:36 --> Config Class Initialized
INFO - 2018-01-18 16:28:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:28:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:28:36 --> Utf8 Class Initialized
INFO - 2018-01-18 16:28:36 --> URI Class Initialized
INFO - 2018-01-18 16:28:36 --> Router Class Initialized
INFO - 2018-01-18 16:28:36 --> Output Class Initialized
INFO - 2018-01-18 16:28:36 --> Security Class Initialized
DEBUG - 2018-01-18 16:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:28:36 --> Input Class Initialized
INFO - 2018-01-18 16:28:36 --> Language Class Initialized
INFO - 2018-01-18 16:28:36 --> Loader Class Initialized
INFO - 2018-01-18 16:28:36 --> Helper loaded: url_helper
INFO - 2018-01-18 16:28:36 --> Helper loaded: form_helper
INFO - 2018-01-18 16:28:36 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:28:36 --> Form Validation Class Initialized
INFO - 2018-01-18 16:28:36 --> Model Class Initialized
INFO - 2018-01-18 16:28:36 --> Controller Class Initialized
INFO - 2018-01-18 16:28:36 --> Model Class Initialized
INFO - 2018-01-18 16:28:36 --> Model Class Initialized
INFO - 2018-01-18 16:28:36 --> Model Class Initialized
INFO - 2018-01-18 16:28:36 --> Model Class Initialized
DEBUG - 2018-01-18 16:28:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 16:28:36 --> Severity: Notice --> Undefined variable: gasto_tipo /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 16:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 51
ERROR - 2018-01-18 16:28:36 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 16:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 16:28:36 --> Severity: Notice --> Undefined variable: gasto_estados /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
ERROR - 2018-01-18 16:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 101
INFO - 2018-01-18 16:28:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:28:36 --> Final output sent to browser
DEBUG - 2018-01-18 16:28:36 --> Total execution time: 0.0639
INFO - 2018-01-18 16:28:37 --> Config Class Initialized
INFO - 2018-01-18 16:28:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:28:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:28:37 --> Utf8 Class Initialized
INFO - 2018-01-18 16:28:37 --> URI Class Initialized
INFO - 2018-01-18 16:28:37 --> Router Class Initialized
INFO - 2018-01-18 16:28:37 --> Output Class Initialized
INFO - 2018-01-18 16:28:37 --> Security Class Initialized
DEBUG - 2018-01-18 16:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:28:37 --> Input Class Initialized
INFO - 2018-01-18 16:28:37 --> Language Class Initialized
ERROR - 2018-01-18 16:28:37 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:28:50 --> Config Class Initialized
INFO - 2018-01-18 16:28:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:28:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:28:50 --> Utf8 Class Initialized
INFO - 2018-01-18 16:28:50 --> URI Class Initialized
DEBUG - 2018-01-18 16:28:50 --> No URI present. Default controller set.
INFO - 2018-01-18 16:28:50 --> Router Class Initialized
INFO - 2018-01-18 16:28:50 --> Output Class Initialized
INFO - 2018-01-18 16:28:50 --> Security Class Initialized
DEBUG - 2018-01-18 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:28:50 --> Input Class Initialized
INFO - 2018-01-18 16:28:50 --> Language Class Initialized
INFO - 2018-01-18 16:28:50 --> Loader Class Initialized
INFO - 2018-01-18 16:28:50 --> Helper loaded: url_helper
INFO - 2018-01-18 16:28:50 --> Helper loaded: form_helper
INFO - 2018-01-18 16:28:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:28:50 --> Form Validation Class Initialized
INFO - 2018-01-18 16:28:50 --> Model Class Initialized
INFO - 2018-01-18 16:28:50 --> Controller Class Initialized
INFO - 2018-01-18 16:28:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:28:50 --> Final output sent to browser
DEBUG - 2018-01-18 16:28:50 --> Total execution time: 0.0351
INFO - 2018-01-18 16:28:57 --> Config Class Initialized
INFO - 2018-01-18 16:28:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:28:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:28:57 --> Utf8 Class Initialized
INFO - 2018-01-18 16:28:57 --> URI Class Initialized
DEBUG - 2018-01-18 16:28:57 --> No URI present. Default controller set.
INFO - 2018-01-18 16:28:57 --> Router Class Initialized
INFO - 2018-01-18 16:28:57 --> Output Class Initialized
INFO - 2018-01-18 16:28:57 --> Security Class Initialized
DEBUG - 2018-01-18 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:28:57 --> Input Class Initialized
INFO - 2018-01-18 16:28:57 --> Language Class Initialized
INFO - 2018-01-18 16:28:57 --> Loader Class Initialized
INFO - 2018-01-18 16:28:57 --> Helper loaded: url_helper
INFO - 2018-01-18 16:28:57 --> Helper loaded: form_helper
INFO - 2018-01-18 16:28:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:28:57 --> Form Validation Class Initialized
INFO - 2018-01-18 16:28:57 --> Model Class Initialized
INFO - 2018-01-18 16:28:57 --> Controller Class Initialized
INFO - 2018-01-18 16:28:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:28:57 --> Final output sent to browser
DEBUG - 2018-01-18 16:28:57 --> Total execution time: 0.0348
INFO - 2018-01-18 16:29:01 --> Config Class Initialized
INFO - 2018-01-18 16:29:01 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:01 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:01 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:01 --> URI Class Initialized
INFO - 2018-01-18 16:29:01 --> Router Class Initialized
INFO - 2018-01-18 16:29:01 --> Output Class Initialized
INFO - 2018-01-18 16:29:01 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:01 --> Input Class Initialized
INFO - 2018-01-18 16:29:01 --> Language Class Initialized
INFO - 2018-01-18 16:29:01 --> Loader Class Initialized
INFO - 2018-01-18 16:29:01 --> Helper loaded: url_helper
INFO - 2018-01-18 16:29:01 --> Helper loaded: form_helper
INFO - 2018-01-18 16:29:01 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:29:01 --> Form Validation Class Initialized
INFO - 2018-01-18 16:29:01 --> Model Class Initialized
INFO - 2018-01-18 16:29:01 --> Controller Class Initialized
INFO - 2018-01-18 16:29:01 --> Model Class Initialized
INFO - 2018-01-18 16:29:01 --> Model Class Initialized
INFO - 2018-01-18 16:29:01 --> Model Class Initialized
INFO - 2018-01-18 16:29:01 --> Model Class Initialized
DEBUG - 2018-01-18 16:29:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:29:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:29:01 --> Final output sent to browser
DEBUG - 2018-01-18 16:29:01 --> Total execution time: 0.0500
INFO - 2018-01-18 16:29:02 --> Config Class Initialized
INFO - 2018-01-18 16:29:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:02 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:02 --> URI Class Initialized
INFO - 2018-01-18 16:29:02 --> Router Class Initialized
INFO - 2018-01-18 16:29:02 --> Output Class Initialized
INFO - 2018-01-18 16:29:02 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:02 --> Input Class Initialized
INFO - 2018-01-18 16:29:02 --> Language Class Initialized
INFO - 2018-01-18 16:29:02 --> Loader Class Initialized
INFO - 2018-01-18 16:29:02 --> Helper loaded: url_helper
INFO - 2018-01-18 16:29:02 --> Helper loaded: form_helper
INFO - 2018-01-18 16:29:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:29:02 --> Form Validation Class Initialized
INFO - 2018-01-18 16:29:02 --> Model Class Initialized
INFO - 2018-01-18 16:29:02 --> Controller Class Initialized
INFO - 2018-01-18 16:29:02 --> Model Class Initialized
INFO - 2018-01-18 16:29:02 --> Model Class Initialized
INFO - 2018-01-18 16:29:02 --> Model Class Initialized
INFO - 2018-01-18 16:29:02 --> Model Class Initialized
DEBUG - 2018-01-18 16:29:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:29:07 --> Config Class Initialized
INFO - 2018-01-18 16:29:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:07 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:07 --> URI Class Initialized
INFO - 2018-01-18 16:29:07 --> Router Class Initialized
INFO - 2018-01-18 16:29:07 --> Output Class Initialized
INFO - 2018-01-18 16:29:07 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:07 --> Input Class Initialized
INFO - 2018-01-18 16:29:07 --> Language Class Initialized
INFO - 2018-01-18 16:29:07 --> Loader Class Initialized
INFO - 2018-01-18 16:29:07 --> Helper loaded: url_helper
INFO - 2018-01-18 16:29:07 --> Helper loaded: form_helper
INFO - 2018-01-18 16:29:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:29:07 --> Form Validation Class Initialized
INFO - 2018-01-18 16:29:07 --> Model Class Initialized
INFO - 2018-01-18 16:29:07 --> Controller Class Initialized
INFO - 2018-01-18 16:29:07 --> Model Class Initialized
INFO - 2018-01-18 16:29:07 --> Model Class Initialized
INFO - 2018-01-18 16:29:07 --> Model Class Initialized
INFO - 2018-01-18 16:29:07 --> Model Class Initialized
DEBUG - 2018-01-18 16:29:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:29:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:29:07 --> Final output sent to browser
DEBUG - 2018-01-18 16:29:07 --> Total execution time: 0.0669
INFO - 2018-01-18 16:29:07 --> Config Class Initialized
INFO - 2018-01-18 16:29:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:07 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:07 --> URI Class Initialized
INFO - 2018-01-18 16:29:07 --> Router Class Initialized
INFO - 2018-01-18 16:29:07 --> Output Class Initialized
INFO - 2018-01-18 16:29:07 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:07 --> Input Class Initialized
INFO - 2018-01-18 16:29:07 --> Language Class Initialized
ERROR - 2018-01-18 16:29:07 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:29:12 --> Config Class Initialized
INFO - 2018-01-18 16:29:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:12 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:12 --> URI Class Initialized
INFO - 2018-01-18 16:29:12 --> Router Class Initialized
INFO - 2018-01-18 16:29:12 --> Output Class Initialized
INFO - 2018-01-18 16:29:12 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:12 --> Input Class Initialized
INFO - 2018-01-18 16:29:12 --> Language Class Initialized
INFO - 2018-01-18 16:29:12 --> Loader Class Initialized
INFO - 2018-01-18 16:29:12 --> Helper loaded: url_helper
INFO - 2018-01-18 16:29:12 --> Helper loaded: form_helper
INFO - 2018-01-18 16:29:12 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:29:12 --> Form Validation Class Initialized
INFO - 2018-01-18 16:29:12 --> Model Class Initialized
INFO - 2018-01-18 16:29:12 --> Controller Class Initialized
INFO - 2018-01-18 16:29:12 --> Model Class Initialized
INFO - 2018-01-18 16:29:12 --> Model Class Initialized
INFO - 2018-01-18 16:29:12 --> Model Class Initialized
INFO - 2018-01-18 16:29:12 --> Model Class Initialized
DEBUG - 2018-01-18 16:29:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:29:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:29:12 --> Final output sent to browser
DEBUG - 2018-01-18 16:29:12 --> Total execution time: 0.0512
INFO - 2018-01-18 16:29:12 --> Config Class Initialized
INFO - 2018-01-18 16:29:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:12 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:12 --> URI Class Initialized
INFO - 2018-01-18 16:29:12 --> Router Class Initialized
INFO - 2018-01-18 16:29:12 --> Output Class Initialized
INFO - 2018-01-18 16:29:12 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:12 --> Input Class Initialized
INFO - 2018-01-18 16:29:12 --> Language Class Initialized
ERROR - 2018-01-18 16:29:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:29:13 --> Config Class Initialized
INFO - 2018-01-18 16:29:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:13 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:13 --> URI Class Initialized
INFO - 2018-01-18 16:29:13 --> Router Class Initialized
INFO - 2018-01-18 16:29:13 --> Output Class Initialized
INFO - 2018-01-18 16:29:13 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:13 --> Input Class Initialized
INFO - 2018-01-18 16:29:13 --> Language Class Initialized
ERROR - 2018-01-18 16:29:13 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:29:45 --> Config Class Initialized
INFO - 2018-01-18 16:29:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:29:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:29:45 --> Utf8 Class Initialized
INFO - 2018-01-18 16:29:45 --> URI Class Initialized
INFO - 2018-01-18 16:29:45 --> Router Class Initialized
INFO - 2018-01-18 16:29:45 --> Output Class Initialized
INFO - 2018-01-18 16:29:45 --> Security Class Initialized
DEBUG - 2018-01-18 16:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:29:45 --> Input Class Initialized
INFO - 2018-01-18 16:29:45 --> Language Class Initialized
ERROR - 2018-01-18 16:29:45 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:30:09 --> Config Class Initialized
INFO - 2018-01-18 16:30:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:30:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:30:09 --> Utf8 Class Initialized
INFO - 2018-01-18 16:30:09 --> URI Class Initialized
INFO - 2018-01-18 16:30:09 --> Router Class Initialized
INFO - 2018-01-18 16:30:09 --> Output Class Initialized
INFO - 2018-01-18 16:30:09 --> Security Class Initialized
DEBUG - 2018-01-18 16:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:30:09 --> Input Class Initialized
INFO - 2018-01-18 16:30:09 --> Language Class Initialized
INFO - 2018-01-18 16:30:09 --> Loader Class Initialized
INFO - 2018-01-18 16:30:09 --> Helper loaded: url_helper
INFO - 2018-01-18 16:30:09 --> Helper loaded: form_helper
INFO - 2018-01-18 16:30:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:30:09 --> Form Validation Class Initialized
INFO - 2018-01-18 16:30:09 --> Model Class Initialized
INFO - 2018-01-18 16:30:09 --> Controller Class Initialized
INFO - 2018-01-18 16:30:09 --> Model Class Initialized
INFO - 2018-01-18 16:30:09 --> Model Class Initialized
INFO - 2018-01-18 16:30:09 --> Model Class Initialized
INFO - 2018-01-18 16:30:09 --> Model Class Initialized
DEBUG - 2018-01-18 16:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:30:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:30:11 --> Final output sent to browser
DEBUG - 2018-01-18 16:30:11 --> Total execution time: 1.5991
INFO - 2018-01-18 16:30:12 --> Config Class Initialized
INFO - 2018-01-18 16:30:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:30:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:30:12 --> Utf8 Class Initialized
INFO - 2018-01-18 16:30:12 --> URI Class Initialized
INFO - 2018-01-18 16:30:12 --> Router Class Initialized
INFO - 2018-01-18 16:30:12 --> Output Class Initialized
INFO - 2018-01-18 16:30:12 --> Security Class Initialized
DEBUG - 2018-01-18 16:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:30:12 --> Input Class Initialized
INFO - 2018-01-18 16:30:12 --> Language Class Initialized
ERROR - 2018-01-18 16:30:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:30:12 --> Config Class Initialized
INFO - 2018-01-18 16:30:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:30:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:30:12 --> Utf8 Class Initialized
INFO - 2018-01-18 16:30:12 --> URI Class Initialized
INFO - 2018-01-18 16:30:12 --> Router Class Initialized
INFO - 2018-01-18 16:30:12 --> Output Class Initialized
INFO - 2018-01-18 16:30:12 --> Security Class Initialized
DEBUG - 2018-01-18 16:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:30:12 --> Input Class Initialized
INFO - 2018-01-18 16:30:12 --> Language Class Initialized
ERROR - 2018-01-18 16:30:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 16:30:33 --> Config Class Initialized
INFO - 2018-01-18 16:30:33 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:30:33 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:30:33 --> Utf8 Class Initialized
INFO - 2018-01-18 16:30:33 --> URI Class Initialized
INFO - 2018-01-18 16:30:33 --> Router Class Initialized
INFO - 2018-01-18 16:30:33 --> Output Class Initialized
INFO - 2018-01-18 16:30:33 --> Security Class Initialized
DEBUG - 2018-01-18 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:30:33 --> Input Class Initialized
INFO - 2018-01-18 16:30:33 --> Language Class Initialized
INFO - 2018-01-18 16:30:33 --> Loader Class Initialized
INFO - 2018-01-18 16:30:33 --> Helper loaded: url_helper
INFO - 2018-01-18 16:30:33 --> Helper loaded: form_helper
INFO - 2018-01-18 16:30:33 --> Database Driver Class Initialized
DEBUG - 2018-01-18 16:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 16:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 16:30:33 --> Form Validation Class Initialized
INFO - 2018-01-18 16:30:33 --> Model Class Initialized
INFO - 2018-01-18 16:30:33 --> Controller Class Initialized
INFO - 2018-01-18 16:30:33 --> Model Class Initialized
INFO - 2018-01-18 16:30:33 --> Model Class Initialized
INFO - 2018-01-18 16:30:33 --> Model Class Initialized
INFO - 2018-01-18 16:30:33 --> Model Class Initialized
DEBUG - 2018-01-18 16:30:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 16:30:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 16:30:33 --> Final output sent to browser
DEBUG - 2018-01-18 16:30:33 --> Total execution time: 0.0503
INFO - 2018-01-18 16:30:34 --> Config Class Initialized
INFO - 2018-01-18 16:30:34 --> Hooks Class Initialized
DEBUG - 2018-01-18 16:30:34 --> UTF-8 Support Enabled
INFO - 2018-01-18 16:30:34 --> Utf8 Class Initialized
INFO - 2018-01-18 16:30:34 --> URI Class Initialized
INFO - 2018-01-18 16:30:34 --> Router Class Initialized
INFO - 2018-01-18 16:30:34 --> Output Class Initialized
INFO - 2018-01-18 16:30:34 --> Security Class Initialized
DEBUG - 2018-01-18 16:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 16:30:34 --> Input Class Initialized
INFO - 2018-01-18 16:30:34 --> Language Class Initialized
ERROR - 2018-01-18 16:30:34 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:13:50 --> Config Class Initialized
INFO - 2018-01-18 19:13:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:13:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:13:50 --> Utf8 Class Initialized
INFO - 2018-01-18 19:13:50 --> URI Class Initialized
INFO - 2018-01-18 19:13:50 --> Router Class Initialized
INFO - 2018-01-18 19:13:50 --> Output Class Initialized
INFO - 2018-01-18 19:13:50 --> Security Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:13:50 --> Input Class Initialized
INFO - 2018-01-18 19:13:50 --> Language Class Initialized
INFO - 2018-01-18 19:13:50 --> Loader Class Initialized
INFO - 2018-01-18 19:13:50 --> Helper loaded: url_helper
INFO - 2018-01-18 19:13:50 --> Helper loaded: form_helper
INFO - 2018-01-18 19:13:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:13:50 --> Form Validation Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
INFO - 2018-01-18 19:13:50 --> Controller Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:13:50 --> Config Class Initialized
INFO - 2018-01-18 19:13:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:13:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:13:50 --> Utf8 Class Initialized
INFO - 2018-01-18 19:13:50 --> URI Class Initialized
INFO - 2018-01-18 19:13:50 --> Router Class Initialized
INFO - 2018-01-18 19:13:50 --> Output Class Initialized
INFO - 2018-01-18 19:13:50 --> Security Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:13:50 --> Input Class Initialized
INFO - 2018-01-18 19:13:50 --> Language Class Initialized
INFO - 2018-01-18 19:13:50 --> Loader Class Initialized
INFO - 2018-01-18 19:13:50 --> Helper loaded: url_helper
INFO - 2018-01-18 19:13:50 --> Helper loaded: form_helper
INFO - 2018-01-18 19:13:50 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:13:50 --> Form Validation Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
INFO - 2018-01-18 19:13:50 --> Controller Class Initialized
INFO - 2018-01-18 19:13:50 --> Model Class Initialized
DEBUG - 2018-01-18 19:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:13:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:13:50 --> Final output sent to browser
DEBUG - 2018-01-18 19:13:50 --> Total execution time: 0.0427
INFO - 2018-01-18 19:13:58 --> Config Class Initialized
INFO - 2018-01-18 19:13:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:13:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:13:58 --> Utf8 Class Initialized
INFO - 2018-01-18 19:13:58 --> URI Class Initialized
INFO - 2018-01-18 19:13:58 --> Router Class Initialized
INFO - 2018-01-18 19:13:58 --> Output Class Initialized
INFO - 2018-01-18 19:13:58 --> Security Class Initialized
DEBUG - 2018-01-18 19:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:13:58 --> Input Class Initialized
INFO - 2018-01-18 19:13:58 --> Language Class Initialized
INFO - 2018-01-18 19:13:58 --> Loader Class Initialized
INFO - 2018-01-18 19:13:58 --> Helper loaded: url_helper
INFO - 2018-01-18 19:13:58 --> Helper loaded: form_helper
INFO - 2018-01-18 19:13:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:13:58 --> Form Validation Class Initialized
INFO - 2018-01-18 19:13:58 --> Model Class Initialized
INFO - 2018-01-18 19:13:58 --> Controller Class Initialized
INFO - 2018-01-18 19:13:58 --> Model Class Initialized
INFO - 2018-01-18 19:13:58 --> Model Class Initialized
INFO - 2018-01-18 19:13:58 --> Model Class Initialized
INFO - 2018-01-18 19:13:58 --> Model Class Initialized
DEBUG - 2018-01-18 19:13:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:13:59 --> Config Class Initialized
INFO - 2018-01-18 19:13:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:13:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:13:59 --> Utf8 Class Initialized
INFO - 2018-01-18 19:13:59 --> URI Class Initialized
INFO - 2018-01-18 19:13:59 --> Router Class Initialized
INFO - 2018-01-18 19:13:59 --> Output Class Initialized
INFO - 2018-01-18 19:13:59 --> Security Class Initialized
DEBUG - 2018-01-18 19:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:13:59 --> Input Class Initialized
INFO - 2018-01-18 19:13:59 --> Language Class Initialized
INFO - 2018-01-18 19:13:59 --> Loader Class Initialized
INFO - 2018-01-18 19:13:59 --> Helper loaded: url_helper
INFO - 2018-01-18 19:13:59 --> Helper loaded: form_helper
INFO - 2018-01-18 19:13:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:13:59 --> Form Validation Class Initialized
INFO - 2018-01-18 19:13:59 --> Model Class Initialized
INFO - 2018-01-18 19:13:59 --> Controller Class Initialized
INFO - 2018-01-18 19:13:59 --> Model Class Initialized
DEBUG - 2018-01-18 19:13:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:13:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:13:59 --> Final output sent to browser
DEBUG - 2018-01-18 19:13:59 --> Total execution time: 0.0419
INFO - 2018-01-18 19:14:03 --> Config Class Initialized
INFO - 2018-01-18 19:14:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:14:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:14:03 --> Utf8 Class Initialized
INFO - 2018-01-18 19:14:03 --> URI Class Initialized
INFO - 2018-01-18 19:14:03 --> Router Class Initialized
INFO - 2018-01-18 19:14:03 --> Output Class Initialized
INFO - 2018-01-18 19:14:03 --> Security Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:14:03 --> Input Class Initialized
INFO - 2018-01-18 19:14:03 --> Language Class Initialized
INFO - 2018-01-18 19:14:03 --> Loader Class Initialized
INFO - 2018-01-18 19:14:03 --> Helper loaded: url_helper
INFO - 2018-01-18 19:14:03 --> Helper loaded: form_helper
INFO - 2018-01-18 19:14:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:14:03 --> Form Validation Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
INFO - 2018-01-18 19:14:03 --> Controller Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:14:03 --> Config Class Initialized
INFO - 2018-01-18 19:14:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:14:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:14:03 --> Utf8 Class Initialized
INFO - 2018-01-18 19:14:03 --> URI Class Initialized
INFO - 2018-01-18 19:14:03 --> Router Class Initialized
INFO - 2018-01-18 19:14:03 --> Output Class Initialized
INFO - 2018-01-18 19:14:03 --> Security Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:14:03 --> Input Class Initialized
INFO - 2018-01-18 19:14:03 --> Language Class Initialized
INFO - 2018-01-18 19:14:03 --> Loader Class Initialized
INFO - 2018-01-18 19:14:03 --> Helper loaded: url_helper
INFO - 2018-01-18 19:14:03 --> Helper loaded: form_helper
INFO - 2018-01-18 19:14:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:14:03 --> Form Validation Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
INFO - 2018-01-18 19:14:03 --> Controller Class Initialized
INFO - 2018-01-18 19:14:03 --> Model Class Initialized
DEBUG - 2018-01-18 19:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:14:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:14:03 --> Final output sent to browser
DEBUG - 2018-01-18 19:14:03 --> Total execution time: 0.0345
INFO - 2018-01-18 19:17:42 --> Config Class Initialized
INFO - 2018-01-18 19:17:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:17:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:17:42 --> Utf8 Class Initialized
INFO - 2018-01-18 19:17:42 --> URI Class Initialized
DEBUG - 2018-01-18 19:17:42 --> No URI present. Default controller set.
INFO - 2018-01-18 19:17:42 --> Router Class Initialized
INFO - 2018-01-18 19:17:42 --> Output Class Initialized
INFO - 2018-01-18 19:17:42 --> Security Class Initialized
DEBUG - 2018-01-18 19:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:17:42 --> Input Class Initialized
INFO - 2018-01-18 19:17:42 --> Language Class Initialized
INFO - 2018-01-18 19:17:42 --> Loader Class Initialized
INFO - 2018-01-18 19:17:42 --> Helper loaded: url_helper
INFO - 2018-01-18 19:17:42 --> Helper loaded: form_helper
INFO - 2018-01-18 19:17:42 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:17:42 --> Form Validation Class Initialized
INFO - 2018-01-18 19:17:42 --> Model Class Initialized
INFO - 2018-01-18 19:17:42 --> Controller Class Initialized
INFO - 2018-01-18 19:17:43 --> Config Class Initialized
INFO - 2018-01-18 19:17:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:17:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:17:43 --> Utf8 Class Initialized
INFO - 2018-01-18 19:17:43 --> URI Class Initialized
INFO - 2018-01-18 19:17:43 --> Router Class Initialized
INFO - 2018-01-18 19:17:43 --> Output Class Initialized
INFO - 2018-01-18 19:17:43 --> Security Class Initialized
DEBUG - 2018-01-18 19:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:17:43 --> Input Class Initialized
INFO - 2018-01-18 19:17:43 --> Language Class Initialized
INFO - 2018-01-18 19:17:43 --> Loader Class Initialized
INFO - 2018-01-18 19:17:43 --> Helper loaded: url_helper
INFO - 2018-01-18 19:17:43 --> Helper loaded: form_helper
INFO - 2018-01-18 19:17:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:17:43 --> Form Validation Class Initialized
INFO - 2018-01-18 19:17:43 --> Model Class Initialized
INFO - 2018-01-18 19:17:43 --> Controller Class Initialized
INFO - 2018-01-18 19:17:43 --> Model Class Initialized
DEBUG - 2018-01-18 19:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:17:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:17:43 --> Final output sent to browser
DEBUG - 2018-01-18 19:17:43 --> Total execution time: 0.0345
INFO - 2018-01-18 19:19:00 --> Config Class Initialized
INFO - 2018-01-18 19:19:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:19:00 --> Utf8 Class Initialized
INFO - 2018-01-18 19:19:00 --> URI Class Initialized
INFO - 2018-01-18 19:19:00 --> Router Class Initialized
INFO - 2018-01-18 19:19:00 --> Output Class Initialized
INFO - 2018-01-18 19:19:00 --> Security Class Initialized
DEBUG - 2018-01-18 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:19:00 --> Input Class Initialized
INFO - 2018-01-18 19:19:00 --> Language Class Initialized
INFO - 2018-01-18 19:19:00 --> Loader Class Initialized
INFO - 2018-01-18 19:19:00 --> Helper loaded: url_helper
INFO - 2018-01-18 19:19:00 --> Helper loaded: form_helper
INFO - 2018-01-18 19:19:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:19:00 --> Form Validation Class Initialized
INFO - 2018-01-18 19:19:00 --> Model Class Initialized
INFO - 2018-01-18 19:19:00 --> Controller Class Initialized
INFO - 2018-01-18 19:19:00 --> Model Class Initialized
DEBUG - 2018-01-18 19:19:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:19:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 19:19:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:19:00 --> Final output sent to browser
DEBUG - 2018-01-18 19:19:00 --> Total execution time: 0.4307
INFO - 2018-01-18 19:19:56 --> Config Class Initialized
INFO - 2018-01-18 19:19:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:19:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:19:56 --> Utf8 Class Initialized
INFO - 2018-01-18 19:19:56 --> URI Class Initialized
INFO - 2018-01-18 19:19:56 --> Router Class Initialized
INFO - 2018-01-18 19:19:56 --> Output Class Initialized
INFO - 2018-01-18 19:19:56 --> Security Class Initialized
DEBUG - 2018-01-18 19:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:19:56 --> Input Class Initialized
INFO - 2018-01-18 19:19:56 --> Language Class Initialized
INFO - 2018-01-18 19:19:56 --> Loader Class Initialized
INFO - 2018-01-18 19:19:56 --> Helper loaded: url_helper
INFO - 2018-01-18 19:19:56 --> Helper loaded: form_helper
INFO - 2018-01-18 19:19:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:19:56 --> Form Validation Class Initialized
INFO - 2018-01-18 19:19:56 --> Model Class Initialized
INFO - 2018-01-18 19:19:56 --> Controller Class Initialized
INFO - 2018-01-18 19:19:56 --> Model Class Initialized
DEBUG - 2018-01-18 19:19:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:19:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 19:19:57 --> Config Class Initialized
INFO - 2018-01-18 19:19:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:19:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:19:57 --> Utf8 Class Initialized
INFO - 2018-01-18 19:19:57 --> URI Class Initialized
INFO - 2018-01-18 19:19:57 --> Router Class Initialized
INFO - 2018-01-18 19:19:57 --> Output Class Initialized
INFO - 2018-01-18 19:19:57 --> Security Class Initialized
DEBUG - 2018-01-18 19:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:19:57 --> Input Class Initialized
INFO - 2018-01-18 19:19:57 --> Language Class Initialized
INFO - 2018-01-18 19:19:57 --> Loader Class Initialized
INFO - 2018-01-18 19:19:57 --> Helper loaded: url_helper
INFO - 2018-01-18 19:19:57 --> Helper loaded: form_helper
INFO - 2018-01-18 19:19:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:19:57 --> Form Validation Class Initialized
INFO - 2018-01-18 19:19:57 --> Model Class Initialized
INFO - 2018-01-18 19:19:57 --> Controller Class Initialized
INFO - 2018-01-18 19:19:57 --> Model Class Initialized
DEBUG - 2018-01-18 19:19:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:19:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 19:19:58 --> Config Class Initialized
INFO - 2018-01-18 19:19:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:19:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:19:58 --> Utf8 Class Initialized
INFO - 2018-01-18 19:19:58 --> URI Class Initialized
DEBUG - 2018-01-18 19:19:58 --> No URI present. Default controller set.
INFO - 2018-01-18 19:19:58 --> Router Class Initialized
INFO - 2018-01-18 19:19:58 --> Output Class Initialized
INFO - 2018-01-18 19:19:58 --> Security Class Initialized
DEBUG - 2018-01-18 19:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:19:58 --> Input Class Initialized
INFO - 2018-01-18 19:19:58 --> Language Class Initialized
INFO - 2018-01-18 19:19:58 --> Loader Class Initialized
INFO - 2018-01-18 19:19:58 --> Helper loaded: url_helper
INFO - 2018-01-18 19:19:58 --> Helper loaded: form_helper
INFO - 2018-01-18 19:19:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:19:58 --> Form Validation Class Initialized
INFO - 2018-01-18 19:19:58 --> Model Class Initialized
INFO - 2018-01-18 19:19:58 --> Controller Class Initialized
INFO - 2018-01-18 19:19:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:19:58 --> Final output sent to browser
DEBUG - 2018-01-18 19:19:58 --> Total execution time: 0.0361
INFO - 2018-01-18 19:20:03 --> Config Class Initialized
INFO - 2018-01-18 19:20:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:03 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:03 --> URI Class Initialized
INFO - 2018-01-18 19:20:03 --> Router Class Initialized
INFO - 2018-01-18 19:20:03 --> Output Class Initialized
INFO - 2018-01-18 19:20:03 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:03 --> Input Class Initialized
INFO - 2018-01-18 19:20:03 --> Language Class Initialized
INFO - 2018-01-18 19:20:03 --> Loader Class Initialized
INFO - 2018-01-18 19:20:03 --> Helper loaded: url_helper
INFO - 2018-01-18 19:20:03 --> Helper loaded: form_helper
INFO - 2018-01-18 19:20:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:20:03 --> Form Validation Class Initialized
INFO - 2018-01-18 19:20:03 --> Model Class Initialized
INFO - 2018-01-18 19:20:03 --> Controller Class Initialized
INFO - 2018-01-18 19:20:03 --> Model Class Initialized
INFO - 2018-01-18 19:20:03 --> Model Class Initialized
INFO - 2018-01-18 19:20:03 --> Model Class Initialized
INFO - 2018-01-18 19:20:03 --> Model Class Initialized
DEBUG - 2018-01-18 19:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:20:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:20:03 --> Final output sent to browser
DEBUG - 2018-01-18 19:20:03 --> Total execution time: 0.2753
INFO - 2018-01-18 19:20:04 --> Config Class Initialized
INFO - 2018-01-18 19:20:04 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:04 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:04 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:04 --> URI Class Initialized
INFO - 2018-01-18 19:20:04 --> Router Class Initialized
INFO - 2018-01-18 19:20:04 --> Output Class Initialized
INFO - 2018-01-18 19:20:04 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:04 --> Input Class Initialized
INFO - 2018-01-18 19:20:04 --> Language Class Initialized
INFO - 2018-01-18 19:20:04 --> Loader Class Initialized
INFO - 2018-01-18 19:20:04 --> Helper loaded: url_helper
INFO - 2018-01-18 19:20:04 --> Helper loaded: form_helper
INFO - 2018-01-18 19:20:04 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:20:04 --> Form Validation Class Initialized
INFO - 2018-01-18 19:20:04 --> Model Class Initialized
INFO - 2018-01-18 19:20:04 --> Controller Class Initialized
INFO - 2018-01-18 19:20:04 --> Model Class Initialized
INFO - 2018-01-18 19:20:04 --> Model Class Initialized
INFO - 2018-01-18 19:20:04 --> Model Class Initialized
INFO - 2018-01-18 19:20:04 --> Model Class Initialized
DEBUG - 2018-01-18 19:20:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:20:11 --> Config Class Initialized
INFO - 2018-01-18 19:20:11 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:11 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:11 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:11 --> URI Class Initialized
INFO - 2018-01-18 19:20:11 --> Router Class Initialized
INFO - 2018-01-18 19:20:11 --> Output Class Initialized
INFO - 2018-01-18 19:20:11 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:11 --> Input Class Initialized
INFO - 2018-01-18 19:20:11 --> Language Class Initialized
INFO - 2018-01-18 19:20:11 --> Loader Class Initialized
INFO - 2018-01-18 19:20:11 --> Helper loaded: url_helper
INFO - 2018-01-18 19:20:11 --> Helper loaded: form_helper
INFO - 2018-01-18 19:20:11 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:20:11 --> Form Validation Class Initialized
INFO - 2018-01-18 19:20:11 --> Model Class Initialized
INFO - 2018-01-18 19:20:11 --> Controller Class Initialized
INFO - 2018-01-18 19:20:11 --> Model Class Initialized
INFO - 2018-01-18 19:20:11 --> Model Class Initialized
INFO - 2018-01-18 19:20:11 --> Model Class Initialized
INFO - 2018-01-18 19:20:11 --> Model Class Initialized
DEBUG - 2018-01-18 19:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:20:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:20:11 --> Final output sent to browser
DEBUG - 2018-01-18 19:20:11 --> Total execution time: 0.2042
INFO - 2018-01-18 19:20:12 --> Config Class Initialized
INFO - 2018-01-18 19:20:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:12 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:12 --> URI Class Initialized
INFO - 2018-01-18 19:20:12 --> Router Class Initialized
INFO - 2018-01-18 19:20:12 --> Output Class Initialized
INFO - 2018-01-18 19:20:12 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:12 --> Input Class Initialized
INFO - 2018-01-18 19:20:12 --> Language Class Initialized
ERROR - 2018-01-18 19:20:12 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:20:13 --> Config Class Initialized
INFO - 2018-01-18 19:20:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:14 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:14 --> URI Class Initialized
INFO - 2018-01-18 19:20:14 --> Router Class Initialized
INFO - 2018-01-18 19:20:14 --> Output Class Initialized
INFO - 2018-01-18 19:20:14 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:14 --> Input Class Initialized
INFO - 2018-01-18 19:20:14 --> Language Class Initialized
INFO - 2018-01-18 19:20:14 --> Loader Class Initialized
INFO - 2018-01-18 19:20:14 --> Helper loaded: url_helper
INFO - 2018-01-18 19:20:14 --> Helper loaded: form_helper
INFO - 2018-01-18 19:20:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:20:14 --> Form Validation Class Initialized
INFO - 2018-01-18 19:20:14 --> Model Class Initialized
INFO - 2018-01-18 19:20:14 --> Controller Class Initialized
INFO - 2018-01-18 19:20:14 --> Model Class Initialized
INFO - 2018-01-18 19:20:14 --> Model Class Initialized
INFO - 2018-01-18 19:20:14 --> Model Class Initialized
INFO - 2018-01-18 19:20:14 --> Model Class Initialized
DEBUG - 2018-01-18 19:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:20:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:20:14 --> Final output sent to browser
DEBUG - 2018-01-18 19:20:14 --> Total execution time: 0.0571
INFO - 2018-01-18 19:20:14 --> Config Class Initialized
INFO - 2018-01-18 19:20:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:14 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:14 --> URI Class Initialized
INFO - 2018-01-18 19:20:14 --> Router Class Initialized
INFO - 2018-01-18 19:20:14 --> Output Class Initialized
INFO - 2018-01-18 19:20:14 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:14 --> Input Class Initialized
INFO - 2018-01-18 19:20:14 --> Language Class Initialized
ERROR - 2018-01-18 19:20:14 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:20:14 --> Config Class Initialized
INFO - 2018-01-18 19:20:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:14 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:14 --> URI Class Initialized
INFO - 2018-01-18 19:20:14 --> Router Class Initialized
INFO - 2018-01-18 19:20:14 --> Output Class Initialized
INFO - 2018-01-18 19:20:14 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:14 --> Input Class Initialized
INFO - 2018-01-18 19:20:14 --> Language Class Initialized
ERROR - 2018-01-18 19:20:14 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:20:45 --> Config Class Initialized
INFO - 2018-01-18 19:20:45 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:45 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:45 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:45 --> URI Class Initialized
INFO - 2018-01-18 19:20:45 --> Router Class Initialized
INFO - 2018-01-18 19:20:45 --> Output Class Initialized
INFO - 2018-01-18 19:20:45 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:45 --> Input Class Initialized
INFO - 2018-01-18 19:20:45 --> Language Class Initialized
INFO - 2018-01-18 19:20:45 --> Loader Class Initialized
INFO - 2018-01-18 19:20:45 --> Helper loaded: url_helper
INFO - 2018-01-18 19:20:45 --> Helper loaded: form_helper
INFO - 2018-01-18 19:20:45 --> Database Driver Class Initialized
DEBUG - 2018-01-18 19:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 19:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 19:20:45 --> Form Validation Class Initialized
INFO - 2018-01-18 19:20:45 --> Model Class Initialized
INFO - 2018-01-18 19:20:45 --> Controller Class Initialized
INFO - 2018-01-18 19:20:45 --> Model Class Initialized
INFO - 2018-01-18 19:20:45 --> Model Class Initialized
INFO - 2018-01-18 19:20:45 --> Model Class Initialized
INFO - 2018-01-18 19:20:45 --> Model Class Initialized
DEBUG - 2018-01-18 19:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 19:20:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 19:20:45 --> Final output sent to browser
DEBUG - 2018-01-18 19:20:45 --> Total execution time: 0.4154
INFO - 2018-01-18 19:20:46 --> Config Class Initialized
INFO - 2018-01-18 19:20:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:46 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:46 --> URI Class Initialized
INFO - 2018-01-18 19:20:46 --> Router Class Initialized
INFO - 2018-01-18 19:20:46 --> Output Class Initialized
INFO - 2018-01-18 19:20:46 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:46 --> Input Class Initialized
INFO - 2018-01-18 19:20:46 --> Language Class Initialized
ERROR - 2018-01-18 19:20:46 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:20:46 --> Config Class Initialized
INFO - 2018-01-18 19:20:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:46 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:46 --> URI Class Initialized
INFO - 2018-01-18 19:20:46 --> Router Class Initialized
INFO - 2018-01-18 19:20:46 --> Output Class Initialized
INFO - 2018-01-18 19:20:46 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:46 --> Input Class Initialized
INFO - 2018-01-18 19:20:46 --> Language Class Initialized
ERROR - 2018-01-18 19:20:46 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 19:20:57 --> Config Class Initialized
INFO - 2018-01-18 19:20:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 19:20:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 19:20:57 --> Utf8 Class Initialized
INFO - 2018-01-18 19:20:57 --> URI Class Initialized
INFO - 2018-01-18 19:20:57 --> Router Class Initialized
INFO - 2018-01-18 19:20:57 --> Output Class Initialized
INFO - 2018-01-18 19:20:57 --> Security Class Initialized
DEBUG - 2018-01-18 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 19:20:57 --> Input Class Initialized
INFO - 2018-01-18 19:20:57 --> Language Class Initialized
ERROR - 2018-01-18 19:20:57 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:29:00 --> Config Class Initialized
INFO - 2018-01-18 20:29:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:00 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:00 --> URI Class Initialized
DEBUG - 2018-01-18 20:29:00 --> No URI present. Default controller set.
INFO - 2018-01-18 20:29:00 --> Router Class Initialized
INFO - 2018-01-18 20:29:00 --> Output Class Initialized
INFO - 2018-01-18 20:29:00 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:00 --> Input Class Initialized
INFO - 2018-01-18 20:29:00 --> Language Class Initialized
INFO - 2018-01-18 20:29:00 --> Loader Class Initialized
INFO - 2018-01-18 20:29:00 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:00 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:00 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:00 --> Model Class Initialized
INFO - 2018-01-18 20:29:00 --> Controller Class Initialized
INFO - 2018-01-18 20:29:00 --> Config Class Initialized
INFO - 2018-01-18 20:29:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:00 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:00 --> URI Class Initialized
INFO - 2018-01-18 20:29:00 --> Router Class Initialized
INFO - 2018-01-18 20:29:00 --> Output Class Initialized
INFO - 2018-01-18 20:29:00 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:00 --> Input Class Initialized
INFO - 2018-01-18 20:29:00 --> Language Class Initialized
INFO - 2018-01-18 20:29:00 --> Loader Class Initialized
INFO - 2018-01-18 20:29:00 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:00 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:00 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:00 --> Model Class Initialized
INFO - 2018-01-18 20:29:00 --> Controller Class Initialized
INFO - 2018-01-18 20:29:00 --> Model Class Initialized
DEBUG - 2018-01-18 20:29:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:29:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:29:00 --> Final output sent to browser
DEBUG - 2018-01-18 20:29:00 --> Total execution time: 0.0355
INFO - 2018-01-18 20:29:02 --> Config Class Initialized
INFO - 2018-01-18 20:29:02 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:02 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:02 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:02 --> URI Class Initialized
INFO - 2018-01-18 20:29:02 --> Router Class Initialized
INFO - 2018-01-18 20:29:02 --> Output Class Initialized
INFO - 2018-01-18 20:29:02 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:02 --> Input Class Initialized
INFO - 2018-01-18 20:29:02 --> Language Class Initialized
INFO - 2018-01-18 20:29:02 --> Loader Class Initialized
INFO - 2018-01-18 20:29:02 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:02 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:02 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:02 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:02 --> Model Class Initialized
INFO - 2018-01-18 20:29:02 --> Controller Class Initialized
INFO - 2018-01-18 20:29:02 --> Model Class Initialized
DEBUG - 2018-01-18 20:29:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:29:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-18 20:29:03 --> Config Class Initialized
INFO - 2018-01-18 20:29:03 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:03 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:03 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:03 --> URI Class Initialized
DEBUG - 2018-01-18 20:29:03 --> No URI present. Default controller set.
INFO - 2018-01-18 20:29:03 --> Router Class Initialized
INFO - 2018-01-18 20:29:03 --> Output Class Initialized
INFO - 2018-01-18 20:29:03 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:03 --> Input Class Initialized
INFO - 2018-01-18 20:29:03 --> Language Class Initialized
INFO - 2018-01-18 20:29:03 --> Loader Class Initialized
INFO - 2018-01-18 20:29:03 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:03 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:03 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:03 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:03 --> Model Class Initialized
INFO - 2018-01-18 20:29:03 --> Controller Class Initialized
INFO - 2018-01-18 20:29:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:29:03 --> Final output sent to browser
DEBUG - 2018-01-18 20:29:03 --> Total execution time: 0.0490
INFO - 2018-01-18 20:29:06 --> Config Class Initialized
INFO - 2018-01-18 20:29:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:06 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:06 --> URI Class Initialized
INFO - 2018-01-18 20:29:06 --> Router Class Initialized
INFO - 2018-01-18 20:29:06 --> Output Class Initialized
INFO - 2018-01-18 20:29:06 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:06 --> Input Class Initialized
INFO - 2018-01-18 20:29:06 --> Language Class Initialized
INFO - 2018-01-18 20:29:06 --> Loader Class Initialized
INFO - 2018-01-18 20:29:06 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:06 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:06 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:06 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:06 --> Model Class Initialized
INFO - 2018-01-18 20:29:06 --> Controller Class Initialized
INFO - 2018-01-18 20:29:06 --> Model Class Initialized
INFO - 2018-01-18 20:29:06 --> Model Class Initialized
INFO - 2018-01-18 20:29:06 --> Model Class Initialized
INFO - 2018-01-18 20:29:06 --> Model Class Initialized
DEBUG - 2018-01-18 20:29:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:29:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:29:06 --> Final output sent to browser
DEBUG - 2018-01-18 20:29:06 --> Total execution time: 0.0465
INFO - 2018-01-18 20:29:10 --> Config Class Initialized
INFO - 2018-01-18 20:29:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:10 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:10 --> URI Class Initialized
INFO - 2018-01-18 20:29:10 --> Router Class Initialized
INFO - 2018-01-18 20:29:10 --> Output Class Initialized
INFO - 2018-01-18 20:29:10 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:10 --> Input Class Initialized
INFO - 2018-01-18 20:29:10 --> Language Class Initialized
INFO - 2018-01-18 20:29:10 --> Loader Class Initialized
INFO - 2018-01-18 20:29:10 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:10 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:10 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:10 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:10 --> Model Class Initialized
INFO - 2018-01-18 20:29:10 --> Controller Class Initialized
INFO - 2018-01-18 20:29:10 --> Model Class Initialized
INFO - 2018-01-18 20:29:10 --> Model Class Initialized
INFO - 2018-01-18 20:29:10 --> Model Class Initialized
INFO - 2018-01-18 20:29:10 --> Model Class Initialized
DEBUG - 2018-01-18 20:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:29:10 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:29:10 --> Final output sent to browser
DEBUG - 2018-01-18 20:29:10 --> Total execution time: 0.0448
INFO - 2018-01-18 20:29:36 --> Config Class Initialized
INFO - 2018-01-18 20:29:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:36 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:36 --> URI Class Initialized
INFO - 2018-01-18 20:29:36 --> Router Class Initialized
INFO - 2018-01-18 20:29:36 --> Output Class Initialized
INFO - 2018-01-18 20:29:36 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:36 --> Input Class Initialized
INFO - 2018-01-18 20:29:36 --> Language Class Initialized
ERROR - 2018-01-18 20:29:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:29:36 --> Config Class Initialized
INFO - 2018-01-18 20:29:36 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:36 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:36 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:36 --> URI Class Initialized
INFO - 2018-01-18 20:29:36 --> Router Class Initialized
INFO - 2018-01-18 20:29:36 --> Output Class Initialized
INFO - 2018-01-18 20:29:36 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:36 --> Input Class Initialized
INFO - 2018-01-18 20:29:36 --> Language Class Initialized
ERROR - 2018-01-18 20:29:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:29:53 --> Config Class Initialized
INFO - 2018-01-18 20:29:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:53 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:53 --> URI Class Initialized
INFO - 2018-01-18 20:29:53 --> Router Class Initialized
INFO - 2018-01-18 20:29:53 --> Output Class Initialized
INFO - 2018-01-18 20:29:53 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:53 --> Input Class Initialized
INFO - 2018-01-18 20:29:53 --> Language Class Initialized
INFO - 2018-01-18 20:29:53 --> Loader Class Initialized
INFO - 2018-01-18 20:29:53 --> Helper loaded: url_helper
INFO - 2018-01-18 20:29:53 --> Helper loaded: form_helper
INFO - 2018-01-18 20:29:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:29:53 --> Form Validation Class Initialized
INFO - 2018-01-18 20:29:53 --> Model Class Initialized
INFO - 2018-01-18 20:29:53 --> Controller Class Initialized
INFO - 2018-01-18 20:29:53 --> Model Class Initialized
INFO - 2018-01-18 20:29:53 --> Model Class Initialized
INFO - 2018-01-18 20:29:53 --> Model Class Initialized
INFO - 2018-01-18 20:29:53 --> Model Class Initialized
DEBUG - 2018-01-18 20:29:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:29:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:29:53 --> Final output sent to browser
DEBUG - 2018-01-18 20:29:53 --> Total execution time: 0.0466
INFO - 2018-01-18 20:29:59 --> Config Class Initialized
INFO - 2018-01-18 20:29:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:59 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:59 --> URI Class Initialized
INFO - 2018-01-18 20:29:59 --> Router Class Initialized
INFO - 2018-01-18 20:29:59 --> Output Class Initialized
INFO - 2018-01-18 20:29:59 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:59 --> Input Class Initialized
INFO - 2018-01-18 20:29:59 --> Language Class Initialized
ERROR - 2018-01-18 20:29:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:29:59 --> Config Class Initialized
INFO - 2018-01-18 20:29:59 --> Config Class Initialized
INFO - 2018-01-18 20:29:59 --> Hooks Class Initialized
INFO - 2018-01-18 20:29:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:29:59 --> UTF-8 Support Enabled
DEBUG - 2018-01-18 20:29:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:29:59 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:59 --> Utf8 Class Initialized
INFO - 2018-01-18 20:29:59 --> URI Class Initialized
INFO - 2018-01-18 20:29:59 --> URI Class Initialized
INFO - 2018-01-18 20:29:59 --> Router Class Initialized
INFO - 2018-01-18 20:29:59 --> Router Class Initialized
INFO - 2018-01-18 20:29:59 --> Output Class Initialized
INFO - 2018-01-18 20:29:59 --> Output Class Initialized
INFO - 2018-01-18 20:29:59 --> Security Class Initialized
INFO - 2018-01-18 20:29:59 --> Security Class Initialized
DEBUG - 2018-01-18 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:59 --> Input Class Initialized
DEBUG - 2018-01-18 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:29:59 --> Input Class Initialized
INFO - 2018-01-18 20:29:59 --> Language Class Initialized
INFO - 2018-01-18 20:29:59 --> Language Class Initialized
ERROR - 2018-01-18 20:29:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:29:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:30:53 --> Config Class Initialized
INFO - 2018-01-18 20:30:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:30:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:30:53 --> Utf8 Class Initialized
INFO - 2018-01-18 20:30:53 --> URI Class Initialized
INFO - 2018-01-18 20:30:53 --> Router Class Initialized
INFO - 2018-01-18 20:30:53 --> Output Class Initialized
INFO - 2018-01-18 20:30:53 --> Security Class Initialized
DEBUG - 2018-01-18 20:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:30:53 --> Input Class Initialized
INFO - 2018-01-18 20:30:53 --> Language Class Initialized
INFO - 2018-01-18 20:30:53 --> Loader Class Initialized
INFO - 2018-01-18 20:30:53 --> Helper loaded: url_helper
INFO - 2018-01-18 20:30:53 --> Helper loaded: form_helper
INFO - 2018-01-18 20:30:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:30:53 --> Form Validation Class Initialized
INFO - 2018-01-18 20:30:53 --> Model Class Initialized
INFO - 2018-01-18 20:30:53 --> Controller Class Initialized
INFO - 2018-01-18 20:30:53 --> Model Class Initialized
INFO - 2018-01-18 20:30:53 --> Model Class Initialized
INFO - 2018-01-18 20:30:53 --> Model Class Initialized
INFO - 2018-01-18 20:30:53 --> Model Class Initialized
DEBUG - 2018-01-18 20:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:30:53 --> Final output sent to browser
DEBUG - 2018-01-18 20:30:53 --> Total execution time: 0.0434
INFO - 2018-01-18 20:30:54 --> Config Class Initialized
INFO - 2018-01-18 20:30:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:30:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:30:54 --> Utf8 Class Initialized
INFO - 2018-01-18 20:30:54 --> URI Class Initialized
INFO - 2018-01-18 20:30:54 --> Router Class Initialized
INFO - 2018-01-18 20:30:54 --> Output Class Initialized
INFO - 2018-01-18 20:30:54 --> Security Class Initialized
DEBUG - 2018-01-18 20:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:30:54 --> Input Class Initialized
INFO - 2018-01-18 20:30:54 --> Language Class Initialized
INFO - 2018-01-18 20:30:54 --> Loader Class Initialized
INFO - 2018-01-18 20:30:54 --> Helper loaded: url_helper
INFO - 2018-01-18 20:30:54 --> Helper loaded: form_helper
INFO - 2018-01-18 20:30:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:30:54 --> Form Validation Class Initialized
INFO - 2018-01-18 20:30:54 --> Model Class Initialized
INFO - 2018-01-18 20:30:54 --> Controller Class Initialized
INFO - 2018-01-18 20:30:54 --> Model Class Initialized
INFO - 2018-01-18 20:30:54 --> Model Class Initialized
INFO - 2018-01-18 20:30:54 --> Model Class Initialized
INFO - 2018-01-18 20:30:54 --> Model Class Initialized
DEBUG - 2018-01-18 20:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:30:55 --> Config Class Initialized
INFO - 2018-01-18 20:30:55 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:30:55 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:30:55 --> Utf8 Class Initialized
INFO - 2018-01-18 20:30:55 --> URI Class Initialized
INFO - 2018-01-18 20:30:55 --> Router Class Initialized
INFO - 2018-01-18 20:30:55 --> Output Class Initialized
INFO - 2018-01-18 20:30:55 --> Security Class Initialized
DEBUG - 2018-01-18 20:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:30:55 --> Input Class Initialized
INFO - 2018-01-18 20:30:55 --> Language Class Initialized
INFO - 2018-01-18 20:30:55 --> Loader Class Initialized
INFO - 2018-01-18 20:30:55 --> Helper loaded: url_helper
INFO - 2018-01-18 20:30:55 --> Helper loaded: form_helper
INFO - 2018-01-18 20:30:55 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:30:55 --> Form Validation Class Initialized
INFO - 2018-01-18 20:30:55 --> Model Class Initialized
INFO - 2018-01-18 20:30:55 --> Controller Class Initialized
INFO - 2018-01-18 20:30:55 --> Model Class Initialized
INFO - 2018-01-18 20:30:55 --> Model Class Initialized
INFO - 2018-01-18 20:30:55 --> Model Class Initialized
INFO - 2018-01-18 20:30:55 --> Model Class Initialized
DEBUG - 2018-01-18 20:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:30:56 --> Config Class Initialized
INFO - 2018-01-18 20:30:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:30:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:30:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:30:56 --> URI Class Initialized
INFO - 2018-01-18 20:30:56 --> Router Class Initialized
INFO - 2018-01-18 20:30:56 --> Output Class Initialized
INFO - 2018-01-18 20:30:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:30:56 --> Input Class Initialized
INFO - 2018-01-18 20:30:56 --> Language Class Initialized
INFO - 2018-01-18 20:30:56 --> Loader Class Initialized
INFO - 2018-01-18 20:30:56 --> Helper loaded: url_helper
INFO - 2018-01-18 20:30:56 --> Helper loaded: form_helper
INFO - 2018-01-18 20:30:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:30:56 --> Form Validation Class Initialized
INFO - 2018-01-18 20:30:56 --> Model Class Initialized
INFO - 2018-01-18 20:30:56 --> Controller Class Initialized
INFO - 2018-01-18 20:30:56 --> Model Class Initialized
INFO - 2018-01-18 20:30:56 --> Model Class Initialized
INFO - 2018-01-18 20:30:56 --> Model Class Initialized
INFO - 2018-01-18 20:30:56 --> Model Class Initialized
DEBUG - 2018-01-18 20:30:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:42:40 --> Config Class Initialized
INFO - 2018-01-18 20:42:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:42:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:42:40 --> Utf8 Class Initialized
INFO - 2018-01-18 20:42:40 --> URI Class Initialized
INFO - 2018-01-18 20:42:40 --> Router Class Initialized
INFO - 2018-01-18 20:42:40 --> Output Class Initialized
INFO - 2018-01-18 20:42:40 --> Security Class Initialized
DEBUG - 2018-01-18 20:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:42:40 --> Input Class Initialized
INFO - 2018-01-18 20:42:40 --> Language Class Initialized
INFO - 2018-01-18 20:42:40 --> Loader Class Initialized
INFO - 2018-01-18 20:42:40 --> Helper loaded: url_helper
INFO - 2018-01-18 20:42:40 --> Helper loaded: form_helper
INFO - 2018-01-18 20:42:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:42:40 --> Form Validation Class Initialized
INFO - 2018-01-18 20:42:40 --> Model Class Initialized
INFO - 2018-01-18 20:42:40 --> Controller Class Initialized
INFO - 2018-01-18 20:42:40 --> Model Class Initialized
INFO - 2018-01-18 20:42:40 --> Model Class Initialized
INFO - 2018-01-18 20:42:40 --> Model Class Initialized
INFO - 2018-01-18 20:42:40 --> Model Class Initialized
DEBUG - 2018-01-18 20:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:42:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:42:40 --> Final output sent to browser
DEBUG - 2018-01-18 20:42:40 --> Total execution time: 0.0467
INFO - 2018-01-18 20:42:43 --> Config Class Initialized
INFO - 2018-01-18 20:42:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:42:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:42:43 --> Utf8 Class Initialized
INFO - 2018-01-18 20:42:43 --> URI Class Initialized
INFO - 2018-01-18 20:42:43 --> Router Class Initialized
INFO - 2018-01-18 20:42:43 --> Output Class Initialized
INFO - 2018-01-18 20:42:43 --> Security Class Initialized
DEBUG - 2018-01-18 20:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:42:43 --> Input Class Initialized
INFO - 2018-01-18 20:42:43 --> Language Class Initialized
INFO - 2018-01-18 20:42:43 --> Loader Class Initialized
INFO - 2018-01-18 20:42:43 --> Helper loaded: url_helper
INFO - 2018-01-18 20:42:43 --> Helper loaded: form_helper
INFO - 2018-01-18 20:42:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:42:43 --> Form Validation Class Initialized
INFO - 2018-01-18 20:42:43 --> Model Class Initialized
INFO - 2018-01-18 20:42:43 --> Controller Class Initialized
INFO - 2018-01-18 20:42:43 --> Model Class Initialized
INFO - 2018-01-18 20:42:43 --> Model Class Initialized
INFO - 2018-01-18 20:42:43 --> Model Class Initialized
INFO - 2018-01-18 20:42:43 --> Model Class Initialized
DEBUG - 2018-01-18 20:42:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:42:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:42:43 --> Final output sent to browser
DEBUG - 2018-01-18 20:42:43 --> Total execution time: 0.0465
INFO - 2018-01-18 20:42:44 --> Config Class Initialized
INFO - 2018-01-18 20:42:44 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:42:44 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:42:44 --> Utf8 Class Initialized
INFO - 2018-01-18 20:42:44 --> URI Class Initialized
INFO - 2018-01-18 20:42:44 --> Router Class Initialized
INFO - 2018-01-18 20:42:44 --> Output Class Initialized
INFO - 2018-01-18 20:42:44 --> Security Class Initialized
DEBUG - 2018-01-18 20:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:42:44 --> Input Class Initialized
INFO - 2018-01-18 20:42:44 --> Language Class Initialized
INFO - 2018-01-18 20:42:44 --> Loader Class Initialized
INFO - 2018-01-18 20:42:44 --> Helper loaded: url_helper
INFO - 2018-01-18 20:42:44 --> Helper loaded: form_helper
INFO - 2018-01-18 20:42:44 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:42:44 --> Form Validation Class Initialized
INFO - 2018-01-18 20:42:44 --> Model Class Initialized
INFO - 2018-01-18 20:42:44 --> Controller Class Initialized
INFO - 2018-01-18 20:42:44 --> Model Class Initialized
INFO - 2018-01-18 20:42:44 --> Model Class Initialized
INFO - 2018-01-18 20:42:44 --> Model Class Initialized
INFO - 2018-01-18 20:42:44 --> Model Class Initialized
DEBUG - 2018-01-18 20:42:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:43:00 --> Config Class Initialized
INFO - 2018-01-18 20:43:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:00 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:00 --> URI Class Initialized
INFO - 2018-01-18 20:43:00 --> Router Class Initialized
INFO - 2018-01-18 20:43:00 --> Output Class Initialized
INFO - 2018-01-18 20:43:00 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:00 --> Input Class Initialized
INFO - 2018-01-18 20:43:00 --> Language Class Initialized
INFO - 2018-01-18 20:43:00 --> Loader Class Initialized
INFO - 2018-01-18 20:43:00 --> Helper loaded: url_helper
INFO - 2018-01-18 20:43:00 --> Helper loaded: form_helper
INFO - 2018-01-18 20:43:00 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:43:00 --> Form Validation Class Initialized
INFO - 2018-01-18 20:43:00 --> Model Class Initialized
INFO - 2018-01-18 20:43:00 --> Controller Class Initialized
INFO - 2018-01-18 20:43:00 --> Model Class Initialized
INFO - 2018-01-18 20:43:00 --> Model Class Initialized
INFO - 2018-01-18 20:43:00 --> Model Class Initialized
INFO - 2018-01-18 20:43:00 --> Model Class Initialized
DEBUG - 2018-01-18 20:43:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:43:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:43:00 --> Final output sent to browser
DEBUG - 2018-01-18 20:43:00 --> Total execution time: 0.0674
INFO - 2018-01-18 20:43:00 --> Config Class Initialized
INFO - 2018-01-18 20:43:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:00 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:00 --> URI Class Initialized
INFO - 2018-01-18 20:43:00 --> Router Class Initialized
INFO - 2018-01-18 20:43:00 --> Output Class Initialized
INFO - 2018-01-18 20:43:00 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:00 --> Input Class Initialized
INFO - 2018-01-18 20:43:00 --> Language Class Initialized
ERROR - 2018-01-18 20:43:00 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:43:00 --> Config Class Initialized
INFO - 2018-01-18 20:43:00 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:00 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:00 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:00 --> URI Class Initialized
INFO - 2018-01-18 20:43:00 --> Router Class Initialized
INFO - 2018-01-18 20:43:00 --> Output Class Initialized
INFO - 2018-01-18 20:43:00 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:00 --> Input Class Initialized
INFO - 2018-01-18 20:43:00 --> Language Class Initialized
ERROR - 2018-01-18 20:43:00 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:43:07 --> Config Class Initialized
INFO - 2018-01-18 20:43:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:07 --> URI Class Initialized
INFO - 2018-01-18 20:43:07 --> Router Class Initialized
INFO - 2018-01-18 20:43:07 --> Output Class Initialized
INFO - 2018-01-18 20:43:07 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:07 --> Input Class Initialized
INFO - 2018-01-18 20:43:07 --> Language Class Initialized
ERROR - 2018-01-18 20:43:07 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:43:10 --> Config Class Initialized
INFO - 2018-01-18 20:43:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:10 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:10 --> URI Class Initialized
INFO - 2018-01-18 20:43:10 --> Router Class Initialized
INFO - 2018-01-18 20:43:10 --> Output Class Initialized
INFO - 2018-01-18 20:43:10 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:10 --> Input Class Initialized
INFO - 2018-01-18 20:43:10 --> Language Class Initialized
ERROR - 2018-01-18 20:43:10 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:43:13 --> Config Class Initialized
INFO - 2018-01-18 20:43:13 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:13 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:13 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:13 --> URI Class Initialized
INFO - 2018-01-18 20:43:13 --> Router Class Initialized
INFO - 2018-01-18 20:43:13 --> Output Class Initialized
INFO - 2018-01-18 20:43:13 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:13 --> Input Class Initialized
INFO - 2018-01-18 20:43:13 --> Language Class Initialized
ERROR - 2018-01-18 20:43:13 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:43:17 --> Config Class Initialized
INFO - 2018-01-18 20:43:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:17 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:17 --> URI Class Initialized
INFO - 2018-01-18 20:43:17 --> Router Class Initialized
INFO - 2018-01-18 20:43:17 --> Output Class Initialized
INFO - 2018-01-18 20:43:17 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:17 --> Input Class Initialized
INFO - 2018-01-18 20:43:17 --> Language Class Initialized
ERROR - 2018-01-18 20:43:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:43:17 --> Config Class Initialized
INFO - 2018-01-18 20:43:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:17 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:17 --> URI Class Initialized
INFO - 2018-01-18 20:43:17 --> Router Class Initialized
INFO - 2018-01-18 20:43:17 --> Output Class Initialized
INFO - 2018-01-18 20:43:17 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:17 --> Input Class Initialized
INFO - 2018-01-18 20:43:17 --> Language Class Initialized
ERROR - 2018-01-18 20:43:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:43:17 --> Config Class Initialized
INFO - 2018-01-18 20:43:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:43:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:43:17 --> Utf8 Class Initialized
INFO - 2018-01-18 20:43:17 --> URI Class Initialized
INFO - 2018-01-18 20:43:17 --> Router Class Initialized
INFO - 2018-01-18 20:43:17 --> Output Class Initialized
INFO - 2018-01-18 20:43:17 --> Security Class Initialized
DEBUG - 2018-01-18 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:43:17 --> Input Class Initialized
INFO - 2018-01-18 20:43:17 --> Language Class Initialized
ERROR - 2018-01-18 20:43:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:45:16 --> Config Class Initialized
INFO - 2018-01-18 20:45:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:45:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:45:16 --> Utf8 Class Initialized
INFO - 2018-01-18 20:45:16 --> URI Class Initialized
INFO - 2018-01-18 20:45:16 --> Router Class Initialized
INFO - 2018-01-18 20:45:16 --> Output Class Initialized
INFO - 2018-01-18 20:45:16 --> Security Class Initialized
DEBUG - 2018-01-18 20:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:45:16 --> Input Class Initialized
INFO - 2018-01-18 20:45:16 --> Language Class Initialized
INFO - 2018-01-18 20:45:16 --> Loader Class Initialized
INFO - 2018-01-18 20:45:16 --> Helper loaded: url_helper
INFO - 2018-01-18 20:45:16 --> Helper loaded: form_helper
INFO - 2018-01-18 20:45:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:45:16 --> Form Validation Class Initialized
INFO - 2018-01-18 20:45:16 --> Model Class Initialized
INFO - 2018-01-18 20:45:16 --> Controller Class Initialized
INFO - 2018-01-18 20:45:16 --> Model Class Initialized
INFO - 2018-01-18 20:45:16 --> Model Class Initialized
INFO - 2018-01-18 20:45:16 --> Model Class Initialized
INFO - 2018-01-18 20:45:16 --> Model Class Initialized
DEBUG - 2018-01-18 20:45:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:45:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:45:16 --> Final output sent to browser
DEBUG - 2018-01-18 20:45:16 --> Total execution time: 0.0517
INFO - 2018-01-18 20:45:22 --> Config Class Initialized
INFO - 2018-01-18 20:45:22 --> Hooks Class Initialized
INFO - 2018-01-18 20:45:22 --> Config Class Initialized
INFO - 2018-01-18 20:45:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:45:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:45:22 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:45:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:45:22 --> Utf8 Class Initialized
INFO - 2018-01-18 20:45:22 --> URI Class Initialized
INFO - 2018-01-18 20:45:22 --> URI Class Initialized
INFO - 2018-01-18 20:45:22 --> Router Class Initialized
INFO - 2018-01-18 20:45:22 --> Router Class Initialized
INFO - 2018-01-18 20:45:22 --> Output Class Initialized
INFO - 2018-01-18 20:45:22 --> Output Class Initialized
INFO - 2018-01-18 20:45:22 --> Security Class Initialized
INFO - 2018-01-18 20:45:22 --> Security Class Initialized
DEBUG - 2018-01-18 20:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:45:22 --> Input Class Initialized
INFO - 2018-01-18 20:45:22 --> Language Class Initialized
ERROR - 2018-01-18 20:45:22 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-01-18 20:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:45:22 --> Input Class Initialized
INFO - 2018-01-18 20:45:22 --> Language Class Initialized
ERROR - 2018-01-18 20:45:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:45:22 --> Config Class Initialized
INFO - 2018-01-18 20:45:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:45:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:45:22 --> Utf8 Class Initialized
INFO - 2018-01-18 20:45:22 --> URI Class Initialized
INFO - 2018-01-18 20:45:22 --> Router Class Initialized
INFO - 2018-01-18 20:45:22 --> Output Class Initialized
INFO - 2018-01-18 20:45:22 --> Security Class Initialized
DEBUG - 2018-01-18 20:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:45:22 --> Input Class Initialized
INFO - 2018-01-18 20:45:22 --> Language Class Initialized
ERROR - 2018-01-18 20:45:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:46:09 --> Config Class Initialized
INFO - 2018-01-18 20:46:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:09 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:09 --> URI Class Initialized
INFO - 2018-01-18 20:46:09 --> Router Class Initialized
INFO - 2018-01-18 20:46:09 --> Output Class Initialized
INFO - 2018-01-18 20:46:09 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:09 --> Input Class Initialized
INFO - 2018-01-18 20:46:09 --> Language Class Initialized
INFO - 2018-01-18 20:46:09 --> Loader Class Initialized
INFO - 2018-01-18 20:46:09 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:09 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:09 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:09 --> Model Class Initialized
INFO - 2018-01-18 20:46:09 --> Controller Class Initialized
INFO - 2018-01-18 20:46:09 --> Model Class Initialized
INFO - 2018-01-18 20:46:09 --> Model Class Initialized
INFO - 2018-01-18 20:46:09 --> Model Class Initialized
INFO - 2018-01-18 20:46:09 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:46:09 --> Final output sent to browser
DEBUG - 2018-01-18 20:46:09 --> Total execution time: 0.0541
INFO - 2018-01-18 20:46:14 --> Config Class Initialized
INFO - 2018-01-18 20:46:14 --> Hooks Class Initialized
INFO - 2018-01-18 20:46:14 --> Config Class Initialized
DEBUG - 2018-01-18 20:46:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:14 --> Hooks Class Initialized
INFO - 2018-01-18 20:46:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:14 --> URI Class Initialized
DEBUG - 2018-01-18 20:46:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:14 --> Router Class Initialized
INFO - 2018-01-18 20:46:14 --> URI Class Initialized
INFO - 2018-01-18 20:46:14 --> Router Class Initialized
INFO - 2018-01-18 20:46:14 --> Output Class Initialized
INFO - 2018-01-18 20:46:14 --> Security Class Initialized
INFO - 2018-01-18 20:46:14 --> Output Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:14 --> Input Class Initialized
INFO - 2018-01-18 20:46:14 --> Security Class Initialized
INFO - 2018-01-18 20:46:14 --> Language Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:14 --> Input Class Initialized
INFO - 2018-01-18 20:46:14 --> Language Class Initialized
INFO - 2018-01-18 20:46:14 --> Loader Class Initialized
INFO - 2018-01-18 20:46:14 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:14 --> Loader Class Initialized
INFO - 2018-01-18 20:46:14 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:14 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:14 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:14 --> Database Driver Class Initialized
INFO - 2018-01-18 20:46:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-18 20:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:14 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Controller Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:14 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Controller Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
INFO - 2018-01-18 20:46:14 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:14 --> Config Class Initialized
INFO - 2018-01-18 20:46:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:14 --> URI Class Initialized
INFO - 2018-01-18 20:46:14 --> Router Class Initialized
INFO - 2018-01-18 20:46:14 --> Output Class Initialized
INFO - 2018-01-18 20:46:14 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:14 --> Input Class Initialized
INFO - 2018-01-18 20:46:14 --> Language Class Initialized
ERROR - 2018-01-18 20:46:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:46:14 --> Config Class Initialized
INFO - 2018-01-18 20:46:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:14 --> URI Class Initialized
INFO - 2018-01-18 20:46:14 --> Router Class Initialized
INFO - 2018-01-18 20:46:14 --> Output Class Initialized
INFO - 2018-01-18 20:46:14 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:14 --> Input Class Initialized
INFO - 2018-01-18 20:46:14 --> Language Class Initialized
ERROR - 2018-01-18 20:46:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:46:14 --> Config Class Initialized
INFO - 2018-01-18 20:46:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:14 --> URI Class Initialized
INFO - 2018-01-18 20:46:14 --> Router Class Initialized
INFO - 2018-01-18 20:46:14 --> Output Class Initialized
INFO - 2018-01-18 20:46:14 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:14 --> Input Class Initialized
INFO - 2018-01-18 20:46:14 --> Language Class Initialized
ERROR - 2018-01-18 20:46:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:46:18 --> Config Class Initialized
INFO - 2018-01-18 20:46:18 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:18 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:18 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:18 --> URI Class Initialized
INFO - 2018-01-18 20:46:18 --> Router Class Initialized
INFO - 2018-01-18 20:46:18 --> Output Class Initialized
INFO - 2018-01-18 20:46:18 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:18 --> Input Class Initialized
INFO - 2018-01-18 20:46:18 --> Language Class Initialized
INFO - 2018-01-18 20:46:18 --> Loader Class Initialized
INFO - 2018-01-18 20:46:18 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:18 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:18 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:18 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:18 --> Model Class Initialized
INFO - 2018-01-18 20:46:18 --> Controller Class Initialized
INFO - 2018-01-18 20:46:18 --> Model Class Initialized
INFO - 2018-01-18 20:46:18 --> Model Class Initialized
INFO - 2018-01-18 20:46:18 --> Model Class Initialized
INFO - 2018-01-18 20:46:18 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:25 --> Config Class Initialized
INFO - 2018-01-18 20:46:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:25 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:25 --> URI Class Initialized
INFO - 2018-01-18 20:46:25 --> Router Class Initialized
INFO - 2018-01-18 20:46:25 --> Output Class Initialized
INFO - 2018-01-18 20:46:25 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:25 --> Input Class Initialized
INFO - 2018-01-18 20:46:25 --> Language Class Initialized
INFO - 2018-01-18 20:46:25 --> Loader Class Initialized
INFO - 2018-01-18 20:46:25 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:25 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:25 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:25 --> Model Class Initialized
INFO - 2018-01-18 20:46:25 --> Controller Class Initialized
INFO - 2018-01-18 20:46:25 --> Model Class Initialized
INFO - 2018-01-18 20:46:25 --> Model Class Initialized
INFO - 2018-01-18 20:46:25 --> Model Class Initialized
INFO - 2018-01-18 20:46:25 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:35 --> Config Class Initialized
INFO - 2018-01-18 20:46:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:35 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:35 --> URI Class Initialized
INFO - 2018-01-18 20:46:35 --> Router Class Initialized
INFO - 2018-01-18 20:46:35 --> Output Class Initialized
INFO - 2018-01-18 20:46:35 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:35 --> Input Class Initialized
INFO - 2018-01-18 20:46:35 --> Language Class Initialized
INFO - 2018-01-18 20:46:35 --> Loader Class Initialized
INFO - 2018-01-18 20:46:35 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:35 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:35 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:35 --> Model Class Initialized
INFO - 2018-01-18 20:46:35 --> Controller Class Initialized
INFO - 2018-01-18 20:46:35 --> Model Class Initialized
INFO - 2018-01-18 20:46:35 --> Model Class Initialized
INFO - 2018-01-18 20:46:35 --> Model Class Initialized
INFO - 2018-01-18 20:46:35 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:37 --> Config Class Initialized
INFO - 2018-01-18 20:46:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:37 --> URI Class Initialized
INFO - 2018-01-18 20:46:37 --> Router Class Initialized
INFO - 2018-01-18 20:46:37 --> Output Class Initialized
INFO - 2018-01-18 20:46:37 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:37 --> Input Class Initialized
INFO - 2018-01-18 20:46:37 --> Language Class Initialized
INFO - 2018-01-18 20:46:37 --> Loader Class Initialized
INFO - 2018-01-18 20:46:37 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:37 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:37 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:37 --> Model Class Initialized
INFO - 2018-01-18 20:46:37 --> Controller Class Initialized
INFO - 2018-01-18 20:46:37 --> Model Class Initialized
INFO - 2018-01-18 20:46:37 --> Model Class Initialized
INFO - 2018-01-18 20:46:37 --> Model Class Initialized
INFO - 2018-01-18 20:46:37 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:56 --> Config Class Initialized
INFO - 2018-01-18 20:46:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:56 --> URI Class Initialized
INFO - 2018-01-18 20:46:56 --> Router Class Initialized
INFO - 2018-01-18 20:46:56 --> Output Class Initialized
INFO - 2018-01-18 20:46:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:56 --> Input Class Initialized
INFO - 2018-01-18 20:46:56 --> Language Class Initialized
INFO - 2018-01-18 20:46:56 --> Loader Class Initialized
INFO - 2018-01-18 20:46:56 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:56 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:56 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Controller Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:46:56 --> Final output sent to browser
DEBUG - 2018-01-18 20:46:56 --> Total execution time: 0.1109
INFO - 2018-01-18 20:46:56 --> Config Class Initialized
INFO - 2018-01-18 20:46:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:56 --> URI Class Initialized
INFO - 2018-01-18 20:46:56 --> Router Class Initialized
INFO - 2018-01-18 20:46:56 --> Output Class Initialized
INFO - 2018-01-18 20:46:56 --> Security Class Initialized
INFO - 2018-01-18 20:46:56 --> Config Class Initialized
INFO - 2018-01-18 20:46:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:56 --> Input Class Initialized
INFO - 2018-01-18 20:46:56 --> Language Class Initialized
DEBUG - 2018-01-18 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:56 --> URI Class Initialized
INFO - 2018-01-18 20:46:56 --> Router Class Initialized
INFO - 2018-01-18 20:46:56 --> Loader Class Initialized
INFO - 2018-01-18 20:46:56 --> Helper loaded: url_helper
INFO - 2018-01-18 20:46:56 --> Output Class Initialized
INFO - 2018-01-18 20:46:56 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:56 --> Input Class Initialized
INFO - 2018-01-18 20:46:56 --> Language Class Initialized
INFO - 2018-01-18 20:46:56 --> Config Class Initialized
INFO - 2018-01-18 20:46:56 --> Hooks Class Initialized
INFO - 2018-01-18 20:46:56 --> Loader Class Initialized
INFO - 2018-01-18 20:46:56 --> Helper loaded: url_helper
DEBUG - 2018-01-18 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:56 --> Database Driver Class Initialized
INFO - 2018-01-18 20:46:56 --> URI Class Initialized
INFO - 2018-01-18 20:46:56 --> Helper loaded: form_helper
INFO - 2018-01-18 20:46:56 --> Router Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:56 --> Output Class Initialized
INFO - 2018-01-18 20:46:56 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:56 --> Security Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Controller Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:56 --> Input Class Initialized
INFO - 2018-01-18 20:46:56 --> Language Class Initialized
ERROR - 2018-01-18 20:46:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:46:56 --> Database Driver Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-18 20:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:46:56 --> Form Validation Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Controller Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
INFO - 2018-01-18 20:46:56 --> Model Class Initialized
DEBUG - 2018-01-18 20:46:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:46:57 --> Config Class Initialized
INFO - 2018-01-18 20:46:57 --> Hooks Class Initialized
INFO - 2018-01-18 20:46:57 --> Config Class Initialized
INFO - 2018-01-18 20:46:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:46:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:57 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:46:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:46:57 --> Utf8 Class Initialized
INFO - 2018-01-18 20:46:57 --> URI Class Initialized
INFO - 2018-01-18 20:46:57 --> URI Class Initialized
INFO - 2018-01-18 20:46:57 --> Router Class Initialized
INFO - 2018-01-18 20:46:57 --> Router Class Initialized
INFO - 2018-01-18 20:46:57 --> Output Class Initialized
INFO - 2018-01-18 20:46:57 --> Output Class Initialized
INFO - 2018-01-18 20:46:57 --> Security Class Initialized
INFO - 2018-01-18 20:46:57 --> Security Class Initialized
DEBUG - 2018-01-18 20:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:57 --> Input Class Initialized
INFO - 2018-01-18 20:46:57 --> Language Class Initialized
DEBUG - 2018-01-18 20:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:46:57 --> Input Class Initialized
ERROR - 2018-01-18 20:46:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:46:57 --> Language Class Initialized
ERROR - 2018-01-18 20:46:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:47:58 --> Config Class Initialized
INFO - 2018-01-18 20:47:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:47:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:47:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:47:58 --> URI Class Initialized
INFO - 2018-01-18 20:47:58 --> Router Class Initialized
INFO - 2018-01-18 20:47:58 --> Output Class Initialized
INFO - 2018-01-18 20:47:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:47:58 --> Input Class Initialized
INFO - 2018-01-18 20:47:58 --> Language Class Initialized
INFO - 2018-01-18 20:47:58 --> Loader Class Initialized
INFO - 2018-01-18 20:47:58 --> Helper loaded: url_helper
INFO - 2018-01-18 20:47:58 --> Helper loaded: form_helper
INFO - 2018-01-18 20:47:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:47:58 --> Form Validation Class Initialized
INFO - 2018-01-18 20:47:58 --> Model Class Initialized
INFO - 2018-01-18 20:47:58 --> Controller Class Initialized
INFO - 2018-01-18 20:47:58 --> Model Class Initialized
INFO - 2018-01-18 20:47:58 --> Model Class Initialized
INFO - 2018-01-18 20:47:58 --> Model Class Initialized
INFO - 2018-01-18 20:47:58 --> Model Class Initialized
DEBUG - 2018-01-18 20:47:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:47:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:47:58 --> Final output sent to browser
DEBUG - 2018-01-18 20:47:58 --> Total execution time: 0.0667
INFO - 2018-01-18 20:47:59 --> Config Class Initialized
INFO - 2018-01-18 20:47:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:47:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:47:59 --> Utf8 Class Initialized
INFO - 2018-01-18 20:47:59 --> URI Class Initialized
INFO - 2018-01-18 20:47:59 --> Router Class Initialized
INFO - 2018-01-18 20:47:59 --> Output Class Initialized
INFO - 2018-01-18 20:47:59 --> Security Class Initialized
DEBUG - 2018-01-18 20:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:47:59 --> Input Class Initialized
INFO - 2018-01-18 20:47:59 --> Language Class Initialized
ERROR - 2018-01-18 20:47:59 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:48:08 --> Config Class Initialized
INFO - 2018-01-18 20:48:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:48:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:08 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:08 --> URI Class Initialized
INFO - 2018-01-18 20:48:08 --> Router Class Initialized
INFO - 2018-01-18 20:48:08 --> Output Class Initialized
INFO - 2018-01-18 20:48:08 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:08 --> Input Class Initialized
INFO - 2018-01-18 20:48:08 --> Language Class Initialized
ERROR - 2018-01-18 20:48:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:48:08 --> Config Class Initialized
INFO - 2018-01-18 20:48:08 --> Hooks Class Initialized
INFO - 2018-01-18 20:48:08 --> Config Class Initialized
INFO - 2018-01-18 20:48:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:48:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:08 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:48:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:08 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:08 --> URI Class Initialized
INFO - 2018-01-18 20:48:08 --> URI Class Initialized
INFO - 2018-01-18 20:48:08 --> Router Class Initialized
INFO - 2018-01-18 20:48:08 --> Router Class Initialized
INFO - 2018-01-18 20:48:08 --> Output Class Initialized
INFO - 2018-01-18 20:48:08 --> Output Class Initialized
INFO - 2018-01-18 20:48:08 --> Security Class Initialized
INFO - 2018-01-18 20:48:08 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:08 --> Input Class Initialized
DEBUG - 2018-01-18 20:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:08 --> Input Class Initialized
INFO - 2018-01-18 20:48:08 --> Language Class Initialized
INFO - 2018-01-18 20:48:08 --> Language Class Initialized
ERROR - 2018-01-18 20:48:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:48:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:48:51 --> Config Class Initialized
INFO - 2018-01-18 20:48:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:48:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:51 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:51 --> URI Class Initialized
INFO - 2018-01-18 20:48:51 --> Router Class Initialized
INFO - 2018-01-18 20:48:51 --> Output Class Initialized
INFO - 2018-01-18 20:48:51 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:51 --> Input Class Initialized
INFO - 2018-01-18 20:48:51 --> Language Class Initialized
INFO - 2018-01-18 20:48:51 --> Loader Class Initialized
INFO - 2018-01-18 20:48:51 --> Helper loaded: url_helper
INFO - 2018-01-18 20:48:51 --> Helper loaded: form_helper
INFO - 2018-01-18 20:48:51 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:48:51 --> Form Validation Class Initialized
INFO - 2018-01-18 20:48:51 --> Model Class Initialized
INFO - 2018-01-18 20:48:51 --> Controller Class Initialized
INFO - 2018-01-18 20:48:51 --> Model Class Initialized
INFO - 2018-01-18 20:48:51 --> Model Class Initialized
INFO - 2018-01-18 20:48:51 --> Model Class Initialized
INFO - 2018-01-18 20:48:51 --> Model Class Initialized
DEBUG - 2018-01-18 20:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:48:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:48:51 --> Final output sent to browser
DEBUG - 2018-01-18 20:48:51 --> Total execution time: 0.0570
INFO - 2018-01-18 20:48:56 --> Config Class Initialized
INFO - 2018-01-18 20:48:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:48:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:56 --> URI Class Initialized
INFO - 2018-01-18 20:48:56 --> Router Class Initialized
INFO - 2018-01-18 20:48:56 --> Output Class Initialized
INFO - 2018-01-18 20:48:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:56 --> Input Class Initialized
INFO - 2018-01-18 20:48:56 --> Language Class Initialized
INFO - 2018-01-18 20:48:56 --> Loader Class Initialized
INFO - 2018-01-18 20:48:56 --> Helper loaded: url_helper
INFO - 2018-01-18 20:48:56 --> Helper loaded: form_helper
INFO - 2018-01-18 20:48:56 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:48:56 --> Form Validation Class Initialized
INFO - 2018-01-18 20:48:56 --> Model Class Initialized
INFO - 2018-01-18 20:48:56 --> Controller Class Initialized
INFO - 2018-01-18 20:48:56 --> Config Class Initialized
INFO - 2018-01-18 20:48:56 --> Hooks Class Initialized
INFO - 2018-01-18 20:48:56 --> Config Class Initialized
INFO - 2018-01-18 20:48:56 --> Hooks Class Initialized
INFO - 2018-01-18 20:48:56 --> Model Class Initialized
INFO - 2018-01-18 20:48:56 --> Model Class Initialized
INFO - 2018-01-18 20:48:56 --> Model Class Initialized
INFO - 2018-01-18 20:48:56 --> Model Class Initialized
DEBUG - 2018-01-18 20:48:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:56 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-18 20:48:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:56 --> URI Class Initialized
INFO - 2018-01-18 20:48:56 --> URI Class Initialized
INFO - 2018-01-18 20:48:56 --> Router Class Initialized
INFO - 2018-01-18 20:48:56 --> Router Class Initialized
INFO - 2018-01-18 20:48:56 --> Output Class Initialized
INFO - 2018-01-18 20:48:56 --> Output Class Initialized
INFO - 2018-01-18 20:48:56 --> Security Class Initialized
INFO - 2018-01-18 20:48:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:56 --> Input Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:56 --> Input Class Initialized
INFO - 2018-01-18 20:48:56 --> Language Class Initialized
INFO - 2018-01-18 20:48:56 --> Language Class Initialized
ERROR - 2018-01-18 20:48:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:48:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:48:56 --> Config Class Initialized
INFO - 2018-01-18 20:48:56 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:48:56 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:48:56 --> Utf8 Class Initialized
INFO - 2018-01-18 20:48:56 --> URI Class Initialized
INFO - 2018-01-18 20:48:56 --> Router Class Initialized
INFO - 2018-01-18 20:48:56 --> Output Class Initialized
INFO - 2018-01-18 20:48:56 --> Security Class Initialized
DEBUG - 2018-01-18 20:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:48:56 --> Input Class Initialized
INFO - 2018-01-18 20:48:56 --> Language Class Initialized
ERROR - 2018-01-18 20:48:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:49:06 --> Config Class Initialized
INFO - 2018-01-18 20:49:06 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:06 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:06 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:06 --> URI Class Initialized
INFO - 2018-01-18 20:49:06 --> Router Class Initialized
INFO - 2018-01-18 20:49:06 --> Output Class Initialized
INFO - 2018-01-18 20:49:06 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:06 --> Input Class Initialized
INFO - 2018-01-18 20:49:06 --> Language Class Initialized
INFO - 2018-01-18 20:49:06 --> Loader Class Initialized
INFO - 2018-01-18 20:49:06 --> Helper loaded: url_helper
INFO - 2018-01-18 20:49:06 --> Helper loaded: form_helper
INFO - 2018-01-18 20:49:06 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:49:06 --> Form Validation Class Initialized
INFO - 2018-01-18 20:49:06 --> Model Class Initialized
INFO - 2018-01-18 20:49:06 --> Controller Class Initialized
INFO - 2018-01-18 20:49:06 --> Model Class Initialized
INFO - 2018-01-18 20:49:06 --> Model Class Initialized
INFO - 2018-01-18 20:49:06 --> Model Class Initialized
INFO - 2018-01-18 20:49:06 --> Model Class Initialized
DEBUG - 2018-01-18 20:49:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 20:49:06 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 20:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-18 20:49:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:49:06 --> Final output sent to browser
DEBUG - 2018-01-18 20:49:06 --> Total execution time: 0.0614
INFO - 2018-01-18 20:49:07 --> Config Class Initialized
INFO - 2018-01-18 20:49:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:07 --> Config Class Initialized
INFO - 2018-01-18 20:49:07 --> Hooks Class Initialized
INFO - 2018-01-18 20:49:07 --> URI Class Initialized
DEBUG - 2018-01-18 20:49:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:07 --> Router Class Initialized
INFO - 2018-01-18 20:49:07 --> URI Class Initialized
INFO - 2018-01-18 20:49:07 --> Output Class Initialized
INFO - 2018-01-18 20:49:07 --> Router Class Initialized
INFO - 2018-01-18 20:49:07 --> Security Class Initialized
INFO - 2018-01-18 20:49:07 --> Output Class Initialized
DEBUG - 2018-01-18 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:07 --> Input Class Initialized
INFO - 2018-01-18 20:49:07 --> Language Class Initialized
INFO - 2018-01-18 20:49:07 --> Security Class Initialized
ERROR - 2018-01-18 20:49:07 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-01-18 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:07 --> Input Class Initialized
INFO - 2018-01-18 20:49:07 --> Language Class Initialized
ERROR - 2018-01-18 20:49:07 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-01-18 20:49:07 --> Config Class Initialized
INFO - 2018-01-18 20:49:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:07 --> URI Class Initialized
INFO - 2018-01-18 20:49:07 --> Router Class Initialized
INFO - 2018-01-18 20:49:07 --> Output Class Initialized
INFO - 2018-01-18 20:49:07 --> Security Class Initialized
INFO - 2018-01-18 20:49:07 --> Config Class Initialized
INFO - 2018-01-18 20:49:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:07 --> Input Class Initialized
INFO - 2018-01-18 20:49:07 --> Language Class Initialized
DEBUG - 2018-01-18 20:49:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:07 --> Utf8 Class Initialized
ERROR - 2018-01-18 20:49:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:49:07 --> URI Class Initialized
INFO - 2018-01-18 20:49:07 --> Router Class Initialized
INFO - 2018-01-18 20:49:07 --> Output Class Initialized
INFO - 2018-01-18 20:49:07 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:07 --> Input Class Initialized
INFO - 2018-01-18 20:49:07 --> Language Class Initialized
ERROR - 2018-01-18 20:49:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:49:12 --> Config Class Initialized
INFO - 2018-01-18 20:49:12 --> Hooks Class Initialized
INFO - 2018-01-18 20:49:12 --> Config Class Initialized
INFO - 2018-01-18 20:49:12 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:12 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:49:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:12 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:12 --> URI Class Initialized
INFO - 2018-01-18 20:49:12 --> URI Class Initialized
INFO - 2018-01-18 20:49:12 --> Router Class Initialized
INFO - 2018-01-18 20:49:12 --> Router Class Initialized
INFO - 2018-01-18 20:49:12 --> Config Class Initialized
INFO - 2018-01-18 20:49:12 --> Hooks Class Initialized
INFO - 2018-01-18 20:49:12 --> Output Class Initialized
INFO - 2018-01-18 20:49:12 --> Output Class Initialized
DEBUG - 2018-01-18 20:49:12 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:12 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:12 --> Security Class Initialized
INFO - 2018-01-18 20:49:12 --> Security Class Initialized
INFO - 2018-01-18 20:49:12 --> URI Class Initialized
DEBUG - 2018-01-18 20:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:12 --> Input Class Initialized
DEBUG - 2018-01-18 20:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:12 --> Language Class Initialized
INFO - 2018-01-18 20:49:12 --> Input Class Initialized
INFO - 2018-01-18 20:49:12 --> Router Class Initialized
INFO - 2018-01-18 20:49:12 --> Language Class Initialized
ERROR - 2018-01-18 20:49:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:49:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:49:12 --> Output Class Initialized
INFO - 2018-01-18 20:49:12 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:12 --> Input Class Initialized
INFO - 2018-01-18 20:49:12 --> Language Class Initialized
ERROR - 2018-01-18 20:49:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:49:52 --> Config Class Initialized
INFO - 2018-01-18 20:49:52 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:52 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:52 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:52 --> URI Class Initialized
INFO - 2018-01-18 20:49:52 --> Router Class Initialized
INFO - 2018-01-18 20:49:52 --> Output Class Initialized
INFO - 2018-01-18 20:49:52 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:52 --> Input Class Initialized
INFO - 2018-01-18 20:49:52 --> Language Class Initialized
INFO - 2018-01-18 20:49:52 --> Loader Class Initialized
INFO - 2018-01-18 20:49:52 --> Helper loaded: url_helper
INFO - 2018-01-18 20:49:52 --> Helper loaded: form_helper
INFO - 2018-01-18 20:49:52 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:49:52 --> Form Validation Class Initialized
INFO - 2018-01-18 20:49:52 --> Model Class Initialized
INFO - 2018-01-18 20:49:52 --> Controller Class Initialized
INFO - 2018-01-18 20:49:52 --> Model Class Initialized
INFO - 2018-01-18 20:49:52 --> Model Class Initialized
INFO - 2018-01-18 20:49:52 --> Model Class Initialized
INFO - 2018-01-18 20:49:52 --> Model Class Initialized
DEBUG - 2018-01-18 20:49:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 20:49:52 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 20:49:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-18 20:49:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:49:52 --> Final output sent to browser
DEBUG - 2018-01-18 20:49:52 --> Total execution time: 0.0781
INFO - 2018-01-18 20:49:57 --> Config Class Initialized
INFO - 2018-01-18 20:49:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:57 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:57 --> URI Class Initialized
INFO - 2018-01-18 20:49:57 --> Router Class Initialized
INFO - 2018-01-18 20:49:57 --> Output Class Initialized
INFO - 2018-01-18 20:49:57 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:57 --> Input Class Initialized
INFO - 2018-01-18 20:49:57 --> Language Class Initialized
ERROR - 2018-01-18 20:49:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:49:57 --> Config Class Initialized
INFO - 2018-01-18 20:49:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:57 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:57 --> URI Class Initialized
INFO - 2018-01-18 20:49:57 --> Router Class Initialized
INFO - 2018-01-18 20:49:57 --> Output Class Initialized
INFO - 2018-01-18 20:49:57 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:57 --> Input Class Initialized
INFO - 2018-01-18 20:49:57 --> Language Class Initialized
INFO - 2018-01-18 20:49:57 --> Loader Class Initialized
INFO - 2018-01-18 20:49:57 --> Helper loaded: url_helper
INFO - 2018-01-18 20:49:57 --> Helper loaded: form_helper
INFO - 2018-01-18 20:49:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:49:57 --> Form Validation Class Initialized
INFO - 2018-01-18 20:49:57 --> Model Class Initialized
INFO - 2018-01-18 20:49:57 --> Controller Class Initialized
INFO - 2018-01-18 20:49:57 --> Model Class Initialized
INFO - 2018-01-18 20:49:57 --> Model Class Initialized
INFO - 2018-01-18 20:49:57 --> Model Class Initialized
INFO - 2018-01-18 20:49:57 --> Model Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:49:57 --> Config Class Initialized
INFO - 2018-01-18 20:49:57 --> Hooks Class Initialized
INFO - 2018-01-18 20:49:57 --> Config Class Initialized
INFO - 2018-01-18 20:49:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:49:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:57 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:49:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:49:57 --> Utf8 Class Initialized
INFO - 2018-01-18 20:49:57 --> URI Class Initialized
INFO - 2018-01-18 20:49:57 --> URI Class Initialized
INFO - 2018-01-18 20:49:57 --> Router Class Initialized
INFO - 2018-01-18 20:49:57 --> Router Class Initialized
INFO - 2018-01-18 20:49:57 --> Output Class Initialized
INFO - 2018-01-18 20:49:57 --> Output Class Initialized
INFO - 2018-01-18 20:49:57 --> Security Class Initialized
INFO - 2018-01-18 20:49:57 --> Security Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:57 --> Input Class Initialized
DEBUG - 2018-01-18 20:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:49:57 --> Input Class Initialized
INFO - 2018-01-18 20:49:57 --> Language Class Initialized
INFO - 2018-01-18 20:49:57 --> Language Class Initialized
ERROR - 2018-01-18 20:49:57 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:49:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:50:07 --> Config Class Initialized
INFO - 2018-01-18 20:50:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:07 --> URI Class Initialized
INFO - 2018-01-18 20:50:07 --> Router Class Initialized
INFO - 2018-01-18 20:50:07 --> Output Class Initialized
INFO - 2018-01-18 20:50:07 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:07 --> Input Class Initialized
INFO - 2018-01-18 20:50:07 --> Language Class Initialized
INFO - 2018-01-18 20:50:07 --> Loader Class Initialized
INFO - 2018-01-18 20:50:07 --> Helper loaded: url_helper
INFO - 2018-01-18 20:50:07 --> Helper loaded: form_helper
INFO - 2018-01-18 20:50:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:50:07 --> Form Validation Class Initialized
INFO - 2018-01-18 20:50:07 --> Model Class Initialized
INFO - 2018-01-18 20:50:07 --> Controller Class Initialized
INFO - 2018-01-18 20:50:07 --> Model Class Initialized
INFO - 2018-01-18 20:50:07 --> Model Class Initialized
INFO - 2018-01-18 20:50:07 --> Model Class Initialized
INFO - 2018-01-18 20:50:07 --> Model Class Initialized
DEBUG - 2018-01-18 20:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:50:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:50:07 --> Final output sent to browser
DEBUG - 2018-01-18 20:50:07 --> Total execution time: 0.0640
INFO - 2018-01-18 20:50:08 --> Config Class Initialized
INFO - 2018-01-18 20:50:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:08 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:08 --> Config Class Initialized
INFO - 2018-01-18 20:50:08 --> Hooks Class Initialized
INFO - 2018-01-18 20:50:08 --> URI Class Initialized
DEBUG - 2018-01-18 20:50:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:08 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:08 --> Router Class Initialized
INFO - 2018-01-18 20:50:08 --> URI Class Initialized
INFO - 2018-01-18 20:50:08 --> Router Class Initialized
INFO - 2018-01-18 20:50:08 --> Output Class Initialized
INFO - 2018-01-18 20:50:08 --> Output Class Initialized
INFO - 2018-01-18 20:50:08 --> Security Class Initialized
INFO - 2018-01-18 20:50:08 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:08 --> Input Class Initialized
INFO - 2018-01-18 20:50:08 --> Language Class Initialized
ERROR - 2018-01-18 20:50:08 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-01-18 20:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:08 --> Input Class Initialized
INFO - 2018-01-18 20:50:08 --> Language Class Initialized
ERROR - 2018-01-18 20:50:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:50:08 --> Config Class Initialized
INFO - 2018-01-18 20:50:08 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:08 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:08 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:08 --> URI Class Initialized
INFO - 2018-01-18 20:50:08 --> Router Class Initialized
INFO - 2018-01-18 20:50:08 --> Output Class Initialized
INFO - 2018-01-18 20:50:08 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:08 --> Input Class Initialized
INFO - 2018-01-18 20:50:08 --> Language Class Initialized
ERROR - 2018-01-18 20:50:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:50:42 --> Config Class Initialized
INFO - 2018-01-18 20:50:42 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:42 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:42 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:42 --> URI Class Initialized
INFO - 2018-01-18 20:50:42 --> Router Class Initialized
INFO - 2018-01-18 20:50:42 --> Output Class Initialized
INFO - 2018-01-18 20:50:42 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:42 --> Input Class Initialized
INFO - 2018-01-18 20:50:42 --> Language Class Initialized
INFO - 2018-01-18 20:50:42 --> Loader Class Initialized
INFO - 2018-01-18 20:50:42 --> Helper loaded: url_helper
INFO - 2018-01-18 20:50:42 --> Helper loaded: form_helper
INFO - 2018-01-18 20:50:42 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:50:42 --> Form Validation Class Initialized
INFO - 2018-01-18 20:50:42 --> Model Class Initialized
INFO - 2018-01-18 20:50:42 --> Controller Class Initialized
INFO - 2018-01-18 20:50:42 --> Model Class Initialized
INFO - 2018-01-18 20:50:42 --> Model Class Initialized
INFO - 2018-01-18 20:50:42 --> Model Class Initialized
INFO - 2018-01-18 20:50:42 --> Model Class Initialized
DEBUG - 2018-01-18 20:50:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 20:50:42 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 20:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-18 20:50:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:50:42 --> Final output sent to browser
DEBUG - 2018-01-18 20:50:42 --> Total execution time: 0.0744
INFO - 2018-01-18 20:50:43 --> Config Class Initialized
INFO - 2018-01-18 20:50:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:43 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:43 --> URI Class Initialized
INFO - 2018-01-18 20:50:43 --> Router Class Initialized
INFO - 2018-01-18 20:50:43 --> Output Class Initialized
INFO - 2018-01-18 20:50:43 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:43 --> Input Class Initialized
INFO - 2018-01-18 20:50:43 --> Language Class Initialized
INFO - 2018-01-18 20:50:43 --> Loader Class Initialized
INFO - 2018-01-18 20:50:43 --> Helper loaded: url_helper
INFO - 2018-01-18 20:50:43 --> Helper loaded: form_helper
INFO - 2018-01-18 20:50:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:50:43 --> Form Validation Class Initialized
INFO - 2018-01-18 20:50:43 --> Model Class Initialized
INFO - 2018-01-18 20:50:43 --> Controller Class Initialized
INFO - 2018-01-18 20:50:43 --> Model Class Initialized
INFO - 2018-01-18 20:50:43 --> Model Class Initialized
INFO - 2018-01-18 20:50:43 --> Model Class Initialized
INFO - 2018-01-18 20:50:43 --> Model Class Initialized
DEBUG - 2018-01-18 20:50:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:50:46 --> Config Class Initialized
INFO - 2018-01-18 20:50:46 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:46 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:46 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:46 --> URI Class Initialized
INFO - 2018-01-18 20:50:46 --> Router Class Initialized
INFO - 2018-01-18 20:50:46 --> Output Class Initialized
INFO - 2018-01-18 20:50:46 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:46 --> Input Class Initialized
INFO - 2018-01-18 20:50:46 --> Language Class Initialized
INFO - 2018-01-18 20:50:46 --> Loader Class Initialized
INFO - 2018-01-18 20:50:46 --> Helper loaded: url_helper
INFO - 2018-01-18 20:50:46 --> Helper loaded: form_helper
INFO - 2018-01-18 20:50:46 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:50:46 --> Form Validation Class Initialized
INFO - 2018-01-18 20:50:46 --> Model Class Initialized
INFO - 2018-01-18 20:50:46 --> Controller Class Initialized
INFO - 2018-01-18 20:50:46 --> Model Class Initialized
INFO - 2018-01-18 20:50:46 --> Model Class Initialized
INFO - 2018-01-18 20:50:46 --> Model Class Initialized
INFO - 2018-01-18 20:50:46 --> Model Class Initialized
DEBUG - 2018-01-18 20:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:50:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:50:46 --> Final output sent to browser
DEBUG - 2018-01-18 20:50:46 --> Total execution time: 0.0676
INFO - 2018-01-18 20:50:50 --> Config Class Initialized
INFO - 2018-01-18 20:50:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:50 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:50 --> URI Class Initialized
INFO - 2018-01-18 20:50:50 --> Router Class Initialized
INFO - 2018-01-18 20:50:50 --> Output Class Initialized
INFO - 2018-01-18 20:50:50 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:50 --> Input Class Initialized
INFO - 2018-01-18 20:50:50 --> Language Class Initialized
ERROR - 2018-01-18 20:50:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:50:50 --> Config Class Initialized
INFO - 2018-01-18 20:50:50 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:50:50 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:50:50 --> Utf8 Class Initialized
INFO - 2018-01-18 20:50:50 --> URI Class Initialized
INFO - 2018-01-18 20:50:50 --> Router Class Initialized
INFO - 2018-01-18 20:50:50 --> Output Class Initialized
INFO - 2018-01-18 20:50:50 --> Security Class Initialized
DEBUG - 2018-01-18 20:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:50:50 --> Input Class Initialized
INFO - 2018-01-18 20:50:50 --> Language Class Initialized
ERROR - 2018-01-18 20:50:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:51:47 --> Config Class Initialized
INFO - 2018-01-18 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:47 --> URI Class Initialized
INFO - 2018-01-18 20:51:47 --> Router Class Initialized
INFO - 2018-01-18 20:51:47 --> Output Class Initialized
INFO - 2018-01-18 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:47 --> Input Class Initialized
INFO - 2018-01-18 20:51:47 --> Language Class Initialized
INFO - 2018-01-18 20:51:47 --> Loader Class Initialized
INFO - 2018-01-18 20:51:47 --> Helper loaded: url_helper
INFO - 2018-01-18 20:51:47 --> Helper loaded: form_helper
INFO - 2018-01-18 20:51:47 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:51:47 --> Form Validation Class Initialized
INFO - 2018-01-18 20:51:47 --> Model Class Initialized
INFO - 2018-01-18 20:51:47 --> Controller Class Initialized
INFO - 2018-01-18 20:51:47 --> Model Class Initialized
INFO - 2018-01-18 20:51:47 --> Model Class Initialized
INFO - 2018-01-18 20:51:47 --> Model Class Initialized
INFO - 2018-01-18 20:51:47 --> Model Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:51:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:51:47 --> Final output sent to browser
DEBUG - 2018-01-18 20:51:47 --> Total execution time: 0.0523
INFO - 2018-01-18 20:51:47 --> Config Class Initialized
INFO - 2018-01-18 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:47 --> URI Class Initialized
INFO - 2018-01-18 20:51:47 --> Router Class Initialized
INFO - 2018-01-18 20:51:47 --> Output Class Initialized
INFO - 2018-01-18 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:47 --> Input Class Initialized
INFO - 2018-01-18 20:51:47 --> Language Class Initialized
INFO - 2018-01-18 20:51:47 --> Config Class Initialized
ERROR - 2018-01-18 20:51:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:47 --> URI Class Initialized
INFO - 2018-01-18 20:51:47 --> Router Class Initialized
INFO - 2018-01-18 20:51:47 --> Output Class Initialized
INFO - 2018-01-18 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:47 --> Input Class Initialized
INFO - 2018-01-18 20:51:47 --> Language Class Initialized
ERROR - 2018-01-18 20:51:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:51:47 --> Config Class Initialized
INFO - 2018-01-18 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:47 --> URI Class Initialized
INFO - 2018-01-18 20:51:47 --> Router Class Initialized
INFO - 2018-01-18 20:51:47 --> Output Class Initialized
INFO - 2018-01-18 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:47 --> Input Class Initialized
INFO - 2018-01-18 20:51:47 --> Language Class Initialized
ERROR - 2018-01-18 20:51:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:51:53 --> Config Class Initialized
INFO - 2018-01-18 20:51:53 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:53 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:53 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:53 --> URI Class Initialized
INFO - 2018-01-18 20:51:53 --> Router Class Initialized
INFO - 2018-01-18 20:51:53 --> Output Class Initialized
INFO - 2018-01-18 20:51:53 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:53 --> Input Class Initialized
INFO - 2018-01-18 20:51:53 --> Language Class Initialized
INFO - 2018-01-18 20:51:53 --> Loader Class Initialized
INFO - 2018-01-18 20:51:53 --> Helper loaded: url_helper
INFO - 2018-01-18 20:51:53 --> Helper loaded: form_helper
INFO - 2018-01-18 20:51:53 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:51:53 --> Form Validation Class Initialized
INFO - 2018-01-18 20:51:53 --> Model Class Initialized
INFO - 2018-01-18 20:51:53 --> Controller Class Initialized
INFO - 2018-01-18 20:51:53 --> Model Class Initialized
INFO - 2018-01-18 20:51:53 --> Model Class Initialized
INFO - 2018-01-18 20:51:53 --> Model Class Initialized
INFO - 2018-01-18 20:51:53 --> Model Class Initialized
DEBUG - 2018-01-18 20:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:51:53 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:51:53 --> Final output sent to browser
DEBUG - 2018-01-18 20:51:53 --> Total execution time: 0.0649
INFO - 2018-01-18 20:51:58 --> Config Class Initialized
INFO - 2018-01-18 20:51:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:58 --> URI Class Initialized
INFO - 2018-01-18 20:51:58 --> Router Class Initialized
INFO - 2018-01-18 20:51:58 --> Output Class Initialized
INFO - 2018-01-18 20:51:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:58 --> Input Class Initialized
INFO - 2018-01-18 20:51:58 --> Language Class Initialized
ERROR - 2018-01-18 20:51:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:51:58 --> Config Class Initialized
INFO - 2018-01-18 20:51:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:51:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:58 --> URI Class Initialized
INFO - 2018-01-18 20:51:58 --> Router Class Initialized
INFO - 2018-01-18 20:51:58 --> Config Class Initialized
INFO - 2018-01-18 20:51:58 --> Hooks Class Initialized
INFO - 2018-01-18 20:51:58 --> Output Class Initialized
INFO - 2018-01-18 20:51:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:51:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:51:58 --> URI Class Initialized
DEBUG - 2018-01-18 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:58 --> Input Class Initialized
INFO - 2018-01-18 20:51:58 --> Language Class Initialized
INFO - 2018-01-18 20:51:58 --> Router Class Initialized
ERROR - 2018-01-18 20:51:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:51:58 --> Output Class Initialized
INFO - 2018-01-18 20:51:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:51:58 --> Input Class Initialized
INFO - 2018-01-18 20:51:58 --> Language Class Initialized
ERROR - 2018-01-18 20:51:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:52:16 --> Config Class Initialized
INFO - 2018-01-18 20:52:16 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:16 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:16 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:16 --> URI Class Initialized
INFO - 2018-01-18 20:52:16 --> Router Class Initialized
INFO - 2018-01-18 20:52:16 --> Output Class Initialized
INFO - 2018-01-18 20:52:16 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:16 --> Input Class Initialized
INFO - 2018-01-18 20:52:16 --> Language Class Initialized
INFO - 2018-01-18 20:52:16 --> Loader Class Initialized
INFO - 2018-01-18 20:52:16 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:16 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:16 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:16 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:16 --> Model Class Initialized
INFO - 2018-01-18 20:52:16 --> Controller Class Initialized
INFO - 2018-01-18 20:52:16 --> Model Class Initialized
INFO - 2018-01-18 20:52:16 --> Model Class Initialized
INFO - 2018-01-18 20:52:16 --> Model Class Initialized
INFO - 2018-01-18 20:52:16 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 20:52:16 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 20:52:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-18 20:52:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:52:16 --> Final output sent to browser
DEBUG - 2018-01-18 20:52:16 --> Total execution time: 0.0769
INFO - 2018-01-18 20:52:17 --> Config Class Initialized
INFO - 2018-01-18 20:52:17 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:17 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:17 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:17 --> URI Class Initialized
INFO - 2018-01-18 20:52:17 --> Router Class Initialized
INFO - 2018-01-18 20:52:17 --> Output Class Initialized
INFO - 2018-01-18 20:52:17 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:17 --> Input Class Initialized
INFO - 2018-01-18 20:52:17 --> Language Class Initialized
INFO - 2018-01-18 20:52:17 --> Loader Class Initialized
INFO - 2018-01-18 20:52:17 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:17 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:17 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:17 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:17 --> Model Class Initialized
INFO - 2018-01-18 20:52:17 --> Controller Class Initialized
INFO - 2018-01-18 20:52:17 --> Model Class Initialized
INFO - 2018-01-18 20:52:17 --> Model Class Initialized
INFO - 2018-01-18 20:52:17 --> Model Class Initialized
INFO - 2018-01-18 20:52:17 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:25 --> Config Class Initialized
INFO - 2018-01-18 20:52:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:25 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:25 --> URI Class Initialized
INFO - 2018-01-18 20:52:25 --> Router Class Initialized
INFO - 2018-01-18 20:52:25 --> Output Class Initialized
INFO - 2018-01-18 20:52:25 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:25 --> Input Class Initialized
INFO - 2018-01-18 20:52:25 --> Language Class Initialized
INFO - 2018-01-18 20:52:25 --> Loader Class Initialized
INFO - 2018-01-18 20:52:25 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:25 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:25 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:25 --> Model Class Initialized
INFO - 2018-01-18 20:52:25 --> Controller Class Initialized
INFO - 2018-01-18 20:52:25 --> Model Class Initialized
INFO - 2018-01-18 20:52:25 --> Model Class Initialized
INFO - 2018-01-18 20:52:25 --> Model Class Initialized
INFO - 2018-01-18 20:52:25 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:52:25 --> Final output sent to browser
DEBUG - 2018-01-18 20:52:25 --> Total execution time: 0.0658
INFO - 2018-01-18 20:52:31 --> Config Class Initialized
INFO - 2018-01-18 20:52:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:31 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:31 --> URI Class Initialized
INFO - 2018-01-18 20:52:31 --> Router Class Initialized
INFO - 2018-01-18 20:52:31 --> Output Class Initialized
INFO - 2018-01-18 20:52:31 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:31 --> Input Class Initialized
INFO - 2018-01-18 20:52:31 --> Language Class Initialized
INFO - 2018-01-18 20:52:31 --> Loader Class Initialized
INFO - 2018-01-18 20:52:31 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:31 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:31 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Controller Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:52:31 --> Final output sent to browser
DEBUG - 2018-01-18 20:52:31 --> Total execution time: 0.0472
INFO - 2018-01-18 20:52:31 --> Config Class Initialized
INFO - 2018-01-18 20:52:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:31 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:31 --> URI Class Initialized
INFO - 2018-01-18 20:52:31 --> Router Class Initialized
INFO - 2018-01-18 20:52:31 --> Output Class Initialized
INFO - 2018-01-18 20:52:31 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:31 --> Input Class Initialized
INFO - 2018-01-18 20:52:31 --> Language Class Initialized
INFO - 2018-01-18 20:52:31 --> Loader Class Initialized
INFO - 2018-01-18 20:52:31 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:31 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:31 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Controller Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
INFO - 2018-01-18 20:52:31 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:39 --> Config Class Initialized
INFO - 2018-01-18 20:52:39 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:39 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:39 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:39 --> URI Class Initialized
INFO - 2018-01-18 20:52:39 --> Router Class Initialized
INFO - 2018-01-18 20:52:39 --> Output Class Initialized
INFO - 2018-01-18 20:52:39 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:39 --> Input Class Initialized
INFO - 2018-01-18 20:52:39 --> Language Class Initialized
INFO - 2018-01-18 20:52:39 --> Loader Class Initialized
INFO - 2018-01-18 20:52:39 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:39 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:39 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:39 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:39 --> Model Class Initialized
INFO - 2018-01-18 20:52:39 --> Controller Class Initialized
INFO - 2018-01-18 20:52:39 --> Model Class Initialized
INFO - 2018-01-18 20:52:39 --> Model Class Initialized
INFO - 2018-01-18 20:52:39 --> Model Class Initialized
INFO - 2018-01-18 20:52:39 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:52:39 --> Final output sent to browser
DEBUG - 2018-01-18 20:52:39 --> Total execution time: 0.0509
INFO - 2018-01-18 20:52:40 --> Config Class Initialized
INFO - 2018-01-18 20:52:40 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:40 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:40 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:40 --> URI Class Initialized
INFO - 2018-01-18 20:52:40 --> Router Class Initialized
INFO - 2018-01-18 20:52:40 --> Output Class Initialized
INFO - 2018-01-18 20:52:40 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:40 --> Input Class Initialized
INFO - 2018-01-18 20:52:40 --> Language Class Initialized
INFO - 2018-01-18 20:52:40 --> Loader Class Initialized
INFO - 2018-01-18 20:52:40 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:40 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:40 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:40 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:40 --> Model Class Initialized
INFO - 2018-01-18 20:52:40 --> Controller Class Initialized
INFO - 2018-01-18 20:52:40 --> Model Class Initialized
INFO - 2018-01-18 20:52:40 --> Model Class Initialized
INFO - 2018-01-18 20:52:40 --> Model Class Initialized
INFO - 2018-01-18 20:52:40 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:58 --> Config Class Initialized
INFO - 2018-01-18 20:52:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:58 --> URI Class Initialized
INFO - 2018-01-18 20:52:58 --> Router Class Initialized
INFO - 2018-01-18 20:52:58 --> Output Class Initialized
INFO - 2018-01-18 20:52:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:58 --> Input Class Initialized
INFO - 2018-01-18 20:52:58 --> Language Class Initialized
INFO - 2018-01-18 20:52:58 --> Loader Class Initialized
INFO - 2018-01-18 20:52:58 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:58 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:58 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:58 --> Model Class Initialized
INFO - 2018-01-18 20:52:58 --> Controller Class Initialized
INFO - 2018-01-18 20:52:58 --> Model Class Initialized
INFO - 2018-01-18 20:52:58 --> Model Class Initialized
INFO - 2018-01-18 20:52:58 --> Model Class Initialized
INFO - 2018-01-18 20:52:58 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:52:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:52:58 --> Final output sent to browser
DEBUG - 2018-01-18 20:52:58 --> Total execution time: 0.0642
INFO - 2018-01-18 20:52:59 --> Config Class Initialized
INFO - 2018-01-18 20:52:59 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:52:59 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:52:59 --> Utf8 Class Initialized
INFO - 2018-01-18 20:52:59 --> URI Class Initialized
INFO - 2018-01-18 20:52:59 --> Router Class Initialized
INFO - 2018-01-18 20:52:59 --> Output Class Initialized
INFO - 2018-01-18 20:52:59 --> Security Class Initialized
DEBUG - 2018-01-18 20:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:52:59 --> Input Class Initialized
INFO - 2018-01-18 20:52:59 --> Language Class Initialized
INFO - 2018-01-18 20:52:59 --> Loader Class Initialized
INFO - 2018-01-18 20:52:59 --> Helper loaded: url_helper
INFO - 2018-01-18 20:52:59 --> Helper loaded: form_helper
INFO - 2018-01-18 20:52:59 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:52:59 --> Form Validation Class Initialized
INFO - 2018-01-18 20:52:59 --> Model Class Initialized
INFO - 2018-01-18 20:52:59 --> Controller Class Initialized
INFO - 2018-01-18 20:52:59 --> Model Class Initialized
INFO - 2018-01-18 20:52:59 --> Model Class Initialized
INFO - 2018-01-18 20:52:59 --> Model Class Initialized
INFO - 2018-01-18 20:52:59 --> Model Class Initialized
DEBUG - 2018-01-18 20:52:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:53:07 --> Config Class Initialized
INFO - 2018-01-18 20:53:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:07 --> URI Class Initialized
INFO - 2018-01-18 20:53:07 --> Router Class Initialized
INFO - 2018-01-18 20:53:07 --> Output Class Initialized
INFO - 2018-01-18 20:53:07 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:07 --> Input Class Initialized
INFO - 2018-01-18 20:53:07 --> Language Class Initialized
INFO - 2018-01-18 20:53:07 --> Loader Class Initialized
INFO - 2018-01-18 20:53:07 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:07 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:07 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Controller Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:53:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:53:07 --> Final output sent to browser
DEBUG - 2018-01-18 20:53:07 --> Total execution time: 0.0545
INFO - 2018-01-18 20:53:07 --> Config Class Initialized
INFO - 2018-01-18 20:53:07 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:07 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:07 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:07 --> URI Class Initialized
INFO - 2018-01-18 20:53:07 --> Router Class Initialized
INFO - 2018-01-18 20:53:07 --> Output Class Initialized
INFO - 2018-01-18 20:53:07 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:07 --> Input Class Initialized
INFO - 2018-01-18 20:53:07 --> Language Class Initialized
INFO - 2018-01-18 20:53:07 --> Loader Class Initialized
INFO - 2018-01-18 20:53:07 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:07 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:07 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:07 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Controller Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
INFO - 2018-01-18 20:53:07 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:53:09 --> Config Class Initialized
INFO - 2018-01-18 20:53:09 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:09 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:09 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:09 --> URI Class Initialized
INFO - 2018-01-18 20:53:09 --> Router Class Initialized
INFO - 2018-01-18 20:53:09 --> Output Class Initialized
INFO - 2018-01-18 20:53:09 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:09 --> Input Class Initialized
INFO - 2018-01-18 20:53:09 --> Language Class Initialized
INFO - 2018-01-18 20:53:09 --> Loader Class Initialized
INFO - 2018-01-18 20:53:09 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:09 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:09 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:09 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:09 --> Model Class Initialized
INFO - 2018-01-18 20:53:09 --> Controller Class Initialized
INFO - 2018-01-18 20:53:09 --> Model Class Initialized
INFO - 2018-01-18 20:53:09 --> Model Class Initialized
INFO - 2018-01-18 20:53:09 --> Model Class Initialized
INFO - 2018-01-18 20:53:09 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-18 20:53:09 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-18 20:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-18 20:53:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:53:09 --> Final output sent to browser
DEBUG - 2018-01-18 20:53:09 --> Total execution time: 0.0563
INFO - 2018-01-18 20:53:10 --> Config Class Initialized
INFO - 2018-01-18 20:53:10 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:10 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:10 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:10 --> URI Class Initialized
INFO - 2018-01-18 20:53:10 --> Router Class Initialized
INFO - 2018-01-18 20:53:10 --> Output Class Initialized
INFO - 2018-01-18 20:53:10 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:10 --> Input Class Initialized
INFO - 2018-01-18 20:53:10 --> Language Class Initialized
INFO - 2018-01-18 20:53:10 --> Loader Class Initialized
INFO - 2018-01-18 20:53:10 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:10 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:10 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:10 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:10 --> Model Class Initialized
INFO - 2018-01-18 20:53:10 --> Controller Class Initialized
INFO - 2018-01-18 20:53:10 --> Model Class Initialized
INFO - 2018-01-18 20:53:10 --> Model Class Initialized
INFO - 2018-01-18 20:53:10 --> Model Class Initialized
INFO - 2018-01-18 20:53:10 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:53:14 --> Config Class Initialized
INFO - 2018-01-18 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:14 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:14 --> URI Class Initialized
INFO - 2018-01-18 20:53:14 --> Router Class Initialized
INFO - 2018-01-18 20:53:14 --> Output Class Initialized
INFO - 2018-01-18 20:53:14 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:14 --> Input Class Initialized
INFO - 2018-01-18 20:53:14 --> Language Class Initialized
INFO - 2018-01-18 20:53:14 --> Loader Class Initialized
INFO - 2018-01-18 20:53:14 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:14 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:14 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:14 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:14 --> Model Class Initialized
INFO - 2018-01-18 20:53:14 --> Controller Class Initialized
INFO - 2018-01-18 20:53:14 --> Model Class Initialized
INFO - 2018-01-18 20:53:14 --> Model Class Initialized
INFO - 2018-01-18 20:53:14 --> Model Class Initialized
INFO - 2018-01-18 20:53:14 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:53:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:53:14 --> Final output sent to browser
DEBUG - 2018-01-18 20:53:14 --> Total execution time: 0.0553
INFO - 2018-01-18 20:53:15 --> Config Class Initialized
INFO - 2018-01-18 20:53:15 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:53:15 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:53:15 --> Utf8 Class Initialized
INFO - 2018-01-18 20:53:15 --> URI Class Initialized
INFO - 2018-01-18 20:53:15 --> Router Class Initialized
INFO - 2018-01-18 20:53:15 --> Output Class Initialized
INFO - 2018-01-18 20:53:15 --> Security Class Initialized
DEBUG - 2018-01-18 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:53:15 --> Input Class Initialized
INFO - 2018-01-18 20:53:15 --> Language Class Initialized
INFO - 2018-01-18 20:53:15 --> Loader Class Initialized
INFO - 2018-01-18 20:53:15 --> Helper loaded: url_helper
INFO - 2018-01-18 20:53:15 --> Helper loaded: form_helper
INFO - 2018-01-18 20:53:15 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:53:15 --> Form Validation Class Initialized
INFO - 2018-01-18 20:53:15 --> Model Class Initialized
INFO - 2018-01-18 20:53:15 --> Controller Class Initialized
INFO - 2018-01-18 20:53:15 --> Model Class Initialized
INFO - 2018-01-18 20:53:15 --> Model Class Initialized
INFO - 2018-01-18 20:53:15 --> Model Class Initialized
INFO - 2018-01-18 20:53:15 --> Model Class Initialized
DEBUG - 2018-01-18 20:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:25 --> Config Class Initialized
INFO - 2018-01-18 20:55:25 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:25 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:25 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:25 --> URI Class Initialized
INFO - 2018-01-18 20:55:25 --> Router Class Initialized
INFO - 2018-01-18 20:55:25 --> Output Class Initialized
INFO - 2018-01-18 20:55:25 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:25 --> Input Class Initialized
INFO - 2018-01-18 20:55:25 --> Language Class Initialized
INFO - 2018-01-18 20:55:25 --> Loader Class Initialized
INFO - 2018-01-18 20:55:25 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:25 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:25 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:25 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:25 --> Model Class Initialized
INFO - 2018-01-18 20:55:25 --> Controller Class Initialized
INFO - 2018-01-18 20:55:25 --> Model Class Initialized
INFO - 2018-01-18 20:55:25 --> Model Class Initialized
INFO - 2018-01-18 20:55:25 --> Model Class Initialized
INFO - 2018-01-18 20:55:25 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:55:25 --> Final output sent to browser
DEBUG - 2018-01-18 20:55:25 --> Total execution time: 0.0724
INFO - 2018-01-18 20:55:28 --> Config Class Initialized
INFO - 2018-01-18 20:55:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:28 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:28 --> URI Class Initialized
INFO - 2018-01-18 20:55:28 --> Router Class Initialized
INFO - 2018-01-18 20:55:28 --> Output Class Initialized
INFO - 2018-01-18 20:55:28 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:28 --> Input Class Initialized
INFO - 2018-01-18 20:55:28 --> Language Class Initialized
INFO - 2018-01-18 20:55:28 --> Loader Class Initialized
INFO - 2018-01-18 20:55:28 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:28 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:28 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:28 --> Model Class Initialized
INFO - 2018-01-18 20:55:28 --> Controller Class Initialized
INFO - 2018-01-18 20:55:28 --> Model Class Initialized
INFO - 2018-01-18 20:55:28 --> Model Class Initialized
INFO - 2018-01-18 20:55:28 --> Model Class Initialized
INFO - 2018-01-18 20:55:28 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:35 --> Config Class Initialized
INFO - 2018-01-18 20:55:35 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:35 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:35 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:35 --> URI Class Initialized
INFO - 2018-01-18 20:55:35 --> Router Class Initialized
INFO - 2018-01-18 20:55:35 --> Output Class Initialized
INFO - 2018-01-18 20:55:35 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:35 --> Input Class Initialized
INFO - 2018-01-18 20:55:35 --> Language Class Initialized
INFO - 2018-01-18 20:55:35 --> Loader Class Initialized
INFO - 2018-01-18 20:55:35 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:35 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:35 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:35 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:35 --> Model Class Initialized
INFO - 2018-01-18 20:55:35 --> Controller Class Initialized
INFO - 2018-01-18 20:55:35 --> Model Class Initialized
INFO - 2018-01-18 20:55:35 --> Model Class Initialized
INFO - 2018-01-18 20:55:35 --> Model Class Initialized
INFO - 2018-01-18 20:55:35 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:55:35 --> Final output sent to browser
DEBUG - 2018-01-18 20:55:35 --> Total execution time: 0.0524
INFO - 2018-01-18 20:55:37 --> Config Class Initialized
INFO - 2018-01-18 20:55:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:37 --> URI Class Initialized
INFO - 2018-01-18 20:55:37 --> Router Class Initialized
INFO - 2018-01-18 20:55:37 --> Output Class Initialized
INFO - 2018-01-18 20:55:37 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:37 --> Input Class Initialized
INFO - 2018-01-18 20:55:37 --> Language Class Initialized
INFO - 2018-01-18 20:55:37 --> Config Class Initialized
INFO - 2018-01-18 20:55:37 --> Hooks Class Initialized
INFO - 2018-01-18 20:55:37 --> Loader Class Initialized
DEBUG - 2018-01-18 20:55:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:37 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:37 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:37 --> URI Class Initialized
INFO - 2018-01-18 20:55:37 --> Router Class Initialized
INFO - 2018-01-18 20:55:37 --> Output Class Initialized
INFO - 2018-01-18 20:55:37 --> Database Driver Class Initialized
INFO - 2018-01-18 20:55:37 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-18 20:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:37 --> Input Class Initialized
INFO - 2018-01-18 20:55:37 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:37 --> Language Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Controller Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:37 --> Loader Class Initialized
INFO - 2018-01-18 20:55:37 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:37 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:37 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:37 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Controller Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
INFO - 2018-01-18 20:55:37 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:43 --> Config Class Initialized
INFO - 2018-01-18 20:55:43 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:43 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:43 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:43 --> URI Class Initialized
INFO - 2018-01-18 20:55:43 --> Router Class Initialized
INFO - 2018-01-18 20:55:43 --> Output Class Initialized
INFO - 2018-01-18 20:55:43 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:43 --> Input Class Initialized
INFO - 2018-01-18 20:55:43 --> Language Class Initialized
INFO - 2018-01-18 20:55:43 --> Loader Class Initialized
INFO - 2018-01-18 20:55:43 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:43 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:43 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:43 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:43 --> Model Class Initialized
INFO - 2018-01-18 20:55:43 --> Controller Class Initialized
INFO - 2018-01-18 20:55:43 --> Model Class Initialized
INFO - 2018-01-18 20:55:43 --> Model Class Initialized
INFO - 2018-01-18 20:55:43 --> Model Class Initialized
INFO - 2018-01-18 20:55:43 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:55:43 --> Final output sent to browser
DEBUG - 2018-01-18 20:55:43 --> Total execution time: 0.0568
INFO - 2018-01-18 20:55:49 --> Config Class Initialized
INFO - 2018-01-18 20:55:49 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:55:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:49 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:49 --> URI Class Initialized
INFO - 2018-01-18 20:55:49 --> Router Class Initialized
INFO - 2018-01-18 20:55:49 --> Output Class Initialized
INFO - 2018-01-18 20:55:49 --> Security Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:49 --> Input Class Initialized
INFO - 2018-01-18 20:55:49 --> Language Class Initialized
INFO - 2018-01-18 20:55:49 --> Loader Class Initialized
INFO - 2018-01-18 20:55:49 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:49 --> Config Class Initialized
INFO - 2018-01-18 20:55:49 --> Hooks Class Initialized
INFO - 2018-01-18 20:55:49 --> Helper loaded: form_helper
DEBUG - 2018-01-18 20:55:49 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:55:49 --> Utf8 Class Initialized
INFO - 2018-01-18 20:55:49 --> URI Class Initialized
INFO - 2018-01-18 20:55:49 --> Router Class Initialized
INFO - 2018-01-18 20:55:49 --> Output Class Initialized
INFO - 2018-01-18 20:55:49 --> Security Class Initialized
INFO - 2018-01-18 20:55:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:55:49 --> Input Class Initialized
INFO - 2018-01-18 20:55:49 --> Language Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:49 --> Loader Class Initialized
INFO - 2018-01-18 20:55:49 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:49 --> Helper loaded: url_helper
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Controller Class Initialized
INFO - 2018-01-18 20:55:49 --> Helper loaded: form_helper
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:55:49 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:55:49 --> Form Validation Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Controller Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
INFO - 2018-01-18 20:55:49 --> Model Class Initialized
DEBUG - 2018-01-18 20:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:56:19 --> Config Class Initialized
INFO - 2018-01-18 20:56:19 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:56:19 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:19 --> Utf8 Class Initialized
INFO - 2018-01-18 20:56:19 --> URI Class Initialized
INFO - 2018-01-18 20:56:19 --> Router Class Initialized
INFO - 2018-01-18 20:56:19 --> Output Class Initialized
INFO - 2018-01-18 20:56:19 --> Security Class Initialized
DEBUG - 2018-01-18 20:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:19 --> Input Class Initialized
INFO - 2018-01-18 20:56:19 --> Language Class Initialized
INFO - 2018-01-18 20:56:19 --> Loader Class Initialized
INFO - 2018-01-18 20:56:19 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:19 --> Helper loaded: form_helper
INFO - 2018-01-18 20:56:19 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:56:19 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:19 --> Model Class Initialized
INFO - 2018-01-18 20:56:19 --> Controller Class Initialized
INFO - 2018-01-18 20:56:19 --> Model Class Initialized
INFO - 2018-01-18 20:56:19 --> Model Class Initialized
INFO - 2018-01-18 20:56:19 --> Model Class Initialized
INFO - 2018-01-18 20:56:19 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:56:19 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:56:19 --> Final output sent to browser
DEBUG - 2018-01-18 20:56:19 --> Total execution time: 0.0558
INFO - 2018-01-18 20:56:22 --> Config Class Initialized
INFO - 2018-01-18 20:56:22 --> Hooks Class Initialized
INFO - 2018-01-18 20:56:22 --> Config Class Initialized
INFO - 2018-01-18 20:56:22 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:56:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:22 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:56:22 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:22 --> Utf8 Class Initialized
INFO - 2018-01-18 20:56:22 --> URI Class Initialized
INFO - 2018-01-18 20:56:22 --> URI Class Initialized
INFO - 2018-01-18 20:56:22 --> Router Class Initialized
INFO - 2018-01-18 20:56:22 --> Router Class Initialized
INFO - 2018-01-18 20:56:22 --> Output Class Initialized
INFO - 2018-01-18 20:56:22 --> Output Class Initialized
INFO - 2018-01-18 20:56:22 --> Security Class Initialized
INFO - 2018-01-18 20:56:22 --> Security Class Initialized
DEBUG - 2018-01-18 20:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:22 --> Input Class Initialized
DEBUG - 2018-01-18 20:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:22 --> Language Class Initialized
INFO - 2018-01-18 20:56:22 --> Input Class Initialized
INFO - 2018-01-18 20:56:22 --> Language Class Initialized
INFO - 2018-01-18 20:56:22 --> Loader Class Initialized
INFO - 2018-01-18 20:56:22 --> Loader Class Initialized
INFO - 2018-01-18 20:56:22 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:22 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:22 --> Helper loaded: form_helper
INFO - 2018-01-18 20:56:22 --> Helper loaded: form_helper
INFO - 2018-01-18 20:56:22 --> Database Driver Class Initialized
INFO - 2018-01-18 20:56:22 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-18 20:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:22 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Controller Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:56:22 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Controller Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
INFO - 2018-01-18 20:56:22 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:56:48 --> Config Class Initialized
INFO - 2018-01-18 20:56:48 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:56:48 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:48 --> Utf8 Class Initialized
INFO - 2018-01-18 20:56:48 --> URI Class Initialized
INFO - 2018-01-18 20:56:48 --> Router Class Initialized
INFO - 2018-01-18 20:56:48 --> Output Class Initialized
INFO - 2018-01-18 20:56:48 --> Security Class Initialized
DEBUG - 2018-01-18 20:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:48 --> Input Class Initialized
INFO - 2018-01-18 20:56:48 --> Language Class Initialized
INFO - 2018-01-18 20:56:48 --> Loader Class Initialized
INFO - 2018-01-18 20:56:48 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:48 --> Helper loaded: form_helper
INFO - 2018-01-18 20:56:48 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:56:48 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:48 --> Model Class Initialized
INFO - 2018-01-18 20:56:48 --> Controller Class Initialized
INFO - 2018-01-18 20:56:48 --> Model Class Initialized
INFO - 2018-01-18 20:56:48 --> Model Class Initialized
INFO - 2018-01-18 20:56:48 --> Model Class Initialized
INFO - 2018-01-18 20:56:48 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:56:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:56:48 --> Final output sent to browser
DEBUG - 2018-01-18 20:56:48 --> Total execution time: 0.0553
INFO - 2018-01-18 20:56:51 --> Config Class Initialized
INFO - 2018-01-18 20:56:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:56:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:51 --> Utf8 Class Initialized
INFO - 2018-01-18 20:56:51 --> URI Class Initialized
INFO - 2018-01-18 20:56:51 --> Router Class Initialized
INFO - 2018-01-18 20:56:51 --> Output Class Initialized
INFO - 2018-01-18 20:56:51 --> Security Class Initialized
INFO - 2018-01-18 20:56:51 --> Config Class Initialized
INFO - 2018-01-18 20:56:51 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:51 --> Input Class Initialized
INFO - 2018-01-18 20:56:51 --> Language Class Initialized
DEBUG - 2018-01-18 20:56:51 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:56:51 --> Utf8 Class Initialized
INFO - 2018-01-18 20:56:51 --> URI Class Initialized
INFO - 2018-01-18 20:56:51 --> Router Class Initialized
INFO - 2018-01-18 20:56:51 --> Loader Class Initialized
INFO - 2018-01-18 20:56:51 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:51 --> Output Class Initialized
INFO - 2018-01-18 20:56:51 --> Helper loaded: form_helper
INFO - 2018-01-18 20:56:51 --> Security Class Initialized
DEBUG - 2018-01-18 20:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:56:51 --> Input Class Initialized
INFO - 2018-01-18 20:56:51 --> Language Class Initialized
INFO - 2018-01-18 20:56:51 --> Loader Class Initialized
INFO - 2018-01-18 20:56:51 --> Helper loaded: url_helper
INFO - 2018-01-18 20:56:51 --> Database Driver Class Initialized
INFO - 2018-01-18 20:56:51 --> Helper loaded: form_helper
DEBUG - 2018-01-18 20:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:56:51 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Controller Class Initialized
INFO - 2018-01-18 20:56:51 --> Database Driver Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-18 20:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:56:51 --> Form Validation Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Controller Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
INFO - 2018-01-18 20:56:51 --> Model Class Initialized
DEBUG - 2018-01-18 20:56:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:28 --> Config Class Initialized
INFO - 2018-01-18 20:59:28 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:28 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:28 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:28 --> URI Class Initialized
INFO - 2018-01-18 20:59:28 --> Router Class Initialized
INFO - 2018-01-18 20:59:28 --> Output Class Initialized
INFO - 2018-01-18 20:59:28 --> Security Class Initialized
DEBUG - 2018-01-18 20:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:28 --> Input Class Initialized
INFO - 2018-01-18 20:59:28 --> Language Class Initialized
INFO - 2018-01-18 20:59:28 --> Loader Class Initialized
INFO - 2018-01-18 20:59:28 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:28 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:28 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:28 --> Form Validation Class Initialized
INFO - 2018-01-18 20:59:28 --> Model Class Initialized
INFO - 2018-01-18 20:59:28 --> Controller Class Initialized
INFO - 2018-01-18 20:59:28 --> Model Class Initialized
INFO - 2018-01-18 20:59:28 --> Model Class Initialized
INFO - 2018-01-18 20:59:28 --> Model Class Initialized
INFO - 2018-01-18 20:59:28 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:28 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:59:28 --> Final output sent to browser
DEBUG - 2018-01-18 20:59:28 --> Total execution time: 0.0574
INFO - 2018-01-18 20:59:31 --> Config Class Initialized
INFO - 2018-01-18 20:59:31 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:31 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:31 --> URI Class Initialized
INFO - 2018-01-18 20:59:31 --> Router Class Initialized
INFO - 2018-01-18 20:59:31 --> Config Class Initialized
INFO - 2018-01-18 20:59:31 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:31 --> Output Class Initialized
DEBUG - 2018-01-18 20:59:31 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:31 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:31 --> URI Class Initialized
INFO - 2018-01-18 20:59:31 --> Security Class Initialized
INFO - 2018-01-18 20:59:31 --> Router Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:31 --> Input Class Initialized
INFO - 2018-01-18 20:59:31 --> Language Class Initialized
INFO - 2018-01-18 20:59:31 --> Output Class Initialized
INFO - 2018-01-18 20:59:31 --> Security Class Initialized
INFO - 2018-01-18 20:59:31 --> Loader Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:31 --> Input Class Initialized
INFO - 2018-01-18 20:59:31 --> Language Class Initialized
INFO - 2018-01-18 20:59:31 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:31 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:31 --> Loader Class Initialized
INFO - 2018-01-18 20:59:31 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:31 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:31 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:31 --> Database Driver Class Initialized
INFO - 2018-01-18 20:59:31 --> Form Validation Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Controller Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:31 --> Form Validation Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Controller Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
INFO - 2018-01-18 20:59:31 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:37 --> Config Class Initialized
INFO - 2018-01-18 20:59:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:37 --> URI Class Initialized
INFO - 2018-01-18 20:59:37 --> Router Class Initialized
INFO - 2018-01-18 20:59:37 --> Output Class Initialized
INFO - 2018-01-18 20:59:37 --> Security Class Initialized
DEBUG - 2018-01-18 20:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:37 --> Input Class Initialized
INFO - 2018-01-18 20:59:37 --> Language Class Initialized
ERROR - 2018-01-18 20:59:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:59:37 --> Config Class Initialized
INFO - 2018-01-18 20:59:37 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:37 --> Config Class Initialized
INFO - 2018-01-18 20:59:37 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:37 --> URI Class Initialized
DEBUG - 2018-01-18 20:59:37 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:37 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:37 --> Router Class Initialized
INFO - 2018-01-18 20:59:37 --> URI Class Initialized
INFO - 2018-01-18 20:59:37 --> Output Class Initialized
INFO - 2018-01-18 20:59:37 --> Router Class Initialized
INFO - 2018-01-18 20:59:37 --> Security Class Initialized
INFO - 2018-01-18 20:59:37 --> Output Class Initialized
DEBUG - 2018-01-18 20:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:37 --> Input Class Initialized
INFO - 2018-01-18 20:59:37 --> Language Class Initialized
INFO - 2018-01-18 20:59:37 --> Security Class Initialized
ERROR - 2018-01-18 20:59:37 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-01-18 20:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:37 --> Input Class Initialized
INFO - 2018-01-18 20:59:37 --> Language Class Initialized
ERROR - 2018-01-18 20:59:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:59:54 --> Config Class Initialized
INFO - 2018-01-18 20:59:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:54 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:54 --> URI Class Initialized
INFO - 2018-01-18 20:59:54 --> Router Class Initialized
INFO - 2018-01-18 20:59:54 --> Output Class Initialized
INFO - 2018-01-18 20:59:54 --> Security Class Initialized
DEBUG - 2018-01-18 20:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:54 --> Input Class Initialized
INFO - 2018-01-18 20:59:54 --> Language Class Initialized
INFO - 2018-01-18 20:59:54 --> Loader Class Initialized
INFO - 2018-01-18 20:59:54 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:54 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:54 --> Form Validation Class Initialized
INFO - 2018-01-18 20:59:54 --> Model Class Initialized
INFO - 2018-01-18 20:59:54 --> Controller Class Initialized
INFO - 2018-01-18 20:59:54 --> Model Class Initialized
INFO - 2018-01-18 20:59:54 --> Model Class Initialized
INFO - 2018-01-18 20:59:54 --> Model Class Initialized
INFO - 2018-01-18 20:59:54 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 20:59:54 --> Final output sent to browser
DEBUG - 2018-01-18 20:59:54 --> Total execution time: 0.0782
INFO - 2018-01-18 20:59:58 --> Config Class Initialized
INFO - 2018-01-18 20:59:58 --> Hooks Class Initialized
DEBUG - 2018-01-18 20:59:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:58 --> URI Class Initialized
INFO - 2018-01-18 20:59:58 --> Router Class Initialized
INFO - 2018-01-18 20:59:58 --> Output Class Initialized
INFO - 2018-01-18 20:59:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:58 --> Input Class Initialized
INFO - 2018-01-18 20:59:58 --> Language Class Initialized
ERROR - 2018-01-18 20:59:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 20:59:58 --> Config Class Initialized
INFO - 2018-01-18 20:59:58 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:58 --> Config Class Initialized
INFO - 2018-01-18 20:59:58 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:58 --> Config Class Initialized
DEBUG - 2018-01-18 20:59:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:58 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:58 --> Config Class Initialized
INFO - 2018-01-18 20:59:58 --> Hooks Class Initialized
INFO - 2018-01-18 20:59:58 --> URI Class Initialized
DEBUG - 2018-01-18 20:59:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:58 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:59:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:58 --> Utf8 Class Initialized
DEBUG - 2018-01-18 20:59:58 --> UTF-8 Support Enabled
INFO - 2018-01-18 20:59:58 --> Utf8 Class Initialized
INFO - 2018-01-18 20:59:58 --> Router Class Initialized
INFO - 2018-01-18 20:59:58 --> URI Class Initialized
INFO - 2018-01-18 20:59:58 --> URI Class Initialized
INFO - 2018-01-18 20:59:58 --> URI Class Initialized
INFO - 2018-01-18 20:59:58 --> Router Class Initialized
INFO - 2018-01-18 20:59:58 --> Router Class Initialized
INFO - 2018-01-18 20:59:58 --> Output Class Initialized
INFO - 2018-01-18 20:59:58 --> Router Class Initialized
INFO - 2018-01-18 20:59:58 --> Security Class Initialized
INFO - 2018-01-18 20:59:58 --> Output Class Initialized
INFO - 2018-01-18 20:59:58 --> Output Class Initialized
INFO - 2018-01-18 20:59:58 --> Output Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:58 --> Input Class Initialized
INFO - 2018-01-18 20:59:58 --> Security Class Initialized
INFO - 2018-01-18 20:59:58 --> Security Class Initialized
INFO - 2018-01-18 20:59:58 --> Language Class Initialized
INFO - 2018-01-18 20:59:58 --> Security Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-01-18 20:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:58 --> Input Class Initialized
INFO - 2018-01-18 20:59:58 --> Input Class Initialized
INFO - 2018-01-18 20:59:58 --> Language Class Initialized
INFO - 2018-01-18 20:59:58 --> Language Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 20:59:58 --> Input Class Initialized
INFO - 2018-01-18 20:59:58 --> Language Class Initialized
ERROR - 2018-01-18 20:59:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-18 20:59:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 20:59:58 --> Loader Class Initialized
INFO - 2018-01-18 20:59:58 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:58 --> Loader Class Initialized
INFO - 2018-01-18 20:59:58 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:58 --> Helper loaded: url_helper
INFO - 2018-01-18 20:59:58 --> Helper loaded: form_helper
INFO - 2018-01-18 20:59:58 --> Database Driver Class Initialized
INFO - 2018-01-18 20:59:58 --> Database Driver Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:58 --> Form Validation Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Controller Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 20:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 20:59:58 --> Form Validation Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Controller Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
INFO - 2018-01-18 20:59:58 --> Model Class Initialized
DEBUG - 2018-01-18 20:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 21:02:54 --> Config Class Initialized
INFO - 2018-01-18 21:02:54 --> Hooks Class Initialized
DEBUG - 2018-01-18 21:02:54 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:54 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:54 --> URI Class Initialized
INFO - 2018-01-18 21:02:54 --> Router Class Initialized
INFO - 2018-01-18 21:02:54 --> Output Class Initialized
INFO - 2018-01-18 21:02:54 --> Security Class Initialized
DEBUG - 2018-01-18 21:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:54 --> Input Class Initialized
INFO - 2018-01-18 21:02:54 --> Language Class Initialized
INFO - 2018-01-18 21:02:54 --> Loader Class Initialized
INFO - 2018-01-18 21:02:54 --> Helper loaded: url_helper
INFO - 2018-01-18 21:02:54 --> Helper loaded: form_helper
INFO - 2018-01-18 21:02:54 --> Database Driver Class Initialized
DEBUG - 2018-01-18 21:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 21:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 21:02:54 --> Form Validation Class Initialized
INFO - 2018-01-18 21:02:54 --> Model Class Initialized
INFO - 2018-01-18 21:02:54 --> Controller Class Initialized
INFO - 2018-01-18 21:02:54 --> Model Class Initialized
INFO - 2018-01-18 21:02:54 --> Model Class Initialized
INFO - 2018-01-18 21:02:54 --> Model Class Initialized
INFO - 2018-01-18 21:02:54 --> Model Class Initialized
DEBUG - 2018-01-18 21:02:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 21:02:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-18 21:02:54 --> Final output sent to browser
DEBUG - 2018-01-18 21:02:54 --> Total execution time: 0.0513
INFO - 2018-01-18 21:02:57 --> Config Class Initialized
INFO - 2018-01-18 21:02:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:57 --> Config Class Initialized
INFO - 2018-01-18 21:02:57 --> Hooks Class Initialized
INFO - 2018-01-18 21:02:57 --> URI Class Initialized
DEBUG - 2018-01-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:57 --> URI Class Initialized
INFO - 2018-01-18 21:02:57 --> Router Class Initialized
INFO - 2018-01-18 21:02:57 --> Router Class Initialized
INFO - 2018-01-18 21:02:57 --> Config Class Initialized
INFO - 2018-01-18 21:02:57 --> Hooks Class Initialized
INFO - 2018-01-18 21:02:57 --> Output Class Initialized
INFO - 2018-01-18 21:02:57 --> Output Class Initialized
DEBUG - 2018-01-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:57 --> Security Class Initialized
INFO - 2018-01-18 21:02:57 --> Security Class Initialized
INFO - 2018-01-18 21:02:57 --> URI Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:57 --> Input Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:57 --> Router Class Initialized
INFO - 2018-01-18 21:02:57 --> Input Class Initialized
INFO - 2018-01-18 21:02:57 --> Language Class Initialized
INFO - 2018-01-18 21:02:57 --> Language Class Initialized
INFO - 2018-01-18 21:02:57 --> Output Class Initialized
INFO - 2018-01-18 21:02:57 --> Security Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:57 --> Input Class Initialized
INFO - 2018-01-18 21:02:57 --> Language Class Initialized
INFO - 2018-01-18 21:02:57 --> Loader Class Initialized
ERROR - 2018-01-18 21:02:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-18 21:02:57 --> Loader Class Initialized
INFO - 2018-01-18 21:02:57 --> Helper loaded: url_helper
INFO - 2018-01-18 21:02:57 --> Helper loaded: url_helper
INFO - 2018-01-18 21:02:57 --> Helper loaded: form_helper
INFO - 2018-01-18 21:02:57 --> Helper loaded: form_helper
INFO - 2018-01-18 21:02:57 --> Database Driver Class Initialized
INFO - 2018-01-18 21:02:57 --> Database Driver Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 21:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 21:02:57 --> Form Validation Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Controller Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-18 21:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-18 21:02:57 --> Config Class Initialized
INFO - 2018-01-18 21:02:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:57 --> Form Validation Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Controller Class Initialized
INFO - 2018-01-18 21:02:57 --> URI Class Initialized
INFO - 2018-01-18 21:02:57 --> Router Class Initialized
INFO - 2018-01-18 21:02:57 --> Output Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Security Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
INFO - 2018-01-18 21:02:57 --> Model Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:57 --> Input Class Initialized
INFO - 2018-01-18 21:02:57 --> Language Class Initialized
ERROR - 2018-01-18 21:02:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-18 21:02:57 --> Config Class Initialized
INFO - 2018-01-18 21:02:57 --> Hooks Class Initialized
DEBUG - 2018-01-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-01-18 21:02:57 --> Utf8 Class Initialized
INFO - 2018-01-18 21:02:57 --> URI Class Initialized
INFO - 2018-01-18 21:02:57 --> Router Class Initialized
INFO - 2018-01-18 21:02:57 --> Output Class Initialized
INFO - 2018-01-18 21:02:57 --> Security Class Initialized
DEBUG - 2018-01-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-18 21:02:57 --> Input Class Initialized
INFO - 2018-01-18 21:02:57 --> Language Class Initialized
ERROR - 2018-01-18 21:02:57 --> 404 Page Not Found: Instatec_pub/css
