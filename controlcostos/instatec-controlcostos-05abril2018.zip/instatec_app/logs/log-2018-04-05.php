<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-05 18:42:13 --> Config Class Initialized
INFO - 2018-04-05 18:42:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:42:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:42:14 --> Utf8 Class Initialized
INFO - 2018-04-05 18:42:14 --> URI Class Initialized
INFO - 2018-04-05 18:42:14 --> Router Class Initialized
INFO - 2018-04-05 18:42:14 --> Output Class Initialized
INFO - 2018-04-05 18:42:14 --> Security Class Initialized
DEBUG - 2018-04-05 18:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:42:14 --> Input Class Initialized
INFO - 2018-04-05 18:42:14 --> Language Class Initialized
INFO - 2018-04-05 18:42:14 --> Loader Class Initialized
INFO - 2018-04-05 18:42:14 --> Helper loaded: url_helper
INFO - 2018-04-05 18:42:14 --> Helper loaded: form_helper
INFO - 2018-04-05 18:42:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:42:14 --> Form Validation Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
INFO - 2018-04-05 18:42:14 --> Controller Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
INFO - 2018-04-05 18:42:14 --> Model Class Initialized
DEBUG - 2018-04-05 18:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:42:20 --> Config Class Initialized
INFO - 2018-04-05 18:42:20 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:42:20 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:42:20 --> Utf8 Class Initialized
INFO - 2018-04-05 18:42:20 --> URI Class Initialized
INFO - 2018-04-05 18:42:20 --> Router Class Initialized
INFO - 2018-04-05 18:42:20 --> Output Class Initialized
INFO - 2018-04-05 18:42:20 --> Security Class Initialized
DEBUG - 2018-04-05 18:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:42:20 --> Input Class Initialized
INFO - 2018-04-05 18:42:20 --> Language Class Initialized
INFO - 2018-04-05 18:42:20 --> Loader Class Initialized
INFO - 2018-04-05 18:42:20 --> Helper loaded: url_helper
INFO - 2018-04-05 18:42:20 --> Helper loaded: form_helper
INFO - 2018-04-05 18:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:42:20 --> Form Validation Class Initialized
INFO - 2018-04-05 18:42:20 --> Model Class Initialized
INFO - 2018-04-05 18:42:20 --> Controller Class Initialized
INFO - 2018-04-05 18:42:20 --> Model Class Initialized
DEBUG - 2018-04-05 18:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:42:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:42:20 --> Final output sent to browser
DEBUG - 2018-04-05 18:42:20 --> Total execution time: 0.0545
INFO - 2018-04-05 18:42:30 --> Config Class Initialized
INFO - 2018-04-05 18:42:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:42:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:42:30 --> Utf8 Class Initialized
INFO - 2018-04-05 18:42:30 --> URI Class Initialized
INFO - 2018-04-05 18:42:30 --> Router Class Initialized
INFO - 2018-04-05 18:42:30 --> Output Class Initialized
INFO - 2018-04-05 18:42:30 --> Security Class Initialized
DEBUG - 2018-04-05 18:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:42:30 --> Input Class Initialized
INFO - 2018-04-05 18:42:30 --> Language Class Initialized
INFO - 2018-04-05 18:42:30 --> Loader Class Initialized
INFO - 2018-04-05 18:42:30 --> Helper loaded: url_helper
INFO - 2018-04-05 18:42:30 --> Helper loaded: form_helper
INFO - 2018-04-05 18:42:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:42:30 --> Form Validation Class Initialized
INFO - 2018-04-05 18:42:30 --> Model Class Initialized
INFO - 2018-04-05 18:42:30 --> Controller Class Initialized
INFO - 2018-04-05 18:42:30 --> Model Class Initialized
DEBUG - 2018-04-05 18:42:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:42:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 18:42:31 --> Config Class Initialized
INFO - 2018-04-05 18:42:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:42:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:42:31 --> Utf8 Class Initialized
INFO - 2018-04-05 18:42:31 --> URI Class Initialized
DEBUG - 2018-04-05 18:42:31 --> No URI present. Default controller set.
INFO - 2018-04-05 18:42:31 --> Router Class Initialized
INFO - 2018-04-05 18:42:31 --> Output Class Initialized
INFO - 2018-04-05 18:42:31 --> Security Class Initialized
DEBUG - 2018-04-05 18:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:42:31 --> Input Class Initialized
INFO - 2018-04-05 18:42:31 --> Language Class Initialized
INFO - 2018-04-05 18:42:31 --> Loader Class Initialized
INFO - 2018-04-05 18:42:31 --> Helper loaded: url_helper
INFO - 2018-04-05 18:42:31 --> Helper loaded: form_helper
INFO - 2018-04-05 18:42:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:42:31 --> Form Validation Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Controller Class Initialized
INFO - 2018-04-05 18:42:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:42:31 --> Final output sent to browser
DEBUG - 2018-04-05 18:42:31 --> Total execution time: 0.0400
INFO - 2018-04-05 18:42:31 --> Config Class Initialized
INFO - 2018-04-05 18:42:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:42:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:42:31 --> Utf8 Class Initialized
INFO - 2018-04-05 18:42:31 --> URI Class Initialized
INFO - 2018-04-05 18:42:31 --> Router Class Initialized
INFO - 2018-04-05 18:42:31 --> Output Class Initialized
INFO - 2018-04-05 18:42:31 --> Security Class Initialized
DEBUG - 2018-04-05 18:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:42:31 --> Input Class Initialized
INFO - 2018-04-05 18:42:31 --> Language Class Initialized
INFO - 2018-04-05 18:42:31 --> Loader Class Initialized
INFO - 2018-04-05 18:42:31 --> Helper loaded: url_helper
INFO - 2018-04-05 18:42:31 --> Helper loaded: form_helper
INFO - 2018-04-05 18:42:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:42:31 --> Form Validation Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Controller Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
INFO - 2018-04-05 18:42:31 --> Model Class Initialized
DEBUG - 2018-04-05 18:42:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:27 --> Config Class Initialized
INFO - 2018-04-05 18:43:27 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:27 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:27 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:27 --> URI Class Initialized
INFO - 2018-04-05 18:43:27 --> Router Class Initialized
INFO - 2018-04-05 18:43:27 --> Output Class Initialized
INFO - 2018-04-05 18:43:27 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:27 --> Input Class Initialized
INFO - 2018-04-05 18:43:27 --> Language Class Initialized
INFO - 2018-04-05 18:43:27 --> Loader Class Initialized
INFO - 2018-04-05 18:43:27 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:27 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:27 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Controller Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:43:27 --> Final output sent to browser
DEBUG - 2018-04-05 18:43:27 --> Total execution time: 0.0513
INFO - 2018-04-05 18:43:27 --> Config Class Initialized
INFO - 2018-04-05 18:43:27 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:27 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:27 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:27 --> URI Class Initialized
INFO - 2018-04-05 18:43:27 --> Router Class Initialized
INFO - 2018-04-05 18:43:27 --> Output Class Initialized
INFO - 2018-04-05 18:43:27 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:27 --> Input Class Initialized
INFO - 2018-04-05 18:43:27 --> Language Class Initialized
INFO - 2018-04-05 18:43:27 --> Loader Class Initialized
INFO - 2018-04-05 18:43:27 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:27 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:27 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Controller Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
INFO - 2018-04-05 18:43:27 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:29 --> Config Class Initialized
INFO - 2018-04-05 18:43:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:29 --> URI Class Initialized
INFO - 2018-04-05 18:43:29 --> Router Class Initialized
INFO - 2018-04-05 18:43:29 --> Output Class Initialized
INFO - 2018-04-05 18:43:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:29 --> Input Class Initialized
INFO - 2018-04-05 18:43:29 --> Language Class Initialized
INFO - 2018-04-05 18:43:29 --> Loader Class Initialized
INFO - 2018-04-05 18:43:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Controller Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:43:29 --> Final output sent to browser
DEBUG - 2018-04-05 18:43:29 --> Total execution time: 0.0517
INFO - 2018-04-05 18:43:29 --> Config Class Initialized
INFO - 2018-04-05 18:43:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:29 --> URI Class Initialized
INFO - 2018-04-05 18:43:29 --> Router Class Initialized
INFO - 2018-04-05 18:43:29 --> Output Class Initialized
INFO - 2018-04-05 18:43:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:29 --> Input Class Initialized
INFO - 2018-04-05 18:43:29 --> Language Class Initialized
INFO - 2018-04-05 18:43:29 --> Loader Class Initialized
INFO - 2018-04-05 18:43:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Controller Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
INFO - 2018-04-05 18:43:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:54 --> Config Class Initialized
INFO - 2018-04-05 18:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:54 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:54 --> URI Class Initialized
INFO - 2018-04-05 18:43:54 --> Router Class Initialized
INFO - 2018-04-05 18:43:54 --> Output Class Initialized
INFO - 2018-04-05 18:43:54 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:54 --> Input Class Initialized
INFO - 2018-04-05 18:43:54 --> Language Class Initialized
INFO - 2018-04-05 18:43:54 --> Loader Class Initialized
INFO - 2018-04-05 18:43:54 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:54 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:54 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:54 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
INFO - 2018-04-05 18:43:54 --> Controller Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
INFO - 2018-04-05 18:43:54 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:43:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:43:55 --> Final output sent to browser
DEBUG - 2018-04-05 18:43:55 --> Total execution time: 0.0876
INFO - 2018-04-05 18:43:55 --> Config Class Initialized
INFO - 2018-04-05 18:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:43:55 --> Utf8 Class Initialized
INFO - 2018-04-05 18:43:55 --> URI Class Initialized
INFO - 2018-04-05 18:43:55 --> Router Class Initialized
INFO - 2018-04-05 18:43:55 --> Output Class Initialized
INFO - 2018-04-05 18:43:55 --> Security Class Initialized
DEBUG - 2018-04-05 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:43:55 --> Input Class Initialized
INFO - 2018-04-05 18:43:55 --> Language Class Initialized
INFO - 2018-04-05 18:43:55 --> Loader Class Initialized
INFO - 2018-04-05 18:43:55 --> Helper loaded: url_helper
INFO - 2018-04-05 18:43:55 --> Helper loaded: form_helper
INFO - 2018-04-05 18:43:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:43:55 --> Form Validation Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
INFO - 2018-04-05 18:43:55 --> Controller Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
INFO - 2018-04-05 18:43:55 --> Model Class Initialized
DEBUG - 2018-04-05 18:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:44:50 --> Config Class Initialized
INFO - 2018-04-05 18:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:44:50 --> Utf8 Class Initialized
INFO - 2018-04-05 18:44:50 --> URI Class Initialized
INFO - 2018-04-05 18:44:50 --> Router Class Initialized
INFO - 2018-04-05 18:44:50 --> Output Class Initialized
INFO - 2018-04-05 18:44:50 --> Security Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:44:50 --> Input Class Initialized
INFO - 2018-04-05 18:44:50 --> Language Class Initialized
INFO - 2018-04-05 18:44:50 --> Loader Class Initialized
INFO - 2018-04-05 18:44:50 --> Helper loaded: url_helper
INFO - 2018-04-05 18:44:50 --> Helper loaded: form_helper
INFO - 2018-04-05 18:44:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:44:50 --> Form Validation Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
INFO - 2018-04-05 18:44:50 --> Controller Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:44:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:44:50 --> Final output sent to browser
DEBUG - 2018-04-05 18:44:50 --> Total execution time: 0.0419
INFO - 2018-04-05 18:44:50 --> Config Class Initialized
INFO - 2018-04-05 18:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:44:50 --> Utf8 Class Initialized
INFO - 2018-04-05 18:44:50 --> URI Class Initialized
INFO - 2018-04-05 18:44:50 --> Router Class Initialized
INFO - 2018-04-05 18:44:50 --> Output Class Initialized
INFO - 2018-04-05 18:44:50 --> Security Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:44:50 --> Input Class Initialized
INFO - 2018-04-05 18:44:50 --> Language Class Initialized
INFO - 2018-04-05 18:44:50 --> Loader Class Initialized
INFO - 2018-04-05 18:44:50 --> Helper loaded: url_helper
INFO - 2018-04-05 18:44:50 --> Helper loaded: form_helper
INFO - 2018-04-05 18:44:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:44:50 --> Form Validation Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
INFO - 2018-04-05 18:44:50 --> Controller Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
INFO - 2018-04-05 18:44:50 --> Model Class Initialized
DEBUG - 2018-04-05 18:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:44:53 --> Config Class Initialized
INFO - 2018-04-05 18:44:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:44:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:44:53 --> Utf8 Class Initialized
INFO - 2018-04-05 18:44:53 --> URI Class Initialized
INFO - 2018-04-05 18:44:53 --> Router Class Initialized
INFO - 2018-04-05 18:44:53 --> Output Class Initialized
INFO - 2018-04-05 18:44:53 --> Security Class Initialized
DEBUG - 2018-04-05 18:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:44:53 --> Input Class Initialized
INFO - 2018-04-05 18:44:53 --> Language Class Initialized
INFO - 2018-04-05 18:44:53 --> Loader Class Initialized
INFO - 2018-04-05 18:44:53 --> Helper loaded: url_helper
INFO - 2018-04-05 18:44:53 --> Helper loaded: form_helper
INFO - 2018-04-05 18:44:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:44:53 --> Form Validation Class Initialized
INFO - 2018-04-05 18:44:53 --> Model Class Initialized
INFO - 2018-04-05 18:44:53 --> Controller Class Initialized
INFO - 2018-04-05 18:44:53 --> Model Class Initialized
INFO - 2018-04-05 18:44:53 --> Model Class Initialized
DEBUG - 2018-04-05 18:44:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:44:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:44:53 --> Final output sent to browser
DEBUG - 2018-04-05 18:44:53 --> Total execution time: 0.0821
INFO - 2018-04-05 18:44:59 --> Config Class Initialized
INFO - 2018-04-05 18:44:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:44:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:44:59 --> Utf8 Class Initialized
INFO - 2018-04-05 18:44:59 --> URI Class Initialized
INFO - 2018-04-05 18:44:59 --> Router Class Initialized
INFO - 2018-04-05 18:44:59 --> Output Class Initialized
INFO - 2018-04-05 18:44:59 --> Security Class Initialized
DEBUG - 2018-04-05 18:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:44:59 --> Input Class Initialized
INFO - 2018-04-05 18:44:59 --> Language Class Initialized
INFO - 2018-04-05 18:44:59 --> Loader Class Initialized
INFO - 2018-04-05 18:44:59 --> Helper loaded: url_helper
INFO - 2018-04-05 18:44:59 --> Helper loaded: form_helper
INFO - 2018-04-05 18:44:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:44:59 --> Form Validation Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
INFO - 2018-04-05 18:44:59 --> Controller Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
INFO - 2018-04-05 18:44:59 --> Model Class Initialized
DEBUG - 2018-04-05 18:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:44:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:44:59 --> Final output sent to browser
DEBUG - 2018-04-05 18:44:59 --> Total execution time: 0.0491
INFO - 2018-04-05 18:45:00 --> Config Class Initialized
INFO - 2018-04-05 18:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:00 --> URI Class Initialized
INFO - 2018-04-05 18:45:00 --> Router Class Initialized
INFO - 2018-04-05 18:45:00 --> Output Class Initialized
INFO - 2018-04-05 18:45:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:00 --> Input Class Initialized
INFO - 2018-04-05 18:45:00 --> Language Class Initialized
INFO - 2018-04-05 18:45:00 --> Loader Class Initialized
INFO - 2018-04-05 18:45:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
INFO - 2018-04-05 18:45:00 --> Controller Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
INFO - 2018-04-05 18:45:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:01 --> Config Class Initialized
INFO - 2018-04-05 18:45:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:01 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:01 --> URI Class Initialized
INFO - 2018-04-05 18:45:01 --> Router Class Initialized
INFO - 2018-04-05 18:45:01 --> Output Class Initialized
INFO - 2018-04-05 18:45:01 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:01 --> Input Class Initialized
INFO - 2018-04-05 18:45:01 --> Language Class Initialized
INFO - 2018-04-05 18:45:01 --> Loader Class Initialized
INFO - 2018-04-05 18:45:01 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:01 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:01 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Controller Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:01 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:01 --> Total execution time: 0.0536
INFO - 2018-04-05 18:45:01 --> Config Class Initialized
INFO - 2018-04-05 18:45:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:01 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:01 --> URI Class Initialized
INFO - 2018-04-05 18:45:01 --> Router Class Initialized
INFO - 2018-04-05 18:45:01 --> Output Class Initialized
INFO - 2018-04-05 18:45:01 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:01 --> Input Class Initialized
INFO - 2018-04-05 18:45:01 --> Language Class Initialized
INFO - 2018-04-05 18:45:01 --> Loader Class Initialized
INFO - 2018-04-05 18:45:01 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:01 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:01 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Controller Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
INFO - 2018-04-05 18:45:01 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:04 --> Config Class Initialized
INFO - 2018-04-05 18:45:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:04 --> URI Class Initialized
INFO - 2018-04-05 18:45:04 --> Router Class Initialized
INFO - 2018-04-05 18:45:04 --> Output Class Initialized
INFO - 2018-04-05 18:45:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:04 --> Input Class Initialized
INFO - 2018-04-05 18:45:04 --> Language Class Initialized
INFO - 2018-04-05 18:45:04 --> Loader Class Initialized
INFO - 2018-04-05 18:45:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Controller Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:04 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:04 --> Total execution time: 0.0983
INFO - 2018-04-05 18:45:04 --> Config Class Initialized
INFO - 2018-04-05 18:45:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:04 --> URI Class Initialized
INFO - 2018-04-05 18:45:04 --> Router Class Initialized
INFO - 2018-04-05 18:45:04 --> Output Class Initialized
INFO - 2018-04-05 18:45:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:04 --> Input Class Initialized
INFO - 2018-04-05 18:45:04 --> Language Class Initialized
INFO - 2018-04-05 18:45:04 --> Loader Class Initialized
INFO - 2018-04-05 18:45:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Controller Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
INFO - 2018-04-05 18:45:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:07 --> Config Class Initialized
INFO - 2018-04-05 18:45:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:07 --> URI Class Initialized
INFO - 2018-04-05 18:45:07 --> Router Class Initialized
INFO - 2018-04-05 18:45:07 --> Output Class Initialized
INFO - 2018-04-05 18:45:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:07 --> Input Class Initialized
INFO - 2018-04-05 18:45:07 --> Language Class Initialized
INFO - 2018-04-05 18:45:07 --> Loader Class Initialized
INFO - 2018-04-05 18:45:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Controller Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:07 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:07 --> Total execution time: 0.0913
INFO - 2018-04-05 18:45:07 --> Config Class Initialized
INFO - 2018-04-05 18:45:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:07 --> URI Class Initialized
INFO - 2018-04-05 18:45:07 --> Router Class Initialized
INFO - 2018-04-05 18:45:07 --> Output Class Initialized
INFO - 2018-04-05 18:45:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:07 --> Input Class Initialized
INFO - 2018-04-05 18:45:07 --> Language Class Initialized
INFO - 2018-04-05 18:45:07 --> Loader Class Initialized
INFO - 2018-04-05 18:45:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Controller Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
INFO - 2018-04-05 18:45:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:13 --> Config Class Initialized
INFO - 2018-04-05 18:45:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:13 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:13 --> URI Class Initialized
INFO - 2018-04-05 18:45:13 --> Router Class Initialized
INFO - 2018-04-05 18:45:13 --> Output Class Initialized
INFO - 2018-04-05 18:45:13 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:13 --> Input Class Initialized
INFO - 2018-04-05 18:45:13 --> Language Class Initialized
INFO - 2018-04-05 18:45:13 --> Loader Class Initialized
INFO - 2018-04-05 18:45:13 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:13 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:13 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
INFO - 2018-04-05 18:45:13 --> Controller Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
INFO - 2018-04-05 18:45:13 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:14 --> Config Class Initialized
INFO - 2018-04-05 18:45:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:14 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:14 --> URI Class Initialized
INFO - 2018-04-05 18:45:14 --> Router Class Initialized
INFO - 2018-04-05 18:45:14 --> Output Class Initialized
INFO - 2018-04-05 18:45:14 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:14 --> Input Class Initialized
INFO - 2018-04-05 18:45:14 --> Language Class Initialized
INFO - 2018-04-05 18:45:14 --> Loader Class Initialized
INFO - 2018-04-05 18:45:14 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:14 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:14 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
INFO - 2018-04-05 18:45:14 --> Controller Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
INFO - 2018-04-05 18:45:14 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:19 --> Config Class Initialized
INFO - 2018-04-05 18:45:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:19 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:19 --> URI Class Initialized
INFO - 2018-04-05 18:45:19 --> Router Class Initialized
INFO - 2018-04-05 18:45:19 --> Output Class Initialized
INFO - 2018-04-05 18:45:19 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:19 --> Input Class Initialized
INFO - 2018-04-05 18:45:19 --> Language Class Initialized
INFO - 2018-04-05 18:45:19 --> Loader Class Initialized
INFO - 2018-04-05 18:45:19 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:19 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:19 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Controller Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:19 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:19 --> Total execution time: 0.0541
INFO - 2018-04-05 18:45:19 --> Config Class Initialized
INFO - 2018-04-05 18:45:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:19 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:19 --> URI Class Initialized
INFO - 2018-04-05 18:45:19 --> Router Class Initialized
INFO - 2018-04-05 18:45:19 --> Output Class Initialized
INFO - 2018-04-05 18:45:19 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:19 --> Input Class Initialized
INFO - 2018-04-05 18:45:19 --> Language Class Initialized
INFO - 2018-04-05 18:45:19 --> Loader Class Initialized
INFO - 2018-04-05 18:45:19 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:19 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:19 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Controller Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
INFO - 2018-04-05 18:45:19 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:23 --> Config Class Initialized
INFO - 2018-04-05 18:45:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:23 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:23 --> URI Class Initialized
INFO - 2018-04-05 18:45:23 --> Router Class Initialized
INFO - 2018-04-05 18:45:23 --> Output Class Initialized
INFO - 2018-04-05 18:45:23 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:23 --> Input Class Initialized
INFO - 2018-04-05 18:45:23 --> Language Class Initialized
INFO - 2018-04-05 18:45:23 --> Loader Class Initialized
INFO - 2018-04-05 18:45:23 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:23 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:23 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Controller Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:23 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:23 --> Total execution time: 0.0540
INFO - 2018-04-05 18:45:23 --> Config Class Initialized
INFO - 2018-04-05 18:45:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:23 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:23 --> URI Class Initialized
INFO - 2018-04-05 18:45:23 --> Router Class Initialized
INFO - 2018-04-05 18:45:23 --> Output Class Initialized
INFO - 2018-04-05 18:45:23 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:23 --> Input Class Initialized
INFO - 2018-04-05 18:45:23 --> Language Class Initialized
INFO - 2018-04-05 18:45:23 --> Loader Class Initialized
INFO - 2018-04-05 18:45:23 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:23 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:23 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Controller Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
INFO - 2018-04-05 18:45:23 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:57 --> Config Class Initialized
INFO - 2018-04-05 18:45:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:57 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:57 --> URI Class Initialized
INFO - 2018-04-05 18:45:57 --> Router Class Initialized
INFO - 2018-04-05 18:45:57 --> Output Class Initialized
INFO - 2018-04-05 18:45:57 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:57 --> Input Class Initialized
INFO - 2018-04-05 18:45:57 --> Language Class Initialized
INFO - 2018-04-05 18:45:57 --> Loader Class Initialized
INFO - 2018-04-05 18:45:57 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:57 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:57 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
INFO - 2018-04-05 18:45:57 --> Controller Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
INFO - 2018-04-05 18:45:57 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:45:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:45:57 --> Final output sent to browser
DEBUG - 2018-04-05 18:45:57 --> Total execution time: 0.5099
INFO - 2018-04-05 18:45:58 --> Config Class Initialized
INFO - 2018-04-05 18:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:45:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:45:58 --> URI Class Initialized
INFO - 2018-04-05 18:45:58 --> Router Class Initialized
INFO - 2018-04-05 18:45:58 --> Output Class Initialized
INFO - 2018-04-05 18:45:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:45:58 --> Input Class Initialized
INFO - 2018-04-05 18:45:58 --> Language Class Initialized
INFO - 2018-04-05 18:45:58 --> Loader Class Initialized
INFO - 2018-04-05 18:45:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:45:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:45:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:45:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
INFO - 2018-04-05 18:45:58 --> Controller Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
INFO - 2018-04-05 18:45:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:06 --> Config Class Initialized
INFO - 2018-04-05 18:46:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:06 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:06 --> URI Class Initialized
INFO - 2018-04-05 18:46:06 --> Router Class Initialized
INFO - 2018-04-05 18:46:06 --> Output Class Initialized
INFO - 2018-04-05 18:46:06 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:06 --> Input Class Initialized
INFO - 2018-04-05 18:46:06 --> Language Class Initialized
INFO - 2018-04-05 18:46:06 --> Loader Class Initialized
INFO - 2018-04-05 18:46:06 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:06 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:06 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
INFO - 2018-04-05 18:46:06 --> Controller Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
INFO - 2018-04-05 18:46:06 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:09 --> Config Class Initialized
INFO - 2018-04-05 18:46:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:09 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:09 --> URI Class Initialized
INFO - 2018-04-05 18:46:09 --> Router Class Initialized
INFO - 2018-04-05 18:46:09 --> Output Class Initialized
INFO - 2018-04-05 18:46:09 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:09 --> Input Class Initialized
INFO - 2018-04-05 18:46:09 --> Language Class Initialized
INFO - 2018-04-05 18:46:09 --> Loader Class Initialized
INFO - 2018-04-05 18:46:09 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:09 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:09 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
INFO - 2018-04-05 18:46:09 --> Controller Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
INFO - 2018-04-05 18:46:09 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:09 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:09 --> Total execution time: 0.0650
INFO - 2018-04-05 18:46:10 --> Config Class Initialized
INFO - 2018-04-05 18:46:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:10 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:10 --> URI Class Initialized
INFO - 2018-04-05 18:46:10 --> Router Class Initialized
INFO - 2018-04-05 18:46:10 --> Output Class Initialized
INFO - 2018-04-05 18:46:10 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:10 --> Input Class Initialized
INFO - 2018-04-05 18:46:10 --> Language Class Initialized
INFO - 2018-04-05 18:46:10 --> Loader Class Initialized
INFO - 2018-04-05 18:46:10 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:10 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:10 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
INFO - 2018-04-05 18:46:10 --> Controller Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
INFO - 2018-04-05 18:46:10 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:11 --> Config Class Initialized
INFO - 2018-04-05 18:46:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:11 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:11 --> URI Class Initialized
INFO - 2018-04-05 18:46:11 --> Router Class Initialized
INFO - 2018-04-05 18:46:11 --> Output Class Initialized
INFO - 2018-04-05 18:46:11 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:11 --> Input Class Initialized
INFO - 2018-04-05 18:46:11 --> Language Class Initialized
INFO - 2018-04-05 18:46:11 --> Loader Class Initialized
INFO - 2018-04-05 18:46:11 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:11 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:11 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Controller Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:11 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:11 --> Total execution time: 0.0570
INFO - 2018-04-05 18:46:11 --> Config Class Initialized
INFO - 2018-04-05 18:46:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:11 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:11 --> URI Class Initialized
INFO - 2018-04-05 18:46:11 --> Router Class Initialized
INFO - 2018-04-05 18:46:11 --> Output Class Initialized
INFO - 2018-04-05 18:46:11 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:11 --> Input Class Initialized
INFO - 2018-04-05 18:46:11 --> Language Class Initialized
INFO - 2018-04-05 18:46:11 --> Loader Class Initialized
INFO - 2018-04-05 18:46:11 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:11 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:11 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Controller Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
INFO - 2018-04-05 18:46:11 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:29 --> Config Class Initialized
INFO - 2018-04-05 18:46:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:29 --> URI Class Initialized
INFO - 2018-04-05 18:46:29 --> Router Class Initialized
INFO - 2018-04-05 18:46:29 --> Output Class Initialized
INFO - 2018-04-05 18:46:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:29 --> Input Class Initialized
INFO - 2018-04-05 18:46:29 --> Language Class Initialized
INFO - 2018-04-05 18:46:29 --> Loader Class Initialized
INFO - 2018-04-05 18:46:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Controller Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:29 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:29 --> Total execution time: 0.0717
INFO - 2018-04-05 18:46:29 --> Config Class Initialized
INFO - 2018-04-05 18:46:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:29 --> URI Class Initialized
INFO - 2018-04-05 18:46:29 --> Router Class Initialized
INFO - 2018-04-05 18:46:29 --> Output Class Initialized
INFO - 2018-04-05 18:46:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:29 --> Input Class Initialized
INFO - 2018-04-05 18:46:29 --> Language Class Initialized
INFO - 2018-04-05 18:46:29 --> Loader Class Initialized
INFO - 2018-04-05 18:46:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Controller Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
INFO - 2018-04-05 18:46:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:35 --> Config Class Initialized
INFO - 2018-04-05 18:46:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:35 --> URI Class Initialized
INFO - 2018-04-05 18:46:35 --> Router Class Initialized
INFO - 2018-04-05 18:46:35 --> Output Class Initialized
INFO - 2018-04-05 18:46:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:35 --> Input Class Initialized
INFO - 2018-04-05 18:46:35 --> Language Class Initialized
INFO - 2018-04-05 18:46:35 --> Loader Class Initialized
INFO - 2018-04-05 18:46:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
INFO - 2018-04-05 18:46:35 --> Controller Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
INFO - 2018-04-05 18:46:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:47 --> Config Class Initialized
INFO - 2018-04-05 18:46:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:47 --> URI Class Initialized
INFO - 2018-04-05 18:46:47 --> Router Class Initialized
INFO - 2018-04-05 18:46:47 --> Output Class Initialized
INFO - 2018-04-05 18:46:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:47 --> Input Class Initialized
INFO - 2018-04-05 18:46:47 --> Language Class Initialized
INFO - 2018-04-05 18:46:47 --> Loader Class Initialized
INFO - 2018-04-05 18:46:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Controller Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:47 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:47 --> Total execution time: 0.3388
INFO - 2018-04-05 18:46:47 --> Config Class Initialized
INFO - 2018-04-05 18:46:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:47 --> URI Class Initialized
INFO - 2018-04-05 18:46:47 --> Router Class Initialized
INFO - 2018-04-05 18:46:47 --> Output Class Initialized
INFO - 2018-04-05 18:46:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:47 --> Input Class Initialized
INFO - 2018-04-05 18:46:47 --> Language Class Initialized
INFO - 2018-04-05 18:46:47 --> Loader Class Initialized
INFO - 2018-04-05 18:46:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Controller Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
INFO - 2018-04-05 18:46:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:52 --> Config Class Initialized
INFO - 2018-04-05 18:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:52 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:52 --> URI Class Initialized
INFO - 2018-04-05 18:46:52 --> Router Class Initialized
INFO - 2018-04-05 18:46:52 --> Output Class Initialized
INFO - 2018-04-05 18:46:52 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:52 --> Input Class Initialized
INFO - 2018-04-05 18:46:52 --> Language Class Initialized
INFO - 2018-04-05 18:46:52 --> Loader Class Initialized
INFO - 2018-04-05 18:46:52 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:52 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:52 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Controller Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:52 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:52 --> Total execution time: 0.0558
INFO - 2018-04-05 18:46:52 --> Config Class Initialized
INFO - 2018-04-05 18:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:52 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:52 --> URI Class Initialized
INFO - 2018-04-05 18:46:52 --> Router Class Initialized
INFO - 2018-04-05 18:46:52 --> Output Class Initialized
INFO - 2018-04-05 18:46:52 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:52 --> Input Class Initialized
INFO - 2018-04-05 18:46:52 --> Language Class Initialized
INFO - 2018-04-05 18:46:52 --> Loader Class Initialized
INFO - 2018-04-05 18:46:52 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:52 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:52 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Controller Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
INFO - 2018-04-05 18:46:52 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:53 --> Config Class Initialized
INFO - 2018-04-05 18:46:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:53 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:53 --> URI Class Initialized
INFO - 2018-04-05 18:46:53 --> Router Class Initialized
INFO - 2018-04-05 18:46:53 --> Output Class Initialized
INFO - 2018-04-05 18:46:53 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:53 --> Input Class Initialized
INFO - 2018-04-05 18:46:53 --> Language Class Initialized
INFO - 2018-04-05 18:46:53 --> Loader Class Initialized
INFO - 2018-04-05 18:46:53 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:53 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:53 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Controller Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:46:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:46:53 --> Final output sent to browser
DEBUG - 2018-04-05 18:46:53 --> Total execution time: 0.0572
INFO - 2018-04-05 18:46:53 --> Config Class Initialized
INFO - 2018-04-05 18:46:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:46:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:46:53 --> Utf8 Class Initialized
INFO - 2018-04-05 18:46:53 --> URI Class Initialized
INFO - 2018-04-05 18:46:53 --> Router Class Initialized
INFO - 2018-04-05 18:46:53 --> Output Class Initialized
INFO - 2018-04-05 18:46:53 --> Security Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:46:53 --> Input Class Initialized
INFO - 2018-04-05 18:46:53 --> Language Class Initialized
INFO - 2018-04-05 18:46:53 --> Loader Class Initialized
INFO - 2018-04-05 18:46:53 --> Helper loaded: url_helper
INFO - 2018-04-05 18:46:53 --> Helper loaded: form_helper
INFO - 2018-04-05 18:46:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:46:53 --> Form Validation Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Controller Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
INFO - 2018-04-05 18:46:53 --> Model Class Initialized
DEBUG - 2018-04-05 18:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:09 --> Config Class Initialized
INFO - 2018-04-05 18:47:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:09 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:09 --> URI Class Initialized
INFO - 2018-04-05 18:47:09 --> Router Class Initialized
INFO - 2018-04-05 18:47:09 --> Output Class Initialized
INFO - 2018-04-05 18:47:09 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:09 --> Input Class Initialized
INFO - 2018-04-05 18:47:09 --> Language Class Initialized
INFO - 2018-04-05 18:47:09 --> Loader Class Initialized
INFO - 2018-04-05 18:47:09 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:09 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:09 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Controller Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:47:09 --> Final output sent to browser
DEBUG - 2018-04-05 18:47:09 --> Total execution time: 0.0599
INFO - 2018-04-05 18:47:09 --> Config Class Initialized
INFO - 2018-04-05 18:47:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:09 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:09 --> URI Class Initialized
INFO - 2018-04-05 18:47:09 --> Router Class Initialized
INFO - 2018-04-05 18:47:09 --> Output Class Initialized
INFO - 2018-04-05 18:47:09 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:09 --> Input Class Initialized
INFO - 2018-04-05 18:47:09 --> Language Class Initialized
INFO - 2018-04-05 18:47:09 --> Loader Class Initialized
INFO - 2018-04-05 18:47:09 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:09 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:09 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Controller Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
INFO - 2018-04-05 18:47:09 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:32 --> Config Class Initialized
INFO - 2018-04-05 18:47:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:32 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:32 --> URI Class Initialized
INFO - 2018-04-05 18:47:32 --> Router Class Initialized
INFO - 2018-04-05 18:47:32 --> Output Class Initialized
INFO - 2018-04-05 18:47:32 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:32 --> Input Class Initialized
INFO - 2018-04-05 18:47:32 --> Language Class Initialized
INFO - 2018-04-05 18:47:32 --> Loader Class Initialized
INFO - 2018-04-05 18:47:32 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:32 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:33 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Controller Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:47:33 --> Final output sent to browser
DEBUG - 2018-04-05 18:47:33 --> Total execution time: 0.0636
INFO - 2018-04-05 18:47:33 --> Config Class Initialized
INFO - 2018-04-05 18:47:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:33 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:33 --> URI Class Initialized
INFO - 2018-04-05 18:47:33 --> Router Class Initialized
INFO - 2018-04-05 18:47:33 --> Output Class Initialized
INFO - 2018-04-05 18:47:33 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:33 --> Input Class Initialized
INFO - 2018-04-05 18:47:33 --> Language Class Initialized
INFO - 2018-04-05 18:47:33 --> Loader Class Initialized
INFO - 2018-04-05 18:47:33 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:33 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:33 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Controller Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
INFO - 2018-04-05 18:47:33 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:43 --> Config Class Initialized
INFO - 2018-04-05 18:47:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:43 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:43 --> URI Class Initialized
INFO - 2018-04-05 18:47:43 --> Router Class Initialized
INFO - 2018-04-05 18:47:43 --> Output Class Initialized
INFO - 2018-04-05 18:47:43 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:43 --> Input Class Initialized
INFO - 2018-04-05 18:47:43 --> Language Class Initialized
INFO - 2018-04-05 18:47:43 --> Loader Class Initialized
INFO - 2018-04-05 18:47:43 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:43 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:43 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
INFO - 2018-04-05 18:47:43 --> Controller Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
INFO - 2018-04-05 18:47:43 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:47:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:47:43 --> Final output sent to browser
DEBUG - 2018-04-05 18:47:43 --> Total execution time: 0.0694
INFO - 2018-04-05 18:47:44 --> Config Class Initialized
INFO - 2018-04-05 18:47:44 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:47:44 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:47:44 --> Utf8 Class Initialized
INFO - 2018-04-05 18:47:44 --> URI Class Initialized
INFO - 2018-04-05 18:47:44 --> Router Class Initialized
INFO - 2018-04-05 18:47:44 --> Output Class Initialized
INFO - 2018-04-05 18:47:44 --> Security Class Initialized
DEBUG - 2018-04-05 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:47:44 --> Input Class Initialized
INFO - 2018-04-05 18:47:44 --> Language Class Initialized
INFO - 2018-04-05 18:47:44 --> Loader Class Initialized
INFO - 2018-04-05 18:47:44 --> Helper loaded: url_helper
INFO - 2018-04-05 18:47:44 --> Helper loaded: form_helper
INFO - 2018-04-05 18:47:44 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:47:44 --> Form Validation Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
INFO - 2018-04-05 18:47:44 --> Controller Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
INFO - 2018-04-05 18:47:44 --> Model Class Initialized
DEBUG - 2018-04-05 18:47:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:00 --> Config Class Initialized
INFO - 2018-04-05 18:48:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:00 --> URI Class Initialized
INFO - 2018-04-05 18:48:00 --> Router Class Initialized
INFO - 2018-04-05 18:48:00 --> Output Class Initialized
INFO - 2018-04-05 18:48:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:00 --> Input Class Initialized
INFO - 2018-04-05 18:48:00 --> Language Class Initialized
INFO - 2018-04-05 18:48:00 --> Loader Class Initialized
INFO - 2018-04-05 18:48:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Controller Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:00 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:00 --> Total execution time: 0.0677
INFO - 2018-04-05 18:48:00 --> Config Class Initialized
INFO - 2018-04-05 18:48:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:00 --> URI Class Initialized
INFO - 2018-04-05 18:48:00 --> Router Class Initialized
INFO - 2018-04-05 18:48:00 --> Output Class Initialized
INFO - 2018-04-05 18:48:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:00 --> Input Class Initialized
INFO - 2018-04-05 18:48:00 --> Language Class Initialized
INFO - 2018-04-05 18:48:00 --> Loader Class Initialized
INFO - 2018-04-05 18:48:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Controller Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
INFO - 2018-04-05 18:48:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:02 --> Config Class Initialized
INFO - 2018-04-05 18:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:02 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:02 --> URI Class Initialized
INFO - 2018-04-05 18:48:02 --> Router Class Initialized
INFO - 2018-04-05 18:48:02 --> Output Class Initialized
INFO - 2018-04-05 18:48:02 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:02 --> Input Class Initialized
INFO - 2018-04-05 18:48:02 --> Language Class Initialized
INFO - 2018-04-05 18:48:02 --> Loader Class Initialized
INFO - 2018-04-05 18:48:02 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:02 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:02 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Controller Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:02 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:02 --> Total execution time: 0.0693
INFO - 2018-04-05 18:48:02 --> Config Class Initialized
INFO - 2018-04-05 18:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:02 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:02 --> URI Class Initialized
INFO - 2018-04-05 18:48:02 --> Router Class Initialized
INFO - 2018-04-05 18:48:02 --> Output Class Initialized
INFO - 2018-04-05 18:48:02 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:02 --> Input Class Initialized
INFO - 2018-04-05 18:48:02 --> Language Class Initialized
INFO - 2018-04-05 18:48:02 --> Loader Class Initialized
INFO - 2018-04-05 18:48:02 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:02 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:02 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Controller Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
INFO - 2018-04-05 18:48:02 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:04 --> Config Class Initialized
INFO - 2018-04-05 18:48:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:04 --> URI Class Initialized
INFO - 2018-04-05 18:48:04 --> Router Class Initialized
INFO - 2018-04-05 18:48:04 --> Output Class Initialized
INFO - 2018-04-05 18:48:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:04 --> Input Class Initialized
INFO - 2018-04-05 18:48:04 --> Language Class Initialized
INFO - 2018-04-05 18:48:04 --> Loader Class Initialized
INFO - 2018-04-05 18:48:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Controller Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:05 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:05 --> Total execution time: 0.0657
INFO - 2018-04-05 18:48:05 --> Config Class Initialized
INFO - 2018-04-05 18:48:05 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:05 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:05 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:05 --> URI Class Initialized
INFO - 2018-04-05 18:48:05 --> Router Class Initialized
INFO - 2018-04-05 18:48:05 --> Output Class Initialized
INFO - 2018-04-05 18:48:05 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:05 --> Input Class Initialized
INFO - 2018-04-05 18:48:05 --> Language Class Initialized
INFO - 2018-04-05 18:48:05 --> Loader Class Initialized
INFO - 2018-04-05 18:48:05 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:05 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:05 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:05 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Controller Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
INFO - 2018-04-05 18:48:05 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:06 --> Config Class Initialized
INFO - 2018-04-05 18:48:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:06 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:06 --> URI Class Initialized
INFO - 2018-04-05 18:48:06 --> Router Class Initialized
INFO - 2018-04-05 18:48:06 --> Output Class Initialized
INFO - 2018-04-05 18:48:06 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:06 --> Input Class Initialized
INFO - 2018-04-05 18:48:06 --> Language Class Initialized
INFO - 2018-04-05 18:48:06 --> Loader Class Initialized
INFO - 2018-04-05 18:48:06 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:06 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:06 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
INFO - 2018-04-05 18:48:06 --> Controller Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
INFO - 2018-04-05 18:48:06 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:06 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:06 --> Total execution time: 0.0938
INFO - 2018-04-05 18:48:22 --> Config Class Initialized
INFO - 2018-04-05 18:48:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:22 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:22 --> URI Class Initialized
INFO - 2018-04-05 18:48:22 --> Router Class Initialized
INFO - 2018-04-05 18:48:22 --> Output Class Initialized
INFO - 2018-04-05 18:48:22 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:22 --> Input Class Initialized
INFO - 2018-04-05 18:48:22 --> Language Class Initialized
INFO - 2018-04-05 18:48:22 --> Loader Class Initialized
INFO - 2018-04-05 18:48:22 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:22 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:22 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Controller Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:22 --> Config Class Initialized
INFO - 2018-04-05 18:48:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:22 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:22 --> URI Class Initialized
INFO - 2018-04-05 18:48:22 --> Router Class Initialized
INFO - 2018-04-05 18:48:22 --> Output Class Initialized
INFO - 2018-04-05 18:48:22 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:22 --> Input Class Initialized
INFO - 2018-04-05 18:48:22 --> Language Class Initialized
INFO - 2018-04-05 18:48:22 --> Loader Class Initialized
INFO - 2018-04-05 18:48:22 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:22 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:22 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Controller Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:22 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:22 --> Total execution time: 0.0695
INFO - 2018-04-05 18:48:22 --> Config Class Initialized
INFO - 2018-04-05 18:48:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:22 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:22 --> URI Class Initialized
INFO - 2018-04-05 18:48:22 --> Router Class Initialized
INFO - 2018-04-05 18:48:22 --> Output Class Initialized
INFO - 2018-04-05 18:48:22 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:22 --> Input Class Initialized
INFO - 2018-04-05 18:48:22 --> Language Class Initialized
INFO - 2018-04-05 18:48:22 --> Loader Class Initialized
INFO - 2018-04-05 18:48:22 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:22 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:22 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Controller Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
INFO - 2018-04-05 18:48:22 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:34 --> Config Class Initialized
INFO - 2018-04-05 18:48:34 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:34 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:34 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:34 --> URI Class Initialized
INFO - 2018-04-05 18:48:34 --> Router Class Initialized
INFO - 2018-04-05 18:48:34 --> Output Class Initialized
INFO - 2018-04-05 18:48:34 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:34 --> Input Class Initialized
INFO - 2018-04-05 18:48:34 --> Language Class Initialized
INFO - 2018-04-05 18:48:34 --> Loader Class Initialized
INFO - 2018-04-05 18:48:34 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:34 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:34 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:34 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
INFO - 2018-04-05 18:48:34 --> Controller Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
INFO - 2018-04-05 18:48:34 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:34 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:34 --> Total execution time: 0.1080
INFO - 2018-04-05 18:48:51 --> Config Class Initialized
INFO - 2018-04-05 18:48:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:51 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:51 --> URI Class Initialized
INFO - 2018-04-05 18:48:51 --> Router Class Initialized
INFO - 2018-04-05 18:48:51 --> Output Class Initialized
INFO - 2018-04-05 18:48:51 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:51 --> Input Class Initialized
INFO - 2018-04-05 18:48:51 --> Language Class Initialized
INFO - 2018-04-05 18:48:51 --> Loader Class Initialized
INFO - 2018-04-05 18:48:51 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:51 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:51 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Controller Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:51 --> Config Class Initialized
INFO - 2018-04-05 18:48:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:51 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:51 --> URI Class Initialized
INFO - 2018-04-05 18:48:51 --> Router Class Initialized
INFO - 2018-04-05 18:48:51 --> Output Class Initialized
INFO - 2018-04-05 18:48:51 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:51 --> Input Class Initialized
INFO - 2018-04-05 18:48:51 --> Language Class Initialized
INFO - 2018-04-05 18:48:51 --> Loader Class Initialized
INFO - 2018-04-05 18:48:51 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:51 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:51 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Controller Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
INFO - 2018-04-05 18:48:51 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:48:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:48:51 --> Final output sent to browser
DEBUG - 2018-04-05 18:48:51 --> Total execution time: 0.1238
INFO - 2018-04-05 18:48:52 --> Config Class Initialized
INFO - 2018-04-05 18:48:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:48:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:48:52 --> Utf8 Class Initialized
INFO - 2018-04-05 18:48:52 --> URI Class Initialized
INFO - 2018-04-05 18:48:52 --> Router Class Initialized
INFO - 2018-04-05 18:48:52 --> Output Class Initialized
INFO - 2018-04-05 18:48:52 --> Security Class Initialized
DEBUG - 2018-04-05 18:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:48:52 --> Input Class Initialized
INFO - 2018-04-05 18:48:52 --> Language Class Initialized
INFO - 2018-04-05 18:48:52 --> Loader Class Initialized
INFO - 2018-04-05 18:48:52 --> Helper loaded: url_helper
INFO - 2018-04-05 18:48:52 --> Helper loaded: form_helper
INFO - 2018-04-05 18:48:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:48:52 --> Form Validation Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
INFO - 2018-04-05 18:48:52 --> Controller Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
INFO - 2018-04-05 18:48:52 --> Model Class Initialized
DEBUG - 2018-04-05 18:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:00 --> Config Class Initialized
INFO - 2018-04-05 18:49:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:00 --> URI Class Initialized
INFO - 2018-04-05 18:49:00 --> Router Class Initialized
INFO - 2018-04-05 18:49:00 --> Output Class Initialized
INFO - 2018-04-05 18:49:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:00 --> Input Class Initialized
INFO - 2018-04-05 18:49:00 --> Language Class Initialized
INFO - 2018-04-05 18:49:00 --> Loader Class Initialized
INFO - 2018-04-05 18:49:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
INFO - 2018-04-05 18:49:00 --> Controller Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
INFO - 2018-04-05 18:49:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:00 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:00 --> Total execution time: 0.1839
INFO - 2018-04-05 18:49:03 --> Config Class Initialized
INFO - 2018-04-05 18:49:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:03 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:03 --> URI Class Initialized
INFO - 2018-04-05 18:49:03 --> Router Class Initialized
INFO - 2018-04-05 18:49:03 --> Output Class Initialized
INFO - 2018-04-05 18:49:03 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:03 --> Input Class Initialized
INFO - 2018-04-05 18:49:03 --> Language Class Initialized
INFO - 2018-04-05 18:49:03 --> Loader Class Initialized
INFO - 2018-04-05 18:49:03 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:03 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:03 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
INFO - 2018-04-05 18:49:03 --> Controller Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
INFO - 2018-04-05 18:49:03 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:03 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:03 --> Total execution time: 0.1089
INFO - 2018-04-05 18:49:04 --> Config Class Initialized
INFO - 2018-04-05 18:49:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:04 --> URI Class Initialized
INFO - 2018-04-05 18:49:04 --> Router Class Initialized
INFO - 2018-04-05 18:49:04 --> Output Class Initialized
INFO - 2018-04-05 18:49:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:04 --> Input Class Initialized
INFO - 2018-04-05 18:49:04 --> Language Class Initialized
INFO - 2018-04-05 18:49:04 --> Loader Class Initialized
INFO - 2018-04-05 18:49:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
INFO - 2018-04-05 18:49:04 --> Controller Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
INFO - 2018-04-05 18:49:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:08 --> Config Class Initialized
INFO - 2018-04-05 18:49:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:08 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:08 --> URI Class Initialized
INFO - 2018-04-05 18:49:08 --> Router Class Initialized
INFO - 2018-04-05 18:49:08 --> Output Class Initialized
INFO - 2018-04-05 18:49:08 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:08 --> Input Class Initialized
INFO - 2018-04-05 18:49:08 --> Language Class Initialized
INFO - 2018-04-05 18:49:08 --> Loader Class Initialized
INFO - 2018-04-05 18:49:08 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:08 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:08 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Controller Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:08 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:08 --> Total execution time: 0.1028
INFO - 2018-04-05 18:49:08 --> Config Class Initialized
INFO - 2018-04-05 18:49:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:08 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:08 --> URI Class Initialized
INFO - 2018-04-05 18:49:08 --> Router Class Initialized
INFO - 2018-04-05 18:49:08 --> Output Class Initialized
INFO - 2018-04-05 18:49:08 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:08 --> Input Class Initialized
INFO - 2018-04-05 18:49:08 --> Language Class Initialized
INFO - 2018-04-05 18:49:08 --> Loader Class Initialized
INFO - 2018-04-05 18:49:08 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:08 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:08 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Controller Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
INFO - 2018-04-05 18:49:08 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:14 --> Config Class Initialized
INFO - 2018-04-05 18:49:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:14 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:14 --> URI Class Initialized
INFO - 2018-04-05 18:49:14 --> Router Class Initialized
INFO - 2018-04-05 18:49:14 --> Output Class Initialized
INFO - 2018-04-05 18:49:14 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:14 --> Input Class Initialized
INFO - 2018-04-05 18:49:14 --> Language Class Initialized
INFO - 2018-04-05 18:49:14 --> Loader Class Initialized
INFO - 2018-04-05 18:49:14 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:14 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:14 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Controller Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:14 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:14 --> Total execution time: 0.1034
INFO - 2018-04-05 18:49:14 --> Config Class Initialized
INFO - 2018-04-05 18:49:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:14 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:14 --> URI Class Initialized
INFO - 2018-04-05 18:49:14 --> Router Class Initialized
INFO - 2018-04-05 18:49:14 --> Output Class Initialized
INFO - 2018-04-05 18:49:14 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:14 --> Input Class Initialized
INFO - 2018-04-05 18:49:14 --> Language Class Initialized
INFO - 2018-04-05 18:49:14 --> Loader Class Initialized
INFO - 2018-04-05 18:49:14 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:14 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:14 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Controller Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
INFO - 2018-04-05 18:49:14 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:17 --> Config Class Initialized
INFO - 2018-04-05 18:49:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:17 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:17 --> URI Class Initialized
INFO - 2018-04-05 18:49:17 --> Router Class Initialized
INFO - 2018-04-05 18:49:17 --> Output Class Initialized
INFO - 2018-04-05 18:49:17 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:17 --> Input Class Initialized
INFO - 2018-04-05 18:49:17 --> Language Class Initialized
INFO - 2018-04-05 18:49:17 --> Loader Class Initialized
INFO - 2018-04-05 18:49:17 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:17 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:17 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
INFO - 2018-04-05 18:49:17 --> Controller Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
INFO - 2018-04-05 18:49:17 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:17 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:17 --> Total execution time: 0.0989
INFO - 2018-04-05 18:49:18 --> Config Class Initialized
INFO - 2018-04-05 18:49:18 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:18 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:18 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:18 --> URI Class Initialized
INFO - 2018-04-05 18:49:18 --> Router Class Initialized
INFO - 2018-04-05 18:49:18 --> Output Class Initialized
INFO - 2018-04-05 18:49:18 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:18 --> Input Class Initialized
INFO - 2018-04-05 18:49:18 --> Language Class Initialized
INFO - 2018-04-05 18:49:18 --> Loader Class Initialized
INFO - 2018-04-05 18:49:18 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:18 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:18 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:18 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Controller Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:18 --> Config Class Initialized
INFO - 2018-04-05 18:49:18 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:18 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:18 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:18 --> URI Class Initialized
INFO - 2018-04-05 18:49:18 --> Router Class Initialized
INFO - 2018-04-05 18:49:18 --> Output Class Initialized
INFO - 2018-04-05 18:49:18 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:18 --> Input Class Initialized
INFO - 2018-04-05 18:49:18 --> Language Class Initialized
INFO - 2018-04-05 18:49:18 --> Loader Class Initialized
INFO - 2018-04-05 18:49:18 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:18 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:18 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:18 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Controller Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
INFO - 2018-04-05 18:49:18 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:18 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:18 --> Total execution time: 0.1371
INFO - 2018-04-05 18:49:19 --> Config Class Initialized
INFO - 2018-04-05 18:49:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:19 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:19 --> URI Class Initialized
INFO - 2018-04-05 18:49:19 --> Router Class Initialized
INFO - 2018-04-05 18:49:19 --> Output Class Initialized
INFO - 2018-04-05 18:49:19 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:19 --> Input Class Initialized
INFO - 2018-04-05 18:49:19 --> Language Class Initialized
INFO - 2018-04-05 18:49:19 --> Loader Class Initialized
INFO - 2018-04-05 18:49:19 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:19 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:19 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
INFO - 2018-04-05 18:49:19 --> Controller Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
INFO - 2018-04-05 18:49:19 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:28 --> Config Class Initialized
INFO - 2018-04-05 18:49:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:28 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:28 --> URI Class Initialized
INFO - 2018-04-05 18:49:28 --> Router Class Initialized
INFO - 2018-04-05 18:49:28 --> Output Class Initialized
INFO - 2018-04-05 18:49:28 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:28 --> Input Class Initialized
INFO - 2018-04-05 18:49:28 --> Language Class Initialized
INFO - 2018-04-05 18:49:28 --> Loader Class Initialized
INFO - 2018-04-05 18:49:28 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:28 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:28 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:28 --> Model Class Initialized
INFO - 2018-04-05 18:49:28 --> Controller Class Initialized
INFO - 2018-04-05 18:49:28 --> Model Class Initialized
INFO - 2018-04-05 18:49:28 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:28 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:28 --> Total execution time: 0.0930
INFO - 2018-04-05 18:49:29 --> Config Class Initialized
INFO - 2018-04-05 18:49:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:29 --> URI Class Initialized
INFO - 2018-04-05 18:49:29 --> Router Class Initialized
INFO - 2018-04-05 18:49:29 --> Output Class Initialized
INFO - 2018-04-05 18:49:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:29 --> Input Class Initialized
INFO - 2018-04-05 18:49:29 --> Language Class Initialized
INFO - 2018-04-05 18:49:29 --> Loader Class Initialized
INFO - 2018-04-05 18:49:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:29 --> Model Class Initialized
INFO - 2018-04-05 18:49:29 --> Controller Class Initialized
INFO - 2018-04-05 18:49:29 --> Model Class Initialized
INFO - 2018-04-05 18:49:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:32 --> Config Class Initialized
INFO - 2018-04-05 18:49:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:49:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:49:32 --> Utf8 Class Initialized
INFO - 2018-04-05 18:49:32 --> URI Class Initialized
INFO - 2018-04-05 18:49:32 --> Router Class Initialized
INFO - 2018-04-05 18:49:32 --> Output Class Initialized
INFO - 2018-04-05 18:49:32 --> Security Class Initialized
DEBUG - 2018-04-05 18:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:49:32 --> Input Class Initialized
INFO - 2018-04-05 18:49:32 --> Language Class Initialized
INFO - 2018-04-05 18:49:32 --> Loader Class Initialized
INFO - 2018-04-05 18:49:32 --> Helper loaded: url_helper
INFO - 2018-04-05 18:49:32 --> Helper loaded: form_helper
INFO - 2018-04-05 18:49:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:49:32 --> Form Validation Class Initialized
INFO - 2018-04-05 18:49:32 --> Model Class Initialized
INFO - 2018-04-05 18:49:32 --> Controller Class Initialized
INFO - 2018-04-05 18:49:32 --> Model Class Initialized
INFO - 2018-04-05 18:49:32 --> Model Class Initialized
DEBUG - 2018-04-05 18:49:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:49:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:49:32 --> Final output sent to browser
DEBUG - 2018-04-05 18:49:32 --> Total execution time: 0.1043
INFO - 2018-04-05 18:51:17 --> Config Class Initialized
INFO - 2018-04-05 18:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:17 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:17 --> URI Class Initialized
INFO - 2018-04-05 18:51:17 --> Router Class Initialized
INFO - 2018-04-05 18:51:17 --> Output Class Initialized
INFO - 2018-04-05 18:51:17 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:17 --> Input Class Initialized
INFO - 2018-04-05 18:51:17 --> Language Class Initialized
INFO - 2018-04-05 18:51:17 --> Loader Class Initialized
INFO - 2018-04-05 18:51:17 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:17 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:17 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Controller Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:17 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:17 --> Total execution time: 0.1294
INFO - 2018-04-05 18:51:17 --> Config Class Initialized
INFO - 2018-04-05 18:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:17 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:17 --> URI Class Initialized
INFO - 2018-04-05 18:51:17 --> Router Class Initialized
INFO - 2018-04-05 18:51:17 --> Output Class Initialized
INFO - 2018-04-05 18:51:17 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:17 --> Input Class Initialized
INFO - 2018-04-05 18:51:17 --> Language Class Initialized
INFO - 2018-04-05 18:51:17 --> Loader Class Initialized
INFO - 2018-04-05 18:51:17 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:17 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:17 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Controller Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
INFO - 2018-04-05 18:51:17 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:23 --> Config Class Initialized
INFO - 2018-04-05 18:51:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:23 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:23 --> URI Class Initialized
INFO - 2018-04-05 18:51:23 --> Router Class Initialized
INFO - 2018-04-05 18:51:23 --> Output Class Initialized
INFO - 2018-04-05 18:51:23 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:23 --> Input Class Initialized
INFO - 2018-04-05 18:51:23 --> Language Class Initialized
INFO - 2018-04-05 18:51:23 --> Loader Class Initialized
INFO - 2018-04-05 18:51:23 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:23 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:23 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:23 --> Model Class Initialized
INFO - 2018-04-05 18:51:23 --> Controller Class Initialized
INFO - 2018-04-05 18:51:23 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:23 --> Config Class Initialized
INFO - 2018-04-05 18:51:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:23 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:23 --> URI Class Initialized
INFO - 2018-04-05 18:51:23 --> Router Class Initialized
INFO - 2018-04-05 18:51:23 --> Output Class Initialized
INFO - 2018-04-05 18:51:23 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:23 --> Input Class Initialized
INFO - 2018-04-05 18:51:23 --> Language Class Initialized
INFO - 2018-04-05 18:51:23 --> Loader Class Initialized
INFO - 2018-04-05 18:51:23 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:23 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:23 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:23 --> Model Class Initialized
INFO - 2018-04-05 18:51:23 --> Controller Class Initialized
INFO - 2018-04-05 18:51:23 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:23 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:23 --> Total execution time: 0.0755
INFO - 2018-04-05 18:51:28 --> Config Class Initialized
INFO - 2018-04-05 18:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:28 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:28 --> URI Class Initialized
INFO - 2018-04-05 18:51:28 --> Router Class Initialized
INFO - 2018-04-05 18:51:28 --> Output Class Initialized
INFO - 2018-04-05 18:51:28 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:28 --> Input Class Initialized
INFO - 2018-04-05 18:51:28 --> Language Class Initialized
INFO - 2018-04-05 18:51:28 --> Loader Class Initialized
INFO - 2018-04-05 18:51:28 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:28 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:28 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Controller Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 18:51:28 --> Config Class Initialized
INFO - 2018-04-05 18:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:28 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:28 --> URI Class Initialized
DEBUG - 2018-04-05 18:51:28 --> No URI present. Default controller set.
INFO - 2018-04-05 18:51:28 --> Router Class Initialized
INFO - 2018-04-05 18:51:28 --> Output Class Initialized
INFO - 2018-04-05 18:51:28 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:28 --> Input Class Initialized
INFO - 2018-04-05 18:51:28 --> Language Class Initialized
INFO - 2018-04-05 18:51:28 --> Loader Class Initialized
INFO - 2018-04-05 18:51:28 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:28 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:28 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Controller Class Initialized
INFO - 2018-04-05 18:51:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:28 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:28 --> Total execution time: 0.0854
INFO - 2018-04-05 18:51:28 --> Config Class Initialized
INFO - 2018-04-05 18:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:28 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:28 --> URI Class Initialized
INFO - 2018-04-05 18:51:28 --> Router Class Initialized
INFO - 2018-04-05 18:51:28 --> Output Class Initialized
INFO - 2018-04-05 18:51:28 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:28 --> Input Class Initialized
INFO - 2018-04-05 18:51:28 --> Language Class Initialized
INFO - 2018-04-05 18:51:28 --> Loader Class Initialized
INFO - 2018-04-05 18:51:28 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:28 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:28 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Controller Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
INFO - 2018-04-05 18:51:28 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:35 --> Config Class Initialized
INFO - 2018-04-05 18:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:35 --> URI Class Initialized
INFO - 2018-04-05 18:51:35 --> Router Class Initialized
INFO - 2018-04-05 18:51:35 --> Output Class Initialized
INFO - 2018-04-05 18:51:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:35 --> Input Class Initialized
INFO - 2018-04-05 18:51:35 --> Language Class Initialized
INFO - 2018-04-05 18:51:35 --> Loader Class Initialized
INFO - 2018-04-05 18:51:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Controller Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:35 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:35 --> Total execution time: 0.0525
INFO - 2018-04-05 18:51:35 --> Config Class Initialized
INFO - 2018-04-05 18:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:35 --> URI Class Initialized
INFO - 2018-04-05 18:51:35 --> Router Class Initialized
INFO - 2018-04-05 18:51:35 --> Output Class Initialized
INFO - 2018-04-05 18:51:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:35 --> Input Class Initialized
INFO - 2018-04-05 18:51:35 --> Language Class Initialized
INFO - 2018-04-05 18:51:35 --> Loader Class Initialized
INFO - 2018-04-05 18:51:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Controller Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
INFO - 2018-04-05 18:51:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:41 --> Config Class Initialized
INFO - 2018-04-05 18:51:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:41 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:41 --> URI Class Initialized
INFO - 2018-04-05 18:51:41 --> Router Class Initialized
INFO - 2018-04-05 18:51:41 --> Output Class Initialized
INFO - 2018-04-05 18:51:41 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:41 --> Input Class Initialized
INFO - 2018-04-05 18:51:41 --> Language Class Initialized
INFO - 2018-04-05 18:51:41 --> Loader Class Initialized
INFO - 2018-04-05 18:51:41 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:41 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:41 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Controller Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:41 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:41 --> Total execution time: 0.1151
INFO - 2018-04-05 18:51:41 --> Config Class Initialized
INFO - 2018-04-05 18:51:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:41 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:41 --> URI Class Initialized
INFO - 2018-04-05 18:51:41 --> Router Class Initialized
INFO - 2018-04-05 18:51:41 --> Output Class Initialized
INFO - 2018-04-05 18:51:41 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:41 --> Input Class Initialized
INFO - 2018-04-05 18:51:41 --> Language Class Initialized
INFO - 2018-04-05 18:51:41 --> Loader Class Initialized
INFO - 2018-04-05 18:51:41 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:41 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:41 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Controller Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
INFO - 2018-04-05 18:51:41 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:56 --> Config Class Initialized
INFO - 2018-04-05 18:51:56 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:56 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:56 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:56 --> URI Class Initialized
INFO - 2018-04-05 18:51:56 --> Router Class Initialized
INFO - 2018-04-05 18:51:56 --> Output Class Initialized
INFO - 2018-04-05 18:51:56 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:56 --> Input Class Initialized
INFO - 2018-04-05 18:51:56 --> Language Class Initialized
INFO - 2018-04-05 18:51:56 --> Loader Class Initialized
INFO - 2018-04-05 18:51:56 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:56 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:56 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:56 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Controller Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:51:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:51:56 --> Final output sent to browser
DEBUG - 2018-04-05 18:51:56 --> Total execution time: 0.1472
INFO - 2018-04-05 18:51:56 --> Config Class Initialized
INFO - 2018-04-05 18:51:56 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:51:56 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:51:56 --> Utf8 Class Initialized
INFO - 2018-04-05 18:51:56 --> URI Class Initialized
INFO - 2018-04-05 18:51:56 --> Router Class Initialized
INFO - 2018-04-05 18:51:56 --> Output Class Initialized
INFO - 2018-04-05 18:51:56 --> Security Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:51:56 --> Input Class Initialized
INFO - 2018-04-05 18:51:56 --> Language Class Initialized
INFO - 2018-04-05 18:51:56 --> Loader Class Initialized
INFO - 2018-04-05 18:51:56 --> Helper loaded: url_helper
INFO - 2018-04-05 18:51:56 --> Helper loaded: form_helper
INFO - 2018-04-05 18:51:56 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:51:56 --> Form Validation Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Controller Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
INFO - 2018-04-05 18:51:56 --> Model Class Initialized
DEBUG - 2018-04-05 18:51:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:01 --> Config Class Initialized
INFO - 2018-04-05 18:52:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:01 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:01 --> URI Class Initialized
INFO - 2018-04-05 18:52:01 --> Router Class Initialized
INFO - 2018-04-05 18:52:01 --> Output Class Initialized
INFO - 2018-04-05 18:52:01 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:01 --> Input Class Initialized
INFO - 2018-04-05 18:52:01 --> Language Class Initialized
INFO - 2018-04-05 18:52:01 --> Loader Class Initialized
INFO - 2018-04-05 18:52:01 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:01 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:01 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
INFO - 2018-04-05 18:52:01 --> Controller Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:01 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:01 --> Total execution time: 0.1165
INFO - 2018-04-05 18:52:01 --> Config Class Initialized
INFO - 2018-04-05 18:52:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:01 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:01 --> URI Class Initialized
INFO - 2018-04-05 18:52:01 --> Router Class Initialized
INFO - 2018-04-05 18:52:01 --> Output Class Initialized
INFO - 2018-04-05 18:52:01 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:01 --> Input Class Initialized
INFO - 2018-04-05 18:52:01 --> Language Class Initialized
INFO - 2018-04-05 18:52:01 --> Loader Class Initialized
INFO - 2018-04-05 18:52:01 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:01 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:01 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
INFO - 2018-04-05 18:52:01 --> Controller Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
INFO - 2018-04-05 18:52:01 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:04 --> Config Class Initialized
INFO - 2018-04-05 18:52:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:04 --> URI Class Initialized
INFO - 2018-04-05 18:52:04 --> Router Class Initialized
INFO - 2018-04-05 18:52:04 --> Output Class Initialized
INFO - 2018-04-05 18:52:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:04 --> Input Class Initialized
INFO - 2018-04-05 18:52:04 --> Language Class Initialized
INFO - 2018-04-05 18:52:04 --> Loader Class Initialized
INFO - 2018-04-05 18:52:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:04 --> Model Class Initialized
INFO - 2018-04-05 18:52:04 --> Controller Class Initialized
INFO - 2018-04-05 18:52:04 --> Model Class Initialized
INFO - 2018-04-05 18:52:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:04 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:04 --> Total execution time: 0.1117
INFO - 2018-04-05 18:52:22 --> Config Class Initialized
INFO - 2018-04-05 18:52:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:22 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:22 --> URI Class Initialized
INFO - 2018-04-05 18:52:22 --> Router Class Initialized
INFO - 2018-04-05 18:52:22 --> Output Class Initialized
INFO - 2018-04-05 18:52:22 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:22 --> Input Class Initialized
INFO - 2018-04-05 18:52:22 --> Language Class Initialized
INFO - 2018-04-05 18:52:22 --> Loader Class Initialized
INFO - 2018-04-05 18:52:22 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:22 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:22 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Controller Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:22 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:22 --> Total execution time: 0.0838
INFO - 2018-04-05 18:52:22 --> Config Class Initialized
INFO - 2018-04-05 18:52:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:22 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:22 --> URI Class Initialized
INFO - 2018-04-05 18:52:22 --> Router Class Initialized
INFO - 2018-04-05 18:52:22 --> Output Class Initialized
INFO - 2018-04-05 18:52:22 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:22 --> Input Class Initialized
INFO - 2018-04-05 18:52:22 --> Language Class Initialized
INFO - 2018-04-05 18:52:22 --> Loader Class Initialized
INFO - 2018-04-05 18:52:22 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:22 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:22 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Controller Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
INFO - 2018-04-05 18:52:22 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:24 --> Config Class Initialized
INFO - 2018-04-05 18:52:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:24 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:24 --> URI Class Initialized
INFO - 2018-04-05 18:52:24 --> Router Class Initialized
INFO - 2018-04-05 18:52:24 --> Output Class Initialized
INFO - 2018-04-05 18:52:24 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:24 --> Input Class Initialized
INFO - 2018-04-05 18:52:24 --> Language Class Initialized
INFO - 2018-04-05 18:52:24 --> Loader Class Initialized
INFO - 2018-04-05 18:52:24 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:24 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:24 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Controller Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:24 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:24 --> Total execution time: 0.1048
INFO - 2018-04-05 18:52:24 --> Config Class Initialized
INFO - 2018-04-05 18:52:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:24 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:24 --> URI Class Initialized
INFO - 2018-04-05 18:52:24 --> Router Class Initialized
INFO - 2018-04-05 18:52:24 --> Output Class Initialized
INFO - 2018-04-05 18:52:24 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:24 --> Input Class Initialized
INFO - 2018-04-05 18:52:24 --> Language Class Initialized
INFO - 2018-04-05 18:52:24 --> Loader Class Initialized
INFO - 2018-04-05 18:52:24 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:24 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:24 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Controller Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
INFO - 2018-04-05 18:52:24 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:47 --> Config Class Initialized
INFO - 2018-04-05 18:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:47 --> URI Class Initialized
INFO - 2018-04-05 18:52:47 --> Router Class Initialized
INFO - 2018-04-05 18:52:47 --> Output Class Initialized
INFO - 2018-04-05 18:52:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:47 --> Input Class Initialized
INFO - 2018-04-05 18:52:47 --> Language Class Initialized
INFO - 2018-04-05 18:52:47 --> Loader Class Initialized
INFO - 2018-04-05 18:52:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
INFO - 2018-04-05 18:52:47 --> Controller Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
INFO - 2018-04-05 18:52:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:47 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:47 --> Total execution time: 0.0977
INFO - 2018-04-05 18:52:47 --> Config Class Initialized
INFO - 2018-04-05 18:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:47 --> URI Class Initialized
INFO - 2018-04-05 18:52:47 --> Router Class Initialized
INFO - 2018-04-05 18:52:47 --> Output Class Initialized
INFO - 2018-04-05 18:52:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:47 --> Input Class Initialized
INFO - 2018-04-05 18:52:47 --> Language Class Initialized
INFO - 2018-04-05 18:52:47 --> Loader Class Initialized
INFO - 2018-04-05 18:52:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:48 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
INFO - 2018-04-05 18:52:48 --> Controller Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
INFO - 2018-04-05 18:52:48 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:50 --> Config Class Initialized
INFO - 2018-04-05 18:52:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:50 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:50 --> URI Class Initialized
INFO - 2018-04-05 18:52:50 --> Router Class Initialized
INFO - 2018-04-05 18:52:50 --> Output Class Initialized
INFO - 2018-04-05 18:52:50 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:50 --> Input Class Initialized
INFO - 2018-04-05 18:52:50 --> Language Class Initialized
INFO - 2018-04-05 18:52:50 --> Loader Class Initialized
INFO - 2018-04-05 18:52:50 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:50 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:50 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
INFO - 2018-04-05 18:52:50 --> Controller Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
INFO - 2018-04-05 18:52:50 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:50 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:50 --> Total execution time: 0.1170
INFO - 2018-04-05 18:52:50 --> Config Class Initialized
INFO - 2018-04-05 18:52:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:50 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:50 --> URI Class Initialized
INFO - 2018-04-05 18:52:50 --> Router Class Initialized
INFO - 2018-04-05 18:52:50 --> Output Class Initialized
INFO - 2018-04-05 18:52:50 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:50 --> Input Class Initialized
INFO - 2018-04-05 18:52:51 --> Language Class Initialized
INFO - 2018-04-05 18:52:51 --> Loader Class Initialized
INFO - 2018-04-05 18:52:51 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:51 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:51 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
INFO - 2018-04-05 18:52:51 --> Controller Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
INFO - 2018-04-05 18:52:51 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:57 --> Config Class Initialized
INFO - 2018-04-05 18:52:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:52:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:52:57 --> Utf8 Class Initialized
INFO - 2018-04-05 18:52:57 --> URI Class Initialized
INFO - 2018-04-05 18:52:57 --> Router Class Initialized
INFO - 2018-04-05 18:52:57 --> Output Class Initialized
INFO - 2018-04-05 18:52:57 --> Security Class Initialized
DEBUG - 2018-04-05 18:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:52:57 --> Input Class Initialized
INFO - 2018-04-05 18:52:57 --> Language Class Initialized
INFO - 2018-04-05 18:52:57 --> Loader Class Initialized
INFO - 2018-04-05 18:52:57 --> Helper loaded: url_helper
INFO - 2018-04-05 18:52:57 --> Helper loaded: form_helper
INFO - 2018-04-05 18:52:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:52:57 --> Form Validation Class Initialized
INFO - 2018-04-05 18:52:57 --> Model Class Initialized
INFO - 2018-04-05 18:52:57 --> Controller Class Initialized
INFO - 2018-04-05 18:52:57 --> Model Class Initialized
INFO - 2018-04-05 18:52:57 --> Model Class Initialized
INFO - 2018-04-05 18:52:57 --> Model Class Initialized
INFO - 2018-04-05 18:52:57 --> Model Class Initialized
DEBUG - 2018-04-05 18:52:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:52:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:52:57 --> Final output sent to browser
DEBUG - 2018-04-05 18:52:57 --> Total execution time: 0.1090
INFO - 2018-04-05 18:53:07 --> Config Class Initialized
INFO - 2018-04-05 18:53:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:07 --> URI Class Initialized
INFO - 2018-04-05 18:53:07 --> Router Class Initialized
INFO - 2018-04-05 18:53:07 --> Output Class Initialized
INFO - 2018-04-05 18:53:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:07 --> Input Class Initialized
INFO - 2018-04-05 18:53:07 --> Language Class Initialized
INFO - 2018-04-05 18:53:07 --> Loader Class Initialized
INFO - 2018-04-05 18:53:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
INFO - 2018-04-05 18:53:07 --> Controller Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:07 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:07 --> Total execution time: 0.0929
INFO - 2018-04-05 18:53:07 --> Config Class Initialized
INFO - 2018-04-05 18:53:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:07 --> URI Class Initialized
INFO - 2018-04-05 18:53:07 --> Router Class Initialized
INFO - 2018-04-05 18:53:07 --> Output Class Initialized
INFO - 2018-04-05 18:53:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:07 --> Input Class Initialized
INFO - 2018-04-05 18:53:07 --> Language Class Initialized
INFO - 2018-04-05 18:53:07 --> Loader Class Initialized
INFO - 2018-04-05 18:53:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
INFO - 2018-04-05 18:53:07 --> Controller Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
INFO - 2018-04-05 18:53:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:12 --> Config Class Initialized
INFO - 2018-04-05 18:53:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:12 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:12 --> URI Class Initialized
INFO - 2018-04-05 18:53:12 --> Router Class Initialized
INFO - 2018-04-05 18:53:12 --> Output Class Initialized
INFO - 2018-04-05 18:53:12 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:12 --> Input Class Initialized
INFO - 2018-04-05 18:53:12 --> Language Class Initialized
INFO - 2018-04-05 18:53:12 --> Loader Class Initialized
INFO - 2018-04-05 18:53:12 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:12 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:12 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:12 --> Model Class Initialized
INFO - 2018-04-05 18:53:12 --> Controller Class Initialized
INFO - 2018-04-05 18:53:12 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:12 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:12 --> Total execution time: 0.0945
INFO - 2018-04-05 18:53:12 --> Config Class Initialized
INFO - 2018-04-05 18:53:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:12 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:12 --> URI Class Initialized
INFO - 2018-04-05 18:53:12 --> Router Class Initialized
INFO - 2018-04-05 18:53:12 --> Output Class Initialized
INFO - 2018-04-05 18:53:12 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:12 --> Input Class Initialized
INFO - 2018-04-05 18:53:12 --> Language Class Initialized
INFO - 2018-04-05 18:53:12 --> Loader Class Initialized
INFO - 2018-04-05 18:53:12 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:12 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:12 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:12 --> Model Class Initialized
INFO - 2018-04-05 18:53:12 --> Controller Class Initialized
INFO - 2018-04-05 18:53:12 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:13 --> Config Class Initialized
INFO - 2018-04-05 18:53:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:13 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:13 --> URI Class Initialized
INFO - 2018-04-05 18:53:13 --> Router Class Initialized
INFO - 2018-04-05 18:53:13 --> Output Class Initialized
INFO - 2018-04-05 18:53:13 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:13 --> Input Class Initialized
INFO - 2018-04-05 18:53:13 --> Language Class Initialized
INFO - 2018-04-05 18:53:13 --> Loader Class Initialized
INFO - 2018-04-05 18:53:13 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:13 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:13 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:13 --> Model Class Initialized
INFO - 2018-04-05 18:53:13 --> Controller Class Initialized
INFO - 2018-04-05 18:53:13 --> Model Class Initialized
INFO - 2018-04-05 18:53:13 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:13 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:13 --> Total execution time: 0.0710
INFO - 2018-04-05 18:53:13 --> Config Class Initialized
INFO - 2018-04-05 18:53:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:13 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:13 --> URI Class Initialized
INFO - 2018-04-05 18:53:13 --> Router Class Initialized
INFO - 2018-04-05 18:53:13 --> Output Class Initialized
INFO - 2018-04-05 18:53:13 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:13 --> Input Class Initialized
INFO - 2018-04-05 18:53:13 --> Language Class Initialized
INFO - 2018-04-05 18:53:13 --> Loader Class Initialized
INFO - 2018-04-05 18:53:13 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:14 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:14 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:14 --> Model Class Initialized
INFO - 2018-04-05 18:53:14 --> Controller Class Initialized
INFO - 2018-04-05 18:53:14 --> Model Class Initialized
INFO - 2018-04-05 18:53:14 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:16 --> Config Class Initialized
INFO - 2018-04-05 18:53:16 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:16 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:16 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:16 --> URI Class Initialized
INFO - 2018-04-05 18:53:16 --> Router Class Initialized
INFO - 2018-04-05 18:53:16 --> Output Class Initialized
INFO - 2018-04-05 18:53:16 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:16 --> Input Class Initialized
INFO - 2018-04-05 18:53:16 --> Language Class Initialized
INFO - 2018-04-05 18:53:16 --> Loader Class Initialized
INFO - 2018-04-05 18:53:16 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:16 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:16 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:16 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:16 --> Model Class Initialized
INFO - 2018-04-05 18:53:16 --> Controller Class Initialized
INFO - 2018-04-05 18:53:16 --> Model Class Initialized
INFO - 2018-04-05 18:53:16 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:16 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:16 --> Total execution time: 0.0776
INFO - 2018-04-05 18:53:35 --> Config Class Initialized
INFO - 2018-04-05 18:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:35 --> URI Class Initialized
INFO - 2018-04-05 18:53:35 --> Router Class Initialized
INFO - 2018-04-05 18:53:35 --> Output Class Initialized
INFO - 2018-04-05 18:53:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:35 --> Input Class Initialized
INFO - 2018-04-05 18:53:35 --> Language Class Initialized
INFO - 2018-04-05 18:53:35 --> Loader Class Initialized
INFO - 2018-04-05 18:53:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:35 --> Model Class Initialized
INFO - 2018-04-05 18:53:35 --> Controller Class Initialized
INFO - 2018-04-05 18:53:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:35 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:35 --> Total execution time: 0.0708
INFO - 2018-04-05 18:53:36 --> Config Class Initialized
INFO - 2018-04-05 18:53:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:36 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:36 --> URI Class Initialized
INFO - 2018-04-05 18:53:36 --> Router Class Initialized
INFO - 2018-04-05 18:53:36 --> Output Class Initialized
INFO - 2018-04-05 18:53:36 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:36 --> Input Class Initialized
INFO - 2018-04-05 18:53:36 --> Language Class Initialized
INFO - 2018-04-05 18:53:36 --> Loader Class Initialized
INFO - 2018-04-05 18:53:36 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:36 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:36 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:36 --> Model Class Initialized
INFO - 2018-04-05 18:53:36 --> Controller Class Initialized
INFO - 2018-04-05 18:53:36 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:40 --> Config Class Initialized
INFO - 2018-04-05 18:53:40 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:53:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:53:40 --> Utf8 Class Initialized
INFO - 2018-04-05 18:53:40 --> URI Class Initialized
INFO - 2018-04-05 18:53:40 --> Router Class Initialized
INFO - 2018-04-05 18:53:40 --> Output Class Initialized
INFO - 2018-04-05 18:53:40 --> Security Class Initialized
DEBUG - 2018-04-05 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:53:40 --> Input Class Initialized
INFO - 2018-04-05 18:53:40 --> Language Class Initialized
INFO - 2018-04-05 18:53:40 --> Loader Class Initialized
INFO - 2018-04-05 18:53:40 --> Helper loaded: url_helper
INFO - 2018-04-05 18:53:40 --> Helper loaded: form_helper
INFO - 2018-04-05 18:53:40 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:53:40 --> Form Validation Class Initialized
INFO - 2018-04-05 18:53:40 --> Model Class Initialized
INFO - 2018-04-05 18:53:40 --> Controller Class Initialized
INFO - 2018-04-05 18:53:40 --> Model Class Initialized
DEBUG - 2018-04-05 18:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:53:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:53:40 --> Final output sent to browser
DEBUG - 2018-04-05 18:53:40 --> Total execution time: 0.1006
INFO - 2018-04-05 18:54:41 --> Config Class Initialized
INFO - 2018-04-05 18:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:54:41 --> Utf8 Class Initialized
INFO - 2018-04-05 18:54:41 --> URI Class Initialized
INFO - 2018-04-05 18:54:41 --> Router Class Initialized
INFO - 2018-04-05 18:54:41 --> Output Class Initialized
INFO - 2018-04-05 18:54:41 --> Security Class Initialized
DEBUG - 2018-04-05 18:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:54:41 --> Input Class Initialized
INFO - 2018-04-05 18:54:41 --> Language Class Initialized
INFO - 2018-04-05 18:54:41 --> Loader Class Initialized
INFO - 2018-04-05 18:54:41 --> Helper loaded: url_helper
INFO - 2018-04-05 18:54:41 --> Helper loaded: form_helper
INFO - 2018-04-05 18:54:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:54:41 --> Form Validation Class Initialized
INFO - 2018-04-05 18:54:41 --> Model Class Initialized
INFO - 2018-04-05 18:54:41 --> Controller Class Initialized
INFO - 2018-04-05 18:54:41 --> Model Class Initialized
DEBUG - 2018-04-05 18:54:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:54:41 --> Model Class Initialized
INFO - 2018-04-05 18:54:41 --> Model Class Initialized
INFO - 2018-04-05 18:54:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:54:41 --> Final output sent to browser
DEBUG - 2018-04-05 18:54:41 --> Total execution time: 0.5701
INFO - 2018-04-05 18:54:51 --> Config Class Initialized
INFO - 2018-04-05 18:54:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:54:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:54:51 --> Utf8 Class Initialized
INFO - 2018-04-05 18:54:51 --> URI Class Initialized
INFO - 2018-04-05 18:54:51 --> Router Class Initialized
INFO - 2018-04-05 18:54:51 --> Output Class Initialized
INFO - 2018-04-05 18:54:51 --> Security Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:54:51 --> Input Class Initialized
INFO - 2018-04-05 18:54:51 --> Language Class Initialized
INFO - 2018-04-05 18:54:51 --> Loader Class Initialized
INFO - 2018-04-05 18:54:51 --> Helper loaded: url_helper
INFO - 2018-04-05 18:54:51 --> Helper loaded: form_helper
INFO - 2018-04-05 18:54:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:54:51 --> Form Validation Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
INFO - 2018-04-05 18:54:51 --> Controller Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:54:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:54:51 --> Final output sent to browser
DEBUG - 2018-04-05 18:54:51 --> Total execution time: 0.0814
INFO - 2018-04-05 18:54:51 --> Config Class Initialized
INFO - 2018-04-05 18:54:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:54:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:54:51 --> Utf8 Class Initialized
INFO - 2018-04-05 18:54:51 --> URI Class Initialized
INFO - 2018-04-05 18:54:51 --> Router Class Initialized
INFO - 2018-04-05 18:54:51 --> Output Class Initialized
INFO - 2018-04-05 18:54:51 --> Security Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:54:51 --> Input Class Initialized
INFO - 2018-04-05 18:54:51 --> Language Class Initialized
INFO - 2018-04-05 18:54:51 --> Loader Class Initialized
INFO - 2018-04-05 18:54:51 --> Helper loaded: url_helper
INFO - 2018-04-05 18:54:51 --> Helper loaded: form_helper
INFO - 2018-04-05 18:54:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:54:51 --> Form Validation Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
INFO - 2018-04-05 18:54:51 --> Controller Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
INFO - 2018-04-05 18:54:51 --> Model Class Initialized
DEBUG - 2018-04-05 18:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:54:55 --> Config Class Initialized
INFO - 2018-04-05 18:54:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:54:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:54:55 --> Utf8 Class Initialized
INFO - 2018-04-05 18:54:55 --> URI Class Initialized
INFO - 2018-04-05 18:54:55 --> Router Class Initialized
INFO - 2018-04-05 18:54:55 --> Output Class Initialized
INFO - 2018-04-05 18:54:55 --> Security Class Initialized
DEBUG - 2018-04-05 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:54:55 --> Input Class Initialized
INFO - 2018-04-05 18:54:55 --> Language Class Initialized
INFO - 2018-04-05 18:54:55 --> Loader Class Initialized
INFO - 2018-04-05 18:54:55 --> Helper loaded: url_helper
INFO - 2018-04-05 18:54:55 --> Helper loaded: form_helper
INFO - 2018-04-05 18:54:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:54:55 --> Form Validation Class Initialized
INFO - 2018-04-05 18:54:55 --> Model Class Initialized
INFO - 2018-04-05 18:54:55 --> Controller Class Initialized
INFO - 2018-04-05 18:54:55 --> Model Class Initialized
INFO - 2018-04-05 18:54:55 --> Model Class Initialized
DEBUG - 2018-04-05 18:54:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:54:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:54:55 --> Final output sent to browser
DEBUG - 2018-04-05 18:54:55 --> Total execution time: 0.1047
INFO - 2018-04-05 18:55:15 --> Config Class Initialized
INFO - 2018-04-05 18:55:15 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:15 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:15 --> URI Class Initialized
INFO - 2018-04-05 18:55:15 --> Router Class Initialized
INFO - 2018-04-05 18:55:15 --> Output Class Initialized
INFO - 2018-04-05 18:55:15 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:16 --> Input Class Initialized
INFO - 2018-04-05 18:55:16 --> Language Class Initialized
INFO - 2018-04-05 18:55:16 --> Loader Class Initialized
INFO - 2018-04-05 18:55:16 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:16 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:16 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:16 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Controller Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:16 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:16 --> Total execution time: 0.1279
INFO - 2018-04-05 18:55:16 --> Config Class Initialized
INFO - 2018-04-05 18:55:16 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:16 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:16 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:16 --> URI Class Initialized
INFO - 2018-04-05 18:55:16 --> Router Class Initialized
INFO - 2018-04-05 18:55:16 --> Output Class Initialized
INFO - 2018-04-05 18:55:16 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:16 --> Input Class Initialized
INFO - 2018-04-05 18:55:16 --> Language Class Initialized
INFO - 2018-04-05 18:55:16 --> Loader Class Initialized
INFO - 2018-04-05 18:55:16 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:16 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:16 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:16 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Controller Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
INFO - 2018-04-05 18:55:16 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:17 --> Config Class Initialized
INFO - 2018-04-05 18:55:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:17 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:17 --> URI Class Initialized
INFO - 2018-04-05 18:55:17 --> Router Class Initialized
INFO - 2018-04-05 18:55:17 --> Output Class Initialized
INFO - 2018-04-05 18:55:17 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:17 --> Input Class Initialized
INFO - 2018-04-05 18:55:17 --> Language Class Initialized
INFO - 2018-04-05 18:55:17 --> Loader Class Initialized
INFO - 2018-04-05 18:55:17 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:17 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:17 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
INFO - 2018-04-05 18:55:17 --> Controller Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
INFO - 2018-04-05 18:55:17 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:17 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:17 --> Total execution time: 0.1137
INFO - 2018-04-05 18:55:18 --> Config Class Initialized
INFO - 2018-04-05 18:55:18 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:18 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:18 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:18 --> URI Class Initialized
INFO - 2018-04-05 18:55:18 --> Router Class Initialized
INFO - 2018-04-05 18:55:18 --> Output Class Initialized
INFO - 2018-04-05 18:55:18 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:18 --> Input Class Initialized
INFO - 2018-04-05 18:55:18 --> Language Class Initialized
INFO - 2018-04-05 18:55:18 --> Loader Class Initialized
INFO - 2018-04-05 18:55:18 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:18 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:18 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:18 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
INFO - 2018-04-05 18:55:18 --> Controller Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
INFO - 2018-04-05 18:55:18 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:19 --> Config Class Initialized
INFO - 2018-04-05 18:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:19 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:19 --> URI Class Initialized
INFO - 2018-04-05 18:55:19 --> Router Class Initialized
INFO - 2018-04-05 18:55:19 --> Output Class Initialized
INFO - 2018-04-05 18:55:19 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:19 --> Input Class Initialized
INFO - 2018-04-05 18:55:19 --> Language Class Initialized
INFO - 2018-04-05 18:55:19 --> Loader Class Initialized
INFO - 2018-04-05 18:55:19 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:19 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:19 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Controller Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:19 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:19 --> Total execution time: 0.1470
INFO - 2018-04-05 18:55:19 --> Config Class Initialized
INFO - 2018-04-05 18:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:19 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:19 --> URI Class Initialized
INFO - 2018-04-05 18:55:19 --> Router Class Initialized
INFO - 2018-04-05 18:55:19 --> Output Class Initialized
INFO - 2018-04-05 18:55:19 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:19 --> Input Class Initialized
INFO - 2018-04-05 18:55:19 --> Language Class Initialized
INFO - 2018-04-05 18:55:19 --> Loader Class Initialized
INFO - 2018-04-05 18:55:19 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:19 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:19 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Controller Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
INFO - 2018-04-05 18:55:19 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:20 --> Config Class Initialized
INFO - 2018-04-05 18:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:20 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:20 --> URI Class Initialized
INFO - 2018-04-05 18:55:20 --> Router Class Initialized
INFO - 2018-04-05 18:55:20 --> Output Class Initialized
INFO - 2018-04-05 18:55:20 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:20 --> Input Class Initialized
INFO - 2018-04-05 18:55:20 --> Language Class Initialized
INFO - 2018-04-05 18:55:20 --> Loader Class Initialized
INFO - 2018-04-05 18:55:20 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:20 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:20 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Controller Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:20 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:20 --> Total execution time: 0.1178
INFO - 2018-04-05 18:55:20 --> Config Class Initialized
INFO - 2018-04-05 18:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:20 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:20 --> URI Class Initialized
INFO - 2018-04-05 18:55:20 --> Router Class Initialized
INFO - 2018-04-05 18:55:20 --> Output Class Initialized
INFO - 2018-04-05 18:55:20 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:20 --> Input Class Initialized
INFO - 2018-04-05 18:55:20 --> Language Class Initialized
INFO - 2018-04-05 18:55:20 --> Loader Class Initialized
INFO - 2018-04-05 18:55:20 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:20 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:20 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Controller Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
INFO - 2018-04-05 18:55:20 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:29 --> Config Class Initialized
INFO - 2018-04-05 18:55:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:29 --> URI Class Initialized
INFO - 2018-04-05 18:55:29 --> Router Class Initialized
INFO - 2018-04-05 18:55:29 --> Output Class Initialized
INFO - 2018-04-05 18:55:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:29 --> Input Class Initialized
INFO - 2018-04-05 18:55:29 --> Language Class Initialized
INFO - 2018-04-05 18:55:29 --> Loader Class Initialized
INFO - 2018-04-05 18:55:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Controller Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:29 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:29 --> Total execution time: 0.1080
INFO - 2018-04-05 18:55:29 --> Config Class Initialized
INFO - 2018-04-05 18:55:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:29 --> URI Class Initialized
INFO - 2018-04-05 18:55:29 --> Router Class Initialized
INFO - 2018-04-05 18:55:29 --> Output Class Initialized
INFO - 2018-04-05 18:55:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:29 --> Input Class Initialized
INFO - 2018-04-05 18:55:29 --> Language Class Initialized
INFO - 2018-04-05 18:55:29 --> Loader Class Initialized
INFO - 2018-04-05 18:55:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Controller Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
INFO - 2018-04-05 18:55:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:31 --> Config Class Initialized
INFO - 2018-04-05 18:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:31 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:31 --> URI Class Initialized
INFO - 2018-04-05 18:55:31 --> Router Class Initialized
INFO - 2018-04-05 18:55:31 --> Output Class Initialized
INFO - 2018-04-05 18:55:31 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:31 --> Input Class Initialized
INFO - 2018-04-05 18:55:31 --> Language Class Initialized
INFO - 2018-04-05 18:55:31 --> Loader Class Initialized
INFO - 2018-04-05 18:55:31 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:31 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:31 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Controller Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:31 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:31 --> Total execution time: 0.1416
INFO - 2018-04-05 18:55:31 --> Config Class Initialized
INFO - 2018-04-05 18:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:31 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:31 --> URI Class Initialized
INFO - 2018-04-05 18:55:31 --> Router Class Initialized
INFO - 2018-04-05 18:55:31 --> Output Class Initialized
INFO - 2018-04-05 18:55:31 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:31 --> Input Class Initialized
INFO - 2018-04-05 18:55:31 --> Language Class Initialized
INFO - 2018-04-05 18:55:31 --> Loader Class Initialized
INFO - 2018-04-05 18:55:31 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:31 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:31 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Controller Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
INFO - 2018-04-05 18:55:31 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:37 --> Config Class Initialized
INFO - 2018-04-05 18:55:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:37 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:37 --> URI Class Initialized
INFO - 2018-04-05 18:55:37 --> Router Class Initialized
INFO - 2018-04-05 18:55:37 --> Output Class Initialized
INFO - 2018-04-05 18:55:37 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:37 --> Input Class Initialized
INFO - 2018-04-05 18:55:37 --> Language Class Initialized
INFO - 2018-04-05 18:55:37 --> Loader Class Initialized
INFO - 2018-04-05 18:55:37 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:37 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:37 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
INFO - 2018-04-05 18:55:37 --> Controller Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:37 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:37 --> Total execution time: 0.1202
INFO - 2018-04-05 18:55:37 --> Config Class Initialized
INFO - 2018-04-05 18:55:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:37 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:37 --> URI Class Initialized
INFO - 2018-04-05 18:55:37 --> Router Class Initialized
INFO - 2018-04-05 18:55:37 --> Output Class Initialized
INFO - 2018-04-05 18:55:37 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:37 --> Input Class Initialized
INFO - 2018-04-05 18:55:37 --> Language Class Initialized
INFO - 2018-04-05 18:55:37 --> Loader Class Initialized
INFO - 2018-04-05 18:55:37 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:37 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:37 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
INFO - 2018-04-05 18:55:37 --> Controller Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
INFO - 2018-04-05 18:55:37 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:38 --> Config Class Initialized
INFO - 2018-04-05 18:55:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:38 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:38 --> URI Class Initialized
INFO - 2018-04-05 18:55:38 --> Router Class Initialized
INFO - 2018-04-05 18:55:38 --> Output Class Initialized
INFO - 2018-04-05 18:55:38 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:38 --> Input Class Initialized
INFO - 2018-04-05 18:55:38 --> Language Class Initialized
INFO - 2018-04-05 18:55:38 --> Loader Class Initialized
INFO - 2018-04-05 18:55:38 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:38 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:38 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:38 --> Model Class Initialized
INFO - 2018-04-05 18:55:38 --> Controller Class Initialized
INFO - 2018-04-05 18:55:38 --> Model Class Initialized
INFO - 2018-04-05 18:55:38 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:38 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:38 --> Total execution time: 0.0877
INFO - 2018-04-05 18:55:45 --> Config Class Initialized
INFO - 2018-04-05 18:55:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:45 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:45 --> URI Class Initialized
INFO - 2018-04-05 18:55:45 --> Router Class Initialized
INFO - 2018-04-05 18:55:45 --> Output Class Initialized
INFO - 2018-04-05 18:55:45 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:45 --> Input Class Initialized
INFO - 2018-04-05 18:55:45 --> Language Class Initialized
INFO - 2018-04-05 18:55:45 --> Loader Class Initialized
INFO - 2018-04-05 18:55:45 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:45 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:46 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
INFO - 2018-04-05 18:55:46 --> Controller Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:46 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:46 --> Total execution time: 0.0760
INFO - 2018-04-05 18:55:46 --> Config Class Initialized
INFO - 2018-04-05 18:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:46 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:46 --> URI Class Initialized
INFO - 2018-04-05 18:55:46 --> Router Class Initialized
INFO - 2018-04-05 18:55:46 --> Output Class Initialized
INFO - 2018-04-05 18:55:46 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:46 --> Input Class Initialized
INFO - 2018-04-05 18:55:46 --> Language Class Initialized
INFO - 2018-04-05 18:55:46 --> Loader Class Initialized
INFO - 2018-04-05 18:55:46 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:46 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:46 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
INFO - 2018-04-05 18:55:46 --> Controller Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
INFO - 2018-04-05 18:55:46 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:49 --> Config Class Initialized
INFO - 2018-04-05 18:55:49 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:49 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:49 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:49 --> URI Class Initialized
INFO - 2018-04-05 18:55:49 --> Router Class Initialized
INFO - 2018-04-05 18:55:49 --> Output Class Initialized
INFO - 2018-04-05 18:55:49 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:49 --> Input Class Initialized
INFO - 2018-04-05 18:55:49 --> Language Class Initialized
INFO - 2018-04-05 18:55:49 --> Loader Class Initialized
INFO - 2018-04-05 18:55:49 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:49 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:49 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:49 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Controller Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:49 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:49 --> Total execution time: 0.0981
INFO - 2018-04-05 18:55:49 --> Config Class Initialized
INFO - 2018-04-05 18:55:49 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:49 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:49 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:49 --> URI Class Initialized
INFO - 2018-04-05 18:55:49 --> Router Class Initialized
INFO - 2018-04-05 18:55:49 --> Output Class Initialized
INFO - 2018-04-05 18:55:49 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:49 --> Input Class Initialized
INFO - 2018-04-05 18:55:49 --> Language Class Initialized
INFO - 2018-04-05 18:55:49 --> Loader Class Initialized
INFO - 2018-04-05 18:55:49 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:49 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:49 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:49 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Controller Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
INFO - 2018-04-05 18:55:49 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:52 --> Config Class Initialized
INFO - 2018-04-05 18:55:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:52 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:52 --> URI Class Initialized
INFO - 2018-04-05 18:55:52 --> Router Class Initialized
INFO - 2018-04-05 18:55:52 --> Output Class Initialized
INFO - 2018-04-05 18:55:52 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:52 --> Input Class Initialized
INFO - 2018-04-05 18:55:52 --> Language Class Initialized
INFO - 2018-04-05 18:55:52 --> Loader Class Initialized
INFO - 2018-04-05 18:55:52 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:52 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:52 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Controller Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:52 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:52 --> Total execution time: 0.1118
INFO - 2018-04-05 18:55:52 --> Config Class Initialized
INFO - 2018-04-05 18:55:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:52 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:52 --> URI Class Initialized
INFO - 2018-04-05 18:55:52 --> Router Class Initialized
INFO - 2018-04-05 18:55:52 --> Output Class Initialized
INFO - 2018-04-05 18:55:52 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:52 --> Input Class Initialized
INFO - 2018-04-05 18:55:52 --> Language Class Initialized
INFO - 2018-04-05 18:55:52 --> Loader Class Initialized
INFO - 2018-04-05 18:55:52 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:52 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:52 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Controller Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
INFO - 2018-04-05 18:55:52 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:55 --> Config Class Initialized
INFO - 2018-04-05 18:55:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:55 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:55 --> URI Class Initialized
INFO - 2018-04-05 18:55:55 --> Router Class Initialized
INFO - 2018-04-05 18:55:55 --> Output Class Initialized
INFO - 2018-04-05 18:55:55 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:55 --> Input Class Initialized
INFO - 2018-04-05 18:55:55 --> Language Class Initialized
INFO - 2018-04-05 18:55:55 --> Loader Class Initialized
INFO - 2018-04-05 18:55:55 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:55 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:55 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Controller Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:55 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:55 --> Total execution time: 0.0504
INFO - 2018-04-05 18:55:55 --> Config Class Initialized
INFO - 2018-04-05 18:55:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:55 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:55 --> URI Class Initialized
INFO - 2018-04-05 18:55:55 --> Router Class Initialized
INFO - 2018-04-05 18:55:55 --> Output Class Initialized
INFO - 2018-04-05 18:55:55 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:55 --> Input Class Initialized
INFO - 2018-04-05 18:55:55 --> Language Class Initialized
INFO - 2018-04-05 18:55:55 --> Loader Class Initialized
INFO - 2018-04-05 18:55:55 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:55 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:55 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Controller Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
INFO - 2018-04-05 18:55:55 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:57 --> Config Class Initialized
INFO - 2018-04-05 18:55:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:57 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:57 --> URI Class Initialized
INFO - 2018-04-05 18:55:57 --> Router Class Initialized
INFO - 2018-04-05 18:55:57 --> Output Class Initialized
INFO - 2018-04-05 18:55:57 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:57 --> Input Class Initialized
INFO - 2018-04-05 18:55:57 --> Language Class Initialized
INFO - 2018-04-05 18:55:57 --> Loader Class Initialized
INFO - 2018-04-05 18:55:57 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:57 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:57 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
INFO - 2018-04-05 18:55:57 --> Controller Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
INFO - 2018-04-05 18:55:57 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:55:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:55:57 --> Final output sent to browser
DEBUG - 2018-04-05 18:55:57 --> Total execution time: 0.1559
INFO - 2018-04-05 18:55:58 --> Config Class Initialized
INFO - 2018-04-05 18:55:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:55:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:55:58 --> URI Class Initialized
INFO - 2018-04-05 18:55:58 --> Router Class Initialized
INFO - 2018-04-05 18:55:58 --> Output Class Initialized
INFO - 2018-04-05 18:55:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:55:58 --> Input Class Initialized
INFO - 2018-04-05 18:55:58 --> Language Class Initialized
INFO - 2018-04-05 18:55:58 --> Loader Class Initialized
INFO - 2018-04-05 18:55:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:55:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:55:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:55:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
INFO - 2018-04-05 18:55:58 --> Controller Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
INFO - 2018-04-05 18:55:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:55:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:02 --> Config Class Initialized
INFO - 2018-04-05 18:56:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:02 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:02 --> URI Class Initialized
INFO - 2018-04-05 18:56:02 --> Router Class Initialized
INFO - 2018-04-05 18:56:02 --> Output Class Initialized
INFO - 2018-04-05 18:56:02 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:02 --> Input Class Initialized
INFO - 2018-04-05 18:56:02 --> Language Class Initialized
INFO - 2018-04-05 18:56:02 --> Loader Class Initialized
INFO - 2018-04-05 18:56:02 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:02 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:02 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Controller Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:56:02 --> Final output sent to browser
DEBUG - 2018-04-05 18:56:02 --> Total execution time: 0.1123
INFO - 2018-04-05 18:56:02 --> Config Class Initialized
INFO - 2018-04-05 18:56:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:02 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:02 --> URI Class Initialized
INFO - 2018-04-05 18:56:02 --> Router Class Initialized
INFO - 2018-04-05 18:56:02 --> Output Class Initialized
INFO - 2018-04-05 18:56:02 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:02 --> Input Class Initialized
INFO - 2018-04-05 18:56:02 --> Language Class Initialized
INFO - 2018-04-05 18:56:02 --> Loader Class Initialized
INFO - 2018-04-05 18:56:02 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:02 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:02 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Controller Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
INFO - 2018-04-05 18:56:02 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:04 --> Config Class Initialized
INFO - 2018-04-05 18:56:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:04 --> URI Class Initialized
INFO - 2018-04-05 18:56:04 --> Router Class Initialized
INFO - 2018-04-05 18:56:04 --> Output Class Initialized
INFO - 2018-04-05 18:56:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:04 --> Input Class Initialized
INFO - 2018-04-05 18:56:04 --> Language Class Initialized
INFO - 2018-04-05 18:56:04 --> Loader Class Initialized
INFO - 2018-04-05 18:56:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Controller Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:56:04 --> Final output sent to browser
DEBUG - 2018-04-05 18:56:04 --> Total execution time: 0.0821
INFO - 2018-04-05 18:56:04 --> Config Class Initialized
INFO - 2018-04-05 18:56:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:04 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:04 --> URI Class Initialized
INFO - 2018-04-05 18:56:04 --> Router Class Initialized
INFO - 2018-04-05 18:56:04 --> Output Class Initialized
INFO - 2018-04-05 18:56:04 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:04 --> Input Class Initialized
INFO - 2018-04-05 18:56:04 --> Language Class Initialized
INFO - 2018-04-05 18:56:04 --> Loader Class Initialized
INFO - 2018-04-05 18:56:04 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:04 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:04 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Controller Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
INFO - 2018-04-05 18:56:04 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:06 --> Config Class Initialized
INFO - 2018-04-05 18:56:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:07 --> URI Class Initialized
INFO - 2018-04-05 18:56:07 --> Router Class Initialized
INFO - 2018-04-05 18:56:07 --> Output Class Initialized
INFO - 2018-04-05 18:56:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:07 --> Input Class Initialized
INFO - 2018-04-05 18:56:07 --> Language Class Initialized
INFO - 2018-04-05 18:56:07 --> Loader Class Initialized
INFO - 2018-04-05 18:56:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
INFO - 2018-04-05 18:56:07 --> Controller Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:56:07 --> Final output sent to browser
DEBUG - 2018-04-05 18:56:07 --> Total execution time: 0.0754
INFO - 2018-04-05 18:56:07 --> Config Class Initialized
INFO - 2018-04-05 18:56:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:07 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:07 --> URI Class Initialized
INFO - 2018-04-05 18:56:07 --> Router Class Initialized
INFO - 2018-04-05 18:56:07 --> Output Class Initialized
INFO - 2018-04-05 18:56:07 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:07 --> Input Class Initialized
INFO - 2018-04-05 18:56:07 --> Language Class Initialized
INFO - 2018-04-05 18:56:07 --> Loader Class Initialized
INFO - 2018-04-05 18:56:07 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:07 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:07 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
INFO - 2018-04-05 18:56:07 --> Controller Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
INFO - 2018-04-05 18:56:07 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:08 --> Config Class Initialized
INFO - 2018-04-05 18:56:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:56:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:56:08 --> Utf8 Class Initialized
INFO - 2018-04-05 18:56:08 --> URI Class Initialized
INFO - 2018-04-05 18:56:08 --> Router Class Initialized
INFO - 2018-04-05 18:56:08 --> Output Class Initialized
INFO - 2018-04-05 18:56:08 --> Security Class Initialized
DEBUG - 2018-04-05 18:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:56:08 --> Input Class Initialized
INFO - 2018-04-05 18:56:08 --> Language Class Initialized
INFO - 2018-04-05 18:56:08 --> Loader Class Initialized
INFO - 2018-04-05 18:56:08 --> Helper loaded: url_helper
INFO - 2018-04-05 18:56:08 --> Helper loaded: form_helper
INFO - 2018-04-05 18:56:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:56:08 --> Form Validation Class Initialized
INFO - 2018-04-05 18:56:08 --> Model Class Initialized
INFO - 2018-04-05 18:56:08 --> Controller Class Initialized
INFO - 2018-04-05 18:56:08 --> Model Class Initialized
INFO - 2018-04-05 18:56:08 --> Model Class Initialized
DEBUG - 2018-04-05 18:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:56:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:56:08 --> Final output sent to browser
DEBUG - 2018-04-05 18:56:08 --> Total execution time: 0.0808
INFO - 2018-04-05 18:57:55 --> Config Class Initialized
INFO - 2018-04-05 18:57:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:57:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:57:55 --> Utf8 Class Initialized
INFO - 2018-04-05 18:57:55 --> URI Class Initialized
INFO - 2018-04-05 18:57:55 --> Router Class Initialized
INFO - 2018-04-05 18:57:55 --> Output Class Initialized
INFO - 2018-04-05 18:57:55 --> Security Class Initialized
DEBUG - 2018-04-05 18:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:57:55 --> Input Class Initialized
INFO - 2018-04-05 18:57:55 --> Language Class Initialized
INFO - 2018-04-05 18:57:55 --> Loader Class Initialized
INFO - 2018-04-05 18:57:55 --> Helper loaded: url_helper
INFO - 2018-04-05 18:57:55 --> Helper loaded: form_helper
INFO - 2018-04-05 18:57:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:57:55 --> Form Validation Class Initialized
INFO - 2018-04-05 18:57:55 --> Model Class Initialized
INFO - 2018-04-05 18:57:55 --> Controller Class Initialized
INFO - 2018-04-05 18:57:55 --> Model Class Initialized
INFO - 2018-04-05 18:57:55 --> Model Class Initialized
DEBUG - 2018-04-05 18:57:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:57:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:57:56 --> Final output sent to browser
DEBUG - 2018-04-05 18:57:56 --> Total execution time: 0.4184
INFO - 2018-04-05 18:57:58 --> Config Class Initialized
INFO - 2018-04-05 18:57:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:57:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:57:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:57:58 --> URI Class Initialized
INFO - 2018-04-05 18:57:58 --> Router Class Initialized
INFO - 2018-04-05 18:57:58 --> Output Class Initialized
INFO - 2018-04-05 18:57:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:57:58 --> Input Class Initialized
INFO - 2018-04-05 18:57:58 --> Language Class Initialized
INFO - 2018-04-05 18:57:58 --> Loader Class Initialized
INFO - 2018-04-05 18:57:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:57:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:57:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:57:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
INFO - 2018-04-05 18:57:58 --> Controller Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:57:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:57:58 --> Final output sent to browser
DEBUG - 2018-04-05 18:57:58 --> Total execution time: 0.1081
INFO - 2018-04-05 18:57:58 --> Config Class Initialized
INFO - 2018-04-05 18:57:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:57:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:57:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:57:58 --> URI Class Initialized
INFO - 2018-04-05 18:57:58 --> Router Class Initialized
INFO - 2018-04-05 18:57:58 --> Output Class Initialized
INFO - 2018-04-05 18:57:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:57:58 --> Input Class Initialized
INFO - 2018-04-05 18:57:58 --> Language Class Initialized
INFO - 2018-04-05 18:57:58 --> Loader Class Initialized
INFO - 2018-04-05 18:57:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:57:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:57:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:57:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
INFO - 2018-04-05 18:57:58 --> Controller Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
INFO - 2018-04-05 18:57:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:29 --> Config Class Initialized
INFO - 2018-04-05 18:58:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:29 --> URI Class Initialized
INFO - 2018-04-05 18:58:29 --> Router Class Initialized
INFO - 2018-04-05 18:58:29 --> Output Class Initialized
INFO - 2018-04-05 18:58:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:29 --> Input Class Initialized
INFO - 2018-04-05 18:58:29 --> Language Class Initialized
INFO - 2018-04-05 18:58:29 --> Loader Class Initialized
INFO - 2018-04-05 18:58:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Controller Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:29 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:29 --> Total execution time: 0.0856
INFO - 2018-04-05 18:58:29 --> Config Class Initialized
INFO - 2018-04-05 18:58:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:29 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:29 --> URI Class Initialized
INFO - 2018-04-05 18:58:29 --> Router Class Initialized
INFO - 2018-04-05 18:58:29 --> Output Class Initialized
INFO - 2018-04-05 18:58:29 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:29 --> Input Class Initialized
INFO - 2018-04-05 18:58:29 --> Language Class Initialized
INFO - 2018-04-05 18:58:29 --> Loader Class Initialized
INFO - 2018-04-05 18:58:29 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:29 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:29 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Controller Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
INFO - 2018-04-05 18:58:29 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:31 --> Config Class Initialized
INFO - 2018-04-05 18:58:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:31 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:31 --> URI Class Initialized
INFO - 2018-04-05 18:58:31 --> Router Class Initialized
INFO - 2018-04-05 18:58:31 --> Output Class Initialized
INFO - 2018-04-05 18:58:31 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:31 --> Input Class Initialized
INFO - 2018-04-05 18:58:31 --> Language Class Initialized
INFO - 2018-04-05 18:58:31 --> Loader Class Initialized
INFO - 2018-04-05 18:58:31 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:31 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:31 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
INFO - 2018-04-05 18:58:31 --> Controller Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
INFO - 2018-04-05 18:58:31 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:31 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:31 --> Total execution time: 0.1605
INFO - 2018-04-05 18:58:32 --> Config Class Initialized
INFO - 2018-04-05 18:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:32 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:32 --> URI Class Initialized
INFO - 2018-04-05 18:58:32 --> Router Class Initialized
INFO - 2018-04-05 18:58:32 --> Output Class Initialized
INFO - 2018-04-05 18:58:32 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:32 --> Input Class Initialized
INFO - 2018-04-05 18:58:32 --> Language Class Initialized
INFO - 2018-04-05 18:58:32 --> Loader Class Initialized
INFO - 2018-04-05 18:58:32 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:32 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:32 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
INFO - 2018-04-05 18:58:32 --> Controller Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
INFO - 2018-04-05 18:58:32 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:33 --> Config Class Initialized
INFO - 2018-04-05 18:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:33 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:33 --> URI Class Initialized
INFO - 2018-04-05 18:58:33 --> Router Class Initialized
INFO - 2018-04-05 18:58:33 --> Output Class Initialized
INFO - 2018-04-05 18:58:33 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:33 --> Input Class Initialized
INFO - 2018-04-05 18:58:33 --> Language Class Initialized
INFO - 2018-04-05 18:58:33 --> Loader Class Initialized
INFO - 2018-04-05 18:58:33 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:33 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:33 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Controller Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:33 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:33 --> Total execution time: 0.1051
INFO - 2018-04-05 18:58:33 --> Config Class Initialized
INFO - 2018-04-05 18:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:33 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:33 --> URI Class Initialized
INFO - 2018-04-05 18:58:33 --> Router Class Initialized
INFO - 2018-04-05 18:58:33 --> Output Class Initialized
INFO - 2018-04-05 18:58:33 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:33 --> Input Class Initialized
INFO - 2018-04-05 18:58:33 --> Language Class Initialized
INFO - 2018-04-05 18:58:33 --> Loader Class Initialized
INFO - 2018-04-05 18:58:33 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:33 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:33 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Controller Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
INFO - 2018-04-05 18:58:33 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:35 --> Config Class Initialized
INFO - 2018-04-05 18:58:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:35 --> URI Class Initialized
INFO - 2018-04-05 18:58:35 --> Router Class Initialized
INFO - 2018-04-05 18:58:35 --> Output Class Initialized
INFO - 2018-04-05 18:58:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:35 --> Input Class Initialized
INFO - 2018-04-05 18:58:35 --> Language Class Initialized
INFO - 2018-04-05 18:58:35 --> Loader Class Initialized
INFO - 2018-04-05 18:58:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Controller Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:35 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:35 --> Total execution time: 0.1081
INFO - 2018-04-05 18:58:35 --> Config Class Initialized
INFO - 2018-04-05 18:58:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:35 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:35 --> URI Class Initialized
INFO - 2018-04-05 18:58:35 --> Router Class Initialized
INFO - 2018-04-05 18:58:35 --> Output Class Initialized
INFO - 2018-04-05 18:58:35 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:35 --> Input Class Initialized
INFO - 2018-04-05 18:58:35 --> Language Class Initialized
INFO - 2018-04-05 18:58:35 --> Loader Class Initialized
INFO - 2018-04-05 18:58:35 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:35 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:35 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Controller Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
INFO - 2018-04-05 18:58:35 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:44 --> Config Class Initialized
INFO - 2018-04-05 18:58:44 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:44 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:44 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:44 --> URI Class Initialized
INFO - 2018-04-05 18:58:44 --> Router Class Initialized
INFO - 2018-04-05 18:58:44 --> Output Class Initialized
INFO - 2018-04-05 18:58:44 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:44 --> Input Class Initialized
INFO - 2018-04-05 18:58:44 --> Language Class Initialized
INFO - 2018-04-05 18:58:44 --> Loader Class Initialized
INFO - 2018-04-05 18:58:44 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:44 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:44 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:44 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Controller Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:44 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:44 --> Total execution time: 0.1013
INFO - 2018-04-05 18:58:44 --> Config Class Initialized
INFO - 2018-04-05 18:58:44 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:44 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:44 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:44 --> URI Class Initialized
INFO - 2018-04-05 18:58:44 --> Router Class Initialized
INFO - 2018-04-05 18:58:44 --> Output Class Initialized
INFO - 2018-04-05 18:58:44 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:44 --> Input Class Initialized
INFO - 2018-04-05 18:58:44 --> Language Class Initialized
INFO - 2018-04-05 18:58:44 --> Loader Class Initialized
INFO - 2018-04-05 18:58:44 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:44 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:44 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:44 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Controller Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:44 --> Model Class Initialized
INFO - 2018-04-05 18:58:45 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:47 --> Config Class Initialized
INFO - 2018-04-05 18:58:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:47 --> URI Class Initialized
INFO - 2018-04-05 18:58:47 --> Router Class Initialized
INFO - 2018-04-05 18:58:47 --> Output Class Initialized
INFO - 2018-04-05 18:58:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:47 --> Input Class Initialized
INFO - 2018-04-05 18:58:47 --> Language Class Initialized
INFO - 2018-04-05 18:58:47 --> Loader Class Initialized
INFO - 2018-04-05 18:58:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Controller Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:47 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:47 --> Total execution time: 0.1082
INFO - 2018-04-05 18:58:47 --> Config Class Initialized
INFO - 2018-04-05 18:58:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:47 --> URI Class Initialized
INFO - 2018-04-05 18:58:47 --> Router Class Initialized
INFO - 2018-04-05 18:58:47 --> Output Class Initialized
INFO - 2018-04-05 18:58:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:47 --> Input Class Initialized
INFO - 2018-04-05 18:58:47 --> Language Class Initialized
INFO - 2018-04-05 18:58:47 --> Loader Class Initialized
INFO - 2018-04-05 18:58:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Controller Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
INFO - 2018-04-05 18:58:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:54 --> Config Class Initialized
INFO - 2018-04-05 18:58:54 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:54 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:54 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:54 --> URI Class Initialized
INFO - 2018-04-05 18:58:54 --> Router Class Initialized
INFO - 2018-04-05 18:58:54 --> Output Class Initialized
INFO - 2018-04-05 18:58:54 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:54 --> Input Class Initialized
INFO - 2018-04-05 18:58:54 --> Language Class Initialized
INFO - 2018-04-05 18:58:54 --> Loader Class Initialized
INFO - 2018-04-05 18:58:54 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:54 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:54 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:54 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Controller Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:54 --> Config Class Initialized
INFO - 2018-04-05 18:58:54 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:54 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:54 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:54 --> URI Class Initialized
INFO - 2018-04-05 18:58:54 --> Router Class Initialized
INFO - 2018-04-05 18:58:54 --> Output Class Initialized
INFO - 2018-04-05 18:58:54 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:54 --> Input Class Initialized
INFO - 2018-04-05 18:58:54 --> Language Class Initialized
INFO - 2018-04-05 18:58:54 --> Loader Class Initialized
INFO - 2018-04-05 18:58:54 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:54 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:54 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:54 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Controller Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
INFO - 2018-04-05 18:58:54 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:58 --> Config Class Initialized
INFO - 2018-04-05 18:58:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:58 --> URI Class Initialized
INFO - 2018-04-05 18:58:58 --> Router Class Initialized
INFO - 2018-04-05 18:58:58 --> Output Class Initialized
INFO - 2018-04-05 18:58:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:58 --> Input Class Initialized
INFO - 2018-04-05 18:58:58 --> Language Class Initialized
INFO - 2018-04-05 18:58:58 --> Loader Class Initialized
INFO - 2018-04-05 18:58:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Controller Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:58:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:58:58 --> Final output sent to browser
DEBUG - 2018-04-05 18:58:58 --> Total execution time: 0.1028
INFO - 2018-04-05 18:58:58 --> Config Class Initialized
INFO - 2018-04-05 18:58:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:58:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:58:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:58:58 --> URI Class Initialized
INFO - 2018-04-05 18:58:58 --> Router Class Initialized
INFO - 2018-04-05 18:58:58 --> Output Class Initialized
INFO - 2018-04-05 18:58:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:58:58 --> Input Class Initialized
INFO - 2018-04-05 18:58:58 --> Language Class Initialized
INFO - 2018-04-05 18:58:58 --> Loader Class Initialized
INFO - 2018-04-05 18:58:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:58:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:58:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:58:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Controller Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
INFO - 2018-04-05 18:58:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:58:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:00 --> Config Class Initialized
INFO - 2018-04-05 18:59:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:00 --> URI Class Initialized
INFO - 2018-04-05 18:59:00 --> Router Class Initialized
INFO - 2018-04-05 18:59:00 --> Output Class Initialized
INFO - 2018-04-05 18:59:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:00 --> Input Class Initialized
INFO - 2018-04-05 18:59:00 --> Language Class Initialized
INFO - 2018-04-05 18:59:00 --> Loader Class Initialized
INFO - 2018-04-05 18:59:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Controller Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:00 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:00 --> Total execution time: 0.1651
INFO - 2018-04-05 18:59:00 --> Config Class Initialized
INFO - 2018-04-05 18:59:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:00 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:00 --> URI Class Initialized
INFO - 2018-04-05 18:59:00 --> Router Class Initialized
INFO - 2018-04-05 18:59:00 --> Output Class Initialized
INFO - 2018-04-05 18:59:00 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:00 --> Input Class Initialized
INFO - 2018-04-05 18:59:00 --> Language Class Initialized
INFO - 2018-04-05 18:59:00 --> Loader Class Initialized
INFO - 2018-04-05 18:59:00 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:00 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:00 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Controller Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
INFO - 2018-04-05 18:59:00 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:06 --> Config Class Initialized
INFO - 2018-04-05 18:59:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:06 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:06 --> URI Class Initialized
INFO - 2018-04-05 18:59:06 --> Router Class Initialized
INFO - 2018-04-05 18:59:06 --> Output Class Initialized
INFO - 2018-04-05 18:59:06 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:06 --> Input Class Initialized
INFO - 2018-04-05 18:59:06 --> Language Class Initialized
INFO - 2018-04-05 18:59:06 --> Loader Class Initialized
INFO - 2018-04-05 18:59:06 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:06 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:06 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
INFO - 2018-04-05 18:59:06 --> Controller Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
INFO - 2018-04-05 18:59:06 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:38 --> Config Class Initialized
INFO - 2018-04-05 18:59:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:38 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:38 --> URI Class Initialized
INFO - 2018-04-05 18:59:38 --> Router Class Initialized
INFO - 2018-04-05 18:59:38 --> Output Class Initialized
INFO - 2018-04-05 18:59:38 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:38 --> Input Class Initialized
INFO - 2018-04-05 18:59:38 --> Language Class Initialized
INFO - 2018-04-05 18:59:38 --> Loader Class Initialized
INFO - 2018-04-05 18:59:38 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:38 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:38 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:38 --> Model Class Initialized
INFO - 2018-04-05 18:59:38 --> Controller Class Initialized
INFO - 2018-04-05 18:59:38 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:38 --> Config Class Initialized
INFO - 2018-04-05 18:59:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:38 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:38 --> URI Class Initialized
INFO - 2018-04-05 18:59:38 --> Router Class Initialized
INFO - 2018-04-05 18:59:38 --> Output Class Initialized
INFO - 2018-04-05 18:59:38 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:38 --> Input Class Initialized
INFO - 2018-04-05 18:59:38 --> Language Class Initialized
INFO - 2018-04-05 18:59:38 --> Loader Class Initialized
INFO - 2018-04-05 18:59:38 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:38 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:38 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:38 --> Model Class Initialized
INFO - 2018-04-05 18:59:38 --> Controller Class Initialized
INFO - 2018-04-05 18:59:38 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:38 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:38 --> Total execution time: 0.0583
INFO - 2018-04-05 18:59:42 --> Config Class Initialized
INFO - 2018-04-05 18:59:42 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:42 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:42 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:42 --> URI Class Initialized
INFO - 2018-04-05 18:59:42 --> Router Class Initialized
INFO - 2018-04-05 18:59:42 --> Output Class Initialized
INFO - 2018-04-05 18:59:42 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:42 --> Input Class Initialized
INFO - 2018-04-05 18:59:42 --> Language Class Initialized
INFO - 2018-04-05 18:59:42 --> Loader Class Initialized
INFO - 2018-04-05 18:59:42 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:42 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:42 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:42 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:42 --> Model Class Initialized
INFO - 2018-04-05 18:59:42 --> Controller Class Initialized
INFO - 2018-04-05 18:59:42 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 18:59:43 --> Config Class Initialized
INFO - 2018-04-05 18:59:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:43 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:43 --> URI Class Initialized
DEBUG - 2018-04-05 18:59:43 --> No URI present. Default controller set.
INFO - 2018-04-05 18:59:43 --> Router Class Initialized
INFO - 2018-04-05 18:59:43 --> Output Class Initialized
INFO - 2018-04-05 18:59:43 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:43 --> Input Class Initialized
INFO - 2018-04-05 18:59:43 --> Language Class Initialized
INFO - 2018-04-05 18:59:43 --> Loader Class Initialized
INFO - 2018-04-05 18:59:43 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:43 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:43 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Controller Class Initialized
INFO - 2018-04-05 18:59:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:43 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:43 --> Total execution time: 0.0947
INFO - 2018-04-05 18:59:43 --> Config Class Initialized
INFO - 2018-04-05 18:59:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:43 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:43 --> URI Class Initialized
INFO - 2018-04-05 18:59:43 --> Router Class Initialized
INFO - 2018-04-05 18:59:43 --> Output Class Initialized
INFO - 2018-04-05 18:59:43 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:43 --> Input Class Initialized
INFO - 2018-04-05 18:59:43 --> Language Class Initialized
INFO - 2018-04-05 18:59:43 --> Loader Class Initialized
INFO - 2018-04-05 18:59:43 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:43 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:43 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Controller Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
INFO - 2018-04-05 18:59:43 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:45 --> Config Class Initialized
INFO - 2018-04-05 18:59:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:45 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:45 --> URI Class Initialized
INFO - 2018-04-05 18:59:45 --> Router Class Initialized
INFO - 2018-04-05 18:59:45 --> Output Class Initialized
INFO - 2018-04-05 18:59:45 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:45 --> Input Class Initialized
INFO - 2018-04-05 18:59:45 --> Language Class Initialized
INFO - 2018-04-05 18:59:45 --> Loader Class Initialized
INFO - 2018-04-05 18:59:45 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:45 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:45 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:45 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Controller Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:45 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:45 --> Total execution time: 0.1423
INFO - 2018-04-05 18:59:45 --> Config Class Initialized
INFO - 2018-04-05 18:59:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:45 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:45 --> URI Class Initialized
INFO - 2018-04-05 18:59:45 --> Router Class Initialized
INFO - 2018-04-05 18:59:45 --> Output Class Initialized
INFO - 2018-04-05 18:59:45 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:45 --> Input Class Initialized
INFO - 2018-04-05 18:59:45 --> Language Class Initialized
INFO - 2018-04-05 18:59:45 --> Loader Class Initialized
INFO - 2018-04-05 18:59:45 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:45 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:45 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:45 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Controller Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
INFO - 2018-04-05 18:59:45 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:47 --> Config Class Initialized
INFO - 2018-04-05 18:59:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:47 --> URI Class Initialized
INFO - 2018-04-05 18:59:47 --> Router Class Initialized
INFO - 2018-04-05 18:59:47 --> Output Class Initialized
INFO - 2018-04-05 18:59:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:47 --> Input Class Initialized
INFO - 2018-04-05 18:59:47 --> Language Class Initialized
INFO - 2018-04-05 18:59:47 --> Loader Class Initialized
INFO - 2018-04-05 18:59:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Controller Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:47 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:47 --> Total execution time: 0.1819
INFO - 2018-04-05 18:59:47 --> Config Class Initialized
INFO - 2018-04-05 18:59:47 --> Hooks Class Initialized
INFO - 2018-04-05 18:59:47 --> Config Class Initialized
INFO - 2018-04-05 18:59:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:47 --> URI Class Initialized
DEBUG - 2018-04-05 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:47 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:47 --> Router Class Initialized
INFO - 2018-04-05 18:59:47 --> URI Class Initialized
INFO - 2018-04-05 18:59:47 --> Output Class Initialized
INFO - 2018-04-05 18:59:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:47 --> Input Class Initialized
INFO - 2018-04-05 18:59:47 --> Language Class Initialized
INFO - 2018-04-05 18:59:47 --> Router Class Initialized
INFO - 2018-04-05 18:59:47 --> Loader Class Initialized
INFO - 2018-04-05 18:59:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:47 --> Output Class Initialized
INFO - 2018-04-05 18:59:47 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:47 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:47 --> Input Class Initialized
INFO - 2018-04-05 18:59:47 --> Language Class Initialized
INFO - 2018-04-05 18:59:47 --> Database Driver Class Initialized
INFO - 2018-04-05 18:59:47 --> Loader Class Initialized
INFO - 2018-04-05 18:59:47 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:47 --> Helper loaded: form_helper
DEBUG - 2018-04-05 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Controller Class Initialized
INFO - 2018-04-05 18:59:47 --> Database Driver Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:47 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Controller Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
INFO - 2018-04-05 18:59:47 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:57 --> Config Class Initialized
INFO - 2018-04-05 18:59:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:57 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:57 --> URI Class Initialized
INFO - 2018-04-05 18:59:57 --> Router Class Initialized
INFO - 2018-04-05 18:59:57 --> Output Class Initialized
INFO - 2018-04-05 18:59:57 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:57 --> Input Class Initialized
INFO - 2018-04-05 18:59:57 --> Language Class Initialized
INFO - 2018-04-05 18:59:57 --> Loader Class Initialized
INFO - 2018-04-05 18:59:57 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:57 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:57 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
INFO - 2018-04-05 18:59:57 --> Controller Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
INFO - 2018-04-05 18:59:57 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:57 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:57 --> Total execution time: 0.4789
INFO - 2018-04-05 18:59:58 --> Config Class Initialized
INFO - 2018-04-05 18:59:58 --> Hooks Class Initialized
INFO - 2018-04-05 18:59:58 --> Config Class Initialized
INFO - 2018-04-05 18:59:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:58 --> Utf8 Class Initialized
DEBUG - 2018-04-05 18:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:58 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:58 --> URI Class Initialized
INFO - 2018-04-05 18:59:58 --> URI Class Initialized
INFO - 2018-04-05 18:59:58 --> Router Class Initialized
INFO - 2018-04-05 18:59:58 --> Router Class Initialized
INFO - 2018-04-05 18:59:58 --> Output Class Initialized
INFO - 2018-04-05 18:59:58 --> Output Class Initialized
INFO - 2018-04-05 18:59:58 --> Security Class Initialized
INFO - 2018-04-05 18:59:58 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:58 --> Input Class Initialized
DEBUG - 2018-04-05 18:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:58 --> Input Class Initialized
INFO - 2018-04-05 18:59:58 --> Language Class Initialized
INFO - 2018-04-05 18:59:58 --> Language Class Initialized
INFO - 2018-04-05 18:59:58 --> Loader Class Initialized
INFO - 2018-04-05 18:59:58 --> Loader Class Initialized
INFO - 2018-04-05 18:59:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:58 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:58 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:58 --> Database Driver Class Initialized
INFO - 2018-04-05 18:59:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-05 18:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Controller Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:58 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Controller Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
INFO - 2018-04-05 18:59:58 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:59 --> Config Class Initialized
INFO - 2018-04-05 18:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:59 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:59 --> URI Class Initialized
INFO - 2018-04-05 18:59:59 --> Router Class Initialized
INFO - 2018-04-05 18:59:59 --> Output Class Initialized
INFO - 2018-04-05 18:59:59 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:59 --> Input Class Initialized
INFO - 2018-04-05 18:59:59 --> Language Class Initialized
INFO - 2018-04-05 18:59:59 --> Loader Class Initialized
INFO - 2018-04-05 18:59:59 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:59 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:59 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Controller Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 18:59:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 18:59:59 --> Final output sent to browser
DEBUG - 2018-04-05 18:59:59 --> Total execution time: 0.1183
INFO - 2018-04-05 18:59:59 --> Config Class Initialized
INFO - 2018-04-05 18:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 18:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 18:59:59 --> Utf8 Class Initialized
INFO - 2018-04-05 18:59:59 --> URI Class Initialized
INFO - 2018-04-05 18:59:59 --> Router Class Initialized
INFO - 2018-04-05 18:59:59 --> Output Class Initialized
INFO - 2018-04-05 18:59:59 --> Security Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 18:59:59 --> Input Class Initialized
INFO - 2018-04-05 18:59:59 --> Language Class Initialized
INFO - 2018-04-05 18:59:59 --> Loader Class Initialized
INFO - 2018-04-05 18:59:59 --> Helper loaded: url_helper
INFO - 2018-04-05 18:59:59 --> Helper loaded: form_helper
INFO - 2018-04-05 18:59:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 18:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 18:59:59 --> Form Validation Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Controller Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
INFO - 2018-04-05 18:59:59 --> Model Class Initialized
DEBUG - 2018-04-05 18:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:04 --> Config Class Initialized
INFO - 2018-04-05 19:00:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:04 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:04 --> URI Class Initialized
INFO - 2018-04-05 19:00:04 --> Router Class Initialized
INFO - 2018-04-05 19:00:04 --> Output Class Initialized
INFO - 2018-04-05 19:00:04 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:04 --> Input Class Initialized
INFO - 2018-04-05 19:00:04 --> Language Class Initialized
INFO - 2018-04-05 19:00:04 --> Loader Class Initialized
INFO - 2018-04-05 19:00:04 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:04 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:04 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Controller Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:04 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:04 --> Total execution time: 0.1019
INFO - 2018-04-05 19:00:04 --> Config Class Initialized
INFO - 2018-04-05 19:00:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:04 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:04 --> URI Class Initialized
INFO - 2018-04-05 19:00:04 --> Router Class Initialized
INFO - 2018-04-05 19:00:04 --> Output Class Initialized
INFO - 2018-04-05 19:00:04 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:04 --> Input Class Initialized
INFO - 2018-04-05 19:00:04 --> Language Class Initialized
INFO - 2018-04-05 19:00:04 --> Loader Class Initialized
INFO - 2018-04-05 19:00:04 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:04 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:04 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Controller Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
INFO - 2018-04-05 19:00:04 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:06 --> Config Class Initialized
INFO - 2018-04-05 19:00:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:06 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:06 --> URI Class Initialized
INFO - 2018-04-05 19:00:06 --> Router Class Initialized
INFO - 2018-04-05 19:00:06 --> Output Class Initialized
INFO - 2018-04-05 19:00:06 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:06 --> Input Class Initialized
INFO - 2018-04-05 19:00:06 --> Language Class Initialized
INFO - 2018-04-05 19:00:06 --> Loader Class Initialized
INFO - 2018-04-05 19:00:06 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:06 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:06 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Controller Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:06 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:06 --> Total execution time: 0.1003
INFO - 2018-04-05 19:00:06 --> Config Class Initialized
INFO - 2018-04-05 19:00:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:06 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:06 --> URI Class Initialized
INFO - 2018-04-05 19:00:06 --> Router Class Initialized
INFO - 2018-04-05 19:00:06 --> Output Class Initialized
INFO - 2018-04-05 19:00:06 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:06 --> Input Class Initialized
INFO - 2018-04-05 19:00:06 --> Language Class Initialized
INFO - 2018-04-05 19:00:06 --> Loader Class Initialized
INFO - 2018-04-05 19:00:06 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:06 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:06 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Controller Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
INFO - 2018-04-05 19:00:06 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:28 --> Config Class Initialized
INFO - 2018-04-05 19:00:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:28 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:28 --> URI Class Initialized
INFO - 2018-04-05 19:00:28 --> Router Class Initialized
INFO - 2018-04-05 19:00:28 --> Output Class Initialized
INFO - 2018-04-05 19:00:28 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:28 --> Input Class Initialized
INFO - 2018-04-05 19:00:28 --> Language Class Initialized
INFO - 2018-04-05 19:00:28 --> Loader Class Initialized
INFO - 2018-04-05 19:00:28 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:28 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:28 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
INFO - 2018-04-05 19:00:28 --> Controller Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:28 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:28 --> Total execution time: 0.1036
INFO - 2018-04-05 19:00:28 --> Config Class Initialized
INFO - 2018-04-05 19:00:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:28 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:28 --> URI Class Initialized
INFO - 2018-04-05 19:00:28 --> Router Class Initialized
INFO - 2018-04-05 19:00:28 --> Output Class Initialized
INFO - 2018-04-05 19:00:28 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:28 --> Input Class Initialized
INFO - 2018-04-05 19:00:28 --> Language Class Initialized
INFO - 2018-04-05 19:00:28 --> Loader Class Initialized
INFO - 2018-04-05 19:00:28 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:28 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:28 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
INFO - 2018-04-05 19:00:28 --> Controller Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
INFO - 2018-04-05 19:00:28 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:30 --> Config Class Initialized
INFO - 2018-04-05 19:00:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:30 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:30 --> URI Class Initialized
INFO - 2018-04-05 19:00:30 --> Router Class Initialized
INFO - 2018-04-05 19:00:30 --> Output Class Initialized
INFO - 2018-04-05 19:00:30 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:30 --> Input Class Initialized
INFO - 2018-04-05 19:00:30 --> Language Class Initialized
INFO - 2018-04-05 19:00:30 --> Loader Class Initialized
INFO - 2018-04-05 19:00:30 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:30 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:30 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:30 --> Model Class Initialized
INFO - 2018-04-05 19:00:30 --> Controller Class Initialized
INFO - 2018-04-05 19:00:30 --> Model Class Initialized
INFO - 2018-04-05 19:00:30 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:30 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:30 --> Total execution time: 0.0960
INFO - 2018-04-05 19:00:54 --> Config Class Initialized
INFO - 2018-04-05 19:00:54 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:54 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:54 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:54 --> URI Class Initialized
INFO - 2018-04-05 19:00:54 --> Router Class Initialized
INFO - 2018-04-05 19:00:54 --> Output Class Initialized
INFO - 2018-04-05 19:00:54 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:54 --> Input Class Initialized
INFO - 2018-04-05 19:00:54 --> Language Class Initialized
INFO - 2018-04-05 19:00:54 --> Loader Class Initialized
INFO - 2018-04-05 19:00:54 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:54 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:54 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:54 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:54 --> Model Class Initialized
INFO - 2018-04-05 19:00:54 --> Controller Class Initialized
INFO - 2018-04-05 19:00:54 --> Model Class Initialized
INFO - 2018-04-05 19:00:54 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:55 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:55 --> Total execution time: 0.4511
INFO - 2018-04-05 19:00:57 --> Config Class Initialized
INFO - 2018-04-05 19:00:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:57 --> URI Class Initialized
INFO - 2018-04-05 19:00:57 --> Router Class Initialized
INFO - 2018-04-05 19:00:57 --> Output Class Initialized
INFO - 2018-04-05 19:00:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:57 --> Input Class Initialized
INFO - 2018-04-05 19:00:57 --> Language Class Initialized
INFO - 2018-04-05 19:00:57 --> Loader Class Initialized
INFO - 2018-04-05 19:00:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Controller Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:57 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:57 --> Total execution time: 0.1164
INFO - 2018-04-05 19:00:57 --> Config Class Initialized
INFO - 2018-04-05 19:00:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:57 --> URI Class Initialized
INFO - 2018-04-05 19:00:57 --> Router Class Initialized
INFO - 2018-04-05 19:00:57 --> Output Class Initialized
INFO - 2018-04-05 19:00:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:57 --> Input Class Initialized
INFO - 2018-04-05 19:00:57 --> Language Class Initialized
INFO - 2018-04-05 19:00:57 --> Loader Class Initialized
INFO - 2018-04-05 19:00:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Controller Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
INFO - 2018-04-05 19:00:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:59 --> Config Class Initialized
INFO - 2018-04-05 19:00:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:59 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:59 --> URI Class Initialized
INFO - 2018-04-05 19:00:59 --> Router Class Initialized
INFO - 2018-04-05 19:00:59 --> Output Class Initialized
INFO - 2018-04-05 19:00:59 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:59 --> Input Class Initialized
INFO - 2018-04-05 19:00:59 --> Language Class Initialized
INFO - 2018-04-05 19:00:59 --> Loader Class Initialized
INFO - 2018-04-05 19:00:59 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:59 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:00:59 --> Form Validation Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
INFO - 2018-04-05 19:00:59 --> Controller Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
INFO - 2018-04-05 19:00:59 --> Model Class Initialized
DEBUG - 2018-04-05 19:00:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:00:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:00:59 --> Final output sent to browser
DEBUG - 2018-04-05 19:00:59 --> Total execution time: 0.0969
INFO - 2018-04-05 19:00:59 --> Config Class Initialized
INFO - 2018-04-05 19:00:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:00:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:00:59 --> Utf8 Class Initialized
INFO - 2018-04-05 19:00:59 --> URI Class Initialized
INFO - 2018-04-05 19:00:59 --> Router Class Initialized
INFO - 2018-04-05 19:00:59 --> Output Class Initialized
INFO - 2018-04-05 19:00:59 --> Security Class Initialized
DEBUG - 2018-04-05 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:00:59 --> Input Class Initialized
INFO - 2018-04-05 19:00:59 --> Language Class Initialized
INFO - 2018-04-05 19:00:59 --> Loader Class Initialized
INFO - 2018-04-05 19:00:59 --> Helper loaded: url_helper
INFO - 2018-04-05 19:00:59 --> Helper loaded: form_helper
INFO - 2018-04-05 19:00:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:00 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
INFO - 2018-04-05 19:01:00 --> Controller Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
INFO - 2018-04-05 19:01:00 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:01 --> Config Class Initialized
INFO - 2018-04-05 19:01:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:01 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:01 --> URI Class Initialized
INFO - 2018-04-05 19:01:01 --> Router Class Initialized
INFO - 2018-04-05 19:01:01 --> Output Class Initialized
INFO - 2018-04-05 19:01:01 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:01 --> Input Class Initialized
INFO - 2018-04-05 19:01:01 --> Language Class Initialized
INFO - 2018-04-05 19:01:01 --> Loader Class Initialized
INFO - 2018-04-05 19:01:01 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:01 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:01 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
INFO - 2018-04-05 19:01:01 --> Controller Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
INFO - 2018-04-05 19:01:01 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:01 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:01 --> Total execution time: 0.1385
INFO - 2018-04-05 19:01:02 --> Config Class Initialized
INFO - 2018-04-05 19:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:02 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:02 --> URI Class Initialized
INFO - 2018-04-05 19:01:02 --> Router Class Initialized
INFO - 2018-04-05 19:01:02 --> Output Class Initialized
INFO - 2018-04-05 19:01:02 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:02 --> Input Class Initialized
INFO - 2018-04-05 19:01:02 --> Language Class Initialized
INFO - 2018-04-05 19:01:02 --> Loader Class Initialized
INFO - 2018-04-05 19:01:02 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:02 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:02 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
INFO - 2018-04-05 19:01:02 --> Controller Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
INFO - 2018-04-05 19:01:02 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:03 --> Config Class Initialized
INFO - 2018-04-05 19:01:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:03 --> URI Class Initialized
INFO - 2018-04-05 19:01:03 --> Router Class Initialized
INFO - 2018-04-05 19:01:03 --> Output Class Initialized
INFO - 2018-04-05 19:01:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:03 --> Input Class Initialized
INFO - 2018-04-05 19:01:03 --> Language Class Initialized
INFO - 2018-04-05 19:01:03 --> Loader Class Initialized
INFO - 2018-04-05 19:01:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Controller Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:03 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:03 --> Total execution time: 0.1349
INFO - 2018-04-05 19:01:03 --> Config Class Initialized
INFO - 2018-04-05 19:01:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:03 --> URI Class Initialized
INFO - 2018-04-05 19:01:03 --> Router Class Initialized
INFO - 2018-04-05 19:01:03 --> Output Class Initialized
INFO - 2018-04-05 19:01:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:03 --> Input Class Initialized
INFO - 2018-04-05 19:01:03 --> Language Class Initialized
INFO - 2018-04-05 19:01:03 --> Loader Class Initialized
INFO - 2018-04-05 19:01:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Controller Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
INFO - 2018-04-05 19:01:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:10 --> Config Class Initialized
INFO - 2018-04-05 19:01:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:10 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:10 --> URI Class Initialized
INFO - 2018-04-05 19:01:10 --> Router Class Initialized
INFO - 2018-04-05 19:01:10 --> Output Class Initialized
INFO - 2018-04-05 19:01:10 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:10 --> Input Class Initialized
INFO - 2018-04-05 19:01:10 --> Language Class Initialized
INFO - 2018-04-05 19:01:10 --> Loader Class Initialized
INFO - 2018-04-05 19:01:10 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:10 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:10 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
INFO - 2018-04-05 19:01:10 --> Controller Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
INFO - 2018-04-05 19:01:10 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:10 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:10 --> Total execution time: 0.1112
INFO - 2018-04-05 19:01:10 --> Config Class Initialized
INFO - 2018-04-05 19:01:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:10 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:10 --> URI Class Initialized
INFO - 2018-04-05 19:01:10 --> Router Class Initialized
INFO - 2018-04-05 19:01:10 --> Output Class Initialized
INFO - 2018-04-05 19:01:10 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:10 --> Input Class Initialized
INFO - 2018-04-05 19:01:10 --> Language Class Initialized
INFO - 2018-04-05 19:01:11 --> Loader Class Initialized
INFO - 2018-04-05 19:01:11 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:11 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
INFO - 2018-04-05 19:01:11 --> Controller Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
INFO - 2018-04-05 19:01:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:22 --> Config Class Initialized
INFO - 2018-04-05 19:01:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:22 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:22 --> URI Class Initialized
INFO - 2018-04-05 19:01:22 --> Router Class Initialized
INFO - 2018-04-05 19:01:22 --> Output Class Initialized
INFO - 2018-04-05 19:01:22 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:22 --> Input Class Initialized
INFO - 2018-04-05 19:01:22 --> Language Class Initialized
INFO - 2018-04-05 19:01:22 --> Loader Class Initialized
INFO - 2018-04-05 19:01:22 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:22 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:22 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:22 --> Model Class Initialized
INFO - 2018-04-05 19:01:22 --> Controller Class Initialized
INFO - 2018-04-05 19:01:22 --> Model Class Initialized
INFO - 2018-04-05 19:01:22 --> Model Class Initialized
INFO - 2018-04-05 19:01:22 --> Model Class Initialized
INFO - 2018-04-05 19:01:22 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:22 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:22 --> Total execution time: 0.1076
INFO - 2018-04-05 19:01:25 --> Config Class Initialized
INFO - 2018-04-05 19:01:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:25 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:25 --> URI Class Initialized
INFO - 2018-04-05 19:01:25 --> Router Class Initialized
INFO - 2018-04-05 19:01:25 --> Output Class Initialized
INFO - 2018-04-05 19:01:25 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:25 --> Input Class Initialized
INFO - 2018-04-05 19:01:25 --> Language Class Initialized
INFO - 2018-04-05 19:01:25 --> Loader Class Initialized
INFO - 2018-04-05 19:01:25 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:25 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:25 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Controller Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:25 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:25 --> Total execution time: 0.1003
INFO - 2018-04-05 19:01:25 --> Config Class Initialized
INFO - 2018-04-05 19:01:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:25 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:25 --> URI Class Initialized
INFO - 2018-04-05 19:01:25 --> Router Class Initialized
INFO - 2018-04-05 19:01:25 --> Output Class Initialized
INFO - 2018-04-05 19:01:25 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:25 --> Input Class Initialized
INFO - 2018-04-05 19:01:25 --> Language Class Initialized
INFO - 2018-04-05 19:01:25 --> Loader Class Initialized
INFO - 2018-04-05 19:01:25 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:25 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:25 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Controller Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
INFO - 2018-04-05 19:01:25 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:27 --> Config Class Initialized
INFO - 2018-04-05 19:01:27 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:27 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:27 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:27 --> URI Class Initialized
INFO - 2018-04-05 19:01:27 --> Router Class Initialized
INFO - 2018-04-05 19:01:27 --> Output Class Initialized
INFO - 2018-04-05 19:01:27 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:27 --> Input Class Initialized
INFO - 2018-04-05 19:01:27 --> Language Class Initialized
INFO - 2018-04-05 19:01:27 --> Loader Class Initialized
INFO - 2018-04-05 19:01:27 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:27 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:27 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Controller Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:27 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:27 --> Total execution time: 0.1162
INFO - 2018-04-05 19:01:27 --> Config Class Initialized
INFO - 2018-04-05 19:01:27 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:27 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:27 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:27 --> URI Class Initialized
INFO - 2018-04-05 19:01:27 --> Router Class Initialized
INFO - 2018-04-05 19:01:27 --> Output Class Initialized
INFO - 2018-04-05 19:01:27 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:27 --> Input Class Initialized
INFO - 2018-04-05 19:01:27 --> Language Class Initialized
INFO - 2018-04-05 19:01:27 --> Loader Class Initialized
INFO - 2018-04-05 19:01:27 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:27 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:27 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Controller Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
INFO - 2018-04-05 19:01:27 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:35 --> Config Class Initialized
INFO - 2018-04-05 19:01:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:35 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:35 --> URI Class Initialized
INFO - 2018-04-05 19:01:35 --> Router Class Initialized
INFO - 2018-04-05 19:01:35 --> Output Class Initialized
INFO - 2018-04-05 19:01:35 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:35 --> Input Class Initialized
INFO - 2018-04-05 19:01:35 --> Language Class Initialized
INFO - 2018-04-05 19:01:35 --> Loader Class Initialized
INFO - 2018-04-05 19:01:35 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:35 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:35 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
INFO - 2018-04-05 19:01:35 --> Controller Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:35 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:35 --> Total execution time: 0.0985
INFO - 2018-04-05 19:01:35 --> Config Class Initialized
INFO - 2018-04-05 19:01:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:35 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:35 --> URI Class Initialized
INFO - 2018-04-05 19:01:35 --> Router Class Initialized
INFO - 2018-04-05 19:01:35 --> Output Class Initialized
INFO - 2018-04-05 19:01:35 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:35 --> Input Class Initialized
INFO - 2018-04-05 19:01:35 --> Language Class Initialized
INFO - 2018-04-05 19:01:35 --> Loader Class Initialized
INFO - 2018-04-05 19:01:35 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:35 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:35 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
INFO - 2018-04-05 19:01:35 --> Controller Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
INFO - 2018-04-05 19:01:35 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:38 --> Config Class Initialized
INFO - 2018-04-05 19:01:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:38 --> URI Class Initialized
INFO - 2018-04-05 19:01:38 --> Router Class Initialized
INFO - 2018-04-05 19:01:38 --> Output Class Initialized
INFO - 2018-04-05 19:01:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:38 --> Input Class Initialized
INFO - 2018-04-05 19:01:38 --> Language Class Initialized
INFO - 2018-04-05 19:01:38 --> Loader Class Initialized
INFO - 2018-04-05 19:01:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:38 --> Model Class Initialized
INFO - 2018-04-05 19:01:38 --> Controller Class Initialized
INFO - 2018-04-05 19:01:38 --> Model Class Initialized
INFO - 2018-04-05 19:01:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:38 --> Model Class Initialized
INFO - 2018-04-05 19:01:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:38 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:38 --> Total execution time: 0.1087
INFO - 2018-04-05 19:01:52 --> Config Class Initialized
INFO - 2018-04-05 19:01:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:52 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:52 --> URI Class Initialized
INFO - 2018-04-05 19:01:52 --> Router Class Initialized
INFO - 2018-04-05 19:01:52 --> Output Class Initialized
INFO - 2018-04-05 19:01:52 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:52 --> Input Class Initialized
INFO - 2018-04-05 19:01:52 --> Language Class Initialized
INFO - 2018-04-05 19:01:52 --> Loader Class Initialized
INFO - 2018-04-05 19:01:52 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:52 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:52 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:52 --> Model Class Initialized
INFO - 2018-04-05 19:01:52 --> Controller Class Initialized
INFO - 2018-04-05 19:01:52 --> Model Class Initialized
INFO - 2018-04-05 19:01:52 --> Model Class Initialized
INFO - 2018-04-05 19:01:52 --> Model Class Initialized
INFO - 2018-04-05 19:01:52 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:52 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:52 --> Total execution time: 0.0903
INFO - 2018-04-05 19:01:57 --> Config Class Initialized
INFO - 2018-04-05 19:01:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:57 --> URI Class Initialized
INFO - 2018-04-05 19:01:57 --> Router Class Initialized
INFO - 2018-04-05 19:01:57 --> Output Class Initialized
INFO - 2018-04-05 19:01:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:57 --> Input Class Initialized
INFO - 2018-04-05 19:01:57 --> Language Class Initialized
INFO - 2018-04-05 19:01:57 --> Loader Class Initialized
INFO - 2018-04-05 19:01:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Controller Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:01:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:01:57 --> Final output sent to browser
DEBUG - 2018-04-05 19:01:57 --> Total execution time: 0.1033
INFO - 2018-04-05 19:01:57 --> Config Class Initialized
INFO - 2018-04-05 19:01:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:01:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:01:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:01:57 --> URI Class Initialized
INFO - 2018-04-05 19:01:57 --> Router Class Initialized
INFO - 2018-04-05 19:01:57 --> Output Class Initialized
INFO - 2018-04-05 19:01:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:01:57 --> Input Class Initialized
INFO - 2018-04-05 19:01:57 --> Language Class Initialized
INFO - 2018-04-05 19:01:57 --> Loader Class Initialized
INFO - 2018-04-05 19:01:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:01:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:01:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:01:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Controller Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
INFO - 2018-04-05 19:01:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:01:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:02:33 --> Config Class Initialized
INFO - 2018-04-05 19:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:02:33 --> Utf8 Class Initialized
INFO - 2018-04-05 19:02:33 --> URI Class Initialized
INFO - 2018-04-05 19:02:33 --> Router Class Initialized
INFO - 2018-04-05 19:02:33 --> Output Class Initialized
INFO - 2018-04-05 19:02:33 --> Security Class Initialized
DEBUG - 2018-04-05 19:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:02:33 --> Input Class Initialized
INFO - 2018-04-05 19:02:33 --> Language Class Initialized
INFO - 2018-04-05 19:02:33 --> Loader Class Initialized
INFO - 2018-04-05 19:02:33 --> Helper loaded: url_helper
INFO - 2018-04-05 19:02:33 --> Helper loaded: form_helper
INFO - 2018-04-05 19:02:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:02:33 --> Form Validation Class Initialized
INFO - 2018-04-05 19:02:33 --> Model Class Initialized
INFO - 2018-04-05 19:02:33 --> Controller Class Initialized
INFO - 2018-04-05 19:02:33 --> Model Class Initialized
INFO - 2018-04-05 19:02:33 --> Model Class Initialized
INFO - 2018-04-05 19:02:33 --> Model Class Initialized
INFO - 2018-04-05 19:02:33 --> Model Class Initialized
DEBUG - 2018-04-05 19:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:02:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:02:33 --> Final output sent to browser
DEBUG - 2018-04-05 19:02:33 --> Total execution time: 0.1156
INFO - 2018-04-05 19:02:35 --> Config Class Initialized
INFO - 2018-04-05 19:02:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:02:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:02:35 --> Utf8 Class Initialized
INFO - 2018-04-05 19:02:35 --> URI Class Initialized
INFO - 2018-04-05 19:02:35 --> Router Class Initialized
INFO - 2018-04-05 19:02:35 --> Output Class Initialized
INFO - 2018-04-05 19:02:35 --> Security Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:02:35 --> Input Class Initialized
INFO - 2018-04-05 19:02:35 --> Language Class Initialized
INFO - 2018-04-05 19:02:35 --> Loader Class Initialized
INFO - 2018-04-05 19:02:35 --> Helper loaded: url_helper
INFO - 2018-04-05 19:02:35 --> Helper loaded: form_helper
INFO - 2018-04-05 19:02:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:02:35 --> Form Validation Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Controller Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:02:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:02:35 --> Final output sent to browser
DEBUG - 2018-04-05 19:02:35 --> Total execution time: 0.1053
INFO - 2018-04-05 19:02:35 --> Config Class Initialized
INFO - 2018-04-05 19:02:35 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:02:35 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:02:35 --> Utf8 Class Initialized
INFO - 2018-04-05 19:02:35 --> URI Class Initialized
INFO - 2018-04-05 19:02:35 --> Router Class Initialized
INFO - 2018-04-05 19:02:35 --> Output Class Initialized
INFO - 2018-04-05 19:02:35 --> Security Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:02:35 --> Input Class Initialized
INFO - 2018-04-05 19:02:35 --> Language Class Initialized
INFO - 2018-04-05 19:02:35 --> Loader Class Initialized
INFO - 2018-04-05 19:02:35 --> Helper loaded: url_helper
INFO - 2018-04-05 19:02:35 --> Helper loaded: form_helper
INFO - 2018-04-05 19:02:35 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:02:35 --> Form Validation Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Controller Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
INFO - 2018-04-05 19:02:35 --> Model Class Initialized
DEBUG - 2018-04-05 19:02:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:02:37 --> Config Class Initialized
INFO - 2018-04-05 19:02:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:02:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:02:37 --> Utf8 Class Initialized
INFO - 2018-04-05 19:02:37 --> URI Class Initialized
INFO - 2018-04-05 19:02:37 --> Router Class Initialized
INFO - 2018-04-05 19:02:37 --> Output Class Initialized
INFO - 2018-04-05 19:02:37 --> Security Class Initialized
DEBUG - 2018-04-05 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:02:37 --> Input Class Initialized
INFO - 2018-04-05 19:02:37 --> Language Class Initialized
INFO - 2018-04-05 19:02:37 --> Loader Class Initialized
INFO - 2018-04-05 19:02:37 --> Helper loaded: url_helper
INFO - 2018-04-05 19:02:37 --> Helper loaded: form_helper
INFO - 2018-04-05 19:02:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:02:37 --> Form Validation Class Initialized
INFO - 2018-04-05 19:02:37 --> Model Class Initialized
INFO - 2018-04-05 19:02:37 --> Controller Class Initialized
INFO - 2018-04-05 19:02:37 --> Model Class Initialized
INFO - 2018-04-05 19:02:37 --> Model Class Initialized
INFO - 2018-04-05 19:02:37 --> Model Class Initialized
INFO - 2018-04-05 19:02:37 --> Model Class Initialized
DEBUG - 2018-04-05 19:02:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:02:38 --> Final output sent to browser
DEBUG - 2018-04-05 19:02:38 --> Total execution time: 0.8151
INFO - 2018-04-05 19:03:14 --> Config Class Initialized
INFO - 2018-04-05 19:03:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:03:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:03:14 --> Utf8 Class Initialized
INFO - 2018-04-05 19:03:14 --> URI Class Initialized
INFO - 2018-04-05 19:03:14 --> Router Class Initialized
INFO - 2018-04-05 19:03:14 --> Output Class Initialized
INFO - 2018-04-05 19:03:14 --> Security Class Initialized
DEBUG - 2018-04-05 19:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:03:14 --> Input Class Initialized
INFO - 2018-04-05 19:03:14 --> Language Class Initialized
INFO - 2018-04-05 19:03:14 --> Loader Class Initialized
INFO - 2018-04-05 19:03:14 --> Helper loaded: url_helper
INFO - 2018-04-05 19:03:14 --> Helper loaded: form_helper
INFO - 2018-04-05 19:03:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:03:14 --> Form Validation Class Initialized
INFO - 2018-04-05 19:03:14 --> Model Class Initialized
INFO - 2018-04-05 19:03:14 --> Controller Class Initialized
INFO - 2018-04-05 19:03:14 --> Model Class Initialized
INFO - 2018-04-05 19:03:14 --> Model Class Initialized
INFO - 2018-04-05 19:03:14 --> Model Class Initialized
INFO - 2018-04-05 19:03:14 --> Model Class Initialized
DEBUG - 2018-04-05 19:03:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:03:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:03:14 --> Final output sent to browser
DEBUG - 2018-04-05 19:03:14 --> Total execution time: 0.1055
INFO - 2018-04-05 19:03:17 --> Config Class Initialized
INFO - 2018-04-05 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:03:17 --> Utf8 Class Initialized
INFO - 2018-04-05 19:03:17 --> URI Class Initialized
INFO - 2018-04-05 19:03:17 --> Router Class Initialized
INFO - 2018-04-05 19:03:17 --> Output Class Initialized
INFO - 2018-04-05 19:03:17 --> Security Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:03:17 --> Input Class Initialized
INFO - 2018-04-05 19:03:17 --> Language Class Initialized
INFO - 2018-04-05 19:03:17 --> Loader Class Initialized
INFO - 2018-04-05 19:03:17 --> Helper loaded: url_helper
INFO - 2018-04-05 19:03:17 --> Helper loaded: form_helper
INFO - 2018-04-05 19:03:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:03:17 --> Form Validation Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Controller Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:03:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:03:17 --> Final output sent to browser
DEBUG - 2018-04-05 19:03:17 --> Total execution time: 0.1206
INFO - 2018-04-05 19:03:17 --> Config Class Initialized
INFO - 2018-04-05 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:03:17 --> Utf8 Class Initialized
INFO - 2018-04-05 19:03:17 --> URI Class Initialized
INFO - 2018-04-05 19:03:17 --> Router Class Initialized
INFO - 2018-04-05 19:03:17 --> Output Class Initialized
INFO - 2018-04-05 19:03:17 --> Security Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:03:17 --> Input Class Initialized
INFO - 2018-04-05 19:03:17 --> Language Class Initialized
INFO - 2018-04-05 19:03:17 --> Loader Class Initialized
INFO - 2018-04-05 19:03:17 --> Helper loaded: url_helper
INFO - 2018-04-05 19:03:17 --> Helper loaded: form_helper
INFO - 2018-04-05 19:03:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:03:17 --> Form Validation Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Controller Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
INFO - 2018-04-05 19:03:17 --> Model Class Initialized
DEBUG - 2018-04-05 19:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:04:43 --> Config Class Initialized
INFO - 2018-04-05 19:04:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:04:43 --> Utf8 Class Initialized
INFO - 2018-04-05 19:04:43 --> URI Class Initialized
INFO - 2018-04-05 19:04:43 --> Router Class Initialized
INFO - 2018-04-05 19:04:43 --> Output Class Initialized
INFO - 2018-04-05 19:04:43 --> Security Class Initialized
DEBUG - 2018-04-05 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:04:43 --> Input Class Initialized
INFO - 2018-04-05 19:04:43 --> Language Class Initialized
INFO - 2018-04-05 19:04:43 --> Loader Class Initialized
INFO - 2018-04-05 19:04:43 --> Helper loaded: url_helper
INFO - 2018-04-05 19:04:43 --> Helper loaded: form_helper
INFO - 2018-04-05 19:04:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:04:43 --> Form Validation Class Initialized
INFO - 2018-04-05 19:04:43 --> Model Class Initialized
INFO - 2018-04-05 19:04:43 --> Controller Class Initialized
INFO - 2018-04-05 19:04:43 --> Model Class Initialized
INFO - 2018-04-05 19:04:43 --> Model Class Initialized
INFO - 2018-04-05 19:04:43 --> Model Class Initialized
INFO - 2018-04-05 19:04:43 --> Model Class Initialized
DEBUG - 2018-04-05 19:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:04:47 --> Config Class Initialized
INFO - 2018-04-05 19:04:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:04:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:04:47 --> Utf8 Class Initialized
INFO - 2018-04-05 19:04:47 --> URI Class Initialized
INFO - 2018-04-05 19:04:47 --> Router Class Initialized
INFO - 2018-04-05 19:04:47 --> Output Class Initialized
INFO - 2018-04-05 19:04:47 --> Security Class Initialized
DEBUG - 2018-04-05 19:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:04:47 --> Input Class Initialized
INFO - 2018-04-05 19:04:47 --> Language Class Initialized
INFO - 2018-04-05 19:04:48 --> Loader Class Initialized
INFO - 2018-04-05 19:04:48 --> Helper loaded: url_helper
INFO - 2018-04-05 19:04:48 --> Helper loaded: form_helper
INFO - 2018-04-05 19:04:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:04:48 --> Form Validation Class Initialized
INFO - 2018-04-05 19:04:48 --> Model Class Initialized
INFO - 2018-04-05 19:04:48 --> Controller Class Initialized
INFO - 2018-04-05 19:04:48 --> Model Class Initialized
INFO - 2018-04-05 19:04:48 --> Model Class Initialized
INFO - 2018-04-05 19:04:48 --> Model Class Initialized
INFO - 2018-04-05 19:04:48 --> Model Class Initialized
DEBUG - 2018-04-05 19:04:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:04:48 --> Final output sent to browser
DEBUG - 2018-04-05 19:04:48 --> Total execution time: 0.1851
INFO - 2018-04-05 19:05:24 --> Config Class Initialized
INFO - 2018-04-05 19:05:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:05:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:05:24 --> Utf8 Class Initialized
INFO - 2018-04-05 19:05:24 --> URI Class Initialized
INFO - 2018-04-05 19:05:24 --> Router Class Initialized
INFO - 2018-04-05 19:05:24 --> Output Class Initialized
INFO - 2018-04-05 19:05:24 --> Security Class Initialized
DEBUG - 2018-04-05 19:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:05:24 --> Input Class Initialized
INFO - 2018-04-05 19:05:24 --> Language Class Initialized
INFO - 2018-04-05 19:05:24 --> Loader Class Initialized
INFO - 2018-04-05 19:05:24 --> Helper loaded: url_helper
INFO - 2018-04-05 19:05:24 --> Helper loaded: form_helper
INFO - 2018-04-05 19:05:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:05:24 --> Form Validation Class Initialized
INFO - 2018-04-05 19:05:24 --> Model Class Initialized
INFO - 2018-04-05 19:05:24 --> Controller Class Initialized
INFO - 2018-04-05 19:05:24 --> Model Class Initialized
INFO - 2018-04-05 19:05:24 --> Model Class Initialized
INFO - 2018-04-05 19:05:24 --> Model Class Initialized
INFO - 2018-04-05 19:05:24 --> Model Class Initialized
DEBUG - 2018-04-05 19:05:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:05:28 --> Config Class Initialized
INFO - 2018-04-05 19:05:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:05:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:05:28 --> Utf8 Class Initialized
INFO - 2018-04-05 19:05:28 --> URI Class Initialized
INFO - 2018-04-05 19:05:28 --> Router Class Initialized
INFO - 2018-04-05 19:05:28 --> Output Class Initialized
INFO - 2018-04-05 19:05:28 --> Security Class Initialized
DEBUG - 2018-04-05 19:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:05:28 --> Input Class Initialized
INFO - 2018-04-05 19:05:28 --> Language Class Initialized
INFO - 2018-04-05 19:05:28 --> Loader Class Initialized
INFO - 2018-04-05 19:05:28 --> Helper loaded: url_helper
INFO - 2018-04-05 19:05:28 --> Helper loaded: form_helper
INFO - 2018-04-05 19:05:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:05:28 --> Form Validation Class Initialized
INFO - 2018-04-05 19:05:28 --> Model Class Initialized
INFO - 2018-04-05 19:05:28 --> Controller Class Initialized
INFO - 2018-04-05 19:05:28 --> Model Class Initialized
INFO - 2018-04-05 19:05:28 --> Model Class Initialized
INFO - 2018-04-05 19:05:28 --> Model Class Initialized
INFO - 2018-04-05 19:05:28 --> Model Class Initialized
DEBUG - 2018-04-05 19:05:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:05:28 --> Final output sent to browser
DEBUG - 2018-04-05 19:05:28 --> Total execution time: 0.2105
INFO - 2018-04-05 19:05:38 --> Config Class Initialized
INFO - 2018-04-05 19:05:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:05:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:05:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:05:38 --> URI Class Initialized
INFO - 2018-04-05 19:05:38 --> Router Class Initialized
INFO - 2018-04-05 19:05:38 --> Output Class Initialized
INFO - 2018-04-05 19:05:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:05:38 --> Input Class Initialized
INFO - 2018-04-05 19:05:38 --> Language Class Initialized
INFO - 2018-04-05 19:05:38 --> Loader Class Initialized
INFO - 2018-04-05 19:05:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:05:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:05:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:05:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:05:38 --> Model Class Initialized
INFO - 2018-04-05 19:05:38 --> Controller Class Initialized
INFO - 2018-04-05 19:05:38 --> Model Class Initialized
INFO - 2018-04-05 19:05:38 --> Model Class Initialized
INFO - 2018-04-05 19:05:38 --> Model Class Initialized
INFO - 2018-04-05 19:05:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:05:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:05:38 --> Final output sent to browser
DEBUG - 2018-04-05 19:05:38 --> Total execution time: 0.2455
INFO - 2018-04-05 19:06:10 --> Config Class Initialized
INFO - 2018-04-05 19:06:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:10 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:10 --> URI Class Initialized
INFO - 2018-04-05 19:06:10 --> Router Class Initialized
INFO - 2018-04-05 19:06:10 --> Output Class Initialized
INFO - 2018-04-05 19:06:10 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:10 --> Input Class Initialized
INFO - 2018-04-05 19:06:10 --> Language Class Initialized
INFO - 2018-04-05 19:06:10 --> Loader Class Initialized
INFO - 2018-04-05 19:06:10 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:10 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:10 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:10 --> Model Class Initialized
INFO - 2018-04-05 19:06:10 --> Controller Class Initialized
INFO - 2018-04-05 19:06:10 --> Model Class Initialized
INFO - 2018-04-05 19:06:10 --> Model Class Initialized
INFO - 2018-04-05 19:06:10 --> Model Class Initialized
INFO - 2018-04-05 19:06:10 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:13 --> Config Class Initialized
INFO - 2018-04-05 19:06:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:13 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:13 --> URI Class Initialized
INFO - 2018-04-05 19:06:13 --> Router Class Initialized
INFO - 2018-04-05 19:06:13 --> Output Class Initialized
INFO - 2018-04-05 19:06:13 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:13 --> Input Class Initialized
INFO - 2018-04-05 19:06:13 --> Language Class Initialized
INFO - 2018-04-05 19:06:13 --> Loader Class Initialized
INFO - 2018-04-05 19:06:13 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:13 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:13 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:13 --> Model Class Initialized
INFO - 2018-04-05 19:06:13 --> Controller Class Initialized
INFO - 2018-04-05 19:06:13 --> Model Class Initialized
INFO - 2018-04-05 19:06:13 --> Model Class Initialized
INFO - 2018-04-05 19:06:13 --> Model Class Initialized
INFO - 2018-04-05 19:06:13 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:14 --> Final output sent to browser
DEBUG - 2018-04-05 19:06:14 --> Total execution time: 0.3521
INFO - 2018-04-05 19:06:25 --> Config Class Initialized
INFO - 2018-04-05 19:06:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:25 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:25 --> URI Class Initialized
INFO - 2018-04-05 19:06:25 --> Router Class Initialized
INFO - 2018-04-05 19:06:25 --> Output Class Initialized
INFO - 2018-04-05 19:06:25 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:25 --> Input Class Initialized
INFO - 2018-04-05 19:06:25 --> Language Class Initialized
INFO - 2018-04-05 19:06:25 --> Loader Class Initialized
INFO - 2018-04-05 19:06:25 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:25 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:25 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:25 --> Model Class Initialized
INFO - 2018-04-05 19:06:25 --> Controller Class Initialized
INFO - 2018-04-05 19:06:25 --> Model Class Initialized
INFO - 2018-04-05 19:06:25 --> Model Class Initialized
INFO - 2018-04-05 19:06:25 --> Model Class Initialized
INFO - 2018-04-05 19:06:25 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:06:25 --> Final output sent to browser
DEBUG - 2018-04-05 19:06:25 --> Total execution time: 0.1263
INFO - 2018-04-05 19:06:30 --> Config Class Initialized
INFO - 2018-04-05 19:06:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:30 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:30 --> URI Class Initialized
INFO - 2018-04-05 19:06:30 --> Router Class Initialized
INFO - 2018-04-05 19:06:30 --> Output Class Initialized
INFO - 2018-04-05 19:06:30 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:30 --> Input Class Initialized
INFO - 2018-04-05 19:06:30 --> Language Class Initialized
INFO - 2018-04-05 19:06:30 --> Loader Class Initialized
INFO - 2018-04-05 19:06:30 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:30 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:30 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:30 --> Model Class Initialized
INFO - 2018-04-05 19:06:30 --> Controller Class Initialized
INFO - 2018-04-05 19:06:30 --> Model Class Initialized
INFO - 2018-04-05 19:06:30 --> Model Class Initialized
INFO - 2018-04-05 19:06:30 --> Model Class Initialized
INFO - 2018-04-05 19:06:30 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:06:30 --> Final output sent to browser
DEBUG - 2018-04-05 19:06:30 --> Total execution time: 0.1118
INFO - 2018-04-05 19:06:31 --> Config Class Initialized
INFO - 2018-04-05 19:06:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:31 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:31 --> URI Class Initialized
INFO - 2018-04-05 19:06:31 --> Router Class Initialized
INFO - 2018-04-05 19:06:31 --> Output Class Initialized
INFO - 2018-04-05 19:06:31 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:31 --> Input Class Initialized
INFO - 2018-04-05 19:06:31 --> Language Class Initialized
INFO - 2018-04-05 19:06:31 --> Loader Class Initialized
INFO - 2018-04-05 19:06:31 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:31 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:31 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:31 --> Model Class Initialized
INFO - 2018-04-05 19:06:31 --> Controller Class Initialized
INFO - 2018-04-05 19:06:31 --> Model Class Initialized
INFO - 2018-04-05 19:06:31 --> Model Class Initialized
INFO - 2018-04-05 19:06:31 --> Model Class Initialized
INFO - 2018-04-05 19:06:31 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:39 --> Config Class Initialized
INFO - 2018-04-05 19:06:39 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:06:39 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:06:39 --> Utf8 Class Initialized
INFO - 2018-04-05 19:06:39 --> URI Class Initialized
INFO - 2018-04-05 19:06:39 --> Router Class Initialized
INFO - 2018-04-05 19:06:39 --> Output Class Initialized
INFO - 2018-04-05 19:06:39 --> Security Class Initialized
DEBUG - 2018-04-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:06:39 --> Input Class Initialized
INFO - 2018-04-05 19:06:39 --> Language Class Initialized
INFO - 2018-04-05 19:06:39 --> Loader Class Initialized
INFO - 2018-04-05 19:06:39 --> Helper loaded: url_helper
INFO - 2018-04-05 19:06:39 --> Helper loaded: form_helper
INFO - 2018-04-05 19:06:39 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:06:39 --> Form Validation Class Initialized
INFO - 2018-04-05 19:06:39 --> Model Class Initialized
INFO - 2018-04-05 19:06:39 --> Controller Class Initialized
INFO - 2018-04-05 19:06:39 --> Model Class Initialized
INFO - 2018-04-05 19:06:39 --> Model Class Initialized
INFO - 2018-04-05 19:06:39 --> Model Class Initialized
INFO - 2018-04-05 19:06:39 --> Model Class Initialized
DEBUG - 2018-04-05 19:06:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:06:39 --> Final output sent to browser
DEBUG - 2018-04-05 19:06:39 --> Total execution time: 0.3409
INFO - 2018-04-05 19:07:34 --> Config Class Initialized
INFO - 2018-04-05 19:07:34 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:07:34 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:07:34 --> Utf8 Class Initialized
INFO - 2018-04-05 19:07:34 --> URI Class Initialized
INFO - 2018-04-05 19:07:34 --> Router Class Initialized
INFO - 2018-04-05 19:07:34 --> Output Class Initialized
INFO - 2018-04-05 19:07:34 --> Security Class Initialized
DEBUG - 2018-04-05 19:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:07:34 --> Input Class Initialized
INFO - 2018-04-05 19:07:34 --> Language Class Initialized
INFO - 2018-04-05 19:07:34 --> Loader Class Initialized
INFO - 2018-04-05 19:07:34 --> Helper loaded: url_helper
INFO - 2018-04-05 19:07:34 --> Helper loaded: form_helper
INFO - 2018-04-05 19:07:34 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:07:34 --> Form Validation Class Initialized
INFO - 2018-04-05 19:07:34 --> Model Class Initialized
INFO - 2018-04-05 19:07:34 --> Controller Class Initialized
INFO - 2018-04-05 19:07:34 --> Model Class Initialized
INFO - 2018-04-05 19:07:34 --> Model Class Initialized
INFO - 2018-04-05 19:07:34 --> Model Class Initialized
INFO - 2018-04-05 19:07:34 --> Model Class Initialized
DEBUG - 2018-04-05 19:07:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:07:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:07:34 --> Final output sent to browser
DEBUG - 2018-04-05 19:07:34 --> Total execution time: 0.1028
INFO - 2018-04-05 19:07:37 --> Config Class Initialized
INFO - 2018-04-05 19:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:07:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:07:37 --> Utf8 Class Initialized
INFO - 2018-04-05 19:07:37 --> URI Class Initialized
INFO - 2018-04-05 19:07:37 --> Router Class Initialized
INFO - 2018-04-05 19:07:37 --> Output Class Initialized
INFO - 2018-04-05 19:07:37 --> Security Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:07:37 --> Input Class Initialized
INFO - 2018-04-05 19:07:37 --> Language Class Initialized
INFO - 2018-04-05 19:07:37 --> Loader Class Initialized
INFO - 2018-04-05 19:07:37 --> Helper loaded: url_helper
INFO - 2018-04-05 19:07:37 --> Helper loaded: form_helper
INFO - 2018-04-05 19:07:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:07:37 --> Form Validation Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Controller Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:07:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:07:37 --> Final output sent to browser
DEBUG - 2018-04-05 19:07:37 --> Total execution time: 0.1298
INFO - 2018-04-05 19:07:37 --> Config Class Initialized
INFO - 2018-04-05 19:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:07:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:07:37 --> Utf8 Class Initialized
INFO - 2018-04-05 19:07:37 --> URI Class Initialized
INFO - 2018-04-05 19:07:37 --> Router Class Initialized
INFO - 2018-04-05 19:07:37 --> Output Class Initialized
INFO - 2018-04-05 19:07:37 --> Security Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:07:37 --> Input Class Initialized
INFO - 2018-04-05 19:07:37 --> Language Class Initialized
INFO - 2018-04-05 19:07:37 --> Loader Class Initialized
INFO - 2018-04-05 19:07:37 --> Helper loaded: url_helper
INFO - 2018-04-05 19:07:37 --> Helper loaded: form_helper
INFO - 2018-04-05 19:07:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:07:37 --> Form Validation Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Controller Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
INFO - 2018-04-05 19:07:37 --> Model Class Initialized
DEBUG - 2018-04-05 19:07:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:07:41 --> Config Class Initialized
INFO - 2018-04-05 19:07:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:07:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:07:41 --> Utf8 Class Initialized
INFO - 2018-04-05 19:07:41 --> URI Class Initialized
INFO - 2018-04-05 19:07:41 --> Router Class Initialized
INFO - 2018-04-05 19:07:41 --> Output Class Initialized
INFO - 2018-04-05 19:07:41 --> Security Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:07:41 --> Input Class Initialized
INFO - 2018-04-05 19:07:41 --> Language Class Initialized
INFO - 2018-04-05 19:07:41 --> Loader Class Initialized
INFO - 2018-04-05 19:07:41 --> Helper loaded: url_helper
INFO - 2018-04-05 19:07:41 --> Helper loaded: form_helper
INFO - 2018-04-05 19:07:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:07:41 --> Form Validation Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Controller Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:07:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:07:41 --> Final output sent to browser
DEBUG - 2018-04-05 19:07:41 --> Total execution time: 0.1364
INFO - 2018-04-05 19:07:41 --> Config Class Initialized
INFO - 2018-04-05 19:07:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:07:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:07:41 --> Utf8 Class Initialized
INFO - 2018-04-05 19:07:41 --> URI Class Initialized
INFO - 2018-04-05 19:07:41 --> Router Class Initialized
INFO - 2018-04-05 19:07:41 --> Output Class Initialized
INFO - 2018-04-05 19:07:41 --> Security Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:07:41 --> Input Class Initialized
INFO - 2018-04-05 19:07:41 --> Language Class Initialized
INFO - 2018-04-05 19:07:41 --> Loader Class Initialized
INFO - 2018-04-05 19:07:41 --> Helper loaded: url_helper
INFO - 2018-04-05 19:07:41 --> Helper loaded: form_helper
INFO - 2018-04-05 19:07:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:07:41 --> Form Validation Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Controller Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
INFO - 2018-04-05 19:07:41 --> Model Class Initialized
DEBUG - 2018-04-05 19:07:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:09:06 --> Config Class Initialized
INFO - 2018-04-05 19:09:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:09:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:09:06 --> Utf8 Class Initialized
INFO - 2018-04-05 19:09:06 --> URI Class Initialized
INFO - 2018-04-05 19:09:06 --> Router Class Initialized
INFO - 2018-04-05 19:09:06 --> Output Class Initialized
INFO - 2018-04-05 19:09:06 --> Security Class Initialized
DEBUG - 2018-04-05 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:09:06 --> Input Class Initialized
INFO - 2018-04-05 19:09:06 --> Language Class Initialized
INFO - 2018-04-05 19:09:06 --> Loader Class Initialized
INFO - 2018-04-05 19:09:06 --> Helper loaded: url_helper
INFO - 2018-04-05 19:09:06 --> Helper loaded: form_helper
INFO - 2018-04-05 19:09:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:09:06 --> Form Validation Class Initialized
INFO - 2018-04-05 19:09:06 --> Model Class Initialized
INFO - 2018-04-05 19:09:06 --> Controller Class Initialized
INFO - 2018-04-05 19:09:06 --> Model Class Initialized
INFO - 2018-04-05 19:09:06 --> Model Class Initialized
INFO - 2018-04-05 19:09:06 --> Model Class Initialized
INFO - 2018-04-05 19:09:06 --> Model Class Initialized
DEBUG - 2018-04-05 19:09:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:09:11 --> Config Class Initialized
INFO - 2018-04-05 19:09:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:09:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:09:11 --> Utf8 Class Initialized
INFO - 2018-04-05 19:09:11 --> URI Class Initialized
INFO - 2018-04-05 19:09:11 --> Router Class Initialized
INFO - 2018-04-05 19:09:11 --> Output Class Initialized
INFO - 2018-04-05 19:09:11 --> Security Class Initialized
DEBUG - 2018-04-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:09:11 --> Input Class Initialized
INFO - 2018-04-05 19:09:11 --> Language Class Initialized
INFO - 2018-04-05 19:09:11 --> Loader Class Initialized
INFO - 2018-04-05 19:09:11 --> Helper loaded: url_helper
INFO - 2018-04-05 19:09:11 --> Helper loaded: form_helper
INFO - 2018-04-05 19:09:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:09:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:09:11 --> Model Class Initialized
INFO - 2018-04-05 19:09:11 --> Controller Class Initialized
INFO - 2018-04-05 19:09:11 --> Model Class Initialized
INFO - 2018-04-05 19:09:11 --> Model Class Initialized
INFO - 2018-04-05 19:09:11 --> Model Class Initialized
INFO - 2018-04-05 19:09:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:09:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:09:15 --> Config Class Initialized
INFO - 2018-04-05 19:09:15 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:09:15 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:09:15 --> Utf8 Class Initialized
INFO - 2018-04-05 19:09:15 --> URI Class Initialized
INFO - 2018-04-05 19:09:15 --> Router Class Initialized
INFO - 2018-04-05 19:09:15 --> Output Class Initialized
INFO - 2018-04-05 19:09:15 --> Security Class Initialized
DEBUG - 2018-04-05 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:09:16 --> Input Class Initialized
INFO - 2018-04-05 19:09:16 --> Language Class Initialized
INFO - 2018-04-05 19:09:16 --> Loader Class Initialized
INFO - 2018-04-05 19:09:16 --> Helper loaded: url_helper
INFO - 2018-04-05 19:09:16 --> Helper loaded: form_helper
INFO - 2018-04-05 19:09:16 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:09:16 --> Form Validation Class Initialized
INFO - 2018-04-05 19:09:16 --> Model Class Initialized
INFO - 2018-04-05 19:09:16 --> Controller Class Initialized
INFO - 2018-04-05 19:09:16 --> Model Class Initialized
INFO - 2018-04-05 19:09:16 --> Model Class Initialized
INFO - 2018-04-05 19:09:16 --> Model Class Initialized
INFO - 2018-04-05 19:09:16 --> Model Class Initialized
DEBUG - 2018-04-05 19:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:09:47 --> Config Class Initialized
INFO - 2018-04-05 19:09:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:09:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:09:47 --> Utf8 Class Initialized
INFO - 2018-04-05 19:09:47 --> URI Class Initialized
INFO - 2018-04-05 19:09:47 --> Router Class Initialized
INFO - 2018-04-05 19:09:47 --> Output Class Initialized
INFO - 2018-04-05 19:09:47 --> Security Class Initialized
DEBUG - 2018-04-05 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:09:47 --> Input Class Initialized
INFO - 2018-04-05 19:09:47 --> Language Class Initialized
INFO - 2018-04-05 19:09:47 --> Loader Class Initialized
INFO - 2018-04-05 19:09:47 --> Helper loaded: url_helper
INFO - 2018-04-05 19:09:47 --> Helper loaded: form_helper
INFO - 2018-04-05 19:09:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:09:47 --> Form Validation Class Initialized
INFO - 2018-04-05 19:09:47 --> Model Class Initialized
INFO - 2018-04-05 19:09:47 --> Controller Class Initialized
INFO - 2018-04-05 19:09:47 --> Model Class Initialized
INFO - 2018-04-05 19:09:47 --> Model Class Initialized
INFO - 2018-04-05 19:09:47 --> Model Class Initialized
INFO - 2018-04-05 19:09:47 --> Model Class Initialized
DEBUG - 2018-04-05 19:09:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:10:03 --> Config Class Initialized
INFO - 2018-04-05 19:10:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:10:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:10:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:10:03 --> URI Class Initialized
INFO - 2018-04-05 19:10:03 --> Router Class Initialized
INFO - 2018-04-05 19:10:03 --> Output Class Initialized
INFO - 2018-04-05 19:10:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:10:03 --> Input Class Initialized
INFO - 2018-04-05 19:10:03 --> Language Class Initialized
INFO - 2018-04-05 19:10:03 --> Loader Class Initialized
INFO - 2018-04-05 19:10:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:10:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:10:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:10:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:10:03 --> Model Class Initialized
INFO - 2018-04-05 19:10:03 --> Controller Class Initialized
INFO - 2018-04-05 19:10:03 --> Model Class Initialized
INFO - 2018-04-05 19:10:03 --> Model Class Initialized
INFO - 2018-04-05 19:10:03 --> Model Class Initialized
INFO - 2018-04-05 19:10:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:12:04 --> Config Class Initialized
INFO - 2018-04-05 19:12:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:12:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:12:04 --> Utf8 Class Initialized
INFO - 2018-04-05 19:12:04 --> URI Class Initialized
INFO - 2018-04-05 19:12:04 --> Router Class Initialized
INFO - 2018-04-05 19:12:04 --> Output Class Initialized
INFO - 2018-04-05 19:12:04 --> Security Class Initialized
DEBUG - 2018-04-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:12:04 --> Input Class Initialized
INFO - 2018-04-05 19:12:04 --> Language Class Initialized
INFO - 2018-04-05 19:12:04 --> Loader Class Initialized
INFO - 2018-04-05 19:12:04 --> Helper loaded: url_helper
INFO - 2018-04-05 19:12:04 --> Helper loaded: form_helper
INFO - 2018-04-05 19:12:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:12:04 --> Form Validation Class Initialized
INFO - 2018-04-05 19:12:04 --> Model Class Initialized
INFO - 2018-04-05 19:12:04 --> Controller Class Initialized
INFO - 2018-04-05 19:12:04 --> Model Class Initialized
INFO - 2018-04-05 19:12:04 --> Model Class Initialized
INFO - 2018-04-05 19:12:04 --> Model Class Initialized
INFO - 2018-04-05 19:12:04 --> Model Class Initialized
DEBUG - 2018-04-05 19:12:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:12:07 --> Config Class Initialized
INFO - 2018-04-05 19:12:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:12:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:12:07 --> Utf8 Class Initialized
INFO - 2018-04-05 19:12:07 --> URI Class Initialized
INFO - 2018-04-05 19:12:07 --> Router Class Initialized
INFO - 2018-04-05 19:12:07 --> Output Class Initialized
INFO - 2018-04-05 19:12:07 --> Security Class Initialized
DEBUG - 2018-04-05 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:12:07 --> Input Class Initialized
INFO - 2018-04-05 19:12:07 --> Language Class Initialized
INFO - 2018-04-05 19:12:07 --> Loader Class Initialized
INFO - 2018-04-05 19:12:07 --> Helper loaded: url_helper
INFO - 2018-04-05 19:12:07 --> Helper loaded: form_helper
INFO - 2018-04-05 19:12:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:12:07 --> Form Validation Class Initialized
INFO - 2018-04-05 19:12:07 --> Model Class Initialized
INFO - 2018-04-05 19:12:07 --> Controller Class Initialized
INFO - 2018-04-05 19:12:07 --> Model Class Initialized
INFO - 2018-04-05 19:12:07 --> Model Class Initialized
INFO - 2018-04-05 19:12:07 --> Model Class Initialized
INFO - 2018-04-05 19:12:07 --> Model Class Initialized
DEBUG - 2018-04-05 19:12:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:12:10 --> Config Class Initialized
INFO - 2018-04-05 19:12:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:12:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:12:10 --> Utf8 Class Initialized
INFO - 2018-04-05 19:12:10 --> URI Class Initialized
INFO - 2018-04-05 19:12:10 --> Router Class Initialized
INFO - 2018-04-05 19:12:10 --> Output Class Initialized
INFO - 2018-04-05 19:12:10 --> Security Class Initialized
DEBUG - 2018-04-05 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:12:10 --> Input Class Initialized
INFO - 2018-04-05 19:12:10 --> Language Class Initialized
INFO - 2018-04-05 19:12:10 --> Loader Class Initialized
INFO - 2018-04-05 19:12:10 --> Helper loaded: url_helper
INFO - 2018-04-05 19:12:10 --> Helper loaded: form_helper
INFO - 2018-04-05 19:12:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:12:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:12:11 --> Model Class Initialized
INFO - 2018-04-05 19:12:11 --> Controller Class Initialized
INFO - 2018-04-05 19:12:11 --> Model Class Initialized
INFO - 2018-04-05 19:12:11 --> Model Class Initialized
INFO - 2018-04-05 19:12:11 --> Model Class Initialized
INFO - 2018-04-05 19:12:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:12:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:12:47 --> Config Class Initialized
INFO - 2018-04-05 19:12:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:12:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:12:47 --> Utf8 Class Initialized
INFO - 2018-04-05 19:12:47 --> URI Class Initialized
INFO - 2018-04-05 19:12:47 --> Router Class Initialized
INFO - 2018-04-05 19:12:47 --> Output Class Initialized
INFO - 2018-04-05 19:12:47 --> Security Class Initialized
DEBUG - 2018-04-05 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:12:47 --> Input Class Initialized
INFO - 2018-04-05 19:12:47 --> Language Class Initialized
INFO - 2018-04-05 19:12:47 --> Loader Class Initialized
INFO - 2018-04-05 19:12:47 --> Helper loaded: url_helper
INFO - 2018-04-05 19:12:47 --> Helper loaded: form_helper
INFO - 2018-04-05 19:12:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:12:47 --> Form Validation Class Initialized
INFO - 2018-04-05 19:12:47 --> Model Class Initialized
INFO - 2018-04-05 19:12:47 --> Controller Class Initialized
INFO - 2018-04-05 19:12:47 --> Model Class Initialized
INFO - 2018-04-05 19:12:47 --> Model Class Initialized
INFO - 2018-04-05 19:12:47 --> Model Class Initialized
INFO - 2018-04-05 19:12:47 --> Model Class Initialized
DEBUG - 2018-04-05 19:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:12:48 --> Config Class Initialized
INFO - 2018-04-05 19:12:48 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:12:48 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:12:48 --> Utf8 Class Initialized
INFO - 2018-04-05 19:12:48 --> URI Class Initialized
INFO - 2018-04-05 19:12:48 --> Router Class Initialized
INFO - 2018-04-05 19:12:48 --> Output Class Initialized
INFO - 2018-04-05 19:12:48 --> Security Class Initialized
DEBUG - 2018-04-05 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:12:48 --> Input Class Initialized
INFO - 2018-04-05 19:12:48 --> Language Class Initialized
INFO - 2018-04-05 19:12:48 --> Loader Class Initialized
INFO - 2018-04-05 19:12:48 --> Helper loaded: url_helper
INFO - 2018-04-05 19:12:48 --> Helper loaded: form_helper
INFO - 2018-04-05 19:12:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:12:48 --> Form Validation Class Initialized
INFO - 2018-04-05 19:12:48 --> Model Class Initialized
INFO - 2018-04-05 19:12:48 --> Controller Class Initialized
INFO - 2018-04-05 19:12:48 --> Model Class Initialized
INFO - 2018-04-05 19:12:48 --> Model Class Initialized
INFO - 2018-04-05 19:12:48 --> Model Class Initialized
INFO - 2018-04-05 19:12:48 --> Model Class Initialized
DEBUG - 2018-04-05 19:12:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:13:38 --> Config Class Initialized
INFO - 2018-04-05 19:13:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:13:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:13:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:13:38 --> URI Class Initialized
INFO - 2018-04-05 19:13:38 --> Router Class Initialized
INFO - 2018-04-05 19:13:38 --> Output Class Initialized
INFO - 2018-04-05 19:13:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:13:38 --> Input Class Initialized
INFO - 2018-04-05 19:13:38 --> Language Class Initialized
INFO - 2018-04-05 19:13:38 --> Loader Class Initialized
INFO - 2018-04-05 19:13:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:13:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:13:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:13:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:13:38 --> Model Class Initialized
INFO - 2018-04-05 19:13:38 --> Controller Class Initialized
INFO - 2018-04-05 19:13:38 --> Model Class Initialized
INFO - 2018-04-05 19:13:38 --> Model Class Initialized
INFO - 2018-04-05 19:13:38 --> Model Class Initialized
INFO - 2018-04-05 19:13:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:13:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:13:39 --> Final output sent to browser
DEBUG - 2018-04-05 19:13:39 --> Total execution time: 0.1916
INFO - 2018-04-05 19:14:08 --> Config Class Initialized
INFO - 2018-04-05 19:14:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:14:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:14:08 --> Utf8 Class Initialized
INFO - 2018-04-05 19:14:08 --> URI Class Initialized
INFO - 2018-04-05 19:14:08 --> Router Class Initialized
INFO - 2018-04-05 19:14:08 --> Output Class Initialized
INFO - 2018-04-05 19:14:08 --> Security Class Initialized
DEBUG - 2018-04-05 19:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:14:08 --> Input Class Initialized
INFO - 2018-04-05 19:14:08 --> Language Class Initialized
INFO - 2018-04-05 19:14:08 --> Loader Class Initialized
INFO - 2018-04-05 19:14:08 --> Helper loaded: url_helper
INFO - 2018-04-05 19:14:08 --> Helper loaded: form_helper
INFO - 2018-04-05 19:14:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:14:08 --> Form Validation Class Initialized
INFO - 2018-04-05 19:14:08 --> Model Class Initialized
INFO - 2018-04-05 19:14:08 --> Controller Class Initialized
INFO - 2018-04-05 19:14:08 --> Model Class Initialized
INFO - 2018-04-05 19:14:08 --> Model Class Initialized
INFO - 2018-04-05 19:14:08 --> Model Class Initialized
INFO - 2018-04-05 19:14:08 --> Model Class Initialized
DEBUG - 2018-04-05 19:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:14:10 --> Config Class Initialized
INFO - 2018-04-05 19:14:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:14:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:14:10 --> Utf8 Class Initialized
INFO - 2018-04-05 19:14:10 --> URI Class Initialized
INFO - 2018-04-05 19:14:10 --> Router Class Initialized
INFO - 2018-04-05 19:14:10 --> Output Class Initialized
INFO - 2018-04-05 19:14:10 --> Security Class Initialized
DEBUG - 2018-04-05 19:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:14:10 --> Input Class Initialized
INFO - 2018-04-05 19:14:10 --> Language Class Initialized
INFO - 2018-04-05 19:14:10 --> Loader Class Initialized
INFO - 2018-04-05 19:14:10 --> Helper loaded: url_helper
INFO - 2018-04-05 19:14:10 --> Helper loaded: form_helper
INFO - 2018-04-05 19:14:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:14:10 --> Form Validation Class Initialized
INFO - 2018-04-05 19:14:10 --> Model Class Initialized
INFO - 2018-04-05 19:14:10 --> Controller Class Initialized
INFO - 2018-04-05 19:14:10 --> Model Class Initialized
INFO - 2018-04-05 19:14:10 --> Model Class Initialized
INFO - 2018-04-05 19:14:10 --> Model Class Initialized
INFO - 2018-04-05 19:14:10 --> Model Class Initialized
DEBUG - 2018-04-05 19:14:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:14:10 --> Final output sent to browser
DEBUG - 2018-04-05 19:14:10 --> Total execution time: 0.2484
INFO - 2018-04-05 19:18:49 --> Config Class Initialized
INFO - 2018-04-05 19:18:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:18:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:18:50 --> Utf8 Class Initialized
INFO - 2018-04-05 19:18:50 --> URI Class Initialized
INFO - 2018-04-05 19:18:50 --> Router Class Initialized
INFO - 2018-04-05 19:18:50 --> Output Class Initialized
INFO - 2018-04-05 19:18:50 --> Security Class Initialized
DEBUG - 2018-04-05 19:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:18:50 --> Input Class Initialized
INFO - 2018-04-05 19:18:50 --> Language Class Initialized
INFO - 2018-04-05 19:18:50 --> Loader Class Initialized
INFO - 2018-04-05 19:18:50 --> Helper loaded: url_helper
INFO - 2018-04-05 19:18:50 --> Helper loaded: form_helper
INFO - 2018-04-05 19:18:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:18:51 --> Form Validation Class Initialized
INFO - 2018-04-05 19:18:51 --> Model Class Initialized
INFO - 2018-04-05 19:18:51 --> Controller Class Initialized
INFO - 2018-04-05 19:18:51 --> Model Class Initialized
INFO - 2018-04-05 19:18:51 --> Model Class Initialized
INFO - 2018-04-05 19:18:51 --> Model Class Initialized
INFO - 2018-04-05 19:18:51 --> Model Class Initialized
DEBUG - 2018-04-05 19:18:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:18:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:18:52 --> Final output sent to browser
DEBUG - 2018-04-05 19:18:52 --> Total execution time: 2.3848
INFO - 2018-04-05 19:18:52 --> Config Class Initialized
INFO - 2018-04-05 19:18:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:18:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:18:52 --> Utf8 Class Initialized
INFO - 2018-04-05 19:18:52 --> URI Class Initialized
INFO - 2018-04-05 19:18:52 --> Router Class Initialized
INFO - 2018-04-05 19:18:52 --> Output Class Initialized
INFO - 2018-04-05 19:18:52 --> Security Class Initialized
DEBUG - 2018-04-05 19:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:18:52 --> Input Class Initialized
INFO - 2018-04-05 19:18:52 --> Language Class Initialized
INFO - 2018-04-05 19:18:52 --> Loader Class Initialized
INFO - 2018-04-05 19:18:52 --> Helper loaded: url_helper
INFO - 2018-04-05 19:18:52 --> Helper loaded: form_helper
INFO - 2018-04-05 19:18:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:18:52 --> Form Validation Class Initialized
INFO - 2018-04-05 19:18:52 --> Model Class Initialized
INFO - 2018-04-05 19:18:52 --> Controller Class Initialized
INFO - 2018-04-05 19:18:52 --> Model Class Initialized
INFO - 2018-04-05 19:18:52 --> Model Class Initialized
INFO - 2018-04-05 19:18:52 --> Model Class Initialized
INFO - 2018-04-05 19:18:52 --> Model Class Initialized
DEBUG - 2018-04-05 19:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:19:46 --> Config Class Initialized
INFO - 2018-04-05 19:19:46 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:19:46 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:19:46 --> Utf8 Class Initialized
INFO - 2018-04-05 19:19:46 --> URI Class Initialized
INFO - 2018-04-05 19:19:46 --> Router Class Initialized
INFO - 2018-04-05 19:19:46 --> Output Class Initialized
INFO - 2018-04-05 19:19:46 --> Security Class Initialized
DEBUG - 2018-04-05 19:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:19:46 --> Input Class Initialized
INFO - 2018-04-05 19:19:46 --> Language Class Initialized
INFO - 2018-04-05 19:19:46 --> Loader Class Initialized
INFO - 2018-04-05 19:19:46 --> Helper loaded: url_helper
INFO - 2018-04-05 19:19:46 --> Helper loaded: form_helper
INFO - 2018-04-05 19:19:46 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:19:46 --> Form Validation Class Initialized
INFO - 2018-04-05 19:19:46 --> Model Class Initialized
INFO - 2018-04-05 19:19:46 --> Controller Class Initialized
INFO - 2018-04-05 19:19:46 --> Model Class Initialized
INFO - 2018-04-05 19:19:46 --> Model Class Initialized
INFO - 2018-04-05 19:19:46 --> Model Class Initialized
INFO - 2018-04-05 19:19:46 --> Model Class Initialized
DEBUG - 2018-04-05 19:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:19:47 --> Final output sent to browser
DEBUG - 2018-04-05 19:19:47 --> Total execution time: 1.5257
INFO - 2018-04-05 19:20:14 --> Config Class Initialized
INFO - 2018-04-05 19:20:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:14 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:14 --> URI Class Initialized
INFO - 2018-04-05 19:20:14 --> Router Class Initialized
INFO - 2018-04-05 19:20:14 --> Output Class Initialized
INFO - 2018-04-05 19:20:14 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:14 --> Input Class Initialized
INFO - 2018-04-05 19:20:14 --> Language Class Initialized
INFO - 2018-04-05 19:20:14 --> Loader Class Initialized
INFO - 2018-04-05 19:20:14 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:14 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:14 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Controller Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:20:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:20:14 --> Final output sent to browser
DEBUG - 2018-04-05 19:20:14 --> Total execution time: 0.0889
INFO - 2018-04-05 19:20:14 --> Config Class Initialized
INFO - 2018-04-05 19:20:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:14 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:14 --> URI Class Initialized
INFO - 2018-04-05 19:20:14 --> Router Class Initialized
INFO - 2018-04-05 19:20:14 --> Output Class Initialized
INFO - 2018-04-05 19:20:14 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:14 --> Input Class Initialized
INFO - 2018-04-05 19:20:14 --> Language Class Initialized
INFO - 2018-04-05 19:20:14 --> Loader Class Initialized
INFO - 2018-04-05 19:20:14 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:14 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:14 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Controller Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
INFO - 2018-04-05 19:20:14 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:20:28 --> Config Class Initialized
INFO - 2018-04-05 19:20:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:28 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:28 --> URI Class Initialized
INFO - 2018-04-05 19:20:28 --> Router Class Initialized
INFO - 2018-04-05 19:20:28 --> Output Class Initialized
INFO - 2018-04-05 19:20:28 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:28 --> Input Class Initialized
INFO - 2018-04-05 19:20:28 --> Language Class Initialized
INFO - 2018-04-05 19:20:28 --> Loader Class Initialized
INFO - 2018-04-05 19:20:28 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:28 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:28 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
INFO - 2018-04-05 19:20:28 --> Controller Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
INFO - 2018-04-05 19:20:28 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:20:32 --> Config Class Initialized
INFO - 2018-04-05 19:20:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:32 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:32 --> URI Class Initialized
INFO - 2018-04-05 19:20:32 --> Router Class Initialized
INFO - 2018-04-05 19:20:32 --> Output Class Initialized
INFO - 2018-04-05 19:20:32 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:32 --> Input Class Initialized
INFO - 2018-04-05 19:20:32 --> Language Class Initialized
INFO - 2018-04-05 19:20:32 --> Loader Class Initialized
INFO - 2018-04-05 19:20:32 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:32 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:32 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:32 --> Model Class Initialized
INFO - 2018-04-05 19:20:32 --> Controller Class Initialized
INFO - 2018-04-05 19:20:32 --> Model Class Initialized
INFO - 2018-04-05 19:20:32 --> Model Class Initialized
INFO - 2018-04-05 19:20:32 --> Model Class Initialized
INFO - 2018-04-05 19:20:32 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:20:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:20:32 --> Final output sent to browser
DEBUG - 2018-04-05 19:20:32 --> Total execution time: 0.0762
INFO - 2018-04-05 19:20:36 --> Config Class Initialized
INFO - 2018-04-05 19:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:36 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:36 --> URI Class Initialized
INFO - 2018-04-05 19:20:36 --> Router Class Initialized
INFO - 2018-04-05 19:20:36 --> Output Class Initialized
INFO - 2018-04-05 19:20:36 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:36 --> Input Class Initialized
INFO - 2018-04-05 19:20:36 --> Language Class Initialized
INFO - 2018-04-05 19:20:36 --> Loader Class Initialized
INFO - 2018-04-05 19:20:36 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:36 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:36 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Controller Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:20:36 --> Final output sent to browser
DEBUG - 2018-04-05 19:20:36 --> Total execution time: 0.1068
INFO - 2018-04-05 19:20:36 --> Config Class Initialized
INFO - 2018-04-05 19:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:20:36 --> Utf8 Class Initialized
INFO - 2018-04-05 19:20:36 --> URI Class Initialized
INFO - 2018-04-05 19:20:36 --> Router Class Initialized
INFO - 2018-04-05 19:20:36 --> Output Class Initialized
INFO - 2018-04-05 19:20:36 --> Security Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:20:36 --> Input Class Initialized
INFO - 2018-04-05 19:20:36 --> Language Class Initialized
INFO - 2018-04-05 19:20:36 --> Loader Class Initialized
INFO - 2018-04-05 19:20:36 --> Helper loaded: url_helper
INFO - 2018-04-05 19:20:36 --> Helper loaded: form_helper
INFO - 2018-04-05 19:20:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:20:36 --> Form Validation Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Controller Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
INFO - 2018-04-05 19:20:36 --> Model Class Initialized
DEBUG - 2018-04-05 19:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:22:50 --> Config Class Initialized
INFO - 2018-04-05 19:22:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:22:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:22:50 --> Utf8 Class Initialized
INFO - 2018-04-05 19:22:50 --> URI Class Initialized
INFO - 2018-04-05 19:22:50 --> Router Class Initialized
INFO - 2018-04-05 19:22:50 --> Output Class Initialized
INFO - 2018-04-05 19:22:50 --> Security Class Initialized
DEBUG - 2018-04-05 19:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:22:50 --> Input Class Initialized
INFO - 2018-04-05 19:22:50 --> Language Class Initialized
INFO - 2018-04-05 19:22:50 --> Loader Class Initialized
INFO - 2018-04-05 19:22:50 --> Helper loaded: url_helper
INFO - 2018-04-05 19:22:50 --> Helper loaded: form_helper
INFO - 2018-04-05 19:22:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:22:50 --> Form Validation Class Initialized
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
INFO - 2018-04-05 19:22:50 --> Controller Class Initialized
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
DEBUG - 2018-04-05 19:22:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:22:50 --> Model Class Initialized
INFO - 2018-04-05 19:22:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:22:51 --> Final output sent to browser
DEBUG - 2018-04-05 19:22:51 --> Total execution time: 0.4265
INFO - 2018-04-05 19:22:51 --> Config Class Initialized
INFO - 2018-04-05 19:22:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:22:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:22:51 --> Utf8 Class Initialized
INFO - 2018-04-05 19:22:51 --> URI Class Initialized
INFO - 2018-04-05 19:22:51 --> Router Class Initialized
INFO - 2018-04-05 19:22:51 --> Output Class Initialized
INFO - 2018-04-05 19:22:51 --> Security Class Initialized
DEBUG - 2018-04-05 19:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:22:51 --> Input Class Initialized
INFO - 2018-04-05 19:22:51 --> Language Class Initialized
INFO - 2018-04-05 19:22:51 --> Loader Class Initialized
INFO - 2018-04-05 19:22:51 --> Helper loaded: url_helper
INFO - 2018-04-05 19:22:51 --> Helper loaded: form_helper
INFO - 2018-04-05 19:22:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:22:51 --> Form Validation Class Initialized
INFO - 2018-04-05 19:22:51 --> Model Class Initialized
INFO - 2018-04-05 19:22:51 --> Controller Class Initialized
INFO - 2018-04-05 19:22:51 --> Model Class Initialized
INFO - 2018-04-05 19:22:51 --> Model Class Initialized
INFO - 2018-04-05 19:22:51 --> Model Class Initialized
INFO - 2018-04-05 19:22:51 --> Model Class Initialized
DEBUG - 2018-04-05 19:22:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:22:59 --> Config Class Initialized
INFO - 2018-04-05 19:22:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:22:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:22:59 --> Utf8 Class Initialized
INFO - 2018-04-05 19:22:59 --> URI Class Initialized
INFO - 2018-04-05 19:22:59 --> Router Class Initialized
INFO - 2018-04-05 19:22:59 --> Output Class Initialized
INFO - 2018-04-05 19:22:59 --> Security Class Initialized
DEBUG - 2018-04-05 19:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:22:59 --> Input Class Initialized
INFO - 2018-04-05 19:22:59 --> Language Class Initialized
INFO - 2018-04-05 19:22:59 --> Loader Class Initialized
INFO - 2018-04-05 19:22:59 --> Helper loaded: url_helper
INFO - 2018-04-05 19:22:59 --> Helper loaded: form_helper
INFO - 2018-04-05 19:22:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:22:59 --> Form Validation Class Initialized
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
INFO - 2018-04-05 19:22:59 --> Controller Class Initialized
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
DEBUG - 2018-04-05 19:22:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:22:59 --> Model Class Initialized
INFO - 2018-04-05 19:22:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:22:59 --> Final output sent to browser
DEBUG - 2018-04-05 19:22:59 --> Total execution time: 0.0801
INFO - 2018-04-05 19:23:00 --> Config Class Initialized
INFO - 2018-04-05 19:23:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:00 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:00 --> URI Class Initialized
INFO - 2018-04-05 19:23:00 --> Router Class Initialized
INFO - 2018-04-05 19:23:00 --> Output Class Initialized
INFO - 2018-04-05 19:23:00 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:00 --> Input Class Initialized
INFO - 2018-04-05 19:23:00 --> Language Class Initialized
INFO - 2018-04-05 19:23:00 --> Loader Class Initialized
INFO - 2018-04-05 19:23:00 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:00 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:00 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:00 --> Model Class Initialized
INFO - 2018-04-05 19:23:00 --> Controller Class Initialized
INFO - 2018-04-05 19:23:00 --> Model Class Initialized
INFO - 2018-04-05 19:23:00 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:03 --> Config Class Initialized
INFO - 2018-04-05 19:23:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:03 --> URI Class Initialized
INFO - 2018-04-05 19:23:03 --> Router Class Initialized
INFO - 2018-04-05 19:23:03 --> Output Class Initialized
INFO - 2018-04-05 19:23:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:03 --> Input Class Initialized
INFO - 2018-04-05 19:23:03 --> Language Class Initialized
INFO - 2018-04-05 19:23:03 --> Loader Class Initialized
INFO - 2018-04-05 19:23:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Controller Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:23:03 --> Final output sent to browser
DEBUG - 2018-04-05 19:23:03 --> Total execution time: 0.0827
INFO - 2018-04-05 19:23:03 --> Config Class Initialized
INFO - 2018-04-05 19:23:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:03 --> URI Class Initialized
INFO - 2018-04-05 19:23:03 --> Router Class Initialized
INFO - 2018-04-05 19:23:03 --> Output Class Initialized
INFO - 2018-04-05 19:23:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:03 --> Input Class Initialized
INFO - 2018-04-05 19:23:03 --> Language Class Initialized
INFO - 2018-04-05 19:23:03 --> Loader Class Initialized
INFO - 2018-04-05 19:23:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Controller Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
INFO - 2018-04-05 19:23:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:21 --> Config Class Initialized
INFO - 2018-04-05 19:23:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:21 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:21 --> URI Class Initialized
INFO - 2018-04-05 19:23:21 --> Router Class Initialized
INFO - 2018-04-05 19:23:21 --> Output Class Initialized
INFO - 2018-04-05 19:23:21 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:21 --> Input Class Initialized
INFO - 2018-04-05 19:23:21 --> Language Class Initialized
INFO - 2018-04-05 19:23:21 --> Loader Class Initialized
INFO - 2018-04-05 19:23:21 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:21 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:21 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Controller Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:21 --> Config Class Initialized
INFO - 2018-04-05 19:23:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:21 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:21 --> URI Class Initialized
INFO - 2018-04-05 19:23:21 --> Router Class Initialized
INFO - 2018-04-05 19:23:21 --> Output Class Initialized
INFO - 2018-04-05 19:23:21 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:21 --> Input Class Initialized
INFO - 2018-04-05 19:23:21 --> Language Class Initialized
INFO - 2018-04-05 19:23:21 --> Loader Class Initialized
INFO - 2018-04-05 19:23:21 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:21 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:21 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Controller Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
INFO - 2018-04-05 19:23:21 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:25 --> Config Class Initialized
INFO - 2018-04-05 19:23:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:25 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:25 --> URI Class Initialized
INFO - 2018-04-05 19:23:25 --> Router Class Initialized
INFO - 2018-04-05 19:23:25 --> Output Class Initialized
INFO - 2018-04-05 19:23:25 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:25 --> Input Class Initialized
INFO - 2018-04-05 19:23:25 --> Language Class Initialized
INFO - 2018-04-05 19:23:25 --> Loader Class Initialized
INFO - 2018-04-05 19:23:25 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:25 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:26 --> Model Class Initialized
INFO - 2018-04-05 19:23:26 --> Controller Class Initialized
INFO - 2018-04-05 19:23:26 --> Model Class Initialized
INFO - 2018-04-05 19:23:26 --> Model Class Initialized
INFO - 2018-04-05 19:23:26 --> Model Class Initialized
INFO - 2018-04-05 19:23:26 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:28 --> Config Class Initialized
INFO - 2018-04-05 19:23:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:28 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:28 --> URI Class Initialized
INFO - 2018-04-05 19:23:28 --> Router Class Initialized
INFO - 2018-04-05 19:23:28 --> Output Class Initialized
INFO - 2018-04-05 19:23:28 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:28 --> Input Class Initialized
INFO - 2018-04-05 19:23:28 --> Language Class Initialized
INFO - 2018-04-05 19:23:28 --> Loader Class Initialized
INFO - 2018-04-05 19:23:28 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:28 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:28 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:28 --> Model Class Initialized
INFO - 2018-04-05 19:23:28 --> Controller Class Initialized
INFO - 2018-04-05 19:23:28 --> Model Class Initialized
INFO - 2018-04-05 19:23:28 --> Model Class Initialized
INFO - 2018-04-05 19:23:28 --> Model Class Initialized
INFO - 2018-04-05 19:23:28 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:43 --> Config Class Initialized
INFO - 2018-04-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:43 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:43 --> URI Class Initialized
INFO - 2018-04-05 19:23:43 --> Router Class Initialized
INFO - 2018-04-05 19:23:43 --> Output Class Initialized
INFO - 2018-04-05 19:23:43 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:43 --> Input Class Initialized
INFO - 2018-04-05 19:23:43 --> Language Class Initialized
INFO - 2018-04-05 19:23:43 --> Loader Class Initialized
INFO - 2018-04-05 19:23:43 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:43 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:43 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:43 --> Model Class Initialized
INFO - 2018-04-05 19:23:43 --> Controller Class Initialized
INFO - 2018-04-05 19:23:43 --> Model Class Initialized
INFO - 2018-04-05 19:23:43 --> Model Class Initialized
INFO - 2018-04-05 19:23:43 --> Model Class Initialized
INFO - 2018-04-05 19:23:43 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:48 --> Config Class Initialized
INFO - 2018-04-05 19:23:48 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:23:48 --> Utf8 Class Initialized
INFO - 2018-04-05 19:23:48 --> URI Class Initialized
INFO - 2018-04-05 19:23:48 --> Router Class Initialized
INFO - 2018-04-05 19:23:48 --> Output Class Initialized
INFO - 2018-04-05 19:23:48 --> Security Class Initialized
DEBUG - 2018-04-05 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:23:48 --> Input Class Initialized
INFO - 2018-04-05 19:23:48 --> Language Class Initialized
INFO - 2018-04-05 19:23:48 --> Loader Class Initialized
INFO - 2018-04-05 19:23:48 --> Helper loaded: url_helper
INFO - 2018-04-05 19:23:48 --> Helper loaded: form_helper
INFO - 2018-04-05 19:23:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:23:48 --> Form Validation Class Initialized
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
INFO - 2018-04-05 19:23:48 --> Controller Class Initialized
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
DEBUG - 2018-04-05 19:23:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:23:48 --> Model Class Initialized
INFO - 2018-04-05 19:23:48 --> Final output sent to browser
DEBUG - 2018-04-05 19:23:48 --> Total execution time: 0.1527
INFO - 2018-04-05 19:24:09 --> Config Class Initialized
INFO - 2018-04-05 19:24:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:09 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:09 --> URI Class Initialized
INFO - 2018-04-05 19:24:09 --> Router Class Initialized
INFO - 2018-04-05 19:24:09 --> Output Class Initialized
INFO - 2018-04-05 19:24:09 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:09 --> Input Class Initialized
INFO - 2018-04-05 19:24:09 --> Language Class Initialized
INFO - 2018-04-05 19:24:09 --> Loader Class Initialized
INFO - 2018-04-05 19:24:09 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:09 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:09 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:09 --> Model Class Initialized
INFO - 2018-04-05 19:24:09 --> Controller Class Initialized
INFO - 2018-04-05 19:24:09 --> Model Class Initialized
INFO - 2018-04-05 19:24:09 --> Model Class Initialized
INFO - 2018-04-05 19:24:09 --> Model Class Initialized
INFO - 2018-04-05 19:24:09 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:24:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:24:09 --> Final output sent to browser
DEBUG - 2018-04-05 19:24:09 --> Total execution time: 0.0759
INFO - 2018-04-05 19:24:12 --> Config Class Initialized
INFO - 2018-04-05 19:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:12 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:12 --> URI Class Initialized
INFO - 2018-04-05 19:24:12 --> Router Class Initialized
INFO - 2018-04-05 19:24:12 --> Output Class Initialized
INFO - 2018-04-05 19:24:12 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:12 --> Input Class Initialized
INFO - 2018-04-05 19:24:12 --> Language Class Initialized
INFO - 2018-04-05 19:24:12 --> Loader Class Initialized
INFO - 2018-04-05 19:24:12 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:12 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:12 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Controller Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:24:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:24:12 --> Final output sent to browser
DEBUG - 2018-04-05 19:24:12 --> Total execution time: 0.1063
INFO - 2018-04-05 19:24:12 --> Config Class Initialized
INFO - 2018-04-05 19:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:12 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:12 --> URI Class Initialized
INFO - 2018-04-05 19:24:12 --> Router Class Initialized
INFO - 2018-04-05 19:24:12 --> Output Class Initialized
INFO - 2018-04-05 19:24:12 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:12 --> Input Class Initialized
INFO - 2018-04-05 19:24:12 --> Language Class Initialized
INFO - 2018-04-05 19:24:12 --> Loader Class Initialized
INFO - 2018-04-05 19:24:12 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:12 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:12 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Controller Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
INFO - 2018-04-05 19:24:12 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:24:16 --> Config Class Initialized
INFO - 2018-04-05 19:24:16 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:16 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:16 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:16 --> URI Class Initialized
INFO - 2018-04-05 19:24:16 --> Router Class Initialized
INFO - 2018-04-05 19:24:16 --> Output Class Initialized
INFO - 2018-04-05 19:24:16 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:16 --> Input Class Initialized
INFO - 2018-04-05 19:24:16 --> Language Class Initialized
INFO - 2018-04-05 19:24:16 --> Loader Class Initialized
INFO - 2018-04-05 19:24:16 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:16 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:16 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:16 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:16 --> Model Class Initialized
INFO - 2018-04-05 19:24:16 --> Controller Class Initialized
INFO - 2018-04-05 19:24:16 --> Model Class Initialized
INFO - 2018-04-05 19:24:16 --> Model Class Initialized
INFO - 2018-04-05 19:24:16 --> Model Class Initialized
INFO - 2018-04-05 19:24:16 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:24:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:24:17 --> Final output sent to browser
DEBUG - 2018-04-05 19:24:17 --> Total execution time: 0.1150
INFO - 2018-04-05 19:24:17 --> Config Class Initialized
INFO - 2018-04-05 19:24:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:17 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:17 --> URI Class Initialized
INFO - 2018-04-05 19:24:17 --> Router Class Initialized
INFO - 2018-04-05 19:24:17 --> Output Class Initialized
INFO - 2018-04-05 19:24:17 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:17 --> Input Class Initialized
INFO - 2018-04-05 19:24:17 --> Language Class Initialized
INFO - 2018-04-05 19:24:17 --> Loader Class Initialized
INFO - 2018-04-05 19:24:17 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:17 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:17 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:17 --> Model Class Initialized
INFO - 2018-04-05 19:24:17 --> Controller Class Initialized
INFO - 2018-04-05 19:24:17 --> Model Class Initialized
INFO - 2018-04-05 19:24:17 --> Model Class Initialized
INFO - 2018-04-05 19:24:17 --> Model Class Initialized
INFO - 2018-04-05 19:24:17 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:24:38 --> Config Class Initialized
INFO - 2018-04-05 19:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:24:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:24:38 --> URI Class Initialized
INFO - 2018-04-05 19:24:38 --> Router Class Initialized
INFO - 2018-04-05 19:24:38 --> Output Class Initialized
INFO - 2018-04-05 19:24:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:24:38 --> Input Class Initialized
INFO - 2018-04-05 19:24:38 --> Language Class Initialized
INFO - 2018-04-05 19:24:38 --> Loader Class Initialized
INFO - 2018-04-05 19:24:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:24:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:24:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:24:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:24:38 --> Model Class Initialized
INFO - 2018-04-05 19:24:38 --> Controller Class Initialized
INFO - 2018-04-05 19:24:38 --> Model Class Initialized
INFO - 2018-04-05 19:24:38 --> Model Class Initialized
INFO - 2018-04-05 19:24:38 --> Model Class Initialized
INFO - 2018-04-05 19:24:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:24:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:34:26 --> Config Class Initialized
INFO - 2018-04-05 19:34:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:34:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:34:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:34:26 --> URI Class Initialized
INFO - 2018-04-05 19:34:26 --> Router Class Initialized
INFO - 2018-04-05 19:34:26 --> Output Class Initialized
INFO - 2018-04-05 19:34:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:34:26 --> Input Class Initialized
INFO - 2018-04-05 19:34:26 --> Language Class Initialized
INFO - 2018-04-05 19:34:26 --> Loader Class Initialized
INFO - 2018-04-05 19:34:26 --> Helper loaded: url_helper
INFO - 2018-04-05 19:34:26 --> Helper loaded: form_helper
INFO - 2018-04-05 19:34:26 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:34:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
INFO - 2018-04-05 19:34:26 --> Controller Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
INFO - 2018-04-05 19:34:26 --> Model Class Initialized
DEBUG - 2018-04-05 19:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:34:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:34:26 --> Final output sent to browser
DEBUG - 2018-04-05 19:34:26 --> Total execution time: 0.0745
INFO - 2018-04-05 19:34:26 --> Config Class Initialized
INFO - 2018-04-05 19:34:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:34:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:34:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:34:26 --> URI Class Initialized
INFO - 2018-04-05 19:34:26 --> Router Class Initialized
INFO - 2018-04-05 19:34:26 --> Output Class Initialized
INFO - 2018-04-05 19:34:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:34:27 --> Input Class Initialized
INFO - 2018-04-05 19:34:27 --> Language Class Initialized
INFO - 2018-04-05 19:34:27 --> Loader Class Initialized
INFO - 2018-04-05 19:34:27 --> Helper loaded: url_helper
INFO - 2018-04-05 19:34:27 --> Helper loaded: form_helper
INFO - 2018-04-05 19:34:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:34:27 --> Form Validation Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
INFO - 2018-04-05 19:34:27 --> Controller Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
INFO - 2018-04-05 19:34:27 --> Model Class Initialized
DEBUG - 2018-04-05 19:34:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:34:29 --> Config Class Initialized
INFO - 2018-04-05 19:34:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:34:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:34:29 --> Utf8 Class Initialized
INFO - 2018-04-05 19:34:29 --> URI Class Initialized
INFO - 2018-04-05 19:34:29 --> Router Class Initialized
INFO - 2018-04-05 19:34:29 --> Output Class Initialized
INFO - 2018-04-05 19:34:29 --> Security Class Initialized
DEBUG - 2018-04-05 19:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:34:29 --> Input Class Initialized
INFO - 2018-04-05 19:34:29 --> Language Class Initialized
INFO - 2018-04-05 19:34:29 --> Loader Class Initialized
INFO - 2018-04-05 19:34:29 --> Helper loaded: url_helper
INFO - 2018-04-05 19:34:29 --> Helper loaded: form_helper
INFO - 2018-04-05 19:34:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:34:29 --> Form Validation Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
INFO - 2018-04-05 19:34:29 --> Controller Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
INFO - 2018-04-05 19:34:29 --> Model Class Initialized
DEBUG - 2018-04-05 19:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:34:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:34:29 --> Final output sent to browser
DEBUG - 2018-04-05 19:34:29 --> Total execution time: 0.0779
INFO - 2018-04-05 19:36:56 --> Config Class Initialized
INFO - 2018-04-05 19:36:56 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:36:56 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:36:56 --> Utf8 Class Initialized
INFO - 2018-04-05 19:36:56 --> URI Class Initialized
INFO - 2018-04-05 19:36:56 --> Router Class Initialized
INFO - 2018-04-05 19:36:56 --> Output Class Initialized
INFO - 2018-04-05 19:36:56 --> Security Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:36:56 --> Input Class Initialized
INFO - 2018-04-05 19:36:56 --> Language Class Initialized
INFO - 2018-04-05 19:36:56 --> Loader Class Initialized
INFO - 2018-04-05 19:36:56 --> Helper loaded: url_helper
INFO - 2018-04-05 19:36:56 --> Helper loaded: form_helper
INFO - 2018-04-05 19:36:56 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:36:56 --> Form Validation Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Controller Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:36:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:36:56 --> Final output sent to browser
DEBUG - 2018-04-05 19:36:56 --> Total execution time: 0.0728
INFO - 2018-04-05 19:36:56 --> Config Class Initialized
INFO - 2018-04-05 19:36:56 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:36:56 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:36:56 --> Utf8 Class Initialized
INFO - 2018-04-05 19:36:56 --> URI Class Initialized
INFO - 2018-04-05 19:36:56 --> Router Class Initialized
INFO - 2018-04-05 19:36:56 --> Output Class Initialized
INFO - 2018-04-05 19:36:56 --> Security Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:36:56 --> Input Class Initialized
INFO - 2018-04-05 19:36:56 --> Language Class Initialized
INFO - 2018-04-05 19:36:56 --> Loader Class Initialized
INFO - 2018-04-05 19:36:56 --> Helper loaded: url_helper
INFO - 2018-04-05 19:36:56 --> Helper loaded: form_helper
INFO - 2018-04-05 19:36:56 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:36:56 --> Form Validation Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Controller Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
INFO - 2018-04-05 19:36:56 --> Model Class Initialized
DEBUG - 2018-04-05 19:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:36:59 --> Config Class Initialized
INFO - 2018-04-05 19:36:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:36:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:36:59 --> Utf8 Class Initialized
INFO - 2018-04-05 19:36:59 --> URI Class Initialized
INFO - 2018-04-05 19:36:59 --> Router Class Initialized
INFO - 2018-04-05 19:36:59 --> Output Class Initialized
INFO - 2018-04-05 19:36:59 --> Security Class Initialized
DEBUG - 2018-04-05 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:36:59 --> Input Class Initialized
INFO - 2018-04-05 19:36:59 --> Language Class Initialized
INFO - 2018-04-05 19:36:59 --> Loader Class Initialized
INFO - 2018-04-05 19:36:59 --> Helper loaded: url_helper
INFO - 2018-04-05 19:36:59 --> Helper loaded: form_helper
INFO - 2018-04-05 19:36:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:36:59 --> Form Validation Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
INFO - 2018-04-05 19:36:59 --> Controller Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
INFO - 2018-04-05 19:36:59 --> Model Class Initialized
DEBUG - 2018-04-05 19:36:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:36:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:36:59 --> Final output sent to browser
DEBUG - 2018-04-05 19:36:59 --> Total execution time: 0.1190
INFO - 2018-04-05 19:37:00 --> Config Class Initialized
INFO - 2018-04-05 19:37:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:00 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:00 --> URI Class Initialized
INFO - 2018-04-05 19:37:00 --> Router Class Initialized
INFO - 2018-04-05 19:37:00 --> Output Class Initialized
INFO - 2018-04-05 19:37:00 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:00 --> Input Class Initialized
INFO - 2018-04-05 19:37:00 --> Language Class Initialized
INFO - 2018-04-05 19:37:00 --> Loader Class Initialized
INFO - 2018-04-05 19:37:00 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:00 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:00 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:00 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
INFO - 2018-04-05 19:37:00 --> Controller Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
INFO - 2018-04-05 19:37:00 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:37:09 --> Config Class Initialized
INFO - 2018-04-05 19:37:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:09 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:09 --> URI Class Initialized
INFO - 2018-04-05 19:37:09 --> Router Class Initialized
INFO - 2018-04-05 19:37:09 --> Output Class Initialized
INFO - 2018-04-05 19:37:09 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:09 --> Input Class Initialized
INFO - 2018-04-05 19:37:09 --> Language Class Initialized
INFO - 2018-04-05 19:37:09 --> Loader Class Initialized
INFO - 2018-04-05 19:37:09 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:09 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:09 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Controller Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:37:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:37:09 --> Final output sent to browser
DEBUG - 2018-04-05 19:37:09 --> Total execution time: 0.0692
INFO - 2018-04-05 19:37:09 --> Config Class Initialized
INFO - 2018-04-05 19:37:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:09 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:09 --> URI Class Initialized
INFO - 2018-04-05 19:37:09 --> Router Class Initialized
INFO - 2018-04-05 19:37:09 --> Output Class Initialized
INFO - 2018-04-05 19:37:09 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:09 --> Input Class Initialized
INFO - 2018-04-05 19:37:09 --> Language Class Initialized
INFO - 2018-04-05 19:37:09 --> Loader Class Initialized
INFO - 2018-04-05 19:37:09 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:09 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:09 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Controller Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
INFO - 2018-04-05 19:37:09 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:37:12 --> Config Class Initialized
INFO - 2018-04-05 19:37:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:12 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:12 --> URI Class Initialized
INFO - 2018-04-05 19:37:12 --> Router Class Initialized
INFO - 2018-04-05 19:37:12 --> Output Class Initialized
INFO - 2018-04-05 19:37:12 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:12 --> Input Class Initialized
INFO - 2018-04-05 19:37:12 --> Language Class Initialized
INFO - 2018-04-05 19:37:12 --> Loader Class Initialized
INFO - 2018-04-05 19:37:12 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:12 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:12 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
INFO - 2018-04-05 19:37:12 --> Controller Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
INFO - 2018-04-05 19:37:12 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:37:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:37:12 --> Final output sent to browser
DEBUG - 2018-04-05 19:37:12 --> Total execution time: 0.1164
INFO - 2018-04-05 19:37:55 --> Config Class Initialized
INFO - 2018-04-05 19:37:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:55 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:55 --> URI Class Initialized
INFO - 2018-04-05 19:37:55 --> Router Class Initialized
INFO - 2018-04-05 19:37:55 --> Output Class Initialized
INFO - 2018-04-05 19:37:55 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:55 --> Input Class Initialized
INFO - 2018-04-05 19:37:55 --> Language Class Initialized
INFO - 2018-04-05 19:37:55 --> Loader Class Initialized
INFO - 2018-04-05 19:37:55 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:55 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:55 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
INFO - 2018-04-05 19:37:55 --> Controller Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
INFO - 2018-04-05 19:37:55 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:37:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:37:55 --> Final output sent to browser
DEBUG - 2018-04-05 19:37:55 --> Total execution time: 0.0888
INFO - 2018-04-05 19:37:56 --> Config Class Initialized
INFO - 2018-04-05 19:37:56 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:37:56 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:37:56 --> Utf8 Class Initialized
INFO - 2018-04-05 19:37:56 --> URI Class Initialized
INFO - 2018-04-05 19:37:56 --> Router Class Initialized
INFO - 2018-04-05 19:37:56 --> Output Class Initialized
INFO - 2018-04-05 19:37:56 --> Security Class Initialized
DEBUG - 2018-04-05 19:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:37:56 --> Input Class Initialized
INFO - 2018-04-05 19:37:56 --> Language Class Initialized
INFO - 2018-04-05 19:37:56 --> Loader Class Initialized
INFO - 2018-04-05 19:37:56 --> Helper loaded: url_helper
INFO - 2018-04-05 19:37:56 --> Helper loaded: form_helper
INFO - 2018-04-05 19:37:56 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:37:56 --> Form Validation Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
INFO - 2018-04-05 19:37:56 --> Controller Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
INFO - 2018-04-05 19:37:56 --> Model Class Initialized
DEBUG - 2018-04-05 19:37:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:11 --> Config Class Initialized
INFO - 2018-04-05 19:40:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:11 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:11 --> URI Class Initialized
INFO - 2018-04-05 19:40:11 --> Router Class Initialized
INFO - 2018-04-05 19:40:11 --> Output Class Initialized
INFO - 2018-04-05 19:40:11 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:11 --> Input Class Initialized
INFO - 2018-04-05 19:40:11 --> Language Class Initialized
INFO - 2018-04-05 19:40:11 --> Loader Class Initialized
INFO - 2018-04-05 19:40:11 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:11 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:11 --> Model Class Initialized
INFO - 2018-04-05 19:40:11 --> Controller Class Initialized
INFO - 2018-04-05 19:40:11 --> Model Class Initialized
INFO - 2018-04-05 19:40:11 --> Model Class Initialized
INFO - 2018-04-05 19:40:11 --> Model Class Initialized
INFO - 2018-04-05 19:40:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:40:11 --> Final output sent to browser
DEBUG - 2018-04-05 19:40:11 --> Total execution time: 0.0658
INFO - 2018-04-05 19:40:14 --> Config Class Initialized
INFO - 2018-04-05 19:40:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:14 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:14 --> URI Class Initialized
INFO - 2018-04-05 19:40:14 --> Router Class Initialized
INFO - 2018-04-05 19:40:14 --> Output Class Initialized
INFO - 2018-04-05 19:40:14 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:14 --> Input Class Initialized
INFO - 2018-04-05 19:40:14 --> Language Class Initialized
INFO - 2018-04-05 19:40:14 --> Loader Class Initialized
INFO - 2018-04-05 19:40:14 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:14 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:14 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Controller Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:40:14 --> Final output sent to browser
DEBUG - 2018-04-05 19:40:14 --> Total execution time: 0.0819
INFO - 2018-04-05 19:40:14 --> Config Class Initialized
INFO - 2018-04-05 19:40:14 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:14 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:14 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:14 --> URI Class Initialized
INFO - 2018-04-05 19:40:14 --> Router Class Initialized
INFO - 2018-04-05 19:40:14 --> Output Class Initialized
INFO - 2018-04-05 19:40:14 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:14 --> Input Class Initialized
INFO - 2018-04-05 19:40:14 --> Language Class Initialized
INFO - 2018-04-05 19:40:14 --> Loader Class Initialized
INFO - 2018-04-05 19:40:14 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:14 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:14 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:14 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Controller Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
INFO - 2018-04-05 19:40:14 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:17 --> Config Class Initialized
INFO - 2018-04-05 19:40:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:17 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:17 --> URI Class Initialized
INFO - 2018-04-05 19:40:17 --> Router Class Initialized
INFO - 2018-04-05 19:40:17 --> Output Class Initialized
INFO - 2018-04-05 19:40:17 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:17 --> Input Class Initialized
INFO - 2018-04-05 19:40:17 --> Language Class Initialized
INFO - 2018-04-05 19:40:17 --> Loader Class Initialized
INFO - 2018-04-05 19:40:17 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:17 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:17 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Controller Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:40:17 --> Final output sent to browser
DEBUG - 2018-04-05 19:40:17 --> Total execution time: 0.0845
INFO - 2018-04-05 19:40:17 --> Config Class Initialized
INFO - 2018-04-05 19:40:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:17 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:17 --> URI Class Initialized
INFO - 2018-04-05 19:40:17 --> Router Class Initialized
INFO - 2018-04-05 19:40:17 --> Output Class Initialized
INFO - 2018-04-05 19:40:17 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:17 --> Input Class Initialized
INFO - 2018-04-05 19:40:17 --> Language Class Initialized
INFO - 2018-04-05 19:40:17 --> Loader Class Initialized
INFO - 2018-04-05 19:40:17 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:17 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:17 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Controller Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
INFO - 2018-04-05 19:40:17 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:23 --> Config Class Initialized
INFO - 2018-04-05 19:40:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:23 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:23 --> URI Class Initialized
INFO - 2018-04-05 19:40:23 --> Router Class Initialized
INFO - 2018-04-05 19:40:23 --> Output Class Initialized
INFO - 2018-04-05 19:40:23 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:23 --> Input Class Initialized
INFO - 2018-04-05 19:40:23 --> Language Class Initialized
INFO - 2018-04-05 19:40:23 --> Loader Class Initialized
INFO - 2018-04-05 19:40:23 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:23 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:23 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:23 --> Model Class Initialized
INFO - 2018-04-05 19:40:23 --> Controller Class Initialized
INFO - 2018-04-05 19:40:23 --> Model Class Initialized
INFO - 2018-04-05 19:40:23 --> Model Class Initialized
INFO - 2018-04-05 19:40:23 --> Model Class Initialized
INFO - 2018-04-05 19:40:23 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:26 --> Config Class Initialized
INFO - 2018-04-05 19:40:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:26 --> URI Class Initialized
INFO - 2018-04-05 19:40:26 --> Router Class Initialized
INFO - 2018-04-05 19:40:26 --> Output Class Initialized
INFO - 2018-04-05 19:40:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:26 --> Input Class Initialized
INFO - 2018-04-05 19:40:26 --> Language Class Initialized
INFO - 2018-04-05 19:40:26 --> Loader Class Initialized
INFO - 2018-04-05 19:40:26 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:26 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:26 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:26 --> Model Class Initialized
INFO - 2018-04-05 19:40:26 --> Controller Class Initialized
INFO - 2018-04-05 19:40:26 --> Model Class Initialized
INFO - 2018-04-05 19:40:26 --> Model Class Initialized
INFO - 2018-04-05 19:40:26 --> Model Class Initialized
INFO - 2018-04-05 19:40:26 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:36 --> Config Class Initialized
INFO - 2018-04-05 19:40:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:36 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:36 --> URI Class Initialized
INFO - 2018-04-05 19:40:36 --> Router Class Initialized
INFO - 2018-04-05 19:40:36 --> Output Class Initialized
INFO - 2018-04-05 19:40:36 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:36 --> Input Class Initialized
INFO - 2018-04-05 19:40:36 --> Language Class Initialized
INFO - 2018-04-05 19:40:36 --> Loader Class Initialized
INFO - 2018-04-05 19:40:36 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:36 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:36 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:36 --> Model Class Initialized
INFO - 2018-04-05 19:40:36 --> Controller Class Initialized
INFO - 2018-04-05 19:40:36 --> Model Class Initialized
INFO - 2018-04-05 19:40:36 --> Model Class Initialized
INFO - 2018-04-05 19:40:36 --> Model Class Initialized
INFO - 2018-04-05 19:40:36 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:38 --> Config Class Initialized
INFO - 2018-04-05 19:40:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:40:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:40:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:40:38 --> URI Class Initialized
INFO - 2018-04-05 19:40:38 --> Router Class Initialized
INFO - 2018-04-05 19:40:38 --> Output Class Initialized
INFO - 2018-04-05 19:40:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:40:38 --> Input Class Initialized
INFO - 2018-04-05 19:40:38 --> Language Class Initialized
INFO - 2018-04-05 19:40:38 --> Loader Class Initialized
INFO - 2018-04-05 19:40:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:40:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:40:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:40:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:40:38 --> Model Class Initialized
INFO - 2018-04-05 19:40:38 --> Controller Class Initialized
INFO - 2018-04-05 19:40:38 --> Model Class Initialized
INFO - 2018-04-05 19:40:38 --> Model Class Initialized
INFO - 2018-04-05 19:40:38 --> Model Class Initialized
INFO - 2018-04-05 19:40:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:40:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:40:38 --> Final output sent to browser
DEBUG - 2018-04-05 19:40:38 --> Total execution time: 0.1552
INFO - 2018-04-05 19:41:43 --> Config Class Initialized
INFO - 2018-04-05 19:41:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:43 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:43 --> URI Class Initialized
INFO - 2018-04-05 19:41:43 --> Router Class Initialized
INFO - 2018-04-05 19:41:43 --> Output Class Initialized
INFO - 2018-04-05 19:41:43 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:43 --> Input Class Initialized
INFO - 2018-04-05 19:41:43 --> Language Class Initialized
INFO - 2018-04-05 19:41:43 --> Loader Class Initialized
INFO - 2018-04-05 19:41:43 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:43 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:43 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:43 --> Model Class Initialized
INFO - 2018-04-05 19:41:43 --> Controller Class Initialized
INFO - 2018-04-05 19:41:43 --> Model Class Initialized
INFO - 2018-04-05 19:41:43 --> Model Class Initialized
INFO - 2018-04-05 19:41:43 --> Model Class Initialized
INFO - 2018-04-05 19:41:43 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:41:43 --> Final output sent to browser
DEBUG - 2018-04-05 19:41:43 --> Total execution time: 0.0810
INFO - 2018-04-05 19:41:47 --> Config Class Initialized
INFO - 2018-04-05 19:41:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:47 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:47 --> URI Class Initialized
INFO - 2018-04-05 19:41:47 --> Router Class Initialized
INFO - 2018-04-05 19:41:47 --> Output Class Initialized
INFO - 2018-04-05 19:41:47 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:47 --> Input Class Initialized
INFO - 2018-04-05 19:41:47 --> Language Class Initialized
INFO - 2018-04-05 19:41:47 --> Loader Class Initialized
INFO - 2018-04-05 19:41:47 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:47 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:47 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
INFO - 2018-04-05 19:41:47 --> Controller Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
INFO - 2018-04-05 19:41:47 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:41:47 --> Final output sent to browser
DEBUG - 2018-04-05 19:41:47 --> Total execution time: 0.0821
INFO - 2018-04-05 19:41:48 --> Config Class Initialized
INFO - 2018-04-05 19:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:48 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:48 --> URI Class Initialized
INFO - 2018-04-05 19:41:48 --> Router Class Initialized
INFO - 2018-04-05 19:41:48 --> Output Class Initialized
INFO - 2018-04-05 19:41:48 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:48 --> Input Class Initialized
INFO - 2018-04-05 19:41:48 --> Language Class Initialized
INFO - 2018-04-05 19:41:48 --> Loader Class Initialized
INFO - 2018-04-05 19:41:48 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:48 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:48 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
INFO - 2018-04-05 19:41:48 --> Controller Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
INFO - 2018-04-05 19:41:48 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:53 --> Config Class Initialized
INFO - 2018-04-05 19:41:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:53 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:53 --> URI Class Initialized
INFO - 2018-04-05 19:41:53 --> Router Class Initialized
INFO - 2018-04-05 19:41:53 --> Output Class Initialized
INFO - 2018-04-05 19:41:53 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:53 --> Input Class Initialized
INFO - 2018-04-05 19:41:53 --> Language Class Initialized
INFO - 2018-04-05 19:41:53 --> Loader Class Initialized
INFO - 2018-04-05 19:41:53 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:53 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:53 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:53 --> Model Class Initialized
INFO - 2018-04-05 19:41:53 --> Controller Class Initialized
INFO - 2018-04-05 19:41:53 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:53 --> Config Class Initialized
INFO - 2018-04-05 19:41:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:53 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:53 --> URI Class Initialized
INFO - 2018-04-05 19:41:53 --> Router Class Initialized
INFO - 2018-04-05 19:41:53 --> Output Class Initialized
INFO - 2018-04-05 19:41:53 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:53 --> Input Class Initialized
INFO - 2018-04-05 19:41:53 --> Language Class Initialized
INFO - 2018-04-05 19:41:53 --> Loader Class Initialized
INFO - 2018-04-05 19:41:53 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:53 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:53 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:53 --> Model Class Initialized
INFO - 2018-04-05 19:41:53 --> Controller Class Initialized
INFO - 2018-04-05 19:41:53 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:41:53 --> Final output sent to browser
DEBUG - 2018-04-05 19:41:53 --> Total execution time: 0.0588
INFO - 2018-04-05 19:41:57 --> Config Class Initialized
INFO - 2018-04-05 19:41:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:57 --> URI Class Initialized
INFO - 2018-04-05 19:41:57 --> Router Class Initialized
INFO - 2018-04-05 19:41:57 --> Output Class Initialized
INFO - 2018-04-05 19:41:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:57 --> Input Class Initialized
INFO - 2018-04-05 19:41:57 --> Language Class Initialized
INFO - 2018-04-05 19:41:57 --> Loader Class Initialized
INFO - 2018-04-05 19:41:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Controller Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:41:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 19:41:57 --> Config Class Initialized
INFO - 2018-04-05 19:41:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:57 --> URI Class Initialized
DEBUG - 2018-04-05 19:41:57 --> No URI present. Default controller set.
INFO - 2018-04-05 19:41:57 --> Router Class Initialized
INFO - 2018-04-05 19:41:57 --> Output Class Initialized
INFO - 2018-04-05 19:41:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:57 --> Input Class Initialized
INFO - 2018-04-05 19:41:57 --> Language Class Initialized
INFO - 2018-04-05 19:41:57 --> Loader Class Initialized
INFO - 2018-04-05 19:41:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Controller Class Initialized
INFO - 2018-04-05 19:41:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:41:57 --> Final output sent to browser
DEBUG - 2018-04-05 19:41:57 --> Total execution time: 0.0749
INFO - 2018-04-05 19:41:57 --> Config Class Initialized
INFO - 2018-04-05 19:41:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:41:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:41:57 --> Utf8 Class Initialized
INFO - 2018-04-05 19:41:57 --> URI Class Initialized
INFO - 2018-04-05 19:41:57 --> Router Class Initialized
INFO - 2018-04-05 19:41:57 --> Output Class Initialized
INFO - 2018-04-05 19:41:57 --> Security Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:41:57 --> Input Class Initialized
INFO - 2018-04-05 19:41:57 --> Language Class Initialized
INFO - 2018-04-05 19:41:57 --> Loader Class Initialized
INFO - 2018-04-05 19:41:57 --> Helper loaded: url_helper
INFO - 2018-04-05 19:41:57 --> Helper loaded: form_helper
INFO - 2018-04-05 19:41:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:41:57 --> Form Validation Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Controller Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
INFO - 2018-04-05 19:41:57 --> Model Class Initialized
DEBUG - 2018-04-05 19:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:07 --> Config Class Initialized
INFO - 2018-04-05 19:42:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:07 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:07 --> URI Class Initialized
INFO - 2018-04-05 19:42:07 --> Router Class Initialized
INFO - 2018-04-05 19:42:07 --> Output Class Initialized
INFO - 2018-04-05 19:42:07 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:07 --> Input Class Initialized
INFO - 2018-04-05 19:42:07 --> Language Class Initialized
INFO - 2018-04-05 19:42:07 --> Loader Class Initialized
INFO - 2018-04-05 19:42:07 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:07 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:07 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Controller Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:42:07 --> Final output sent to browser
DEBUG - 2018-04-05 19:42:07 --> Total execution time: 0.0790
INFO - 2018-04-05 19:42:07 --> Config Class Initialized
INFO - 2018-04-05 19:42:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:07 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:07 --> URI Class Initialized
INFO - 2018-04-05 19:42:07 --> Router Class Initialized
INFO - 2018-04-05 19:42:07 --> Output Class Initialized
INFO - 2018-04-05 19:42:07 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:07 --> Input Class Initialized
INFO - 2018-04-05 19:42:07 --> Language Class Initialized
INFO - 2018-04-05 19:42:07 --> Loader Class Initialized
INFO - 2018-04-05 19:42:07 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:07 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:07 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Controller Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
INFO - 2018-04-05 19:42:07 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:15 --> Config Class Initialized
INFO - 2018-04-05 19:42:15 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:15 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:15 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:15 --> URI Class Initialized
INFO - 2018-04-05 19:42:15 --> Router Class Initialized
INFO - 2018-04-05 19:42:15 --> Output Class Initialized
INFO - 2018-04-05 19:42:15 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:15 --> Input Class Initialized
INFO - 2018-04-05 19:42:15 --> Language Class Initialized
INFO - 2018-04-05 19:42:15 --> Loader Class Initialized
INFO - 2018-04-05 19:42:15 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:15 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:15 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:15 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
INFO - 2018-04-05 19:42:15 --> Controller Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
INFO - 2018-04-05 19:42:15 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:19 --> Config Class Initialized
INFO - 2018-04-05 19:42:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:19 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:19 --> URI Class Initialized
INFO - 2018-04-05 19:42:19 --> Router Class Initialized
INFO - 2018-04-05 19:42:19 --> Output Class Initialized
INFO - 2018-04-05 19:42:19 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:19 --> Input Class Initialized
INFO - 2018-04-05 19:42:19 --> Language Class Initialized
INFO - 2018-04-05 19:42:19 --> Loader Class Initialized
INFO - 2018-04-05 19:42:19 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:19 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:19 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
INFO - 2018-04-05 19:42:19 --> Controller Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
INFO - 2018-04-05 19:42:19 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:22 --> Config Class Initialized
INFO - 2018-04-05 19:42:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:22 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:22 --> URI Class Initialized
INFO - 2018-04-05 19:42:22 --> Router Class Initialized
INFO - 2018-04-05 19:42:22 --> Output Class Initialized
INFO - 2018-04-05 19:42:22 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:22 --> Input Class Initialized
INFO - 2018-04-05 19:42:22 --> Language Class Initialized
INFO - 2018-04-05 19:42:22 --> Loader Class Initialized
INFO - 2018-04-05 19:42:22 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:22 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:22 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
INFO - 2018-04-05 19:42:22 --> Controller Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
INFO - 2018-04-05 19:42:22 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:23 --> Config Class Initialized
INFO - 2018-04-05 19:42:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:23 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:23 --> URI Class Initialized
INFO - 2018-04-05 19:42:23 --> Router Class Initialized
INFO - 2018-04-05 19:42:23 --> Output Class Initialized
INFO - 2018-04-05 19:42:23 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:23 --> Input Class Initialized
INFO - 2018-04-05 19:42:23 --> Language Class Initialized
INFO - 2018-04-05 19:42:23 --> Loader Class Initialized
INFO - 2018-04-05 19:42:23 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:23 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:23 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
INFO - 2018-04-05 19:42:23 --> Controller Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
INFO - 2018-04-05 19:42:23 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:42:23 --> Final output sent to browser
DEBUG - 2018-04-05 19:42:23 --> Total execution time: 0.0645
INFO - 2018-04-05 19:42:23 --> Config Class Initialized
INFO - 2018-04-05 19:42:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:23 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:23 --> URI Class Initialized
INFO - 2018-04-05 19:42:23 --> Router Class Initialized
INFO - 2018-04-05 19:42:23 --> Output Class Initialized
INFO - 2018-04-05 19:42:23 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:23 --> Input Class Initialized
INFO - 2018-04-05 19:42:23 --> Language Class Initialized
INFO - 2018-04-05 19:42:23 --> Loader Class Initialized
INFO - 2018-04-05 19:42:23 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:23 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:24 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
INFO - 2018-04-05 19:42:24 --> Controller Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
INFO - 2018-04-05 19:42:24 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:38 --> Config Class Initialized
INFO - 2018-04-05 19:42:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:38 --> URI Class Initialized
INFO - 2018-04-05 19:42:38 --> Router Class Initialized
INFO - 2018-04-05 19:42:38 --> Output Class Initialized
INFO - 2018-04-05 19:42:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:38 --> Input Class Initialized
INFO - 2018-04-05 19:42:38 --> Language Class Initialized
INFO - 2018-04-05 19:42:38 --> Loader Class Initialized
INFO - 2018-04-05 19:42:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Controller Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:42:38 --> Final output sent to browser
DEBUG - 2018-04-05 19:42:38 --> Total execution time: 0.0620
INFO - 2018-04-05 19:42:38 --> Config Class Initialized
INFO - 2018-04-05 19:42:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:38 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:38 --> URI Class Initialized
INFO - 2018-04-05 19:42:38 --> Router Class Initialized
INFO - 2018-04-05 19:42:38 --> Output Class Initialized
INFO - 2018-04-05 19:42:38 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:38 --> Input Class Initialized
INFO - 2018-04-05 19:42:38 --> Language Class Initialized
INFO - 2018-04-05 19:42:38 --> Loader Class Initialized
INFO - 2018-04-05 19:42:38 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:38 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:38 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Controller Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
INFO - 2018-04-05 19:42:38 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:40 --> Config Class Initialized
INFO - 2018-04-05 19:42:40 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:40 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:40 --> URI Class Initialized
INFO - 2018-04-05 19:42:40 --> Router Class Initialized
INFO - 2018-04-05 19:42:40 --> Output Class Initialized
INFO - 2018-04-05 19:42:40 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:40 --> Input Class Initialized
INFO - 2018-04-05 19:42:40 --> Language Class Initialized
INFO - 2018-04-05 19:42:40 --> Loader Class Initialized
INFO - 2018-04-05 19:42:40 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:40 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:40 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:40 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Controller Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:42:40 --> Final output sent to browser
DEBUG - 2018-04-05 19:42:40 --> Total execution time: 0.0774
INFO - 2018-04-05 19:42:40 --> Config Class Initialized
INFO - 2018-04-05 19:42:40 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:40 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:40 --> URI Class Initialized
INFO - 2018-04-05 19:42:40 --> Router Class Initialized
INFO - 2018-04-05 19:42:40 --> Output Class Initialized
INFO - 2018-04-05 19:42:40 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:40 --> Input Class Initialized
INFO - 2018-04-05 19:42:40 --> Language Class Initialized
INFO - 2018-04-05 19:42:40 --> Loader Class Initialized
INFO - 2018-04-05 19:42:40 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:40 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:40 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:40 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Controller Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
INFO - 2018-04-05 19:42:40 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:42:49 --> Config Class Initialized
INFO - 2018-04-05 19:42:49 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:42:49 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:42:49 --> Utf8 Class Initialized
INFO - 2018-04-05 19:42:49 --> URI Class Initialized
INFO - 2018-04-05 19:42:49 --> Router Class Initialized
INFO - 2018-04-05 19:42:49 --> Output Class Initialized
INFO - 2018-04-05 19:42:49 --> Security Class Initialized
DEBUG - 2018-04-05 19:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:42:49 --> Input Class Initialized
INFO - 2018-04-05 19:42:49 --> Language Class Initialized
INFO - 2018-04-05 19:42:49 --> Loader Class Initialized
INFO - 2018-04-05 19:42:49 --> Helper loaded: url_helper
INFO - 2018-04-05 19:42:49 --> Helper loaded: form_helper
INFO - 2018-04-05 19:42:49 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:42:49 --> Form Validation Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
INFO - 2018-04-05 19:42:49 --> Controller Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
INFO - 2018-04-05 19:42:49 --> Model Class Initialized
DEBUG - 2018-04-05 19:42:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:43:24 --> Config Class Initialized
INFO - 2018-04-05 19:43:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:43:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:43:24 --> Utf8 Class Initialized
INFO - 2018-04-05 19:43:24 --> URI Class Initialized
INFO - 2018-04-05 19:43:24 --> Router Class Initialized
INFO - 2018-04-05 19:43:24 --> Output Class Initialized
INFO - 2018-04-05 19:43:24 --> Security Class Initialized
DEBUG - 2018-04-05 19:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:43:24 --> Input Class Initialized
INFO - 2018-04-05 19:43:24 --> Language Class Initialized
INFO - 2018-04-05 19:43:24 --> Loader Class Initialized
INFO - 2018-04-05 19:43:24 --> Helper loaded: url_helper
INFO - 2018-04-05 19:43:24 --> Helper loaded: form_helper
INFO - 2018-04-05 19:43:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:43:24 --> Form Validation Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
INFO - 2018-04-05 19:43:24 --> Controller Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
INFO - 2018-04-05 19:43:24 --> Model Class Initialized
DEBUG - 2018-04-05 19:43:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:43:40 --> Config Class Initialized
INFO - 2018-04-05 19:43:40 --> Hooks Class Initialized
INFO - 2018-04-05 19:43:40 --> Config Class Initialized
INFO - 2018-04-05 19:43:40 --> Config Class Initialized
DEBUG - 2018-04-05 19:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:43:40 --> Hooks Class Initialized
INFO - 2018-04-05 19:43:40 --> Hooks Class Initialized
INFO - 2018-04-05 19:43:40 --> Utf8 Class Initialized
INFO - 2018-04-05 19:43:40 --> URI Class Initialized
DEBUG - 2018-04-05 19:43:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-05 19:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:43:40 --> Utf8 Class Initialized
INFO - 2018-04-05 19:43:40 --> Router Class Initialized
INFO - 2018-04-05 19:43:40 --> Utf8 Class Initialized
INFO - 2018-04-05 19:43:40 --> URI Class Initialized
INFO - 2018-04-05 19:43:40 --> URI Class Initialized
INFO - 2018-04-05 19:43:40 --> Output Class Initialized
INFO - 2018-04-05 19:43:40 --> Router Class Initialized
INFO - 2018-04-05 19:43:40 --> Security Class Initialized
INFO - 2018-04-05 19:43:40 --> Output Class Initialized
DEBUG - 2018-04-05 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:43:40 --> Input Class Initialized
INFO - 2018-04-05 19:43:40 --> Security Class Initialized
INFO - 2018-04-05 19:43:40 --> Language Class Initialized
DEBUG - 2018-04-05 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:43:40 --> Input Class Initialized
INFO - 2018-04-05 19:43:40 --> Language Class Initialized
INFO - 2018-04-05 19:43:40 --> Router Class Initialized
INFO - 2018-04-05 19:43:40 --> Output Class Initialized
INFO - 2018-04-05 19:43:40 --> Security Class Initialized
DEBUG - 2018-04-05 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:43:40 --> Input Class Initialized
INFO - 2018-04-05 19:43:40 --> Language Class Initialized
ERROR - 2018-04-05 19:43:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-05 19:43:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-05 19:43:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-05 19:47:55 --> Config Class Initialized
INFO - 2018-04-05 19:47:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:47:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:47:55 --> Utf8 Class Initialized
INFO - 2018-04-05 19:47:55 --> URI Class Initialized
INFO - 2018-04-05 19:47:55 --> Router Class Initialized
INFO - 2018-04-05 19:47:55 --> Output Class Initialized
INFO - 2018-04-05 19:47:55 --> Security Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:47:55 --> Input Class Initialized
INFO - 2018-04-05 19:47:55 --> Language Class Initialized
INFO - 2018-04-05 19:47:55 --> Loader Class Initialized
INFO - 2018-04-05 19:47:55 --> Helper loaded: url_helper
INFO - 2018-04-05 19:47:55 --> Helper loaded: form_helper
INFO - 2018-04-05 19:47:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:47:55 --> Form Validation Class Initialized
INFO - 2018-04-05 19:47:55 --> Model Class Initialized
INFO - 2018-04-05 19:47:55 --> Controller Class Initialized
INFO - 2018-04-05 19:47:55 --> Model Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:47:55 --> Config Class Initialized
INFO - 2018-04-05 19:47:55 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:47:55 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:47:55 --> Utf8 Class Initialized
INFO - 2018-04-05 19:47:55 --> URI Class Initialized
INFO - 2018-04-05 19:47:55 --> Router Class Initialized
INFO - 2018-04-05 19:47:55 --> Output Class Initialized
INFO - 2018-04-05 19:47:55 --> Security Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:47:55 --> Input Class Initialized
INFO - 2018-04-05 19:47:55 --> Language Class Initialized
INFO - 2018-04-05 19:47:55 --> Loader Class Initialized
INFO - 2018-04-05 19:47:55 --> Helper loaded: url_helper
INFO - 2018-04-05 19:47:55 --> Helper loaded: form_helper
INFO - 2018-04-05 19:47:55 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:47:55 --> Form Validation Class Initialized
INFO - 2018-04-05 19:47:55 --> Model Class Initialized
INFO - 2018-04-05 19:47:55 --> Controller Class Initialized
INFO - 2018-04-05 19:47:55 --> Model Class Initialized
DEBUG - 2018-04-05 19:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:47:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:47:55 --> Final output sent to browser
DEBUG - 2018-04-05 19:47:55 --> Total execution time: 0.0441
INFO - 2018-04-05 19:47:58 --> Config Class Initialized
INFO - 2018-04-05 19:47:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:47:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:47:58 --> Utf8 Class Initialized
INFO - 2018-04-05 19:47:58 --> URI Class Initialized
INFO - 2018-04-05 19:47:58 --> Router Class Initialized
INFO - 2018-04-05 19:47:58 --> Output Class Initialized
INFO - 2018-04-05 19:47:58 --> Security Class Initialized
DEBUG - 2018-04-05 19:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:47:58 --> Input Class Initialized
INFO - 2018-04-05 19:47:58 --> Language Class Initialized
INFO - 2018-04-05 19:47:58 --> Loader Class Initialized
INFO - 2018-04-05 19:47:58 --> Helper loaded: url_helper
INFO - 2018-04-05 19:47:58 --> Helper loaded: form_helper
INFO - 2018-04-05 19:47:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:47:58 --> Form Validation Class Initialized
INFO - 2018-04-05 19:47:58 --> Model Class Initialized
INFO - 2018-04-05 19:47:58 --> Controller Class Initialized
INFO - 2018-04-05 19:47:58 --> Model Class Initialized
DEBUG - 2018-04-05 19:47:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:47:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 19:47:58 --> Config Class Initialized
INFO - 2018-04-05 19:47:58 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:47:58 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:47:58 --> Utf8 Class Initialized
INFO - 2018-04-05 19:47:58 --> URI Class Initialized
DEBUG - 2018-04-05 19:47:58 --> No URI present. Default controller set.
INFO - 2018-04-05 19:47:58 --> Router Class Initialized
INFO - 2018-04-05 19:47:58 --> Output Class Initialized
INFO - 2018-04-05 19:47:58 --> Security Class Initialized
DEBUG - 2018-04-05 19:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:47:58 --> Input Class Initialized
INFO - 2018-04-05 19:47:58 --> Language Class Initialized
INFO - 2018-04-05 19:47:58 --> Loader Class Initialized
INFO - 2018-04-05 19:47:58 --> Helper loaded: url_helper
INFO - 2018-04-05 19:47:58 --> Helper loaded: form_helper
INFO - 2018-04-05 19:47:58 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:47:58 --> Form Validation Class Initialized
INFO - 2018-04-05 19:47:58 --> Model Class Initialized
INFO - 2018-04-05 19:47:58 --> Controller Class Initialized
INFO - 2018-04-05 19:47:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:47:58 --> Final output sent to browser
DEBUG - 2018-04-05 19:47:58 --> Total execution time: 0.0422
INFO - 2018-04-05 19:47:59 --> Config Class Initialized
INFO - 2018-04-05 19:47:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:47:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:47:59 --> Utf8 Class Initialized
INFO - 2018-04-05 19:47:59 --> URI Class Initialized
INFO - 2018-04-05 19:47:59 --> Router Class Initialized
INFO - 2018-04-05 19:47:59 --> Output Class Initialized
INFO - 2018-04-05 19:47:59 --> Security Class Initialized
DEBUG - 2018-04-05 19:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:47:59 --> Input Class Initialized
INFO - 2018-04-05 19:47:59 --> Language Class Initialized
INFO - 2018-04-05 19:47:59 --> Loader Class Initialized
INFO - 2018-04-05 19:47:59 --> Helper loaded: url_helper
INFO - 2018-04-05 19:47:59 --> Helper loaded: form_helper
INFO - 2018-04-05 19:47:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:47:59 --> Form Validation Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
INFO - 2018-04-05 19:47:59 --> Controller Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
INFO - 2018-04-05 19:47:59 --> Model Class Initialized
DEBUG - 2018-04-05 19:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:01 --> Config Class Initialized
INFO - 2018-04-05 19:48:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:01 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:01 --> URI Class Initialized
INFO - 2018-04-05 19:48:01 --> Router Class Initialized
INFO - 2018-04-05 19:48:01 --> Output Class Initialized
INFO - 2018-04-05 19:48:01 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:01 --> Input Class Initialized
INFO - 2018-04-05 19:48:01 --> Language Class Initialized
INFO - 2018-04-05 19:48:01 --> Loader Class Initialized
INFO - 2018-04-05 19:48:01 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:01 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:01 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:01 --> Model Class Initialized
INFO - 2018-04-05 19:48:01 --> Controller Class Initialized
INFO - 2018-04-05 19:48:01 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:01 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:01 --> Total execution time: 0.1116
INFO - 2018-04-05 19:48:01 --> Config Class Initialized
INFO - 2018-04-05 19:48:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:01 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:01 --> URI Class Initialized
INFO - 2018-04-05 19:48:01 --> Router Class Initialized
INFO - 2018-04-05 19:48:01 --> Output Class Initialized
INFO - 2018-04-05 19:48:01 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:01 --> Input Class Initialized
INFO - 2018-04-05 19:48:01 --> Language Class Initialized
INFO - 2018-04-05 19:48:01 --> Loader Class Initialized
INFO - 2018-04-05 19:48:01 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:01 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:01 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:01 --> Model Class Initialized
INFO - 2018-04-05 19:48:01 --> Controller Class Initialized
INFO - 2018-04-05 19:48:01 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:07 --> Config Class Initialized
INFO - 2018-04-05 19:48:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:07 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:07 --> URI Class Initialized
INFO - 2018-04-05 19:48:07 --> Router Class Initialized
INFO - 2018-04-05 19:48:07 --> Output Class Initialized
INFO - 2018-04-05 19:48:07 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:07 --> Input Class Initialized
INFO - 2018-04-05 19:48:07 --> Language Class Initialized
INFO - 2018-04-05 19:48:07 --> Loader Class Initialized
INFO - 2018-04-05 19:48:07 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:07 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:07 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:07 --> Model Class Initialized
INFO - 2018-04-05 19:48:07 --> Controller Class Initialized
INFO - 2018-04-05 19:48:07 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:07 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:07 --> Total execution time: 0.1043
INFO - 2018-04-05 19:48:24 --> Config Class Initialized
INFO - 2018-04-05 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:24 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:24 --> URI Class Initialized
INFO - 2018-04-05 19:48:24 --> Router Class Initialized
INFO - 2018-04-05 19:48:24 --> Output Class Initialized
INFO - 2018-04-05 19:48:24 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:24 --> Input Class Initialized
INFO - 2018-04-05 19:48:24 --> Language Class Initialized
INFO - 2018-04-05 19:48:24 --> Loader Class Initialized
INFO - 2018-04-05 19:48:24 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:24 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:24 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:24 --> Model Class Initialized
INFO - 2018-04-05 19:48:24 --> Controller Class Initialized
INFO - 2018-04-05 19:48:24 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:24 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:24 --> Total execution time: 0.0649
INFO - 2018-04-05 19:48:24 --> Config Class Initialized
INFO - 2018-04-05 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:24 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:24 --> URI Class Initialized
INFO - 2018-04-05 19:48:24 --> Router Class Initialized
INFO - 2018-04-05 19:48:24 --> Output Class Initialized
INFO - 2018-04-05 19:48:24 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:24 --> Input Class Initialized
INFO - 2018-04-05 19:48:24 --> Language Class Initialized
INFO - 2018-04-05 19:48:24 --> Loader Class Initialized
INFO - 2018-04-05 19:48:24 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:24 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:24 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:24 --> Model Class Initialized
INFO - 2018-04-05 19:48:24 --> Controller Class Initialized
INFO - 2018-04-05 19:48:24 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:27 --> Config Class Initialized
INFO - 2018-04-05 19:48:27 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:27 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:27 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:27 --> URI Class Initialized
INFO - 2018-04-05 19:48:27 --> Router Class Initialized
INFO - 2018-04-05 19:48:27 --> Output Class Initialized
INFO - 2018-04-05 19:48:27 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:27 --> Input Class Initialized
INFO - 2018-04-05 19:48:27 --> Language Class Initialized
INFO - 2018-04-05 19:48:27 --> Loader Class Initialized
INFO - 2018-04-05 19:48:27 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:27 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:27 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:27 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:27 --> Model Class Initialized
INFO - 2018-04-05 19:48:27 --> Controller Class Initialized
INFO - 2018-04-05 19:48:27 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:27 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:27 --> Total execution time: 0.0700
INFO - 2018-04-05 19:48:30 --> Config Class Initialized
INFO - 2018-04-05 19:48:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:30 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:30 --> URI Class Initialized
INFO - 2018-04-05 19:48:30 --> Router Class Initialized
INFO - 2018-04-05 19:48:30 --> Output Class Initialized
INFO - 2018-04-05 19:48:30 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:30 --> Input Class Initialized
INFO - 2018-04-05 19:48:30 --> Language Class Initialized
INFO - 2018-04-05 19:48:30 --> Loader Class Initialized
INFO - 2018-04-05 19:48:30 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:30 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:30 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:30 --> Model Class Initialized
INFO - 2018-04-05 19:48:30 --> Controller Class Initialized
INFO - 2018-04-05 19:48:30 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:30 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:30 --> Total execution time: 0.0772
INFO - 2018-04-05 19:48:30 --> Config Class Initialized
INFO - 2018-04-05 19:48:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:30 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:30 --> URI Class Initialized
INFO - 2018-04-05 19:48:30 --> Router Class Initialized
INFO - 2018-04-05 19:48:30 --> Output Class Initialized
INFO - 2018-04-05 19:48:30 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:30 --> Input Class Initialized
INFO - 2018-04-05 19:48:30 --> Language Class Initialized
INFO - 2018-04-05 19:48:30 --> Loader Class Initialized
INFO - 2018-04-05 19:48:30 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:30 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:30 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:30 --> Model Class Initialized
INFO - 2018-04-05 19:48:30 --> Controller Class Initialized
INFO - 2018-04-05 19:48:30 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:37 --> Config Class Initialized
INFO - 2018-04-05 19:48:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:37 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:37 --> URI Class Initialized
INFO - 2018-04-05 19:48:37 --> Router Class Initialized
INFO - 2018-04-05 19:48:37 --> Output Class Initialized
INFO - 2018-04-05 19:48:37 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:37 --> Input Class Initialized
INFO - 2018-04-05 19:48:37 --> Language Class Initialized
INFO - 2018-04-05 19:48:37 --> Loader Class Initialized
INFO - 2018-04-05 19:48:37 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:37 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:37 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:37 --> Model Class Initialized
INFO - 2018-04-05 19:48:37 --> Controller Class Initialized
INFO - 2018-04-05 19:48:37 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:37 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:37 --> Total execution time: 0.0559
INFO - 2018-04-05 19:48:37 --> Config Class Initialized
INFO - 2018-04-05 19:48:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:37 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:37 --> URI Class Initialized
INFO - 2018-04-05 19:48:37 --> Router Class Initialized
INFO - 2018-04-05 19:48:37 --> Output Class Initialized
INFO - 2018-04-05 19:48:37 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:37 --> Input Class Initialized
INFO - 2018-04-05 19:48:37 --> Language Class Initialized
INFO - 2018-04-05 19:48:37 --> Loader Class Initialized
INFO - 2018-04-05 19:48:37 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:37 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:37 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:37 --> Model Class Initialized
INFO - 2018-04-05 19:48:37 --> Controller Class Initialized
INFO - 2018-04-05 19:48:37 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:54 --> Config Class Initialized
INFO - 2018-04-05 19:48:54 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:48:54 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:48:54 --> Utf8 Class Initialized
INFO - 2018-04-05 19:48:54 --> URI Class Initialized
INFO - 2018-04-05 19:48:54 --> Router Class Initialized
INFO - 2018-04-05 19:48:54 --> Output Class Initialized
INFO - 2018-04-05 19:48:54 --> Security Class Initialized
DEBUG - 2018-04-05 19:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:48:54 --> Input Class Initialized
INFO - 2018-04-05 19:48:54 --> Language Class Initialized
INFO - 2018-04-05 19:48:54 --> Loader Class Initialized
INFO - 2018-04-05 19:48:54 --> Helper loaded: url_helper
INFO - 2018-04-05 19:48:54 --> Helper loaded: form_helper
INFO - 2018-04-05 19:48:54 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:48:54 --> Form Validation Class Initialized
INFO - 2018-04-05 19:48:54 --> Model Class Initialized
INFO - 2018-04-05 19:48:54 --> Controller Class Initialized
INFO - 2018-04-05 19:48:54 --> Model Class Initialized
DEBUG - 2018-04-05 19:48:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:48:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:48:54 --> Final output sent to browser
DEBUG - 2018-04-05 19:48:54 --> Total execution time: 0.0567
INFO - 2018-04-05 19:50:03 --> Config Class Initialized
INFO - 2018-04-05 19:50:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:03 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:03 --> URI Class Initialized
INFO - 2018-04-05 19:50:03 --> Router Class Initialized
INFO - 2018-04-05 19:50:03 --> Output Class Initialized
INFO - 2018-04-05 19:50:03 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:03 --> Input Class Initialized
INFO - 2018-04-05 19:50:03 --> Language Class Initialized
INFO - 2018-04-05 19:50:03 --> Loader Class Initialized
INFO - 2018-04-05 19:50:03 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:03 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:03 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:03 --> Model Class Initialized
INFO - 2018-04-05 19:50:03 --> Controller Class Initialized
INFO - 2018-04-05 19:50:03 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:50:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:50:03 --> Final output sent to browser
DEBUG - 2018-04-05 19:50:03 --> Total execution time: 0.5271
INFO - 2018-04-05 19:50:11 --> Config Class Initialized
INFO - 2018-04-05 19:50:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:11 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:11 --> URI Class Initialized
INFO - 2018-04-05 19:50:11 --> Router Class Initialized
INFO - 2018-04-05 19:50:11 --> Output Class Initialized
INFO - 2018-04-05 19:50:11 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:11 --> Input Class Initialized
INFO - 2018-04-05 19:50:11 --> Language Class Initialized
INFO - 2018-04-05 19:50:11 --> Loader Class Initialized
INFO - 2018-04-05 19:50:11 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:11 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:11 --> Model Class Initialized
INFO - 2018-04-05 19:50:11 --> Controller Class Initialized
INFO - 2018-04-05 19:50:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:50:11 --> Config Class Initialized
INFO - 2018-04-05 19:50:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:11 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:11 --> URI Class Initialized
INFO - 2018-04-05 19:50:11 --> Router Class Initialized
INFO - 2018-04-05 19:50:11 --> Output Class Initialized
INFO - 2018-04-05 19:50:11 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:11 --> Input Class Initialized
INFO - 2018-04-05 19:50:11 --> Language Class Initialized
INFO - 2018-04-05 19:50:11 --> Loader Class Initialized
INFO - 2018-04-05 19:50:11 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:11 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:11 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:11 --> Model Class Initialized
INFO - 2018-04-05 19:50:11 --> Controller Class Initialized
INFO - 2018-04-05 19:50:11 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:50:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:50:11 --> Final output sent to browser
DEBUG - 2018-04-05 19:50:11 --> Total execution time: 0.0440
INFO - 2018-04-05 19:50:26 --> Config Class Initialized
INFO - 2018-04-05 19:50:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:26 --> URI Class Initialized
INFO - 2018-04-05 19:50:26 --> Router Class Initialized
INFO - 2018-04-05 19:50:26 --> Output Class Initialized
INFO - 2018-04-05 19:50:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:26 --> Input Class Initialized
INFO - 2018-04-05 19:50:26 --> Language Class Initialized
INFO - 2018-04-05 19:50:26 --> Loader Class Initialized
INFO - 2018-04-05 19:50:26 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:26 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:26 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Controller Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:50:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 19:50:26 --> Config Class Initialized
INFO - 2018-04-05 19:50:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:26 --> URI Class Initialized
DEBUG - 2018-04-05 19:50:26 --> No URI present. Default controller set.
INFO - 2018-04-05 19:50:26 --> Router Class Initialized
INFO - 2018-04-05 19:50:26 --> Output Class Initialized
INFO - 2018-04-05 19:50:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:26 --> Input Class Initialized
INFO - 2018-04-05 19:50:26 --> Language Class Initialized
INFO - 2018-04-05 19:50:26 --> Loader Class Initialized
INFO - 2018-04-05 19:50:26 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:26 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:26 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Controller Class Initialized
INFO - 2018-04-05 19:50:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:50:26 --> Final output sent to browser
DEBUG - 2018-04-05 19:50:26 --> Total execution time: 0.0578
INFO - 2018-04-05 19:50:26 --> Config Class Initialized
INFO - 2018-04-05 19:50:26 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:26 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:26 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:26 --> URI Class Initialized
INFO - 2018-04-05 19:50:26 --> Router Class Initialized
INFO - 2018-04-05 19:50:26 --> Output Class Initialized
INFO - 2018-04-05 19:50:26 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:26 --> Input Class Initialized
INFO - 2018-04-05 19:50:26 --> Language Class Initialized
INFO - 2018-04-05 19:50:26 --> Loader Class Initialized
INFO - 2018-04-05 19:50:26 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:26 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:26 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:26 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Controller Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
INFO - 2018-04-05 19:50:26 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 19:50:53 --> Config Class Initialized
INFO - 2018-04-05 19:50:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:53 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:53 --> URI Class Initialized
DEBUG - 2018-04-05 19:50:53 --> No URI present. Default controller set.
INFO - 2018-04-05 19:50:53 --> Router Class Initialized
INFO - 2018-04-05 19:50:53 --> Output Class Initialized
INFO - 2018-04-05 19:50:53 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:53 --> Input Class Initialized
INFO - 2018-04-05 19:50:53 --> Language Class Initialized
INFO - 2018-04-05 19:50:53 --> Loader Class Initialized
INFO - 2018-04-05 19:50:53 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:53 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:53 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Controller Class Initialized
INFO - 2018-04-05 19:50:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 19:50:53 --> Final output sent to browser
DEBUG - 2018-04-05 19:50:53 --> Total execution time: 0.0593
INFO - 2018-04-05 19:50:53 --> Config Class Initialized
INFO - 2018-04-05 19:50:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 19:50:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 19:50:53 --> Utf8 Class Initialized
INFO - 2018-04-05 19:50:53 --> URI Class Initialized
INFO - 2018-04-05 19:50:53 --> Router Class Initialized
INFO - 2018-04-05 19:50:53 --> Output Class Initialized
INFO - 2018-04-05 19:50:53 --> Security Class Initialized
DEBUG - 2018-04-05 19:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 19:50:53 --> Input Class Initialized
INFO - 2018-04-05 19:50:53 --> Language Class Initialized
INFO - 2018-04-05 19:50:53 --> Loader Class Initialized
INFO - 2018-04-05 19:50:53 --> Helper loaded: url_helper
INFO - 2018-04-05 19:50:53 --> Helper loaded: form_helper
INFO - 2018-04-05 19:50:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 19:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 19:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 19:50:53 --> Form Validation Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Controller Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
INFO - 2018-04-05 19:50:53 --> Model Class Initialized
DEBUG - 2018-04-05 19:50:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:03:43 --> Config Class Initialized
INFO - 2018-04-05 20:03:43 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:03:43 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:03:43 --> Utf8 Class Initialized
INFO - 2018-04-05 20:03:43 --> URI Class Initialized
INFO - 2018-04-05 20:03:43 --> Router Class Initialized
INFO - 2018-04-05 20:03:43 --> Output Class Initialized
INFO - 2018-04-05 20:03:43 --> Security Class Initialized
DEBUG - 2018-04-05 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:03:43 --> Input Class Initialized
INFO - 2018-04-05 20:03:43 --> Language Class Initialized
INFO - 2018-04-05 20:03:43 --> Loader Class Initialized
INFO - 2018-04-05 20:03:43 --> Helper loaded: url_helper
INFO - 2018-04-05 20:03:43 --> Helper loaded: form_helper
INFO - 2018-04-05 20:03:43 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:03:43 --> Form Validation Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
INFO - 2018-04-05 20:03:43 --> Controller Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
INFO - 2018-04-05 20:03:43 --> Model Class Initialized
DEBUG - 2018-04-05 20:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:03:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:03:43 --> Final output sent to browser
DEBUG - 2018-04-05 20:03:43 --> Total execution time: 0.0531
INFO - 2018-04-05 20:06:28 --> Config Class Initialized
INFO - 2018-04-05 20:06:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:06:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:06:28 --> Utf8 Class Initialized
INFO - 2018-04-05 20:06:28 --> URI Class Initialized
INFO - 2018-04-05 20:06:28 --> Router Class Initialized
INFO - 2018-04-05 20:06:28 --> Output Class Initialized
INFO - 2018-04-05 20:06:28 --> Security Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:06:28 --> Input Class Initialized
INFO - 2018-04-05 20:06:28 --> Language Class Initialized
INFO - 2018-04-05 20:06:28 --> Loader Class Initialized
INFO - 2018-04-05 20:06:28 --> Helper loaded: url_helper
INFO - 2018-04-05 20:06:28 --> Helper loaded: form_helper
INFO - 2018-04-05 20:06:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:06:28 --> Form Validation Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Controller Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:06:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:06:28 --> Final output sent to browser
DEBUG - 2018-04-05 20:06:28 --> Total execution time: 0.0680
INFO - 2018-04-05 20:06:28 --> Config Class Initialized
INFO - 2018-04-05 20:06:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:06:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:06:28 --> Utf8 Class Initialized
INFO - 2018-04-05 20:06:28 --> URI Class Initialized
INFO - 2018-04-05 20:06:28 --> Router Class Initialized
INFO - 2018-04-05 20:06:28 --> Output Class Initialized
INFO - 2018-04-05 20:06:28 --> Security Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:06:28 --> Input Class Initialized
INFO - 2018-04-05 20:06:28 --> Language Class Initialized
INFO - 2018-04-05 20:06:28 --> Loader Class Initialized
INFO - 2018-04-05 20:06:28 --> Helper loaded: url_helper
INFO - 2018-04-05 20:06:28 --> Helper loaded: form_helper
INFO - 2018-04-05 20:06:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:06:28 --> Form Validation Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Controller Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
INFO - 2018-04-05 20:06:28 --> Model Class Initialized
DEBUG - 2018-04-05 20:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:06:30 --> Config Class Initialized
INFO - 2018-04-05 20:06:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:06:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:06:30 --> Utf8 Class Initialized
INFO - 2018-04-05 20:06:30 --> URI Class Initialized
INFO - 2018-04-05 20:06:30 --> Router Class Initialized
INFO - 2018-04-05 20:06:30 --> Output Class Initialized
INFO - 2018-04-05 20:06:30 --> Security Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:06:30 --> Input Class Initialized
INFO - 2018-04-05 20:06:30 --> Language Class Initialized
INFO - 2018-04-05 20:06:30 --> Loader Class Initialized
INFO - 2018-04-05 20:06:30 --> Helper loaded: url_helper
INFO - 2018-04-05 20:06:30 --> Helper loaded: form_helper
INFO - 2018-04-05 20:06:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:06:30 --> Form Validation Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Controller Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:06:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:06:30 --> Final output sent to browser
DEBUG - 2018-04-05 20:06:30 --> Total execution time: 0.0725
INFO - 2018-04-05 20:06:30 --> Config Class Initialized
INFO - 2018-04-05 20:06:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:06:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:06:30 --> Utf8 Class Initialized
INFO - 2018-04-05 20:06:30 --> URI Class Initialized
INFO - 2018-04-05 20:06:30 --> Router Class Initialized
INFO - 2018-04-05 20:06:30 --> Output Class Initialized
INFO - 2018-04-05 20:06:30 --> Security Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:06:30 --> Input Class Initialized
INFO - 2018-04-05 20:06:30 --> Language Class Initialized
INFO - 2018-04-05 20:06:30 --> Loader Class Initialized
INFO - 2018-04-05 20:06:30 --> Helper loaded: url_helper
INFO - 2018-04-05 20:06:30 --> Helper loaded: form_helper
INFO - 2018-04-05 20:06:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:06:30 --> Form Validation Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Controller Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
INFO - 2018-04-05 20:06:30 --> Model Class Initialized
DEBUG - 2018-04-05 20:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:08 --> Config Class Initialized
INFO - 2018-04-05 20:14:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:08 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:08 --> URI Class Initialized
INFO - 2018-04-05 20:14:08 --> Router Class Initialized
INFO - 2018-04-05 20:14:08 --> Output Class Initialized
INFO - 2018-04-05 20:14:08 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:08 --> Input Class Initialized
INFO - 2018-04-05 20:14:08 --> Language Class Initialized
INFO - 2018-04-05 20:14:08 --> Loader Class Initialized
INFO - 2018-04-05 20:14:08 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:08 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:08 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:08 --> Model Class Initialized
INFO - 2018-04-05 20:14:08 --> Controller Class Initialized
INFO - 2018-04-05 20:14:08 --> Model Class Initialized
INFO - 2018-04-05 20:14:08 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:14:08 --> Final output sent to browser
DEBUG - 2018-04-05 20:14:08 --> Total execution time: 0.3775
INFO - 2018-04-05 20:14:08 --> Config Class Initialized
INFO - 2018-04-05 20:14:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:09 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:09 --> URI Class Initialized
INFO - 2018-04-05 20:14:09 --> Router Class Initialized
INFO - 2018-04-05 20:14:09 --> Output Class Initialized
INFO - 2018-04-05 20:14:09 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:09 --> Input Class Initialized
INFO - 2018-04-05 20:14:09 --> Language Class Initialized
INFO - 2018-04-05 20:14:09 --> Loader Class Initialized
INFO - 2018-04-05 20:14:09 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:09 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:09 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:09 --> Model Class Initialized
INFO - 2018-04-05 20:14:09 --> Controller Class Initialized
INFO - 2018-04-05 20:14:09 --> Model Class Initialized
INFO - 2018-04-05 20:14:09 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:11 --> Config Class Initialized
INFO - 2018-04-05 20:14:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:11 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:11 --> URI Class Initialized
INFO - 2018-04-05 20:14:11 --> Router Class Initialized
INFO - 2018-04-05 20:14:11 --> Output Class Initialized
INFO - 2018-04-05 20:14:11 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:11 --> Input Class Initialized
INFO - 2018-04-05 20:14:11 --> Language Class Initialized
INFO - 2018-04-05 20:14:11 --> Loader Class Initialized
INFO - 2018-04-05 20:14:11 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:11 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:11 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
INFO - 2018-04-05 20:14:11 --> Controller Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:14:11 --> Final output sent to browser
DEBUG - 2018-04-05 20:14:11 --> Total execution time: 0.1306
INFO - 2018-04-05 20:14:11 --> Config Class Initialized
INFO - 2018-04-05 20:14:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:11 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:11 --> URI Class Initialized
INFO - 2018-04-05 20:14:11 --> Router Class Initialized
INFO - 2018-04-05 20:14:11 --> Output Class Initialized
INFO - 2018-04-05 20:14:11 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:11 --> Input Class Initialized
INFO - 2018-04-05 20:14:11 --> Language Class Initialized
INFO - 2018-04-05 20:14:11 --> Loader Class Initialized
INFO - 2018-04-05 20:14:11 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:11 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:11 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
INFO - 2018-04-05 20:14:11 --> Controller Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
INFO - 2018-04-05 20:14:11 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:13 --> Config Class Initialized
INFO - 2018-04-05 20:14:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:13 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:13 --> URI Class Initialized
INFO - 2018-04-05 20:14:13 --> Router Class Initialized
INFO - 2018-04-05 20:14:13 --> Output Class Initialized
INFO - 2018-04-05 20:14:13 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:13 --> Input Class Initialized
INFO - 2018-04-05 20:14:13 --> Language Class Initialized
INFO - 2018-04-05 20:14:13 --> Loader Class Initialized
INFO - 2018-04-05 20:14:13 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:13 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:13 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:13 --> Model Class Initialized
INFO - 2018-04-05 20:14:13 --> Controller Class Initialized
INFO - 2018-04-05 20:14:13 --> Model Class Initialized
INFO - 2018-04-05 20:14:13 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:14:13 --> Final output sent to browser
DEBUG - 2018-04-05 20:14:13 --> Total execution time: 0.1124
INFO - 2018-04-05 20:14:47 --> Config Class Initialized
INFO - 2018-04-05 20:14:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:47 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:48 --> URI Class Initialized
INFO - 2018-04-05 20:14:48 --> Router Class Initialized
INFO - 2018-04-05 20:14:48 --> Output Class Initialized
INFO - 2018-04-05 20:14:48 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:48 --> Input Class Initialized
INFO - 2018-04-05 20:14:48 --> Language Class Initialized
INFO - 2018-04-05 20:14:48 --> Loader Class Initialized
INFO - 2018-04-05 20:14:48 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:48 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:48 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
INFO - 2018-04-05 20:14:48 --> Controller Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:14:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:14:48 --> Final output sent to browser
DEBUG - 2018-04-05 20:14:48 --> Total execution time: 0.0710
INFO - 2018-04-05 20:14:48 --> Config Class Initialized
INFO - 2018-04-05 20:14:48 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:14:48 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:14:48 --> Utf8 Class Initialized
INFO - 2018-04-05 20:14:48 --> URI Class Initialized
INFO - 2018-04-05 20:14:48 --> Router Class Initialized
INFO - 2018-04-05 20:14:48 --> Output Class Initialized
INFO - 2018-04-05 20:14:48 --> Security Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:14:48 --> Input Class Initialized
INFO - 2018-04-05 20:14:48 --> Language Class Initialized
INFO - 2018-04-05 20:14:48 --> Loader Class Initialized
INFO - 2018-04-05 20:14:48 --> Helper loaded: url_helper
INFO - 2018-04-05 20:14:48 --> Helper loaded: form_helper
INFO - 2018-04-05 20:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:14:48 --> Form Validation Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
INFO - 2018-04-05 20:14:48 --> Controller Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
INFO - 2018-04-05 20:14:48 --> Model Class Initialized
DEBUG - 2018-04-05 20:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:06 --> Config Class Initialized
INFO - 2018-04-05 20:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:06 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:06 --> URI Class Initialized
INFO - 2018-04-05 20:16:06 --> Router Class Initialized
INFO - 2018-04-05 20:16:06 --> Output Class Initialized
INFO - 2018-04-05 20:16:06 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:06 --> Input Class Initialized
INFO - 2018-04-05 20:16:06 --> Language Class Initialized
INFO - 2018-04-05 20:16:06 --> Loader Class Initialized
INFO - 2018-04-05 20:16:06 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:06 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:06 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
INFO - 2018-04-05 20:16:06 --> Controller Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
INFO - 2018-04-05 20:16:06 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:16:06 --> Final output sent to browser
DEBUG - 2018-04-05 20:16:06 --> Total execution time: 0.0722
INFO - 2018-04-05 20:16:06 --> Config Class Initialized
INFO - 2018-04-05 20:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:06 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:06 --> URI Class Initialized
INFO - 2018-04-05 20:16:06 --> Router Class Initialized
INFO - 2018-04-05 20:16:06 --> Output Class Initialized
INFO - 2018-04-05 20:16:06 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:06 --> Input Class Initialized
INFO - 2018-04-05 20:16:06 --> Language Class Initialized
INFO - 2018-04-05 20:16:06 --> Loader Class Initialized
INFO - 2018-04-05 20:16:06 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:06 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:06 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:07 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
INFO - 2018-04-05 20:16:07 --> Controller Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
INFO - 2018-04-05 20:16:07 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:08 --> Config Class Initialized
INFO - 2018-04-05 20:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:08 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:08 --> URI Class Initialized
INFO - 2018-04-05 20:16:08 --> Router Class Initialized
INFO - 2018-04-05 20:16:08 --> Output Class Initialized
INFO - 2018-04-05 20:16:08 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:08 --> Input Class Initialized
INFO - 2018-04-05 20:16:08 --> Language Class Initialized
INFO - 2018-04-05 20:16:08 --> Loader Class Initialized
INFO - 2018-04-05 20:16:08 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:08 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:08 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Controller Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:16:08 --> Final output sent to browser
DEBUG - 2018-04-05 20:16:08 --> Total execution time: 0.0703
INFO - 2018-04-05 20:16:08 --> Config Class Initialized
INFO - 2018-04-05 20:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:08 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:08 --> URI Class Initialized
INFO - 2018-04-05 20:16:08 --> Router Class Initialized
INFO - 2018-04-05 20:16:08 --> Output Class Initialized
INFO - 2018-04-05 20:16:08 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:08 --> Input Class Initialized
INFO - 2018-04-05 20:16:08 --> Language Class Initialized
INFO - 2018-04-05 20:16:08 --> Loader Class Initialized
INFO - 2018-04-05 20:16:08 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:08 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:08 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Controller Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
INFO - 2018-04-05 20:16:08 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:10 --> Config Class Initialized
INFO - 2018-04-05 20:16:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:10 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:10 --> URI Class Initialized
INFO - 2018-04-05 20:16:10 --> Router Class Initialized
INFO - 2018-04-05 20:16:10 --> Output Class Initialized
INFO - 2018-04-05 20:16:10 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:10 --> Input Class Initialized
INFO - 2018-04-05 20:16:10 --> Language Class Initialized
INFO - 2018-04-05 20:16:10 --> Loader Class Initialized
INFO - 2018-04-05 20:16:10 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:10 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:10 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Controller Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:16:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:16:10 --> Final output sent to browser
DEBUG - 2018-04-05 20:16:10 --> Total execution time: 0.0718
INFO - 2018-04-05 20:16:10 --> Config Class Initialized
INFO - 2018-04-05 20:16:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:16:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:16:10 --> Utf8 Class Initialized
INFO - 2018-04-05 20:16:10 --> URI Class Initialized
INFO - 2018-04-05 20:16:10 --> Router Class Initialized
INFO - 2018-04-05 20:16:10 --> Output Class Initialized
INFO - 2018-04-05 20:16:10 --> Security Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:16:10 --> Input Class Initialized
INFO - 2018-04-05 20:16:10 --> Language Class Initialized
INFO - 2018-04-05 20:16:10 --> Loader Class Initialized
INFO - 2018-04-05 20:16:10 --> Helper loaded: url_helper
INFO - 2018-04-05 20:16:10 --> Helper loaded: form_helper
INFO - 2018-04-05 20:16:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:16:10 --> Form Validation Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Controller Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
INFO - 2018-04-05 20:16:10 --> Model Class Initialized
DEBUG - 2018-04-05 20:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:47 --> Config Class Initialized
INFO - 2018-04-05 20:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:47 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:47 --> URI Class Initialized
INFO - 2018-04-05 20:23:47 --> Router Class Initialized
INFO - 2018-04-05 20:23:47 --> Output Class Initialized
INFO - 2018-04-05 20:23:47 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:47 --> Input Class Initialized
INFO - 2018-04-05 20:23:47 --> Language Class Initialized
INFO - 2018-04-05 20:23:47 --> Loader Class Initialized
INFO - 2018-04-05 20:23:47 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:47 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:47 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Controller Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:23:47 --> Final output sent to browser
DEBUG - 2018-04-05 20:23:47 --> Total execution time: 0.0724
INFO - 2018-04-05 20:23:47 --> Config Class Initialized
INFO - 2018-04-05 20:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:47 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:47 --> URI Class Initialized
INFO - 2018-04-05 20:23:47 --> Router Class Initialized
INFO - 2018-04-05 20:23:47 --> Output Class Initialized
INFO - 2018-04-05 20:23:47 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:47 --> Input Class Initialized
INFO - 2018-04-05 20:23:47 --> Language Class Initialized
INFO - 2018-04-05 20:23:47 --> Loader Class Initialized
INFO - 2018-04-05 20:23:47 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:47 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:47 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:47 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Controller Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
INFO - 2018-04-05 20:23:47 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:49 --> Config Class Initialized
INFO - 2018-04-05 20:23:49 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:49 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:49 --> URI Class Initialized
INFO - 2018-04-05 20:23:49 --> Router Class Initialized
INFO - 2018-04-05 20:23:49 --> Output Class Initialized
INFO - 2018-04-05 20:23:49 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:49 --> Input Class Initialized
INFO - 2018-04-05 20:23:49 --> Language Class Initialized
INFO - 2018-04-05 20:23:49 --> Loader Class Initialized
INFO - 2018-04-05 20:23:49 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:49 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:49 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:49 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Controller Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:23:49 --> Final output sent to browser
DEBUG - 2018-04-05 20:23:49 --> Total execution time: 0.0717
INFO - 2018-04-05 20:23:49 --> Config Class Initialized
INFO - 2018-04-05 20:23:49 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:49 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:49 --> URI Class Initialized
INFO - 2018-04-05 20:23:49 --> Router Class Initialized
INFO - 2018-04-05 20:23:49 --> Output Class Initialized
INFO - 2018-04-05 20:23:49 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:49 --> Input Class Initialized
INFO - 2018-04-05 20:23:49 --> Language Class Initialized
INFO - 2018-04-05 20:23:49 --> Loader Class Initialized
INFO - 2018-04-05 20:23:49 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:49 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:49 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:49 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Controller Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
INFO - 2018-04-05 20:23:49 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:50 --> Config Class Initialized
INFO - 2018-04-05 20:23:50 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:50 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:50 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:50 --> URI Class Initialized
INFO - 2018-04-05 20:23:50 --> Router Class Initialized
INFO - 2018-04-05 20:23:50 --> Output Class Initialized
INFO - 2018-04-05 20:23:50 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:50 --> Input Class Initialized
INFO - 2018-04-05 20:23:50 --> Language Class Initialized
INFO - 2018-04-05 20:23:50 --> Loader Class Initialized
INFO - 2018-04-05 20:23:50 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:50 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:50 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:50 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
INFO - 2018-04-05 20:23:50 --> Controller Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
INFO - 2018-04-05 20:23:50 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:23:51 --> Final output sent to browser
DEBUG - 2018-04-05 20:23:51 --> Total execution time: 0.3618
INFO - 2018-04-05 20:23:51 --> Config Class Initialized
INFO - 2018-04-05 20:23:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:51 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:51 --> URI Class Initialized
INFO - 2018-04-05 20:23:51 --> Router Class Initialized
INFO - 2018-04-05 20:23:51 --> Output Class Initialized
INFO - 2018-04-05 20:23:51 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:51 --> Input Class Initialized
INFO - 2018-04-05 20:23:51 --> Language Class Initialized
INFO - 2018-04-05 20:23:51 --> Loader Class Initialized
INFO - 2018-04-05 20:23:51 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:51 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:51 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
INFO - 2018-04-05 20:23:51 --> Controller Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
INFO - 2018-04-05 20:23:51 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:53 --> Config Class Initialized
INFO - 2018-04-05 20:23:53 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:23:53 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:23:53 --> Utf8 Class Initialized
INFO - 2018-04-05 20:23:53 --> URI Class Initialized
INFO - 2018-04-05 20:23:53 --> Router Class Initialized
INFO - 2018-04-05 20:23:53 --> Output Class Initialized
INFO - 2018-04-05 20:23:53 --> Security Class Initialized
DEBUG - 2018-04-05 20:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:23:53 --> Input Class Initialized
INFO - 2018-04-05 20:23:53 --> Language Class Initialized
INFO - 2018-04-05 20:23:53 --> Loader Class Initialized
INFO - 2018-04-05 20:23:53 --> Helper loaded: url_helper
INFO - 2018-04-05 20:23:53 --> Helper loaded: form_helper
INFO - 2018-04-05 20:23:53 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:23:53 --> Form Validation Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
INFO - 2018-04-05 20:23:53 --> Controller Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
INFO - 2018-04-05 20:23:53 --> Model Class Initialized
DEBUG - 2018-04-05 20:23:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:23:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:23:53 --> Final output sent to browser
DEBUG - 2018-04-05 20:23:53 --> Total execution time: 0.1021
INFO - 2018-04-05 20:24:12 --> Config Class Initialized
INFO - 2018-04-05 20:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:12 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:12 --> URI Class Initialized
INFO - 2018-04-05 20:24:12 --> Router Class Initialized
INFO - 2018-04-05 20:24:12 --> Output Class Initialized
INFO - 2018-04-05 20:24:12 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:12 --> Input Class Initialized
INFO - 2018-04-05 20:24:12 --> Language Class Initialized
INFO - 2018-04-05 20:24:12 --> Loader Class Initialized
INFO - 2018-04-05 20:24:12 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:12 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:12 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Controller Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:24:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:24:12 --> Final output sent to browser
DEBUG - 2018-04-05 20:24:12 --> Total execution time: 0.0701
INFO - 2018-04-05 20:24:12 --> Config Class Initialized
INFO - 2018-04-05 20:24:12 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:12 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:12 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:12 --> URI Class Initialized
INFO - 2018-04-05 20:24:12 --> Router Class Initialized
INFO - 2018-04-05 20:24:12 --> Output Class Initialized
INFO - 2018-04-05 20:24:12 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:12 --> Input Class Initialized
INFO - 2018-04-05 20:24:12 --> Language Class Initialized
INFO - 2018-04-05 20:24:12 --> Loader Class Initialized
INFO - 2018-04-05 20:24:12 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:12 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:12 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:12 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Controller Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
INFO - 2018-04-05 20:24:12 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:24:13 --> Config Class Initialized
INFO - 2018-04-05 20:24:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:13 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:13 --> URI Class Initialized
INFO - 2018-04-05 20:24:13 --> Router Class Initialized
INFO - 2018-04-05 20:24:13 --> Output Class Initialized
INFO - 2018-04-05 20:24:13 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:13 --> Input Class Initialized
INFO - 2018-04-05 20:24:13 --> Language Class Initialized
INFO - 2018-04-05 20:24:13 --> Loader Class Initialized
INFO - 2018-04-05 20:24:13 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:13 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:13 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Controller Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:24:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:24:13 --> Final output sent to browser
DEBUG - 2018-04-05 20:24:13 --> Total execution time: 0.0752
INFO - 2018-04-05 20:24:13 --> Config Class Initialized
INFO - 2018-04-05 20:24:13 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:13 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:13 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:13 --> URI Class Initialized
INFO - 2018-04-05 20:24:13 --> Router Class Initialized
INFO - 2018-04-05 20:24:13 --> Output Class Initialized
INFO - 2018-04-05 20:24:13 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:13 --> Input Class Initialized
INFO - 2018-04-05 20:24:13 --> Language Class Initialized
INFO - 2018-04-05 20:24:13 --> Loader Class Initialized
INFO - 2018-04-05 20:24:13 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:13 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:13 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:13 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Controller Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
INFO - 2018-04-05 20:24:13 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:24:21 --> Config Class Initialized
INFO - 2018-04-05 20:24:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:21 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:21 --> URI Class Initialized
INFO - 2018-04-05 20:24:21 --> Router Class Initialized
INFO - 2018-04-05 20:24:21 --> Output Class Initialized
INFO - 2018-04-05 20:24:21 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:21 --> Input Class Initialized
INFO - 2018-04-05 20:24:21 --> Language Class Initialized
INFO - 2018-04-05 20:24:21 --> Loader Class Initialized
INFO - 2018-04-05 20:24:21 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:21 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:21 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Controller Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 20:24:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 20:24:21 --> Final output sent to browser
DEBUG - 2018-04-05 20:24:21 --> Total execution time: 0.0995
INFO - 2018-04-05 20:24:21 --> Config Class Initialized
INFO - 2018-04-05 20:24:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 20:24:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 20:24:21 --> Utf8 Class Initialized
INFO - 2018-04-05 20:24:21 --> URI Class Initialized
INFO - 2018-04-05 20:24:21 --> Router Class Initialized
INFO - 2018-04-05 20:24:21 --> Output Class Initialized
INFO - 2018-04-05 20:24:21 --> Security Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 20:24:21 --> Input Class Initialized
INFO - 2018-04-05 20:24:21 --> Language Class Initialized
INFO - 2018-04-05 20:24:21 --> Loader Class Initialized
INFO - 2018-04-05 20:24:21 --> Helper loaded: url_helper
INFO - 2018-04-05 20:24:21 --> Helper loaded: form_helper
INFO - 2018-04-05 20:24:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 20:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 20:24:21 --> Form Validation Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Controller Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
INFO - 2018-04-05 20:24:21 --> Model Class Initialized
DEBUG - 2018-04-05 20:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:19 --> Config Class Initialized
INFO - 2018-04-05 22:37:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:19 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:19 --> URI Class Initialized
INFO - 2018-04-05 22:37:19 --> Router Class Initialized
INFO - 2018-04-05 22:37:19 --> Output Class Initialized
INFO - 2018-04-05 22:37:19 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:19 --> Input Class Initialized
INFO - 2018-04-05 22:37:19 --> Language Class Initialized
INFO - 2018-04-05 22:37:19 --> Loader Class Initialized
INFO - 2018-04-05 22:37:19 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:19 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:19 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Controller Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:19 --> Config Class Initialized
INFO - 2018-04-05 22:37:19 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:19 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:19 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:19 --> URI Class Initialized
INFO - 2018-04-05 22:37:19 --> Router Class Initialized
INFO - 2018-04-05 22:37:19 --> Output Class Initialized
INFO - 2018-04-05 22:37:19 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:19 --> Input Class Initialized
INFO - 2018-04-05 22:37:19 --> Language Class Initialized
INFO - 2018-04-05 22:37:19 --> Loader Class Initialized
INFO - 2018-04-05 22:37:19 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:19 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:19 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:19 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
INFO - 2018-04-05 22:37:19 --> Controller Class Initialized
INFO - 2018-04-05 22:37:19 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:19 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:19 --> Total execution time: 0.0333
INFO - 2018-04-05 22:37:21 --> Config Class Initialized
INFO - 2018-04-05 22:37:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:21 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:21 --> URI Class Initialized
INFO - 2018-04-05 22:37:21 --> Router Class Initialized
INFO - 2018-04-05 22:37:21 --> Output Class Initialized
INFO - 2018-04-05 22:37:21 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:21 --> Input Class Initialized
INFO - 2018-04-05 22:37:21 --> Language Class Initialized
INFO - 2018-04-05 22:37:21 --> Loader Class Initialized
INFO - 2018-04-05 22:37:21 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:21 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:21 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:21 --> Model Class Initialized
INFO - 2018-04-05 22:37:21 --> Controller Class Initialized
INFO - 2018-04-05 22:37:21 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-05 22:37:23 --> Config Class Initialized
INFO - 2018-04-05 22:37:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:23 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:23 --> URI Class Initialized
DEBUG - 2018-04-05 22:37:23 --> No URI present. Default controller set.
INFO - 2018-04-05 22:37:23 --> Router Class Initialized
INFO - 2018-04-05 22:37:23 --> Output Class Initialized
INFO - 2018-04-05 22:37:23 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:23 --> Input Class Initialized
INFO - 2018-04-05 22:37:23 --> Language Class Initialized
INFO - 2018-04-05 22:37:23 --> Loader Class Initialized
INFO - 2018-04-05 22:37:23 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:23 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:23 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:23 --> Model Class Initialized
INFO - 2018-04-05 22:37:23 --> Controller Class Initialized
INFO - 2018-04-05 22:37:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:23 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:23 --> Total execution time: 0.0453
INFO - 2018-04-05 22:37:23 --> Config Class Initialized
INFO - 2018-04-05 22:37:23 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:23 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:23 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:23 --> URI Class Initialized
INFO - 2018-04-05 22:37:23 --> Router Class Initialized
INFO - 2018-04-05 22:37:23 --> Output Class Initialized
INFO - 2018-04-05 22:37:23 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:23 --> Input Class Initialized
INFO - 2018-04-05 22:37:23 --> Language Class Initialized
INFO - 2018-04-05 22:37:23 --> Loader Class Initialized
INFO - 2018-04-05 22:37:23 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:23 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:23 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:24 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
INFO - 2018-04-05 22:37:24 --> Controller Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
INFO - 2018-04-05 22:37:24 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:25 --> Config Class Initialized
INFO - 2018-04-05 22:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:25 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:25 --> URI Class Initialized
INFO - 2018-04-05 22:37:25 --> Router Class Initialized
INFO - 2018-04-05 22:37:25 --> Output Class Initialized
INFO - 2018-04-05 22:37:25 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:25 --> Input Class Initialized
INFO - 2018-04-05 22:37:25 --> Language Class Initialized
INFO - 2018-04-05 22:37:25 --> Loader Class Initialized
INFO - 2018-04-05 22:37:25 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:25 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:25 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Controller Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:25 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:25 --> Total execution time: 0.0605
INFO - 2018-04-05 22:37:25 --> Config Class Initialized
INFO - 2018-04-05 22:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:25 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:25 --> URI Class Initialized
INFO - 2018-04-05 22:37:25 --> Router Class Initialized
INFO - 2018-04-05 22:37:25 --> Output Class Initialized
INFO - 2018-04-05 22:37:25 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:25 --> Input Class Initialized
INFO - 2018-04-05 22:37:25 --> Language Class Initialized
INFO - 2018-04-05 22:37:25 --> Loader Class Initialized
INFO - 2018-04-05 22:37:25 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:25 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:25 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Controller Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
INFO - 2018-04-05 22:37:25 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:29 --> Config Class Initialized
INFO - 2018-04-05 22:37:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:29 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:29 --> URI Class Initialized
INFO - 2018-04-05 22:37:29 --> Router Class Initialized
INFO - 2018-04-05 22:37:29 --> Output Class Initialized
INFO - 2018-04-05 22:37:29 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:29 --> Input Class Initialized
INFO - 2018-04-05 22:37:29 --> Language Class Initialized
INFO - 2018-04-05 22:37:29 --> Loader Class Initialized
INFO - 2018-04-05 22:37:29 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:29 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:29 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Controller Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:29 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:29 --> Total execution time: 0.0650
INFO - 2018-04-05 22:37:29 --> Config Class Initialized
INFO - 2018-04-05 22:37:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:29 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:29 --> URI Class Initialized
INFO - 2018-04-05 22:37:29 --> Router Class Initialized
INFO - 2018-04-05 22:37:29 --> Output Class Initialized
INFO - 2018-04-05 22:37:29 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:29 --> Input Class Initialized
INFO - 2018-04-05 22:37:29 --> Language Class Initialized
INFO - 2018-04-05 22:37:29 --> Loader Class Initialized
INFO - 2018-04-05 22:37:29 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:29 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:29 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Controller Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
INFO - 2018-04-05 22:37:29 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:36 --> Config Class Initialized
INFO - 2018-04-05 22:37:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:36 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:36 --> URI Class Initialized
INFO - 2018-04-05 22:37:36 --> Router Class Initialized
INFO - 2018-04-05 22:37:36 --> Output Class Initialized
INFO - 2018-04-05 22:37:36 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:36 --> Input Class Initialized
INFO - 2018-04-05 22:37:36 --> Language Class Initialized
INFO - 2018-04-05 22:37:36 --> Loader Class Initialized
INFO - 2018-04-05 22:37:36 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:36 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:36 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Controller Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:36 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:36 --> Total execution time: 0.0547
INFO - 2018-04-05 22:37:36 --> Config Class Initialized
INFO - 2018-04-05 22:37:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:36 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:36 --> URI Class Initialized
INFO - 2018-04-05 22:37:36 --> Router Class Initialized
INFO - 2018-04-05 22:37:36 --> Output Class Initialized
INFO - 2018-04-05 22:37:36 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:36 --> Input Class Initialized
INFO - 2018-04-05 22:37:36 --> Language Class Initialized
INFO - 2018-04-05 22:37:36 --> Loader Class Initialized
INFO - 2018-04-05 22:37:36 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:36 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:36 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Controller Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
INFO - 2018-04-05 22:37:36 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:37 --> Config Class Initialized
INFO - 2018-04-05 22:37:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:37 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:37 --> URI Class Initialized
INFO - 2018-04-05 22:37:37 --> Router Class Initialized
INFO - 2018-04-05 22:37:37 --> Output Class Initialized
INFO - 2018-04-05 22:37:37 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:37 --> Input Class Initialized
INFO - 2018-04-05 22:37:37 --> Language Class Initialized
INFO - 2018-04-05 22:37:37 --> Loader Class Initialized
INFO - 2018-04-05 22:37:37 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:37 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:37 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Controller Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:37 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:37 --> Total execution time: 0.0586
INFO - 2018-04-05 22:37:37 --> Config Class Initialized
INFO - 2018-04-05 22:37:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:37 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:37 --> URI Class Initialized
INFO - 2018-04-05 22:37:37 --> Router Class Initialized
INFO - 2018-04-05 22:37:37 --> Output Class Initialized
INFO - 2018-04-05 22:37:37 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:37 --> Input Class Initialized
INFO - 2018-04-05 22:37:37 --> Language Class Initialized
INFO - 2018-04-05 22:37:37 --> Loader Class Initialized
INFO - 2018-04-05 22:37:37 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:37 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:37 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Controller Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
INFO - 2018-04-05 22:37:37 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:40 --> Config Class Initialized
INFO - 2018-04-05 22:37:40 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:40 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:40 --> URI Class Initialized
INFO - 2018-04-05 22:37:40 --> Router Class Initialized
INFO - 2018-04-05 22:37:40 --> Output Class Initialized
INFO - 2018-04-05 22:37:40 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:40 --> Input Class Initialized
INFO - 2018-04-05 22:37:40 --> Language Class Initialized
INFO - 2018-04-05 22:37:40 --> Loader Class Initialized
INFO - 2018-04-05 22:37:40 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:40 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:40 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:40 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Controller Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:37:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:37:40 --> Final output sent to browser
DEBUG - 2018-04-05 22:37:40 --> Total execution time: 0.0650
INFO - 2018-04-05 22:37:40 --> Config Class Initialized
INFO - 2018-04-05 22:37:40 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:37:40 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:37:40 --> Utf8 Class Initialized
INFO - 2018-04-05 22:37:40 --> URI Class Initialized
INFO - 2018-04-05 22:37:40 --> Router Class Initialized
INFO - 2018-04-05 22:37:40 --> Output Class Initialized
INFO - 2018-04-05 22:37:40 --> Security Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:37:40 --> Input Class Initialized
INFO - 2018-04-05 22:37:40 --> Language Class Initialized
INFO - 2018-04-05 22:37:40 --> Loader Class Initialized
INFO - 2018-04-05 22:37:40 --> Helper loaded: url_helper
INFO - 2018-04-05 22:37:40 --> Helper loaded: form_helper
INFO - 2018-04-05 22:37:40 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:37:40 --> Form Validation Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Controller Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
INFO - 2018-04-05 22:37:40 --> Model Class Initialized
DEBUG - 2018-04-05 22:37:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:38:21 --> Config Class Initialized
INFO - 2018-04-05 22:38:21 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:38:21 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:38:21 --> Utf8 Class Initialized
INFO - 2018-04-05 22:38:21 --> URI Class Initialized
INFO - 2018-04-05 22:38:21 --> Router Class Initialized
INFO - 2018-04-05 22:38:21 --> Output Class Initialized
INFO - 2018-04-05 22:38:21 --> Security Class Initialized
DEBUG - 2018-04-05 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:38:21 --> Input Class Initialized
INFO - 2018-04-05 22:38:21 --> Language Class Initialized
INFO - 2018-04-05 22:38:21 --> Loader Class Initialized
INFO - 2018-04-05 22:38:21 --> Helper loaded: url_helper
INFO - 2018-04-05 22:38:21 --> Helper loaded: form_helper
INFO - 2018-04-05 22:38:21 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:38:21 --> Form Validation Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
INFO - 2018-04-05 22:38:21 --> Controller Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
INFO - 2018-04-05 22:38:21 --> Model Class Initialized
DEBUG - 2018-04-05 22:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:38:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:38:21 --> Final output sent to browser
DEBUG - 2018-04-05 22:38:21 --> Total execution time: 0.0553
INFO - 2018-04-05 22:38:22 --> Config Class Initialized
INFO - 2018-04-05 22:38:22 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:38:22 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:38:22 --> Utf8 Class Initialized
INFO - 2018-04-05 22:38:22 --> URI Class Initialized
INFO - 2018-04-05 22:38:22 --> Router Class Initialized
INFO - 2018-04-05 22:38:22 --> Output Class Initialized
INFO - 2018-04-05 22:38:22 --> Security Class Initialized
DEBUG - 2018-04-05 22:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:38:22 --> Input Class Initialized
INFO - 2018-04-05 22:38:22 --> Language Class Initialized
INFO - 2018-04-05 22:38:22 --> Loader Class Initialized
INFO - 2018-04-05 22:38:22 --> Helper loaded: url_helper
INFO - 2018-04-05 22:38:22 --> Helper loaded: form_helper
INFO - 2018-04-05 22:38:22 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:38:22 --> Form Validation Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
INFO - 2018-04-05 22:38:22 --> Controller Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
INFO - 2018-04-05 22:38:22 --> Model Class Initialized
DEBUG - 2018-04-05 22:38:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:38:36 --> Config Class Initialized
INFO - 2018-04-05 22:38:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:38:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:38:36 --> Utf8 Class Initialized
INFO - 2018-04-05 22:38:36 --> URI Class Initialized
INFO - 2018-04-05 22:38:36 --> Router Class Initialized
INFO - 2018-04-05 22:38:36 --> Output Class Initialized
INFO - 2018-04-05 22:38:36 --> Security Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:38:36 --> Input Class Initialized
INFO - 2018-04-05 22:38:36 --> Language Class Initialized
INFO - 2018-04-05 22:38:36 --> Loader Class Initialized
INFO - 2018-04-05 22:38:36 --> Helper loaded: url_helper
INFO - 2018-04-05 22:38:36 --> Helper loaded: form_helper
INFO - 2018-04-05 22:38:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:38:36 --> Form Validation Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
INFO - 2018-04-05 22:38:36 --> Controller Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:38:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:38:36 --> Final output sent to browser
DEBUG - 2018-04-05 22:38:36 --> Total execution time: 0.0501
INFO - 2018-04-05 22:38:36 --> Config Class Initialized
INFO - 2018-04-05 22:38:36 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:38:36 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:38:36 --> Utf8 Class Initialized
INFO - 2018-04-05 22:38:36 --> URI Class Initialized
INFO - 2018-04-05 22:38:36 --> Router Class Initialized
INFO - 2018-04-05 22:38:36 --> Output Class Initialized
INFO - 2018-04-05 22:38:36 --> Security Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:38:36 --> Input Class Initialized
INFO - 2018-04-05 22:38:36 --> Language Class Initialized
INFO - 2018-04-05 22:38:36 --> Loader Class Initialized
INFO - 2018-04-05 22:38:36 --> Helper loaded: url_helper
INFO - 2018-04-05 22:38:36 --> Helper loaded: form_helper
INFO - 2018-04-05 22:38:36 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:38:36 --> Form Validation Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
INFO - 2018-04-05 22:38:36 --> Controller Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
INFO - 2018-04-05 22:38:36 --> Model Class Initialized
DEBUG - 2018-04-05 22:38:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:01 --> Config Class Initialized
INFO - 2018-04-05 22:46:01 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:01 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:01 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:01 --> URI Class Initialized
INFO - 2018-04-05 22:46:01 --> Router Class Initialized
INFO - 2018-04-05 22:46:01 --> Output Class Initialized
INFO - 2018-04-05 22:46:01 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:01 --> Input Class Initialized
INFO - 2018-04-05 22:46:01 --> Language Class Initialized
INFO - 2018-04-05 22:46:01 --> Loader Class Initialized
INFO - 2018-04-05 22:46:01 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:01 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:01 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:01 --> Model Class Initialized
INFO - 2018-04-05 22:46:01 --> Controller Class Initialized
INFO - 2018-04-05 22:46:01 --> Model Class Initialized
INFO - 2018-04-05 22:46:01 --> Model Class Initialized
INFO - 2018-04-05 22:46:01 --> Model Class Initialized
INFO - 2018-04-05 22:46:01 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:01 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:01 --> Total execution time: 0.0599
INFO - 2018-04-05 22:46:02 --> Config Class Initialized
INFO - 2018-04-05 22:46:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:02 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:02 --> URI Class Initialized
INFO - 2018-04-05 22:46:02 --> Router Class Initialized
INFO - 2018-04-05 22:46:02 --> Output Class Initialized
INFO - 2018-04-05 22:46:02 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:02 --> Input Class Initialized
INFO - 2018-04-05 22:46:02 --> Language Class Initialized
INFO - 2018-04-05 22:46:02 --> Loader Class Initialized
INFO - 2018-04-05 22:46:02 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:02 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:02 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Controller Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:02 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:02 --> Total execution time: 0.0614
INFO - 2018-04-05 22:46:02 --> Config Class Initialized
INFO - 2018-04-05 22:46:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:02 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:02 --> URI Class Initialized
INFO - 2018-04-05 22:46:02 --> Router Class Initialized
INFO - 2018-04-05 22:46:02 --> Output Class Initialized
INFO - 2018-04-05 22:46:02 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:02 --> Input Class Initialized
INFO - 2018-04-05 22:46:02 --> Language Class Initialized
INFO - 2018-04-05 22:46:02 --> Loader Class Initialized
INFO - 2018-04-05 22:46:02 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:02 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:02 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Controller Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
INFO - 2018-04-05 22:46:02 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:03 --> Config Class Initialized
INFO - 2018-04-05 22:46:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:03 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:03 --> URI Class Initialized
INFO - 2018-04-05 22:46:03 --> Router Class Initialized
INFO - 2018-04-05 22:46:03 --> Output Class Initialized
INFO - 2018-04-05 22:46:03 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:03 --> Input Class Initialized
INFO - 2018-04-05 22:46:03 --> Language Class Initialized
INFO - 2018-04-05 22:46:03 --> Loader Class Initialized
INFO - 2018-04-05 22:46:03 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:03 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:03 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Controller Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:03 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:03 --> Total execution time: 0.0643
INFO - 2018-04-05 22:46:03 --> Config Class Initialized
INFO - 2018-04-05 22:46:03 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:03 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:03 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:03 --> URI Class Initialized
INFO - 2018-04-05 22:46:03 --> Router Class Initialized
INFO - 2018-04-05 22:46:03 --> Output Class Initialized
INFO - 2018-04-05 22:46:03 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:03 --> Input Class Initialized
INFO - 2018-04-05 22:46:03 --> Language Class Initialized
INFO - 2018-04-05 22:46:03 --> Loader Class Initialized
INFO - 2018-04-05 22:46:03 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:03 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:03 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:03 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Controller Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
INFO - 2018-04-05 22:46:03 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:05 --> Config Class Initialized
INFO - 2018-04-05 22:46:05 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:05 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:05 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:05 --> URI Class Initialized
INFO - 2018-04-05 22:46:05 --> Router Class Initialized
INFO - 2018-04-05 22:46:05 --> Output Class Initialized
INFO - 2018-04-05 22:46:05 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:05 --> Input Class Initialized
INFO - 2018-04-05 22:46:05 --> Language Class Initialized
INFO - 2018-04-05 22:46:05 --> Loader Class Initialized
INFO - 2018-04-05 22:46:05 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:05 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:05 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:05 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Controller Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:05 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:05 --> Total execution time: 0.0695
INFO - 2018-04-05 22:46:05 --> Config Class Initialized
INFO - 2018-04-05 22:46:05 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:05 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:05 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:05 --> URI Class Initialized
INFO - 2018-04-05 22:46:05 --> Router Class Initialized
INFO - 2018-04-05 22:46:05 --> Output Class Initialized
INFO - 2018-04-05 22:46:05 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:05 --> Input Class Initialized
INFO - 2018-04-05 22:46:05 --> Language Class Initialized
INFO - 2018-04-05 22:46:05 --> Loader Class Initialized
INFO - 2018-04-05 22:46:05 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:05 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:05 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:05 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Controller Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
INFO - 2018-04-05 22:46:05 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:10 --> Config Class Initialized
INFO - 2018-04-05 22:46:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:10 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:10 --> URI Class Initialized
INFO - 2018-04-05 22:46:10 --> Router Class Initialized
INFO - 2018-04-05 22:46:10 --> Output Class Initialized
INFO - 2018-04-05 22:46:10 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:10 --> Input Class Initialized
INFO - 2018-04-05 22:46:10 --> Language Class Initialized
INFO - 2018-04-05 22:46:10 --> Loader Class Initialized
INFO - 2018-04-05 22:46:10 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:10 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:10 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Controller Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:10 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:10 --> Total execution time: 0.0580
INFO - 2018-04-05 22:46:10 --> Config Class Initialized
INFO - 2018-04-05 22:46:10 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:10 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:10 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:10 --> URI Class Initialized
INFO - 2018-04-05 22:46:10 --> Router Class Initialized
INFO - 2018-04-05 22:46:10 --> Output Class Initialized
INFO - 2018-04-05 22:46:10 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:10 --> Input Class Initialized
INFO - 2018-04-05 22:46:10 --> Language Class Initialized
INFO - 2018-04-05 22:46:10 --> Loader Class Initialized
INFO - 2018-04-05 22:46:10 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:10 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:10 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:10 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Controller Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
INFO - 2018-04-05 22:46:10 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:17 --> Config Class Initialized
INFO - 2018-04-05 22:46:17 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:17 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:17 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:17 --> URI Class Initialized
INFO - 2018-04-05 22:46:17 --> Router Class Initialized
INFO - 2018-04-05 22:46:17 --> Output Class Initialized
INFO - 2018-04-05 22:46:17 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:17 --> Input Class Initialized
INFO - 2018-04-05 22:46:17 --> Language Class Initialized
INFO - 2018-04-05 22:46:17 --> Loader Class Initialized
INFO - 2018-04-05 22:46:17 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:17 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:17 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:17 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
INFO - 2018-04-05 22:46:17 --> Controller Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
INFO - 2018-04-05 22:46:17 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:25 --> Config Class Initialized
INFO - 2018-04-05 22:46:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:25 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:25 --> URI Class Initialized
INFO - 2018-04-05 22:46:25 --> Router Class Initialized
INFO - 2018-04-05 22:46:25 --> Output Class Initialized
INFO - 2018-04-05 22:46:25 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:25 --> Input Class Initialized
INFO - 2018-04-05 22:46:25 --> Language Class Initialized
INFO - 2018-04-05 22:46:25 --> Loader Class Initialized
INFO - 2018-04-05 22:46:25 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:25 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:25 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
INFO - 2018-04-05 22:46:25 --> Controller Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:25 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:25 --> Total execution time: 0.0375
INFO - 2018-04-05 22:46:25 --> Config Class Initialized
INFO - 2018-04-05 22:46:25 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:25 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:25 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:25 --> URI Class Initialized
INFO - 2018-04-05 22:46:25 --> Router Class Initialized
INFO - 2018-04-05 22:46:25 --> Output Class Initialized
INFO - 2018-04-05 22:46:25 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:25 --> Input Class Initialized
INFO - 2018-04-05 22:46:25 --> Language Class Initialized
INFO - 2018-04-05 22:46:25 --> Loader Class Initialized
INFO - 2018-04-05 22:46:25 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:25 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:25 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:25 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
INFO - 2018-04-05 22:46:25 --> Controller Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
INFO - 2018-04-05 22:46:25 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:28 --> Config Class Initialized
INFO - 2018-04-05 22:46:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:28 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:28 --> URI Class Initialized
INFO - 2018-04-05 22:46:28 --> Router Class Initialized
INFO - 2018-04-05 22:46:28 --> Output Class Initialized
INFO - 2018-04-05 22:46:28 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:28 --> Input Class Initialized
INFO - 2018-04-05 22:46:28 --> Language Class Initialized
INFO - 2018-04-05 22:46:28 --> Loader Class Initialized
INFO - 2018-04-05 22:46:28 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:28 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:28 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:28 --> Model Class Initialized
INFO - 2018-04-05 22:46:28 --> Controller Class Initialized
INFO - 2018-04-05 22:46:28 --> Model Class Initialized
INFO - 2018-04-05 22:46:28 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:28 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:28 --> Total execution time: 0.1021
INFO - 2018-04-05 22:46:31 --> Config Class Initialized
INFO - 2018-04-05 22:46:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:31 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:31 --> URI Class Initialized
INFO - 2018-04-05 22:46:31 --> Router Class Initialized
INFO - 2018-04-05 22:46:31 --> Output Class Initialized
INFO - 2018-04-05 22:46:31 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:31 --> Input Class Initialized
INFO - 2018-04-05 22:46:31 --> Language Class Initialized
INFO - 2018-04-05 22:46:31 --> Loader Class Initialized
INFO - 2018-04-05 22:46:31 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:31 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:31 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:31 --> Model Class Initialized
INFO - 2018-04-05 22:46:31 --> Controller Class Initialized
INFO - 2018-04-05 22:46:31 --> Model Class Initialized
INFO - 2018-04-05 22:46:31 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:31 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:31 --> Total execution time: 0.1781
INFO - 2018-04-05 22:46:32 --> Config Class Initialized
INFO - 2018-04-05 22:46:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:32 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:32 --> URI Class Initialized
INFO - 2018-04-05 22:46:32 --> Router Class Initialized
INFO - 2018-04-05 22:46:32 --> Output Class Initialized
INFO - 2018-04-05 22:46:32 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:32 --> Input Class Initialized
INFO - 2018-04-05 22:46:32 --> Language Class Initialized
INFO - 2018-04-05 22:46:32 --> Loader Class Initialized
INFO - 2018-04-05 22:46:32 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:32 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:32 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Controller Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:32 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:32 --> Total execution time: 0.0596
INFO - 2018-04-05 22:46:32 --> Config Class Initialized
INFO - 2018-04-05 22:46:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:32 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:32 --> URI Class Initialized
INFO - 2018-04-05 22:46:32 --> Router Class Initialized
INFO - 2018-04-05 22:46:32 --> Output Class Initialized
INFO - 2018-04-05 22:46:32 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:32 --> Input Class Initialized
INFO - 2018-04-05 22:46:32 --> Language Class Initialized
INFO - 2018-04-05 22:46:32 --> Loader Class Initialized
INFO - 2018-04-05 22:46:32 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:32 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:32 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Controller Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
INFO - 2018-04-05 22:46:32 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:33 --> Config Class Initialized
INFO - 2018-04-05 22:46:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:33 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:33 --> URI Class Initialized
INFO - 2018-04-05 22:46:33 --> Router Class Initialized
INFO - 2018-04-05 22:46:33 --> Output Class Initialized
INFO - 2018-04-05 22:46:33 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:33 --> Input Class Initialized
INFO - 2018-04-05 22:46:33 --> Language Class Initialized
INFO - 2018-04-05 22:46:33 --> Loader Class Initialized
INFO - 2018-04-05 22:46:33 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:33 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:33 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Controller Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:33 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:33 --> Total execution time: 0.0631
INFO - 2018-04-05 22:46:33 --> Config Class Initialized
INFO - 2018-04-05 22:46:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:33 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:33 --> URI Class Initialized
INFO - 2018-04-05 22:46:33 --> Router Class Initialized
INFO - 2018-04-05 22:46:33 --> Output Class Initialized
INFO - 2018-04-05 22:46:33 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:33 --> Input Class Initialized
INFO - 2018-04-05 22:46:33 --> Language Class Initialized
INFO - 2018-04-05 22:46:33 --> Loader Class Initialized
INFO - 2018-04-05 22:46:33 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:33 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:33 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Controller Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
INFO - 2018-04-05 22:46:33 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:34 --> Config Class Initialized
INFO - 2018-04-05 22:46:34 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:34 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:34 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:34 --> URI Class Initialized
INFO - 2018-04-05 22:46:34 --> Router Class Initialized
INFO - 2018-04-05 22:46:34 --> Output Class Initialized
INFO - 2018-04-05 22:46:34 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:34 --> Input Class Initialized
INFO - 2018-04-05 22:46:34 --> Language Class Initialized
INFO - 2018-04-05 22:46:34 --> Loader Class Initialized
INFO - 2018-04-05 22:46:34 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:34 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:34 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:34 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Controller Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:34 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:34 --> Total execution time: 0.0564
INFO - 2018-04-05 22:46:34 --> Config Class Initialized
INFO - 2018-04-05 22:46:34 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:34 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:34 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:34 --> URI Class Initialized
INFO - 2018-04-05 22:46:34 --> Router Class Initialized
INFO - 2018-04-05 22:46:34 --> Output Class Initialized
INFO - 2018-04-05 22:46:34 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:34 --> Input Class Initialized
INFO - 2018-04-05 22:46:34 --> Language Class Initialized
INFO - 2018-04-05 22:46:34 --> Loader Class Initialized
INFO - 2018-04-05 22:46:34 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:34 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:34 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:34 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Controller Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
INFO - 2018-04-05 22:46:34 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:38 --> Config Class Initialized
INFO - 2018-04-05 22:46:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:38 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:38 --> URI Class Initialized
INFO - 2018-04-05 22:46:38 --> Router Class Initialized
INFO - 2018-04-05 22:46:38 --> Output Class Initialized
INFO - 2018-04-05 22:46:38 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:38 --> Input Class Initialized
INFO - 2018-04-05 22:46:38 --> Language Class Initialized
INFO - 2018-04-05 22:46:38 --> Loader Class Initialized
INFO - 2018-04-05 22:46:38 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:38 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:38 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Controller Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:38 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:38 --> Total execution time: 0.0657
INFO - 2018-04-05 22:46:38 --> Config Class Initialized
INFO - 2018-04-05 22:46:38 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:38 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:38 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:38 --> URI Class Initialized
INFO - 2018-04-05 22:46:38 --> Router Class Initialized
INFO - 2018-04-05 22:46:38 --> Output Class Initialized
INFO - 2018-04-05 22:46:38 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:38 --> Input Class Initialized
INFO - 2018-04-05 22:46:38 --> Language Class Initialized
INFO - 2018-04-05 22:46:38 --> Loader Class Initialized
INFO - 2018-04-05 22:46:38 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:38 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:38 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:38 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Controller Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
INFO - 2018-04-05 22:46:38 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:45 --> Config Class Initialized
INFO - 2018-04-05 22:46:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:45 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:45 --> URI Class Initialized
INFO - 2018-04-05 22:46:45 --> Router Class Initialized
INFO - 2018-04-05 22:46:45 --> Output Class Initialized
INFO - 2018-04-05 22:46:45 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:45 --> Input Class Initialized
INFO - 2018-04-05 22:46:45 --> Language Class Initialized
INFO - 2018-04-05 22:46:45 --> Loader Class Initialized
INFO - 2018-04-05 22:46:45 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:45 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:45 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:45 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
INFO - 2018-04-05 22:46:45 --> Controller Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
INFO - 2018-04-05 22:46:45 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:59 --> Config Class Initialized
INFO - 2018-04-05 22:46:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:59 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:59 --> URI Class Initialized
INFO - 2018-04-05 22:46:59 --> Router Class Initialized
INFO - 2018-04-05 22:46:59 --> Output Class Initialized
INFO - 2018-04-05 22:46:59 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:59 --> Input Class Initialized
INFO - 2018-04-05 22:46:59 --> Language Class Initialized
INFO - 2018-04-05 22:46:59 --> Loader Class Initialized
INFO - 2018-04-05 22:46:59 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:59 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:59 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Controller Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:46:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:46:59 --> Final output sent to browser
DEBUG - 2018-04-05 22:46:59 --> Total execution time: 0.0625
INFO - 2018-04-05 22:46:59 --> Config Class Initialized
INFO - 2018-04-05 22:46:59 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:46:59 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:46:59 --> Utf8 Class Initialized
INFO - 2018-04-05 22:46:59 --> URI Class Initialized
INFO - 2018-04-05 22:46:59 --> Router Class Initialized
INFO - 2018-04-05 22:46:59 --> Output Class Initialized
INFO - 2018-04-05 22:46:59 --> Security Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:46:59 --> Input Class Initialized
INFO - 2018-04-05 22:46:59 --> Language Class Initialized
INFO - 2018-04-05 22:46:59 --> Loader Class Initialized
INFO - 2018-04-05 22:46:59 --> Helper loaded: url_helper
INFO - 2018-04-05 22:46:59 --> Helper loaded: form_helper
INFO - 2018-04-05 22:46:59 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:46:59 --> Form Validation Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Controller Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
INFO - 2018-04-05 22:46:59 --> Model Class Initialized
DEBUG - 2018-04-05 22:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:04 --> Config Class Initialized
INFO - 2018-04-05 22:47:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:04 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:04 --> URI Class Initialized
INFO - 2018-04-05 22:47:04 --> Router Class Initialized
INFO - 2018-04-05 22:47:04 --> Output Class Initialized
INFO - 2018-04-05 22:47:04 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:04 --> Input Class Initialized
INFO - 2018-04-05 22:47:04 --> Language Class Initialized
INFO - 2018-04-05 22:47:04 --> Loader Class Initialized
INFO - 2018-04-05 22:47:04 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:04 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:04 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
INFO - 2018-04-05 22:47:04 --> Controller Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
INFO - 2018-04-05 22:47:04 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:07 --> Config Class Initialized
INFO - 2018-04-05 22:47:07 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:07 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:07 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:07 --> URI Class Initialized
INFO - 2018-04-05 22:47:07 --> Router Class Initialized
INFO - 2018-04-05 22:47:07 --> Output Class Initialized
INFO - 2018-04-05 22:47:07 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:07 --> Input Class Initialized
INFO - 2018-04-05 22:47:07 --> Language Class Initialized
INFO - 2018-04-05 22:47:07 --> Loader Class Initialized
INFO - 2018-04-05 22:47:07 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:07 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:07 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:07 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
INFO - 2018-04-05 22:47:07 --> Controller Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
INFO - 2018-04-05 22:47:07 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:07 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:07 --> Total execution time: 0.0612
INFO - 2018-04-05 22:47:08 --> Config Class Initialized
INFO - 2018-04-05 22:47:08 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:08 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:08 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:08 --> URI Class Initialized
INFO - 2018-04-05 22:47:08 --> Router Class Initialized
INFO - 2018-04-05 22:47:08 --> Output Class Initialized
INFO - 2018-04-05 22:47:08 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:08 --> Input Class Initialized
INFO - 2018-04-05 22:47:08 --> Language Class Initialized
INFO - 2018-04-05 22:47:08 --> Loader Class Initialized
INFO - 2018-04-05 22:47:08 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:08 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:08 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:08 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
INFO - 2018-04-05 22:47:08 --> Controller Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
INFO - 2018-04-05 22:47:08 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:11 --> Config Class Initialized
INFO - 2018-04-05 22:47:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:11 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:11 --> URI Class Initialized
INFO - 2018-04-05 22:47:11 --> Router Class Initialized
INFO - 2018-04-05 22:47:11 --> Output Class Initialized
INFO - 2018-04-05 22:47:11 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:11 --> Input Class Initialized
INFO - 2018-04-05 22:47:11 --> Language Class Initialized
INFO - 2018-04-05 22:47:11 --> Loader Class Initialized
INFO - 2018-04-05 22:47:11 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:11 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:11 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
INFO - 2018-04-05 22:47:11 --> Controller Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:11 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:11 --> Total execution time: 0.0407
INFO - 2018-04-05 22:47:11 --> Config Class Initialized
INFO - 2018-04-05 22:47:11 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:11 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:11 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:11 --> URI Class Initialized
INFO - 2018-04-05 22:47:11 --> Router Class Initialized
INFO - 2018-04-05 22:47:11 --> Output Class Initialized
INFO - 2018-04-05 22:47:11 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:11 --> Input Class Initialized
INFO - 2018-04-05 22:47:11 --> Language Class Initialized
INFO - 2018-04-05 22:47:11 --> Loader Class Initialized
INFO - 2018-04-05 22:47:11 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:11 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:11 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:11 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
INFO - 2018-04-05 22:47:11 --> Controller Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
INFO - 2018-04-05 22:47:11 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:24 --> Config Class Initialized
INFO - 2018-04-05 22:47:24 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:24 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:24 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:24 --> URI Class Initialized
INFO - 2018-04-05 22:47:24 --> Router Class Initialized
INFO - 2018-04-05 22:47:24 --> Output Class Initialized
INFO - 2018-04-05 22:47:24 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:24 --> Input Class Initialized
INFO - 2018-04-05 22:47:24 --> Language Class Initialized
INFO - 2018-04-05 22:47:24 --> Loader Class Initialized
INFO - 2018-04-05 22:47:24 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:24 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:24 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:24 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:24 --> Model Class Initialized
INFO - 2018-04-05 22:47:24 --> Controller Class Initialized
INFO - 2018-04-05 22:47:24 --> Model Class Initialized
INFO - 2018-04-05 22:47:24 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:28 --> Config Class Initialized
INFO - 2018-04-05 22:47:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:28 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:28 --> URI Class Initialized
INFO - 2018-04-05 22:47:28 --> Router Class Initialized
INFO - 2018-04-05 22:47:28 --> Output Class Initialized
INFO - 2018-04-05 22:47:28 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:28 --> Input Class Initialized
INFO - 2018-04-05 22:47:28 --> Language Class Initialized
INFO - 2018-04-05 22:47:28 --> Loader Class Initialized
INFO - 2018-04-05 22:47:28 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:28 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:28 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
INFO - 2018-04-05 22:47:28 --> Controller Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:28 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:28 --> Total execution time: 0.0431
INFO - 2018-04-05 22:47:28 --> Config Class Initialized
INFO - 2018-04-05 22:47:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:28 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:28 --> URI Class Initialized
INFO - 2018-04-05 22:47:28 --> Router Class Initialized
INFO - 2018-04-05 22:47:28 --> Output Class Initialized
INFO - 2018-04-05 22:47:28 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:28 --> Input Class Initialized
INFO - 2018-04-05 22:47:28 --> Language Class Initialized
INFO - 2018-04-05 22:47:28 --> Loader Class Initialized
INFO - 2018-04-05 22:47:28 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:28 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:28 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
INFO - 2018-04-05 22:47:28 --> Controller Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
INFO - 2018-04-05 22:47:28 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:29 --> Config Class Initialized
INFO - 2018-04-05 22:47:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:29 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:29 --> URI Class Initialized
INFO - 2018-04-05 22:47:29 --> Router Class Initialized
INFO - 2018-04-05 22:47:29 --> Output Class Initialized
INFO - 2018-04-05 22:47:29 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:29 --> Input Class Initialized
INFO - 2018-04-05 22:47:29 --> Language Class Initialized
INFO - 2018-04-05 22:47:29 --> Loader Class Initialized
INFO - 2018-04-05 22:47:29 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:29 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:29 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Controller Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:29 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:29 --> Total execution time: 0.0456
INFO - 2018-04-05 22:47:29 --> Config Class Initialized
INFO - 2018-04-05 22:47:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:29 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:29 --> URI Class Initialized
INFO - 2018-04-05 22:47:29 --> Router Class Initialized
INFO - 2018-04-05 22:47:29 --> Output Class Initialized
INFO - 2018-04-05 22:47:29 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:29 --> Input Class Initialized
INFO - 2018-04-05 22:47:29 --> Language Class Initialized
INFO - 2018-04-05 22:47:29 --> Loader Class Initialized
INFO - 2018-04-05 22:47:29 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:29 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:29 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Controller Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:29 --> Config Class Initialized
INFO - 2018-04-05 22:47:29 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:29 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:29 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:29 --> URI Class Initialized
INFO - 2018-04-05 22:47:29 --> Router Class Initialized
INFO - 2018-04-05 22:47:29 --> Output Class Initialized
INFO - 2018-04-05 22:47:29 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:29 --> Input Class Initialized
INFO - 2018-04-05 22:47:29 --> Language Class Initialized
INFO - 2018-04-05 22:47:29 --> Loader Class Initialized
INFO - 2018-04-05 22:47:29 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:29 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:29 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:29 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Controller Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
INFO - 2018-04-05 22:47:29 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:29 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:29 --> Total execution time: 0.0504
INFO - 2018-04-05 22:47:30 --> Config Class Initialized
INFO - 2018-04-05 22:47:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:30 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:30 --> URI Class Initialized
INFO - 2018-04-05 22:47:30 --> Router Class Initialized
INFO - 2018-04-05 22:47:30 --> Output Class Initialized
INFO - 2018-04-05 22:47:30 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:30 --> Input Class Initialized
INFO - 2018-04-05 22:47:30 --> Language Class Initialized
INFO - 2018-04-05 22:47:30 --> Loader Class Initialized
INFO - 2018-04-05 22:47:30 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:30 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:30 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
INFO - 2018-04-05 22:47:30 --> Controller Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
INFO - 2018-04-05 22:47:30 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:31 --> Config Class Initialized
INFO - 2018-04-05 22:47:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:31 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:31 --> URI Class Initialized
INFO - 2018-04-05 22:47:31 --> Router Class Initialized
INFO - 2018-04-05 22:47:31 --> Output Class Initialized
INFO - 2018-04-05 22:47:31 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:31 --> Input Class Initialized
INFO - 2018-04-05 22:47:31 --> Language Class Initialized
INFO - 2018-04-05 22:47:31 --> Loader Class Initialized
INFO - 2018-04-05 22:47:31 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:31 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:31 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Controller Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:31 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:31 --> Total execution time: 0.0645
INFO - 2018-04-05 22:47:31 --> Config Class Initialized
INFO - 2018-04-05 22:47:31 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:31 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:31 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:31 --> URI Class Initialized
INFO - 2018-04-05 22:47:31 --> Router Class Initialized
INFO - 2018-04-05 22:47:31 --> Output Class Initialized
INFO - 2018-04-05 22:47:31 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:31 --> Input Class Initialized
INFO - 2018-04-05 22:47:31 --> Language Class Initialized
INFO - 2018-04-05 22:47:31 --> Loader Class Initialized
INFO - 2018-04-05 22:47:31 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:31 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:31 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:31 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Controller Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
INFO - 2018-04-05 22:47:31 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:32 --> Config Class Initialized
INFO - 2018-04-05 22:47:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:32 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:32 --> URI Class Initialized
INFO - 2018-04-05 22:47:32 --> Router Class Initialized
INFO - 2018-04-05 22:47:32 --> Output Class Initialized
INFO - 2018-04-05 22:47:32 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:32 --> Input Class Initialized
INFO - 2018-04-05 22:47:32 --> Language Class Initialized
INFO - 2018-04-05 22:47:32 --> Loader Class Initialized
INFO - 2018-04-05 22:47:32 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:32 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:32 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Controller Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:32 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:32 --> Total execution time: 0.1094
INFO - 2018-04-05 22:47:32 --> Config Class Initialized
INFO - 2018-04-05 22:47:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:32 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:32 --> URI Class Initialized
INFO - 2018-04-05 22:47:32 --> Router Class Initialized
INFO - 2018-04-05 22:47:32 --> Output Class Initialized
INFO - 2018-04-05 22:47:32 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:32 --> Input Class Initialized
INFO - 2018-04-05 22:47:32 --> Language Class Initialized
INFO - 2018-04-05 22:47:32 --> Loader Class Initialized
INFO - 2018-04-05 22:47:32 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:32 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:32 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Controller Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
INFO - 2018-04-05 22:47:32 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:37 --> Config Class Initialized
INFO - 2018-04-05 22:47:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:37 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:37 --> URI Class Initialized
INFO - 2018-04-05 22:47:37 --> Router Class Initialized
INFO - 2018-04-05 22:47:37 --> Output Class Initialized
INFO - 2018-04-05 22:47:37 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:37 --> Input Class Initialized
INFO - 2018-04-05 22:47:37 --> Language Class Initialized
INFO - 2018-04-05 22:47:37 --> Loader Class Initialized
INFO - 2018-04-05 22:47:37 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:37 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:37 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Controller Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 22:47:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 22:47:37 --> Final output sent to browser
DEBUG - 2018-04-05 22:47:37 --> Total execution time: 0.0648
INFO - 2018-04-05 22:47:37 --> Config Class Initialized
INFO - 2018-04-05 22:47:37 --> Hooks Class Initialized
DEBUG - 2018-04-05 22:47:37 --> UTF-8 Support Enabled
INFO - 2018-04-05 22:47:37 --> Utf8 Class Initialized
INFO - 2018-04-05 22:47:37 --> URI Class Initialized
INFO - 2018-04-05 22:47:37 --> Router Class Initialized
INFO - 2018-04-05 22:47:37 --> Output Class Initialized
INFO - 2018-04-05 22:47:37 --> Security Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 22:47:37 --> Input Class Initialized
INFO - 2018-04-05 22:47:37 --> Language Class Initialized
INFO - 2018-04-05 22:47:37 --> Loader Class Initialized
INFO - 2018-04-05 22:47:37 --> Helper loaded: url_helper
INFO - 2018-04-05 22:47:37 --> Helper loaded: form_helper
INFO - 2018-04-05 22:47:37 --> Database Driver Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 22:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 22:47:37 --> Form Validation Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Controller Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
INFO - 2018-04-05 22:47:37 --> Model Class Initialized
DEBUG - 2018-04-05 22:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:30 --> Config Class Initialized
INFO - 2018-04-05 23:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:30 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:30 --> URI Class Initialized
INFO - 2018-04-05 23:02:30 --> Router Class Initialized
INFO - 2018-04-05 23:02:30 --> Output Class Initialized
INFO - 2018-04-05 23:02:30 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:30 --> Input Class Initialized
INFO - 2018-04-05 23:02:30 --> Language Class Initialized
INFO - 2018-04-05 23:02:30 --> Loader Class Initialized
INFO - 2018-04-05 23:02:30 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:30 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:30 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Controller Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:02:30 --> Final output sent to browser
DEBUG - 2018-04-05 23:02:30 --> Total execution time: 0.0611
INFO - 2018-04-05 23:02:30 --> Config Class Initialized
INFO - 2018-04-05 23:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:30 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:30 --> URI Class Initialized
INFO - 2018-04-05 23:02:30 --> Router Class Initialized
INFO - 2018-04-05 23:02:30 --> Output Class Initialized
INFO - 2018-04-05 23:02:30 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:30 --> Input Class Initialized
INFO - 2018-04-05 23:02:30 --> Language Class Initialized
INFO - 2018-04-05 23:02:30 --> Loader Class Initialized
INFO - 2018-04-05 23:02:30 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:30 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:30 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:30 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Controller Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
INFO - 2018-04-05 23:02:30 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:32 --> Config Class Initialized
INFO - 2018-04-05 23:02:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:32 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:32 --> URI Class Initialized
INFO - 2018-04-05 23:02:32 --> Router Class Initialized
INFO - 2018-04-05 23:02:32 --> Output Class Initialized
INFO - 2018-04-05 23:02:32 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:32 --> Input Class Initialized
INFO - 2018-04-05 23:02:32 --> Language Class Initialized
INFO - 2018-04-05 23:02:32 --> Loader Class Initialized
INFO - 2018-04-05 23:02:32 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:32 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:32 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Controller Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:02:32 --> Final output sent to browser
DEBUG - 2018-04-05 23:02:32 --> Total execution time: 0.0624
INFO - 2018-04-05 23:02:32 --> Config Class Initialized
INFO - 2018-04-05 23:02:32 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:32 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:32 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:32 --> URI Class Initialized
INFO - 2018-04-05 23:02:32 --> Router Class Initialized
INFO - 2018-04-05 23:02:32 --> Output Class Initialized
INFO - 2018-04-05 23:02:32 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:32 --> Input Class Initialized
INFO - 2018-04-05 23:02:32 --> Language Class Initialized
INFO - 2018-04-05 23:02:32 --> Loader Class Initialized
INFO - 2018-04-05 23:02:32 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:32 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:32 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:32 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Controller Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
INFO - 2018-04-05 23:02:32 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:33 --> Config Class Initialized
INFO - 2018-04-05 23:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:33 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:33 --> URI Class Initialized
INFO - 2018-04-05 23:02:33 --> Router Class Initialized
INFO - 2018-04-05 23:02:33 --> Output Class Initialized
INFO - 2018-04-05 23:02:33 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:33 --> Input Class Initialized
INFO - 2018-04-05 23:02:33 --> Language Class Initialized
INFO - 2018-04-05 23:02:33 --> Loader Class Initialized
INFO - 2018-04-05 23:02:33 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:33 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:33 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Controller Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:02:33 --> Final output sent to browser
DEBUG - 2018-04-05 23:02:33 --> Total execution time: 0.0634
INFO - 2018-04-05 23:02:33 --> Config Class Initialized
INFO - 2018-04-05 23:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:33 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:33 --> URI Class Initialized
INFO - 2018-04-05 23:02:33 --> Router Class Initialized
INFO - 2018-04-05 23:02:33 --> Output Class Initialized
INFO - 2018-04-05 23:02:33 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:33 --> Input Class Initialized
INFO - 2018-04-05 23:02:33 --> Language Class Initialized
INFO - 2018-04-05 23:02:33 --> Loader Class Initialized
INFO - 2018-04-05 23:02:33 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:33 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:33 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:33 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Controller Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
INFO - 2018-04-05 23:02:33 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:42 --> Config Class Initialized
INFO - 2018-04-05 23:02:42 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:42 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:42 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:42 --> URI Class Initialized
INFO - 2018-04-05 23:02:42 --> Router Class Initialized
INFO - 2018-04-05 23:02:42 --> Output Class Initialized
INFO - 2018-04-05 23:02:42 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:42 --> Input Class Initialized
INFO - 2018-04-05 23:02:42 --> Language Class Initialized
INFO - 2018-04-05 23:02:42 --> Loader Class Initialized
INFO - 2018-04-05 23:02:42 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:42 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:42 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:42 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Controller Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:02:42 --> Final output sent to browser
DEBUG - 2018-04-05 23:02:42 --> Total execution time: 0.0526
INFO - 2018-04-05 23:02:42 --> Config Class Initialized
INFO - 2018-04-05 23:02:42 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:42 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:42 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:42 --> URI Class Initialized
INFO - 2018-04-05 23:02:42 --> Router Class Initialized
INFO - 2018-04-05 23:02:42 --> Output Class Initialized
INFO - 2018-04-05 23:02:42 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:42 --> Input Class Initialized
INFO - 2018-04-05 23:02:42 --> Language Class Initialized
INFO - 2018-04-05 23:02:42 --> Loader Class Initialized
INFO - 2018-04-05 23:02:42 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:42 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:42 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:42 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Controller Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
INFO - 2018-04-05 23:02:42 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:52 --> Config Class Initialized
INFO - 2018-04-05 23:02:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:52 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:52 --> URI Class Initialized
INFO - 2018-04-05 23:02:52 --> Router Class Initialized
INFO - 2018-04-05 23:02:52 --> Output Class Initialized
INFO - 2018-04-05 23:02:52 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:52 --> Input Class Initialized
INFO - 2018-04-05 23:02:52 --> Language Class Initialized
INFO - 2018-04-05 23:02:52 --> Loader Class Initialized
INFO - 2018-04-05 23:02:52 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:52 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:52 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Controller Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:02:52 --> Final output sent to browser
DEBUG - 2018-04-05 23:02:52 --> Total execution time: 0.0532
INFO - 2018-04-05 23:02:52 --> Config Class Initialized
INFO - 2018-04-05 23:02:52 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:52 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:52 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:52 --> URI Class Initialized
INFO - 2018-04-05 23:02:52 --> Router Class Initialized
INFO - 2018-04-05 23:02:52 --> Output Class Initialized
INFO - 2018-04-05 23:02:52 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:52 --> Input Class Initialized
INFO - 2018-04-05 23:02:52 --> Language Class Initialized
INFO - 2018-04-05 23:02:52 --> Loader Class Initialized
INFO - 2018-04-05 23:02:52 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:52 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:52 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:52 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Controller Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
INFO - 2018-04-05 23:02:52 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:02:57 --> Config Class Initialized
INFO - 2018-04-05 23:02:57 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:02:57 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:02:57 --> Utf8 Class Initialized
INFO - 2018-04-05 23:02:57 --> URI Class Initialized
INFO - 2018-04-05 23:02:57 --> Router Class Initialized
INFO - 2018-04-05 23:02:57 --> Output Class Initialized
INFO - 2018-04-05 23:02:57 --> Security Class Initialized
DEBUG - 2018-04-05 23:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:02:57 --> Input Class Initialized
INFO - 2018-04-05 23:02:57 --> Language Class Initialized
INFO - 2018-04-05 23:02:57 --> Loader Class Initialized
INFO - 2018-04-05 23:02:57 --> Helper loaded: url_helper
INFO - 2018-04-05 23:02:57 --> Helper loaded: form_helper
INFO - 2018-04-05 23:02:57 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:02:57 --> Form Validation Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
INFO - 2018-04-05 23:02:57 --> Controller Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
INFO - 2018-04-05 23:02:57 --> Model Class Initialized
DEBUG - 2018-04-05 23:02:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:02 --> Config Class Initialized
INFO - 2018-04-05 23:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:02 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:02 --> URI Class Initialized
INFO - 2018-04-05 23:03:02 --> Router Class Initialized
INFO - 2018-04-05 23:03:02 --> Output Class Initialized
INFO - 2018-04-05 23:03:02 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:02 --> Input Class Initialized
INFO - 2018-04-05 23:03:02 --> Language Class Initialized
INFO - 2018-04-05 23:03:02 --> Loader Class Initialized
INFO - 2018-04-05 23:03:02 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:02 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:02 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Controller Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:02 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:02 --> Total execution time: 0.0681
INFO - 2018-04-05 23:03:02 --> Config Class Initialized
INFO - 2018-04-05 23:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:02 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:02 --> URI Class Initialized
INFO - 2018-04-05 23:03:02 --> Router Class Initialized
INFO - 2018-04-05 23:03:02 --> Output Class Initialized
INFO - 2018-04-05 23:03:02 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:02 --> Input Class Initialized
INFO - 2018-04-05 23:03:02 --> Language Class Initialized
INFO - 2018-04-05 23:03:02 --> Loader Class Initialized
INFO - 2018-04-05 23:03:02 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:02 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:02 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Controller Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
INFO - 2018-04-05 23:03:02 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:04 --> Config Class Initialized
INFO - 2018-04-05 23:03:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:04 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:04 --> URI Class Initialized
INFO - 2018-04-05 23:03:04 --> Router Class Initialized
INFO - 2018-04-05 23:03:04 --> Output Class Initialized
INFO - 2018-04-05 23:03:04 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:04 --> Input Class Initialized
INFO - 2018-04-05 23:03:04 --> Language Class Initialized
INFO - 2018-04-05 23:03:04 --> Loader Class Initialized
INFO - 2018-04-05 23:03:04 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:04 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:04 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Controller Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:04 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:04 --> Total execution time: 0.0672
INFO - 2018-04-05 23:03:04 --> Config Class Initialized
INFO - 2018-04-05 23:03:04 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:04 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:04 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:04 --> URI Class Initialized
INFO - 2018-04-05 23:03:04 --> Router Class Initialized
INFO - 2018-04-05 23:03:04 --> Output Class Initialized
INFO - 2018-04-05 23:03:04 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:04 --> Input Class Initialized
INFO - 2018-04-05 23:03:04 --> Language Class Initialized
INFO - 2018-04-05 23:03:04 --> Loader Class Initialized
INFO - 2018-04-05 23:03:04 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:04 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:04 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:04 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Controller Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
INFO - 2018-04-05 23:03:04 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:09 --> Config Class Initialized
INFO - 2018-04-05 23:03:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:09 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:09 --> URI Class Initialized
INFO - 2018-04-05 23:03:09 --> Router Class Initialized
INFO - 2018-04-05 23:03:09 --> Output Class Initialized
INFO - 2018-04-05 23:03:09 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:09 --> Input Class Initialized
INFO - 2018-04-05 23:03:09 --> Language Class Initialized
INFO - 2018-04-05 23:03:09 --> Loader Class Initialized
INFO - 2018-04-05 23:03:09 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:09 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:09 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Controller Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:09 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:09 --> Total execution time: 0.0647
INFO - 2018-04-05 23:03:09 --> Config Class Initialized
INFO - 2018-04-05 23:03:09 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:09 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:09 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:09 --> URI Class Initialized
INFO - 2018-04-05 23:03:09 --> Router Class Initialized
INFO - 2018-04-05 23:03:09 --> Output Class Initialized
INFO - 2018-04-05 23:03:09 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:09 --> Input Class Initialized
INFO - 2018-04-05 23:03:09 --> Language Class Initialized
INFO - 2018-04-05 23:03:09 --> Loader Class Initialized
INFO - 2018-04-05 23:03:09 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:09 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:09 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:09 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Controller Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
INFO - 2018-04-05 23:03:09 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:28 --> Config Class Initialized
INFO - 2018-04-05 23:03:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:28 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:28 --> URI Class Initialized
INFO - 2018-04-05 23:03:28 --> Router Class Initialized
INFO - 2018-04-05 23:03:28 --> Output Class Initialized
INFO - 2018-04-05 23:03:28 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:28 --> Input Class Initialized
INFO - 2018-04-05 23:03:28 --> Language Class Initialized
INFO - 2018-04-05 23:03:28 --> Loader Class Initialized
INFO - 2018-04-05 23:03:28 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:28 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:28 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Controller Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:28 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:28 --> Total execution time: 0.0486
INFO - 2018-04-05 23:03:28 --> Config Class Initialized
INFO - 2018-04-05 23:03:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:28 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:28 --> URI Class Initialized
INFO - 2018-04-05 23:03:28 --> Router Class Initialized
INFO - 2018-04-05 23:03:28 --> Output Class Initialized
INFO - 2018-04-05 23:03:28 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:28 --> Input Class Initialized
INFO - 2018-04-05 23:03:28 --> Language Class Initialized
INFO - 2018-04-05 23:03:28 --> Loader Class Initialized
INFO - 2018-04-05 23:03:28 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:28 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:28 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Controller Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
INFO - 2018-04-05 23:03:28 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:41 --> Config Class Initialized
INFO - 2018-04-05 23:03:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:41 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:41 --> URI Class Initialized
INFO - 2018-04-05 23:03:41 --> Router Class Initialized
INFO - 2018-04-05 23:03:41 --> Output Class Initialized
INFO - 2018-04-05 23:03:41 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:41 --> Input Class Initialized
INFO - 2018-04-05 23:03:41 --> Language Class Initialized
INFO - 2018-04-05 23:03:41 --> Loader Class Initialized
INFO - 2018-04-05 23:03:41 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:41 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:41 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Controller Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:41 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:41 --> Total execution time: 0.0527
INFO - 2018-04-05 23:03:41 --> Config Class Initialized
INFO - 2018-04-05 23:03:41 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:41 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:41 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:41 --> URI Class Initialized
INFO - 2018-04-05 23:03:41 --> Router Class Initialized
INFO - 2018-04-05 23:03:41 --> Output Class Initialized
INFO - 2018-04-05 23:03:41 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:41 --> Input Class Initialized
INFO - 2018-04-05 23:03:41 --> Language Class Initialized
INFO - 2018-04-05 23:03:41 --> Loader Class Initialized
INFO - 2018-04-05 23:03:41 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:41 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:41 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:41 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Controller Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
INFO - 2018-04-05 23:03:41 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:45 --> Config Class Initialized
INFO - 2018-04-05 23:03:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:45 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:45 --> URI Class Initialized
INFO - 2018-04-05 23:03:45 --> Router Class Initialized
INFO - 2018-04-05 23:03:45 --> Output Class Initialized
INFO - 2018-04-05 23:03:45 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:45 --> Input Class Initialized
INFO - 2018-04-05 23:03:45 --> Language Class Initialized
INFO - 2018-04-05 23:03:45 --> Loader Class Initialized
INFO - 2018-04-05 23:03:45 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:45 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:45 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:45 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Controller Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-05 23:03:45 --> Final output sent to browser
DEBUG - 2018-04-05 23:03:45 --> Total execution time: 0.0520
INFO - 2018-04-05 23:03:45 --> Config Class Initialized
INFO - 2018-04-05 23:03:45 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:45 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:45 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:45 --> URI Class Initialized
INFO - 2018-04-05 23:03:45 --> Router Class Initialized
INFO - 2018-04-05 23:03:45 --> Output Class Initialized
INFO - 2018-04-05 23:03:45 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:45 --> Input Class Initialized
INFO - 2018-04-05 23:03:45 --> Language Class Initialized
INFO - 2018-04-05 23:03:45 --> Loader Class Initialized
INFO - 2018-04-05 23:03:45 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:45 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:45 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:45 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Controller Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
INFO - 2018-04-05 23:03:45 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:03:51 --> Config Class Initialized
INFO - 2018-04-05 23:03:51 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:03:51 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:03:51 --> Utf8 Class Initialized
INFO - 2018-04-05 23:03:51 --> URI Class Initialized
INFO - 2018-04-05 23:03:51 --> Router Class Initialized
INFO - 2018-04-05 23:03:51 --> Output Class Initialized
INFO - 2018-04-05 23:03:51 --> Security Class Initialized
DEBUG - 2018-04-05 23:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:03:51 --> Input Class Initialized
INFO - 2018-04-05 23:03:51 --> Language Class Initialized
INFO - 2018-04-05 23:03:51 --> Loader Class Initialized
INFO - 2018-04-05 23:03:51 --> Helper loaded: url_helper
INFO - 2018-04-05 23:03:51 --> Helper loaded: form_helper
INFO - 2018-04-05 23:03:51 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:03:51 --> Form Validation Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
INFO - 2018-04-05 23:03:51 --> Controller Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
INFO - 2018-04-05 23:03:51 --> Model Class Initialized
DEBUG - 2018-04-05 23:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:08:20 --> Config Class Initialized
INFO - 2018-04-05 23:08:20 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:08:20 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:08:20 --> Utf8 Class Initialized
INFO - 2018-04-05 23:08:20 --> URI Class Initialized
INFO - 2018-04-05 23:08:20 --> Router Class Initialized
INFO - 2018-04-05 23:08:20 --> Output Class Initialized
INFO - 2018-04-05 23:08:20 --> Security Class Initialized
DEBUG - 2018-04-05 23:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:08:20 --> Input Class Initialized
INFO - 2018-04-05 23:08:20 --> Language Class Initialized
INFO - 2018-04-05 23:08:20 --> Loader Class Initialized
INFO - 2018-04-05 23:08:20 --> Helper loaded: url_helper
INFO - 2018-04-05 23:08:20 --> Helper loaded: form_helper
INFO - 2018-04-05 23:08:20 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:08:20 --> Form Validation Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
INFO - 2018-04-05 23:08:20 --> Controller Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
INFO - 2018-04-05 23:08:20 --> Model Class Initialized
DEBUG - 2018-04-05 23:08:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-05 23:08:28 --> Config Class Initialized
INFO - 2018-04-05 23:08:28 --> Hooks Class Initialized
DEBUG - 2018-04-05 23:08:28 --> UTF-8 Support Enabled
INFO - 2018-04-05 23:08:28 --> Utf8 Class Initialized
INFO - 2018-04-05 23:08:28 --> URI Class Initialized
INFO - 2018-04-05 23:08:28 --> Router Class Initialized
INFO - 2018-04-05 23:08:28 --> Output Class Initialized
INFO - 2018-04-05 23:08:28 --> Security Class Initialized
DEBUG - 2018-04-05 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 23:08:28 --> Input Class Initialized
INFO - 2018-04-05 23:08:28 --> Language Class Initialized
INFO - 2018-04-05 23:08:28 --> Loader Class Initialized
INFO - 2018-04-05 23:08:28 --> Helper loaded: url_helper
INFO - 2018-04-05 23:08:28 --> Helper loaded: form_helper
INFO - 2018-04-05 23:08:28 --> Database Driver Class Initialized
DEBUG - 2018-04-05 23:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 23:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 23:08:28 --> Form Validation Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
INFO - 2018-04-05 23:08:28 --> Controller Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
INFO - 2018-04-05 23:08:28 --> Model Class Initialized
DEBUG - 2018-04-05 23:08:28 --> Form_validation class already loaded. Second attempt ignored.
