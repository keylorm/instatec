<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-20 23:17:17 --> Config Class Initialized
INFO - 2018-02-20 23:17:17 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:17 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:17 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:18 --> URI Class Initialized
INFO - 2018-02-20 23:17:18 --> Router Class Initialized
INFO - 2018-02-20 23:17:18 --> Output Class Initialized
INFO - 2018-02-20 23:17:18 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:18 --> Input Class Initialized
INFO - 2018-02-20 23:17:18 --> Language Class Initialized
INFO - 2018-02-20 23:17:18 --> Loader Class Initialized
INFO - 2018-02-20 23:17:18 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:18 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:18 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Controller Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:18 --> Config Class Initialized
INFO - 2018-02-20 23:17:18 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:18 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:18 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:18 --> URI Class Initialized
INFO - 2018-02-20 23:17:18 --> Router Class Initialized
INFO - 2018-02-20 23:17:18 --> Output Class Initialized
INFO - 2018-02-20 23:17:18 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:18 --> Input Class Initialized
INFO - 2018-02-20 23:17:18 --> Language Class Initialized
INFO - 2018-02-20 23:17:18 --> Loader Class Initialized
INFO - 2018-02-20 23:17:18 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:18 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:18 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
INFO - 2018-02-20 23:17:18 --> Controller Class Initialized
INFO - 2018-02-20 23:17:18 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:18 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:18 --> Total execution time: 0.1904
INFO - 2018-02-20 23:17:29 --> Config Class Initialized
INFO - 2018-02-20 23:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:29 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:30 --> URI Class Initialized
INFO - 2018-02-20 23:17:30 --> Router Class Initialized
INFO - 2018-02-20 23:17:30 --> Output Class Initialized
INFO - 2018-02-20 23:17:30 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:30 --> Input Class Initialized
INFO - 2018-02-20 23:17:30 --> Language Class Initialized
INFO - 2018-02-20 23:17:30 --> Loader Class Initialized
INFO - 2018-02-20 23:17:30 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:30 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:30 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:30 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Controller Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-20 23:17:30 --> Config Class Initialized
INFO - 2018-02-20 23:17:30 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:30 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:30 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:30 --> URI Class Initialized
DEBUG - 2018-02-20 23:17:30 --> No URI present. Default controller set.
INFO - 2018-02-20 23:17:30 --> Router Class Initialized
INFO - 2018-02-20 23:17:30 --> Output Class Initialized
INFO - 2018-02-20 23:17:30 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:30 --> Input Class Initialized
INFO - 2018-02-20 23:17:30 --> Language Class Initialized
INFO - 2018-02-20 23:17:30 --> Loader Class Initialized
INFO - 2018-02-20 23:17:30 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:30 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:30 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:30 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Controller Class Initialized
INFO - 2018-02-20 23:17:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:30 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:30 --> Total execution time: 0.1159
INFO - 2018-02-20 23:17:30 --> Config Class Initialized
INFO - 2018-02-20 23:17:30 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:30 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:30 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:30 --> URI Class Initialized
INFO - 2018-02-20 23:17:30 --> Router Class Initialized
INFO - 2018-02-20 23:17:30 --> Output Class Initialized
INFO - 2018-02-20 23:17:30 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:30 --> Input Class Initialized
INFO - 2018-02-20 23:17:30 --> Language Class Initialized
INFO - 2018-02-20 23:17:30 --> Loader Class Initialized
INFO - 2018-02-20 23:17:30 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:30 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:30 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:30 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Controller Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
INFO - 2018-02-20 23:17:30 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:35 --> Config Class Initialized
INFO - 2018-02-20 23:17:35 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:35 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:35 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:35 --> URI Class Initialized
INFO - 2018-02-20 23:17:35 --> Router Class Initialized
INFO - 2018-02-20 23:17:35 --> Output Class Initialized
INFO - 2018-02-20 23:17:35 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:35 --> Input Class Initialized
INFO - 2018-02-20 23:17:35 --> Language Class Initialized
INFO - 2018-02-20 23:17:35 --> Loader Class Initialized
INFO - 2018-02-20 23:17:35 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:35 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:35 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:35 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:35 --> Model Class Initialized
INFO - 2018-02-20 23:17:35 --> Controller Class Initialized
INFO - 2018-02-20 23:17:35 --> Model Class Initialized
INFO - 2018-02-20 23:17:35 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:35 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:35 --> Total execution time: 0.1373
INFO - 2018-02-20 23:17:36 --> Config Class Initialized
INFO - 2018-02-20 23:17:36 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:36 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:36 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:36 --> URI Class Initialized
INFO - 2018-02-20 23:17:36 --> Router Class Initialized
INFO - 2018-02-20 23:17:36 --> Output Class Initialized
INFO - 2018-02-20 23:17:36 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:36 --> Input Class Initialized
INFO - 2018-02-20 23:17:36 --> Language Class Initialized
INFO - 2018-02-20 23:17:36 --> Loader Class Initialized
INFO - 2018-02-20 23:17:36 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:36 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:36 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:36 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:36 --> Model Class Initialized
INFO - 2018-02-20 23:17:36 --> Controller Class Initialized
INFO - 2018-02-20 23:17:36 --> Model Class Initialized
INFO - 2018-02-20 23:17:36 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:38 --> Config Class Initialized
INFO - 2018-02-20 23:17:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:38 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:38 --> URI Class Initialized
INFO - 2018-02-20 23:17:38 --> Router Class Initialized
INFO - 2018-02-20 23:17:38 --> Output Class Initialized
INFO - 2018-02-20 23:17:38 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:38 --> Input Class Initialized
INFO - 2018-02-20 23:17:38 --> Language Class Initialized
INFO - 2018-02-20 23:17:39 --> Loader Class Initialized
INFO - 2018-02-20 23:17:39 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:39 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:39 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:39 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
INFO - 2018-02-20 23:17:39 --> Controller Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:39 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:39 --> Total execution time: 0.1383
INFO - 2018-02-20 23:17:39 --> Config Class Initialized
INFO - 2018-02-20 23:17:39 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:39 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:39 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:39 --> URI Class Initialized
INFO - 2018-02-20 23:17:39 --> Router Class Initialized
INFO - 2018-02-20 23:17:39 --> Output Class Initialized
INFO - 2018-02-20 23:17:39 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:39 --> Input Class Initialized
INFO - 2018-02-20 23:17:39 --> Language Class Initialized
INFO - 2018-02-20 23:17:39 --> Loader Class Initialized
INFO - 2018-02-20 23:17:39 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:39 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:39 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:39 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
INFO - 2018-02-20 23:17:39 --> Controller Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
INFO - 2018-02-20 23:17:39 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:40 --> Config Class Initialized
INFO - 2018-02-20 23:17:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:40 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:40 --> URI Class Initialized
INFO - 2018-02-20 23:17:40 --> Router Class Initialized
INFO - 2018-02-20 23:17:40 --> Output Class Initialized
INFO - 2018-02-20 23:17:40 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:40 --> Input Class Initialized
INFO - 2018-02-20 23:17:40 --> Language Class Initialized
INFO - 2018-02-20 23:17:40 --> Loader Class Initialized
INFO - 2018-02-20 23:17:40 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:40 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:40 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
INFO - 2018-02-20 23:17:40 --> Controller Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:40 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:40 --> Total execution time: 0.0486
INFO - 2018-02-20 23:17:40 --> Config Class Initialized
INFO - 2018-02-20 23:17:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:40 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:40 --> URI Class Initialized
INFO - 2018-02-20 23:17:40 --> Router Class Initialized
INFO - 2018-02-20 23:17:40 --> Output Class Initialized
INFO - 2018-02-20 23:17:40 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:40 --> Input Class Initialized
INFO - 2018-02-20 23:17:40 --> Language Class Initialized
INFO - 2018-02-20 23:17:40 --> Loader Class Initialized
INFO - 2018-02-20 23:17:40 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:40 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:40 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
INFO - 2018-02-20 23:17:40 --> Controller Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
INFO - 2018-02-20 23:17:40 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:42 --> Config Class Initialized
INFO - 2018-02-20 23:17:42 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:17:42 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:17:42 --> Utf8 Class Initialized
INFO - 2018-02-20 23:17:42 --> URI Class Initialized
INFO - 2018-02-20 23:17:42 --> Router Class Initialized
INFO - 2018-02-20 23:17:42 --> Output Class Initialized
INFO - 2018-02-20 23:17:42 --> Security Class Initialized
DEBUG - 2018-02-20 23:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:17:42 --> Input Class Initialized
INFO - 2018-02-20 23:17:42 --> Language Class Initialized
INFO - 2018-02-20 23:17:42 --> Loader Class Initialized
INFO - 2018-02-20 23:17:42 --> Helper loaded: url_helper
INFO - 2018-02-20 23:17:42 --> Helper loaded: form_helper
INFO - 2018-02-20 23:17:42 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:17:42 --> Form Validation Class Initialized
INFO - 2018-02-20 23:17:42 --> Model Class Initialized
INFO - 2018-02-20 23:17:42 --> Controller Class Initialized
INFO - 2018-02-20 23:17:42 --> Model Class Initialized
INFO - 2018-02-20 23:17:42 --> Model Class Initialized
DEBUG - 2018-02-20 23:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:17:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:17:42 --> Final output sent to browser
DEBUG - 2018-02-20 23:17:42 --> Total execution time: 0.1455
INFO - 2018-02-20 23:23:06 --> Config Class Initialized
INFO - 2018-02-20 23:23:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:06 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:06 --> URI Class Initialized
INFO - 2018-02-20 23:23:06 --> Router Class Initialized
INFO - 2018-02-20 23:23:06 --> Output Class Initialized
INFO - 2018-02-20 23:23:06 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:06 --> Input Class Initialized
INFO - 2018-02-20 23:23:06 --> Language Class Initialized
INFO - 2018-02-20 23:23:06 --> Loader Class Initialized
INFO - 2018-02-20 23:23:06 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:06 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:06 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:06 --> Model Class Initialized
INFO - 2018-02-20 23:23:06 --> Controller Class Initialized
INFO - 2018-02-20 23:23:06 --> Model Class Initialized
INFO - 2018-02-20 23:23:06 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:23:06 --> Final output sent to browser
DEBUG - 2018-02-20 23:23:06 --> Total execution time: 0.0505
INFO - 2018-02-20 23:23:10 --> Config Class Initialized
INFO - 2018-02-20 23:23:10 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:10 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:10 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:10 --> URI Class Initialized
INFO - 2018-02-20 23:23:10 --> Router Class Initialized
INFO - 2018-02-20 23:23:10 --> Output Class Initialized
INFO - 2018-02-20 23:23:10 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:10 --> Input Class Initialized
INFO - 2018-02-20 23:23:10 --> Language Class Initialized
INFO - 2018-02-20 23:23:10 --> Loader Class Initialized
INFO - 2018-02-20 23:23:10 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:10 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:10 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:10 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:10 --> Model Class Initialized
INFO - 2018-02-20 23:23:10 --> Controller Class Initialized
INFO - 2018-02-20 23:23:10 --> Model Class Initialized
INFO - 2018-02-20 23:23:10 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:23:10 --> Final output sent to browser
DEBUG - 2018-02-20 23:23:10 --> Total execution time: 0.0440
INFO - 2018-02-20 23:23:11 --> Config Class Initialized
INFO - 2018-02-20 23:23:11 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:11 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:11 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:11 --> URI Class Initialized
INFO - 2018-02-20 23:23:11 --> Router Class Initialized
INFO - 2018-02-20 23:23:11 --> Output Class Initialized
INFO - 2018-02-20 23:23:11 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:11 --> Input Class Initialized
INFO - 2018-02-20 23:23:11 --> Language Class Initialized
INFO - 2018-02-20 23:23:11 --> Loader Class Initialized
INFO - 2018-02-20 23:23:11 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:11 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:11 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:11 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:11 --> Model Class Initialized
INFO - 2018-02-20 23:23:11 --> Controller Class Initialized
INFO - 2018-02-20 23:23:11 --> Model Class Initialized
INFO - 2018-02-20 23:23:11 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:18 --> Config Class Initialized
INFO - 2018-02-20 23:23:18 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:18 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:18 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:18 --> URI Class Initialized
INFO - 2018-02-20 23:23:18 --> Router Class Initialized
INFO - 2018-02-20 23:23:18 --> Output Class Initialized
INFO - 2018-02-20 23:23:18 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:18 --> Input Class Initialized
INFO - 2018-02-20 23:23:18 --> Language Class Initialized
INFO - 2018-02-20 23:23:18 --> Loader Class Initialized
INFO - 2018-02-20 23:23:18 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:18 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:18 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
INFO - 2018-02-20 23:23:18 --> Controller Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:23:18 --> Final output sent to browser
DEBUG - 2018-02-20 23:23:18 --> Total execution time: 0.0478
INFO - 2018-02-20 23:23:18 --> Config Class Initialized
INFO - 2018-02-20 23:23:18 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:18 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:18 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:18 --> URI Class Initialized
INFO - 2018-02-20 23:23:18 --> Router Class Initialized
INFO - 2018-02-20 23:23:18 --> Output Class Initialized
INFO - 2018-02-20 23:23:18 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:18 --> Input Class Initialized
INFO - 2018-02-20 23:23:18 --> Language Class Initialized
INFO - 2018-02-20 23:23:18 --> Loader Class Initialized
INFO - 2018-02-20 23:23:18 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:18 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:18 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
INFO - 2018-02-20 23:23:18 --> Controller Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
INFO - 2018-02-20 23:23:18 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:24 --> Config Class Initialized
INFO - 2018-02-20 23:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:23:24 --> Utf8 Class Initialized
INFO - 2018-02-20 23:23:24 --> URI Class Initialized
INFO - 2018-02-20 23:23:24 --> Router Class Initialized
INFO - 2018-02-20 23:23:24 --> Output Class Initialized
INFO - 2018-02-20 23:23:24 --> Security Class Initialized
DEBUG - 2018-02-20 23:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:23:24 --> Input Class Initialized
INFO - 2018-02-20 23:23:24 --> Language Class Initialized
INFO - 2018-02-20 23:23:24 --> Loader Class Initialized
INFO - 2018-02-20 23:23:24 --> Helper loaded: url_helper
INFO - 2018-02-20 23:23:24 --> Helper loaded: form_helper
INFO - 2018-02-20 23:23:24 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:23:24 --> Form Validation Class Initialized
INFO - 2018-02-20 23:23:24 --> Model Class Initialized
INFO - 2018-02-20 23:23:24 --> Controller Class Initialized
INFO - 2018-02-20 23:23:24 --> Model Class Initialized
INFO - 2018-02-20 23:23:24 --> Model Class Initialized
DEBUG - 2018-02-20 23:23:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:23:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:23:24 --> Final output sent to browser
DEBUG - 2018-02-20 23:23:24 --> Total execution time: 0.1149
INFO - 2018-02-20 23:24:09 --> Config Class Initialized
INFO - 2018-02-20 23:24:09 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:24:09 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:24:09 --> Utf8 Class Initialized
INFO - 2018-02-20 23:24:09 --> URI Class Initialized
INFO - 2018-02-20 23:24:09 --> Router Class Initialized
INFO - 2018-02-20 23:24:09 --> Output Class Initialized
INFO - 2018-02-20 23:24:09 --> Security Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:24:09 --> Input Class Initialized
INFO - 2018-02-20 23:24:09 --> Language Class Initialized
INFO - 2018-02-20 23:24:09 --> Loader Class Initialized
INFO - 2018-02-20 23:24:09 --> Helper loaded: url_helper
INFO - 2018-02-20 23:24:09 --> Helper loaded: form_helper
INFO - 2018-02-20 23:24:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:24:09 --> Form Validation Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
INFO - 2018-02-20 23:24:09 --> Controller Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:24:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:24:09 --> Final output sent to browser
DEBUG - 2018-02-20 23:24:09 --> Total execution time: 0.0606
INFO - 2018-02-20 23:24:09 --> Config Class Initialized
INFO - 2018-02-20 23:24:09 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:24:09 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:24:09 --> Utf8 Class Initialized
INFO - 2018-02-20 23:24:09 --> URI Class Initialized
INFO - 2018-02-20 23:24:09 --> Router Class Initialized
INFO - 2018-02-20 23:24:09 --> Output Class Initialized
INFO - 2018-02-20 23:24:09 --> Security Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:24:09 --> Input Class Initialized
INFO - 2018-02-20 23:24:09 --> Language Class Initialized
INFO - 2018-02-20 23:24:09 --> Loader Class Initialized
INFO - 2018-02-20 23:24:09 --> Helper loaded: url_helper
INFO - 2018-02-20 23:24:09 --> Helper loaded: form_helper
INFO - 2018-02-20 23:24:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:24:09 --> Form Validation Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
INFO - 2018-02-20 23:24:09 --> Controller Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
INFO - 2018-02-20 23:24:09 --> Model Class Initialized
DEBUG - 2018-02-20 23:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:50 --> Config Class Initialized
INFO - 2018-02-20 23:26:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:50 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:50 --> URI Class Initialized
INFO - 2018-02-20 23:26:50 --> Router Class Initialized
INFO - 2018-02-20 23:26:50 --> Output Class Initialized
INFO - 2018-02-20 23:26:50 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:50 --> Input Class Initialized
INFO - 2018-02-20 23:26:50 --> Language Class Initialized
INFO - 2018-02-20 23:26:50 --> Loader Class Initialized
INFO - 2018-02-20 23:26:50 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:50 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:50 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Controller Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:50 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:50 --> Total execution time: 0.0553
INFO - 2018-02-20 23:26:50 --> Config Class Initialized
INFO - 2018-02-20 23:26:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:50 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:50 --> URI Class Initialized
INFO - 2018-02-20 23:26:50 --> Router Class Initialized
INFO - 2018-02-20 23:26:50 --> Output Class Initialized
INFO - 2018-02-20 23:26:50 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:50 --> Input Class Initialized
INFO - 2018-02-20 23:26:50 --> Language Class Initialized
INFO - 2018-02-20 23:26:50 --> Loader Class Initialized
INFO - 2018-02-20 23:26:50 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:50 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:50 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Controller Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
INFO - 2018-02-20 23:26:50 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:51 --> Config Class Initialized
INFO - 2018-02-20 23:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:51 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:51 --> URI Class Initialized
INFO - 2018-02-20 23:26:51 --> Router Class Initialized
INFO - 2018-02-20 23:26:51 --> Output Class Initialized
INFO - 2018-02-20 23:26:51 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:51 --> Input Class Initialized
INFO - 2018-02-20 23:26:51 --> Language Class Initialized
INFO - 2018-02-20 23:26:51 --> Loader Class Initialized
INFO - 2018-02-20 23:26:51 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:51 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:51 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
INFO - 2018-02-20 23:26:51 --> Controller Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:51 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:51 --> Total execution time: 0.0496
INFO - 2018-02-20 23:26:51 --> Config Class Initialized
INFO - 2018-02-20 23:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:51 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:51 --> URI Class Initialized
INFO - 2018-02-20 23:26:51 --> Router Class Initialized
INFO - 2018-02-20 23:26:51 --> Output Class Initialized
INFO - 2018-02-20 23:26:51 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:51 --> Input Class Initialized
INFO - 2018-02-20 23:26:51 --> Language Class Initialized
INFO - 2018-02-20 23:26:51 --> Loader Class Initialized
INFO - 2018-02-20 23:26:51 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:51 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:51 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
INFO - 2018-02-20 23:26:51 --> Controller Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
INFO - 2018-02-20 23:26:51 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:52 --> Config Class Initialized
INFO - 2018-02-20 23:26:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:52 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:52 --> URI Class Initialized
INFO - 2018-02-20 23:26:52 --> Router Class Initialized
INFO - 2018-02-20 23:26:52 --> Output Class Initialized
INFO - 2018-02-20 23:26:52 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:52 --> Input Class Initialized
INFO - 2018-02-20 23:26:52 --> Language Class Initialized
INFO - 2018-02-20 23:26:52 --> Loader Class Initialized
INFO - 2018-02-20 23:26:52 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:52 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:52 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
INFO - 2018-02-20 23:26:52 --> Controller Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:52 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:52 --> Total execution time: 0.0577
INFO - 2018-02-20 23:26:52 --> Config Class Initialized
INFO - 2018-02-20 23:26:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:52 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:52 --> URI Class Initialized
INFO - 2018-02-20 23:26:52 --> Router Class Initialized
INFO - 2018-02-20 23:26:52 --> Output Class Initialized
INFO - 2018-02-20 23:26:52 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:52 --> Input Class Initialized
INFO - 2018-02-20 23:26:52 --> Language Class Initialized
INFO - 2018-02-20 23:26:52 --> Loader Class Initialized
INFO - 2018-02-20 23:26:52 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:52 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:52 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
INFO - 2018-02-20 23:26:52 --> Controller Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
INFO - 2018-02-20 23:26:52 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:54 --> Config Class Initialized
INFO - 2018-02-20 23:26:54 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:54 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:54 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:54 --> URI Class Initialized
INFO - 2018-02-20 23:26:54 --> Router Class Initialized
INFO - 2018-02-20 23:26:54 --> Output Class Initialized
INFO - 2018-02-20 23:26:54 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:54 --> Input Class Initialized
INFO - 2018-02-20 23:26:54 --> Language Class Initialized
INFO - 2018-02-20 23:26:54 --> Loader Class Initialized
INFO - 2018-02-20 23:26:54 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:54 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:54 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:54 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:54 --> Model Class Initialized
INFO - 2018-02-20 23:26:54 --> Controller Class Initialized
INFO - 2018-02-20 23:26:54 --> Model Class Initialized
INFO - 2018-02-20 23:26:54 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:54 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:54 --> Total execution time: 0.0511
INFO - 2018-02-20 23:26:57 --> Config Class Initialized
INFO - 2018-02-20 23:26:57 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:58 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:58 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:58 --> URI Class Initialized
INFO - 2018-02-20 23:26:58 --> Router Class Initialized
INFO - 2018-02-20 23:26:58 --> Output Class Initialized
INFO - 2018-02-20 23:26:58 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:58 --> Input Class Initialized
INFO - 2018-02-20 23:26:58 --> Language Class Initialized
INFO - 2018-02-20 23:26:58 --> Loader Class Initialized
INFO - 2018-02-20 23:26:58 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:58 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:58 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:58 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:58 --> Model Class Initialized
INFO - 2018-02-20 23:26:58 --> Controller Class Initialized
INFO - 2018-02-20 23:26:58 --> Model Class Initialized
INFO - 2018-02-20 23:26:58 --> Model Class Initialized
INFO - 2018-02-20 23:26:58 --> Model Class Initialized
INFO - 2018-02-20 23:26:58 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:58 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:58 --> Total execution time: 0.1820
INFO - 2018-02-20 23:26:59 --> Config Class Initialized
INFO - 2018-02-20 23:26:59 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:59 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:59 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:59 --> URI Class Initialized
INFO - 2018-02-20 23:26:59 --> Router Class Initialized
INFO - 2018-02-20 23:26:59 --> Output Class Initialized
INFO - 2018-02-20 23:26:59 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:59 --> Input Class Initialized
INFO - 2018-02-20 23:26:59 --> Language Class Initialized
INFO - 2018-02-20 23:26:59 --> Loader Class Initialized
INFO - 2018-02-20 23:26:59 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:59 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:59 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:59 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
INFO - 2018-02-20 23:26:59 --> Controller Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:26:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:26:59 --> Final output sent to browser
DEBUG - 2018-02-20 23:26:59 --> Total execution time: 0.0551
INFO - 2018-02-20 23:26:59 --> Config Class Initialized
INFO - 2018-02-20 23:26:59 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:26:59 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:26:59 --> Utf8 Class Initialized
INFO - 2018-02-20 23:26:59 --> URI Class Initialized
INFO - 2018-02-20 23:26:59 --> Router Class Initialized
INFO - 2018-02-20 23:26:59 --> Output Class Initialized
INFO - 2018-02-20 23:26:59 --> Security Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:26:59 --> Input Class Initialized
INFO - 2018-02-20 23:26:59 --> Language Class Initialized
INFO - 2018-02-20 23:26:59 --> Loader Class Initialized
INFO - 2018-02-20 23:26:59 --> Helper loaded: url_helper
INFO - 2018-02-20 23:26:59 --> Helper loaded: form_helper
INFO - 2018-02-20 23:26:59 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:26:59 --> Form Validation Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
INFO - 2018-02-20 23:26:59 --> Controller Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
INFO - 2018-02-20 23:26:59 --> Model Class Initialized
DEBUG - 2018-02-20 23:26:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:27:08 --> Config Class Initialized
INFO - 2018-02-20 23:27:08 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:27:08 --> Utf8 Class Initialized
INFO - 2018-02-20 23:27:08 --> URI Class Initialized
INFO - 2018-02-20 23:27:08 --> Router Class Initialized
INFO - 2018-02-20 23:27:08 --> Output Class Initialized
INFO - 2018-02-20 23:27:08 --> Security Class Initialized
DEBUG - 2018-02-20 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:27:08 --> Input Class Initialized
INFO - 2018-02-20 23:27:08 --> Language Class Initialized
INFO - 2018-02-20 23:27:08 --> Loader Class Initialized
INFO - 2018-02-20 23:27:08 --> Helper loaded: url_helper
INFO - 2018-02-20 23:27:08 --> Helper loaded: form_helper
INFO - 2018-02-20 23:27:08 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:27:08 --> Form Validation Class Initialized
INFO - 2018-02-20 23:27:08 --> Model Class Initialized
INFO - 2018-02-20 23:27:08 --> Controller Class Initialized
INFO - 2018-02-20 23:27:08 --> Model Class Initialized
DEBUG - 2018-02-20 23:27:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:27:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:27:08 --> Final output sent to browser
DEBUG - 2018-02-20 23:27:08 --> Total execution time: 0.1383
INFO - 2018-02-20 23:27:08 --> Config Class Initialized
INFO - 2018-02-20 23:27:08 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:27:08 --> Utf8 Class Initialized
INFO - 2018-02-20 23:27:08 --> URI Class Initialized
INFO - 2018-02-20 23:27:08 --> Router Class Initialized
INFO - 2018-02-20 23:27:08 --> Output Class Initialized
INFO - 2018-02-20 23:27:08 --> Security Class Initialized
DEBUG - 2018-02-20 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:27:08 --> Input Class Initialized
INFO - 2018-02-20 23:27:08 --> Language Class Initialized
INFO - 2018-02-20 23:27:08 --> Loader Class Initialized
INFO - 2018-02-20 23:27:08 --> Helper loaded: url_helper
INFO - 2018-02-20 23:27:08 --> Helper loaded: form_helper
INFO - 2018-02-20 23:27:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:27:09 --> Form Validation Class Initialized
INFO - 2018-02-20 23:27:09 --> Model Class Initialized
INFO - 2018-02-20 23:27:09 --> Controller Class Initialized
INFO - 2018-02-20 23:27:09 --> Model Class Initialized
DEBUG - 2018-02-20 23:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:27:10 --> Config Class Initialized
INFO - 2018-02-20 23:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:27:10 --> Utf8 Class Initialized
INFO - 2018-02-20 23:27:10 --> URI Class Initialized
INFO - 2018-02-20 23:27:10 --> Router Class Initialized
INFO - 2018-02-20 23:27:10 --> Output Class Initialized
INFO - 2018-02-20 23:27:10 --> Security Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:27:10 --> Input Class Initialized
INFO - 2018-02-20 23:27:10 --> Language Class Initialized
INFO - 2018-02-20 23:27:10 --> Loader Class Initialized
INFO - 2018-02-20 23:27:10 --> Helper loaded: url_helper
INFO - 2018-02-20 23:27:10 --> Helper loaded: form_helper
INFO - 2018-02-20 23:27:10 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:27:10 --> Form Validation Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
INFO - 2018-02-20 23:27:10 --> Controller Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:27:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:27:10 --> Final output sent to browser
DEBUG - 2018-02-20 23:27:10 --> Total execution time: 0.0506
INFO - 2018-02-20 23:27:10 --> Config Class Initialized
INFO - 2018-02-20 23:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:27:10 --> Utf8 Class Initialized
INFO - 2018-02-20 23:27:10 --> URI Class Initialized
INFO - 2018-02-20 23:27:10 --> Router Class Initialized
INFO - 2018-02-20 23:27:10 --> Output Class Initialized
INFO - 2018-02-20 23:27:10 --> Security Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:27:10 --> Input Class Initialized
INFO - 2018-02-20 23:27:10 --> Language Class Initialized
INFO - 2018-02-20 23:27:10 --> Loader Class Initialized
INFO - 2018-02-20 23:27:10 --> Helper loaded: url_helper
INFO - 2018-02-20 23:27:10 --> Helper loaded: form_helper
INFO - 2018-02-20 23:27:10 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:27:10 --> Form Validation Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
INFO - 2018-02-20 23:27:10 --> Controller Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
INFO - 2018-02-20 23:27:10 --> Model Class Initialized
DEBUG - 2018-02-20 23:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:29:40 --> Config Class Initialized
INFO - 2018-02-20 23:29:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:29:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:29:40 --> Utf8 Class Initialized
INFO - 2018-02-20 23:29:40 --> URI Class Initialized
INFO - 2018-02-20 23:29:40 --> Router Class Initialized
INFO - 2018-02-20 23:29:40 --> Output Class Initialized
INFO - 2018-02-20 23:29:40 --> Security Class Initialized
DEBUG - 2018-02-20 23:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:29:40 --> Input Class Initialized
INFO - 2018-02-20 23:29:40 --> Language Class Initialized
INFO - 2018-02-20 23:29:40 --> Loader Class Initialized
INFO - 2018-02-20 23:29:40 --> Helper loaded: url_helper
INFO - 2018-02-20 23:29:40 --> Helper loaded: form_helper
INFO - 2018-02-20 23:29:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:29:40 --> Form Validation Class Initialized
INFO - 2018-02-20 23:29:40 --> Model Class Initialized
INFO - 2018-02-20 23:29:40 --> Controller Class Initialized
INFO - 2018-02-20 23:29:40 --> Model Class Initialized
INFO - 2018-02-20 23:29:40 --> Model Class Initialized
DEBUG - 2018-02-20 23:29:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:29:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:29:40 --> Final output sent to browser
DEBUG - 2018-02-20 23:29:40 --> Total execution time: 0.0538
INFO - 2018-02-20 23:29:41 --> Config Class Initialized
INFO - 2018-02-20 23:29:41 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:29:41 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:29:41 --> Utf8 Class Initialized
INFO - 2018-02-20 23:29:41 --> URI Class Initialized
INFO - 2018-02-20 23:29:41 --> Router Class Initialized
INFO - 2018-02-20 23:29:41 --> Output Class Initialized
INFO - 2018-02-20 23:29:41 --> Security Class Initialized
DEBUG - 2018-02-20 23:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:29:41 --> Input Class Initialized
INFO - 2018-02-20 23:29:41 --> Language Class Initialized
INFO - 2018-02-20 23:29:41 --> Loader Class Initialized
INFO - 2018-02-20 23:29:41 --> Helper loaded: url_helper
INFO - 2018-02-20 23:29:41 --> Helper loaded: form_helper
INFO - 2018-02-20 23:29:41 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:29:41 --> Form Validation Class Initialized
INFO - 2018-02-20 23:29:41 --> Model Class Initialized
INFO - 2018-02-20 23:29:41 --> Controller Class Initialized
INFO - 2018-02-20 23:29:41 --> Model Class Initialized
INFO - 2018-02-20 23:29:41 --> Model Class Initialized
DEBUG - 2018-02-20 23:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:38 --> Config Class Initialized
INFO - 2018-02-20 23:30:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:38 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:38 --> URI Class Initialized
INFO - 2018-02-20 23:30:38 --> Router Class Initialized
INFO - 2018-02-20 23:30:38 --> Output Class Initialized
INFO - 2018-02-20 23:30:38 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:38 --> Input Class Initialized
INFO - 2018-02-20 23:30:38 --> Language Class Initialized
INFO - 2018-02-20 23:30:38 --> Loader Class Initialized
INFO - 2018-02-20 23:30:38 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:38 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:38 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
INFO - 2018-02-20 23:30:38 --> Controller Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:38 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:38 --> Total execution time: 0.0470
INFO - 2018-02-20 23:30:38 --> Config Class Initialized
INFO - 2018-02-20 23:30:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:38 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:38 --> URI Class Initialized
INFO - 2018-02-20 23:30:38 --> Router Class Initialized
INFO - 2018-02-20 23:30:38 --> Output Class Initialized
INFO - 2018-02-20 23:30:38 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:38 --> Input Class Initialized
INFO - 2018-02-20 23:30:38 --> Language Class Initialized
INFO - 2018-02-20 23:30:38 --> Loader Class Initialized
INFO - 2018-02-20 23:30:38 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:38 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:38 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
INFO - 2018-02-20 23:30:38 --> Controller Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
INFO - 2018-02-20 23:30:38 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:42 --> Config Class Initialized
INFO - 2018-02-20 23:30:42 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:42 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:42 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:42 --> URI Class Initialized
INFO - 2018-02-20 23:30:42 --> Router Class Initialized
INFO - 2018-02-20 23:30:42 --> Output Class Initialized
INFO - 2018-02-20 23:30:42 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:42 --> Input Class Initialized
INFO - 2018-02-20 23:30:42 --> Language Class Initialized
INFO - 2018-02-20 23:30:42 --> Loader Class Initialized
INFO - 2018-02-20 23:30:42 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:42 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:42 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:42 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:42 --> Model Class Initialized
INFO - 2018-02-20 23:30:42 --> Controller Class Initialized
INFO - 2018-02-20 23:30:42 --> Model Class Initialized
INFO - 2018-02-20 23:30:42 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:42 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:42 --> Total execution time: 0.1096
INFO - 2018-02-20 23:30:43 --> Config Class Initialized
INFO - 2018-02-20 23:30:43 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:43 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:43 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:43 --> URI Class Initialized
INFO - 2018-02-20 23:30:43 --> Router Class Initialized
INFO - 2018-02-20 23:30:43 --> Output Class Initialized
INFO - 2018-02-20 23:30:43 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:43 --> Input Class Initialized
INFO - 2018-02-20 23:30:43 --> Language Class Initialized
INFO - 2018-02-20 23:30:43 --> Loader Class Initialized
INFO - 2018-02-20 23:30:43 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:43 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:43 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:44 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
INFO - 2018-02-20 23:30:44 --> Controller Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:44 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:44 --> Total execution time: 0.0495
INFO - 2018-02-20 23:30:44 --> Config Class Initialized
INFO - 2018-02-20 23:30:44 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:44 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:44 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:44 --> URI Class Initialized
INFO - 2018-02-20 23:30:44 --> Router Class Initialized
INFO - 2018-02-20 23:30:44 --> Output Class Initialized
INFO - 2018-02-20 23:30:44 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:44 --> Input Class Initialized
INFO - 2018-02-20 23:30:44 --> Language Class Initialized
INFO - 2018-02-20 23:30:44 --> Loader Class Initialized
INFO - 2018-02-20 23:30:44 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:44 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:44 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:44 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
INFO - 2018-02-20 23:30:44 --> Controller Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
INFO - 2018-02-20 23:30:44 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:52 --> Config Class Initialized
INFO - 2018-02-20 23:30:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:52 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:52 --> URI Class Initialized
INFO - 2018-02-20 23:30:52 --> Router Class Initialized
INFO - 2018-02-20 23:30:52 --> Output Class Initialized
INFO - 2018-02-20 23:30:52 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:52 --> Input Class Initialized
INFO - 2018-02-20 23:30:52 --> Language Class Initialized
INFO - 2018-02-20 23:30:52 --> Loader Class Initialized
INFO - 2018-02-20 23:30:52 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:52 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:52 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:52 --> Model Class Initialized
INFO - 2018-02-20 23:30:52 --> Controller Class Initialized
INFO - 2018-02-20 23:30:52 --> Model Class Initialized
INFO - 2018-02-20 23:30:52 --> Model Class Initialized
INFO - 2018-02-20 23:30:52 --> Model Class Initialized
INFO - 2018-02-20 23:30:52 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:52 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:52 --> Total execution time: 0.0646
INFO - 2018-02-20 23:30:53 --> Config Class Initialized
INFO - 2018-02-20 23:30:53 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:53 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:53 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:53 --> URI Class Initialized
INFO - 2018-02-20 23:30:53 --> Router Class Initialized
INFO - 2018-02-20 23:30:53 --> Output Class Initialized
INFO - 2018-02-20 23:30:54 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:54 --> Input Class Initialized
INFO - 2018-02-20 23:30:54 --> Language Class Initialized
INFO - 2018-02-20 23:30:54 --> Loader Class Initialized
INFO - 2018-02-20 23:30:54 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:54 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:54 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:54 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
INFO - 2018-02-20 23:30:54 --> Controller Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:54 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:54 --> Total execution time: 0.0554
INFO - 2018-02-20 23:30:54 --> Config Class Initialized
INFO - 2018-02-20 23:30:54 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:54 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:54 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:54 --> URI Class Initialized
INFO - 2018-02-20 23:30:54 --> Router Class Initialized
INFO - 2018-02-20 23:30:54 --> Output Class Initialized
INFO - 2018-02-20 23:30:54 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:54 --> Input Class Initialized
INFO - 2018-02-20 23:30:54 --> Language Class Initialized
INFO - 2018-02-20 23:30:54 --> Loader Class Initialized
INFO - 2018-02-20 23:30:54 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:54 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:54 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:54 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
INFO - 2018-02-20 23:30:54 --> Controller Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
INFO - 2018-02-20 23:30:54 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:55 --> Config Class Initialized
INFO - 2018-02-20 23:30:55 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:55 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:55 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:55 --> URI Class Initialized
INFO - 2018-02-20 23:30:55 --> Router Class Initialized
INFO - 2018-02-20 23:30:55 --> Output Class Initialized
INFO - 2018-02-20 23:30:55 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:55 --> Input Class Initialized
INFO - 2018-02-20 23:30:55 --> Language Class Initialized
INFO - 2018-02-20 23:30:55 --> Loader Class Initialized
INFO - 2018-02-20 23:30:55 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:55 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:55 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:55 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:55 --> Model Class Initialized
INFO - 2018-02-20 23:30:55 --> Controller Class Initialized
INFO - 2018-02-20 23:30:55 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:30:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:30:55 --> Final output sent to browser
DEBUG - 2018-02-20 23:30:55 --> Total execution time: 0.0489
INFO - 2018-02-20 23:30:55 --> Config Class Initialized
INFO - 2018-02-20 23:30:55 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:30:55 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:30:55 --> Utf8 Class Initialized
INFO - 2018-02-20 23:30:55 --> URI Class Initialized
INFO - 2018-02-20 23:30:55 --> Router Class Initialized
INFO - 2018-02-20 23:30:55 --> Output Class Initialized
INFO - 2018-02-20 23:30:55 --> Security Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:30:55 --> Input Class Initialized
INFO - 2018-02-20 23:30:55 --> Language Class Initialized
INFO - 2018-02-20 23:30:55 --> Loader Class Initialized
INFO - 2018-02-20 23:30:55 --> Helper loaded: url_helper
INFO - 2018-02-20 23:30:55 --> Helper loaded: form_helper
INFO - 2018-02-20 23:30:55 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:30:55 --> Form Validation Class Initialized
INFO - 2018-02-20 23:30:55 --> Model Class Initialized
INFO - 2018-02-20 23:30:55 --> Controller Class Initialized
INFO - 2018-02-20 23:30:55 --> Model Class Initialized
DEBUG - 2018-02-20 23:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:31:42 --> Config Class Initialized
INFO - 2018-02-20 23:31:42 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:31:42 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:31:42 --> Utf8 Class Initialized
INFO - 2018-02-20 23:31:42 --> URI Class Initialized
INFO - 2018-02-20 23:31:42 --> Router Class Initialized
INFO - 2018-02-20 23:31:42 --> Output Class Initialized
INFO - 2018-02-20 23:31:42 --> Security Class Initialized
DEBUG - 2018-02-20 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:31:42 --> Input Class Initialized
INFO - 2018-02-20 23:31:42 --> Language Class Initialized
INFO - 2018-02-20 23:31:42 --> Loader Class Initialized
INFO - 2018-02-20 23:31:42 --> Helper loaded: url_helper
INFO - 2018-02-20 23:31:42 --> Helper loaded: form_helper
INFO - 2018-02-20 23:31:42 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:31:42 --> Form Validation Class Initialized
INFO - 2018-02-20 23:31:42 --> Model Class Initialized
INFO - 2018-02-20 23:31:42 --> Controller Class Initialized
INFO - 2018-02-20 23:31:42 --> Model Class Initialized
DEBUG - 2018-02-20 23:31:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:31:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:31:42 --> Final output sent to browser
DEBUG - 2018-02-20 23:31:42 --> Total execution time: 0.0620
INFO - 2018-02-20 23:31:44 --> Config Class Initialized
INFO - 2018-02-20 23:31:44 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:31:44 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:31:44 --> Utf8 Class Initialized
INFO - 2018-02-20 23:31:44 --> URI Class Initialized
INFO - 2018-02-20 23:31:44 --> Router Class Initialized
INFO - 2018-02-20 23:31:44 --> Output Class Initialized
INFO - 2018-02-20 23:31:44 --> Security Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:31:44 --> Input Class Initialized
INFO - 2018-02-20 23:31:44 --> Language Class Initialized
INFO - 2018-02-20 23:31:44 --> Loader Class Initialized
INFO - 2018-02-20 23:31:44 --> Helper loaded: url_helper
INFO - 2018-02-20 23:31:44 --> Helper loaded: form_helper
INFO - 2018-02-20 23:31:44 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:31:44 --> Form Validation Class Initialized
INFO - 2018-02-20 23:31:44 --> Model Class Initialized
INFO - 2018-02-20 23:31:44 --> Controller Class Initialized
INFO - 2018-02-20 23:31:44 --> Model Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:31:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:31:44 --> Final output sent to browser
DEBUG - 2018-02-20 23:31:44 --> Total execution time: 0.0603
INFO - 2018-02-20 23:31:44 --> Config Class Initialized
INFO - 2018-02-20 23:31:44 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:31:44 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:31:44 --> Utf8 Class Initialized
INFO - 2018-02-20 23:31:44 --> URI Class Initialized
INFO - 2018-02-20 23:31:44 --> Router Class Initialized
INFO - 2018-02-20 23:31:44 --> Output Class Initialized
INFO - 2018-02-20 23:31:44 --> Security Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:31:44 --> Input Class Initialized
INFO - 2018-02-20 23:31:44 --> Language Class Initialized
INFO - 2018-02-20 23:31:44 --> Loader Class Initialized
INFO - 2018-02-20 23:31:44 --> Helper loaded: url_helper
INFO - 2018-02-20 23:31:44 --> Helper loaded: form_helper
INFO - 2018-02-20 23:31:44 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:31:44 --> Form Validation Class Initialized
INFO - 2018-02-20 23:31:44 --> Model Class Initialized
INFO - 2018-02-20 23:31:44 --> Controller Class Initialized
INFO - 2018-02-20 23:31:44 --> Model Class Initialized
DEBUG - 2018-02-20 23:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:33:52 --> Config Class Initialized
INFO - 2018-02-20 23:33:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:33:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:33:52 --> Utf8 Class Initialized
INFO - 2018-02-20 23:33:52 --> URI Class Initialized
INFO - 2018-02-20 23:33:52 --> Router Class Initialized
INFO - 2018-02-20 23:33:52 --> Output Class Initialized
INFO - 2018-02-20 23:33:52 --> Security Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:33:52 --> Input Class Initialized
INFO - 2018-02-20 23:33:52 --> Language Class Initialized
INFO - 2018-02-20 23:33:52 --> Loader Class Initialized
INFO - 2018-02-20 23:33:52 --> Helper loaded: url_helper
INFO - 2018-02-20 23:33:52 --> Helper loaded: form_helper
INFO - 2018-02-20 23:33:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:33:52 --> Form Validation Class Initialized
INFO - 2018-02-20 23:33:52 --> Model Class Initialized
INFO - 2018-02-20 23:33:52 --> Controller Class Initialized
INFO - 2018-02-20 23:33:52 --> Model Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:33:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:33:52 --> Final output sent to browser
DEBUG - 2018-02-20 23:33:52 --> Total execution time: 0.0606
INFO - 2018-02-20 23:33:52 --> Config Class Initialized
INFO - 2018-02-20 23:33:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:33:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:33:52 --> Utf8 Class Initialized
INFO - 2018-02-20 23:33:52 --> URI Class Initialized
INFO - 2018-02-20 23:33:52 --> Router Class Initialized
INFO - 2018-02-20 23:33:52 --> Output Class Initialized
INFO - 2018-02-20 23:33:52 --> Security Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:33:52 --> Input Class Initialized
INFO - 2018-02-20 23:33:52 --> Language Class Initialized
INFO - 2018-02-20 23:33:52 --> Loader Class Initialized
INFO - 2018-02-20 23:33:52 --> Helper loaded: url_helper
INFO - 2018-02-20 23:33:52 --> Helper loaded: form_helper
INFO - 2018-02-20 23:33:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:33:52 --> Form Validation Class Initialized
INFO - 2018-02-20 23:33:52 --> Model Class Initialized
INFO - 2018-02-20 23:33:52 --> Controller Class Initialized
INFO - 2018-02-20 23:33:52 --> Model Class Initialized
DEBUG - 2018-02-20 23:33:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:02 --> Config Class Initialized
INFO - 2018-02-20 23:35:02 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:02 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:02 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:02 --> URI Class Initialized
INFO - 2018-02-20 23:35:02 --> Router Class Initialized
INFO - 2018-02-20 23:35:02 --> Output Class Initialized
INFO - 2018-02-20 23:35:02 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:02 --> Input Class Initialized
INFO - 2018-02-20 23:35:02 --> Language Class Initialized
INFO - 2018-02-20 23:35:02 --> Loader Class Initialized
INFO - 2018-02-20 23:35:02 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:02 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:02 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:02 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:02 --> Model Class Initialized
INFO - 2018-02-20 23:35:02 --> Controller Class Initialized
INFO - 2018-02-20 23:35:02 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:02 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:02 --> Total execution time: 0.0583
INFO - 2018-02-20 23:35:04 --> Config Class Initialized
INFO - 2018-02-20 23:35:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:04 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:04 --> URI Class Initialized
INFO - 2018-02-20 23:35:04 --> Router Class Initialized
INFO - 2018-02-20 23:35:04 --> Output Class Initialized
INFO - 2018-02-20 23:35:04 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:04 --> Input Class Initialized
INFO - 2018-02-20 23:35:04 --> Language Class Initialized
INFO - 2018-02-20 23:35:04 --> Loader Class Initialized
INFO - 2018-02-20 23:35:04 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:04 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:04 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:04 --> Model Class Initialized
INFO - 2018-02-20 23:35:04 --> Controller Class Initialized
INFO - 2018-02-20 23:35:04 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:04 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:04 --> Total execution time: 0.0438
INFO - 2018-02-20 23:35:04 --> Config Class Initialized
INFO - 2018-02-20 23:35:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:04 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:04 --> URI Class Initialized
INFO - 2018-02-20 23:35:04 --> Router Class Initialized
INFO - 2018-02-20 23:35:04 --> Output Class Initialized
INFO - 2018-02-20 23:35:04 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:04 --> Input Class Initialized
INFO - 2018-02-20 23:35:04 --> Language Class Initialized
INFO - 2018-02-20 23:35:04 --> Loader Class Initialized
INFO - 2018-02-20 23:35:04 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:04 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:04 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:04 --> Model Class Initialized
INFO - 2018-02-20 23:35:04 --> Controller Class Initialized
INFO - 2018-02-20 23:35:04 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:06 --> Config Class Initialized
INFO - 2018-02-20 23:35:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:06 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:06 --> URI Class Initialized
INFO - 2018-02-20 23:35:06 --> Router Class Initialized
INFO - 2018-02-20 23:35:06 --> Output Class Initialized
INFO - 2018-02-20 23:35:06 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:06 --> Input Class Initialized
INFO - 2018-02-20 23:35:06 --> Language Class Initialized
INFO - 2018-02-20 23:35:06 --> Loader Class Initialized
INFO - 2018-02-20 23:35:06 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:06 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:06 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
INFO - 2018-02-20 23:35:06 --> Controller Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:06 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:06 --> Total execution time: 0.0648
INFO - 2018-02-20 23:35:06 --> Config Class Initialized
INFO - 2018-02-20 23:35:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:06 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:06 --> URI Class Initialized
INFO - 2018-02-20 23:35:06 --> Router Class Initialized
INFO - 2018-02-20 23:35:06 --> Output Class Initialized
INFO - 2018-02-20 23:35:06 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:06 --> Input Class Initialized
INFO - 2018-02-20 23:35:06 --> Language Class Initialized
INFO - 2018-02-20 23:35:06 --> Loader Class Initialized
INFO - 2018-02-20 23:35:06 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:06 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:06 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
INFO - 2018-02-20 23:35:06 --> Controller Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
INFO - 2018-02-20 23:35:06 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:07 --> Config Class Initialized
INFO - 2018-02-20 23:35:07 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:07 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:07 --> URI Class Initialized
INFO - 2018-02-20 23:35:07 --> Router Class Initialized
INFO - 2018-02-20 23:35:07 --> Output Class Initialized
INFO - 2018-02-20 23:35:07 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:07 --> Input Class Initialized
INFO - 2018-02-20 23:35:07 --> Language Class Initialized
INFO - 2018-02-20 23:35:07 --> Loader Class Initialized
INFO - 2018-02-20 23:35:07 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:07 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:07 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:07 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:07 --> Model Class Initialized
INFO - 2018-02-20 23:35:07 --> Controller Class Initialized
INFO - 2018-02-20 23:35:07 --> Model Class Initialized
INFO - 2018-02-20 23:35:07 --> Model Class Initialized
INFO - 2018-02-20 23:35:07 --> Model Class Initialized
INFO - 2018-02-20 23:35:07 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:07 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:07 --> Total execution time: 0.0538
INFO - 2018-02-20 23:35:09 --> Config Class Initialized
INFO - 2018-02-20 23:35:09 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:09 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:09 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:09 --> URI Class Initialized
INFO - 2018-02-20 23:35:09 --> Router Class Initialized
INFO - 2018-02-20 23:35:09 --> Output Class Initialized
INFO - 2018-02-20 23:35:09 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:09 --> Input Class Initialized
INFO - 2018-02-20 23:35:09 --> Language Class Initialized
INFO - 2018-02-20 23:35:09 --> Loader Class Initialized
INFO - 2018-02-20 23:35:09 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:09 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:09 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:09 --> Model Class Initialized
INFO - 2018-02-20 23:35:09 --> Controller Class Initialized
INFO - 2018-02-20 23:35:09 --> Model Class Initialized
INFO - 2018-02-20 23:35:09 --> Model Class Initialized
INFO - 2018-02-20 23:35:09 --> Model Class Initialized
INFO - 2018-02-20 23:35:09 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:09 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:09 --> Total execution time: 0.0610
INFO - 2018-02-20 23:35:11 --> Config Class Initialized
INFO - 2018-02-20 23:35:11 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:11 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:11 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:11 --> URI Class Initialized
INFO - 2018-02-20 23:35:11 --> Router Class Initialized
INFO - 2018-02-20 23:35:11 --> Output Class Initialized
INFO - 2018-02-20 23:35:11 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:11 --> Input Class Initialized
INFO - 2018-02-20 23:35:11 --> Language Class Initialized
INFO - 2018-02-20 23:35:11 --> Loader Class Initialized
INFO - 2018-02-20 23:35:11 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:11 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:11 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:11 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
INFO - 2018-02-20 23:35:11 --> Controller Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:11 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:11 --> Total execution time: 0.0604
INFO - 2018-02-20 23:35:11 --> Config Class Initialized
INFO - 2018-02-20 23:35:11 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:11 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:11 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:11 --> URI Class Initialized
INFO - 2018-02-20 23:35:11 --> Router Class Initialized
INFO - 2018-02-20 23:35:11 --> Output Class Initialized
INFO - 2018-02-20 23:35:11 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:11 --> Input Class Initialized
INFO - 2018-02-20 23:35:11 --> Language Class Initialized
INFO - 2018-02-20 23:35:11 --> Loader Class Initialized
INFO - 2018-02-20 23:35:11 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:11 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:11 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:11 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
INFO - 2018-02-20 23:35:11 --> Controller Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
INFO - 2018-02-20 23:35:11 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:12 --> Config Class Initialized
INFO - 2018-02-20 23:35:12 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:12 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:12 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:12 --> URI Class Initialized
INFO - 2018-02-20 23:35:12 --> Router Class Initialized
INFO - 2018-02-20 23:35:12 --> Output Class Initialized
INFO - 2018-02-20 23:35:12 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:12 --> Input Class Initialized
INFO - 2018-02-20 23:35:12 --> Language Class Initialized
INFO - 2018-02-20 23:35:12 --> Loader Class Initialized
INFO - 2018-02-20 23:35:12 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:12 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:12 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:12 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Controller Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:12 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:12 --> Total execution time: 0.0603
INFO - 2018-02-20 23:35:12 --> Config Class Initialized
INFO - 2018-02-20 23:35:12 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:12 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:12 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:12 --> URI Class Initialized
INFO - 2018-02-20 23:35:12 --> Router Class Initialized
INFO - 2018-02-20 23:35:12 --> Output Class Initialized
INFO - 2018-02-20 23:35:12 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:12 --> Input Class Initialized
INFO - 2018-02-20 23:35:12 --> Language Class Initialized
INFO - 2018-02-20 23:35:12 --> Loader Class Initialized
INFO - 2018-02-20 23:35:12 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:12 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:12 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:12 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Controller Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
INFO - 2018-02-20 23:35:12 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:15 --> Config Class Initialized
INFO - 2018-02-20 23:35:15 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:15 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:15 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:15 --> URI Class Initialized
INFO - 2018-02-20 23:35:15 --> Router Class Initialized
INFO - 2018-02-20 23:35:15 --> Output Class Initialized
INFO - 2018-02-20 23:35:15 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:15 --> Input Class Initialized
INFO - 2018-02-20 23:35:15 --> Language Class Initialized
INFO - 2018-02-20 23:35:15 --> Loader Class Initialized
INFO - 2018-02-20 23:35:15 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:15 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:15 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Controller Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:35:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:35:15 --> Final output sent to browser
DEBUG - 2018-02-20 23:35:15 --> Total execution time: 0.1919
INFO - 2018-02-20 23:35:15 --> Config Class Initialized
INFO - 2018-02-20 23:35:15 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:35:15 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:35:15 --> Utf8 Class Initialized
INFO - 2018-02-20 23:35:15 --> URI Class Initialized
INFO - 2018-02-20 23:35:15 --> Router Class Initialized
INFO - 2018-02-20 23:35:15 --> Output Class Initialized
INFO - 2018-02-20 23:35:15 --> Security Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:35:15 --> Input Class Initialized
INFO - 2018-02-20 23:35:15 --> Language Class Initialized
INFO - 2018-02-20 23:35:15 --> Loader Class Initialized
INFO - 2018-02-20 23:35:15 --> Helper loaded: url_helper
INFO - 2018-02-20 23:35:15 --> Helper loaded: form_helper
INFO - 2018-02-20 23:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:35:15 --> Form Validation Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Controller Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
INFO - 2018-02-20 23:35:15 --> Model Class Initialized
DEBUG - 2018-02-20 23:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:53:46 --> Config Class Initialized
INFO - 2018-02-20 23:53:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:53:46 --> Utf8 Class Initialized
INFO - 2018-02-20 23:53:46 --> URI Class Initialized
INFO - 2018-02-20 23:53:46 --> Router Class Initialized
INFO - 2018-02-20 23:53:46 --> Output Class Initialized
INFO - 2018-02-20 23:53:46 --> Security Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:53:46 --> Input Class Initialized
INFO - 2018-02-20 23:53:46 --> Language Class Initialized
INFO - 2018-02-20 23:53:46 --> Loader Class Initialized
INFO - 2018-02-20 23:53:46 --> Helper loaded: url_helper
INFO - 2018-02-20 23:53:46 --> Helper loaded: form_helper
INFO - 2018-02-20 23:53:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:53:46 --> Form Validation Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Controller Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:53:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:53:46 --> Final output sent to browser
DEBUG - 2018-02-20 23:53:46 --> Total execution time: 0.0641
INFO - 2018-02-20 23:53:46 --> Config Class Initialized
INFO - 2018-02-20 23:53:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:53:46 --> Utf8 Class Initialized
INFO - 2018-02-20 23:53:46 --> URI Class Initialized
INFO - 2018-02-20 23:53:46 --> Router Class Initialized
INFO - 2018-02-20 23:53:46 --> Output Class Initialized
INFO - 2018-02-20 23:53:46 --> Security Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:53:46 --> Input Class Initialized
INFO - 2018-02-20 23:53:46 --> Language Class Initialized
INFO - 2018-02-20 23:53:46 --> Loader Class Initialized
INFO - 2018-02-20 23:53:46 --> Helper loaded: url_helper
INFO - 2018-02-20 23:53:46 --> Helper loaded: form_helper
INFO - 2018-02-20 23:53:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:53:46 --> Form Validation Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Controller Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
INFO - 2018-02-20 23:53:46 --> Model Class Initialized
DEBUG - 2018-02-20 23:53:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:55:50 --> Config Class Initialized
INFO - 2018-02-20 23:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:55:51 --> Utf8 Class Initialized
INFO - 2018-02-20 23:55:51 --> URI Class Initialized
INFO - 2018-02-20 23:55:51 --> Router Class Initialized
INFO - 2018-02-20 23:55:51 --> Output Class Initialized
INFO - 2018-02-20 23:55:51 --> Security Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:55:51 --> Input Class Initialized
INFO - 2018-02-20 23:55:51 --> Language Class Initialized
INFO - 2018-02-20 23:55:51 --> Loader Class Initialized
INFO - 2018-02-20 23:55:51 --> Helper loaded: url_helper
INFO - 2018-02-20 23:55:51 --> Helper loaded: form_helper
INFO - 2018-02-20 23:55:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:55:51 --> Form Validation Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Controller Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:55:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:55:51 --> Final output sent to browser
DEBUG - 2018-02-20 23:55:51 --> Total execution time: 0.0499
INFO - 2018-02-20 23:55:51 --> Config Class Initialized
INFO - 2018-02-20 23:55:51 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:55:51 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:55:51 --> Utf8 Class Initialized
INFO - 2018-02-20 23:55:51 --> URI Class Initialized
INFO - 2018-02-20 23:55:51 --> Router Class Initialized
INFO - 2018-02-20 23:55:51 --> Output Class Initialized
INFO - 2018-02-20 23:55:51 --> Security Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:55:51 --> Input Class Initialized
INFO - 2018-02-20 23:55:51 --> Language Class Initialized
INFO - 2018-02-20 23:55:51 --> Loader Class Initialized
INFO - 2018-02-20 23:55:51 --> Helper loaded: url_helper
INFO - 2018-02-20 23:55:51 --> Helper loaded: form_helper
INFO - 2018-02-20 23:55:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:55:51 --> Form Validation Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Controller Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
INFO - 2018-02-20 23:55:51 --> Model Class Initialized
DEBUG - 2018-02-20 23:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:56:16 --> Config Class Initialized
INFO - 2018-02-20 23:56:16 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:56:16 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:56:16 --> Utf8 Class Initialized
INFO - 2018-02-20 23:56:16 --> URI Class Initialized
INFO - 2018-02-20 23:56:16 --> Router Class Initialized
INFO - 2018-02-20 23:56:16 --> Output Class Initialized
INFO - 2018-02-20 23:56:16 --> Security Class Initialized
DEBUG - 2018-02-20 23:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:56:16 --> Input Class Initialized
INFO - 2018-02-20 23:56:16 --> Language Class Initialized
INFO - 2018-02-20 23:56:16 --> Loader Class Initialized
INFO - 2018-02-20 23:56:16 --> Helper loaded: url_helper
INFO - 2018-02-20 23:56:16 --> Helper loaded: form_helper
INFO - 2018-02-20 23:56:16 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:56:16 --> Form Validation Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
INFO - 2018-02-20 23:56:16 --> Controller Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
INFO - 2018-02-20 23:56:16 --> Model Class Initialized
DEBUG - 2018-02-20 23:56:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-20 23:56:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-20 23:56:16 --> Final output sent to browser
DEBUG - 2018-02-20 23:56:16 --> Total execution time: 0.0711
INFO - 2018-02-20 23:56:17 --> Config Class Initialized
INFO - 2018-02-20 23:56:17 --> Hooks Class Initialized
DEBUG - 2018-02-20 23:56:17 --> UTF-8 Support Enabled
INFO - 2018-02-20 23:56:17 --> Utf8 Class Initialized
INFO - 2018-02-20 23:56:17 --> URI Class Initialized
INFO - 2018-02-20 23:56:17 --> Router Class Initialized
INFO - 2018-02-20 23:56:17 --> Output Class Initialized
INFO - 2018-02-20 23:56:17 --> Security Class Initialized
DEBUG - 2018-02-20 23:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 23:56:17 --> Input Class Initialized
INFO - 2018-02-20 23:56:17 --> Language Class Initialized
INFO - 2018-02-20 23:56:17 --> Loader Class Initialized
INFO - 2018-02-20 23:56:17 --> Helper loaded: url_helper
INFO - 2018-02-20 23:56:17 --> Helper loaded: form_helper
INFO - 2018-02-20 23:56:17 --> Database Driver Class Initialized
DEBUG - 2018-02-20 23:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 23:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 23:56:17 --> Form Validation Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
INFO - 2018-02-20 23:56:17 --> Controller Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
INFO - 2018-02-20 23:56:17 --> Model Class Initialized
DEBUG - 2018-02-20 23:56:17 --> Form_validation class already loaded. Second attempt ignored.
