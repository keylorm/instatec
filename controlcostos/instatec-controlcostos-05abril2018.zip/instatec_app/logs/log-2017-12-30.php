<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-30 00:03:11 --> Config Class Initialized
INFO - 2017-12-30 00:03:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 00:03:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 00:03:11 --> Utf8 Class Initialized
INFO - 2017-12-30 00:03:11 --> URI Class Initialized
DEBUG - 2017-12-30 00:03:11 --> No URI present. Default controller set.
INFO - 2017-12-30 00:03:11 --> Router Class Initialized
INFO - 2017-12-30 00:03:11 --> Output Class Initialized
INFO - 2017-12-30 00:03:11 --> Security Class Initialized
DEBUG - 2017-12-30 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 00:03:11 --> Input Class Initialized
INFO - 2017-12-30 00:03:11 --> Language Class Initialized
INFO - 2017-12-30 00:03:11 --> Loader Class Initialized
INFO - 2017-12-30 00:03:11 --> Helper loaded: url_helper
INFO - 2017-12-30 00:03:11 --> Helper loaded: form_helper
INFO - 2017-12-30 00:03:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 00:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 00:03:11 --> Form Validation Class Initialized
INFO - 2017-12-30 00:03:11 --> Model Class Initialized
INFO - 2017-12-30 00:03:11 --> Controller Class Initialized
INFO - 2017-12-30 00:03:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 00:03:11 --> Final output sent to browser
DEBUG - 2017-12-30 00:03:11 --> Total execution time: 0.0783
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/css
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/js
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/js
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/css
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/css
INFO - 2017-12-30 01:11:41 --> Config Class Initialized
INFO - 2017-12-30 01:11:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:11:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:11:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:11:41 --> URI Class Initialized
INFO - 2017-12-30 01:11:41 --> Router Class Initialized
INFO - 2017-12-30 01:11:41 --> Output Class Initialized
INFO - 2017-12-30 01:11:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:11:41 --> Input Class Initialized
INFO - 2017-12-30 01:11:41 --> Language Class Initialized
ERROR - 2017-12-30 01:11:41 --> 404 Page Not Found: Bootstrap/js
INFO - 2017-12-30 01:12:05 --> Config Class Initialized
INFO - 2017-12-30 01:12:05 --> Hooks Class Initialized
INFO - 2017-12-30 01:12:05 --> Config Class Initialized
INFO - 2017-12-30 01:12:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:12:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:12:05 --> Utf8 Class Initialized
DEBUG - 2017-12-30 01:12:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:12:05 --> Utf8 Class Initialized
INFO - 2017-12-30 01:12:05 --> URI Class Initialized
INFO - 2017-12-30 01:12:05 --> URI Class Initialized
INFO - 2017-12-30 01:12:05 --> Router Class Initialized
INFO - 2017-12-30 01:12:05 --> Router Class Initialized
INFO - 2017-12-30 01:12:05 --> Output Class Initialized
INFO - 2017-12-30 01:12:05 --> Output Class Initialized
INFO - 2017-12-30 01:12:05 --> Security Class Initialized
INFO - 2017-12-30 01:12:05 --> Security Class Initialized
DEBUG - 2017-12-30 01:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:12:05 --> Input Class Initialized
DEBUG - 2017-12-30 01:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:12:05 --> Input Class Initialized
INFO - 2017-12-30 01:12:05 --> Language Class Initialized
INFO - 2017-12-30 01:12:05 --> Language Class Initialized
ERROR - 2017-12-30 01:12:05 --> 404 Page Not Found: Bootstrap/css
ERROR - 2017-12-30 01:12:05 --> 404 Page Not Found: Bootstrap/js
INFO - 2017-12-30 01:12:09 --> Config Class Initialized
INFO - 2017-12-30 01:12:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:12:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:12:09 --> Utf8 Class Initialized
INFO - 2017-12-30 01:12:09 --> URI Class Initialized
DEBUG - 2017-12-30 01:12:09 --> No URI present. Default controller set.
INFO - 2017-12-30 01:12:09 --> Router Class Initialized
INFO - 2017-12-30 01:12:09 --> Output Class Initialized
INFO - 2017-12-30 01:12:09 --> Security Class Initialized
DEBUG - 2017-12-30 01:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:12:09 --> Input Class Initialized
INFO - 2017-12-30 01:12:09 --> Language Class Initialized
INFO - 2017-12-30 01:12:09 --> Loader Class Initialized
INFO - 2017-12-30 01:12:09 --> Helper loaded: url_helper
INFO - 2017-12-30 01:12:09 --> Helper loaded: form_helper
INFO - 2017-12-30 01:12:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:12:10 --> Form Validation Class Initialized
INFO - 2017-12-30 01:12:10 --> Model Class Initialized
INFO - 2017-12-30 01:12:10 --> Controller Class Initialized
INFO - 2017-12-30 01:12:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 01:12:10 --> Final output sent to browser
DEBUG - 2017-12-30 01:12:10 --> Total execution time: 0.0614
INFO - 2017-12-30 01:12:11 --> Config Class Initialized
INFO - 2017-12-30 01:12:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:12:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:12:11 --> Utf8 Class Initialized
INFO - 2017-12-30 01:12:11 --> URI Class Initialized
INFO - 2017-12-30 01:12:11 --> Router Class Initialized
INFO - 2017-12-30 01:12:11 --> Output Class Initialized
INFO - 2017-12-30 01:12:11 --> Security Class Initialized
DEBUG - 2017-12-30 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:12:11 --> Input Class Initialized
INFO - 2017-12-30 01:12:11 --> Language Class Initialized
ERROR - 2017-12-30 01:12:11 --> 404 Page Not Found: Bootstrap/css
INFO - 2017-12-30 01:17:58 --> Config Class Initialized
INFO - 2017-12-30 01:17:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:17:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:17:58 --> Utf8 Class Initialized
INFO - 2017-12-30 01:17:58 --> URI Class Initialized
INFO - 2017-12-30 01:17:58 --> Router Class Initialized
INFO - 2017-12-30 01:17:58 --> Output Class Initialized
INFO - 2017-12-30 01:17:58 --> Security Class Initialized
DEBUG - 2017-12-30 01:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:17:58 --> Input Class Initialized
INFO - 2017-12-30 01:17:58 --> Language Class Initialized
ERROR - 2017-12-30 01:17:58 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 42
INFO - 2017-12-30 01:18:26 --> Config Class Initialized
INFO - 2017-12-30 01:18:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:18:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:18:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:18:26 --> URI Class Initialized
INFO - 2017-12-30 01:18:26 --> Router Class Initialized
INFO - 2017-12-30 01:18:26 --> Output Class Initialized
INFO - 2017-12-30 01:18:26 --> Security Class Initialized
DEBUG - 2017-12-30 01:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:18:26 --> Input Class Initialized
INFO - 2017-12-30 01:18:26 --> Language Class Initialized
ERROR - 2017-12-30 01:18:26 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:18:31 --> Config Class Initialized
INFO - 2017-12-30 01:18:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:18:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:18:31 --> Utf8 Class Initialized
INFO - 2017-12-30 01:18:31 --> URI Class Initialized
INFO - 2017-12-30 01:18:31 --> Router Class Initialized
INFO - 2017-12-30 01:18:31 --> Output Class Initialized
INFO - 2017-12-30 01:18:31 --> Security Class Initialized
DEBUG - 2017-12-30 01:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:18:31 --> Input Class Initialized
INFO - 2017-12-30 01:18:31 --> Language Class Initialized
ERROR - 2017-12-30 01:18:31 --> Severity: Parsing Error --> syntax error, unexpected 'require' (T_REQUIRE), expecting function (T_FUNCTION) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 6
INFO - 2017-12-30 01:18:41 --> Config Class Initialized
INFO - 2017-12-30 01:18:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:18:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:18:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:18:41 --> URI Class Initialized
INFO - 2017-12-30 01:18:41 --> Router Class Initialized
INFO - 2017-12-30 01:18:41 --> Output Class Initialized
INFO - 2017-12-30 01:18:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:18:41 --> Input Class Initialized
INFO - 2017-12-30 01:18:41 --> Language Class Initialized
ERROR - 2017-12-30 01:18:41 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:19:09 --> Config Class Initialized
INFO - 2017-12-30 01:19:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:19:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:19:09 --> Utf8 Class Initialized
INFO - 2017-12-30 01:19:09 --> URI Class Initialized
INFO - 2017-12-30 01:19:09 --> Router Class Initialized
INFO - 2017-12-30 01:19:09 --> Output Class Initialized
INFO - 2017-12-30 01:19:09 --> Security Class Initialized
DEBUG - 2017-12-30 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:19:09 --> Input Class Initialized
INFO - 2017-12-30 01:19:09 --> Language Class Initialized
ERROR - 2017-12-30 01:19:09 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:19:26 --> Config Class Initialized
INFO - 2017-12-30 01:19:26 --> Hooks Class Initialized
INFO - 2017-12-30 01:19:26 --> Config Class Initialized
INFO - 2017-12-30 01:19:26 --> Config Class Initialized
INFO - 2017-12-30 01:19:26 --> Hooks Class Initialized
INFO - 2017-12-30 01:19:26 --> Hooks Class Initialized
INFO - 2017-12-30 01:19:26 --> Config Class Initialized
INFO - 2017-12-30 01:19:26 --> Config Class Initialized
INFO - 2017-12-30 01:19:26 --> Hooks Class Initialized
INFO - 2017-12-30 01:19:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 01:19:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:19:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:19:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:19:26 --> Utf8 Class Initialized
DEBUG - 2017-12-30 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 01:19:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:19:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:19:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:19:26 --> URI Class Initialized
INFO - 2017-12-30 01:19:26 --> URI Class Initialized
INFO - 2017-12-30 01:19:26 --> URI Class Initialized
INFO - 2017-12-30 01:19:26 --> URI Class Initialized
INFO - 2017-12-30 01:19:26 --> URI Class Initialized
INFO - 2017-12-30 01:19:26 --> Router Class Initialized
INFO - 2017-12-30 01:19:26 --> Router Class Initialized
INFO - 2017-12-30 01:19:26 --> Router Class Initialized
INFO - 2017-12-30 01:19:26 --> Router Class Initialized
INFO - 2017-12-30 01:19:26 --> Router Class Initialized
INFO - 2017-12-30 01:19:26 --> Output Class Initialized
INFO - 2017-12-30 01:19:26 --> Output Class Initialized
INFO - 2017-12-30 01:19:26 --> Output Class Initialized
INFO - 2017-12-30 01:19:26 --> Output Class Initialized
INFO - 2017-12-30 01:19:26 --> Output Class Initialized
INFO - 2017-12-30 01:19:26 --> Security Class Initialized
INFO - 2017-12-30 01:19:26 --> Security Class Initialized
INFO - 2017-12-30 01:19:26 --> Security Class Initialized
INFO - 2017-12-30 01:19:26 --> Security Class Initialized
INFO - 2017-12-30 01:19:26 --> Security Class Initialized
DEBUG - 2017-12-30 01:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 01:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:19:26 --> Input Class Initialized
INFO - 2017-12-30 01:19:26 --> Input Class Initialized
DEBUG - 2017-12-30 01:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 01:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:19:26 --> Input Class Initialized
INFO - 2017-12-30 01:19:26 --> Input Class Initialized
INFO - 2017-12-30 01:19:26 --> Language Class Initialized
DEBUG - 2017-12-30 01:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:19:26 --> Language Class Initialized
INFO - 2017-12-30 01:19:26 --> Input Class Initialized
INFO - 2017-12-30 01:19:26 --> Language Class Initialized
INFO - 2017-12-30 01:19:26 --> Language Class Initialized
INFO - 2017-12-30 01:19:26 --> Language Class Initialized
ERROR - 2017-12-30 01:19:26 --> 404 Page Not Found: Bootstrap/css
ERROR - 2017-12-30 01:19:26 --> 404 Page Not Found: Bootstrap/css
ERROR - 2017-12-30 01:19:26 --> 404 Page Not Found: Bootstrap/css
ERROR - 2017-12-30 01:19:26 --> 404 Page Not Found: Bootstrap/js
ERROR - 2017-12-30 01:19:26 --> 404 Page Not Found: Bootstrap/js
INFO - 2017-12-30 01:24:08 --> Config Class Initialized
INFO - 2017-12-30 01:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:08 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:08 --> URI Class Initialized
INFO - 2017-12-30 01:24:08 --> Router Class Initialized
INFO - 2017-12-30 01:24:08 --> Output Class Initialized
INFO - 2017-12-30 01:24:08 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:08 --> Input Class Initialized
INFO - 2017-12-30 01:24:08 --> Language Class Initialized
ERROR - 2017-12-30 01:24:08 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:24:08 --> Config Class Initialized
INFO - 2017-12-30 01:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:08 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:08 --> URI Class Initialized
INFO - 2017-12-30 01:24:08 --> Router Class Initialized
INFO - 2017-12-30 01:24:08 --> Output Class Initialized
INFO - 2017-12-30 01:24:08 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:08 --> Input Class Initialized
INFO - 2017-12-30 01:24:08 --> Language Class Initialized
ERROR - 2017-12-30 01:24:08 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:24:09 --> Config Class Initialized
INFO - 2017-12-30 01:24:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:09 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:09 --> URI Class Initialized
INFO - 2017-12-30 01:24:09 --> Router Class Initialized
INFO - 2017-12-30 01:24:09 --> Output Class Initialized
INFO - 2017-12-30 01:24:09 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:09 --> Input Class Initialized
INFO - 2017-12-30 01:24:09 --> Language Class Initialized
ERROR - 2017-12-30 01:24:09 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 45
INFO - 2017-12-30 01:24:44 --> Config Class Initialized
INFO - 2017-12-30 01:24:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:44 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:44 --> URI Class Initialized
INFO - 2017-12-30 01:24:44 --> Router Class Initialized
INFO - 2017-12-30 01:24:44 --> Output Class Initialized
INFO - 2017-12-30 01:24:44 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:44 --> Input Class Initialized
INFO - 2017-12-30 01:24:44 --> Language Class Initialized
ERROR - 2017-12-30 01:24:44 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:24:44 --> Config Class Initialized
INFO - 2017-12-30 01:24:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:44 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:44 --> URI Class Initialized
INFO - 2017-12-30 01:24:44 --> Router Class Initialized
INFO - 2017-12-30 01:24:44 --> Output Class Initialized
INFO - 2017-12-30 01:24:44 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:44 --> Input Class Initialized
INFO - 2017-12-30 01:24:44 --> Language Class Initialized
ERROR - 2017-12-30 01:24:44 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:24:51 --> Config Class Initialized
INFO - 2017-12-30 01:24:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:51 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:51 --> URI Class Initialized
INFO - 2017-12-30 01:24:51 --> Router Class Initialized
INFO - 2017-12-30 01:24:51 --> Output Class Initialized
INFO - 2017-12-30 01:24:51 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:51 --> Input Class Initialized
INFO - 2017-12-30 01:24:51 --> Language Class Initialized
ERROR - 2017-12-30 01:24:51 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:24:51 --> Config Class Initialized
INFO - 2017-12-30 01:24:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:51 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:51 --> URI Class Initialized
INFO - 2017-12-30 01:24:51 --> Router Class Initialized
INFO - 2017-12-30 01:24:51 --> Output Class Initialized
INFO - 2017-12-30 01:24:51 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:51 --> Input Class Initialized
INFO - 2017-12-30 01:24:51 --> Language Class Initialized
ERROR - 2017-12-30 01:24:51 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:24:52 --> Config Class Initialized
INFO - 2017-12-30 01:24:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:24:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:24:52 --> Utf8 Class Initialized
INFO - 2017-12-30 01:24:52 --> URI Class Initialized
INFO - 2017-12-30 01:24:52 --> Router Class Initialized
INFO - 2017-12-30 01:24:52 --> Output Class Initialized
INFO - 2017-12-30 01:24:52 --> Security Class Initialized
DEBUG - 2017-12-30 01:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:24:52 --> Input Class Initialized
INFO - 2017-12-30 01:24:52 --> Language Class Initialized
ERROR - 2017-12-30 01:24:52 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:25:13 --> Config Class Initialized
INFO - 2017-12-30 01:25:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:13 --> URI Class Initialized
INFO - 2017-12-30 01:25:13 --> Router Class Initialized
INFO - 2017-12-30 01:25:13 --> Output Class Initialized
INFO - 2017-12-30 01:25:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:13 --> Input Class Initialized
INFO - 2017-12-30 01:25:13 --> Language Class Initialized
ERROR - 2017-12-30 01:25:13 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:25:13 --> Config Class Initialized
INFO - 2017-12-30 01:25:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:13 --> URI Class Initialized
INFO - 2017-12-30 01:25:13 --> Router Class Initialized
INFO - 2017-12-30 01:25:13 --> Output Class Initialized
INFO - 2017-12-30 01:25:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:13 --> Input Class Initialized
INFO - 2017-12-30 01:25:13 --> Language Class Initialized
ERROR - 2017-12-30 01:25:13 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 46
INFO - 2017-12-30 01:25:30 --> Config Class Initialized
INFO - 2017-12-30 01:25:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:30 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:30 --> URI Class Initialized
INFO - 2017-12-30 01:25:30 --> Router Class Initialized
INFO - 2017-12-30 01:25:30 --> Output Class Initialized
INFO - 2017-12-30 01:25:30 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:30 --> Input Class Initialized
INFO - 2017-12-30 01:25:30 --> Language Class Initialized
ERROR - 2017-12-30 01:25:30 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 48
INFO - 2017-12-30 01:25:30 --> Config Class Initialized
INFO - 2017-12-30 01:25:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:30 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:30 --> URI Class Initialized
INFO - 2017-12-30 01:25:30 --> Router Class Initialized
INFO - 2017-12-30 01:25:30 --> Output Class Initialized
INFO - 2017-12-30 01:25:30 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:30 --> Input Class Initialized
INFO - 2017-12-30 01:25:30 --> Language Class Initialized
ERROR - 2017-12-30 01:25:30 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 48
INFO - 2017-12-30 01:25:30 --> Config Class Initialized
INFO - 2017-12-30 01:25:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:30 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:30 --> URI Class Initialized
INFO - 2017-12-30 01:25:30 --> Router Class Initialized
INFO - 2017-12-30 01:25:30 --> Output Class Initialized
INFO - 2017-12-30 01:25:30 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:30 --> Input Class Initialized
INFO - 2017-12-30 01:25:30 --> Language Class Initialized
ERROR - 2017-12-30 01:25:30 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 48
INFO - 2017-12-30 01:25:41 --> Config Class Initialized
INFO - 2017-12-30 01:25:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:41 --> URI Class Initialized
INFO - 2017-12-30 01:25:41 --> Router Class Initialized
INFO - 2017-12-30 01:25:41 --> Output Class Initialized
INFO - 2017-12-30 01:25:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:41 --> Input Class Initialized
INFO - 2017-12-30 01:25:41 --> Language Class Initialized
ERROR - 2017-12-30 01:25:41 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:25:41 --> Config Class Initialized
INFO - 2017-12-30 01:25:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:41 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:41 --> URI Class Initialized
INFO - 2017-12-30 01:25:41 --> Router Class Initialized
INFO - 2017-12-30 01:25:41 --> Output Class Initialized
INFO - 2017-12-30 01:25:41 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:41 --> Input Class Initialized
INFO - 2017-12-30 01:25:41 --> Language Class Initialized
ERROR - 2017-12-30 01:25:41 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:25:42 --> Config Class Initialized
INFO - 2017-12-30 01:25:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:42 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:42 --> URI Class Initialized
INFO - 2017-12-30 01:25:42 --> Router Class Initialized
INFO - 2017-12-30 01:25:42 --> Output Class Initialized
INFO - 2017-12-30 01:25:42 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:42 --> Input Class Initialized
INFO - 2017-12-30 01:25:42 --> Language Class Initialized
ERROR - 2017-12-30 01:25:42 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:25:42 --> Config Class Initialized
INFO - 2017-12-30 01:25:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:25:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:25:42 --> Utf8 Class Initialized
INFO - 2017-12-30 01:25:42 --> URI Class Initialized
INFO - 2017-12-30 01:25:42 --> Router Class Initialized
INFO - 2017-12-30 01:25:42 --> Output Class Initialized
INFO - 2017-12-30 01:25:42 --> Security Class Initialized
DEBUG - 2017-12-30 01:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:25:42 --> Input Class Initialized
INFO - 2017-12-30 01:25:42 --> Language Class Initialized
ERROR - 2017-12-30 01:25:42 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:10 --> Config Class Initialized
INFO - 2017-12-30 01:27:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:10 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:10 --> URI Class Initialized
INFO - 2017-12-30 01:27:10 --> Router Class Initialized
INFO - 2017-12-30 01:27:10 --> Output Class Initialized
INFO - 2017-12-30 01:27:10 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:10 --> Input Class Initialized
INFO - 2017-12-30 01:27:10 --> Language Class Initialized
INFO - 2017-12-30 01:27:11 --> Config Class Initialized
INFO - 2017-12-30 01:27:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:11 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:11 --> URI Class Initialized
INFO - 2017-12-30 01:27:11 --> Router Class Initialized
INFO - 2017-12-30 01:27:11 --> Output Class Initialized
INFO - 2017-12-30 01:27:11 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:11 --> Input Class Initialized
INFO - 2017-12-30 01:27:11 --> Language Class Initialized
INFO - 2017-12-30 01:27:12 --> Config Class Initialized
INFO - 2017-12-30 01:27:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:12 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:12 --> URI Class Initialized
INFO - 2017-12-30 01:27:12 --> Router Class Initialized
INFO - 2017-12-30 01:27:12 --> Output Class Initialized
INFO - 2017-12-30 01:27:12 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:12 --> Input Class Initialized
INFO - 2017-12-30 01:27:12 --> Language Class Initialized
INFO - 2017-12-30 01:27:12 --> Config Class Initialized
INFO - 2017-12-30 01:27:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:12 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:12 --> URI Class Initialized
INFO - 2017-12-30 01:27:12 --> Router Class Initialized
INFO - 2017-12-30 01:27:12 --> Output Class Initialized
INFO - 2017-12-30 01:27:12 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:12 --> Input Class Initialized
INFO - 2017-12-30 01:27:12 --> Language Class Initialized
INFO - 2017-12-30 01:27:12 --> Config Class Initialized
INFO - 2017-12-30 01:27:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:12 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:12 --> URI Class Initialized
INFO - 2017-12-30 01:27:12 --> Router Class Initialized
INFO - 2017-12-30 01:27:12 --> Output Class Initialized
INFO - 2017-12-30 01:27:12 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:12 --> Input Class Initialized
INFO - 2017-12-30 01:27:12 --> Language Class Initialized
INFO - 2017-12-30 01:27:12 --> Config Class Initialized
INFO - 2017-12-30 01:27:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:12 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:12 --> URI Class Initialized
INFO - 2017-12-30 01:27:12 --> Router Class Initialized
INFO - 2017-12-30 01:27:12 --> Output Class Initialized
INFO - 2017-12-30 01:27:12 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:12 --> Input Class Initialized
INFO - 2017-12-30 01:27:12 --> Language Class Initialized
INFO - 2017-12-30 01:27:13 --> Config Class Initialized
INFO - 2017-12-30 01:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:13 --> URI Class Initialized
INFO - 2017-12-30 01:27:13 --> Router Class Initialized
INFO - 2017-12-30 01:27:13 --> Output Class Initialized
INFO - 2017-12-30 01:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:13 --> Input Class Initialized
INFO - 2017-12-30 01:27:13 --> Language Class Initialized
INFO - 2017-12-30 01:27:13 --> Config Class Initialized
INFO - 2017-12-30 01:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:13 --> URI Class Initialized
INFO - 2017-12-30 01:27:13 --> Router Class Initialized
INFO - 2017-12-30 01:27:13 --> Output Class Initialized
INFO - 2017-12-30 01:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:13 --> Input Class Initialized
INFO - 2017-12-30 01:27:13 --> Language Class Initialized
INFO - 2017-12-30 01:27:13 --> Config Class Initialized
INFO - 2017-12-30 01:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:13 --> URI Class Initialized
INFO - 2017-12-30 01:27:13 --> Router Class Initialized
INFO - 2017-12-30 01:27:13 --> Output Class Initialized
INFO - 2017-12-30 01:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:13 --> Input Class Initialized
INFO - 2017-12-30 01:27:13 --> Language Class Initialized
INFO - 2017-12-30 01:27:13 --> Config Class Initialized
INFO - 2017-12-30 01:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:13 --> URI Class Initialized
INFO - 2017-12-30 01:27:13 --> Router Class Initialized
INFO - 2017-12-30 01:27:13 --> Output Class Initialized
INFO - 2017-12-30 01:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:13 --> Input Class Initialized
INFO - 2017-12-30 01:27:13 --> Language Class Initialized
INFO - 2017-12-30 01:27:13 --> Config Class Initialized
INFO - 2017-12-30 01:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:13 --> URI Class Initialized
INFO - 2017-12-30 01:27:13 --> Router Class Initialized
INFO - 2017-12-30 01:27:13 --> Output Class Initialized
INFO - 2017-12-30 01:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:13 --> Input Class Initialized
INFO - 2017-12-30 01:27:13 --> Language Class Initialized
INFO - 2017-12-30 01:27:14 --> Config Class Initialized
INFO - 2017-12-30 01:27:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:14 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:14 --> URI Class Initialized
INFO - 2017-12-30 01:27:14 --> Router Class Initialized
INFO - 2017-12-30 01:27:14 --> Output Class Initialized
INFO - 2017-12-30 01:27:14 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:14 --> Input Class Initialized
INFO - 2017-12-30 01:27:14 --> Language Class Initialized
INFO - 2017-12-30 01:27:14 --> Config Class Initialized
INFO - 2017-12-30 01:27:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:14 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:14 --> URI Class Initialized
INFO - 2017-12-30 01:27:14 --> Router Class Initialized
INFO - 2017-12-30 01:27:14 --> Output Class Initialized
INFO - 2017-12-30 01:27:14 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:14 --> Input Class Initialized
INFO - 2017-12-30 01:27:14 --> Language Class Initialized
INFO - 2017-12-30 01:27:22 --> Config Class Initialized
INFO - 2017-12-30 01:27:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:22 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:22 --> URI Class Initialized
INFO - 2017-12-30 01:27:22 --> Router Class Initialized
INFO - 2017-12-30 01:27:22 --> Output Class Initialized
INFO - 2017-12-30 01:27:22 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:22 --> Input Class Initialized
INFO - 2017-12-30 01:27:22 --> Language Class Initialized
ERROR - 2017-12-30 01:27:22 --> Severity: Notice --> Use of undefined constant SYSPATH - assumed 'SYSPATH' D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:28 --> Config Class Initialized
INFO - 2017-12-30 01:27:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:28 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:28 --> URI Class Initialized
INFO - 2017-12-30 01:27:28 --> Router Class Initialized
INFO - 2017-12-30 01:27:28 --> Output Class Initialized
INFO - 2017-12-30 01:27:28 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:28 --> Input Class Initialized
INFO - 2017-12-30 01:27:28 --> Language Class Initialized
INFO - 2017-12-30 01:27:46 --> Config Class Initialized
INFO - 2017-12-30 01:27:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:46 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:46 --> URI Class Initialized
INFO - 2017-12-30 01:27:46 --> Router Class Initialized
INFO - 2017-12-30 01:27:46 --> Output Class Initialized
INFO - 2017-12-30 01:27:46 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:46 --> Input Class Initialized
INFO - 2017-12-30 01:27:46 --> Language Class Initialized
ERROR - 2017-12-30 01:27:46 --> Severity: Error --> Call to undefined function baseurl() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:53 --> Config Class Initialized
INFO - 2017-12-30 01:27:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:53 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:53 --> URI Class Initialized
INFO - 2017-12-30 01:27:53 --> Router Class Initialized
INFO - 2017-12-30 01:27:53 --> Output Class Initialized
INFO - 2017-12-30 01:27:53 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:53 --> Input Class Initialized
INFO - 2017-12-30 01:27:53 --> Language Class Initialized
ERROR - 2017-12-30 01:27:53 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:53 --> Config Class Initialized
INFO - 2017-12-30 01:27:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:53 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:53 --> URI Class Initialized
INFO - 2017-12-30 01:27:53 --> Router Class Initialized
INFO - 2017-12-30 01:27:53 --> Output Class Initialized
INFO - 2017-12-30 01:27:53 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:53 --> Input Class Initialized
INFO - 2017-12-30 01:27:53 --> Language Class Initialized
ERROR - 2017-12-30 01:27:53 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:53 --> Config Class Initialized
INFO - 2017-12-30 01:27:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:54 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:54 --> URI Class Initialized
INFO - 2017-12-30 01:27:54 --> Router Class Initialized
INFO - 2017-12-30 01:27:54 --> Output Class Initialized
INFO - 2017-12-30 01:27:54 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:54 --> Input Class Initialized
INFO - 2017-12-30 01:27:54 --> Language Class Initialized
ERROR - 2017-12-30 01:27:54 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:27:54 --> Config Class Initialized
INFO - 2017-12-30 01:27:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:27:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:27:54 --> Utf8 Class Initialized
INFO - 2017-12-30 01:27:54 --> URI Class Initialized
INFO - 2017-12-30 01:27:54 --> Router Class Initialized
INFO - 2017-12-30 01:27:54 --> Output Class Initialized
INFO - 2017-12-30 01:27:54 --> Security Class Initialized
DEBUG - 2017-12-30 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:27:54 --> Input Class Initialized
INFO - 2017-12-30 01:27:54 --> Language Class Initialized
ERROR - 2017-12-30 01:27:54 --> Severity: Error --> Call to undefined function base_url() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:28:02 --> Config Class Initialized
INFO - 2017-12-30 01:28:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:28:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:28:02 --> Utf8 Class Initialized
INFO - 2017-12-30 01:28:02 --> URI Class Initialized
INFO - 2017-12-30 01:28:02 --> Router Class Initialized
INFO - 2017-12-30 01:28:02 --> Output Class Initialized
INFO - 2017-12-30 01:28:02 --> Security Class Initialized
DEBUG - 2017-12-30 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:28:02 --> Input Class Initialized
INFO - 2017-12-30 01:28:02 --> Language Class Initialized
INFO - 2017-12-30 01:28:24 --> Config Class Initialized
INFO - 2017-12-30 01:28:24 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:28:24 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:28:24 --> Utf8 Class Initialized
INFO - 2017-12-30 01:28:24 --> URI Class Initialized
INFO - 2017-12-30 01:28:24 --> Router Class Initialized
INFO - 2017-12-30 01:28:24 --> Output Class Initialized
INFO - 2017-12-30 01:28:24 --> Security Class Initialized
DEBUG - 2017-12-30 01:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:28:24 --> Input Class Initialized
INFO - 2017-12-30 01:28:24 --> Language Class Initialized
ERROR - 2017-12-30 01:28:24 --> Severity: Warning --> require(/vendor/autoload.php): failed to open stream: No such file or directory D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
ERROR - 2017-12-30 01:28:24 --> Severity: Compile Error --> require(): Failed opening required '/vendor/autoload.php' (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:28:30 --> Config Class Initialized
INFO - 2017-12-30 01:28:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:28:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:28:30 --> Utf8 Class Initialized
INFO - 2017-12-30 01:28:30 --> URI Class Initialized
INFO - 2017-12-30 01:28:30 --> Router Class Initialized
INFO - 2017-12-30 01:28:30 --> Output Class Initialized
INFO - 2017-12-30 01:28:30 --> Security Class Initialized
DEBUG - 2017-12-30 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:28:30 --> Input Class Initialized
INFO - 2017-12-30 01:28:30 --> Language Class Initialized
ERROR - 2017-12-30 01:28:30 --> Severity: Warning --> require(/vendor/autoload.php): failed to open stream: No such file or directory D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
ERROR - 2017-12-30 01:28:30 --> Severity: Compile Error --> require(): Failed opening required '/vendor/autoload.php' (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:28:42 --> Config Class Initialized
INFO - 2017-12-30 01:28:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:28:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:28:42 --> Utf8 Class Initialized
INFO - 2017-12-30 01:28:42 --> URI Class Initialized
INFO - 2017-12-30 01:28:42 --> Router Class Initialized
INFO - 2017-12-30 01:28:42 --> Output Class Initialized
INFO - 2017-12-30 01:28:42 --> Security Class Initialized
DEBUG - 2017-12-30 01:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:28:42 --> Input Class Initialized
INFO - 2017-12-30 01:28:42 --> Language Class Initialized
INFO - 2017-12-30 01:28:42 --> Loader Class Initialized
INFO - 2017-12-30 01:28:42 --> Helper loaded: url_helper
INFO - 2017-12-30 01:28:42 --> Helper loaded: form_helper
INFO - 2017-12-30 01:28:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:28:42 --> Form Validation Class Initialized
INFO - 2017-12-30 01:28:42 --> Model Class Initialized
INFO - 2017-12-30 01:28:42 --> Controller Class Initialized
INFO - 2017-12-30 01:28:42 --> Model Class Initialized
INFO - 2017-12-30 01:28:42 --> Model Class Initialized
INFO - 2017-12-30 01:28:42 --> Model Class Initialized
INFO - 2017-12-30 01:28:42 --> Model Class Initialized
DEBUG - 2017-12-30 01:28:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:28:42 --> Final output sent to browser
DEBUG - 2017-12-30 01:28:42 --> Total execution time: 0.1651
INFO - 2017-12-30 01:28:43 --> Config Class Initialized
INFO - 2017-12-30 01:28:43 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:28:43 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:28:43 --> Utf8 Class Initialized
INFO - 2017-12-30 01:28:43 --> URI Class Initialized
INFO - 2017-12-30 01:28:43 --> Router Class Initialized
INFO - 2017-12-30 01:28:43 --> Output Class Initialized
INFO - 2017-12-30 01:28:43 --> Security Class Initialized
DEBUG - 2017-12-30 01:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:28:43 --> Input Class Initialized
INFO - 2017-12-30 01:28:43 --> Language Class Initialized
INFO - 2017-12-30 01:28:43 --> Loader Class Initialized
INFO - 2017-12-30 01:28:43 --> Helper loaded: url_helper
INFO - 2017-12-30 01:28:43 --> Helper loaded: form_helper
INFO - 2017-12-30 01:28:43 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:28:43 --> Form Validation Class Initialized
INFO - 2017-12-30 01:28:43 --> Model Class Initialized
INFO - 2017-12-30 01:28:43 --> Controller Class Initialized
INFO - 2017-12-30 01:28:43 --> Model Class Initialized
INFO - 2017-12-30 01:28:43 --> Model Class Initialized
INFO - 2017-12-30 01:28:43 --> Model Class Initialized
INFO - 2017-12-30 01:28:43 --> Model Class Initialized
DEBUG - 2017-12-30 01:28:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:28:43 --> Final output sent to browser
DEBUG - 2017-12-30 01:28:43 --> Total execution time: 0.1474
INFO - 2017-12-30 01:29:37 --> Config Class Initialized
INFO - 2017-12-30 01:29:37 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:29:37 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:29:37 --> Utf8 Class Initialized
INFO - 2017-12-30 01:29:37 --> URI Class Initialized
INFO - 2017-12-30 01:29:37 --> Router Class Initialized
INFO - 2017-12-30 01:29:37 --> Output Class Initialized
INFO - 2017-12-30 01:29:37 --> Security Class Initialized
DEBUG - 2017-12-30 01:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:29:37 --> Input Class Initialized
INFO - 2017-12-30 01:29:37 --> Language Class Initialized
ERROR - 2017-12-30 01:29:37 --> Severity: Error --> Using $this when not in object context D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:29:38 --> Config Class Initialized
INFO - 2017-12-30 01:29:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:29:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:29:38 --> Utf8 Class Initialized
INFO - 2017-12-30 01:29:38 --> URI Class Initialized
INFO - 2017-12-30 01:29:38 --> Router Class Initialized
INFO - 2017-12-30 01:29:38 --> Output Class Initialized
INFO - 2017-12-30 01:29:38 --> Security Class Initialized
DEBUG - 2017-12-30 01:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:29:38 --> Input Class Initialized
INFO - 2017-12-30 01:29:38 --> Language Class Initialized
ERROR - 2017-12-30 01:29:38 --> Severity: Error --> Using $this when not in object context D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:29:38 --> Config Class Initialized
INFO - 2017-12-30 01:29:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:29:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:29:38 --> Utf8 Class Initialized
INFO - 2017-12-30 01:29:38 --> URI Class Initialized
INFO - 2017-12-30 01:29:38 --> Router Class Initialized
INFO - 2017-12-30 01:29:38 --> Output Class Initialized
INFO - 2017-12-30 01:29:38 --> Security Class Initialized
DEBUG - 2017-12-30 01:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:29:38 --> Input Class Initialized
INFO - 2017-12-30 01:29:38 --> Language Class Initialized
ERROR - 2017-12-30 01:29:38 --> Severity: Error --> Using $this when not in object context D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 4
INFO - 2017-12-30 01:29:56 --> Config Class Initialized
INFO - 2017-12-30 01:29:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:29:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:29:56 --> Utf8 Class Initialized
INFO - 2017-12-30 01:29:56 --> URI Class Initialized
INFO - 2017-12-30 01:29:56 --> Router Class Initialized
INFO - 2017-12-30 01:29:56 --> Output Class Initialized
INFO - 2017-12-30 01:29:56 --> Security Class Initialized
DEBUG - 2017-12-30 01:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:29:56 --> Input Class Initialized
INFO - 2017-12-30 01:29:56 --> Language Class Initialized
INFO - 2017-12-30 01:29:56 --> Loader Class Initialized
INFO - 2017-12-30 01:29:56 --> Helper loaded: url_helper
INFO - 2017-12-30 01:29:56 --> Helper loaded: form_helper
INFO - 2017-12-30 01:29:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:29:56 --> Form Validation Class Initialized
INFO - 2017-12-30 01:29:56 --> Model Class Initialized
INFO - 2017-12-30 01:29:56 --> Controller Class Initialized
INFO - 2017-12-30 01:29:56 --> Model Class Initialized
INFO - 2017-12-30 01:29:56 --> Model Class Initialized
INFO - 2017-12-30 01:29:56 --> Model Class Initialized
INFO - 2017-12-30 01:29:56 --> Model Class Initialized
DEBUG - 2017-12-30 01:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:29:56 --> Final output sent to browser
DEBUG - 2017-12-30 01:29:56 --> Total execution time: 0.1698
INFO - 2017-12-30 01:30:06 --> Config Class Initialized
INFO - 2017-12-30 01:30:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:30:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:30:06 --> Utf8 Class Initialized
INFO - 2017-12-30 01:30:06 --> URI Class Initialized
INFO - 2017-12-30 01:30:06 --> Router Class Initialized
INFO - 2017-12-30 01:30:06 --> Output Class Initialized
INFO - 2017-12-30 01:30:06 --> Security Class Initialized
DEBUG - 2017-12-30 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:30:06 --> Input Class Initialized
INFO - 2017-12-30 01:30:06 --> Language Class Initialized
INFO - 2017-12-30 01:30:06 --> Loader Class Initialized
INFO - 2017-12-30 01:30:06 --> Helper loaded: url_helper
INFO - 2017-12-30 01:30:06 --> Helper loaded: form_helper
INFO - 2017-12-30 01:30:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:30:06 --> Form Validation Class Initialized
INFO - 2017-12-30 01:30:06 --> Model Class Initialized
INFO - 2017-12-30 01:30:06 --> Controller Class Initialized
INFO - 2017-12-30 01:30:06 --> Model Class Initialized
INFO - 2017-12-30 01:30:06 --> Model Class Initialized
INFO - 2017-12-30 01:30:06 --> Model Class Initialized
INFO - 2017-12-30 01:30:06 --> Model Class Initialized
DEBUG - 2017-12-30 01:30:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:30:06 --> Final output sent to browser
DEBUG - 2017-12-30 01:30:06 --> Total execution time: 0.1458
INFO - 2017-12-30 01:31:25 --> Config Class Initialized
INFO - 2017-12-30 01:31:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:31:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:31:25 --> Utf8 Class Initialized
INFO - 2017-12-30 01:31:25 --> URI Class Initialized
INFO - 2017-12-30 01:31:25 --> Router Class Initialized
INFO - 2017-12-30 01:31:25 --> Output Class Initialized
INFO - 2017-12-30 01:31:25 --> Security Class Initialized
DEBUG - 2017-12-30 01:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:31:25 --> Input Class Initialized
INFO - 2017-12-30 01:31:25 --> Language Class Initialized
INFO - 2017-12-30 01:31:25 --> Loader Class Initialized
INFO - 2017-12-30 01:31:25 --> Helper loaded: url_helper
INFO - 2017-12-30 01:31:25 --> Helper loaded: form_helper
INFO - 2017-12-30 01:31:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:31:25 --> Form Validation Class Initialized
INFO - 2017-12-30 01:31:25 --> Model Class Initialized
INFO - 2017-12-30 01:31:25 --> Controller Class Initialized
INFO - 2017-12-30 01:31:25 --> Model Class Initialized
INFO - 2017-12-30 01:31:25 --> Model Class Initialized
INFO - 2017-12-30 01:31:25 --> Model Class Initialized
INFO - 2017-12-30 01:31:25 --> Model Class Initialized
DEBUG - 2017-12-30 01:31:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:31:25 --> Final output sent to browser
DEBUG - 2017-12-30 01:31:25 --> Total execution time: 0.0992
INFO - 2017-12-30 01:31:25 --> Config Class Initialized
INFO - 2017-12-30 01:31:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:31:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:31:25 --> Utf8 Class Initialized
INFO - 2017-12-30 01:31:25 --> URI Class Initialized
INFO - 2017-12-30 01:31:25 --> Router Class Initialized
INFO - 2017-12-30 01:31:25 --> Output Class Initialized
INFO - 2017-12-30 01:31:25 --> Security Class Initialized
DEBUG - 2017-12-30 01:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:31:25 --> Input Class Initialized
INFO - 2017-12-30 01:31:25 --> Language Class Initialized
INFO - 2017-12-30 01:31:25 --> Loader Class Initialized
INFO - 2017-12-30 01:31:25 --> Helper loaded: url_helper
INFO - 2017-12-30 01:31:25 --> Helper loaded: form_helper
INFO - 2017-12-30 01:31:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:31:26 --> Form Validation Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Controller Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
DEBUG - 2017-12-30 01:31:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:31:26 --> Final output sent to browser
DEBUG - 2017-12-30 01:31:26 --> Total execution time: 0.1269
INFO - 2017-12-30 01:31:26 --> Config Class Initialized
INFO - 2017-12-30 01:31:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:31:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:31:26 --> Utf8 Class Initialized
INFO - 2017-12-30 01:31:26 --> URI Class Initialized
INFO - 2017-12-30 01:31:26 --> Router Class Initialized
INFO - 2017-12-30 01:31:26 --> Output Class Initialized
INFO - 2017-12-30 01:31:26 --> Security Class Initialized
DEBUG - 2017-12-30 01:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:31:26 --> Input Class Initialized
INFO - 2017-12-30 01:31:26 --> Language Class Initialized
INFO - 2017-12-30 01:31:26 --> Loader Class Initialized
INFO - 2017-12-30 01:31:26 --> Helper loaded: url_helper
INFO - 2017-12-30 01:31:26 --> Helper loaded: form_helper
INFO - 2017-12-30 01:31:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:31:26 --> Form Validation Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Controller Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
INFO - 2017-12-30 01:31:26 --> Model Class Initialized
DEBUG - 2017-12-30 01:31:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:31:26 --> Final output sent to browser
DEBUG - 2017-12-30 01:31:26 --> Total execution time: 0.2391
INFO - 2017-12-30 01:35:05 --> Config Class Initialized
INFO - 2017-12-30 01:35:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:35:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:35:05 --> Utf8 Class Initialized
INFO - 2017-12-30 01:35:05 --> URI Class Initialized
INFO - 2017-12-30 01:35:05 --> Router Class Initialized
INFO - 2017-12-30 01:35:05 --> Output Class Initialized
INFO - 2017-12-30 01:35:05 --> Security Class Initialized
DEBUG - 2017-12-30 01:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:35:05 --> Input Class Initialized
INFO - 2017-12-30 01:35:05 --> Language Class Initialized
INFO - 2017-12-30 01:35:05 --> Loader Class Initialized
INFO - 2017-12-30 01:35:05 --> Helper loaded: url_helper
INFO - 2017-12-30 01:35:05 --> Helper loaded: form_helper
INFO - 2017-12-30 01:35:05 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:35:05 --> Form Validation Class Initialized
INFO - 2017-12-30 01:35:05 --> Model Class Initialized
INFO - 2017-12-30 01:35:05 --> Controller Class Initialized
INFO - 2017-12-30 01:35:05 --> Model Class Initialized
INFO - 2017-12-30 01:35:05 --> Model Class Initialized
INFO - 2017-12-30 01:35:05 --> Model Class Initialized
INFO - 2017-12-30 01:35:05 --> Model Class Initialized
DEBUG - 2017-12-30 01:35:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:35:05 --> Final output sent to browser
DEBUG - 2017-12-30 01:35:05 --> Total execution time: 0.1343
INFO - 2017-12-30 01:35:32 --> Config Class Initialized
INFO - 2017-12-30 01:35:32 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:35:32 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:35:32 --> Utf8 Class Initialized
INFO - 2017-12-30 01:35:33 --> URI Class Initialized
INFO - 2017-12-30 01:35:33 --> Router Class Initialized
INFO - 2017-12-30 01:35:33 --> Output Class Initialized
INFO - 2017-12-30 01:35:33 --> Security Class Initialized
DEBUG - 2017-12-30 01:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:35:33 --> Input Class Initialized
INFO - 2017-12-30 01:35:33 --> Language Class Initialized
INFO - 2017-12-30 01:35:33 --> Loader Class Initialized
INFO - 2017-12-30 01:35:33 --> Helper loaded: url_helper
INFO - 2017-12-30 01:35:33 --> Helper loaded: form_helper
INFO - 2017-12-30 01:35:33 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:35:33 --> Form Validation Class Initialized
INFO - 2017-12-30 01:35:33 --> Model Class Initialized
INFO - 2017-12-30 01:35:33 --> Controller Class Initialized
INFO - 2017-12-30 01:35:33 --> Model Class Initialized
INFO - 2017-12-30 01:35:33 --> Model Class Initialized
INFO - 2017-12-30 01:35:33 --> Model Class Initialized
INFO - 2017-12-30 01:35:33 --> Model Class Initialized
DEBUG - 2017-12-30 01:35:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:35:33 --> Final output sent to browser
DEBUG - 2017-12-30 01:35:33 --> Total execution time: 0.1781
INFO - 2017-12-30 01:36:02 --> Config Class Initialized
INFO - 2017-12-30 01:36:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:36:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:36:02 --> Utf8 Class Initialized
INFO - 2017-12-30 01:36:02 --> URI Class Initialized
INFO - 2017-12-30 01:36:02 --> Router Class Initialized
INFO - 2017-12-30 01:36:02 --> Output Class Initialized
INFO - 2017-12-30 01:36:02 --> Security Class Initialized
DEBUG - 2017-12-30 01:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:36:02 --> Input Class Initialized
INFO - 2017-12-30 01:36:02 --> Language Class Initialized
INFO - 2017-12-30 01:36:02 --> Loader Class Initialized
INFO - 2017-12-30 01:36:02 --> Helper loaded: url_helper
INFO - 2017-12-30 01:36:02 --> Helper loaded: form_helper
INFO - 2017-12-30 01:36:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:36:02 --> Form Validation Class Initialized
INFO - 2017-12-30 01:36:02 --> Model Class Initialized
INFO - 2017-12-30 01:36:02 --> Controller Class Initialized
INFO - 2017-12-30 01:36:02 --> Model Class Initialized
INFO - 2017-12-30 01:36:02 --> Model Class Initialized
INFO - 2017-12-30 01:36:02 --> Model Class Initialized
INFO - 2017-12-30 01:36:02 --> Model Class Initialized
DEBUG - 2017-12-30 01:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:36:02 --> Final output sent to browser
DEBUG - 2017-12-30 01:36:02 --> Total execution time: 0.1119
INFO - 2017-12-30 01:43:18 --> Config Class Initialized
INFO - 2017-12-30 01:43:18 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:43:18 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:43:18 --> Utf8 Class Initialized
INFO - 2017-12-30 01:43:18 --> URI Class Initialized
INFO - 2017-12-30 01:43:18 --> Router Class Initialized
INFO - 2017-12-30 01:43:18 --> Output Class Initialized
INFO - 2017-12-30 01:43:18 --> Security Class Initialized
DEBUG - 2017-12-30 01:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:43:18 --> Input Class Initialized
INFO - 2017-12-30 01:43:18 --> Language Class Initialized
INFO - 2017-12-30 01:43:18 --> Loader Class Initialized
INFO - 2017-12-30 01:43:18 --> Helper loaded: url_helper
INFO - 2017-12-30 01:43:18 --> Helper loaded: form_helper
INFO - 2017-12-30 01:43:18 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:43:18 --> Form Validation Class Initialized
INFO - 2017-12-30 01:43:18 --> Model Class Initialized
INFO - 2017-12-30 01:43:18 --> Controller Class Initialized
INFO - 2017-12-30 01:43:18 --> Model Class Initialized
INFO - 2017-12-30 01:43:18 --> Model Class Initialized
INFO - 2017-12-30 01:43:18 --> Model Class Initialized
INFO - 2017-12-30 01:43:18 --> Model Class Initialized
DEBUG - 2017-12-30 01:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:43:21 --> Config Class Initialized
INFO - 2017-12-30 01:43:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:43:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:43:21 --> Utf8 Class Initialized
INFO - 2017-12-30 01:43:21 --> URI Class Initialized
INFO - 2017-12-30 01:43:21 --> Router Class Initialized
INFO - 2017-12-30 01:43:21 --> Output Class Initialized
INFO - 2017-12-30 01:43:21 --> Security Class Initialized
DEBUG - 2017-12-30 01:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:43:21 --> Input Class Initialized
INFO - 2017-12-30 01:43:21 --> Language Class Initialized
INFO - 2017-12-30 01:43:21 --> Loader Class Initialized
INFO - 2017-12-30 01:43:21 --> Helper loaded: url_helper
INFO - 2017-12-30 01:43:21 --> Helper loaded: form_helper
INFO - 2017-12-30 01:43:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:43:21 --> Form Validation Class Initialized
INFO - 2017-12-30 01:43:21 --> Model Class Initialized
INFO - 2017-12-30 01:43:21 --> Controller Class Initialized
INFO - 2017-12-30 01:43:21 --> Model Class Initialized
INFO - 2017-12-30 01:43:21 --> Model Class Initialized
INFO - 2017-12-30 01:43:21 --> Model Class Initialized
INFO - 2017-12-30 01:43:21 --> Model Class Initialized
DEBUG - 2017-12-30 01:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:43:22 --> Config Class Initialized
INFO - 2017-12-30 01:43:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:43:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:43:22 --> Utf8 Class Initialized
INFO - 2017-12-30 01:43:22 --> URI Class Initialized
INFO - 2017-12-30 01:43:22 --> Router Class Initialized
INFO - 2017-12-30 01:43:22 --> Output Class Initialized
INFO - 2017-12-30 01:43:22 --> Security Class Initialized
DEBUG - 2017-12-30 01:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:43:22 --> Input Class Initialized
INFO - 2017-12-30 01:43:22 --> Language Class Initialized
INFO - 2017-12-30 01:43:22 --> Loader Class Initialized
INFO - 2017-12-30 01:43:22 --> Helper loaded: url_helper
INFO - 2017-12-30 01:43:22 --> Helper loaded: form_helper
INFO - 2017-12-30 01:43:22 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:43:22 --> Form Validation Class Initialized
INFO - 2017-12-30 01:43:22 --> Model Class Initialized
INFO - 2017-12-30 01:43:22 --> Controller Class Initialized
INFO - 2017-12-30 01:43:22 --> Model Class Initialized
INFO - 2017-12-30 01:43:22 --> Model Class Initialized
INFO - 2017-12-30 01:43:22 --> Model Class Initialized
INFO - 2017-12-30 01:43:22 --> Model Class Initialized
DEBUG - 2017-12-30 01:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:53:21 --> Config Class Initialized
INFO - 2017-12-30 01:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:53:21 --> Utf8 Class Initialized
INFO - 2017-12-30 01:53:21 --> URI Class Initialized
INFO - 2017-12-30 01:53:21 --> Router Class Initialized
INFO - 2017-12-30 01:53:21 --> Output Class Initialized
INFO - 2017-12-30 01:53:21 --> Security Class Initialized
DEBUG - 2017-12-30 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:53:21 --> Input Class Initialized
INFO - 2017-12-30 01:53:21 --> Language Class Initialized
INFO - 2017-12-30 01:53:21 --> Loader Class Initialized
INFO - 2017-12-30 01:53:21 --> Helper loaded: url_helper
INFO - 2017-12-30 01:53:21 --> Helper loaded: form_helper
INFO - 2017-12-30 01:53:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:53:21 --> Form Validation Class Initialized
INFO - 2017-12-30 01:53:21 --> Model Class Initialized
INFO - 2017-12-30 01:53:21 --> Controller Class Initialized
INFO - 2017-12-30 01:53:21 --> Model Class Initialized
INFO - 2017-12-30 01:53:21 --> Model Class Initialized
INFO - 2017-12-30 01:53:21 --> Model Class Initialized
INFO - 2017-12-30 01:53:21 --> Model Class Initialized
DEBUG - 2017-12-30 01:53:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 01:53:22 --> Severity: Error --> Call to undefined method PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::applyFromArray() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 62
INFO - 2017-12-30 01:54:10 --> Config Class Initialized
INFO - 2017-12-30 01:54:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:54:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:54:10 --> Utf8 Class Initialized
INFO - 2017-12-30 01:54:10 --> URI Class Initialized
INFO - 2017-12-30 01:54:10 --> Router Class Initialized
INFO - 2017-12-30 01:54:10 --> Output Class Initialized
INFO - 2017-12-30 01:54:10 --> Security Class Initialized
DEBUG - 2017-12-30 01:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:54:10 --> Input Class Initialized
INFO - 2017-12-30 01:54:10 --> Language Class Initialized
INFO - 2017-12-30 01:54:10 --> Loader Class Initialized
INFO - 2017-12-30 01:54:10 --> Helper loaded: url_helper
INFO - 2017-12-30 01:54:10 --> Helper loaded: form_helper
INFO - 2017-12-30 01:54:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:54:10 --> Form Validation Class Initialized
INFO - 2017-12-30 01:54:10 --> Model Class Initialized
INFO - 2017-12-30 01:54:10 --> Controller Class Initialized
INFO - 2017-12-30 01:54:10 --> Model Class Initialized
INFO - 2017-12-30 01:54:10 --> Model Class Initialized
INFO - 2017-12-30 01:54:10 --> Model Class Initialized
INFO - 2017-12-30 01:54:10 --> Model Class Initialized
DEBUG - 2017-12-30 01:54:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 01:54:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 64
INFO - 2017-12-30 01:54:10 --> Final output sent to browser
DEBUG - 2017-12-30 01:54:10 --> Total execution time: 0.1673
INFO - 2017-12-30 01:58:06 --> Config Class Initialized
INFO - 2017-12-30 01:58:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:58:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:58:06 --> Utf8 Class Initialized
INFO - 2017-12-30 01:58:06 --> URI Class Initialized
INFO - 2017-12-30 01:58:06 --> Router Class Initialized
INFO - 2017-12-30 01:58:06 --> Output Class Initialized
INFO - 2017-12-30 01:58:06 --> Security Class Initialized
DEBUG - 2017-12-30 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:58:06 --> Input Class Initialized
INFO - 2017-12-30 01:58:06 --> Language Class Initialized
INFO - 2017-12-30 01:58:06 --> Loader Class Initialized
INFO - 2017-12-30 01:58:06 --> Helper loaded: url_helper
INFO - 2017-12-30 01:58:06 --> Helper loaded: form_helper
INFO - 2017-12-30 01:58:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:58:06 --> Form Validation Class Initialized
INFO - 2017-12-30 01:58:06 --> Model Class Initialized
INFO - 2017-12-30 01:58:06 --> Controller Class Initialized
INFO - 2017-12-30 01:58:06 --> Model Class Initialized
INFO - 2017-12-30 01:58:06 --> Model Class Initialized
INFO - 2017-12-30 01:58:06 --> Model Class Initialized
INFO - 2017-12-30 01:58:06 --> Model Class Initialized
DEBUG - 2017-12-30 01:58:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 01:58:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 64
ERROR - 2017-12-30 01:58:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 73
INFO - 2017-12-30 01:58:07 --> Final output sent to browser
DEBUG - 2017-12-30 01:58:07 --> Total execution time: 0.1847
INFO - 2017-12-30 01:58:08 --> Config Class Initialized
INFO - 2017-12-30 01:58:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:58:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:58:08 --> Utf8 Class Initialized
INFO - 2017-12-30 01:58:08 --> URI Class Initialized
INFO - 2017-12-30 01:58:08 --> Router Class Initialized
INFO - 2017-12-30 01:58:08 --> Output Class Initialized
INFO - 2017-12-30 01:58:08 --> Security Class Initialized
DEBUG - 2017-12-30 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:58:08 --> Input Class Initialized
INFO - 2017-12-30 01:58:08 --> Language Class Initialized
INFO - 2017-12-30 01:58:08 --> Loader Class Initialized
INFO - 2017-12-30 01:58:08 --> Helper loaded: url_helper
INFO - 2017-12-30 01:58:08 --> Helper loaded: form_helper
INFO - 2017-12-30 01:58:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:58:08 --> Form Validation Class Initialized
INFO - 2017-12-30 01:58:08 --> Model Class Initialized
INFO - 2017-12-30 01:58:08 --> Controller Class Initialized
INFO - 2017-12-30 01:58:08 --> Model Class Initialized
INFO - 2017-12-30 01:58:08 --> Model Class Initialized
INFO - 2017-12-30 01:58:08 --> Model Class Initialized
INFO - 2017-12-30 01:58:08 --> Model Class Initialized
DEBUG - 2017-12-30 01:58:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 01:58:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 64
ERROR - 2017-12-30 01:58:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 73
INFO - 2017-12-30 01:58:08 --> Final output sent to browser
DEBUG - 2017-12-30 01:58:08 --> Total execution time: 0.1635
INFO - 2017-12-30 01:58:28 --> Config Class Initialized
INFO - 2017-12-30 01:58:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:58:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:58:28 --> Utf8 Class Initialized
INFO - 2017-12-30 01:58:28 --> URI Class Initialized
INFO - 2017-12-30 01:58:28 --> Router Class Initialized
INFO - 2017-12-30 01:58:28 --> Output Class Initialized
INFO - 2017-12-30 01:58:28 --> Security Class Initialized
DEBUG - 2017-12-30 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:58:28 --> Input Class Initialized
INFO - 2017-12-30 01:58:28 --> Language Class Initialized
INFO - 2017-12-30 01:58:28 --> Loader Class Initialized
INFO - 2017-12-30 01:58:28 --> Helper loaded: url_helper
INFO - 2017-12-30 01:58:28 --> Helper loaded: form_helper
INFO - 2017-12-30 01:58:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:58:28 --> Form Validation Class Initialized
INFO - 2017-12-30 01:58:28 --> Model Class Initialized
INFO - 2017-12-30 01:58:28 --> Controller Class Initialized
INFO - 2017-12-30 01:58:28 --> Model Class Initialized
INFO - 2017-12-30 01:58:28 --> Model Class Initialized
INFO - 2017-12-30 01:58:28 --> Model Class Initialized
INFO - 2017-12-30 01:58:28 --> Model Class Initialized
DEBUG - 2017-12-30 01:58:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:59:06 --> Config Class Initialized
INFO - 2017-12-30 01:59:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:59:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:59:06 --> Utf8 Class Initialized
INFO - 2017-12-30 01:59:06 --> URI Class Initialized
INFO - 2017-12-30 01:59:06 --> Router Class Initialized
INFO - 2017-12-30 01:59:06 --> Output Class Initialized
INFO - 2017-12-30 01:59:06 --> Security Class Initialized
DEBUG - 2017-12-30 01:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:59:06 --> Input Class Initialized
INFO - 2017-12-30 01:59:06 --> Language Class Initialized
INFO - 2017-12-30 01:59:06 --> Loader Class Initialized
INFO - 2017-12-30 01:59:06 --> Helper loaded: url_helper
INFO - 2017-12-30 01:59:06 --> Helper loaded: form_helper
INFO - 2017-12-30 01:59:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:59:06 --> Form Validation Class Initialized
INFO - 2017-12-30 01:59:06 --> Model Class Initialized
INFO - 2017-12-30 01:59:06 --> Controller Class Initialized
INFO - 2017-12-30 01:59:06 --> Model Class Initialized
INFO - 2017-12-30 01:59:06 --> Model Class Initialized
INFO - 2017-12-30 01:59:06 --> Model Class Initialized
INFO - 2017-12-30 01:59:06 --> Model Class Initialized
DEBUG - 2017-12-30 01:59:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:59:36 --> Config Class Initialized
INFO - 2017-12-30 01:59:36 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:59:36 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:59:36 --> Utf8 Class Initialized
INFO - 2017-12-30 01:59:36 --> URI Class Initialized
INFO - 2017-12-30 01:59:36 --> Router Class Initialized
INFO - 2017-12-30 01:59:36 --> Output Class Initialized
INFO - 2017-12-30 01:59:36 --> Security Class Initialized
DEBUG - 2017-12-30 01:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:59:36 --> Input Class Initialized
INFO - 2017-12-30 01:59:36 --> Language Class Initialized
INFO - 2017-12-30 01:59:36 --> Loader Class Initialized
INFO - 2017-12-30 01:59:36 --> Helper loaded: url_helper
INFO - 2017-12-30 01:59:36 --> Helper loaded: form_helper
INFO - 2017-12-30 01:59:36 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:59:36 --> Form Validation Class Initialized
INFO - 2017-12-30 01:59:36 --> Model Class Initialized
INFO - 2017-12-30 01:59:36 --> Controller Class Initialized
INFO - 2017-12-30 01:59:36 --> Model Class Initialized
INFO - 2017-12-30 01:59:36 --> Model Class Initialized
INFO - 2017-12-30 01:59:36 --> Model Class Initialized
INFO - 2017-12-30 01:59:36 --> Model Class Initialized
DEBUG - 2017-12-30 01:59:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:59:42 --> Config Class Initialized
INFO - 2017-12-30 01:59:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 01:59:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 01:59:42 --> Utf8 Class Initialized
INFO - 2017-12-30 01:59:42 --> URI Class Initialized
INFO - 2017-12-30 01:59:42 --> Router Class Initialized
INFO - 2017-12-30 01:59:42 --> Output Class Initialized
INFO - 2017-12-30 01:59:42 --> Security Class Initialized
DEBUG - 2017-12-30 01:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 01:59:42 --> Input Class Initialized
INFO - 2017-12-30 01:59:42 --> Language Class Initialized
INFO - 2017-12-30 01:59:42 --> Loader Class Initialized
INFO - 2017-12-30 01:59:42 --> Helper loaded: url_helper
INFO - 2017-12-30 01:59:42 --> Helper loaded: form_helper
INFO - 2017-12-30 01:59:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 01:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 01:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 01:59:42 --> Form Validation Class Initialized
INFO - 2017-12-30 01:59:42 --> Model Class Initialized
INFO - 2017-12-30 01:59:42 --> Controller Class Initialized
INFO - 2017-12-30 01:59:42 --> Model Class Initialized
INFO - 2017-12-30 01:59:42 --> Model Class Initialized
INFO - 2017-12-30 01:59:42 --> Model Class Initialized
INFO - 2017-12-30 01:59:42 --> Model Class Initialized
DEBUG - 2017-12-30 01:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 01:59:42 --> Final output sent to browser
DEBUG - 2017-12-30 01:59:42 --> Total execution time: 0.1900
INFO - 2017-12-30 02:00:13 --> Config Class Initialized
INFO - 2017-12-30 02:00:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:00:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:00:13 --> Utf8 Class Initialized
INFO - 2017-12-30 02:00:13 --> URI Class Initialized
INFO - 2017-12-30 02:00:13 --> Router Class Initialized
INFO - 2017-12-30 02:00:13 --> Output Class Initialized
INFO - 2017-12-30 02:00:13 --> Security Class Initialized
DEBUG - 2017-12-30 02:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:00:13 --> Input Class Initialized
INFO - 2017-12-30 02:00:13 --> Language Class Initialized
INFO - 2017-12-30 02:00:13 --> Loader Class Initialized
INFO - 2017-12-30 02:00:13 --> Helper loaded: url_helper
INFO - 2017-12-30 02:00:13 --> Helper loaded: form_helper
INFO - 2017-12-30 02:00:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:00:13 --> Form Validation Class Initialized
INFO - 2017-12-30 02:00:13 --> Model Class Initialized
INFO - 2017-12-30 02:00:13 --> Controller Class Initialized
INFO - 2017-12-30 02:00:13 --> Model Class Initialized
INFO - 2017-12-30 02:00:13 --> Model Class Initialized
INFO - 2017-12-30 02:00:13 --> Model Class Initialized
INFO - 2017-12-30 02:00:13 --> Model Class Initialized
DEBUG - 2017-12-30 02:00:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:00:13 --> Final output sent to browser
DEBUG - 2017-12-30 02:00:13 --> Total execution time: 0.2148
INFO - 2017-12-30 02:02:04 --> Config Class Initialized
INFO - 2017-12-30 02:02:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:02:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:02:04 --> Utf8 Class Initialized
INFO - 2017-12-30 02:02:04 --> URI Class Initialized
INFO - 2017-12-30 02:02:04 --> Router Class Initialized
INFO - 2017-12-30 02:02:04 --> Output Class Initialized
INFO - 2017-12-30 02:02:04 --> Security Class Initialized
DEBUG - 2017-12-30 02:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:02:04 --> Input Class Initialized
INFO - 2017-12-30 02:02:04 --> Language Class Initialized
INFO - 2017-12-30 02:02:04 --> Loader Class Initialized
INFO - 2017-12-30 02:02:04 --> Helper loaded: url_helper
INFO - 2017-12-30 02:02:04 --> Helper loaded: form_helper
INFO - 2017-12-30 02:02:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:02:04 --> Form Validation Class Initialized
INFO - 2017-12-30 02:02:04 --> Model Class Initialized
INFO - 2017-12-30 02:02:04 --> Controller Class Initialized
INFO - 2017-12-30 02:02:04 --> Model Class Initialized
INFO - 2017-12-30 02:02:04 --> Model Class Initialized
INFO - 2017-12-30 02:02:04 --> Model Class Initialized
INFO - 2017-12-30 02:02:04 --> Model Class Initialized
DEBUG - 2017-12-30 02:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:02:04 --> Final output sent to browser
DEBUG - 2017-12-30 02:02:04 --> Total execution time: 0.2629
INFO - 2017-12-30 02:04:21 --> Config Class Initialized
INFO - 2017-12-30 02:04:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:04:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:04:21 --> Utf8 Class Initialized
INFO - 2017-12-30 02:04:21 --> URI Class Initialized
INFO - 2017-12-30 02:04:21 --> Router Class Initialized
INFO - 2017-12-30 02:04:21 --> Output Class Initialized
INFO - 2017-12-30 02:04:21 --> Security Class Initialized
DEBUG - 2017-12-30 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:04:21 --> Input Class Initialized
INFO - 2017-12-30 02:04:21 --> Language Class Initialized
INFO - 2017-12-30 02:04:21 --> Loader Class Initialized
INFO - 2017-12-30 02:04:21 --> Helper loaded: url_helper
INFO - 2017-12-30 02:04:21 --> Helper loaded: form_helper
INFO - 2017-12-30 02:04:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:04:21 --> Form Validation Class Initialized
INFO - 2017-12-30 02:04:21 --> Model Class Initialized
INFO - 2017-12-30 02:04:21 --> Controller Class Initialized
INFO - 2017-12-30 02:04:21 --> Model Class Initialized
INFO - 2017-12-30 02:04:21 --> Model Class Initialized
INFO - 2017-12-30 02:04:21 --> Model Class Initialized
INFO - 2017-12-30 02:04:21 --> Model Class Initialized
DEBUG - 2017-12-30 02:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:04:21 --> Final output sent to browser
DEBUG - 2017-12-30 02:04:21 --> Total execution time: 0.2190
INFO - 2017-12-30 02:11:08 --> Config Class Initialized
INFO - 2017-12-30 02:11:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:08 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:08 --> URI Class Initialized
INFO - 2017-12-30 02:11:08 --> Router Class Initialized
INFO - 2017-12-30 02:11:08 --> Output Class Initialized
INFO - 2017-12-30 02:11:08 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:08 --> Input Class Initialized
INFO - 2017-12-30 02:11:08 --> Language Class Initialized
INFO - 2017-12-30 02:11:08 --> Loader Class Initialized
INFO - 2017-12-30 02:11:08 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:08 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:08 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:08 --> Model Class Initialized
INFO - 2017-12-30 02:11:08 --> Controller Class Initialized
INFO - 2017-12-30 02:11:08 --> Model Class Initialized
INFO - 2017-12-30 02:11:08 --> Model Class Initialized
INFO - 2017-12-30 02:11:08 --> Model Class Initialized
INFO - 2017-12-30 02:11:08 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:22 --> Config Class Initialized
INFO - 2017-12-30 02:11:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:22 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:22 --> URI Class Initialized
INFO - 2017-12-30 02:11:22 --> Router Class Initialized
INFO - 2017-12-30 02:11:22 --> Output Class Initialized
INFO - 2017-12-30 02:11:22 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:22 --> Input Class Initialized
INFO - 2017-12-30 02:11:22 --> Language Class Initialized
INFO - 2017-12-30 02:11:22 --> Loader Class Initialized
INFO - 2017-12-30 02:11:22 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:22 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:22 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:22 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:22 --> Model Class Initialized
INFO - 2017-12-30 02:11:22 --> Controller Class Initialized
INFO - 2017-12-30 02:11:22 --> Model Class Initialized
INFO - 2017-12-30 02:11:22 --> Model Class Initialized
INFO - 2017-12-30 02:11:22 --> Model Class Initialized
INFO - 2017-12-30 02:11:22 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:24 --> Config Class Initialized
INFO - 2017-12-30 02:11:24 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:24 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:24 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:24 --> URI Class Initialized
INFO - 2017-12-30 02:11:24 --> Router Class Initialized
INFO - 2017-12-30 02:11:24 --> Output Class Initialized
INFO - 2017-12-30 02:11:24 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:24 --> Input Class Initialized
INFO - 2017-12-30 02:11:24 --> Language Class Initialized
INFO - 2017-12-30 02:11:24 --> Loader Class Initialized
INFO - 2017-12-30 02:11:24 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:24 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:24 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:24 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:24 --> Model Class Initialized
INFO - 2017-12-30 02:11:24 --> Controller Class Initialized
INFO - 2017-12-30 02:11:24 --> Model Class Initialized
INFO - 2017-12-30 02:11:24 --> Model Class Initialized
INFO - 2017-12-30 02:11:24 --> Model Class Initialized
INFO - 2017-12-30 02:11:24 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:25 --> Config Class Initialized
INFO - 2017-12-30 02:11:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:25 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:25 --> URI Class Initialized
INFO - 2017-12-30 02:11:25 --> Router Class Initialized
INFO - 2017-12-30 02:11:25 --> Output Class Initialized
INFO - 2017-12-30 02:11:25 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:25 --> Input Class Initialized
INFO - 2017-12-30 02:11:25 --> Language Class Initialized
INFO - 2017-12-30 02:11:25 --> Loader Class Initialized
INFO - 2017-12-30 02:11:25 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:25 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:26 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Controller Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:26 --> Config Class Initialized
INFO - 2017-12-30 02:11:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:26 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:26 --> URI Class Initialized
INFO - 2017-12-30 02:11:26 --> Router Class Initialized
INFO - 2017-12-30 02:11:26 --> Output Class Initialized
INFO - 2017-12-30 02:11:26 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:26 --> Input Class Initialized
INFO - 2017-12-30 02:11:26 --> Language Class Initialized
INFO - 2017-12-30 02:11:26 --> Loader Class Initialized
INFO - 2017-12-30 02:11:26 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:26 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:26 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Controller Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
INFO - 2017-12-30 02:11:26 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:27 --> Config Class Initialized
INFO - 2017-12-30 02:11:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:27 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:27 --> URI Class Initialized
INFO - 2017-12-30 02:11:27 --> Router Class Initialized
INFO - 2017-12-30 02:11:27 --> Output Class Initialized
INFO - 2017-12-30 02:11:27 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:27 --> Input Class Initialized
INFO - 2017-12-30 02:11:27 --> Language Class Initialized
INFO - 2017-12-30 02:11:27 --> Loader Class Initialized
INFO - 2017-12-30 02:11:27 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:27 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:27 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:27 --> Model Class Initialized
INFO - 2017-12-30 02:11:27 --> Controller Class Initialized
INFO - 2017-12-30 02:11:27 --> Model Class Initialized
INFO - 2017-12-30 02:11:27 --> Model Class Initialized
INFO - 2017-12-30 02:11:27 --> Model Class Initialized
INFO - 2017-12-30 02:11:27 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:28 --> Config Class Initialized
INFO - 2017-12-30 02:11:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:28 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:28 --> URI Class Initialized
INFO - 2017-12-30 02:11:28 --> Router Class Initialized
INFO - 2017-12-30 02:11:28 --> Output Class Initialized
INFO - 2017-12-30 02:11:28 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:28 --> Input Class Initialized
INFO - 2017-12-30 02:11:28 --> Language Class Initialized
INFO - 2017-12-30 02:11:28 --> Loader Class Initialized
INFO - 2017-12-30 02:11:28 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:28 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:28 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:28 --> Model Class Initialized
INFO - 2017-12-30 02:11:28 --> Controller Class Initialized
INFO - 2017-12-30 02:11:28 --> Model Class Initialized
INFO - 2017-12-30 02:11:28 --> Model Class Initialized
INFO - 2017-12-30 02:11:28 --> Model Class Initialized
INFO - 2017-12-30 02:11:28 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:11:29 --> Config Class Initialized
INFO - 2017-12-30 02:11:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:11:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:11:29 --> Utf8 Class Initialized
INFO - 2017-12-30 02:11:29 --> URI Class Initialized
INFO - 2017-12-30 02:11:29 --> Router Class Initialized
INFO - 2017-12-30 02:11:29 --> Output Class Initialized
INFO - 2017-12-30 02:11:29 --> Security Class Initialized
DEBUG - 2017-12-30 02:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:11:29 --> Input Class Initialized
INFO - 2017-12-30 02:11:29 --> Language Class Initialized
INFO - 2017-12-30 02:11:29 --> Loader Class Initialized
INFO - 2017-12-30 02:11:29 --> Helper loaded: url_helper
INFO - 2017-12-30 02:11:29 --> Helper loaded: form_helper
INFO - 2017-12-30 02:11:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:11:29 --> Form Validation Class Initialized
INFO - 2017-12-30 02:11:29 --> Model Class Initialized
INFO - 2017-12-30 02:11:29 --> Controller Class Initialized
INFO - 2017-12-30 02:11:29 --> Model Class Initialized
INFO - 2017-12-30 02:11:29 --> Model Class Initialized
INFO - 2017-12-30 02:11:29 --> Model Class Initialized
INFO - 2017-12-30 02:11:29 --> Model Class Initialized
DEBUG - 2017-12-30 02:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:16:33 --> Config Class Initialized
INFO - 2017-12-30 02:16:33 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:16:33 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:16:33 --> Utf8 Class Initialized
INFO - 2017-12-30 02:16:33 --> URI Class Initialized
INFO - 2017-12-30 02:16:33 --> Router Class Initialized
INFO - 2017-12-30 02:16:33 --> Output Class Initialized
INFO - 2017-12-30 02:16:33 --> Security Class Initialized
DEBUG - 2017-12-30 02:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:16:33 --> Input Class Initialized
INFO - 2017-12-30 02:16:33 --> Language Class Initialized
ERROR - 2017-12-30 02:16:33 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 98
INFO - 2017-12-30 02:17:04 --> Config Class Initialized
INFO - 2017-12-30 02:17:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:17:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:17:04 --> Utf8 Class Initialized
INFO - 2017-12-30 02:17:04 --> URI Class Initialized
INFO - 2017-12-30 02:17:04 --> Router Class Initialized
INFO - 2017-12-30 02:17:04 --> Output Class Initialized
INFO - 2017-12-30 02:17:04 --> Security Class Initialized
DEBUG - 2017-12-30 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:17:04 --> Input Class Initialized
INFO - 2017-12-30 02:17:04 --> Language Class Initialized
INFO - 2017-12-30 02:17:04 --> Loader Class Initialized
INFO - 2017-12-30 02:17:04 --> Helper loaded: url_helper
INFO - 2017-12-30 02:17:04 --> Helper loaded: form_helper
INFO - 2017-12-30 02:17:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:17:04 --> Form Validation Class Initialized
INFO - 2017-12-30 02:17:04 --> Model Class Initialized
INFO - 2017-12-30 02:17:04 --> Controller Class Initialized
INFO - 2017-12-30 02:17:04 --> Model Class Initialized
INFO - 2017-12-30 02:17:04 --> Model Class Initialized
INFO - 2017-12-30 02:17:04 --> Model Class Initialized
INFO - 2017-12-30 02:17:04 --> Model Class Initialized
DEBUG - 2017-12-30 02:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:19:05 --> Config Class Initialized
INFO - 2017-12-30 02:19:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:19:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:19:05 --> Utf8 Class Initialized
INFO - 2017-12-30 02:19:05 --> URI Class Initialized
INFO - 2017-12-30 02:19:05 --> Router Class Initialized
INFO - 2017-12-30 02:19:05 --> Output Class Initialized
INFO - 2017-12-30 02:19:05 --> Security Class Initialized
DEBUG - 2017-12-30 02:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:19:05 --> Input Class Initialized
INFO - 2017-12-30 02:19:05 --> Language Class Initialized
INFO - 2017-12-30 02:19:05 --> Loader Class Initialized
INFO - 2017-12-30 02:19:05 --> Helper loaded: url_helper
INFO - 2017-12-30 02:19:05 --> Helper loaded: form_helper
INFO - 2017-12-30 02:19:05 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:19:05 --> Form Validation Class Initialized
INFO - 2017-12-30 02:19:05 --> Model Class Initialized
INFO - 2017-12-30 02:19:05 --> Controller Class Initialized
INFO - 2017-12-30 02:19:05 --> Model Class Initialized
INFO - 2017-12-30 02:19:05 --> Model Class Initialized
INFO - 2017-12-30 02:19:05 --> Model Class Initialized
INFO - 2017-12-30 02:19:05 --> Model Class Initialized
DEBUG - 2017-12-30 02:19:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:20:29 --> Config Class Initialized
INFO - 2017-12-30 02:20:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:20:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:20:29 --> Utf8 Class Initialized
INFO - 2017-12-30 02:20:29 --> URI Class Initialized
INFO - 2017-12-30 02:20:29 --> Router Class Initialized
INFO - 2017-12-30 02:20:29 --> Output Class Initialized
INFO - 2017-12-30 02:20:29 --> Security Class Initialized
DEBUG - 2017-12-30 02:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:20:29 --> Input Class Initialized
INFO - 2017-12-30 02:20:29 --> Language Class Initialized
INFO - 2017-12-30 02:20:29 --> Loader Class Initialized
INFO - 2017-12-30 02:20:29 --> Helper loaded: url_helper
INFO - 2017-12-30 02:20:29 --> Helper loaded: form_helper
INFO - 2017-12-30 02:20:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:20:29 --> Form Validation Class Initialized
INFO - 2017-12-30 02:20:29 --> Model Class Initialized
INFO - 2017-12-30 02:20:29 --> Controller Class Initialized
INFO - 2017-12-30 02:20:29 --> Model Class Initialized
INFO - 2017-12-30 02:20:29 --> Model Class Initialized
INFO - 2017-12-30 02:20:29 --> Model Class Initialized
INFO - 2017-12-30 02:20:29 --> Model Class Initialized
DEBUG - 2017-12-30 02:20:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 02:20:29 --> Severity: Error --> Call to a member function setValue() on null D:\xampp\htdocs\instateccr\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\Worksheet\Worksheet.php 1125
INFO - 2017-12-30 02:20:58 --> Config Class Initialized
INFO - 2017-12-30 02:20:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:20:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:20:58 --> Utf8 Class Initialized
INFO - 2017-12-30 02:20:58 --> URI Class Initialized
INFO - 2017-12-30 02:20:58 --> Router Class Initialized
INFO - 2017-12-30 02:20:58 --> Output Class Initialized
INFO - 2017-12-30 02:20:58 --> Security Class Initialized
DEBUG - 2017-12-30 02:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:20:58 --> Input Class Initialized
INFO - 2017-12-30 02:20:58 --> Language Class Initialized
INFO - 2017-12-30 02:20:58 --> Loader Class Initialized
INFO - 2017-12-30 02:20:58 --> Helper loaded: url_helper
INFO - 2017-12-30 02:20:58 --> Helper loaded: form_helper
INFO - 2017-12-30 02:20:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:20:58 --> Form Validation Class Initialized
INFO - 2017-12-30 02:20:58 --> Model Class Initialized
INFO - 2017-12-30 02:20:58 --> Controller Class Initialized
INFO - 2017-12-30 02:20:58 --> Model Class Initialized
INFO - 2017-12-30 02:20:58 --> Model Class Initialized
INFO - 2017-12-30 02:20:58 --> Model Class Initialized
INFO - 2017-12-30 02:20:58 --> Model Class Initialized
DEBUG - 2017-12-30 02:20:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:20:58 --> Final output sent to browser
DEBUG - 2017-12-30 02:20:58 --> Total execution time: 0.1643
INFO - 2017-12-30 02:24:16 --> Config Class Initialized
INFO - 2017-12-30 02:24:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:24:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:24:16 --> Utf8 Class Initialized
INFO - 2017-12-30 02:24:16 --> URI Class Initialized
INFO - 2017-12-30 02:24:16 --> Router Class Initialized
INFO - 2017-12-30 02:24:16 --> Output Class Initialized
INFO - 2017-12-30 02:24:16 --> Security Class Initialized
DEBUG - 2017-12-30 02:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:24:16 --> Input Class Initialized
INFO - 2017-12-30 02:24:16 --> Language Class Initialized
INFO - 2017-12-30 02:24:16 --> Loader Class Initialized
INFO - 2017-12-30 02:24:16 --> Helper loaded: url_helper
INFO - 2017-12-30 02:24:16 --> Helper loaded: form_helper
INFO - 2017-12-30 02:24:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:24:16 --> Form Validation Class Initialized
INFO - 2017-12-30 02:24:16 --> Model Class Initialized
INFO - 2017-12-30 02:24:16 --> Controller Class Initialized
INFO - 2017-12-30 02:24:16 --> Model Class Initialized
INFO - 2017-12-30 02:24:16 --> Model Class Initialized
INFO - 2017-12-30 02:24:16 --> Model Class Initialized
INFO - 2017-12-30 02:24:16 --> Model Class Initialized
DEBUG - 2017-12-30 02:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:24:16 --> Final output sent to browser
DEBUG - 2017-12-30 02:24:16 --> Total execution time: 0.2331
INFO - 2017-12-30 02:24:40 --> Config Class Initialized
INFO - 2017-12-30 02:24:40 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:24:40 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:24:40 --> Utf8 Class Initialized
INFO - 2017-12-30 02:24:40 --> URI Class Initialized
INFO - 2017-12-30 02:24:40 --> Router Class Initialized
INFO - 2017-12-30 02:24:40 --> Output Class Initialized
INFO - 2017-12-30 02:24:40 --> Security Class Initialized
DEBUG - 2017-12-30 02:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:24:40 --> Input Class Initialized
INFO - 2017-12-30 02:24:40 --> Language Class Initialized
INFO - 2017-12-30 02:24:40 --> Loader Class Initialized
INFO - 2017-12-30 02:24:40 --> Helper loaded: url_helper
INFO - 2017-12-30 02:24:40 --> Helper loaded: form_helper
INFO - 2017-12-30 02:24:40 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:24:40 --> Form Validation Class Initialized
INFO - 2017-12-30 02:24:40 --> Model Class Initialized
INFO - 2017-12-30 02:24:40 --> Controller Class Initialized
INFO - 2017-12-30 02:24:40 --> Model Class Initialized
INFO - 2017-12-30 02:24:40 --> Model Class Initialized
INFO - 2017-12-30 02:24:40 --> Model Class Initialized
INFO - 2017-12-30 02:24:40 --> Model Class Initialized
DEBUG - 2017-12-30 02:24:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:24:41 --> Final output sent to browser
DEBUG - 2017-12-30 02:24:41 --> Total execution time: 0.1973
INFO - 2017-12-30 02:28:20 --> Config Class Initialized
INFO - 2017-12-30 02:28:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:20 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:20 --> URI Class Initialized
INFO - 2017-12-30 02:28:20 --> Router Class Initialized
INFO - 2017-12-30 02:28:20 --> Output Class Initialized
INFO - 2017-12-30 02:28:20 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:20 --> Input Class Initialized
INFO - 2017-12-30 02:28:20 --> Language Class Initialized
ERROR - 2017-12-30 02:28:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
INFO - 2017-12-30 02:28:28 --> Config Class Initialized
INFO - 2017-12-30 02:28:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:28 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:28 --> URI Class Initialized
INFO - 2017-12-30 02:28:28 --> Router Class Initialized
INFO - 2017-12-30 02:28:28 --> Output Class Initialized
INFO - 2017-12-30 02:28:28 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:28 --> Input Class Initialized
INFO - 2017-12-30 02:28:28 --> Language Class Initialized
INFO - 2017-12-30 02:28:28 --> Loader Class Initialized
INFO - 2017-12-30 02:28:28 --> Helper loaded: url_helper
INFO - 2017-12-30 02:28:28 --> Helper loaded: form_helper
INFO - 2017-12-30 02:28:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:28:28 --> Form Validation Class Initialized
INFO - 2017-12-30 02:28:28 --> Model Class Initialized
INFO - 2017-12-30 02:28:28 --> Controller Class Initialized
INFO - 2017-12-30 02:28:28 --> Model Class Initialized
INFO - 2017-12-30 02:28:28 --> Model Class Initialized
INFO - 2017-12-30 02:28:28 --> Model Class Initialized
INFO - 2017-12-30 02:28:28 --> Model Class Initialized
DEBUG - 2017-12-30 02:28:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:28:45 --> Config Class Initialized
INFO - 2017-12-30 02:28:45 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:45 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:45 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:45 --> URI Class Initialized
INFO - 2017-12-30 02:28:45 --> Router Class Initialized
INFO - 2017-12-30 02:28:45 --> Output Class Initialized
INFO - 2017-12-30 02:28:45 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:45 --> Input Class Initialized
INFO - 2017-12-30 02:28:45 --> Language Class Initialized
INFO - 2017-12-30 02:28:45 --> Loader Class Initialized
INFO - 2017-12-30 02:28:45 --> Helper loaded: url_helper
INFO - 2017-12-30 02:28:45 --> Helper loaded: form_helper
INFO - 2017-12-30 02:28:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:28:45 --> Form Validation Class Initialized
INFO - 2017-12-30 02:28:45 --> Model Class Initialized
INFO - 2017-12-30 02:28:45 --> Controller Class Initialized
INFO - 2017-12-30 02:28:45 --> Model Class Initialized
INFO - 2017-12-30 02:28:45 --> Model Class Initialized
INFO - 2017-12-30 02:28:45 --> Model Class Initialized
INFO - 2017-12-30 02:28:45 --> Model Class Initialized
DEBUG - 2017-12-30 02:28:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:28:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 02:28:45 --> Final output sent to browser
DEBUG - 2017-12-30 02:28:45 --> Total execution time: 0.0552
INFO - 2017-12-30 02:28:46 --> Config Class Initialized
INFO - 2017-12-30 02:28:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:46 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:46 --> URI Class Initialized
INFO - 2017-12-30 02:28:46 --> Router Class Initialized
INFO - 2017-12-30 02:28:46 --> Output Class Initialized
INFO - 2017-12-30 02:28:46 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:46 --> Input Class Initialized
INFO - 2017-12-30 02:28:46 --> Language Class Initialized
INFO - 2017-12-30 02:28:46 --> Loader Class Initialized
INFO - 2017-12-30 02:28:46 --> Helper loaded: url_helper
INFO - 2017-12-30 02:28:46 --> Helper loaded: form_helper
INFO - 2017-12-30 02:28:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:28:46 --> Form Validation Class Initialized
INFO - 2017-12-30 02:28:46 --> Model Class Initialized
INFO - 2017-12-30 02:28:46 --> Controller Class Initialized
INFO - 2017-12-30 02:28:46 --> Model Class Initialized
INFO - 2017-12-30 02:28:46 --> Model Class Initialized
INFO - 2017-12-30 02:28:46 --> Model Class Initialized
INFO - 2017-12-30 02:28:46 --> Model Class Initialized
DEBUG - 2017-12-30 02:28:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:28:50 --> Config Class Initialized
INFO - 2017-12-30 02:28:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:50 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:50 --> URI Class Initialized
INFO - 2017-12-30 02:28:50 --> Router Class Initialized
INFO - 2017-12-30 02:28:50 --> Output Class Initialized
INFO - 2017-12-30 02:28:50 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:50 --> Input Class Initialized
INFO - 2017-12-30 02:28:50 --> Language Class Initialized
INFO - 2017-12-30 02:28:50 --> Loader Class Initialized
INFO - 2017-12-30 02:28:50 --> Helper loaded: url_helper
INFO - 2017-12-30 02:28:50 --> Helper loaded: form_helper
INFO - 2017-12-30 02:28:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:28:50 --> Form Validation Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Controller Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:28:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 02:28:50 --> Final output sent to browser
DEBUG - 2017-12-30 02:28:50 --> Total execution time: 0.0719
INFO - 2017-12-30 02:28:50 --> Config Class Initialized
INFO - 2017-12-30 02:28:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:28:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:28:50 --> Utf8 Class Initialized
INFO - 2017-12-30 02:28:50 --> URI Class Initialized
INFO - 2017-12-30 02:28:50 --> Router Class Initialized
INFO - 2017-12-30 02:28:50 --> Output Class Initialized
INFO - 2017-12-30 02:28:50 --> Security Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:28:50 --> Input Class Initialized
INFO - 2017-12-30 02:28:50 --> Language Class Initialized
INFO - 2017-12-30 02:28:50 --> Loader Class Initialized
INFO - 2017-12-30 02:28:50 --> Helper loaded: url_helper
INFO - 2017-12-30 02:28:50 --> Helper loaded: form_helper
INFO - 2017-12-30 02:28:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:28:50 --> Form Validation Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Controller Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
INFO - 2017-12-30 02:28:50 --> Model Class Initialized
DEBUG - 2017-12-30 02:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:29:39 --> Config Class Initialized
INFO - 2017-12-30 02:29:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:29:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:29:39 --> Utf8 Class Initialized
INFO - 2017-12-30 02:29:39 --> URI Class Initialized
INFO - 2017-12-30 02:29:39 --> Router Class Initialized
INFO - 2017-12-30 02:29:39 --> Output Class Initialized
INFO - 2017-12-30 02:29:39 --> Security Class Initialized
DEBUG - 2017-12-30 02:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:29:39 --> Input Class Initialized
INFO - 2017-12-30 02:29:39 --> Language Class Initialized
INFO - 2017-12-30 02:29:39 --> Loader Class Initialized
INFO - 2017-12-30 02:29:39 --> Helper loaded: url_helper
INFO - 2017-12-30 02:29:39 --> Helper loaded: form_helper
INFO - 2017-12-30 02:29:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:29:39 --> Form Validation Class Initialized
INFO - 2017-12-30 02:29:39 --> Model Class Initialized
INFO - 2017-12-30 02:29:39 --> Controller Class Initialized
INFO - 2017-12-30 02:29:39 --> Model Class Initialized
INFO - 2017-12-30 02:29:39 --> Model Class Initialized
INFO - 2017-12-30 02:29:39 --> Model Class Initialized
INFO - 2017-12-30 02:29:39 --> Model Class Initialized
DEBUG - 2017-12-30 02:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:30:31 --> Config Class Initialized
INFO - 2017-12-30 02:30:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:30:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:30:31 --> Utf8 Class Initialized
INFO - 2017-12-30 02:30:31 --> URI Class Initialized
INFO - 2017-12-30 02:30:31 --> Router Class Initialized
INFO - 2017-12-30 02:30:31 --> Output Class Initialized
INFO - 2017-12-30 02:30:31 --> Security Class Initialized
DEBUG - 2017-12-30 02:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:30:31 --> Input Class Initialized
INFO - 2017-12-30 02:30:31 --> Language Class Initialized
INFO - 2017-12-30 02:30:31 --> Loader Class Initialized
INFO - 2017-12-30 02:30:31 --> Helper loaded: url_helper
INFO - 2017-12-30 02:30:31 --> Helper loaded: form_helper
INFO - 2017-12-30 02:30:31 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:30:31 --> Form Validation Class Initialized
INFO - 2017-12-30 02:30:31 --> Model Class Initialized
INFO - 2017-12-30 02:30:31 --> Controller Class Initialized
INFO - 2017-12-30 02:30:31 --> Model Class Initialized
INFO - 2017-12-30 02:30:31 --> Model Class Initialized
INFO - 2017-12-30 02:30:31 --> Model Class Initialized
INFO - 2017-12-30 02:30:31 --> Model Class Initialized
DEBUG - 2017-12-30 02:30:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:30:59 --> Config Class Initialized
INFO - 2017-12-30 02:30:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:30:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:30:59 --> Utf8 Class Initialized
INFO - 2017-12-30 02:30:59 --> URI Class Initialized
INFO - 2017-12-30 02:30:59 --> Router Class Initialized
INFO - 2017-12-30 02:30:59 --> Output Class Initialized
INFO - 2017-12-30 02:30:59 --> Security Class Initialized
DEBUG - 2017-12-30 02:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:30:59 --> Input Class Initialized
INFO - 2017-12-30 02:30:59 --> Language Class Initialized
INFO - 2017-12-30 02:30:59 --> Loader Class Initialized
INFO - 2017-12-30 02:30:59 --> Helper loaded: url_helper
INFO - 2017-12-30 02:30:59 --> Helper loaded: form_helper
INFO - 2017-12-30 02:30:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:30:59 --> Form Validation Class Initialized
INFO - 2017-12-30 02:30:59 --> Model Class Initialized
INFO - 2017-12-30 02:30:59 --> Controller Class Initialized
INFO - 2017-12-30 02:30:59 --> Model Class Initialized
INFO - 2017-12-30 02:30:59 --> Model Class Initialized
INFO - 2017-12-30 02:30:59 --> Model Class Initialized
INFO - 2017-12-30 02:30:59 --> Model Class Initialized
DEBUG - 2017-12-30 02:30:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
ERROR - 2017-12-30 02:30:59 --> Severity: Notice --> Undefined index: valor D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 103
INFO - 2017-12-30 02:31:28 --> Config Class Initialized
INFO - 2017-12-30 02:31:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:31:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:31:28 --> Utf8 Class Initialized
INFO - 2017-12-30 02:31:28 --> URI Class Initialized
INFO - 2017-12-30 02:31:28 --> Router Class Initialized
INFO - 2017-12-30 02:31:28 --> Output Class Initialized
INFO - 2017-12-30 02:31:28 --> Security Class Initialized
DEBUG - 2017-12-30 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:31:28 --> Input Class Initialized
INFO - 2017-12-30 02:31:28 --> Language Class Initialized
INFO - 2017-12-30 02:31:28 --> Loader Class Initialized
INFO - 2017-12-30 02:31:28 --> Helper loaded: url_helper
INFO - 2017-12-30 02:31:28 --> Helper loaded: form_helper
INFO - 2017-12-30 02:31:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:31:28 --> Form Validation Class Initialized
INFO - 2017-12-30 02:31:28 --> Model Class Initialized
INFO - 2017-12-30 02:31:28 --> Controller Class Initialized
INFO - 2017-12-30 02:31:28 --> Model Class Initialized
INFO - 2017-12-30 02:31:28 --> Model Class Initialized
INFO - 2017-12-30 02:31:28 --> Model Class Initialized
INFO - 2017-12-30 02:31:28 --> Model Class Initialized
DEBUG - 2017-12-30 02:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:32:44 --> Config Class Initialized
INFO - 2017-12-30 02:32:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:32:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:32:44 --> Utf8 Class Initialized
INFO - 2017-12-30 02:32:44 --> URI Class Initialized
INFO - 2017-12-30 02:32:44 --> Router Class Initialized
INFO - 2017-12-30 02:32:44 --> Output Class Initialized
INFO - 2017-12-30 02:32:44 --> Security Class Initialized
DEBUG - 2017-12-30 02:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:32:44 --> Input Class Initialized
INFO - 2017-12-30 02:32:44 --> Language Class Initialized
INFO - 2017-12-30 02:32:44 --> Loader Class Initialized
INFO - 2017-12-30 02:32:44 --> Helper loaded: url_helper
INFO - 2017-12-30 02:32:44 --> Helper loaded: form_helper
INFO - 2017-12-30 02:32:44 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:32:44 --> Form Validation Class Initialized
INFO - 2017-12-30 02:32:44 --> Model Class Initialized
INFO - 2017-12-30 02:32:44 --> Controller Class Initialized
INFO - 2017-12-30 02:32:44 --> Model Class Initialized
INFO - 2017-12-30 02:32:44 --> Model Class Initialized
INFO - 2017-12-30 02:32:44 --> Model Class Initialized
INFO - 2017-12-30 02:32:44 --> Model Class Initialized
DEBUG - 2017-12-30 02:32:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:32:51 --> Config Class Initialized
INFO - 2017-12-30 02:32:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:32:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:32:51 --> Utf8 Class Initialized
INFO - 2017-12-30 02:32:51 --> URI Class Initialized
INFO - 2017-12-30 02:32:51 --> Router Class Initialized
INFO - 2017-12-30 02:32:51 --> Output Class Initialized
INFO - 2017-12-30 02:32:51 --> Security Class Initialized
DEBUG - 2017-12-30 02:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:32:51 --> Input Class Initialized
INFO - 2017-12-30 02:32:51 --> Language Class Initialized
INFO - 2017-12-30 02:32:51 --> Loader Class Initialized
INFO - 2017-12-30 02:32:51 --> Helper loaded: url_helper
INFO - 2017-12-30 02:32:51 --> Helper loaded: form_helper
INFO - 2017-12-30 02:32:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:32:51 --> Form Validation Class Initialized
INFO - 2017-12-30 02:32:51 --> Model Class Initialized
INFO - 2017-12-30 02:32:51 --> Controller Class Initialized
INFO - 2017-12-30 02:32:51 --> Model Class Initialized
INFO - 2017-12-30 02:32:51 --> Model Class Initialized
INFO - 2017-12-30 02:32:51 --> Model Class Initialized
INFO - 2017-12-30 02:32:51 --> Model Class Initialized
DEBUG - 2017-12-30 02:32:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
ERROR - 2017-12-30 02:32:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 119
INFO - 2017-12-30 02:32:51 --> Final output sent to browser
DEBUG - 2017-12-30 02:32:51 --> Total execution time: 0.1188
INFO - 2017-12-30 02:33:19 --> Config Class Initialized
INFO - 2017-12-30 02:33:19 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:33:19 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:33:19 --> Utf8 Class Initialized
INFO - 2017-12-30 02:33:19 --> URI Class Initialized
INFO - 2017-12-30 02:33:19 --> Router Class Initialized
INFO - 2017-12-30 02:33:19 --> Output Class Initialized
INFO - 2017-12-30 02:33:19 --> Security Class Initialized
DEBUG - 2017-12-30 02:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:33:19 --> Input Class Initialized
INFO - 2017-12-30 02:33:19 --> Language Class Initialized
INFO - 2017-12-30 02:33:19 --> Loader Class Initialized
INFO - 2017-12-30 02:33:19 --> Helper loaded: url_helper
INFO - 2017-12-30 02:33:19 --> Helper loaded: form_helper
INFO - 2017-12-30 02:33:19 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:33:19 --> Form Validation Class Initialized
INFO - 2017-12-30 02:33:19 --> Model Class Initialized
INFO - 2017-12-30 02:33:19 --> Controller Class Initialized
INFO - 2017-12-30 02:33:19 --> Model Class Initialized
INFO - 2017-12-30 02:33:19 --> Model Class Initialized
INFO - 2017-12-30 02:33:19 --> Model Class Initialized
INFO - 2017-12-30 02:33:19 --> Model Class Initialized
DEBUG - 2017-12-30 02:33:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:33:20 --> Final output sent to browser
DEBUG - 2017-12-30 02:33:20 --> Total execution time: 0.2131
INFO - 2017-12-30 02:34:21 --> Config Class Initialized
INFO - 2017-12-30 02:34:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 02:34:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 02:34:21 --> Utf8 Class Initialized
INFO - 2017-12-30 02:34:21 --> URI Class Initialized
INFO - 2017-12-30 02:34:21 --> Router Class Initialized
INFO - 2017-12-30 02:34:21 --> Output Class Initialized
INFO - 2017-12-30 02:34:21 --> Security Class Initialized
DEBUG - 2017-12-30 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 02:34:21 --> Input Class Initialized
INFO - 2017-12-30 02:34:21 --> Language Class Initialized
INFO - 2017-12-30 02:34:21 --> Loader Class Initialized
INFO - 2017-12-30 02:34:21 --> Helper loaded: url_helper
INFO - 2017-12-30 02:34:21 --> Helper loaded: form_helper
INFO - 2017-12-30 02:34:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 02:34:21 --> Form Validation Class Initialized
INFO - 2017-12-30 02:34:21 --> Model Class Initialized
INFO - 2017-12-30 02:34:21 --> Controller Class Initialized
INFO - 2017-12-30 02:34:21 --> Model Class Initialized
INFO - 2017-12-30 02:34:21 --> Model Class Initialized
INFO - 2017-12-30 02:34:21 --> Model Class Initialized
INFO - 2017-12-30 02:34:21 --> Model Class Initialized
DEBUG - 2017-12-30 02:34:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 02:34:21 --> Final output sent to browser
DEBUG - 2017-12-30 02:34:21 --> Total execution time: 0.2194
INFO - 2017-12-30 03:05:39 --> Config Class Initialized
INFO - 2017-12-30 03:05:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:05:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:05:39 --> Utf8 Class Initialized
INFO - 2017-12-30 03:05:39 --> URI Class Initialized
INFO - 2017-12-30 03:05:39 --> Router Class Initialized
INFO - 2017-12-30 03:05:39 --> Output Class Initialized
INFO - 2017-12-30 03:05:39 --> Security Class Initialized
DEBUG - 2017-12-30 03:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:05:39 --> Input Class Initialized
INFO - 2017-12-30 03:05:39 --> Language Class Initialized
INFO - 2017-12-30 03:05:39 --> Loader Class Initialized
INFO - 2017-12-30 03:05:39 --> Helper loaded: url_helper
INFO - 2017-12-30 03:05:39 --> Helper loaded: form_helper
INFO - 2017-12-30 03:05:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:05:39 --> Form Validation Class Initialized
INFO - 2017-12-30 03:05:39 --> Model Class Initialized
INFO - 2017-12-30 03:05:39 --> Controller Class Initialized
INFO - 2017-12-30 03:05:39 --> Model Class Initialized
INFO - 2017-12-30 03:05:39 --> Model Class Initialized
INFO - 2017-12-30 03:05:39 --> Model Class Initialized
INFO - 2017-12-30 03:05:39 --> Model Class Initialized
DEBUG - 2017-12-30 03:05:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:05:39 --> Final output sent to browser
DEBUG - 2017-12-30 03:05:39 --> Total execution time: 0.2811
INFO - 2017-12-30 03:08:19 --> Config Class Initialized
INFO - 2017-12-30 03:08:19 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:08:19 --> Utf8 Class Initialized
INFO - 2017-12-30 03:08:19 --> URI Class Initialized
INFO - 2017-12-30 03:08:19 --> Router Class Initialized
INFO - 2017-12-30 03:08:19 --> Output Class Initialized
INFO - 2017-12-30 03:08:19 --> Security Class Initialized
DEBUG - 2017-12-30 03:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:08:19 --> Input Class Initialized
INFO - 2017-12-30 03:08:19 --> Language Class Initialized
INFO - 2017-12-30 03:08:19 --> Loader Class Initialized
INFO - 2017-12-30 03:08:19 --> Helper loaded: url_helper
INFO - 2017-12-30 03:08:19 --> Helper loaded: form_helper
INFO - 2017-12-30 03:08:19 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:08:19 --> Form Validation Class Initialized
INFO - 2017-12-30 03:08:19 --> Model Class Initialized
INFO - 2017-12-30 03:08:19 --> Controller Class Initialized
INFO - 2017-12-30 03:08:19 --> Model Class Initialized
INFO - 2017-12-30 03:08:19 --> Model Class Initialized
INFO - 2017-12-30 03:08:19 --> Model Class Initialized
INFO - 2017-12-30 03:08:19 --> Model Class Initialized
DEBUG - 2017-12-30 03:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:08:19 --> Final output sent to browser
DEBUG - 2017-12-30 03:08:19 --> Total execution time: 0.1708
INFO - 2017-12-30 03:08:49 --> Config Class Initialized
INFO - 2017-12-30 03:08:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:08:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:08:49 --> Utf8 Class Initialized
INFO - 2017-12-30 03:08:49 --> URI Class Initialized
INFO - 2017-12-30 03:08:49 --> Router Class Initialized
INFO - 2017-12-30 03:08:49 --> Output Class Initialized
INFO - 2017-12-30 03:08:49 --> Security Class Initialized
DEBUG - 2017-12-30 03:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:08:49 --> Input Class Initialized
INFO - 2017-12-30 03:08:49 --> Language Class Initialized
INFO - 2017-12-30 03:08:49 --> Loader Class Initialized
INFO - 2017-12-30 03:08:49 --> Helper loaded: url_helper
INFO - 2017-12-30 03:08:49 --> Helper loaded: form_helper
INFO - 2017-12-30 03:08:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:08:49 --> Form Validation Class Initialized
INFO - 2017-12-30 03:08:49 --> Model Class Initialized
INFO - 2017-12-30 03:08:49 --> Controller Class Initialized
INFO - 2017-12-30 03:08:49 --> Model Class Initialized
INFO - 2017-12-30 03:08:49 --> Model Class Initialized
INFO - 2017-12-30 03:08:49 --> Model Class Initialized
INFO - 2017-12-30 03:08:49 --> Model Class Initialized
DEBUG - 2017-12-30 03:08:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:08:49 --> Final output sent to browser
DEBUG - 2017-12-30 03:08:49 --> Total execution time: 0.1651
INFO - 2017-12-30 03:09:44 --> Config Class Initialized
INFO - 2017-12-30 03:09:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:09:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:09:44 --> Utf8 Class Initialized
INFO - 2017-12-30 03:09:44 --> URI Class Initialized
INFO - 2017-12-30 03:09:44 --> Router Class Initialized
INFO - 2017-12-30 03:09:44 --> Output Class Initialized
INFO - 2017-12-30 03:09:44 --> Security Class Initialized
DEBUG - 2017-12-30 03:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:09:44 --> Input Class Initialized
INFO - 2017-12-30 03:09:44 --> Language Class Initialized
INFO - 2017-12-30 03:09:44 --> Loader Class Initialized
INFO - 2017-12-30 03:09:45 --> Helper loaded: url_helper
INFO - 2017-12-30 03:09:45 --> Helper loaded: form_helper
INFO - 2017-12-30 03:09:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:09:45 --> Form Validation Class Initialized
INFO - 2017-12-30 03:09:45 --> Model Class Initialized
INFO - 2017-12-30 03:09:45 --> Controller Class Initialized
INFO - 2017-12-30 03:09:45 --> Model Class Initialized
INFO - 2017-12-30 03:09:45 --> Model Class Initialized
INFO - 2017-12-30 03:09:45 --> Model Class Initialized
INFO - 2017-12-30 03:09:45 --> Model Class Initialized
DEBUG - 2017-12-30 03:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:09:45 --> Final output sent to browser
DEBUG - 2017-12-30 03:09:45 --> Total execution time: 0.1366
INFO - 2017-12-30 03:55:26 --> Config Class Initialized
INFO - 2017-12-30 03:55:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:55:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:55:26 --> Utf8 Class Initialized
INFO - 2017-12-30 03:55:26 --> URI Class Initialized
INFO - 2017-12-30 03:55:26 --> Router Class Initialized
INFO - 2017-12-30 03:55:26 --> Output Class Initialized
INFO - 2017-12-30 03:55:26 --> Security Class Initialized
DEBUG - 2017-12-30 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:55:26 --> Input Class Initialized
INFO - 2017-12-30 03:55:26 --> Language Class Initialized
INFO - 2017-12-30 03:55:26 --> Loader Class Initialized
INFO - 2017-12-30 03:55:26 --> Helper loaded: url_helper
INFO - 2017-12-30 03:55:26 --> Helper loaded: form_helper
INFO - 2017-12-30 03:55:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:55:26 --> Form Validation Class Initialized
INFO - 2017-12-30 03:55:26 --> Model Class Initialized
INFO - 2017-12-30 03:55:26 --> Controller Class Initialized
INFO - 2017-12-30 03:55:26 --> Model Class Initialized
INFO - 2017-12-30 03:55:26 --> Model Class Initialized
INFO - 2017-12-30 03:55:26 --> Model Class Initialized
INFO - 2017-12-30 03:55:26 --> Model Class Initialized
DEBUG - 2017-12-30 03:55:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:55:26 --> Final output sent to browser
DEBUG - 2017-12-30 03:55:26 --> Total execution time: 0.2065
INFO - 2017-12-30 03:55:54 --> Config Class Initialized
INFO - 2017-12-30 03:55:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:55:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:55:54 --> Utf8 Class Initialized
INFO - 2017-12-30 03:55:54 --> URI Class Initialized
INFO - 2017-12-30 03:55:54 --> Router Class Initialized
INFO - 2017-12-30 03:55:54 --> Output Class Initialized
INFO - 2017-12-30 03:55:54 --> Security Class Initialized
DEBUG - 2017-12-30 03:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:55:54 --> Input Class Initialized
INFO - 2017-12-30 03:55:54 --> Language Class Initialized
INFO - 2017-12-30 03:55:54 --> Loader Class Initialized
INFO - 2017-12-30 03:55:54 --> Helper loaded: url_helper
INFO - 2017-12-30 03:55:54 --> Helper loaded: form_helper
INFO - 2017-12-30 03:55:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:55:54 --> Form Validation Class Initialized
INFO - 2017-12-30 03:55:54 --> Model Class Initialized
INFO - 2017-12-30 03:55:54 --> Controller Class Initialized
INFO - 2017-12-30 03:55:54 --> Model Class Initialized
INFO - 2017-12-30 03:55:54 --> Model Class Initialized
INFO - 2017-12-30 03:55:54 --> Model Class Initialized
INFO - 2017-12-30 03:55:54 --> Model Class Initialized
DEBUG - 2017-12-30 03:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:55:54 --> Final output sent to browser
DEBUG - 2017-12-30 03:55:54 --> Total execution time: 0.1354
INFO - 2017-12-30 03:56:20 --> Config Class Initialized
INFO - 2017-12-30 03:56:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 03:56:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 03:56:20 --> Utf8 Class Initialized
INFO - 2017-12-30 03:56:20 --> URI Class Initialized
INFO - 2017-12-30 03:56:20 --> Router Class Initialized
INFO - 2017-12-30 03:56:20 --> Output Class Initialized
INFO - 2017-12-30 03:56:20 --> Security Class Initialized
DEBUG - 2017-12-30 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 03:56:20 --> Input Class Initialized
INFO - 2017-12-30 03:56:20 --> Language Class Initialized
INFO - 2017-12-30 03:56:20 --> Loader Class Initialized
INFO - 2017-12-30 03:56:20 --> Helper loaded: url_helper
INFO - 2017-12-30 03:56:20 --> Helper loaded: form_helper
INFO - 2017-12-30 03:56:20 --> Database Driver Class Initialized
DEBUG - 2017-12-30 03:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 03:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 03:56:20 --> Form Validation Class Initialized
INFO - 2017-12-30 03:56:20 --> Model Class Initialized
INFO - 2017-12-30 03:56:20 --> Controller Class Initialized
INFO - 2017-12-30 03:56:20 --> Model Class Initialized
INFO - 2017-12-30 03:56:20 --> Model Class Initialized
INFO - 2017-12-30 03:56:20 --> Model Class Initialized
INFO - 2017-12-30 03:56:20 --> Model Class Initialized
DEBUG - 2017-12-30 03:56:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 03:56:21 --> Final output sent to browser
DEBUG - 2017-12-30 03:56:21 --> Total execution time: 0.3236
INFO - 2017-12-30 04:00:48 --> Config Class Initialized
INFO - 2017-12-30 04:00:48 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:00:48 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:00:48 --> Utf8 Class Initialized
INFO - 2017-12-30 04:00:48 --> URI Class Initialized
INFO - 2017-12-30 04:00:48 --> Router Class Initialized
INFO - 2017-12-30 04:00:48 --> Output Class Initialized
INFO - 2017-12-30 04:00:48 --> Security Class Initialized
DEBUG - 2017-12-30 04:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:00:48 --> Input Class Initialized
INFO - 2017-12-30 04:00:48 --> Language Class Initialized
INFO - 2017-12-30 04:00:48 --> Loader Class Initialized
INFO - 2017-12-30 04:00:48 --> Helper loaded: url_helper
INFO - 2017-12-30 04:00:48 --> Helper loaded: form_helper
INFO - 2017-12-30 04:00:48 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:00:48 --> Form Validation Class Initialized
INFO - 2017-12-30 04:00:48 --> Model Class Initialized
INFO - 2017-12-30 04:00:48 --> Controller Class Initialized
INFO - 2017-12-30 04:00:48 --> Model Class Initialized
INFO - 2017-12-30 04:00:48 --> Model Class Initialized
INFO - 2017-12-30 04:00:48 --> Model Class Initialized
INFO - 2017-12-30 04:00:48 --> Model Class Initialized
DEBUG - 2017-12-30 04:00:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:00:48 --> Final output sent to browser
DEBUG - 2017-12-30 04:00:48 --> Total execution time: 0.1435
INFO - 2017-12-30 04:01:23 --> Config Class Initialized
INFO - 2017-12-30 04:01:23 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:01:23 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:01:23 --> Utf8 Class Initialized
INFO - 2017-12-30 04:01:23 --> URI Class Initialized
INFO - 2017-12-30 04:01:23 --> Router Class Initialized
INFO - 2017-12-30 04:01:23 --> Output Class Initialized
INFO - 2017-12-30 04:01:23 --> Security Class Initialized
DEBUG - 2017-12-30 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:01:23 --> Input Class Initialized
INFO - 2017-12-30 04:01:23 --> Language Class Initialized
INFO - 2017-12-30 04:01:23 --> Loader Class Initialized
INFO - 2017-12-30 04:01:23 --> Helper loaded: url_helper
INFO - 2017-12-30 04:01:23 --> Helper loaded: form_helper
INFO - 2017-12-30 04:01:23 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:01:23 --> Form Validation Class Initialized
INFO - 2017-12-30 04:01:23 --> Model Class Initialized
INFO - 2017-12-30 04:01:23 --> Controller Class Initialized
INFO - 2017-12-30 04:01:23 --> Model Class Initialized
INFO - 2017-12-30 04:01:23 --> Model Class Initialized
INFO - 2017-12-30 04:01:23 --> Model Class Initialized
INFO - 2017-12-30 04:01:23 --> Model Class Initialized
DEBUG - 2017-12-30 04:01:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:01:23 --> Final output sent to browser
DEBUG - 2017-12-30 04:01:23 --> Total execution time: 0.1731
INFO - 2017-12-30 04:03:20 --> Config Class Initialized
INFO - 2017-12-30 04:03:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:03:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:03:20 --> Utf8 Class Initialized
INFO - 2017-12-30 04:03:20 --> URI Class Initialized
INFO - 2017-12-30 04:03:20 --> Router Class Initialized
INFO - 2017-12-30 04:03:20 --> Output Class Initialized
INFO - 2017-12-30 04:03:20 --> Security Class Initialized
DEBUG - 2017-12-30 04:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:03:20 --> Input Class Initialized
INFO - 2017-12-30 04:03:20 --> Language Class Initialized
INFO - 2017-12-30 04:03:20 --> Loader Class Initialized
INFO - 2017-12-30 04:03:20 --> Helper loaded: url_helper
INFO - 2017-12-30 04:03:20 --> Helper loaded: form_helper
INFO - 2017-12-30 04:03:20 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:03:20 --> Form Validation Class Initialized
INFO - 2017-12-30 04:03:20 --> Model Class Initialized
INFO - 2017-12-30 04:03:20 --> Controller Class Initialized
INFO - 2017-12-30 04:03:20 --> Model Class Initialized
INFO - 2017-12-30 04:03:20 --> Model Class Initialized
INFO - 2017-12-30 04:03:20 --> Model Class Initialized
INFO - 2017-12-30 04:03:20 --> Model Class Initialized
DEBUG - 2017-12-30 04:03:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:03:20 --> Final output sent to browser
DEBUG - 2017-12-30 04:03:20 --> Total execution time: 0.1850
INFO - 2017-12-30 04:04:30 --> Config Class Initialized
INFO - 2017-12-30 04:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 04:04:30 --> URI Class Initialized
INFO - 2017-12-30 04:04:30 --> Router Class Initialized
INFO - 2017-12-30 04:04:30 --> Output Class Initialized
INFO - 2017-12-30 04:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 04:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:04:30 --> Input Class Initialized
INFO - 2017-12-30 04:04:30 --> Language Class Initialized
INFO - 2017-12-30 04:04:30 --> Loader Class Initialized
INFO - 2017-12-30 04:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 04:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 04:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 04:04:30 --> Model Class Initialized
INFO - 2017-12-30 04:04:30 --> Controller Class Initialized
INFO - 2017-12-30 04:04:30 --> Model Class Initialized
INFO - 2017-12-30 04:04:30 --> Model Class Initialized
INFO - 2017-12-30 04:04:30 --> Model Class Initialized
INFO - 2017-12-30 04:04:30 --> Model Class Initialized
DEBUG - 2017-12-30 04:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:04:30 --> Final output sent to browser
DEBUG - 2017-12-30 04:04:30 --> Total execution time: 0.2232
INFO - 2017-12-30 04:05:22 --> Config Class Initialized
INFO - 2017-12-30 04:05:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:05:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:05:22 --> Utf8 Class Initialized
INFO - 2017-12-30 04:05:22 --> URI Class Initialized
INFO - 2017-12-30 04:05:22 --> Router Class Initialized
INFO - 2017-12-30 04:05:22 --> Output Class Initialized
INFO - 2017-12-30 04:05:22 --> Security Class Initialized
DEBUG - 2017-12-30 04:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:05:22 --> Input Class Initialized
INFO - 2017-12-30 04:05:22 --> Language Class Initialized
INFO - 2017-12-30 04:05:22 --> Loader Class Initialized
INFO - 2017-12-30 04:05:22 --> Helper loaded: url_helper
INFO - 2017-12-30 04:05:22 --> Helper loaded: form_helper
INFO - 2017-12-30 04:05:22 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:05:22 --> Form Validation Class Initialized
INFO - 2017-12-30 04:05:22 --> Model Class Initialized
INFO - 2017-12-30 04:05:22 --> Controller Class Initialized
INFO - 2017-12-30 04:05:22 --> Model Class Initialized
INFO - 2017-12-30 04:05:22 --> Model Class Initialized
INFO - 2017-12-30 04:05:22 --> Model Class Initialized
INFO - 2017-12-30 04:05:22 --> Model Class Initialized
DEBUG - 2017-12-30 04:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:05:22 --> Final output sent to browser
DEBUG - 2017-12-30 04:05:22 --> Total execution time: 0.1989
INFO - 2017-12-30 04:05:57 --> Config Class Initialized
INFO - 2017-12-30 04:05:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:05:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:05:57 --> Utf8 Class Initialized
INFO - 2017-12-30 04:05:57 --> URI Class Initialized
INFO - 2017-12-30 04:05:57 --> Router Class Initialized
INFO - 2017-12-30 04:05:57 --> Output Class Initialized
INFO - 2017-12-30 04:05:57 --> Security Class Initialized
DEBUG - 2017-12-30 04:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:05:57 --> Input Class Initialized
INFO - 2017-12-30 04:05:57 --> Language Class Initialized
INFO - 2017-12-30 04:05:57 --> Loader Class Initialized
INFO - 2017-12-30 04:05:57 --> Helper loaded: url_helper
INFO - 2017-12-30 04:05:57 --> Helper loaded: form_helper
INFO - 2017-12-30 04:05:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:05:57 --> Form Validation Class Initialized
INFO - 2017-12-30 04:05:57 --> Model Class Initialized
INFO - 2017-12-30 04:05:57 --> Controller Class Initialized
INFO - 2017-12-30 04:05:57 --> Model Class Initialized
INFO - 2017-12-30 04:05:57 --> Model Class Initialized
INFO - 2017-12-30 04:05:57 --> Model Class Initialized
INFO - 2017-12-30 04:05:57 --> Model Class Initialized
DEBUG - 2017-12-30 04:05:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:05:57 --> Final output sent to browser
DEBUG - 2017-12-30 04:05:57 --> Total execution time: 0.1907
INFO - 2017-12-30 04:06:12 --> Config Class Initialized
INFO - 2017-12-30 04:06:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:12 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:12 --> URI Class Initialized
INFO - 2017-12-30 04:06:12 --> Router Class Initialized
INFO - 2017-12-30 04:06:12 --> Output Class Initialized
INFO - 2017-12-30 04:06:12 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:12 --> Input Class Initialized
INFO - 2017-12-30 04:06:12 --> Language Class Initialized
INFO - 2017-12-30 04:06:12 --> Loader Class Initialized
INFO - 2017-12-30 04:06:12 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:12 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:12 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Controller Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:12 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:12 --> Total execution time: 0.0732
INFO - 2017-12-30 04:06:12 --> Config Class Initialized
INFO - 2017-12-30 04:06:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:12 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:12 --> URI Class Initialized
INFO - 2017-12-30 04:06:12 --> Router Class Initialized
INFO - 2017-12-30 04:06:12 --> Output Class Initialized
INFO - 2017-12-30 04:06:12 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:12 --> Input Class Initialized
INFO - 2017-12-30 04:06:12 --> Language Class Initialized
INFO - 2017-12-30 04:06:12 --> Loader Class Initialized
INFO - 2017-12-30 04:06:12 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:12 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:12 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Controller Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
INFO - 2017-12-30 04:06:12 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:15 --> Config Class Initialized
INFO - 2017-12-30 04:06:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:15 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:15 --> URI Class Initialized
INFO - 2017-12-30 04:06:15 --> Router Class Initialized
INFO - 2017-12-30 04:06:15 --> Output Class Initialized
INFO - 2017-12-30 04:06:15 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:15 --> Input Class Initialized
INFO - 2017-12-30 04:06:15 --> Language Class Initialized
INFO - 2017-12-30 04:06:15 --> Loader Class Initialized
INFO - 2017-12-30 04:06:15 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:15 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:15 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Controller Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:06:15 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 154
ERROR - 2017-12-30 04:06:15 --> Severity: Notice --> Undefined variable: dias_consumidos D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:06:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:15 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:15 --> Total execution time: 0.0675
INFO - 2017-12-30 04:06:15 --> Config Class Initialized
INFO - 2017-12-30 04:06:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:15 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:15 --> URI Class Initialized
INFO - 2017-12-30 04:06:15 --> Router Class Initialized
INFO - 2017-12-30 04:06:15 --> Output Class Initialized
INFO - 2017-12-30 04:06:15 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:15 --> Input Class Initialized
INFO - 2017-12-30 04:06:15 --> Language Class Initialized
INFO - 2017-12-30 04:06:15 --> Loader Class Initialized
INFO - 2017-12-30 04:06:15 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:15 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:15 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Controller Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
INFO - 2017-12-30 04:06:15 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:17 --> Config Class Initialized
INFO - 2017-12-30 04:06:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:17 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:17 --> URI Class Initialized
INFO - 2017-12-30 04:06:17 --> Router Class Initialized
INFO - 2017-12-30 04:06:17 --> Output Class Initialized
INFO - 2017-12-30 04:06:17 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:17 --> Input Class Initialized
INFO - 2017-12-30 04:06:17 --> Language Class Initialized
INFO - 2017-12-30 04:06:17 --> Loader Class Initialized
INFO - 2017-12-30 04:06:17 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:17 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:17 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Controller Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:06:17 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 154
ERROR - 2017-12-30 04:06:17 --> Severity: Notice --> Undefined variable: dias_consumidos D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:06:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:17 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:17 --> Total execution time: 0.0774
INFO - 2017-12-30 04:06:17 --> Config Class Initialized
INFO - 2017-12-30 04:06:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:17 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:17 --> URI Class Initialized
INFO - 2017-12-30 04:06:17 --> Router Class Initialized
INFO - 2017-12-30 04:06:17 --> Output Class Initialized
INFO - 2017-12-30 04:06:17 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:17 --> Input Class Initialized
INFO - 2017-12-30 04:06:17 --> Language Class Initialized
INFO - 2017-12-30 04:06:17 --> Loader Class Initialized
INFO - 2017-12-30 04:06:17 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:17 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:17 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Controller Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
INFO - 2017-12-30 04:06:17 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:49 --> Config Class Initialized
INFO - 2017-12-30 04:06:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:49 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:49 --> URI Class Initialized
INFO - 2017-12-30 04:06:49 --> Router Class Initialized
INFO - 2017-12-30 04:06:49 --> Output Class Initialized
INFO - 2017-12-30 04:06:49 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:49 --> Input Class Initialized
INFO - 2017-12-30 04:06:49 --> Language Class Initialized
INFO - 2017-12-30 04:06:49 --> Loader Class Initialized
INFO - 2017-12-30 04:06:49 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:49 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:49 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:49 --> Model Class Initialized
INFO - 2017-12-30 04:06:49 --> Controller Class Initialized
INFO - 2017-12-30 04:06:49 --> Model Class Initialized
INFO - 2017-12-30 04:06:49 --> Model Class Initialized
INFO - 2017-12-30 04:06:49 --> Model Class Initialized
INFO - 2017-12-30 04:06:49 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:49 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:49 --> Total execution time: 0.0951
INFO - 2017-12-30 04:06:50 --> Config Class Initialized
INFO - 2017-12-30 04:06:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:50 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:50 --> URI Class Initialized
INFO - 2017-12-30 04:06:50 --> Router Class Initialized
INFO - 2017-12-30 04:06:50 --> Output Class Initialized
INFO - 2017-12-30 04:06:50 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:50 --> Input Class Initialized
INFO - 2017-12-30 04:06:50 --> Language Class Initialized
INFO - 2017-12-30 04:06:50 --> Loader Class Initialized
INFO - 2017-12-30 04:06:50 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:50 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:50 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:50 --> Model Class Initialized
INFO - 2017-12-30 04:06:50 --> Controller Class Initialized
INFO - 2017-12-30 04:06:50 --> Model Class Initialized
INFO - 2017-12-30 04:06:50 --> Model Class Initialized
INFO - 2017-12-30 04:06:50 --> Model Class Initialized
INFO - 2017-12-30 04:06:50 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:51 --> Config Class Initialized
INFO - 2017-12-30 04:06:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:51 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:51 --> URI Class Initialized
INFO - 2017-12-30 04:06:51 --> Router Class Initialized
INFO - 2017-12-30 04:06:51 --> Output Class Initialized
INFO - 2017-12-30 04:06:51 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:51 --> Input Class Initialized
INFO - 2017-12-30 04:06:51 --> Language Class Initialized
INFO - 2017-12-30 04:06:51 --> Loader Class Initialized
INFO - 2017-12-30 04:06:51 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:51 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:51 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:51 --> Model Class Initialized
INFO - 2017-12-30 04:06:51 --> Controller Class Initialized
INFO - 2017-12-30 04:06:51 --> Model Class Initialized
INFO - 2017-12-30 04:06:51 --> Model Class Initialized
INFO - 2017-12-30 04:06:51 --> Model Class Initialized
INFO - 2017-12-30 04:06:51 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:51 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:51 --> Total execution time: 0.0724
INFO - 2017-12-30 04:06:52 --> Config Class Initialized
INFO - 2017-12-30 04:06:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:52 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:52 --> URI Class Initialized
INFO - 2017-12-30 04:06:52 --> Router Class Initialized
INFO - 2017-12-30 04:06:52 --> Output Class Initialized
INFO - 2017-12-30 04:06:52 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:52 --> Input Class Initialized
INFO - 2017-12-30 04:06:52 --> Language Class Initialized
INFO - 2017-12-30 04:06:52 --> Loader Class Initialized
INFO - 2017-12-30 04:06:52 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:52 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:52 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:52 --> Model Class Initialized
INFO - 2017-12-30 04:06:52 --> Controller Class Initialized
INFO - 2017-12-30 04:06:52 --> Model Class Initialized
INFO - 2017-12-30 04:06:52 --> Model Class Initialized
INFO - 2017-12-30 04:06:52 --> Model Class Initialized
INFO - 2017-12-30 04:06:52 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:54 --> Config Class Initialized
INFO - 2017-12-30 04:06:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:54 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:54 --> URI Class Initialized
INFO - 2017-12-30 04:06:54 --> Router Class Initialized
INFO - 2017-12-30 04:06:54 --> Output Class Initialized
INFO - 2017-12-30 04:06:54 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:54 --> Input Class Initialized
INFO - 2017-12-30 04:06:54 --> Language Class Initialized
INFO - 2017-12-30 04:06:54 --> Loader Class Initialized
INFO - 2017-12-30 04:06:54 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:54 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:54 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Controller Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:54 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:54 --> Total execution time: 0.0666
INFO - 2017-12-30 04:06:54 --> Config Class Initialized
INFO - 2017-12-30 04:06:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:54 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:54 --> URI Class Initialized
INFO - 2017-12-30 04:06:54 --> Router Class Initialized
INFO - 2017-12-30 04:06:54 --> Output Class Initialized
INFO - 2017-12-30 04:06:54 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:54 --> Input Class Initialized
INFO - 2017-12-30 04:06:54 --> Language Class Initialized
INFO - 2017-12-30 04:06:54 --> Loader Class Initialized
INFO - 2017-12-30 04:06:54 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:54 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:54 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Controller Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
INFO - 2017-12-30 04:06:54 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:55 --> Config Class Initialized
INFO - 2017-12-30 04:06:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:55 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:55 --> URI Class Initialized
INFO - 2017-12-30 04:06:55 --> Router Class Initialized
INFO - 2017-12-30 04:06:55 --> Output Class Initialized
INFO - 2017-12-30 04:06:55 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:55 --> Input Class Initialized
INFO - 2017-12-30 04:06:55 --> Language Class Initialized
INFO - 2017-12-30 04:06:55 --> Loader Class Initialized
INFO - 2017-12-30 04:06:55 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:55 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:55 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:55 --> Model Class Initialized
INFO - 2017-12-30 04:06:55 --> Controller Class Initialized
INFO - 2017-12-30 04:06:55 --> Model Class Initialized
INFO - 2017-12-30 04:06:55 --> Model Class Initialized
INFO - 2017-12-30 04:06:55 --> Model Class Initialized
INFO - 2017-12-30 04:06:55 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:55 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:55 --> Total execution time: 0.0594
INFO - 2017-12-30 04:06:56 --> Config Class Initialized
INFO - 2017-12-30 04:06:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:56 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:56 --> URI Class Initialized
INFO - 2017-12-30 04:06:56 --> Router Class Initialized
INFO - 2017-12-30 04:06:56 --> Output Class Initialized
INFO - 2017-12-30 04:06:56 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:56 --> Input Class Initialized
INFO - 2017-12-30 04:06:56 --> Language Class Initialized
INFO - 2017-12-30 04:06:56 --> Loader Class Initialized
INFO - 2017-12-30 04:06:56 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:56 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:56 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:56 --> Model Class Initialized
INFO - 2017-12-30 04:06:56 --> Controller Class Initialized
INFO - 2017-12-30 04:06:56 --> Model Class Initialized
INFO - 2017-12-30 04:06:56 --> Model Class Initialized
INFO - 2017-12-30 04:06:56 --> Model Class Initialized
INFO - 2017-12-30 04:06:56 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:58 --> Config Class Initialized
INFO - 2017-12-30 04:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:58 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:58 --> URI Class Initialized
INFO - 2017-12-30 04:06:58 --> Router Class Initialized
INFO - 2017-12-30 04:06:58 --> Output Class Initialized
INFO - 2017-12-30 04:06:58 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:58 --> Input Class Initialized
INFO - 2017-12-30 04:06:58 --> Language Class Initialized
INFO - 2017-12-30 04:06:58 --> Loader Class Initialized
INFO - 2017-12-30 04:06:58 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:58 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:58 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Controller Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:06:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:06:58 --> Final output sent to browser
DEBUG - 2017-12-30 04:06:58 --> Total execution time: 0.0532
INFO - 2017-12-30 04:06:58 --> Config Class Initialized
INFO - 2017-12-30 04:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:06:58 --> Utf8 Class Initialized
INFO - 2017-12-30 04:06:58 --> URI Class Initialized
INFO - 2017-12-30 04:06:58 --> Router Class Initialized
INFO - 2017-12-30 04:06:58 --> Output Class Initialized
INFO - 2017-12-30 04:06:58 --> Security Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:06:58 --> Input Class Initialized
INFO - 2017-12-30 04:06:58 --> Language Class Initialized
INFO - 2017-12-30 04:06:58 --> Loader Class Initialized
INFO - 2017-12-30 04:06:58 --> Helper loaded: url_helper
INFO - 2017-12-30 04:06:58 --> Helper loaded: form_helper
INFO - 2017-12-30 04:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:06:58 --> Form Validation Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Controller Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
INFO - 2017-12-30 04:06:58 --> Model Class Initialized
DEBUG - 2017-12-30 04:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:00 --> Config Class Initialized
INFO - 2017-12-30 04:07:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:00 --> URI Class Initialized
INFO - 2017-12-30 04:07:00 --> Router Class Initialized
INFO - 2017-12-30 04:07:00 --> Output Class Initialized
INFO - 2017-12-30 04:07:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:00 --> Input Class Initialized
INFO - 2017-12-30 04:07:00 --> Language Class Initialized
INFO - 2017-12-30 04:07:00 --> Loader Class Initialized
INFO - 2017-12-30 04:07:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Controller Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:00 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:00 --> Total execution time: 0.0761
INFO - 2017-12-30 04:07:00 --> Config Class Initialized
INFO - 2017-12-30 04:07:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:00 --> URI Class Initialized
INFO - 2017-12-30 04:07:00 --> Router Class Initialized
INFO - 2017-12-30 04:07:00 --> Output Class Initialized
INFO - 2017-12-30 04:07:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:00 --> Input Class Initialized
INFO - 2017-12-30 04:07:00 --> Language Class Initialized
INFO - 2017-12-30 04:07:00 --> Loader Class Initialized
INFO - 2017-12-30 04:07:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Controller Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
INFO - 2017-12-30 04:07:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:02 --> Config Class Initialized
INFO - 2017-12-30 04:07:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:02 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:02 --> URI Class Initialized
INFO - 2017-12-30 04:07:02 --> Router Class Initialized
INFO - 2017-12-30 04:07:02 --> Output Class Initialized
INFO - 2017-12-30 04:07:02 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:02 --> Input Class Initialized
INFO - 2017-12-30 04:07:02 --> Language Class Initialized
INFO - 2017-12-30 04:07:02 --> Loader Class Initialized
INFO - 2017-12-30 04:07:02 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:02 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:03 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Controller Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:03 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:03 --> Total execution time: 0.2145
INFO - 2017-12-30 04:07:03 --> Config Class Initialized
INFO - 2017-12-30 04:07:03 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:03 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:03 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:03 --> URI Class Initialized
INFO - 2017-12-30 04:07:03 --> Router Class Initialized
INFO - 2017-12-30 04:07:03 --> Output Class Initialized
INFO - 2017-12-30 04:07:03 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:03 --> Input Class Initialized
INFO - 2017-12-30 04:07:03 --> Language Class Initialized
INFO - 2017-12-30 04:07:03 --> Loader Class Initialized
INFO - 2017-12-30 04:07:03 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:03 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:03 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:03 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Controller Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
INFO - 2017-12-30 04:07:03 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:05 --> Config Class Initialized
INFO - 2017-12-30 04:07:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:05 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:05 --> URI Class Initialized
INFO - 2017-12-30 04:07:05 --> Router Class Initialized
INFO - 2017-12-30 04:07:05 --> Output Class Initialized
INFO - 2017-12-30 04:07:05 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:05 --> Input Class Initialized
INFO - 2017-12-30 04:07:05 --> Language Class Initialized
INFO - 2017-12-30 04:07:05 --> Loader Class Initialized
INFO - 2017-12-30 04:07:05 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:05 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:05 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:05 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Controller Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:07:05 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 154
ERROR - 2017-12-30 04:07:05 --> Severity: Notice --> Undefined variable: dias_consumidos D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:07:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:05 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:05 --> Total execution time: 0.0731
INFO - 2017-12-30 04:07:05 --> Config Class Initialized
INFO - 2017-12-30 04:07:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:05 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:05 --> URI Class Initialized
INFO - 2017-12-30 04:07:05 --> Router Class Initialized
INFO - 2017-12-30 04:07:05 --> Output Class Initialized
INFO - 2017-12-30 04:07:05 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:05 --> Input Class Initialized
INFO - 2017-12-30 04:07:05 --> Language Class Initialized
INFO - 2017-12-30 04:07:05 --> Loader Class Initialized
INFO - 2017-12-30 04:07:05 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:05 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:05 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:05 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Controller Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
INFO - 2017-12-30 04:07:05 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:08 --> Config Class Initialized
INFO - 2017-12-30 04:07:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:08 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:08 --> URI Class Initialized
INFO - 2017-12-30 04:07:08 --> Router Class Initialized
INFO - 2017-12-30 04:07:08 --> Output Class Initialized
INFO - 2017-12-30 04:07:08 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:08 --> Input Class Initialized
INFO - 2017-12-30 04:07:08 --> Language Class Initialized
INFO - 2017-12-30 04:07:08 --> Loader Class Initialized
INFO - 2017-12-30 04:07:08 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:08 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:08 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Controller Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:08 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:08 --> Total execution time: 0.0695
INFO - 2017-12-30 04:07:08 --> Config Class Initialized
INFO - 2017-12-30 04:07:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:08 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:08 --> URI Class Initialized
INFO - 2017-12-30 04:07:08 --> Router Class Initialized
INFO - 2017-12-30 04:07:08 --> Output Class Initialized
INFO - 2017-12-30 04:07:08 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:08 --> Input Class Initialized
INFO - 2017-12-30 04:07:08 --> Language Class Initialized
INFO - 2017-12-30 04:07:08 --> Loader Class Initialized
INFO - 2017-12-30 04:07:08 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:08 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:08 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Controller Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
INFO - 2017-12-30 04:07:08 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:39 --> Config Class Initialized
INFO - 2017-12-30 04:07:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:39 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:39 --> URI Class Initialized
INFO - 2017-12-30 04:07:39 --> Router Class Initialized
INFO - 2017-12-30 04:07:39 --> Output Class Initialized
INFO - 2017-12-30 04:07:39 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:39 --> Input Class Initialized
INFO - 2017-12-30 04:07:39 --> Language Class Initialized
INFO - 2017-12-30 04:07:39 --> Loader Class Initialized
INFO - 2017-12-30 04:07:39 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:39 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:39 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Controller Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:07:39 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:07:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:39 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:39 --> Total execution time: 0.0616
INFO - 2017-12-30 04:07:39 --> Config Class Initialized
INFO - 2017-12-30 04:07:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:39 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:39 --> URI Class Initialized
INFO - 2017-12-30 04:07:39 --> Router Class Initialized
INFO - 2017-12-30 04:07:39 --> Output Class Initialized
INFO - 2017-12-30 04:07:39 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:39 --> Input Class Initialized
INFO - 2017-12-30 04:07:39 --> Language Class Initialized
INFO - 2017-12-30 04:07:39 --> Loader Class Initialized
INFO - 2017-12-30 04:07:39 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:39 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:39 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Controller Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
INFO - 2017-12-30 04:07:39 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:07:59 --> Config Class Initialized
INFO - 2017-12-30 04:07:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:59 --> URI Class Initialized
INFO - 2017-12-30 04:07:59 --> Router Class Initialized
INFO - 2017-12-30 04:07:59 --> Output Class Initialized
INFO - 2017-12-30 04:07:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:59 --> Input Class Initialized
INFO - 2017-12-30 04:07:59 --> Language Class Initialized
INFO - 2017-12-30 04:07:59 --> Loader Class Initialized
INFO - 2017-12-30 04:07:59 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:59 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:59 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Controller Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:07:59 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:07:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:07:59 --> Final output sent to browser
DEBUG - 2017-12-30 04:07:59 --> Total execution time: 0.1408
INFO - 2017-12-30 04:07:59 --> Config Class Initialized
INFO - 2017-12-30 04:07:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:07:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:07:59 --> URI Class Initialized
INFO - 2017-12-30 04:07:59 --> Router Class Initialized
INFO - 2017-12-30 04:07:59 --> Output Class Initialized
INFO - 2017-12-30 04:07:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:07:59 --> Input Class Initialized
INFO - 2017-12-30 04:07:59 --> Language Class Initialized
INFO - 2017-12-30 04:07:59 --> Loader Class Initialized
INFO - 2017-12-30 04:07:59 --> Helper loaded: url_helper
INFO - 2017-12-30 04:07:59 --> Helper loaded: form_helper
INFO - 2017-12-30 04:07:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:07:59 --> Form Validation Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Controller Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
INFO - 2017-12-30 04:07:59 --> Model Class Initialized
DEBUG - 2017-12-30 04:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:00 --> Config Class Initialized
INFO - 2017-12-30 04:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:00 --> URI Class Initialized
INFO - 2017-12-30 04:08:00 --> Router Class Initialized
INFO - 2017-12-30 04:08:00 --> Output Class Initialized
INFO - 2017-12-30 04:08:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:00 --> Input Class Initialized
INFO - 2017-12-30 04:08:00 --> Language Class Initialized
INFO - 2017-12-30 04:08:00 --> Loader Class Initialized
INFO - 2017-12-30 04:08:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:00 --> Model Class Initialized
INFO - 2017-12-30 04:08:00 --> Controller Class Initialized
INFO - 2017-12-30 04:08:00 --> Model Class Initialized
INFO - 2017-12-30 04:08:00 --> Model Class Initialized
INFO - 2017-12-30 04:08:00 --> Model Class Initialized
INFO - 2017-12-30 04:08:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:08:00 --> Severity: Notice --> Undefined variable: dias_proyecto D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 155
INFO - 2017-12-30 04:08:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:08:00 --> Final output sent to browser
DEBUG - 2017-12-30 04:08:00 --> Total execution time: 0.1596
INFO - 2017-12-30 04:08:00 --> Config Class Initialized
INFO - 2017-12-30 04:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:00 --> URI Class Initialized
INFO - 2017-12-30 04:08:00 --> Router Class Initialized
INFO - 2017-12-30 04:08:00 --> Output Class Initialized
INFO - 2017-12-30 04:08:01 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:01 --> Input Class Initialized
INFO - 2017-12-30 04:08:01 --> Language Class Initialized
INFO - 2017-12-30 04:08:01 --> Loader Class Initialized
INFO - 2017-12-30 04:08:01 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:01 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:01 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:01 --> Model Class Initialized
INFO - 2017-12-30 04:08:01 --> Controller Class Initialized
INFO - 2017-12-30 04:08:01 --> Model Class Initialized
INFO - 2017-12-30 04:08:01 --> Model Class Initialized
INFO - 2017-12-30 04:08:01 --> Model Class Initialized
INFO - 2017-12-30 04:08:01 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:09 --> Config Class Initialized
INFO - 2017-12-30 04:08:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:09 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:09 --> URI Class Initialized
INFO - 2017-12-30 04:08:09 --> Router Class Initialized
INFO - 2017-12-30 04:08:09 --> Output Class Initialized
INFO - 2017-12-30 04:08:09 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:09 --> Input Class Initialized
INFO - 2017-12-30 04:08:09 --> Language Class Initialized
INFO - 2017-12-30 04:08:09 --> Loader Class Initialized
INFO - 2017-12-30 04:08:09 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:09 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:09 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Controller Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:08:09 --> Final output sent to browser
DEBUG - 2017-12-30 04:08:09 --> Total execution time: 0.1553
INFO - 2017-12-30 04:08:09 --> Config Class Initialized
INFO - 2017-12-30 04:08:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:09 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:09 --> URI Class Initialized
INFO - 2017-12-30 04:08:09 --> Router Class Initialized
INFO - 2017-12-30 04:08:09 --> Output Class Initialized
INFO - 2017-12-30 04:08:09 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:09 --> Input Class Initialized
INFO - 2017-12-30 04:08:09 --> Language Class Initialized
INFO - 2017-12-30 04:08:09 --> Loader Class Initialized
INFO - 2017-12-30 04:08:09 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:09 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:09 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Controller Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
INFO - 2017-12-30 04:08:09 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:41 --> Config Class Initialized
INFO - 2017-12-30 04:08:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:41 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:41 --> URI Class Initialized
INFO - 2017-12-30 04:08:41 --> Router Class Initialized
INFO - 2017-12-30 04:08:41 --> Output Class Initialized
INFO - 2017-12-30 04:08:41 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:41 --> Input Class Initialized
INFO - 2017-12-30 04:08:41 --> Language Class Initialized
INFO - 2017-12-30 04:08:41 --> Loader Class Initialized
INFO - 2017-12-30 04:08:41 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:41 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:41 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:41 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:41 --> Model Class Initialized
INFO - 2017-12-30 04:08:41 --> Controller Class Initialized
INFO - 2017-12-30 04:08:41 --> Model Class Initialized
INFO - 2017-12-30 04:08:41 --> Model Class Initialized
INFO - 2017-12-30 04:08:41 --> Model Class Initialized
INFO - 2017-12-30 04:08:41 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:08:41 --> Final output sent to browser
DEBUG - 2017-12-30 04:08:41 --> Total execution time: 0.1327
INFO - 2017-12-30 04:08:42 --> Config Class Initialized
INFO - 2017-12-30 04:08:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:42 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:42 --> URI Class Initialized
INFO - 2017-12-30 04:08:42 --> Router Class Initialized
INFO - 2017-12-30 04:08:42 --> Output Class Initialized
INFO - 2017-12-30 04:08:42 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:42 --> Input Class Initialized
INFO - 2017-12-30 04:08:42 --> Language Class Initialized
INFO - 2017-12-30 04:08:42 --> Loader Class Initialized
INFO - 2017-12-30 04:08:42 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:42 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:42 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:42 --> Model Class Initialized
INFO - 2017-12-30 04:08:42 --> Controller Class Initialized
INFO - 2017-12-30 04:08:42 --> Model Class Initialized
INFO - 2017-12-30 04:08:42 --> Model Class Initialized
INFO - 2017-12-30 04:08:42 --> Model Class Initialized
INFO - 2017-12-30 04:08:42 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:46 --> Config Class Initialized
INFO - 2017-12-30 04:08:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:46 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:46 --> URI Class Initialized
INFO - 2017-12-30 04:08:46 --> Router Class Initialized
INFO - 2017-12-30 04:08:46 --> Output Class Initialized
INFO - 2017-12-30 04:08:46 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:46 --> Input Class Initialized
INFO - 2017-12-30 04:08:46 --> Language Class Initialized
INFO - 2017-12-30 04:08:46 --> Loader Class Initialized
INFO - 2017-12-30 04:08:46 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:46 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:46 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Controller Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:08:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:08:46 --> Final output sent to browser
DEBUG - 2017-12-30 04:08:46 --> Total execution time: 0.0776
INFO - 2017-12-30 04:08:46 --> Config Class Initialized
INFO - 2017-12-30 04:08:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:08:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:08:46 --> Utf8 Class Initialized
INFO - 2017-12-30 04:08:46 --> URI Class Initialized
INFO - 2017-12-30 04:08:46 --> Router Class Initialized
INFO - 2017-12-30 04:08:46 --> Output Class Initialized
INFO - 2017-12-30 04:08:46 --> Security Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:08:46 --> Input Class Initialized
INFO - 2017-12-30 04:08:46 --> Language Class Initialized
INFO - 2017-12-30 04:08:46 --> Loader Class Initialized
INFO - 2017-12-30 04:08:46 --> Helper loaded: url_helper
INFO - 2017-12-30 04:08:46 --> Helper loaded: form_helper
INFO - 2017-12-30 04:08:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:08:46 --> Form Validation Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Controller Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
INFO - 2017-12-30 04:08:46 --> Model Class Initialized
DEBUG - 2017-12-30 04:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:11:42 --> Config Class Initialized
INFO - 2017-12-30 04:11:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:11:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:11:42 --> Utf8 Class Initialized
INFO - 2017-12-30 04:11:42 --> URI Class Initialized
INFO - 2017-12-30 04:11:42 --> Router Class Initialized
INFO - 2017-12-30 04:11:42 --> Output Class Initialized
INFO - 2017-12-30 04:11:42 --> Security Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:11:42 --> Input Class Initialized
INFO - 2017-12-30 04:11:42 --> Language Class Initialized
INFO - 2017-12-30 04:11:42 --> Loader Class Initialized
INFO - 2017-12-30 04:11:42 --> Helper loaded: url_helper
INFO - 2017-12-30 04:11:42 --> Helper loaded: form_helper
INFO - 2017-12-30 04:11:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:11:42 --> Form Validation Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Controller Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:11:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:11:42 --> Final output sent to browser
DEBUG - 2017-12-30 04:11:42 --> Total execution time: 0.0772
INFO - 2017-12-30 04:11:42 --> Config Class Initialized
INFO - 2017-12-30 04:11:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:11:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:11:42 --> Utf8 Class Initialized
INFO - 2017-12-30 04:11:42 --> URI Class Initialized
INFO - 2017-12-30 04:11:42 --> Router Class Initialized
INFO - 2017-12-30 04:11:42 --> Output Class Initialized
INFO - 2017-12-30 04:11:42 --> Security Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:11:42 --> Input Class Initialized
INFO - 2017-12-30 04:11:42 --> Language Class Initialized
INFO - 2017-12-30 04:11:42 --> Loader Class Initialized
INFO - 2017-12-30 04:11:42 --> Helper loaded: url_helper
INFO - 2017-12-30 04:11:42 --> Helper loaded: form_helper
INFO - 2017-12-30 04:11:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:11:42 --> Form Validation Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Controller Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
INFO - 2017-12-30 04:11:42 --> Model Class Initialized
DEBUG - 2017-12-30 04:11:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:12:30 --> Config Class Initialized
INFO - 2017-12-30 04:12:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:12:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:12:30 --> Utf8 Class Initialized
INFO - 2017-12-30 04:12:30 --> URI Class Initialized
INFO - 2017-12-30 04:12:30 --> Router Class Initialized
INFO - 2017-12-30 04:12:30 --> Output Class Initialized
INFO - 2017-12-30 04:12:30 --> Config Class Initialized
INFO - 2017-12-30 04:12:30 --> Hooks Class Initialized
INFO - 2017-12-30 04:12:30 --> Config Class Initialized
INFO - 2017-12-30 04:12:30 --> Security Class Initialized
INFO - 2017-12-30 04:12:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:12:30 --> Utf8 Class Initialized
INFO - 2017-12-30 04:12:30 --> Input Class Initialized
INFO - 2017-12-30 04:12:30 --> URI Class Initialized
INFO - 2017-12-30 04:12:30 --> Language Class Initialized
DEBUG - 2017-12-30 04:12:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:12:30 --> Utf8 Class Initialized
ERROR - 2017-12-30 04:12:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:12:30 --> Router Class Initialized
INFO - 2017-12-30 04:12:30 --> URI Class Initialized
INFO - 2017-12-30 04:12:30 --> Output Class Initialized
INFO - 2017-12-30 04:12:30 --> Router Class Initialized
INFO - 2017-12-30 04:12:30 --> Security Class Initialized
INFO - 2017-12-30 04:12:30 --> Output Class Initialized
DEBUG - 2017-12-30 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:12:30 --> Input Class Initialized
INFO - 2017-12-30 04:12:30 --> Security Class Initialized
INFO - 2017-12-30 04:12:30 --> Language Class Initialized
DEBUG - 2017-12-30 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:12:30 --> Input Class Initialized
ERROR - 2017-12-30 04:12:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:12:30 --> Language Class Initialized
ERROR - 2017-12-30 04:12:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:14:21 --> Config Class Initialized
INFO - 2017-12-30 04:14:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:14:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:14:21 --> Utf8 Class Initialized
INFO - 2017-12-30 04:14:21 --> URI Class Initialized
INFO - 2017-12-30 04:14:21 --> Router Class Initialized
INFO - 2017-12-30 04:14:21 --> Output Class Initialized
INFO - 2017-12-30 04:14:21 --> Security Class Initialized
DEBUG - 2017-12-30 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:14:21 --> Input Class Initialized
INFO - 2017-12-30 04:14:21 --> Language Class Initialized
INFO - 2017-12-30 04:14:21 --> Loader Class Initialized
INFO - 2017-12-30 04:14:21 --> Helper loaded: url_helper
INFO - 2017-12-30 04:14:21 --> Helper loaded: form_helper
INFO - 2017-12-30 04:14:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:14:21 --> Form Validation Class Initialized
INFO - 2017-12-30 04:14:21 --> Model Class Initialized
INFO - 2017-12-30 04:14:21 --> Controller Class Initialized
INFO - 2017-12-30 04:14:21 --> Model Class Initialized
INFO - 2017-12-30 04:14:21 --> Model Class Initialized
INFO - 2017-12-30 04:14:21 --> Model Class Initialized
INFO - 2017-12-30 04:14:21 --> Model Class Initialized
DEBUG - 2017-12-30 04:14:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:14:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:14:21 --> Final output sent to browser
DEBUG - 2017-12-30 04:14:21 --> Total execution time: 0.1617
INFO - 2017-12-30 04:14:25 --> Config Class Initialized
INFO - 2017-12-30 04:14:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:14:25 --> Utf8 Class Initialized
INFO - 2017-12-30 04:14:25 --> URI Class Initialized
INFO - 2017-12-30 04:14:25 --> Router Class Initialized
INFO - 2017-12-30 04:14:25 --> Output Class Initialized
INFO - 2017-12-30 04:14:25 --> Security Class Initialized
DEBUG - 2017-12-30 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:14:25 --> Input Class Initialized
INFO - 2017-12-30 04:14:25 --> Language Class Initialized
ERROR - 2017-12-30 04:14:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:14:25 --> Config Class Initialized
INFO - 2017-12-30 04:14:25 --> Hooks Class Initialized
INFO - 2017-12-30 04:14:25 --> Config Class Initialized
INFO - 2017-12-30 04:14:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:14:25 --> Utf8 Class Initialized
INFO - 2017-12-30 04:14:25 --> URI Class Initialized
DEBUG - 2017-12-30 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:14:25 --> Utf8 Class Initialized
INFO - 2017-12-30 04:14:25 --> Router Class Initialized
INFO - 2017-12-30 04:14:25 --> URI Class Initialized
INFO - 2017-12-30 04:14:25 --> Output Class Initialized
INFO - 2017-12-30 04:14:25 --> Security Class Initialized
INFO - 2017-12-30 04:14:25 --> Router Class Initialized
DEBUG - 2017-12-30 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:14:25 --> Input Class Initialized
INFO - 2017-12-30 04:14:25 --> Output Class Initialized
INFO - 2017-12-30 04:14:25 --> Language Class Initialized
INFO - 2017-12-30 04:14:25 --> Security Class Initialized
ERROR - 2017-12-30 04:14:25 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:14:25 --> Input Class Initialized
INFO - 2017-12-30 04:14:25 --> Language Class Initialized
ERROR - 2017-12-30 04:14:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:14:25 --> Config Class Initialized
INFO - 2017-12-30 04:14:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:14:25 --> Utf8 Class Initialized
INFO - 2017-12-30 04:14:25 --> URI Class Initialized
INFO - 2017-12-30 04:14:25 --> Router Class Initialized
INFO - 2017-12-30 04:14:25 --> Output Class Initialized
INFO - 2017-12-30 04:14:25 --> Security Class Initialized
DEBUG - 2017-12-30 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:14:25 --> Input Class Initialized
INFO - 2017-12-30 04:14:25 --> Language Class Initialized
INFO - 2017-12-30 04:14:25 --> Loader Class Initialized
INFO - 2017-12-30 04:14:25 --> Helper loaded: url_helper
INFO - 2017-12-30 04:14:25 --> Helper loaded: form_helper
INFO - 2017-12-30 04:14:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:14:25 --> Form Validation Class Initialized
INFO - 2017-12-30 04:14:25 --> Model Class Initialized
INFO - 2017-12-30 04:14:25 --> Controller Class Initialized
INFO - 2017-12-30 04:14:25 --> Model Class Initialized
INFO - 2017-12-30 04:14:25 --> Model Class Initialized
INFO - 2017-12-30 04:14:25 --> Model Class Initialized
INFO - 2017-12-30 04:14:25 --> Model Class Initialized
DEBUG - 2017-12-30 04:14:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:15:53 --> Config Class Initialized
INFO - 2017-12-30 04:15:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:15:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:15:53 --> Utf8 Class Initialized
INFO - 2017-12-30 04:15:53 --> URI Class Initialized
INFO - 2017-12-30 04:15:53 --> Router Class Initialized
INFO - 2017-12-30 04:15:53 --> Output Class Initialized
INFO - 2017-12-30 04:15:53 --> Security Class Initialized
DEBUG - 2017-12-30 04:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:15:53 --> Input Class Initialized
INFO - 2017-12-30 04:15:53 --> Language Class Initialized
INFO - 2017-12-30 04:15:53 --> Loader Class Initialized
INFO - 2017-12-30 04:15:53 --> Helper loaded: url_helper
INFO - 2017-12-30 04:15:53 --> Helper loaded: form_helper
INFO - 2017-12-30 04:15:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:15:53 --> Form Validation Class Initialized
INFO - 2017-12-30 04:15:53 --> Model Class Initialized
INFO - 2017-12-30 04:15:53 --> Controller Class Initialized
INFO - 2017-12-30 04:15:53 --> Model Class Initialized
INFO - 2017-12-30 04:15:53 --> Model Class Initialized
INFO - 2017-12-30 04:15:53 --> Model Class Initialized
INFO - 2017-12-30 04:15:53 --> Model Class Initialized
DEBUG - 2017-12-30 04:15:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:15:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:15:53 --> Final output sent to browser
DEBUG - 2017-12-30 04:15:53 --> Total execution time: 0.0694
INFO - 2017-12-30 04:15:55 --> Config Class Initialized
INFO - 2017-12-30 04:15:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:15:55 --> Utf8 Class Initialized
INFO - 2017-12-30 04:15:55 --> URI Class Initialized
INFO - 2017-12-30 04:15:55 --> Router Class Initialized
INFO - 2017-12-30 04:15:55 --> Output Class Initialized
INFO - 2017-12-30 04:15:55 --> Security Class Initialized
DEBUG - 2017-12-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:15:55 --> Input Class Initialized
INFO - 2017-12-30 04:15:55 --> Language Class Initialized
ERROR - 2017-12-30 04:15:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:15:55 --> Config Class Initialized
INFO - 2017-12-30 04:15:55 --> Hooks Class Initialized
INFO - 2017-12-30 04:15:55 --> Config Class Initialized
INFO - 2017-12-30 04:15:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:15:55 --> Utf8 Class Initialized
INFO - 2017-12-30 04:15:55 --> URI Class Initialized
DEBUG - 2017-12-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:15:55 --> Utf8 Class Initialized
INFO - 2017-12-30 04:15:55 --> Router Class Initialized
INFO - 2017-12-30 04:15:55 --> URI Class Initialized
INFO - 2017-12-30 04:15:55 --> Output Class Initialized
INFO - 2017-12-30 04:15:55 --> Router Class Initialized
INFO - 2017-12-30 04:15:55 --> Security Class Initialized
DEBUG - 2017-12-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:15:55 --> Output Class Initialized
INFO - 2017-12-30 04:15:55 --> Input Class Initialized
INFO - 2017-12-30 04:15:55 --> Language Class Initialized
INFO - 2017-12-30 04:15:55 --> Security Class Initialized
ERROR - 2017-12-30 04:15:55 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:15:55 --> Input Class Initialized
INFO - 2017-12-30 04:15:55 --> Language Class Initialized
ERROR - 2017-12-30 04:15:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:15:55 --> Config Class Initialized
INFO - 2017-12-30 04:15:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:15:55 --> Utf8 Class Initialized
INFO - 2017-12-30 04:15:55 --> URI Class Initialized
INFO - 2017-12-30 04:15:55 --> Router Class Initialized
INFO - 2017-12-30 04:15:55 --> Output Class Initialized
INFO - 2017-12-30 04:15:55 --> Security Class Initialized
DEBUG - 2017-12-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:15:55 --> Input Class Initialized
INFO - 2017-12-30 04:15:55 --> Language Class Initialized
INFO - 2017-12-30 04:15:55 --> Loader Class Initialized
INFO - 2017-12-30 04:15:55 --> Helper loaded: url_helper
INFO - 2017-12-30 04:15:55 --> Helper loaded: form_helper
INFO - 2017-12-30 04:15:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:15:55 --> Form Validation Class Initialized
INFO - 2017-12-30 04:15:55 --> Model Class Initialized
INFO - 2017-12-30 04:15:55 --> Controller Class Initialized
INFO - 2017-12-30 04:15:55 --> Model Class Initialized
INFO - 2017-12-30 04:15:55 --> Model Class Initialized
INFO - 2017-12-30 04:15:55 --> Model Class Initialized
INFO - 2017-12-30 04:15:55 --> Model Class Initialized
DEBUG - 2017-12-30 04:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:16:56 --> Config Class Initialized
INFO - 2017-12-30 04:16:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:16:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:16:56 --> Utf8 Class Initialized
INFO - 2017-12-30 04:16:56 --> URI Class Initialized
INFO - 2017-12-30 04:16:56 --> Router Class Initialized
INFO - 2017-12-30 04:16:56 --> Output Class Initialized
INFO - 2017-12-30 04:16:56 --> Security Class Initialized
DEBUG - 2017-12-30 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:16:56 --> Input Class Initialized
INFO - 2017-12-30 04:16:56 --> Language Class Initialized
INFO - 2017-12-30 04:16:56 --> Loader Class Initialized
INFO - 2017-12-30 04:16:56 --> Helper loaded: url_helper
INFO - 2017-12-30 04:16:56 --> Helper loaded: form_helper
INFO - 2017-12-30 04:16:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:16:56 --> Form Validation Class Initialized
INFO - 2017-12-30 04:16:56 --> Model Class Initialized
INFO - 2017-12-30 04:16:56 --> Controller Class Initialized
INFO - 2017-12-30 04:16:56 --> Model Class Initialized
INFO - 2017-12-30 04:16:56 --> Model Class Initialized
INFO - 2017-12-30 04:16:56 --> Model Class Initialized
INFO - 2017-12-30 04:16:56 --> Model Class Initialized
DEBUG - 2017-12-30 04:16:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:16:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:16:56 --> Final output sent to browser
DEBUG - 2017-12-30 04:16:56 --> Total execution time: 0.1230
INFO - 2017-12-30 04:17:00 --> Config Class Initialized
INFO - 2017-12-30 04:17:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:00 --> URI Class Initialized
INFO - 2017-12-30 04:17:00 --> Router Class Initialized
INFO - 2017-12-30 04:17:00 --> Output Class Initialized
INFO - 2017-12-30 04:17:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:00 --> Input Class Initialized
INFO - 2017-12-30 04:17:00 --> Language Class Initialized
ERROR - 2017-12-30 04:17:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:17:00 --> Config Class Initialized
INFO - 2017-12-30 04:17:00 --> Config Class Initialized
INFO - 2017-12-30 04:17:00 --> Hooks Class Initialized
INFO - 2017-12-30 04:17:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 04:17:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:00 --> URI Class Initialized
INFO - 2017-12-30 04:17:00 --> URI Class Initialized
INFO - 2017-12-30 04:17:00 --> Router Class Initialized
INFO - 2017-12-30 04:17:00 --> Router Class Initialized
INFO - 2017-12-30 04:17:00 --> Output Class Initialized
INFO - 2017-12-30 04:17:00 --> Security Class Initialized
INFO - 2017-12-30 04:17:00 --> Output Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:00 --> Security Class Initialized
INFO - 2017-12-30 04:17:00 --> Input Class Initialized
INFO - 2017-12-30 04:17:00 --> Language Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:00 --> Input Class Initialized
INFO - 2017-12-30 04:17:00 --> Language Class Initialized
ERROR - 2017-12-30 04:17:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 04:17:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:17:00 --> Config Class Initialized
INFO - 2017-12-30 04:17:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:00 --> URI Class Initialized
INFO - 2017-12-30 04:17:00 --> Router Class Initialized
INFO - 2017-12-30 04:17:00 --> Output Class Initialized
INFO - 2017-12-30 04:17:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:00 --> Input Class Initialized
INFO - 2017-12-30 04:17:00 --> Language Class Initialized
INFO - 2017-12-30 04:17:00 --> Loader Class Initialized
INFO - 2017-12-30 04:17:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:17:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:17:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:17:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:17:00 --> Model Class Initialized
INFO - 2017-12-30 04:17:00 --> Controller Class Initialized
INFO - 2017-12-30 04:17:00 --> Model Class Initialized
INFO - 2017-12-30 04:17:00 --> Model Class Initialized
INFO - 2017-12-30 04:17:00 --> Model Class Initialized
INFO - 2017-12-30 04:17:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:17:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:17:02 --> Config Class Initialized
INFO - 2017-12-30 04:17:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:02 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:02 --> URI Class Initialized
INFO - 2017-12-30 04:17:02 --> Router Class Initialized
INFO - 2017-12-30 04:17:02 --> Output Class Initialized
INFO - 2017-12-30 04:17:02 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:02 --> Input Class Initialized
INFO - 2017-12-30 04:17:02 --> Language Class Initialized
INFO - 2017-12-30 04:17:02 --> Loader Class Initialized
INFO - 2017-12-30 04:17:02 --> Helper loaded: url_helper
INFO - 2017-12-30 04:17:02 --> Helper loaded: form_helper
INFO - 2017-12-30 04:17:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:17:02 --> Form Validation Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Controller Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:17:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:17:02 --> Final output sent to browser
DEBUG - 2017-12-30 04:17:02 --> Total execution time: 0.0715
INFO - 2017-12-30 04:17:02 --> Config Class Initialized
INFO - 2017-12-30 04:17:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:02 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:02 --> URI Class Initialized
INFO - 2017-12-30 04:17:02 --> Router Class Initialized
INFO - 2017-12-30 04:17:02 --> Output Class Initialized
INFO - 2017-12-30 04:17:02 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:02 --> Input Class Initialized
INFO - 2017-12-30 04:17:02 --> Language Class Initialized
ERROR - 2017-12-30 04:17:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:17:02 --> Config Class Initialized
INFO - 2017-12-30 04:17:02 --> Hooks Class Initialized
INFO - 2017-12-30 04:17:02 --> Config Class Initialized
INFO - 2017-12-30 04:17:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:02 --> Utf8 Class Initialized
DEBUG - 2017-12-30 04:17:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:02 --> URI Class Initialized
INFO - 2017-12-30 04:17:02 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:02 --> URI Class Initialized
INFO - 2017-12-30 04:17:02 --> Router Class Initialized
INFO - 2017-12-30 04:17:02 --> Router Class Initialized
INFO - 2017-12-30 04:17:02 --> Output Class Initialized
INFO - 2017-12-30 04:17:02 --> Output Class Initialized
INFO - 2017-12-30 04:17:02 --> Security Class Initialized
INFO - 2017-12-30 04:17:02 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:02 --> Input Class Initialized
INFO - 2017-12-30 04:17:02 --> Input Class Initialized
INFO - 2017-12-30 04:17:02 --> Language Class Initialized
INFO - 2017-12-30 04:17:02 --> Language Class Initialized
ERROR - 2017-12-30 04:17:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 04:17:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:17:02 --> Config Class Initialized
INFO - 2017-12-30 04:17:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:17:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:17:02 --> Utf8 Class Initialized
INFO - 2017-12-30 04:17:02 --> URI Class Initialized
INFO - 2017-12-30 04:17:02 --> Router Class Initialized
INFO - 2017-12-30 04:17:02 --> Output Class Initialized
INFO - 2017-12-30 04:17:02 --> Security Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:17:02 --> Input Class Initialized
INFO - 2017-12-30 04:17:02 --> Language Class Initialized
INFO - 2017-12-30 04:17:02 --> Loader Class Initialized
INFO - 2017-12-30 04:17:02 --> Helper loaded: url_helper
INFO - 2017-12-30 04:17:02 --> Helper loaded: form_helper
INFO - 2017-12-30 04:17:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:17:02 --> Form Validation Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Controller Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
INFO - 2017-12-30 04:17:02 --> Model Class Initialized
DEBUG - 2017-12-30 04:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:19:58 --> Config Class Initialized
INFO - 2017-12-30 04:19:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:19:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:19:58 --> Utf8 Class Initialized
INFO - 2017-12-30 04:19:58 --> URI Class Initialized
INFO - 2017-12-30 04:19:58 --> Router Class Initialized
INFO - 2017-12-30 04:19:58 --> Output Class Initialized
INFO - 2017-12-30 04:19:58 --> Security Class Initialized
DEBUG - 2017-12-30 04:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:19:58 --> Input Class Initialized
INFO - 2017-12-30 04:19:58 --> Language Class Initialized
INFO - 2017-12-30 04:19:58 --> Loader Class Initialized
INFO - 2017-12-30 04:19:58 --> Helper loaded: url_helper
INFO - 2017-12-30 04:19:58 --> Helper loaded: form_helper
INFO - 2017-12-30 04:19:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:19:58 --> Form Validation Class Initialized
INFO - 2017-12-30 04:19:58 --> Model Class Initialized
INFO - 2017-12-30 04:19:58 --> Controller Class Initialized
INFO - 2017-12-30 04:19:58 --> Model Class Initialized
INFO - 2017-12-30 04:19:58 --> Model Class Initialized
INFO - 2017-12-30 04:19:58 --> Model Class Initialized
INFO - 2017-12-30 04:19:58 --> Model Class Initialized
DEBUG - 2017-12-30 04:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:19:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:19:58 --> Final output sent to browser
DEBUG - 2017-12-30 04:19:58 --> Total execution time: 0.0910
INFO - 2017-12-30 04:19:59 --> Config Class Initialized
INFO - 2017-12-30 04:19:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:19:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:19:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:19:59 --> URI Class Initialized
INFO - 2017-12-30 04:19:59 --> Router Class Initialized
INFO - 2017-12-30 04:19:59 --> Output Class Initialized
INFO - 2017-12-30 04:19:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:19:59 --> Input Class Initialized
INFO - 2017-12-30 04:19:59 --> Language Class Initialized
ERROR - 2017-12-30 04:19:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 04:19:59 --> Config Class Initialized
INFO - 2017-12-30 04:19:59 --> Hooks Class Initialized
INFO - 2017-12-30 04:19:59 --> Config Class Initialized
INFO - 2017-12-30 04:19:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:19:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:19:59 --> Utf8 Class Initialized
DEBUG - 2017-12-30 04:19:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:19:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:19:59 --> URI Class Initialized
INFO - 2017-12-30 04:19:59 --> URI Class Initialized
INFO - 2017-12-30 04:19:59 --> Router Class Initialized
INFO - 2017-12-30 04:19:59 --> Router Class Initialized
INFO - 2017-12-30 04:19:59 --> Output Class Initialized
INFO - 2017-12-30 04:19:59 --> Output Class Initialized
INFO - 2017-12-30 04:19:59 --> Security Class Initialized
INFO - 2017-12-30 04:19:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:19:59 --> Input Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:19:59 --> Input Class Initialized
INFO - 2017-12-30 04:19:59 --> Language Class Initialized
INFO - 2017-12-30 04:19:59 --> Language Class Initialized
ERROR - 2017-12-30 04:19:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 04:19:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 04:19:59 --> Config Class Initialized
INFO - 2017-12-30 04:19:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:19:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:19:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:19:59 --> URI Class Initialized
INFO - 2017-12-30 04:19:59 --> Router Class Initialized
INFO - 2017-12-30 04:19:59 --> Output Class Initialized
INFO - 2017-12-30 04:19:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:19:59 --> Input Class Initialized
INFO - 2017-12-30 04:19:59 --> Language Class Initialized
INFO - 2017-12-30 04:19:59 --> Loader Class Initialized
INFO - 2017-12-30 04:19:59 --> Helper loaded: url_helper
INFO - 2017-12-30 04:19:59 --> Helper loaded: form_helper
INFO - 2017-12-30 04:19:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:19:59 --> Form Validation Class Initialized
INFO - 2017-12-30 04:19:59 --> Model Class Initialized
INFO - 2017-12-30 04:19:59 --> Controller Class Initialized
INFO - 2017-12-30 04:19:59 --> Model Class Initialized
INFO - 2017-12-30 04:19:59 --> Model Class Initialized
INFO - 2017-12-30 04:19:59 --> Model Class Initialized
INFO - 2017-12-30 04:19:59 --> Model Class Initialized
DEBUG - 2017-12-30 04:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:23:28 --> Config Class Initialized
INFO - 2017-12-30 04:23:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:23:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:23:28 --> Utf8 Class Initialized
INFO - 2017-12-30 04:23:28 --> URI Class Initialized
INFO - 2017-12-30 04:23:28 --> Router Class Initialized
INFO - 2017-12-30 04:23:28 --> Output Class Initialized
INFO - 2017-12-30 04:23:28 --> Security Class Initialized
DEBUG - 2017-12-30 04:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:23:28 --> Input Class Initialized
INFO - 2017-12-30 04:23:28 --> Language Class Initialized
INFO - 2017-12-30 04:23:28 --> Loader Class Initialized
INFO - 2017-12-30 04:23:28 --> Helper loaded: url_helper
INFO - 2017-12-30 04:23:28 --> Helper loaded: form_helper
INFO - 2017-12-30 04:23:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:23:28 --> Form Validation Class Initialized
INFO - 2017-12-30 04:23:28 --> Model Class Initialized
INFO - 2017-12-30 04:23:28 --> Controller Class Initialized
INFO - 2017-12-30 04:23:28 --> Model Class Initialized
INFO - 2017-12-30 04:23:28 --> Model Class Initialized
INFO - 2017-12-30 04:23:28 --> Model Class Initialized
INFO - 2017-12-30 04:23:28 --> Model Class Initialized
DEBUG - 2017-12-30 04:23:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 04:23:28 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verProyecto.php 20
ERROR - 2017-12-30 04:23:28 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verProyecto.php 239
INFO - 2017-12-30 04:23:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:23:28 --> Final output sent to browser
DEBUG - 2017-12-30 04:23:28 --> Total execution time: 0.5738
INFO - 2017-12-30 04:23:29 --> Config Class Initialized
INFO - 2017-12-30 04:23:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:23:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:23:29 --> Utf8 Class Initialized
INFO - 2017-12-30 04:23:29 --> URI Class Initialized
INFO - 2017-12-30 04:23:29 --> Router Class Initialized
INFO - 2017-12-30 04:23:29 --> Output Class Initialized
INFO - 2017-12-30 04:23:29 --> Security Class Initialized
DEBUG - 2017-12-30 04:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:23:29 --> Input Class Initialized
INFO - 2017-12-30 04:23:29 --> Language Class Initialized
INFO - 2017-12-30 04:23:29 --> Loader Class Initialized
INFO - 2017-12-30 04:23:29 --> Helper loaded: url_helper
INFO - 2017-12-30 04:23:29 --> Helper loaded: form_helper
INFO - 2017-12-30 04:23:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:23:29 --> Form Validation Class Initialized
INFO - 2017-12-30 04:23:29 --> Model Class Initialized
INFO - 2017-12-30 04:23:29 --> Controller Class Initialized
INFO - 2017-12-30 04:23:29 --> Model Class Initialized
INFO - 2017-12-30 04:23:29 --> Model Class Initialized
INFO - 2017-12-30 04:23:29 --> Model Class Initialized
INFO - 2017-12-30 04:23:29 --> Model Class Initialized
DEBUG - 2017-12-30 04:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:23:42 --> Config Class Initialized
INFO - 2017-12-30 04:23:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:23:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:23:42 --> Utf8 Class Initialized
INFO - 2017-12-30 04:23:42 --> URI Class Initialized
INFO - 2017-12-30 04:23:42 --> Router Class Initialized
INFO - 2017-12-30 04:23:42 --> Output Class Initialized
INFO - 2017-12-30 04:23:42 --> Security Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:23:42 --> Input Class Initialized
INFO - 2017-12-30 04:23:42 --> Language Class Initialized
INFO - 2017-12-30 04:23:42 --> Loader Class Initialized
INFO - 2017-12-30 04:23:42 --> Helper loaded: url_helper
INFO - 2017-12-30 04:23:42 --> Helper loaded: form_helper
INFO - 2017-12-30 04:23:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:23:42 --> Form Validation Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Controller Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:23:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:23:42 --> Final output sent to browser
DEBUG - 2017-12-30 04:23:42 --> Total execution time: 0.0648
INFO - 2017-12-30 04:23:42 --> Config Class Initialized
INFO - 2017-12-30 04:23:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:23:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:23:42 --> Utf8 Class Initialized
INFO - 2017-12-30 04:23:42 --> URI Class Initialized
INFO - 2017-12-30 04:23:42 --> Router Class Initialized
INFO - 2017-12-30 04:23:42 --> Output Class Initialized
INFO - 2017-12-30 04:23:42 --> Security Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:23:42 --> Input Class Initialized
INFO - 2017-12-30 04:23:42 --> Language Class Initialized
INFO - 2017-12-30 04:23:42 --> Loader Class Initialized
INFO - 2017-12-30 04:23:42 --> Helper loaded: url_helper
INFO - 2017-12-30 04:23:42 --> Helper loaded: form_helper
INFO - 2017-12-30 04:23:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:23:42 --> Form Validation Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Controller Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
INFO - 2017-12-30 04:23:42 --> Model Class Initialized
DEBUG - 2017-12-30 04:23:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:23:46 --> Config Class Initialized
INFO - 2017-12-30 04:23:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:23:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:23:46 --> Utf8 Class Initialized
INFO - 2017-12-30 04:23:46 --> URI Class Initialized
INFO - 2017-12-30 04:23:46 --> Router Class Initialized
INFO - 2017-12-30 04:23:46 --> Output Class Initialized
INFO - 2017-12-30 04:23:46 --> Security Class Initialized
DEBUG - 2017-12-30 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:23:46 --> Input Class Initialized
INFO - 2017-12-30 04:23:46 --> Language Class Initialized
INFO - 2017-12-30 04:23:46 --> Loader Class Initialized
INFO - 2017-12-30 04:23:46 --> Helper loaded: url_helper
INFO - 2017-12-30 04:23:46 --> Helper loaded: form_helper
INFO - 2017-12-30 04:23:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:23:46 --> Form Validation Class Initialized
INFO - 2017-12-30 04:23:46 --> Model Class Initialized
INFO - 2017-12-30 04:23:46 --> Controller Class Initialized
INFO - 2017-12-30 04:23:46 --> Model Class Initialized
INFO - 2017-12-30 04:23:46 --> Model Class Initialized
INFO - 2017-12-30 04:23:46 --> Model Class Initialized
INFO - 2017-12-30 04:23:46 --> Model Class Initialized
DEBUG - 2017-12-30 04:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:23:46 --> Final output sent to browser
DEBUG - 2017-12-30 04:23:46 --> Total execution time: 0.4099
INFO - 2017-12-30 04:24:47 --> Config Class Initialized
INFO - 2017-12-30 04:24:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:24:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:24:47 --> Utf8 Class Initialized
INFO - 2017-12-30 04:24:47 --> URI Class Initialized
INFO - 2017-12-30 04:24:47 --> Router Class Initialized
INFO - 2017-12-30 04:24:47 --> Output Class Initialized
INFO - 2017-12-30 04:24:47 --> Security Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:24:47 --> Input Class Initialized
INFO - 2017-12-30 04:24:47 --> Language Class Initialized
INFO - 2017-12-30 04:24:47 --> Loader Class Initialized
INFO - 2017-12-30 04:24:47 --> Helper loaded: url_helper
INFO - 2017-12-30 04:24:47 --> Helper loaded: form_helper
INFO - 2017-12-30 04:24:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:24:47 --> Form Validation Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Controller Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:24:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:24:47 --> Final output sent to browser
DEBUG - 2017-12-30 04:24:47 --> Total execution time: 0.3281
INFO - 2017-12-30 04:24:47 --> Config Class Initialized
INFO - 2017-12-30 04:24:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:24:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:24:47 --> Utf8 Class Initialized
INFO - 2017-12-30 04:24:47 --> URI Class Initialized
INFO - 2017-12-30 04:24:47 --> Router Class Initialized
INFO - 2017-12-30 04:24:47 --> Output Class Initialized
INFO - 2017-12-30 04:24:47 --> Security Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:24:47 --> Input Class Initialized
INFO - 2017-12-30 04:24:47 --> Language Class Initialized
INFO - 2017-12-30 04:24:47 --> Loader Class Initialized
INFO - 2017-12-30 04:24:47 --> Helper loaded: url_helper
INFO - 2017-12-30 04:24:47 --> Helper loaded: form_helper
INFO - 2017-12-30 04:24:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:24:47 --> Form Validation Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Controller Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
INFO - 2017-12-30 04:24:47 --> Model Class Initialized
DEBUG - 2017-12-30 04:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:24:49 --> Config Class Initialized
INFO - 2017-12-30 04:24:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:24:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:24:49 --> Utf8 Class Initialized
INFO - 2017-12-30 04:24:49 --> URI Class Initialized
INFO - 2017-12-30 04:24:49 --> Router Class Initialized
INFO - 2017-12-30 04:24:49 --> Output Class Initialized
INFO - 2017-12-30 04:24:49 --> Security Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:24:49 --> Input Class Initialized
INFO - 2017-12-30 04:24:49 --> Language Class Initialized
INFO - 2017-12-30 04:24:49 --> Loader Class Initialized
INFO - 2017-12-30 04:24:49 --> Helper loaded: url_helper
INFO - 2017-12-30 04:24:49 --> Helper loaded: form_helper
INFO - 2017-12-30 04:24:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:24:49 --> Form Validation Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Controller Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:24:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:24:49 --> Final output sent to browser
DEBUG - 2017-12-30 04:24:49 --> Total execution time: 0.0659
INFO - 2017-12-30 04:24:49 --> Config Class Initialized
INFO - 2017-12-30 04:24:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:24:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:24:49 --> Utf8 Class Initialized
INFO - 2017-12-30 04:24:49 --> URI Class Initialized
INFO - 2017-12-30 04:24:49 --> Router Class Initialized
INFO - 2017-12-30 04:24:49 --> Output Class Initialized
INFO - 2017-12-30 04:24:49 --> Security Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:24:49 --> Input Class Initialized
INFO - 2017-12-30 04:24:49 --> Language Class Initialized
INFO - 2017-12-30 04:24:49 --> Loader Class Initialized
INFO - 2017-12-30 04:24:49 --> Helper loaded: url_helper
INFO - 2017-12-30 04:24:49 --> Helper loaded: form_helper
INFO - 2017-12-30 04:24:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:24:49 --> Form Validation Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Controller Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
INFO - 2017-12-30 04:24:49 --> Model Class Initialized
DEBUG - 2017-12-30 04:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:24:51 --> Config Class Initialized
INFO - 2017-12-30 04:24:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:24:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:24:51 --> Utf8 Class Initialized
INFO - 2017-12-30 04:24:51 --> URI Class Initialized
INFO - 2017-12-30 04:24:51 --> Router Class Initialized
INFO - 2017-12-30 04:24:51 --> Output Class Initialized
INFO - 2017-12-30 04:24:51 --> Security Class Initialized
DEBUG - 2017-12-30 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:24:51 --> Input Class Initialized
INFO - 2017-12-30 04:24:51 --> Language Class Initialized
INFO - 2017-12-30 04:24:51 --> Loader Class Initialized
INFO - 2017-12-30 04:24:51 --> Helper loaded: url_helper
INFO - 2017-12-30 04:24:51 --> Helper loaded: form_helper
INFO - 2017-12-30 04:24:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:24:51 --> Form Validation Class Initialized
INFO - 2017-12-30 04:24:51 --> Model Class Initialized
INFO - 2017-12-30 04:24:51 --> Controller Class Initialized
INFO - 2017-12-30 04:24:51 --> Model Class Initialized
INFO - 2017-12-30 04:24:51 --> Model Class Initialized
INFO - 2017-12-30 04:24:51 --> Model Class Initialized
INFO - 2017-12-30 04:24:51 --> Model Class Initialized
DEBUG - 2017-12-30 04:24:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:24:51 --> Final output sent to browser
DEBUG - 2017-12-30 04:24:51 --> Total execution time: 0.1416
INFO - 2017-12-30 04:37:30 --> Config Class Initialized
INFO - 2017-12-30 04:37:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:30 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:30 --> URI Class Initialized
INFO - 2017-12-30 04:37:30 --> Router Class Initialized
INFO - 2017-12-30 04:37:30 --> Output Class Initialized
INFO - 2017-12-30 04:37:30 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:30 --> Input Class Initialized
INFO - 2017-12-30 04:37:30 --> Language Class Initialized
INFO - 2017-12-30 04:37:30 --> Loader Class Initialized
INFO - 2017-12-30 04:37:30 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:30 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:30 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:30 --> Model Class Initialized
INFO - 2017-12-30 04:37:30 --> Controller Class Initialized
INFO - 2017-12-30 04:37:30 --> Model Class Initialized
INFO - 2017-12-30 04:37:30 --> Model Class Initialized
INFO - 2017-12-30 04:37:30 --> Model Class Initialized
INFO - 2017-12-30 04:37:30 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:30 --> Final output sent to browser
DEBUG - 2017-12-30 04:37:30 --> Total execution time: 0.1367
INFO - 2017-12-30 04:37:41 --> Config Class Initialized
INFO - 2017-12-30 04:37:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:41 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:41 --> URI Class Initialized
INFO - 2017-12-30 04:37:41 --> Router Class Initialized
INFO - 2017-12-30 04:37:41 --> Output Class Initialized
INFO - 2017-12-30 04:37:41 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:41 --> Input Class Initialized
INFO - 2017-12-30 04:37:41 --> Language Class Initialized
INFO - 2017-12-30 04:37:41 --> Loader Class Initialized
INFO - 2017-12-30 04:37:41 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:41 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:41 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:41 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Controller Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:37:41 --> Final output sent to browser
DEBUG - 2017-12-30 04:37:41 --> Total execution time: 0.0562
INFO - 2017-12-30 04:37:41 --> Config Class Initialized
INFO - 2017-12-30 04:37:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:41 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:41 --> URI Class Initialized
INFO - 2017-12-30 04:37:41 --> Router Class Initialized
INFO - 2017-12-30 04:37:41 --> Output Class Initialized
INFO - 2017-12-30 04:37:41 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:41 --> Input Class Initialized
INFO - 2017-12-30 04:37:41 --> Language Class Initialized
INFO - 2017-12-30 04:37:41 --> Loader Class Initialized
INFO - 2017-12-30 04:37:41 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:41 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:41 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:41 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Controller Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
INFO - 2017-12-30 04:37:41 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:43 --> Config Class Initialized
INFO - 2017-12-30 04:37:43 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:43 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:43 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:43 --> URI Class Initialized
INFO - 2017-12-30 04:37:43 --> Router Class Initialized
INFO - 2017-12-30 04:37:43 --> Output Class Initialized
INFO - 2017-12-30 04:37:43 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:43 --> Input Class Initialized
INFO - 2017-12-30 04:37:43 --> Language Class Initialized
INFO - 2017-12-30 04:37:43 --> Loader Class Initialized
INFO - 2017-12-30 04:37:43 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:43 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:43 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:43 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Controller Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:37:43 --> Final output sent to browser
DEBUG - 2017-12-30 04:37:43 --> Total execution time: 0.0659
INFO - 2017-12-30 04:37:43 --> Config Class Initialized
INFO - 2017-12-30 04:37:43 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:43 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:43 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:43 --> URI Class Initialized
INFO - 2017-12-30 04:37:43 --> Router Class Initialized
INFO - 2017-12-30 04:37:43 --> Output Class Initialized
INFO - 2017-12-30 04:37:43 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:43 --> Input Class Initialized
INFO - 2017-12-30 04:37:43 --> Language Class Initialized
INFO - 2017-12-30 04:37:43 --> Loader Class Initialized
INFO - 2017-12-30 04:37:43 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:43 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:43 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:43 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Controller Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
INFO - 2017-12-30 04:37:43 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:47 --> Config Class Initialized
INFO - 2017-12-30 04:37:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:37:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:37:47 --> Utf8 Class Initialized
INFO - 2017-12-30 04:37:47 --> URI Class Initialized
INFO - 2017-12-30 04:37:47 --> Router Class Initialized
INFO - 2017-12-30 04:37:47 --> Output Class Initialized
INFO - 2017-12-30 04:37:47 --> Security Class Initialized
DEBUG - 2017-12-30 04:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:37:47 --> Input Class Initialized
INFO - 2017-12-30 04:37:47 --> Language Class Initialized
INFO - 2017-12-30 04:37:47 --> Loader Class Initialized
INFO - 2017-12-30 04:37:47 --> Helper loaded: url_helper
INFO - 2017-12-30 04:37:47 --> Helper loaded: form_helper
INFO - 2017-12-30 04:37:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:37:47 --> Form Validation Class Initialized
INFO - 2017-12-30 04:37:47 --> Model Class Initialized
INFO - 2017-12-30 04:37:47 --> Controller Class Initialized
INFO - 2017-12-30 04:37:47 --> Model Class Initialized
INFO - 2017-12-30 04:37:47 --> Model Class Initialized
INFO - 2017-12-30 04:37:47 --> Model Class Initialized
INFO - 2017-12-30 04:37:47 --> Model Class Initialized
DEBUG - 2017-12-30 04:37:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:37:47 --> Final output sent to browser
DEBUG - 2017-12-30 04:37:47 --> Total execution time: 0.1462
INFO - 2017-12-30 04:39:29 --> Config Class Initialized
INFO - 2017-12-30 04:39:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:39:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:39:29 --> Utf8 Class Initialized
INFO - 2017-12-30 04:39:29 --> URI Class Initialized
INFO - 2017-12-30 04:39:29 --> Router Class Initialized
INFO - 2017-12-30 04:39:29 --> Output Class Initialized
INFO - 2017-12-30 04:39:29 --> Security Class Initialized
DEBUG - 2017-12-30 04:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:39:29 --> Input Class Initialized
INFO - 2017-12-30 04:39:29 --> Language Class Initialized
ERROR - 2017-12-30 04:39:29 --> 404 Page Not Found: Reportes/index
INFO - 2017-12-30 04:41:00 --> Config Class Initialized
INFO - 2017-12-30 04:41:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:41:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:41:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:41:00 --> URI Class Initialized
INFO - 2017-12-30 04:41:00 --> Router Class Initialized
INFO - 2017-12-30 04:41:00 --> Output Class Initialized
INFO - 2017-12-30 04:41:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:41:00 --> Input Class Initialized
INFO - 2017-12-30 04:41:00 --> Language Class Initialized
INFO - 2017-12-30 04:41:00 --> Loader Class Initialized
INFO - 2017-12-30 04:41:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:41:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:41:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:41:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
INFO - 2017-12-30 04:41:00 --> Controller Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:41:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:41:00 --> Config Class Initialized
INFO - 2017-12-30 04:41:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:41:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:41:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:41:00 --> URI Class Initialized
INFO - 2017-12-30 04:41:00 --> Router Class Initialized
INFO - 2017-12-30 04:41:00 --> Output Class Initialized
INFO - 2017-12-30 04:41:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:41:00 --> Input Class Initialized
INFO - 2017-12-30 04:41:00 --> Language Class Initialized
INFO - 2017-12-30 04:41:00 --> Loader Class Initialized
INFO - 2017-12-30 04:41:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:41:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:41:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:41:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:41:00 --> Model Class Initialized
INFO - 2017-12-30 04:41:00 --> Controller Class Initialized
INFO - 2017-12-30 04:41:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:41:00 --> Final output sent to browser
DEBUG - 2017-12-30 04:41:00 --> Total execution time: 0.0937
INFO - 2017-12-30 04:42:51 --> Config Class Initialized
INFO - 2017-12-30 04:42:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:42:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:42:51 --> Utf8 Class Initialized
INFO - 2017-12-30 04:42:51 --> URI Class Initialized
INFO - 2017-12-30 04:42:51 --> Router Class Initialized
INFO - 2017-12-30 04:42:51 --> Output Class Initialized
INFO - 2017-12-30 04:42:51 --> Security Class Initialized
DEBUG - 2017-12-30 04:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:42:51 --> Input Class Initialized
INFO - 2017-12-30 04:42:51 --> Language Class Initialized
INFO - 2017-12-30 04:42:51 --> Loader Class Initialized
INFO - 2017-12-30 04:42:51 --> Helper loaded: url_helper
INFO - 2017-12-30 04:42:51 --> Helper loaded: form_helper
INFO - 2017-12-30 04:42:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:42:51 --> Form Validation Class Initialized
INFO - 2017-12-30 04:42:51 --> Model Class Initialized
INFO - 2017-12-30 04:42:51 --> Controller Class Initialized
INFO - 2017-12-30 04:42:51 --> Model Class Initialized
INFO - 2017-12-30 04:42:51 --> Model Class Initialized
INFO - 2017-12-30 04:42:51 --> Model Class Initialized
INFO - 2017-12-30 04:42:51 --> Model Class Initialized
DEBUG - 2017-12-30 04:42:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:42:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:42:51 --> Final output sent to browser
DEBUG - 2017-12-30 04:42:52 --> Total execution time: 0.0609
INFO - 2017-12-30 04:42:53 --> Config Class Initialized
INFO - 2017-12-30 04:42:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:42:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:42:53 --> Utf8 Class Initialized
INFO - 2017-12-30 04:42:53 --> URI Class Initialized
INFO - 2017-12-30 04:42:53 --> Router Class Initialized
INFO - 2017-12-30 04:42:53 --> Output Class Initialized
INFO - 2017-12-30 04:42:53 --> Security Class Initialized
DEBUG - 2017-12-30 04:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:42:53 --> Input Class Initialized
INFO - 2017-12-30 04:42:53 --> Language Class Initialized
INFO - 2017-12-30 04:42:53 --> Loader Class Initialized
INFO - 2017-12-30 04:42:53 --> Helper loaded: url_helper
INFO - 2017-12-30 04:42:53 --> Helper loaded: form_helper
INFO - 2017-12-30 04:42:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:42:54 --> Form Validation Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Controller Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:42:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:42:54 --> Final output sent to browser
DEBUG - 2017-12-30 04:42:54 --> Total execution time: 0.0987
INFO - 2017-12-30 04:42:54 --> Config Class Initialized
INFO - 2017-12-30 04:42:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:42:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:42:54 --> Utf8 Class Initialized
INFO - 2017-12-30 04:42:54 --> URI Class Initialized
INFO - 2017-12-30 04:42:54 --> Router Class Initialized
INFO - 2017-12-30 04:42:54 --> Output Class Initialized
INFO - 2017-12-30 04:42:54 --> Security Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:42:54 --> Input Class Initialized
INFO - 2017-12-30 04:42:54 --> Language Class Initialized
INFO - 2017-12-30 04:42:54 --> Loader Class Initialized
INFO - 2017-12-30 04:42:54 --> Helper loaded: url_helper
INFO - 2017-12-30 04:42:54 --> Helper loaded: form_helper
INFO - 2017-12-30 04:42:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:42:54 --> Form Validation Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Controller Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:42:54 --> Config Class Initialized
INFO - 2017-12-30 04:42:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:42:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:42:54 --> Utf8 Class Initialized
INFO - 2017-12-30 04:42:54 --> URI Class Initialized
INFO - 2017-12-30 04:42:54 --> Router Class Initialized
INFO - 2017-12-30 04:42:54 --> Output Class Initialized
INFO - 2017-12-30 04:42:54 --> Security Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:42:54 --> Input Class Initialized
INFO - 2017-12-30 04:42:54 --> Language Class Initialized
INFO - 2017-12-30 04:42:54 --> Loader Class Initialized
INFO - 2017-12-30 04:42:54 --> Helper loaded: url_helper
INFO - 2017-12-30 04:42:54 --> Helper loaded: form_helper
INFO - 2017-12-30 04:42:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:42:54 --> Form Validation Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Controller Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
INFO - 2017-12-30 04:42:54 --> Model Class Initialized
DEBUG - 2017-12-30 04:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:42:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:42:54 --> Final output sent to browser
DEBUG - 2017-12-30 04:42:54 --> Total execution time: 0.0613
INFO - 2017-12-30 04:42:56 --> Config Class Initialized
INFO - 2017-12-30 04:42:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:42:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:42:56 --> Utf8 Class Initialized
INFO - 2017-12-30 04:42:56 --> URI Class Initialized
INFO - 2017-12-30 04:42:56 --> Router Class Initialized
INFO - 2017-12-30 04:42:56 --> Output Class Initialized
INFO - 2017-12-30 04:42:56 --> Security Class Initialized
DEBUG - 2017-12-30 04:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:42:56 --> Input Class Initialized
INFO - 2017-12-30 04:42:56 --> Language Class Initialized
INFO - 2017-12-30 04:42:56 --> Loader Class Initialized
INFO - 2017-12-30 04:42:56 --> Helper loaded: url_helper
INFO - 2017-12-30 04:42:56 --> Helper loaded: form_helper
INFO - 2017-12-30 04:42:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:42:56 --> Form Validation Class Initialized
INFO - 2017-12-30 04:42:56 --> Model Class Initialized
INFO - 2017-12-30 04:42:56 --> Controller Class Initialized
INFO - 2017-12-30 04:42:56 --> Model Class Initialized
INFO - 2017-12-30 04:42:56 --> Model Class Initialized
INFO - 2017-12-30 04:42:56 --> Model Class Initialized
INFO - 2017-12-30 04:42:56 --> Model Class Initialized
DEBUG - 2017-12-30 04:42:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:42:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:42:56 --> Final output sent to browser
DEBUG - 2017-12-30 04:42:56 --> Total execution time: 0.0624
INFO - 2017-12-30 04:43:40 --> Config Class Initialized
INFO - 2017-12-30 04:43:40 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:43:40 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:43:40 --> Utf8 Class Initialized
INFO - 2017-12-30 04:43:40 --> URI Class Initialized
INFO - 2017-12-30 04:43:40 --> Router Class Initialized
INFO - 2017-12-30 04:43:40 --> Output Class Initialized
INFO - 2017-12-30 04:43:40 --> Security Class Initialized
DEBUG - 2017-12-30 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:43:40 --> Input Class Initialized
INFO - 2017-12-30 04:43:40 --> Language Class Initialized
INFO - 2017-12-30 04:43:40 --> Loader Class Initialized
INFO - 2017-12-30 04:43:40 --> Helper loaded: url_helper
INFO - 2017-12-30 04:43:40 --> Helper loaded: form_helper
INFO - 2017-12-30 04:43:40 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:43:40 --> Form Validation Class Initialized
INFO - 2017-12-30 04:43:40 --> Model Class Initialized
INFO - 2017-12-30 04:43:40 --> Controller Class Initialized
INFO - 2017-12-30 04:43:40 --> Model Class Initialized
INFO - 2017-12-30 04:43:40 --> Model Class Initialized
INFO - 2017-12-30 04:43:40 --> Model Class Initialized
INFO - 2017-12-30 04:43:40 --> Model Class Initialized
DEBUG - 2017-12-30 04:43:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:43:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:43:40 --> Final output sent to browser
DEBUG - 2017-12-30 04:43:40 --> Total execution time: 0.0797
INFO - 2017-12-30 04:44:52 --> Config Class Initialized
INFO - 2017-12-30 04:44:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:44:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:44:52 --> Utf8 Class Initialized
INFO - 2017-12-30 04:44:52 --> URI Class Initialized
INFO - 2017-12-30 04:44:52 --> Router Class Initialized
INFO - 2017-12-30 04:44:52 --> Output Class Initialized
INFO - 2017-12-30 04:44:52 --> Security Class Initialized
DEBUG - 2017-12-30 04:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:44:52 --> Input Class Initialized
INFO - 2017-12-30 04:44:52 --> Language Class Initialized
INFO - 2017-12-30 04:44:52 --> Loader Class Initialized
INFO - 2017-12-30 04:44:52 --> Helper loaded: url_helper
INFO - 2017-12-30 04:44:52 --> Helper loaded: form_helper
INFO - 2017-12-30 04:44:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:44:52 --> Form Validation Class Initialized
INFO - 2017-12-30 04:44:52 --> Model Class Initialized
INFO - 2017-12-30 04:44:52 --> Controller Class Initialized
INFO - 2017-12-30 04:44:52 --> Model Class Initialized
INFO - 2017-12-30 04:44:52 --> Model Class Initialized
INFO - 2017-12-30 04:44:52 --> Model Class Initialized
INFO - 2017-12-30 04:44:52 --> Model Class Initialized
DEBUG - 2017-12-30 04:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:44:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:44:52 --> Final output sent to browser
DEBUG - 2017-12-30 04:44:52 --> Total execution time: 0.0939
INFO - 2017-12-30 04:44:58 --> Config Class Initialized
INFO - 2017-12-30 04:44:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:44:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:44:58 --> Utf8 Class Initialized
INFO - 2017-12-30 04:44:58 --> URI Class Initialized
INFO - 2017-12-30 04:44:58 --> Router Class Initialized
INFO - 2017-12-30 04:44:58 --> Output Class Initialized
INFO - 2017-12-30 04:44:58 --> Security Class Initialized
DEBUG - 2017-12-30 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:44:58 --> Input Class Initialized
INFO - 2017-12-30 04:44:58 --> Language Class Initialized
INFO - 2017-12-30 04:44:58 --> Loader Class Initialized
INFO - 2017-12-30 04:44:58 --> Helper loaded: url_helper
INFO - 2017-12-30 04:44:58 --> Helper loaded: form_helper
INFO - 2017-12-30 04:44:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:44:58 --> Form Validation Class Initialized
INFO - 2017-12-30 04:44:58 --> Model Class Initialized
INFO - 2017-12-30 04:44:58 --> Controller Class Initialized
INFO - 2017-12-30 04:44:58 --> Model Class Initialized
INFO - 2017-12-30 04:44:58 --> Model Class Initialized
DEBUG - 2017-12-30 04:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:44:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:44:58 --> Final output sent to browser
DEBUG - 2017-12-30 04:44:58 --> Total execution time: 0.0544
INFO - 2017-12-30 04:44:59 --> Config Class Initialized
INFO - 2017-12-30 04:44:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:44:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:44:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:44:59 --> URI Class Initialized
INFO - 2017-12-30 04:44:59 --> Router Class Initialized
INFO - 2017-12-30 04:44:59 --> Output Class Initialized
INFO - 2017-12-30 04:44:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:44:59 --> Input Class Initialized
INFO - 2017-12-30 04:44:59 --> Language Class Initialized
INFO - 2017-12-30 04:44:59 --> Loader Class Initialized
INFO - 2017-12-30 04:44:59 --> Helper loaded: url_helper
INFO - 2017-12-30 04:44:59 --> Helper loaded: form_helper
INFO - 2017-12-30 04:44:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:44:59 --> Form Validation Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Controller Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:44:59 --> Config Class Initialized
INFO - 2017-12-30 04:44:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:44:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:44:59 --> Utf8 Class Initialized
INFO - 2017-12-30 04:44:59 --> URI Class Initialized
INFO - 2017-12-30 04:44:59 --> Router Class Initialized
INFO - 2017-12-30 04:44:59 --> Output Class Initialized
INFO - 2017-12-30 04:44:59 --> Security Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:44:59 --> Input Class Initialized
INFO - 2017-12-30 04:44:59 --> Language Class Initialized
INFO - 2017-12-30 04:44:59 --> Loader Class Initialized
INFO - 2017-12-30 04:44:59 --> Helper loaded: url_helper
INFO - 2017-12-30 04:44:59 --> Helper loaded: form_helper
INFO - 2017-12-30 04:44:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:44:59 --> Form Validation Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Controller Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
INFO - 2017-12-30 04:44:59 --> Model Class Initialized
DEBUG - 2017-12-30 04:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:44:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:44:59 --> Final output sent to browser
DEBUG - 2017-12-30 04:44:59 --> Total execution time: 0.0700
INFO - 2017-12-30 04:45:00 --> Config Class Initialized
INFO - 2017-12-30 04:45:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:45:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:45:00 --> URI Class Initialized
INFO - 2017-12-30 04:45:00 --> Router Class Initialized
INFO - 2017-12-30 04:45:00 --> Output Class Initialized
INFO - 2017-12-30 04:45:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:45:00 --> Input Class Initialized
INFO - 2017-12-30 04:45:00 --> Language Class Initialized
INFO - 2017-12-30 04:45:00 --> Loader Class Initialized
INFO - 2017-12-30 04:45:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:45:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:45:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:45:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Controller Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:45:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:45:00 --> Final output sent to browser
DEBUG - 2017-12-30 04:45:00 --> Total execution time: 0.1071
INFO - 2017-12-30 04:45:00 --> Config Class Initialized
INFO - 2017-12-30 04:45:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:45:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:45:00 --> URI Class Initialized
INFO - 2017-12-30 04:45:00 --> Router Class Initialized
INFO - 2017-12-30 04:45:00 --> Output Class Initialized
INFO - 2017-12-30 04:45:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:45:00 --> Input Class Initialized
INFO - 2017-12-30 04:45:00 --> Language Class Initialized
INFO - 2017-12-30 04:45:00 --> Loader Class Initialized
INFO - 2017-12-30 04:45:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:45:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:45:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:45:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Controller Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:45:00 --> Config Class Initialized
INFO - 2017-12-30 04:45:00 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:45:00 --> Utf8 Class Initialized
INFO - 2017-12-30 04:45:00 --> URI Class Initialized
INFO - 2017-12-30 04:45:00 --> Router Class Initialized
INFO - 2017-12-30 04:45:00 --> Output Class Initialized
INFO - 2017-12-30 04:45:00 --> Security Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:45:00 --> Input Class Initialized
INFO - 2017-12-30 04:45:00 --> Language Class Initialized
INFO - 2017-12-30 04:45:00 --> Loader Class Initialized
INFO - 2017-12-30 04:45:00 --> Helper loaded: url_helper
INFO - 2017-12-30 04:45:00 --> Helper loaded: form_helper
INFO - 2017-12-30 04:45:00 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:45:00 --> Form Validation Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Controller Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
INFO - 2017-12-30 04:45:00 --> Model Class Initialized
DEBUG - 2017-12-30 04:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:45:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:45:00 --> Final output sent to browser
DEBUG - 2017-12-30 04:45:00 --> Total execution time: 0.0596
INFO - 2017-12-30 04:46:11 --> Config Class Initialized
INFO - 2017-12-30 04:46:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:46:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:46:11 --> Utf8 Class Initialized
INFO - 2017-12-30 04:46:11 --> URI Class Initialized
INFO - 2017-12-30 04:46:11 --> Router Class Initialized
INFO - 2017-12-30 04:46:11 --> Output Class Initialized
INFO - 2017-12-30 04:46:11 --> Security Class Initialized
DEBUG - 2017-12-30 04:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:46:11 --> Input Class Initialized
INFO - 2017-12-30 04:46:11 --> Language Class Initialized
INFO - 2017-12-30 04:46:11 --> Loader Class Initialized
INFO - 2017-12-30 04:46:11 --> Helper loaded: url_helper
INFO - 2017-12-30 04:46:11 --> Helper loaded: form_helper
INFO - 2017-12-30 04:46:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:46:12 --> Form Validation Class Initialized
INFO - 2017-12-30 04:46:12 --> Model Class Initialized
INFO - 2017-12-30 04:46:12 --> Controller Class Initialized
INFO - 2017-12-30 04:46:12 --> Model Class Initialized
INFO - 2017-12-30 04:46:12 --> Model Class Initialized
INFO - 2017-12-30 04:46:12 --> Model Class Initialized
INFO - 2017-12-30 04:46:12 --> Model Class Initialized
DEBUG - 2017-12-30 04:46:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:46:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:46:12 --> Final output sent to browser
DEBUG - 2017-12-30 04:46:12 --> Total execution time: 0.0592
INFO - 2017-12-30 04:46:39 --> Config Class Initialized
INFO - 2017-12-30 04:46:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:46:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:46:39 --> Utf8 Class Initialized
INFO - 2017-12-30 04:46:39 --> URI Class Initialized
INFO - 2017-12-30 04:46:39 --> Router Class Initialized
INFO - 2017-12-30 04:46:39 --> Output Class Initialized
INFO - 2017-12-30 04:46:39 --> Security Class Initialized
DEBUG - 2017-12-30 04:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:46:39 --> Input Class Initialized
INFO - 2017-12-30 04:46:39 --> Language Class Initialized
INFO - 2017-12-30 04:46:39 --> Loader Class Initialized
INFO - 2017-12-30 04:46:39 --> Helper loaded: url_helper
INFO - 2017-12-30 04:46:39 --> Helper loaded: form_helper
INFO - 2017-12-30 04:46:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:46:39 --> Form Validation Class Initialized
INFO - 2017-12-30 04:46:39 --> Model Class Initialized
INFO - 2017-12-30 04:46:39 --> Controller Class Initialized
INFO - 2017-12-30 04:46:39 --> Model Class Initialized
INFO - 2017-12-30 04:46:39 --> Model Class Initialized
INFO - 2017-12-30 04:46:39 --> Model Class Initialized
INFO - 2017-12-30 04:46:39 --> Model Class Initialized
DEBUG - 2017-12-30 04:46:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:46:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:46:39 --> Final output sent to browser
DEBUG - 2017-12-30 04:46:39 --> Total execution time: 0.0601
INFO - 2017-12-30 04:46:53 --> Config Class Initialized
INFO - 2017-12-30 04:46:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:46:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:46:53 --> Utf8 Class Initialized
INFO - 2017-12-30 04:46:53 --> URI Class Initialized
INFO - 2017-12-30 04:46:53 --> Router Class Initialized
INFO - 2017-12-30 04:46:53 --> Output Class Initialized
INFO - 2017-12-30 04:46:53 --> Security Class Initialized
DEBUG - 2017-12-30 04:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:46:53 --> Input Class Initialized
INFO - 2017-12-30 04:46:53 --> Language Class Initialized
INFO - 2017-12-30 04:46:53 --> Loader Class Initialized
INFO - 2017-12-30 04:46:53 --> Helper loaded: url_helper
INFO - 2017-12-30 04:46:53 --> Helper loaded: form_helper
INFO - 2017-12-30 04:46:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:46:53 --> Form Validation Class Initialized
INFO - 2017-12-30 04:46:53 --> Model Class Initialized
INFO - 2017-12-30 04:46:53 --> Controller Class Initialized
INFO - 2017-12-30 04:46:53 --> Model Class Initialized
INFO - 2017-12-30 04:46:53 --> Model Class Initialized
INFO - 2017-12-30 04:46:53 --> Model Class Initialized
INFO - 2017-12-30 04:46:53 --> Model Class Initialized
DEBUG - 2017-12-30 04:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:46:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:46:53 --> Final output sent to browser
DEBUG - 2017-12-30 04:46:53 --> Total execution time: 0.0619
INFO - 2017-12-30 04:47:26 --> Config Class Initialized
INFO - 2017-12-30 04:47:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:47:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:47:26 --> Utf8 Class Initialized
INFO - 2017-12-30 04:47:26 --> URI Class Initialized
INFO - 2017-12-30 04:47:26 --> Router Class Initialized
INFO - 2017-12-30 04:47:26 --> Output Class Initialized
INFO - 2017-12-30 04:47:26 --> Security Class Initialized
DEBUG - 2017-12-30 04:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:47:26 --> Input Class Initialized
INFO - 2017-12-30 04:47:26 --> Language Class Initialized
INFO - 2017-12-30 04:47:26 --> Loader Class Initialized
INFO - 2017-12-30 04:47:26 --> Helper loaded: url_helper
INFO - 2017-12-30 04:47:26 --> Helper loaded: form_helper
INFO - 2017-12-30 04:47:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:47:26 --> Form Validation Class Initialized
INFO - 2017-12-30 04:47:26 --> Model Class Initialized
INFO - 2017-12-30 04:47:26 --> Controller Class Initialized
INFO - 2017-12-30 04:47:26 --> Model Class Initialized
INFO - 2017-12-30 04:47:26 --> Model Class Initialized
INFO - 2017-12-30 04:47:26 --> Model Class Initialized
INFO - 2017-12-30 04:47:26 --> Model Class Initialized
DEBUG - 2017-12-30 04:47:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:47:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:47:26 --> Final output sent to browser
DEBUG - 2017-12-30 04:47:26 --> Total execution time: 0.0675
INFO - 2017-12-30 04:48:16 --> Config Class Initialized
INFO - 2017-12-30 04:48:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:48:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:48:16 --> Utf8 Class Initialized
INFO - 2017-12-30 04:48:16 --> URI Class Initialized
INFO - 2017-12-30 04:48:16 --> Router Class Initialized
INFO - 2017-12-30 04:48:16 --> Output Class Initialized
INFO - 2017-12-30 04:48:16 --> Security Class Initialized
DEBUG - 2017-12-30 04:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:48:16 --> Input Class Initialized
INFO - 2017-12-30 04:48:16 --> Language Class Initialized
INFO - 2017-12-30 04:48:16 --> Loader Class Initialized
INFO - 2017-12-30 04:48:16 --> Helper loaded: url_helper
INFO - 2017-12-30 04:48:16 --> Helper loaded: form_helper
INFO - 2017-12-30 04:48:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:48:16 --> Form Validation Class Initialized
INFO - 2017-12-30 04:48:16 --> Model Class Initialized
INFO - 2017-12-30 04:48:16 --> Controller Class Initialized
INFO - 2017-12-30 04:48:16 --> Model Class Initialized
INFO - 2017-12-30 04:48:16 --> Model Class Initialized
INFO - 2017-12-30 04:48:16 --> Model Class Initialized
INFO - 2017-12-30 04:48:16 --> Model Class Initialized
DEBUG - 2017-12-30 04:48:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:48:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:48:16 --> Final output sent to browser
DEBUG - 2017-12-30 04:48:16 --> Total execution time: 0.0580
INFO - 2017-12-30 04:49:21 --> Config Class Initialized
INFO - 2017-12-30 04:49:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:21 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:21 --> URI Class Initialized
INFO - 2017-12-30 04:49:21 --> Router Class Initialized
INFO - 2017-12-30 04:49:21 --> Output Class Initialized
INFO - 2017-12-30 04:49:21 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:21 --> Input Class Initialized
INFO - 2017-12-30 04:49:21 --> Language Class Initialized
INFO - 2017-12-30 04:49:21 --> Loader Class Initialized
INFO - 2017-12-30 04:49:21 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:21 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:21 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:21 --> Model Class Initialized
INFO - 2017-12-30 04:49:21 --> Controller Class Initialized
INFO - 2017-12-30 04:49:21 --> Model Class Initialized
INFO - 2017-12-30 04:49:21 --> Model Class Initialized
INFO - 2017-12-30 04:49:21 --> Model Class Initialized
INFO - 2017-12-30 04:49:21 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:21 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:21 --> Total execution time: 0.0607
INFO - 2017-12-30 04:49:26 --> Config Class Initialized
INFO - 2017-12-30 04:49:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:26 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:26 --> URI Class Initialized
INFO - 2017-12-30 04:49:26 --> Router Class Initialized
INFO - 2017-12-30 04:49:26 --> Output Class Initialized
INFO - 2017-12-30 04:49:26 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:26 --> Input Class Initialized
INFO - 2017-12-30 04:49:26 --> Language Class Initialized
INFO - 2017-12-30 04:49:26 --> Loader Class Initialized
INFO - 2017-12-30 04:49:26 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:26 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:26 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:26 --> Model Class Initialized
INFO - 2017-12-30 04:49:26 --> Controller Class Initialized
INFO - 2017-12-30 04:49:26 --> Model Class Initialized
INFO - 2017-12-30 04:49:26 --> Model Class Initialized
INFO - 2017-12-30 04:49:26 --> Model Class Initialized
INFO - 2017-12-30 04:49:26 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:26 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:26 --> Total execution time: 0.0613
INFO - 2017-12-30 04:49:27 --> Config Class Initialized
INFO - 2017-12-30 04:49:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:27 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:27 --> URI Class Initialized
INFO - 2017-12-30 04:49:27 --> Router Class Initialized
INFO - 2017-12-30 04:49:27 --> Output Class Initialized
INFO - 2017-12-30 04:49:27 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:27 --> Input Class Initialized
INFO - 2017-12-30 04:49:27 --> Language Class Initialized
INFO - 2017-12-30 04:49:27 --> Loader Class Initialized
INFO - 2017-12-30 04:49:27 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:27 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:27 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:27 --> Model Class Initialized
INFO - 2017-12-30 04:49:27 --> Controller Class Initialized
INFO - 2017-12-30 04:49:27 --> Model Class Initialized
INFO - 2017-12-30 04:49:27 --> Model Class Initialized
INFO - 2017-12-30 04:49:27 --> Model Class Initialized
INFO - 2017-12-30 04:49:27 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:27 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:27 --> Total execution time: 0.0614
INFO - 2017-12-30 04:49:29 --> Config Class Initialized
INFO - 2017-12-30 04:49:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:29 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:29 --> URI Class Initialized
INFO - 2017-12-30 04:49:29 --> Router Class Initialized
INFO - 2017-12-30 04:49:29 --> Output Class Initialized
INFO - 2017-12-30 04:49:29 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:29 --> Input Class Initialized
INFO - 2017-12-30 04:49:29 --> Language Class Initialized
INFO - 2017-12-30 04:49:29 --> Loader Class Initialized
INFO - 2017-12-30 04:49:29 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:29 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:29 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:29 --> Model Class Initialized
INFO - 2017-12-30 04:49:29 --> Controller Class Initialized
INFO - 2017-12-30 04:49:29 --> Model Class Initialized
INFO - 2017-12-30 04:49:29 --> Model Class Initialized
INFO - 2017-12-30 04:49:29 --> Model Class Initialized
INFO - 2017-12-30 04:49:29 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:29 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:29 --> Total execution time: 0.0501
INFO - 2017-12-30 04:49:33 --> Config Class Initialized
INFO - 2017-12-30 04:49:33 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:33 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:33 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:33 --> URI Class Initialized
INFO - 2017-12-30 04:49:33 --> Router Class Initialized
INFO - 2017-12-30 04:49:33 --> Output Class Initialized
INFO - 2017-12-30 04:49:33 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:33 --> Input Class Initialized
INFO - 2017-12-30 04:49:33 --> Language Class Initialized
INFO - 2017-12-30 04:49:33 --> Loader Class Initialized
INFO - 2017-12-30 04:49:33 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:33 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:33 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:33 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Controller Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:33 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:33 --> Total execution time: 0.0602
INFO - 2017-12-30 04:49:33 --> Config Class Initialized
INFO - 2017-12-30 04:49:33 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:49:33 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:49:33 --> Utf8 Class Initialized
INFO - 2017-12-30 04:49:33 --> URI Class Initialized
INFO - 2017-12-30 04:49:33 --> Router Class Initialized
INFO - 2017-12-30 04:49:33 --> Output Class Initialized
INFO - 2017-12-30 04:49:33 --> Security Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:49:33 --> Input Class Initialized
INFO - 2017-12-30 04:49:33 --> Language Class Initialized
INFO - 2017-12-30 04:49:33 --> Loader Class Initialized
INFO - 2017-12-30 04:49:33 --> Helper loaded: url_helper
INFO - 2017-12-30 04:49:33 --> Helper loaded: form_helper
INFO - 2017-12-30 04:49:33 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:49:33 --> Form Validation Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Controller Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
INFO - 2017-12-30 04:49:33 --> Model Class Initialized
DEBUG - 2017-12-30 04:49:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:49:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:49:33 --> Final output sent to browser
DEBUG - 2017-12-30 04:49:33 --> Total execution time: 0.0580
INFO - 2017-12-30 04:53:32 --> Config Class Initialized
INFO - 2017-12-30 04:53:32 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:53:32 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:53:32 --> Utf8 Class Initialized
INFO - 2017-12-30 04:53:32 --> URI Class Initialized
INFO - 2017-12-30 04:53:32 --> Router Class Initialized
INFO - 2017-12-30 04:53:32 --> Output Class Initialized
INFO - 2017-12-30 04:53:32 --> Security Class Initialized
DEBUG - 2017-12-30 04:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:53:32 --> Input Class Initialized
INFO - 2017-12-30 04:53:32 --> Language Class Initialized
INFO - 2017-12-30 04:53:32 --> Loader Class Initialized
INFO - 2017-12-30 04:53:32 --> Helper loaded: url_helper
INFO - 2017-12-30 04:53:32 --> Helper loaded: form_helper
INFO - 2017-12-30 04:53:32 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:53:32 --> Form Validation Class Initialized
INFO - 2017-12-30 04:53:32 --> Model Class Initialized
INFO - 2017-12-30 04:53:32 --> Controller Class Initialized
INFO - 2017-12-30 04:53:32 --> Model Class Initialized
INFO - 2017-12-30 04:53:32 --> Model Class Initialized
INFO - 2017-12-30 04:53:32 --> Model Class Initialized
INFO - 2017-12-30 04:53:32 --> Model Class Initialized
DEBUG - 2017-12-30 04:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:53:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:53:32 --> Final output sent to browser
DEBUG - 2017-12-30 04:53:32 --> Total execution time: 0.0626
INFO - 2017-12-30 04:55:15 --> Config Class Initialized
INFO - 2017-12-30 04:55:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:55:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:55:15 --> Utf8 Class Initialized
INFO - 2017-12-30 04:55:15 --> URI Class Initialized
INFO - 2017-12-30 04:55:15 --> Router Class Initialized
INFO - 2017-12-30 04:55:15 --> Output Class Initialized
INFO - 2017-12-30 04:55:15 --> Security Class Initialized
DEBUG - 2017-12-30 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:55:15 --> Input Class Initialized
INFO - 2017-12-30 04:55:15 --> Language Class Initialized
INFO - 2017-12-30 04:55:15 --> Loader Class Initialized
INFO - 2017-12-30 04:55:15 --> Helper loaded: url_helper
INFO - 2017-12-30 04:55:15 --> Helper loaded: form_helper
INFO - 2017-12-30 04:55:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:55:15 --> Form Validation Class Initialized
INFO - 2017-12-30 04:55:15 --> Model Class Initialized
INFO - 2017-12-30 04:55:15 --> Controller Class Initialized
INFO - 2017-12-30 04:55:15 --> Model Class Initialized
INFO - 2017-12-30 04:55:15 --> Model Class Initialized
INFO - 2017-12-30 04:55:15 --> Model Class Initialized
INFO - 2017-12-30 04:55:15 --> Model Class Initialized
DEBUG - 2017-12-30 04:55:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:55:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:55:15 --> Final output sent to browser
DEBUG - 2017-12-30 04:55:15 --> Total execution time: 0.0511
INFO - 2017-12-30 04:55:35 --> Config Class Initialized
INFO - 2017-12-30 04:55:35 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:55:35 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:55:35 --> Utf8 Class Initialized
INFO - 2017-12-30 04:55:35 --> URI Class Initialized
INFO - 2017-12-30 04:55:35 --> Router Class Initialized
INFO - 2017-12-30 04:55:35 --> Output Class Initialized
INFO - 2017-12-30 04:55:35 --> Security Class Initialized
DEBUG - 2017-12-30 04:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:55:35 --> Input Class Initialized
INFO - 2017-12-30 04:55:35 --> Language Class Initialized
INFO - 2017-12-30 04:55:35 --> Loader Class Initialized
INFO - 2017-12-30 04:55:35 --> Helper loaded: url_helper
INFO - 2017-12-30 04:55:35 --> Helper loaded: form_helper
INFO - 2017-12-30 04:55:35 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:55:35 --> Form Validation Class Initialized
INFO - 2017-12-30 04:55:35 --> Model Class Initialized
INFO - 2017-12-30 04:55:35 --> Controller Class Initialized
INFO - 2017-12-30 04:55:35 --> Model Class Initialized
INFO - 2017-12-30 04:55:35 --> Model Class Initialized
INFO - 2017-12-30 04:55:35 --> Model Class Initialized
INFO - 2017-12-30 04:55:35 --> Model Class Initialized
DEBUG - 2017-12-30 04:55:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:55:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:55:35 --> Final output sent to browser
DEBUG - 2017-12-30 04:55:35 --> Total execution time: 0.0503
INFO - 2017-12-30 04:55:45 --> Config Class Initialized
INFO - 2017-12-30 04:55:45 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:55:45 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:55:45 --> Utf8 Class Initialized
INFO - 2017-12-30 04:55:45 --> URI Class Initialized
INFO - 2017-12-30 04:55:45 --> Router Class Initialized
INFO - 2017-12-30 04:55:45 --> Output Class Initialized
INFO - 2017-12-30 04:55:45 --> Security Class Initialized
DEBUG - 2017-12-30 04:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:55:45 --> Input Class Initialized
INFO - 2017-12-30 04:55:45 --> Language Class Initialized
INFO - 2017-12-30 04:55:45 --> Loader Class Initialized
INFO - 2017-12-30 04:55:45 --> Helper loaded: url_helper
INFO - 2017-12-30 04:55:45 --> Helper loaded: form_helper
INFO - 2017-12-30 04:55:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:55:45 --> Form Validation Class Initialized
INFO - 2017-12-30 04:55:45 --> Model Class Initialized
INFO - 2017-12-30 04:55:45 --> Controller Class Initialized
INFO - 2017-12-30 04:55:45 --> Model Class Initialized
INFO - 2017-12-30 04:55:45 --> Model Class Initialized
INFO - 2017-12-30 04:55:45 --> Model Class Initialized
INFO - 2017-12-30 04:55:45 --> Model Class Initialized
DEBUG - 2017-12-30 04:55:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:55:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:55:45 --> Final output sent to browser
DEBUG - 2017-12-30 04:55:45 --> Total execution time: 0.0535
INFO - 2017-12-30 04:56:33 --> Config Class Initialized
INFO - 2017-12-30 04:56:33 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:56:33 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:56:33 --> Utf8 Class Initialized
INFO - 2017-12-30 04:56:33 --> URI Class Initialized
INFO - 2017-12-30 04:56:33 --> Router Class Initialized
INFO - 2017-12-30 04:56:33 --> Output Class Initialized
INFO - 2017-12-30 04:56:33 --> Security Class Initialized
DEBUG - 2017-12-30 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:56:33 --> Input Class Initialized
INFO - 2017-12-30 04:56:33 --> Language Class Initialized
INFO - 2017-12-30 04:56:33 --> Loader Class Initialized
INFO - 2017-12-30 04:56:33 --> Helper loaded: url_helper
INFO - 2017-12-30 04:56:33 --> Helper loaded: form_helper
INFO - 2017-12-30 04:56:33 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:56:33 --> Form Validation Class Initialized
INFO - 2017-12-30 04:56:33 --> Model Class Initialized
INFO - 2017-12-30 04:56:33 --> Controller Class Initialized
INFO - 2017-12-30 04:56:33 --> Model Class Initialized
INFO - 2017-12-30 04:56:33 --> Model Class Initialized
INFO - 2017-12-30 04:56:33 --> Model Class Initialized
INFO - 2017-12-30 04:56:33 --> Model Class Initialized
DEBUG - 2017-12-30 04:56:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:56:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:56:33 --> Final output sent to browser
DEBUG - 2017-12-30 04:56:33 --> Total execution time: 0.0620
INFO - 2017-12-30 04:56:49 --> Config Class Initialized
INFO - 2017-12-30 04:56:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 04:56:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 04:56:49 --> Utf8 Class Initialized
INFO - 2017-12-30 04:56:49 --> URI Class Initialized
INFO - 2017-12-30 04:56:49 --> Router Class Initialized
INFO - 2017-12-30 04:56:49 --> Output Class Initialized
INFO - 2017-12-30 04:56:49 --> Security Class Initialized
DEBUG - 2017-12-30 04:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 04:56:49 --> Input Class Initialized
INFO - 2017-12-30 04:56:49 --> Language Class Initialized
INFO - 2017-12-30 04:56:49 --> Loader Class Initialized
INFO - 2017-12-30 04:56:49 --> Helper loaded: url_helper
INFO - 2017-12-30 04:56:49 --> Helper loaded: form_helper
INFO - 2017-12-30 04:56:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 04:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 04:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 04:56:49 --> Form Validation Class Initialized
INFO - 2017-12-30 04:56:49 --> Model Class Initialized
INFO - 2017-12-30 04:56:49 --> Controller Class Initialized
INFO - 2017-12-30 04:56:49 --> Model Class Initialized
INFO - 2017-12-30 04:56:49 --> Model Class Initialized
INFO - 2017-12-30 04:56:49 --> Model Class Initialized
INFO - 2017-12-30 04:56:49 --> Model Class Initialized
DEBUG - 2017-12-30 04:56:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 04:56:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 04:56:49 --> Final output sent to browser
DEBUG - 2017-12-30 04:56:49 --> Total execution time: 0.0751
INFO - 2017-12-30 05:05:17 --> Config Class Initialized
INFO - 2017-12-30 05:05:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:05:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:05:17 --> Utf8 Class Initialized
INFO - 2017-12-30 05:05:17 --> URI Class Initialized
INFO - 2017-12-30 05:05:17 --> Router Class Initialized
INFO - 2017-12-30 05:05:17 --> Output Class Initialized
INFO - 2017-12-30 05:05:17 --> Security Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:05:17 --> Input Class Initialized
INFO - 2017-12-30 05:05:17 --> Language Class Initialized
INFO - 2017-12-30 05:05:17 --> Loader Class Initialized
INFO - 2017-12-30 05:05:17 --> Helper loaded: url_helper
INFO - 2017-12-30 05:05:17 --> Helper loaded: form_helper
INFO - 2017-12-30 05:05:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:05:17 --> Form Validation Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Controller Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:05:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:05:17 --> Final output sent to browser
DEBUG - 2017-12-30 05:05:17 --> Total execution time: 0.0524
INFO - 2017-12-30 05:05:17 --> Config Class Initialized
INFO - 2017-12-30 05:05:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:05:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:05:17 --> Utf8 Class Initialized
INFO - 2017-12-30 05:05:17 --> URI Class Initialized
INFO - 2017-12-30 05:05:17 --> Router Class Initialized
INFO - 2017-12-30 05:05:17 --> Output Class Initialized
INFO - 2017-12-30 05:05:17 --> Security Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:05:17 --> Input Class Initialized
INFO - 2017-12-30 05:05:17 --> Language Class Initialized
INFO - 2017-12-30 05:05:17 --> Loader Class Initialized
INFO - 2017-12-30 05:05:17 --> Helper loaded: url_helper
INFO - 2017-12-30 05:05:17 --> Helper loaded: form_helper
INFO - 2017-12-30 05:05:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:05:17 --> Form Validation Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Controller Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
INFO - 2017-12-30 05:05:17 --> Model Class Initialized
DEBUG - 2017-12-30 05:05:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:16 --> Config Class Initialized
INFO - 2017-12-30 05:06:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:16 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:16 --> URI Class Initialized
INFO - 2017-12-30 05:06:16 --> Router Class Initialized
INFO - 2017-12-30 05:06:16 --> Output Class Initialized
INFO - 2017-12-30 05:06:16 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:16 --> Input Class Initialized
INFO - 2017-12-30 05:06:16 --> Language Class Initialized
INFO - 2017-12-30 05:06:16 --> Loader Class Initialized
INFO - 2017-12-30 05:06:16 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:16 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:16 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Controller Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:06:16 --> Final output sent to browser
DEBUG - 2017-12-30 05:06:16 --> Total execution time: 0.0538
INFO - 2017-12-30 05:06:16 --> Config Class Initialized
INFO - 2017-12-30 05:06:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:16 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:16 --> URI Class Initialized
INFO - 2017-12-30 05:06:16 --> Router Class Initialized
INFO - 2017-12-30 05:06:16 --> Output Class Initialized
INFO - 2017-12-30 05:06:16 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:16 --> Input Class Initialized
INFO - 2017-12-30 05:06:16 --> Language Class Initialized
INFO - 2017-12-30 05:06:16 --> Loader Class Initialized
INFO - 2017-12-30 05:06:16 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:16 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:16 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Controller Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
INFO - 2017-12-30 05:06:16 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:27 --> Config Class Initialized
INFO - 2017-12-30 05:06:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:27 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:27 --> URI Class Initialized
INFO - 2017-12-30 05:06:27 --> Router Class Initialized
INFO - 2017-12-30 05:06:27 --> Output Class Initialized
INFO - 2017-12-30 05:06:27 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:27 --> Input Class Initialized
INFO - 2017-12-30 05:06:27 --> Language Class Initialized
INFO - 2017-12-30 05:06:27 --> Loader Class Initialized
INFO - 2017-12-30 05:06:27 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:27 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:27 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:27 --> Model Class Initialized
INFO - 2017-12-30 05:06:27 --> Controller Class Initialized
INFO - 2017-12-30 05:06:27 --> Model Class Initialized
INFO - 2017-12-30 05:06:27 --> Model Class Initialized
INFO - 2017-12-30 05:06:27 --> Model Class Initialized
INFO - 2017-12-30 05:06:27 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:30 --> Config Class Initialized
INFO - 2017-12-30 05:06:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:30 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:30 --> URI Class Initialized
INFO - 2017-12-30 05:06:30 --> Router Class Initialized
INFO - 2017-12-30 05:06:30 --> Output Class Initialized
INFO - 2017-12-30 05:06:30 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:30 --> Input Class Initialized
INFO - 2017-12-30 05:06:30 --> Language Class Initialized
INFO - 2017-12-30 05:06:30 --> Loader Class Initialized
INFO - 2017-12-30 05:06:30 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:30 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:30 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:30 --> Model Class Initialized
INFO - 2017-12-30 05:06:30 --> Controller Class Initialized
INFO - 2017-12-30 05:06:30 --> Model Class Initialized
INFO - 2017-12-30 05:06:30 --> Model Class Initialized
INFO - 2017-12-30 05:06:30 --> Model Class Initialized
INFO - 2017-12-30 05:06:30 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:32 --> Config Class Initialized
INFO - 2017-12-30 05:06:32 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:32 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:32 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:32 --> URI Class Initialized
INFO - 2017-12-30 05:06:32 --> Router Class Initialized
INFO - 2017-12-30 05:06:32 --> Output Class Initialized
INFO - 2017-12-30 05:06:32 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:32 --> Input Class Initialized
INFO - 2017-12-30 05:06:32 --> Language Class Initialized
INFO - 2017-12-30 05:06:32 --> Loader Class Initialized
INFO - 2017-12-30 05:06:32 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:32 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:32 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:32 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:32 --> Model Class Initialized
INFO - 2017-12-30 05:06:32 --> Controller Class Initialized
INFO - 2017-12-30 05:06:32 --> Model Class Initialized
INFO - 2017-12-30 05:06:32 --> Model Class Initialized
INFO - 2017-12-30 05:06:32 --> Model Class Initialized
INFO - 2017-12-30 05:06:32 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:39 --> Config Class Initialized
INFO - 2017-12-30 05:06:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:39 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:39 --> URI Class Initialized
INFO - 2017-12-30 05:06:39 --> Router Class Initialized
INFO - 2017-12-30 05:06:39 --> Output Class Initialized
INFO - 2017-12-30 05:06:39 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:39 --> Input Class Initialized
INFO - 2017-12-30 05:06:39 --> Language Class Initialized
INFO - 2017-12-30 05:06:39 --> Loader Class Initialized
INFO - 2017-12-30 05:06:39 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:39 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:39 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:39 --> Model Class Initialized
INFO - 2017-12-30 05:06:39 --> Controller Class Initialized
INFO - 2017-12-30 05:06:39 --> Model Class Initialized
INFO - 2017-12-30 05:06:39 --> Model Class Initialized
INFO - 2017-12-30 05:06:39 --> Model Class Initialized
INFO - 2017-12-30 05:06:39 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:42 --> Config Class Initialized
INFO - 2017-12-30 05:06:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:42 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:42 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:42 --> URI Class Initialized
INFO - 2017-12-30 05:06:42 --> Router Class Initialized
INFO - 2017-12-30 05:06:42 --> Output Class Initialized
INFO - 2017-12-30 05:06:42 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:42 --> Input Class Initialized
INFO - 2017-12-30 05:06:42 --> Language Class Initialized
INFO - 2017-12-30 05:06:42 --> Loader Class Initialized
INFO - 2017-12-30 05:06:42 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:42 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:42 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:42 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:42 --> Model Class Initialized
INFO - 2017-12-30 05:06:42 --> Controller Class Initialized
INFO - 2017-12-30 05:06:42 --> Model Class Initialized
INFO - 2017-12-30 05:06:42 --> Model Class Initialized
INFO - 2017-12-30 05:06:42 --> Model Class Initialized
INFO - 2017-12-30 05:06:42 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:45 --> Config Class Initialized
INFO - 2017-12-30 05:06:45 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:45 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:45 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:45 --> URI Class Initialized
INFO - 2017-12-30 05:06:45 --> Router Class Initialized
INFO - 2017-12-30 05:06:45 --> Output Class Initialized
INFO - 2017-12-30 05:06:45 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:45 --> Input Class Initialized
INFO - 2017-12-30 05:06:45 --> Language Class Initialized
INFO - 2017-12-30 05:06:45 --> Loader Class Initialized
INFO - 2017-12-30 05:06:45 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:45 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:45 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:45 --> Model Class Initialized
INFO - 2017-12-30 05:06:45 --> Controller Class Initialized
INFO - 2017-12-30 05:06:45 --> Model Class Initialized
INFO - 2017-12-30 05:06:45 --> Model Class Initialized
INFO - 2017-12-30 05:06:45 --> Model Class Initialized
INFO - 2017-12-30 05:06:45 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:46 --> Config Class Initialized
INFO - 2017-12-30 05:06:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:46 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:46 --> URI Class Initialized
INFO - 2017-12-30 05:06:46 --> Router Class Initialized
INFO - 2017-12-30 05:06:46 --> Output Class Initialized
INFO - 2017-12-30 05:06:46 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:46 --> Input Class Initialized
INFO - 2017-12-30 05:06:46 --> Language Class Initialized
INFO - 2017-12-30 05:06:46 --> Loader Class Initialized
INFO - 2017-12-30 05:06:46 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:46 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:46 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:46 --> Model Class Initialized
INFO - 2017-12-30 05:06:46 --> Controller Class Initialized
INFO - 2017-12-30 05:06:46 --> Model Class Initialized
INFO - 2017-12-30 05:06:46 --> Model Class Initialized
INFO - 2017-12-30 05:06:46 --> Model Class Initialized
INFO - 2017-12-30 05:06:46 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:47 --> Config Class Initialized
INFO - 2017-12-30 05:06:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:47 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:47 --> URI Class Initialized
INFO - 2017-12-30 05:06:47 --> Router Class Initialized
INFO - 2017-12-30 05:06:47 --> Output Class Initialized
INFO - 2017-12-30 05:06:47 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:47 --> Input Class Initialized
INFO - 2017-12-30 05:06:47 --> Language Class Initialized
INFO - 2017-12-30 05:06:47 --> Loader Class Initialized
INFO - 2017-12-30 05:06:47 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:47 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:47 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:47 --> Model Class Initialized
INFO - 2017-12-30 05:06:47 --> Controller Class Initialized
INFO - 2017-12-30 05:06:47 --> Model Class Initialized
INFO - 2017-12-30 05:06:47 --> Model Class Initialized
INFO - 2017-12-30 05:06:47 --> Model Class Initialized
INFO - 2017-12-30 05:06:47 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:48 --> Config Class Initialized
INFO - 2017-12-30 05:06:48 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:48 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:48 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:48 --> URI Class Initialized
INFO - 2017-12-30 05:06:48 --> Router Class Initialized
INFO - 2017-12-30 05:06:48 --> Output Class Initialized
INFO - 2017-12-30 05:06:48 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:48 --> Input Class Initialized
INFO - 2017-12-30 05:06:48 --> Language Class Initialized
INFO - 2017-12-30 05:06:48 --> Loader Class Initialized
INFO - 2017-12-30 05:06:48 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:48 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:48 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:48 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:48 --> Model Class Initialized
INFO - 2017-12-30 05:06:48 --> Controller Class Initialized
INFO - 2017-12-30 05:06:48 --> Model Class Initialized
INFO - 2017-12-30 05:06:48 --> Model Class Initialized
INFO - 2017-12-30 05:06:48 --> Model Class Initialized
INFO - 2017-12-30 05:06:48 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:49 --> Config Class Initialized
INFO - 2017-12-30 05:06:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:49 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:49 --> URI Class Initialized
INFO - 2017-12-30 05:06:49 --> Router Class Initialized
INFO - 2017-12-30 05:06:49 --> Output Class Initialized
INFO - 2017-12-30 05:06:49 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:49 --> Input Class Initialized
INFO - 2017-12-30 05:06:49 --> Language Class Initialized
INFO - 2017-12-30 05:06:49 --> Loader Class Initialized
INFO - 2017-12-30 05:06:49 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:49 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:49 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Controller Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:49 --> Config Class Initialized
INFO - 2017-12-30 05:06:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:49 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:49 --> URI Class Initialized
INFO - 2017-12-30 05:06:49 --> Router Class Initialized
INFO - 2017-12-30 05:06:49 --> Output Class Initialized
INFO - 2017-12-30 05:06:49 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:49 --> Input Class Initialized
INFO - 2017-12-30 05:06:49 --> Language Class Initialized
INFO - 2017-12-30 05:06:49 --> Loader Class Initialized
INFO - 2017-12-30 05:06:49 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:49 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:49 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Controller Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
INFO - 2017-12-30 05:06:49 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:50 --> Config Class Initialized
INFO - 2017-12-30 05:06:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:50 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:50 --> URI Class Initialized
INFO - 2017-12-30 05:06:50 --> Router Class Initialized
INFO - 2017-12-30 05:06:50 --> Output Class Initialized
INFO - 2017-12-30 05:06:50 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:50 --> Input Class Initialized
INFO - 2017-12-30 05:06:50 --> Language Class Initialized
INFO - 2017-12-30 05:06:50 --> Loader Class Initialized
INFO - 2017-12-30 05:06:50 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:50 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:50 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:50 --> Model Class Initialized
INFO - 2017-12-30 05:06:50 --> Controller Class Initialized
INFO - 2017-12-30 05:06:50 --> Model Class Initialized
INFO - 2017-12-30 05:06:50 --> Model Class Initialized
INFO - 2017-12-30 05:06:50 --> Model Class Initialized
INFO - 2017-12-30 05:06:50 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:54 --> Config Class Initialized
INFO - 2017-12-30 05:06:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:54 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:54 --> URI Class Initialized
INFO - 2017-12-30 05:06:54 --> Router Class Initialized
INFO - 2017-12-30 05:06:54 --> Output Class Initialized
INFO - 2017-12-30 05:06:54 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:54 --> Input Class Initialized
INFO - 2017-12-30 05:06:54 --> Language Class Initialized
INFO - 2017-12-30 05:06:54 --> Loader Class Initialized
INFO - 2017-12-30 05:06:55 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:55 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:55 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:55 --> Model Class Initialized
INFO - 2017-12-30 05:06:55 --> Controller Class Initialized
INFO - 2017-12-30 05:06:55 --> Model Class Initialized
INFO - 2017-12-30 05:06:55 --> Model Class Initialized
INFO - 2017-12-30 05:06:55 --> Model Class Initialized
INFO - 2017-12-30 05:06:55 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:55 --> Config Class Initialized
INFO - 2017-12-30 05:06:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:55 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:55 --> URI Class Initialized
INFO - 2017-12-30 05:06:55 --> Router Class Initialized
INFO - 2017-12-30 05:06:55 --> Output Class Initialized
INFO - 2017-12-30 05:06:55 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:55 --> Input Class Initialized
INFO - 2017-12-30 05:06:55 --> Language Class Initialized
INFO - 2017-12-30 05:06:55 --> Loader Class Initialized
INFO - 2017-12-30 05:06:55 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:55 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:56 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Controller Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:56 --> Config Class Initialized
INFO - 2017-12-30 05:06:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:56 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:56 --> URI Class Initialized
INFO - 2017-12-30 05:06:56 --> Router Class Initialized
INFO - 2017-12-30 05:06:56 --> Output Class Initialized
INFO - 2017-12-30 05:06:56 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:56 --> Input Class Initialized
INFO - 2017-12-30 05:06:56 --> Language Class Initialized
INFO - 2017-12-30 05:06:56 --> Loader Class Initialized
INFO - 2017-12-30 05:06:56 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:56 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:56 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Controller Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
INFO - 2017-12-30 05:06:56 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:06:58 --> Config Class Initialized
INFO - 2017-12-30 05:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:06:58 --> Utf8 Class Initialized
INFO - 2017-12-30 05:06:58 --> URI Class Initialized
INFO - 2017-12-30 05:06:58 --> Router Class Initialized
INFO - 2017-12-30 05:06:58 --> Output Class Initialized
INFO - 2017-12-30 05:06:58 --> Security Class Initialized
DEBUG - 2017-12-30 05:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:06:58 --> Input Class Initialized
INFO - 2017-12-30 05:06:58 --> Language Class Initialized
INFO - 2017-12-30 05:06:58 --> Loader Class Initialized
INFO - 2017-12-30 05:06:58 --> Helper loaded: url_helper
INFO - 2017-12-30 05:06:58 --> Helper loaded: form_helper
INFO - 2017-12-30 05:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:06:58 --> Form Validation Class Initialized
INFO - 2017-12-30 05:06:58 --> Model Class Initialized
INFO - 2017-12-30 05:06:58 --> Controller Class Initialized
INFO - 2017-12-30 05:06:58 --> Model Class Initialized
INFO - 2017-12-30 05:06:58 --> Model Class Initialized
INFO - 2017-12-30 05:06:58 --> Model Class Initialized
INFO - 2017-12-30 05:06:58 --> Model Class Initialized
DEBUG - 2017-12-30 05:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:03 --> Config Class Initialized
INFO - 2017-12-30 05:07:03 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:03 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:03 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:03 --> URI Class Initialized
INFO - 2017-12-30 05:07:03 --> Router Class Initialized
INFO - 2017-12-30 05:07:03 --> Output Class Initialized
INFO - 2017-12-30 05:07:03 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:03 --> Input Class Initialized
INFO - 2017-12-30 05:07:03 --> Language Class Initialized
INFO - 2017-12-30 05:07:03 --> Loader Class Initialized
INFO - 2017-12-30 05:07:03 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:03 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:03 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:03 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:03 --> Model Class Initialized
INFO - 2017-12-30 05:07:03 --> Controller Class Initialized
INFO - 2017-12-30 05:07:03 --> Model Class Initialized
INFO - 2017-12-30 05:07:03 --> Model Class Initialized
INFO - 2017-12-30 05:07:03 --> Model Class Initialized
INFO - 2017-12-30 05:07:03 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:04 --> Config Class Initialized
INFO - 2017-12-30 05:07:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:04 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:04 --> URI Class Initialized
INFO - 2017-12-30 05:07:04 --> Router Class Initialized
INFO - 2017-12-30 05:07:04 --> Output Class Initialized
INFO - 2017-12-30 05:07:04 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:04 --> Input Class Initialized
INFO - 2017-12-30 05:07:04 --> Language Class Initialized
INFO - 2017-12-30 05:07:04 --> Loader Class Initialized
INFO - 2017-12-30 05:07:04 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:04 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:04 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:04 --> Model Class Initialized
INFO - 2017-12-30 05:07:04 --> Controller Class Initialized
INFO - 2017-12-30 05:07:04 --> Model Class Initialized
INFO - 2017-12-30 05:07:04 --> Model Class Initialized
INFO - 2017-12-30 05:07:04 --> Model Class Initialized
INFO - 2017-12-30 05:07:04 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:05 --> Config Class Initialized
INFO - 2017-12-30 05:07:05 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:05 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:05 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:05 --> URI Class Initialized
INFO - 2017-12-30 05:07:05 --> Router Class Initialized
INFO - 2017-12-30 05:07:05 --> Output Class Initialized
INFO - 2017-12-30 05:07:05 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:05 --> Input Class Initialized
INFO - 2017-12-30 05:07:05 --> Language Class Initialized
INFO - 2017-12-30 05:07:05 --> Loader Class Initialized
INFO - 2017-12-30 05:07:05 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:05 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:05 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:05 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:05 --> Model Class Initialized
INFO - 2017-12-30 05:07:05 --> Controller Class Initialized
INFO - 2017-12-30 05:07:05 --> Model Class Initialized
INFO - 2017-12-30 05:07:05 --> Model Class Initialized
INFO - 2017-12-30 05:07:05 --> Model Class Initialized
INFO - 2017-12-30 05:07:05 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:06 --> Config Class Initialized
INFO - 2017-12-30 05:07:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:06 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:06 --> URI Class Initialized
INFO - 2017-12-30 05:07:06 --> Router Class Initialized
INFO - 2017-12-30 05:07:06 --> Output Class Initialized
INFO - 2017-12-30 05:07:06 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:06 --> Input Class Initialized
INFO - 2017-12-30 05:07:06 --> Language Class Initialized
INFO - 2017-12-30 05:07:06 --> Loader Class Initialized
INFO - 2017-12-30 05:07:06 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:06 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:06 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:06 --> Model Class Initialized
INFO - 2017-12-30 05:07:06 --> Controller Class Initialized
INFO - 2017-12-30 05:07:06 --> Model Class Initialized
INFO - 2017-12-30 05:07:06 --> Model Class Initialized
INFO - 2017-12-30 05:07:06 --> Model Class Initialized
INFO - 2017-12-30 05:07:06 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:42 --> Config Class Initialized
INFO - 2017-12-30 05:07:42 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:43 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:43 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:43 --> URI Class Initialized
INFO - 2017-12-30 05:07:43 --> Router Class Initialized
INFO - 2017-12-30 05:07:43 --> Output Class Initialized
INFO - 2017-12-30 05:07:43 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:43 --> Input Class Initialized
INFO - 2017-12-30 05:07:43 --> Language Class Initialized
INFO - 2017-12-30 05:07:43 --> Loader Class Initialized
INFO - 2017-12-30 05:07:43 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:43 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:43 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:43 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Controller Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:07:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:07:43 --> Final output sent to browser
DEBUG - 2017-12-30 05:07:43 --> Total execution time: 0.0727
INFO - 2017-12-30 05:07:43 --> Config Class Initialized
INFO - 2017-12-30 05:07:43 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:07:43 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:07:43 --> Utf8 Class Initialized
INFO - 2017-12-30 05:07:43 --> URI Class Initialized
INFO - 2017-12-30 05:07:43 --> Router Class Initialized
INFO - 2017-12-30 05:07:43 --> Output Class Initialized
INFO - 2017-12-30 05:07:43 --> Security Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:07:43 --> Input Class Initialized
INFO - 2017-12-30 05:07:43 --> Language Class Initialized
INFO - 2017-12-30 05:07:43 --> Loader Class Initialized
INFO - 2017-12-30 05:07:43 --> Helper loaded: url_helper
INFO - 2017-12-30 05:07:43 --> Helper loaded: form_helper
INFO - 2017-12-30 05:07:43 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:07:43 --> Form Validation Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Controller Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
INFO - 2017-12-30 05:07:43 --> Model Class Initialized
DEBUG - 2017-12-30 05:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:14:57 --> Config Class Initialized
INFO - 2017-12-30 05:14:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:14:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:14:57 --> Utf8 Class Initialized
INFO - 2017-12-30 05:14:57 --> URI Class Initialized
INFO - 2017-12-30 05:14:57 --> Router Class Initialized
INFO - 2017-12-30 05:14:57 --> Output Class Initialized
INFO - 2017-12-30 05:14:57 --> Security Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:14:57 --> Input Class Initialized
INFO - 2017-12-30 05:14:57 --> Language Class Initialized
INFO - 2017-12-30 05:14:57 --> Loader Class Initialized
INFO - 2017-12-30 05:14:57 --> Helper loaded: url_helper
INFO - 2017-12-30 05:14:57 --> Helper loaded: form_helper
INFO - 2017-12-30 05:14:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:14:57 --> Form Validation Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Controller Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:14:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:14:57 --> Final output sent to browser
DEBUG - 2017-12-30 05:14:57 --> Total execution time: 0.0550
INFO - 2017-12-30 05:14:57 --> Config Class Initialized
INFO - 2017-12-30 05:14:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:14:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:14:57 --> Utf8 Class Initialized
INFO - 2017-12-30 05:14:57 --> URI Class Initialized
INFO - 2017-12-30 05:14:57 --> Router Class Initialized
INFO - 2017-12-30 05:14:57 --> Output Class Initialized
INFO - 2017-12-30 05:14:57 --> Security Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:14:57 --> Input Class Initialized
INFO - 2017-12-30 05:14:57 --> Language Class Initialized
INFO - 2017-12-30 05:14:57 --> Loader Class Initialized
INFO - 2017-12-30 05:14:57 --> Helper loaded: url_helper
INFO - 2017-12-30 05:14:57 --> Helper loaded: form_helper
INFO - 2017-12-30 05:14:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:14:57 --> Form Validation Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Controller Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
INFO - 2017-12-30 05:14:57 --> Model Class Initialized
DEBUG - 2017-12-30 05:14:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:04 --> Config Class Initialized
INFO - 2017-12-30 05:15:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:15:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:15:04 --> Utf8 Class Initialized
INFO - 2017-12-30 05:15:04 --> URI Class Initialized
INFO - 2017-12-30 05:15:04 --> Router Class Initialized
INFO - 2017-12-30 05:15:04 --> Output Class Initialized
INFO - 2017-12-30 05:15:04 --> Security Class Initialized
DEBUG - 2017-12-30 05:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:15:04 --> Input Class Initialized
INFO - 2017-12-30 05:15:04 --> Language Class Initialized
INFO - 2017-12-30 05:15:04 --> Loader Class Initialized
INFO - 2017-12-30 05:15:04 --> Helper loaded: url_helper
INFO - 2017-12-30 05:15:04 --> Helper loaded: form_helper
INFO - 2017-12-30 05:15:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:15:04 --> Form Validation Class Initialized
INFO - 2017-12-30 05:15:04 --> Model Class Initialized
INFO - 2017-12-30 05:15:04 --> Controller Class Initialized
INFO - 2017-12-30 05:15:04 --> Model Class Initialized
INFO - 2017-12-30 05:15:04 --> Model Class Initialized
INFO - 2017-12-30 05:15:04 --> Model Class Initialized
INFO - 2017-12-30 05:15:04 --> Model Class Initialized
DEBUG - 2017-12-30 05:15:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:04 --> Final output sent to browser
DEBUG - 2017-12-30 05:15:04 --> Total execution time: 0.1317
INFO - 2017-12-30 05:15:12 --> Config Class Initialized
INFO - 2017-12-30 05:15:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:15:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:15:12 --> Utf8 Class Initialized
INFO - 2017-12-30 05:15:12 --> URI Class Initialized
INFO - 2017-12-30 05:15:12 --> Router Class Initialized
INFO - 2017-12-30 05:15:12 --> Output Class Initialized
INFO - 2017-12-30 05:15:12 --> Security Class Initialized
DEBUG - 2017-12-30 05:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:15:12 --> Input Class Initialized
INFO - 2017-12-30 05:15:12 --> Language Class Initialized
INFO - 2017-12-30 05:15:12 --> Loader Class Initialized
INFO - 2017-12-30 05:15:12 --> Helper loaded: url_helper
INFO - 2017-12-30 05:15:12 --> Helper loaded: form_helper
INFO - 2017-12-30 05:15:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:15:12 --> Form Validation Class Initialized
INFO - 2017-12-30 05:15:12 --> Model Class Initialized
INFO - 2017-12-30 05:15:12 --> Controller Class Initialized
INFO - 2017-12-30 05:15:12 --> Model Class Initialized
INFO - 2017-12-30 05:15:12 --> Model Class Initialized
INFO - 2017-12-30 05:15:12 --> Model Class Initialized
INFO - 2017-12-30 05:15:12 --> Model Class Initialized
DEBUG - 2017-12-30 05:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:12 --> Final output sent to browser
DEBUG - 2017-12-30 05:15:12 --> Total execution time: 0.1372
INFO - 2017-12-30 05:15:21 --> Config Class Initialized
INFO - 2017-12-30 05:15:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:15:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:15:21 --> Utf8 Class Initialized
INFO - 2017-12-30 05:15:21 --> URI Class Initialized
INFO - 2017-12-30 05:15:21 --> Router Class Initialized
INFO - 2017-12-30 05:15:21 --> Output Class Initialized
INFO - 2017-12-30 05:15:21 --> Security Class Initialized
DEBUG - 2017-12-30 05:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:15:21 --> Input Class Initialized
INFO - 2017-12-30 05:15:21 --> Language Class Initialized
INFO - 2017-12-30 05:15:21 --> Loader Class Initialized
INFO - 2017-12-30 05:15:21 --> Helper loaded: url_helper
INFO - 2017-12-30 05:15:21 --> Helper loaded: form_helper
INFO - 2017-12-30 05:15:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:15:21 --> Form Validation Class Initialized
INFO - 2017-12-30 05:15:21 --> Model Class Initialized
INFO - 2017-12-30 05:15:21 --> Controller Class Initialized
INFO - 2017-12-30 05:15:21 --> Model Class Initialized
INFO - 2017-12-30 05:15:21 --> Model Class Initialized
INFO - 2017-12-30 05:15:21 --> Model Class Initialized
INFO - 2017-12-30 05:15:21 --> Model Class Initialized
DEBUG - 2017-12-30 05:15:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:27 --> Config Class Initialized
INFO - 2017-12-30 05:15:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:15:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:15:27 --> Utf8 Class Initialized
INFO - 2017-12-30 05:15:27 --> URI Class Initialized
INFO - 2017-12-30 05:15:27 --> Router Class Initialized
INFO - 2017-12-30 05:15:27 --> Output Class Initialized
INFO - 2017-12-30 05:15:27 --> Security Class Initialized
DEBUG - 2017-12-30 05:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:15:27 --> Input Class Initialized
INFO - 2017-12-30 05:15:27 --> Language Class Initialized
INFO - 2017-12-30 05:15:27 --> Loader Class Initialized
INFO - 2017-12-30 05:15:27 --> Helper loaded: url_helper
INFO - 2017-12-30 05:15:27 --> Helper loaded: form_helper
INFO - 2017-12-30 05:15:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:15:27 --> Form Validation Class Initialized
INFO - 2017-12-30 05:15:27 --> Model Class Initialized
INFO - 2017-12-30 05:15:27 --> Controller Class Initialized
INFO - 2017-12-30 05:15:27 --> Model Class Initialized
INFO - 2017-12-30 05:15:27 --> Model Class Initialized
INFO - 2017-12-30 05:15:27 --> Model Class Initialized
INFO - 2017-12-30 05:15:27 --> Model Class Initialized
DEBUG - 2017-12-30 05:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:29 --> Config Class Initialized
INFO - 2017-12-30 05:15:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:15:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:15:29 --> Utf8 Class Initialized
INFO - 2017-12-30 05:15:29 --> URI Class Initialized
INFO - 2017-12-30 05:15:29 --> Router Class Initialized
INFO - 2017-12-30 05:15:29 --> Output Class Initialized
INFO - 2017-12-30 05:15:29 --> Security Class Initialized
DEBUG - 2017-12-30 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:15:29 --> Input Class Initialized
INFO - 2017-12-30 05:15:29 --> Language Class Initialized
INFO - 2017-12-30 05:15:29 --> Loader Class Initialized
INFO - 2017-12-30 05:15:29 --> Helper loaded: url_helper
INFO - 2017-12-30 05:15:29 --> Helper loaded: form_helper
INFO - 2017-12-30 05:15:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:15:29 --> Form Validation Class Initialized
INFO - 2017-12-30 05:15:29 --> Model Class Initialized
INFO - 2017-12-30 05:15:29 --> Controller Class Initialized
INFO - 2017-12-30 05:15:29 --> Model Class Initialized
INFO - 2017-12-30 05:15:29 --> Model Class Initialized
INFO - 2017-12-30 05:15:29 --> Model Class Initialized
INFO - 2017-12-30 05:15:29 --> Model Class Initialized
DEBUG - 2017-12-30 05:15:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:15:29 --> Final output sent to browser
DEBUG - 2017-12-30 05:15:29 --> Total execution time: 0.1378
INFO - 2017-12-30 05:20:27 --> Config Class Initialized
INFO - 2017-12-30 05:20:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:20:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:20:27 --> Utf8 Class Initialized
INFO - 2017-12-30 05:20:27 --> URI Class Initialized
INFO - 2017-12-30 05:20:27 --> Router Class Initialized
INFO - 2017-12-30 05:20:27 --> Output Class Initialized
INFO - 2017-12-30 05:20:27 --> Security Class Initialized
DEBUG - 2017-12-30 05:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:20:27 --> Input Class Initialized
INFO - 2017-12-30 05:20:27 --> Language Class Initialized
INFO - 2017-12-30 05:20:27 --> Loader Class Initialized
INFO - 2017-12-30 05:20:27 --> Helper loaded: url_helper
INFO - 2017-12-30 05:20:27 --> Helper loaded: form_helper
INFO - 2017-12-30 05:20:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:20:27 --> Form Validation Class Initialized
INFO - 2017-12-30 05:20:27 --> Model Class Initialized
INFO - 2017-12-30 05:20:27 --> Controller Class Initialized
INFO - 2017-12-30 05:20:27 --> Model Class Initialized
INFO - 2017-12-30 05:20:27 --> Model Class Initialized
INFO - 2017-12-30 05:20:27 --> Model Class Initialized
INFO - 2017-12-30 05:20:27 --> Model Class Initialized
DEBUG - 2017-12-30 05:20:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:20:27 --> Final output sent to browser
DEBUG - 2017-12-30 05:20:27 --> Total execution time: 0.1263
INFO - 2017-12-30 05:22:02 --> Config Class Initialized
INFO - 2017-12-30 05:22:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:22:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:22:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:22:02 --> URI Class Initialized
INFO - 2017-12-30 05:22:02 --> Router Class Initialized
INFO - 2017-12-30 05:22:02 --> Output Class Initialized
INFO - 2017-12-30 05:22:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:22:02 --> Input Class Initialized
INFO - 2017-12-30 05:22:02 --> Language Class Initialized
INFO - 2017-12-30 05:22:02 --> Loader Class Initialized
INFO - 2017-12-30 05:22:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:22:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:22:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:22:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Controller Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:22:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:22:02 --> Final output sent to browser
DEBUG - 2017-12-30 05:22:02 --> Total execution time: 0.0699
INFO - 2017-12-30 05:22:02 --> Config Class Initialized
INFO - 2017-12-30 05:22:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:22:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:22:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:22:02 --> URI Class Initialized
INFO - 2017-12-30 05:22:02 --> Router Class Initialized
INFO - 2017-12-30 05:22:02 --> Output Class Initialized
INFO - 2017-12-30 05:22:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:22:02 --> Input Class Initialized
INFO - 2017-12-30 05:22:02 --> Language Class Initialized
INFO - 2017-12-30 05:22:02 --> Loader Class Initialized
INFO - 2017-12-30 05:22:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:22:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:22:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:22:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Controller Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
INFO - 2017-12-30 05:22:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:25:20 --> Config Class Initialized
INFO - 2017-12-30 05:25:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:25:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:25:20 --> Utf8 Class Initialized
INFO - 2017-12-30 05:25:20 --> URI Class Initialized
INFO - 2017-12-30 05:25:20 --> Router Class Initialized
INFO - 2017-12-30 05:25:20 --> Output Class Initialized
INFO - 2017-12-30 05:25:20 --> Security Class Initialized
DEBUG - 2017-12-30 05:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:25:20 --> Input Class Initialized
INFO - 2017-12-30 05:25:20 --> Language Class Initialized
INFO - 2017-12-30 05:25:20 --> Loader Class Initialized
INFO - 2017-12-30 05:25:20 --> Helper loaded: url_helper
INFO - 2017-12-30 05:25:20 --> Helper loaded: form_helper
INFO - 2017-12-30 05:25:20 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:25:20 --> Form Validation Class Initialized
INFO - 2017-12-30 05:25:20 --> Model Class Initialized
INFO - 2017-12-30 05:25:20 --> Controller Class Initialized
INFO - 2017-12-30 05:25:20 --> Model Class Initialized
INFO - 2017-12-30 05:25:20 --> Model Class Initialized
INFO - 2017-12-30 05:25:20 --> Model Class Initialized
INFO - 2017-12-30 05:25:20 --> Model Class Initialized
DEBUG - 2017-12-30 05:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:25:20 --> Final output sent to browser
DEBUG - 2017-12-30 05:25:20 --> Total execution time: 0.1405
INFO - 2017-12-30 05:26:22 --> Config Class Initialized
INFO - 2017-12-30 05:26:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:22 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:22 --> URI Class Initialized
INFO - 2017-12-30 05:26:22 --> Router Class Initialized
INFO - 2017-12-30 05:26:22 --> Output Class Initialized
INFO - 2017-12-30 05:26:22 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:22 --> Input Class Initialized
INFO - 2017-12-30 05:26:22 --> Language Class Initialized
INFO - 2017-12-30 05:26:22 --> Loader Class Initialized
INFO - 2017-12-30 05:26:22 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:22 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:22 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:22 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Controller Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:26:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:26:22 --> Final output sent to browser
DEBUG - 2017-12-30 05:26:22 --> Total execution time: 0.0481
INFO - 2017-12-30 05:26:22 --> Config Class Initialized
INFO - 2017-12-30 05:26:22 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:22 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:22 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:22 --> URI Class Initialized
INFO - 2017-12-30 05:26:22 --> Router Class Initialized
INFO - 2017-12-30 05:26:22 --> Output Class Initialized
INFO - 2017-12-30 05:26:22 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:22 --> Input Class Initialized
INFO - 2017-12-30 05:26:22 --> Language Class Initialized
INFO - 2017-12-30 05:26:22 --> Loader Class Initialized
INFO - 2017-12-30 05:26:22 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:22 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:22 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:22 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Controller Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
INFO - 2017-12-30 05:26:22 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:26:23 --> Config Class Initialized
INFO - 2017-12-30 05:26:23 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:23 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:23 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:23 --> URI Class Initialized
INFO - 2017-12-30 05:26:23 --> Router Class Initialized
INFO - 2017-12-30 05:26:23 --> Output Class Initialized
INFO - 2017-12-30 05:26:23 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:23 --> Input Class Initialized
INFO - 2017-12-30 05:26:23 --> Language Class Initialized
INFO - 2017-12-30 05:26:23 --> Loader Class Initialized
INFO - 2017-12-30 05:26:23 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:23 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:23 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:23 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Controller Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:26:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:26:23 --> Final output sent to browser
DEBUG - 2017-12-30 05:26:23 --> Total execution time: 0.0661
INFO - 2017-12-30 05:26:23 --> Config Class Initialized
INFO - 2017-12-30 05:26:23 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:23 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:23 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:23 --> URI Class Initialized
INFO - 2017-12-30 05:26:23 --> Router Class Initialized
INFO - 2017-12-30 05:26:23 --> Output Class Initialized
INFO - 2017-12-30 05:26:23 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:23 --> Input Class Initialized
INFO - 2017-12-30 05:26:23 --> Language Class Initialized
INFO - 2017-12-30 05:26:23 --> Loader Class Initialized
INFO - 2017-12-30 05:26:23 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:23 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:23 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:23 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Controller Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
INFO - 2017-12-30 05:26:23 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:26:24 --> Config Class Initialized
INFO - 2017-12-30 05:26:24 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:24 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:24 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:24 --> URI Class Initialized
INFO - 2017-12-30 05:26:24 --> Router Class Initialized
INFO - 2017-12-30 05:26:24 --> Output Class Initialized
INFO - 2017-12-30 05:26:24 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:24 --> Input Class Initialized
INFO - 2017-12-30 05:26:24 --> Language Class Initialized
INFO - 2017-12-30 05:26:24 --> Loader Class Initialized
INFO - 2017-12-30 05:26:24 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:24 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:24 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:24 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Controller Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:26:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:26:24 --> Final output sent to browser
DEBUG - 2017-12-30 05:26:24 --> Total execution time: 0.0843
INFO - 2017-12-30 05:26:24 --> Config Class Initialized
INFO - 2017-12-30 05:26:24 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:26:24 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:26:24 --> Utf8 Class Initialized
INFO - 2017-12-30 05:26:24 --> URI Class Initialized
INFO - 2017-12-30 05:26:24 --> Router Class Initialized
INFO - 2017-12-30 05:26:24 --> Output Class Initialized
INFO - 2017-12-30 05:26:24 --> Security Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:26:24 --> Input Class Initialized
INFO - 2017-12-30 05:26:24 --> Language Class Initialized
INFO - 2017-12-30 05:26:24 --> Loader Class Initialized
INFO - 2017-12-30 05:26:24 --> Helper loaded: url_helper
INFO - 2017-12-30 05:26:24 --> Helper loaded: form_helper
INFO - 2017-12-30 05:26:24 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:26:24 --> Form Validation Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Controller Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
INFO - 2017-12-30 05:26:24 --> Model Class Initialized
DEBUG - 2017-12-30 05:26:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:27:02 --> Config Class Initialized
INFO - 2017-12-30 05:27:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:02 --> URI Class Initialized
INFO - 2017-12-30 05:27:02 --> Router Class Initialized
INFO - 2017-12-30 05:27:02 --> Output Class Initialized
INFO - 2017-12-30 05:27:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:02 --> Input Class Initialized
INFO - 2017-12-30 05:27:02 --> Language Class Initialized
INFO - 2017-12-30 05:27:02 --> Loader Class Initialized
INFO - 2017-12-30 05:27:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Controller Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:27:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:27:02 --> Final output sent to browser
DEBUG - 2017-12-30 05:27:02 --> Total execution time: 0.0576
INFO - 2017-12-30 05:27:02 --> Config Class Initialized
INFO - 2017-12-30 05:27:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:02 --> URI Class Initialized
INFO - 2017-12-30 05:27:02 --> Router Class Initialized
INFO - 2017-12-30 05:27:02 --> Output Class Initialized
INFO - 2017-12-30 05:27:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:02 --> Input Class Initialized
INFO - 2017-12-30 05:27:02 --> Language Class Initialized
INFO - 2017-12-30 05:27:02 --> Loader Class Initialized
INFO - 2017-12-30 05:27:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Controller Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
INFO - 2017-12-30 05:27:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:27:08 --> Config Class Initialized
INFO - 2017-12-30 05:27:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:08 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:08 --> URI Class Initialized
INFO - 2017-12-30 05:27:08 --> Router Class Initialized
INFO - 2017-12-30 05:27:08 --> Output Class Initialized
INFO - 2017-12-30 05:27:08 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:08 --> Input Class Initialized
INFO - 2017-12-30 05:27:08 --> Language Class Initialized
INFO - 2017-12-30 05:27:08 --> Loader Class Initialized
INFO - 2017-12-30 05:27:08 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:08 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:08 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:08 --> Model Class Initialized
INFO - 2017-12-30 05:27:08 --> Controller Class Initialized
INFO - 2017-12-30 05:27:08 --> Model Class Initialized
INFO - 2017-12-30 05:27:08 --> Model Class Initialized
INFO - 2017-12-30 05:27:08 --> Model Class Initialized
INFO - 2017-12-30 05:27:08 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:27:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:27:08 --> Final output sent to browser
DEBUG - 2017-12-30 05:27:08 --> Total execution time: 0.0836
INFO - 2017-12-30 05:27:09 --> Config Class Initialized
INFO - 2017-12-30 05:27:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:09 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:09 --> URI Class Initialized
INFO - 2017-12-30 05:27:09 --> Router Class Initialized
INFO - 2017-12-30 05:27:09 --> Output Class Initialized
INFO - 2017-12-30 05:27:09 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:09 --> Input Class Initialized
INFO - 2017-12-30 05:27:09 --> Language Class Initialized
INFO - 2017-12-30 05:27:09 --> Loader Class Initialized
INFO - 2017-12-30 05:27:09 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:09 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:09 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:09 --> Model Class Initialized
INFO - 2017-12-30 05:27:09 --> Controller Class Initialized
INFO - 2017-12-30 05:27:09 --> Model Class Initialized
INFO - 2017-12-30 05:27:09 --> Model Class Initialized
INFO - 2017-12-30 05:27:09 --> Model Class Initialized
INFO - 2017-12-30 05:27:09 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:27:21 --> Config Class Initialized
INFO - 2017-12-30 05:27:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:21 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:21 --> URI Class Initialized
INFO - 2017-12-30 05:27:21 --> Router Class Initialized
INFO - 2017-12-30 05:27:21 --> Output Class Initialized
INFO - 2017-12-30 05:27:21 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:21 --> Input Class Initialized
INFO - 2017-12-30 05:27:21 --> Language Class Initialized
INFO - 2017-12-30 05:27:21 --> Loader Class Initialized
INFO - 2017-12-30 05:27:21 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:21 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:21 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:21 --> Model Class Initialized
INFO - 2017-12-30 05:27:21 --> Controller Class Initialized
INFO - 2017-12-30 05:27:21 --> Model Class Initialized
INFO - 2017-12-30 05:27:21 --> Model Class Initialized
INFO - 2017-12-30 05:27:21 --> Model Class Initialized
INFO - 2017-12-30 05:27:21 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 05:27:21 --> Severity: Warning --> Missing argument 1 for Reporte::generarReporteProyectoEspecifico() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 92
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 127
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 128
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 136
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 142
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 148
ERROR - 2017-12-30 05:27:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 284
ERROR - 2017-12-30 05:27:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 284
INFO - 2017-12-30 05:27:21 --> Final output sent to browser
DEBUG - 2017-12-30 05:27:21 --> Total execution time: 0.1171
INFO - 2017-12-30 05:27:49 --> Config Class Initialized
INFO - 2017-12-30 05:27:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:27:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:27:49 --> Utf8 Class Initialized
INFO - 2017-12-30 05:27:49 --> URI Class Initialized
INFO - 2017-12-30 05:27:49 --> Router Class Initialized
INFO - 2017-12-30 05:27:49 --> Output Class Initialized
INFO - 2017-12-30 05:27:49 --> Security Class Initialized
DEBUG - 2017-12-30 05:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:27:49 --> Input Class Initialized
INFO - 2017-12-30 05:27:49 --> Language Class Initialized
INFO - 2017-12-30 05:27:49 --> Loader Class Initialized
INFO - 2017-12-30 05:27:49 --> Helper loaded: url_helper
INFO - 2017-12-30 05:27:49 --> Helper loaded: form_helper
INFO - 2017-12-30 05:27:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:27:49 --> Form Validation Class Initialized
INFO - 2017-12-30 05:27:49 --> Model Class Initialized
INFO - 2017-12-30 05:27:49 --> Controller Class Initialized
INFO - 2017-12-30 05:27:49 --> Model Class Initialized
INFO - 2017-12-30 05:27:49 --> Model Class Initialized
INFO - 2017-12-30 05:27:49 --> Model Class Initialized
INFO - 2017-12-30 05:27:49 --> Model Class Initialized
DEBUG - 2017-12-30 05:27:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-30 05:27:49 --> Severity: Warning --> Missing argument 1 for Reporte::generarReporteProyectoEspecifico() D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 92
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 127
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Undefined variable: proyecto_id D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 128
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 136
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 142
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 148
ERROR - 2017-12-30 05:27:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 284
ERROR - 2017-12-30 05:27:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\instatec_app\controllers\Reporte.php 284
INFO - 2017-12-30 05:27:49 --> Final output sent to browser
DEBUG - 2017-12-30 05:27:49 --> Total execution time: 0.1157
INFO - 2017-12-30 05:28:25 --> Config Class Initialized
INFO - 2017-12-30 05:28:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:28:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:28:25 --> Utf8 Class Initialized
INFO - 2017-12-30 05:28:25 --> URI Class Initialized
INFO - 2017-12-30 05:28:25 --> Router Class Initialized
INFO - 2017-12-30 05:28:25 --> Output Class Initialized
INFO - 2017-12-30 05:28:25 --> Security Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:28:25 --> Input Class Initialized
INFO - 2017-12-30 05:28:25 --> Language Class Initialized
INFO - 2017-12-30 05:28:25 --> Loader Class Initialized
INFO - 2017-12-30 05:28:25 --> Helper loaded: url_helper
INFO - 2017-12-30 05:28:25 --> Helper loaded: form_helper
INFO - 2017-12-30 05:28:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:28:25 --> Form Validation Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Controller Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:28:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:28:25 --> Final output sent to browser
DEBUG - 2017-12-30 05:28:25 --> Total execution time: 0.0561
INFO - 2017-12-30 05:28:25 --> Config Class Initialized
INFO - 2017-12-30 05:28:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:28:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:28:25 --> Utf8 Class Initialized
INFO - 2017-12-30 05:28:25 --> URI Class Initialized
INFO - 2017-12-30 05:28:25 --> Router Class Initialized
INFO - 2017-12-30 05:28:25 --> Output Class Initialized
INFO - 2017-12-30 05:28:25 --> Security Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:28:25 --> Input Class Initialized
INFO - 2017-12-30 05:28:25 --> Language Class Initialized
INFO - 2017-12-30 05:28:25 --> Loader Class Initialized
INFO - 2017-12-30 05:28:25 --> Helper loaded: url_helper
INFO - 2017-12-30 05:28:25 --> Helper loaded: form_helper
INFO - 2017-12-30 05:28:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:28:25 --> Form Validation Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Controller Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
INFO - 2017-12-30 05:28:25 --> Model Class Initialized
DEBUG - 2017-12-30 05:28:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:28:27 --> Config Class Initialized
INFO - 2017-12-30 05:28:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:28:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:28:27 --> Utf8 Class Initialized
INFO - 2017-12-30 05:28:27 --> URI Class Initialized
INFO - 2017-12-30 05:28:27 --> Router Class Initialized
INFO - 2017-12-30 05:28:27 --> Output Class Initialized
INFO - 2017-12-30 05:28:27 --> Security Class Initialized
DEBUG - 2017-12-30 05:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:28:27 --> Input Class Initialized
INFO - 2017-12-30 05:28:27 --> Language Class Initialized
INFO - 2017-12-30 05:28:27 --> Loader Class Initialized
INFO - 2017-12-30 05:28:27 --> Helper loaded: url_helper
INFO - 2017-12-30 05:28:27 --> Helper loaded: form_helper
INFO - 2017-12-30 05:28:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:28:27 --> Form Validation Class Initialized
INFO - 2017-12-30 05:28:27 --> Model Class Initialized
INFO - 2017-12-30 05:28:27 --> Controller Class Initialized
INFO - 2017-12-30 05:28:27 --> Model Class Initialized
INFO - 2017-12-30 05:28:27 --> Model Class Initialized
INFO - 2017-12-30 05:28:27 --> Model Class Initialized
INFO - 2017-12-30 05:28:27 --> Model Class Initialized
DEBUG - 2017-12-30 05:28:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:28:27 --> Final output sent to browser
DEBUG - 2017-12-30 05:28:27 --> Total execution time: 0.1309
INFO - 2017-12-30 05:29:13 --> Config Class Initialized
INFO - 2017-12-30 05:29:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:13 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:13 --> URI Class Initialized
INFO - 2017-12-30 05:29:13 --> Router Class Initialized
INFO - 2017-12-30 05:29:13 --> Output Class Initialized
INFO - 2017-12-30 05:29:13 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:13 --> Input Class Initialized
INFO - 2017-12-30 05:29:13 --> Language Class Initialized
INFO - 2017-12-30 05:29:13 --> Loader Class Initialized
INFO - 2017-12-30 05:29:13 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:13 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:13 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:13 --> Model Class Initialized
INFO - 2017-12-30 05:29:13 --> Controller Class Initialized
INFO - 2017-12-30 05:29:13 --> Model Class Initialized
INFO - 2017-12-30 05:29:13 --> Model Class Initialized
INFO - 2017-12-30 05:29:13 --> Model Class Initialized
INFO - 2017-12-30 05:29:13 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:29:13 --> Final output sent to browser
DEBUG - 2017-12-30 05:29:13 --> Total execution time: 0.0615
INFO - 2017-12-30 05:29:38 --> Config Class Initialized
INFO - 2017-12-30 05:29:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:38 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:38 --> URI Class Initialized
INFO - 2017-12-30 05:29:38 --> Router Class Initialized
INFO - 2017-12-30 05:29:38 --> Output Class Initialized
INFO - 2017-12-30 05:29:38 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:38 --> Input Class Initialized
INFO - 2017-12-30 05:29:38 --> Language Class Initialized
INFO - 2017-12-30 05:29:38 --> Loader Class Initialized
INFO - 2017-12-30 05:29:38 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:38 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:38 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Controller Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:38 --> Final output sent to browser
DEBUG - 2017-12-30 05:29:38 --> Total execution time: 0.0535
INFO - 2017-12-30 05:29:38 --> Config Class Initialized
INFO - 2017-12-30 05:29:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:38 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:38 --> URI Class Initialized
INFO - 2017-12-30 05:29:38 --> Router Class Initialized
INFO - 2017-12-30 05:29:38 --> Output Class Initialized
INFO - 2017-12-30 05:29:38 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:38 --> Input Class Initialized
INFO - 2017-12-30 05:29:38 --> Language Class Initialized
INFO - 2017-12-30 05:29:38 --> Loader Class Initialized
INFO - 2017-12-30 05:29:38 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:38 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:38 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Controller Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
INFO - 2017-12-30 05:29:38 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:39 --> Config Class Initialized
INFO - 2017-12-30 05:29:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:39 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:39 --> URI Class Initialized
INFO - 2017-12-30 05:29:39 --> Router Class Initialized
INFO - 2017-12-30 05:29:39 --> Output Class Initialized
INFO - 2017-12-30 05:29:39 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:39 --> Input Class Initialized
INFO - 2017-12-30 05:29:39 --> Language Class Initialized
INFO - 2017-12-30 05:29:39 --> Loader Class Initialized
INFO - 2017-12-30 05:29:39 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:39 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:39 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:39 --> Model Class Initialized
INFO - 2017-12-30 05:29:39 --> Controller Class Initialized
INFO - 2017-12-30 05:29:39 --> Model Class Initialized
INFO - 2017-12-30 05:29:39 --> Model Class Initialized
INFO - 2017-12-30 05:29:39 --> Model Class Initialized
INFO - 2017-12-30 05:29:39 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:40 --> Config Class Initialized
INFO - 2017-12-30 05:29:40 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:40 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:40 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:40 --> URI Class Initialized
INFO - 2017-12-30 05:29:40 --> Router Class Initialized
INFO - 2017-12-30 05:29:40 --> Output Class Initialized
INFO - 2017-12-30 05:29:40 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:40 --> Input Class Initialized
INFO - 2017-12-30 05:29:40 --> Language Class Initialized
INFO - 2017-12-30 05:29:40 --> Loader Class Initialized
INFO - 2017-12-30 05:29:40 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:40 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:40 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:40 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:40 --> Model Class Initialized
INFO - 2017-12-30 05:29:40 --> Controller Class Initialized
INFO - 2017-12-30 05:29:40 --> Model Class Initialized
INFO - 2017-12-30 05:29:40 --> Model Class Initialized
INFO - 2017-12-30 05:29:40 --> Model Class Initialized
INFO - 2017-12-30 05:29:40 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:56 --> Config Class Initialized
INFO - 2017-12-30 05:29:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:56 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:56 --> URI Class Initialized
INFO - 2017-12-30 05:29:56 --> Router Class Initialized
INFO - 2017-12-30 05:29:56 --> Output Class Initialized
INFO - 2017-12-30 05:29:56 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:56 --> Input Class Initialized
INFO - 2017-12-30 05:29:56 --> Language Class Initialized
INFO - 2017-12-30 05:29:56 --> Loader Class Initialized
INFO - 2017-12-30 05:29:56 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:56 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:56 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:56 --> Model Class Initialized
INFO - 2017-12-30 05:29:56 --> Controller Class Initialized
INFO - 2017-12-30 05:29:56 --> Model Class Initialized
INFO - 2017-12-30 05:29:56 --> Model Class Initialized
INFO - 2017-12-30 05:29:56 --> Model Class Initialized
INFO - 2017-12-30 05:29:56 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:57 --> Config Class Initialized
INFO - 2017-12-30 05:29:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:57 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:57 --> URI Class Initialized
INFO - 2017-12-30 05:29:57 --> Router Class Initialized
INFO - 2017-12-30 05:29:57 --> Output Class Initialized
INFO - 2017-12-30 05:29:57 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:57 --> Input Class Initialized
INFO - 2017-12-30 05:29:57 --> Language Class Initialized
INFO - 2017-12-30 05:29:57 --> Loader Class Initialized
INFO - 2017-12-30 05:29:57 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:57 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:57 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Controller Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:29:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:29:57 --> Final output sent to browser
DEBUG - 2017-12-30 05:29:57 --> Total execution time: 0.0524
INFO - 2017-12-30 05:29:57 --> Config Class Initialized
INFO - 2017-12-30 05:29:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:29:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:29:57 --> Utf8 Class Initialized
INFO - 2017-12-30 05:29:57 --> URI Class Initialized
INFO - 2017-12-30 05:29:57 --> Router Class Initialized
INFO - 2017-12-30 05:29:57 --> Output Class Initialized
INFO - 2017-12-30 05:29:57 --> Security Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:29:57 --> Input Class Initialized
INFO - 2017-12-30 05:29:57 --> Language Class Initialized
INFO - 2017-12-30 05:29:57 --> Loader Class Initialized
INFO - 2017-12-30 05:29:57 --> Helper loaded: url_helper
INFO - 2017-12-30 05:29:57 --> Helper loaded: form_helper
INFO - 2017-12-30 05:29:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:29:57 --> Form Validation Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Controller Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
INFO - 2017-12-30 05:29:57 --> Model Class Initialized
DEBUG - 2017-12-30 05:29:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:11 --> Config Class Initialized
INFO - 2017-12-30 05:30:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:11 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:11 --> URI Class Initialized
INFO - 2017-12-30 05:30:11 --> Router Class Initialized
INFO - 2017-12-30 05:30:11 --> Output Class Initialized
INFO - 2017-12-30 05:30:11 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:11 --> Input Class Initialized
INFO - 2017-12-30 05:30:11 --> Language Class Initialized
INFO - 2017-12-30 05:30:11 --> Loader Class Initialized
INFO - 2017-12-30 05:30:11 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:11 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:11 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Controller Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:30:11 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:11 --> Total execution time: 0.0733
INFO - 2017-12-30 05:30:11 --> Config Class Initialized
INFO - 2017-12-30 05:30:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:11 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:11 --> URI Class Initialized
INFO - 2017-12-30 05:30:11 --> Router Class Initialized
INFO - 2017-12-30 05:30:11 --> Output Class Initialized
INFO - 2017-12-30 05:30:11 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:11 --> Input Class Initialized
INFO - 2017-12-30 05:30:11 --> Language Class Initialized
INFO - 2017-12-30 05:30:11 --> Loader Class Initialized
INFO - 2017-12-30 05:30:11 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:11 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:11 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Controller Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
INFO - 2017-12-30 05:30:11 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:12 --> Config Class Initialized
INFO - 2017-12-30 05:30:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:12 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:12 --> URI Class Initialized
INFO - 2017-12-30 05:30:12 --> Router Class Initialized
INFO - 2017-12-30 05:30:12 --> Output Class Initialized
INFO - 2017-12-30 05:30:12 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:12 --> Input Class Initialized
INFO - 2017-12-30 05:30:12 --> Language Class Initialized
INFO - 2017-12-30 05:30:12 --> Loader Class Initialized
INFO - 2017-12-30 05:30:12 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:12 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:13 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:13 --> Model Class Initialized
INFO - 2017-12-30 05:30:13 --> Controller Class Initialized
INFO - 2017-12-30 05:30:13 --> Model Class Initialized
INFO - 2017-12-30 05:30:13 --> Model Class Initialized
INFO - 2017-12-30 05:30:13 --> Model Class Initialized
INFO - 2017-12-30 05:30:13 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:30:13 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:13 --> Total execution time: 0.1371
INFO - 2017-12-30 05:30:28 --> Config Class Initialized
INFO - 2017-12-30 05:30:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:28 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:28 --> URI Class Initialized
INFO - 2017-12-30 05:30:28 --> Router Class Initialized
INFO - 2017-12-30 05:30:28 --> Output Class Initialized
INFO - 2017-12-30 05:30:28 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:28 --> Input Class Initialized
INFO - 2017-12-30 05:30:28 --> Language Class Initialized
INFO - 2017-12-30 05:30:28 --> Loader Class Initialized
INFO - 2017-12-30 05:30:28 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:28 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:28 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Controller Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:28 --> Config Class Initialized
INFO - 2017-12-30 05:30:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:28 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:28 --> URI Class Initialized
INFO - 2017-12-30 05:30:28 --> Router Class Initialized
INFO - 2017-12-30 05:30:28 --> Output Class Initialized
INFO - 2017-12-30 05:30:28 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:28 --> Input Class Initialized
INFO - 2017-12-30 05:30:28 --> Language Class Initialized
INFO - 2017-12-30 05:30:28 --> Loader Class Initialized
INFO - 2017-12-30 05:30:28 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:28 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:28 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Controller Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:30:28 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:28 --> Total execution time: 0.0580
INFO - 2017-12-30 05:30:28 --> Config Class Initialized
INFO - 2017-12-30 05:30:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:28 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:28 --> URI Class Initialized
INFO - 2017-12-30 05:30:28 --> Router Class Initialized
INFO - 2017-12-30 05:30:28 --> Output Class Initialized
INFO - 2017-12-30 05:30:28 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:28 --> Input Class Initialized
INFO - 2017-12-30 05:30:28 --> Language Class Initialized
INFO - 2017-12-30 05:30:28 --> Loader Class Initialized
INFO - 2017-12-30 05:30:28 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:28 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:28 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Controller Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
INFO - 2017-12-30 05:30:28 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:29 --> Config Class Initialized
INFO - 2017-12-30 05:30:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:29 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:29 --> URI Class Initialized
INFO - 2017-12-30 05:30:29 --> Router Class Initialized
INFO - 2017-12-30 05:30:29 --> Output Class Initialized
INFO - 2017-12-30 05:30:29 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:29 --> Input Class Initialized
INFO - 2017-12-30 05:30:29 --> Language Class Initialized
INFO - 2017-12-30 05:30:29 --> Loader Class Initialized
INFO - 2017-12-30 05:30:29 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:29 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:29 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Controller Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:30:29 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:29 --> Total execution time: 0.0649
INFO - 2017-12-30 05:30:29 --> Config Class Initialized
INFO - 2017-12-30 05:30:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:29 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:29 --> URI Class Initialized
INFO - 2017-12-30 05:30:29 --> Router Class Initialized
INFO - 2017-12-30 05:30:29 --> Output Class Initialized
INFO - 2017-12-30 05:30:29 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:29 --> Input Class Initialized
INFO - 2017-12-30 05:30:29 --> Language Class Initialized
INFO - 2017-12-30 05:30:29 --> Loader Class Initialized
INFO - 2017-12-30 05:30:29 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:29 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:29 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Controller Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
INFO - 2017-12-30 05:30:29 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:37 --> Config Class Initialized
INFO - 2017-12-30 05:30:37 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:37 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:37 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:37 --> URI Class Initialized
INFO - 2017-12-30 05:30:37 --> Router Class Initialized
INFO - 2017-12-30 05:30:37 --> Output Class Initialized
INFO - 2017-12-30 05:30:37 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:37 --> Input Class Initialized
INFO - 2017-12-30 05:30:37 --> Language Class Initialized
INFO - 2017-12-30 05:30:37 --> Loader Class Initialized
INFO - 2017-12-30 05:30:37 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:37 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:37 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:37 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:37 --> Model Class Initialized
INFO - 2017-12-30 05:30:37 --> Controller Class Initialized
INFO - 2017-12-30 05:30:37 --> Model Class Initialized
INFO - 2017-12-30 05:30:37 --> Model Class Initialized
INFO - 2017-12-30 05:30:37 --> Model Class Initialized
INFO - 2017-12-30 05:30:37 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:37 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:37 --> Total execution time: 0.1893
INFO - 2017-12-30 05:30:53 --> Config Class Initialized
INFO - 2017-12-30 05:30:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:53 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:53 --> URI Class Initialized
INFO - 2017-12-30 05:30:53 --> Router Class Initialized
INFO - 2017-12-30 05:30:53 --> Output Class Initialized
INFO - 2017-12-30 05:30:53 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:53 --> Input Class Initialized
INFO - 2017-12-30 05:30:53 --> Language Class Initialized
INFO - 2017-12-30 05:30:53 --> Loader Class Initialized
INFO - 2017-12-30 05:30:53 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:53 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:53 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Controller Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:30:53 --> Final output sent to browser
DEBUG - 2017-12-30 05:30:53 --> Total execution time: 0.1053
INFO - 2017-12-30 05:30:53 --> Config Class Initialized
INFO - 2017-12-30 05:30:53 --> Hooks Class Initialized
INFO - 2017-12-30 05:30:53 --> Config Class Initialized
INFO - 2017-12-30 05:30:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:30:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:53 --> Utf8 Class Initialized
DEBUG - 2017-12-30 05:30:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:30:53 --> Utf8 Class Initialized
INFO - 2017-12-30 05:30:53 --> URI Class Initialized
INFO - 2017-12-30 05:30:53 --> URI Class Initialized
INFO - 2017-12-30 05:30:53 --> Router Class Initialized
INFO - 2017-12-30 05:30:53 --> Router Class Initialized
INFO - 2017-12-30 05:30:53 --> Output Class Initialized
INFO - 2017-12-30 05:30:53 --> Output Class Initialized
INFO - 2017-12-30 05:30:53 --> Security Class Initialized
INFO - 2017-12-30 05:30:53 --> Security Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:53 --> Input Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:30:53 --> Input Class Initialized
INFO - 2017-12-30 05:30:53 --> Language Class Initialized
INFO - 2017-12-30 05:30:53 --> Language Class Initialized
INFO - 2017-12-30 05:30:53 --> Loader Class Initialized
INFO - 2017-12-30 05:30:53 --> Loader Class Initialized
INFO - 2017-12-30 05:30:53 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:53 --> Helper loaded: url_helper
INFO - 2017-12-30 05:30:53 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:53 --> Helper loaded: form_helper
INFO - 2017-12-30 05:30:53 --> Database Driver Class Initialized
INFO - 2017-12-30 05:30:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-30 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:53 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Controller Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:30:53 --> Form Validation Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Controller Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
INFO - 2017-12-30 05:30:53 --> Model Class Initialized
DEBUG - 2017-12-30 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:01 --> Config Class Initialized
INFO - 2017-12-30 05:31:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:31:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:01 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:01 --> URI Class Initialized
INFO - 2017-12-30 05:31:01 --> Router Class Initialized
INFO - 2017-12-30 05:31:01 --> Output Class Initialized
INFO - 2017-12-30 05:31:01 --> Security Class Initialized
DEBUG - 2017-12-30 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:01 --> Input Class Initialized
INFO - 2017-12-30 05:31:01 --> Language Class Initialized
INFO - 2017-12-30 05:31:01 --> Loader Class Initialized
INFO - 2017-12-30 05:31:01 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:01 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:01 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:01 --> Model Class Initialized
INFO - 2017-12-30 05:31:01 --> Controller Class Initialized
INFO - 2017-12-30 05:31:01 --> Model Class Initialized
INFO - 2017-12-30 05:31:01 --> Model Class Initialized
INFO - 2017-12-30 05:31:01 --> Model Class Initialized
INFO - 2017-12-30 05:31:01 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:31:01 --> Final output sent to browser
DEBUG - 2017-12-30 05:31:01 --> Total execution time: 0.3404
INFO - 2017-12-30 05:31:02 --> Config Class Initialized
INFO - 2017-12-30 05:31:02 --> Hooks Class Initialized
INFO - 2017-12-30 05:31:02 --> Config Class Initialized
INFO - 2017-12-30 05:31:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:31:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:02 --> URI Class Initialized
DEBUG - 2017-12-30 05:31:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:02 --> URI Class Initialized
INFO - 2017-12-30 05:31:02 --> Router Class Initialized
INFO - 2017-12-30 05:31:02 --> Router Class Initialized
INFO - 2017-12-30 05:31:02 --> Output Class Initialized
INFO - 2017-12-30 05:31:02 --> Security Class Initialized
INFO - 2017-12-30 05:31:02 --> Output Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:02 --> Input Class Initialized
INFO - 2017-12-30 05:31:02 --> Security Class Initialized
INFO - 2017-12-30 05:31:02 --> Language Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:02 --> Input Class Initialized
INFO - 2017-12-30 05:31:02 --> Language Class Initialized
INFO - 2017-12-30 05:31:02 --> Loader Class Initialized
INFO - 2017-12-30 05:31:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:02 --> Loader Class Initialized
INFO - 2017-12-30 05:31:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:02 --> Database Driver Class Initialized
INFO - 2017-12-30 05:31:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:02 --> Controller Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Controller Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:02 --> Config Class Initialized
INFO - 2017-12-30 05:31:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:31:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:02 --> URI Class Initialized
INFO - 2017-12-30 05:31:02 --> Router Class Initialized
INFO - 2017-12-30 05:31:02 --> Output Class Initialized
INFO - 2017-12-30 05:31:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:02 --> Input Class Initialized
INFO - 2017-12-30 05:31:02 --> Language Class Initialized
INFO - 2017-12-30 05:31:02 --> Loader Class Initialized
INFO - 2017-12-30 05:31:02 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:02 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:02 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Controller Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
INFO - 2017-12-30 05:31:02 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:31:02 --> Final output sent to browser
DEBUG - 2017-12-30 05:31:02 --> Total execution time: 0.0515
INFO - 2017-12-30 05:31:02 --> Config Class Initialized
INFO - 2017-12-30 05:31:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:31:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:02 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:02 --> URI Class Initialized
INFO - 2017-12-30 05:31:02 --> Router Class Initialized
INFO - 2017-12-30 05:31:02 --> Output Class Initialized
INFO - 2017-12-30 05:31:02 --> Security Class Initialized
DEBUG - 2017-12-30 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:02 --> Input Class Initialized
INFO - 2017-12-30 05:31:02 --> Language Class Initialized
INFO - 2017-12-30 05:31:03 --> Loader Class Initialized
INFO - 2017-12-30 05:31:03 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:03 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:03 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:03 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:03 --> Model Class Initialized
INFO - 2017-12-30 05:31:03 --> Controller Class Initialized
INFO - 2017-12-30 05:31:03 --> Model Class Initialized
INFO - 2017-12-30 05:31:03 --> Model Class Initialized
INFO - 2017-12-30 05:31:03 --> Model Class Initialized
INFO - 2017-12-30 05:31:03 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:12 --> Config Class Initialized
INFO - 2017-12-30 05:31:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:31:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:31:12 --> Utf8 Class Initialized
INFO - 2017-12-30 05:31:12 --> URI Class Initialized
INFO - 2017-12-30 05:31:12 --> Router Class Initialized
INFO - 2017-12-30 05:31:12 --> Output Class Initialized
INFO - 2017-12-30 05:31:12 --> Security Class Initialized
DEBUG - 2017-12-30 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:31:12 --> Input Class Initialized
INFO - 2017-12-30 05:31:12 --> Language Class Initialized
INFO - 2017-12-30 05:31:12 --> Loader Class Initialized
INFO - 2017-12-30 05:31:12 --> Helper loaded: url_helper
INFO - 2017-12-30 05:31:12 --> Helper loaded: form_helper
INFO - 2017-12-30 05:31:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:31:12 --> Form Validation Class Initialized
INFO - 2017-12-30 05:31:12 --> Model Class Initialized
INFO - 2017-12-30 05:31:12 --> Controller Class Initialized
INFO - 2017-12-30 05:31:12 --> Model Class Initialized
INFO - 2017-12-30 05:31:12 --> Model Class Initialized
INFO - 2017-12-30 05:31:12 --> Model Class Initialized
INFO - 2017-12-30 05:31:12 --> Model Class Initialized
DEBUG - 2017-12-30 05:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:31:12 --> Final output sent to browser
DEBUG - 2017-12-30 05:31:12 --> Total execution time: 0.1383
INFO - 2017-12-30 05:32:49 --> Config Class Initialized
INFO - 2017-12-30 05:32:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:32:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:32:49 --> Utf8 Class Initialized
INFO - 2017-12-30 05:32:49 --> URI Class Initialized
INFO - 2017-12-30 05:32:49 --> Router Class Initialized
INFO - 2017-12-30 05:32:49 --> Output Class Initialized
INFO - 2017-12-30 05:32:49 --> Security Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:32:49 --> Input Class Initialized
INFO - 2017-12-30 05:32:49 --> Language Class Initialized
INFO - 2017-12-30 05:32:49 --> Loader Class Initialized
INFO - 2017-12-30 05:32:49 --> Helper loaded: url_helper
INFO - 2017-12-30 05:32:49 --> Helper loaded: form_helper
INFO - 2017-12-30 05:32:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:32:49 --> Form Validation Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Controller Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:32:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:32:49 --> Final output sent to browser
DEBUG - 2017-12-30 05:32:49 --> Total execution time: 0.0751
INFO - 2017-12-30 05:32:49 --> Config Class Initialized
INFO - 2017-12-30 05:32:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:32:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:32:49 --> Utf8 Class Initialized
INFO - 2017-12-30 05:32:49 --> URI Class Initialized
INFO - 2017-12-30 05:32:49 --> Router Class Initialized
INFO - 2017-12-30 05:32:49 --> Output Class Initialized
INFO - 2017-12-30 05:32:49 --> Security Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:32:49 --> Input Class Initialized
INFO - 2017-12-30 05:32:49 --> Language Class Initialized
INFO - 2017-12-30 05:32:49 --> Loader Class Initialized
INFO - 2017-12-30 05:32:49 --> Helper loaded: url_helper
INFO - 2017-12-30 05:32:49 --> Helper loaded: form_helper
INFO - 2017-12-30 05:32:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:32:49 --> Form Validation Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Controller Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
INFO - 2017-12-30 05:32:49 --> Model Class Initialized
DEBUG - 2017-12-30 05:32:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:30 --> Config Class Initialized
INFO - 2017-12-30 05:33:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:30 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:30 --> URI Class Initialized
INFO - 2017-12-30 05:33:30 --> Router Class Initialized
INFO - 2017-12-30 05:33:30 --> Output Class Initialized
INFO - 2017-12-30 05:33:30 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:30 --> Input Class Initialized
INFO - 2017-12-30 05:33:30 --> Language Class Initialized
INFO - 2017-12-30 05:33:30 --> Loader Class Initialized
INFO - 2017-12-30 05:33:30 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:30 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:30 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:30 --> Model Class Initialized
INFO - 2017-12-30 05:33:30 --> Controller Class Initialized
INFO - 2017-12-30 05:33:30 --> Model Class Initialized
INFO - 2017-12-30 05:33:30 --> Model Class Initialized
INFO - 2017-12-30 05:33:30 --> Model Class Initialized
INFO - 2017-12-30 05:33:30 --> Model Class Initialized
DEBUG - 2017-12-30 05:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:33:30 --> Final output sent to browser
DEBUG - 2017-12-30 05:33:30 --> Total execution time: 0.0539
INFO - 2017-12-30 05:33:31 --> Config Class Initialized
INFO - 2017-12-30 05:33:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:31 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:31 --> URI Class Initialized
INFO - 2017-12-30 05:33:31 --> Router Class Initialized
INFO - 2017-12-30 05:33:31 --> Output Class Initialized
INFO - 2017-12-30 05:33:31 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:31 --> Input Class Initialized
INFO - 2017-12-30 05:33:31 --> Language Class Initialized
INFO - 2017-12-30 05:33:31 --> Loader Class Initialized
INFO - 2017-12-30 05:33:31 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:31 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:31 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:31 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:31 --> Model Class Initialized
INFO - 2017-12-30 05:33:31 --> Controller Class Initialized
INFO - 2017-12-30 05:33:31 --> Model Class Initialized
INFO - 2017-12-30 05:33:31 --> Model Class Initialized
INFO - 2017-12-30 05:33:31 --> Model Class Initialized
INFO - 2017-12-30 05:33:31 --> Model Class Initialized
DEBUG - 2017-12-30 05:33:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:33 --> Config Class Initialized
INFO - 2017-12-30 05:33:33 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:33 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:33 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:33 --> URI Class Initialized
INFO - 2017-12-30 05:33:33 --> Router Class Initialized
INFO - 2017-12-30 05:33:33 --> Output Class Initialized
INFO - 2017-12-30 05:33:33 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:33 --> Input Class Initialized
INFO - 2017-12-30 05:33:33 --> Language Class Initialized
INFO - 2017-12-30 05:33:33 --> Loader Class Initialized
INFO - 2017-12-30 05:33:33 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:33 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:33 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:33 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:33 --> Model Class Initialized
INFO - 2017-12-30 05:33:33 --> Controller Class Initialized
INFO - 2017-12-30 05:33:33 --> Model Class Initialized
INFO - 2017-12-30 05:33:33 --> Model Class Initialized
INFO - 2017-12-30 05:33:33 --> Model Class Initialized
INFO - 2017-12-30 05:33:33 --> Model Class Initialized
DEBUG - 2017-12-30 05:33:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:33:33 --> Final output sent to browser
DEBUG - 2017-12-30 05:33:33 --> Total execution time: 0.0527
INFO - 2017-12-30 05:33:34 --> Config Class Initialized
INFO - 2017-12-30 05:33:34 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:34 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:34 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:34 --> URI Class Initialized
INFO - 2017-12-30 05:33:34 --> Router Class Initialized
INFO - 2017-12-30 05:33:34 --> Output Class Initialized
INFO - 2017-12-30 05:33:35 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:35 --> Input Class Initialized
INFO - 2017-12-30 05:33:35 --> Language Class Initialized
INFO - 2017-12-30 05:33:35 --> Loader Class Initialized
INFO - 2017-12-30 05:33:35 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:35 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:35 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:35 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Controller Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:33:35 --> Final output sent to browser
DEBUG - 2017-12-30 05:33:35 --> Total execution time: 0.0601
INFO - 2017-12-30 05:33:35 --> Config Class Initialized
INFO - 2017-12-30 05:33:35 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:35 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:35 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:35 --> URI Class Initialized
INFO - 2017-12-30 05:33:35 --> Router Class Initialized
INFO - 2017-12-30 05:33:35 --> Output Class Initialized
INFO - 2017-12-30 05:33:35 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:35 --> Input Class Initialized
INFO - 2017-12-30 05:33:35 --> Language Class Initialized
INFO - 2017-12-30 05:33:35 --> Loader Class Initialized
INFO - 2017-12-30 05:33:35 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:35 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:35 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:35 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Controller Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
INFO - 2017-12-30 05:33:35 --> Model Class Initialized
DEBUG - 2017-12-30 05:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:33:39 --> Config Class Initialized
INFO - 2017-12-30 05:33:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:33:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:33:39 --> Utf8 Class Initialized
INFO - 2017-12-30 05:33:39 --> URI Class Initialized
DEBUG - 2017-12-30 05:33:39 --> No URI present. Default controller set.
INFO - 2017-12-30 05:33:39 --> Router Class Initialized
INFO - 2017-12-30 05:33:39 --> Output Class Initialized
INFO - 2017-12-30 05:33:39 --> Security Class Initialized
DEBUG - 2017-12-30 05:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:33:39 --> Input Class Initialized
INFO - 2017-12-30 05:33:39 --> Language Class Initialized
INFO - 2017-12-30 05:33:39 --> Loader Class Initialized
INFO - 2017-12-30 05:33:39 --> Helper loaded: url_helper
INFO - 2017-12-30 05:33:39 --> Helper loaded: form_helper
INFO - 2017-12-30 05:33:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:33:39 --> Form Validation Class Initialized
INFO - 2017-12-30 05:33:39 --> Model Class Initialized
INFO - 2017-12-30 05:33:39 --> Controller Class Initialized
INFO - 2017-12-30 05:33:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:33:39 --> Final output sent to browser
DEBUG - 2017-12-30 05:33:39 --> Total execution time: 0.0837
INFO - 2017-12-30 05:36:47 --> Config Class Initialized
INFO - 2017-12-30 05:36:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:36:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:36:47 --> Utf8 Class Initialized
INFO - 2017-12-30 05:36:47 --> URI Class Initialized
INFO - 2017-12-30 05:36:47 --> Router Class Initialized
INFO - 2017-12-30 05:36:47 --> Output Class Initialized
INFO - 2017-12-30 05:36:47 --> Security Class Initialized
DEBUG - 2017-12-30 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:36:47 --> Input Class Initialized
INFO - 2017-12-30 05:36:47 --> Language Class Initialized
INFO - 2017-12-30 05:36:47 --> Loader Class Initialized
INFO - 2017-12-30 05:36:47 --> Helper loaded: url_helper
INFO - 2017-12-30 05:36:47 --> Helper loaded: form_helper
INFO - 2017-12-30 05:36:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:36:47 --> Form Validation Class Initialized
INFO - 2017-12-30 05:36:47 --> Model Class Initialized
INFO - 2017-12-30 05:36:47 --> Controller Class Initialized
INFO - 2017-12-30 05:36:47 --> Model Class Initialized
INFO - 2017-12-30 05:36:47 --> Model Class Initialized
INFO - 2017-12-30 05:36:47 --> Model Class Initialized
INFO - 2017-12-30 05:36:47 --> Model Class Initialized
DEBUG - 2017-12-30 05:36:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:36:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:36:47 --> Final output sent to browser
DEBUG - 2017-12-30 05:36:47 --> Total execution time: 0.0632
INFO - 2017-12-30 05:36:48 --> Config Class Initialized
INFO - 2017-12-30 05:36:48 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:36:48 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:36:48 --> Utf8 Class Initialized
INFO - 2017-12-30 05:36:48 --> URI Class Initialized
INFO - 2017-12-30 05:36:48 --> Router Class Initialized
INFO - 2017-12-30 05:36:48 --> Output Class Initialized
INFO - 2017-12-30 05:36:48 --> Security Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:36:48 --> Input Class Initialized
INFO - 2017-12-30 05:36:48 --> Language Class Initialized
INFO - 2017-12-30 05:36:48 --> Loader Class Initialized
INFO - 2017-12-30 05:36:48 --> Helper loaded: url_helper
INFO - 2017-12-30 05:36:48 --> Helper loaded: form_helper
INFO - 2017-12-30 05:36:48 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:36:48 --> Form Validation Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Controller Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:36:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:36:48 --> Final output sent to browser
DEBUG - 2017-12-30 05:36:48 --> Total execution time: 0.0637
INFO - 2017-12-30 05:36:48 --> Config Class Initialized
INFO - 2017-12-30 05:36:48 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:36:48 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:36:48 --> Utf8 Class Initialized
INFO - 2017-12-30 05:36:48 --> URI Class Initialized
INFO - 2017-12-30 05:36:48 --> Router Class Initialized
INFO - 2017-12-30 05:36:48 --> Output Class Initialized
INFO - 2017-12-30 05:36:48 --> Security Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:36:48 --> Input Class Initialized
INFO - 2017-12-30 05:36:48 --> Language Class Initialized
INFO - 2017-12-30 05:36:48 --> Loader Class Initialized
INFO - 2017-12-30 05:36:48 --> Helper loaded: url_helper
INFO - 2017-12-30 05:36:48 --> Helper loaded: form_helper
INFO - 2017-12-30 05:36:48 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:36:48 --> Form Validation Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Controller Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
INFO - 2017-12-30 05:36:48 --> Model Class Initialized
DEBUG - 2017-12-30 05:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:36:50 --> Config Class Initialized
INFO - 2017-12-30 05:36:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:36:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:36:50 --> Utf8 Class Initialized
INFO - 2017-12-30 05:36:50 --> URI Class Initialized
INFO - 2017-12-30 05:36:50 --> Router Class Initialized
INFO - 2017-12-30 05:36:50 --> Output Class Initialized
INFO - 2017-12-30 05:36:50 --> Security Class Initialized
DEBUG - 2017-12-30 05:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:36:50 --> Input Class Initialized
INFO - 2017-12-30 05:36:50 --> Language Class Initialized
INFO - 2017-12-30 05:36:50 --> Loader Class Initialized
INFO - 2017-12-30 05:36:50 --> Helper loaded: url_helper
INFO - 2017-12-30 05:36:50 --> Helper loaded: form_helper
INFO - 2017-12-30 05:36:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:36:50 --> Form Validation Class Initialized
INFO - 2017-12-30 05:36:50 --> Model Class Initialized
INFO - 2017-12-30 05:36:50 --> Controller Class Initialized
INFO - 2017-12-30 05:36:50 --> Model Class Initialized
INFO - 2017-12-30 05:36:50 --> Model Class Initialized
INFO - 2017-12-30 05:36:50 --> Model Class Initialized
INFO - 2017-12-30 05:36:50 --> Model Class Initialized
DEBUG - 2017-12-30 05:36:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:36:50 --> Final output sent to browser
DEBUG - 2017-12-30 05:36:50 --> Total execution time: 0.1517
INFO - 2017-12-30 05:44:21 --> Config Class Initialized
INFO - 2017-12-30 05:44:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:44:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:44:21 --> Utf8 Class Initialized
INFO - 2017-12-30 05:44:21 --> URI Class Initialized
INFO - 2017-12-30 05:44:21 --> Router Class Initialized
INFO - 2017-12-30 05:44:21 --> Output Class Initialized
INFO - 2017-12-30 05:44:21 --> Security Class Initialized
DEBUG - 2017-12-30 05:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:44:21 --> Input Class Initialized
INFO - 2017-12-30 05:44:21 --> Language Class Initialized
INFO - 2017-12-30 05:44:21 --> Loader Class Initialized
INFO - 2017-12-30 05:44:21 --> Helper loaded: url_helper
INFO - 2017-12-30 05:44:21 --> Helper loaded: form_helper
INFO - 2017-12-30 05:44:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:44:21 --> Form Validation Class Initialized
INFO - 2017-12-30 05:44:21 --> Model Class Initialized
INFO - 2017-12-30 05:44:21 --> Controller Class Initialized
INFO - 2017-12-30 05:44:21 --> Model Class Initialized
INFO - 2017-12-30 05:44:21 --> Model Class Initialized
INFO - 2017-12-30 05:44:21 --> Model Class Initialized
INFO - 2017-12-30 05:44:21 --> Model Class Initialized
DEBUG - 2017-12-30 05:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:44:21 --> Final output sent to browser
DEBUG - 2017-12-30 05:44:21 --> Total execution time: 0.1415
INFO - 2017-12-30 05:44:48 --> Config Class Initialized
INFO - 2017-12-30 05:44:48 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:44:48 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:44:48 --> Utf8 Class Initialized
INFO - 2017-12-30 05:44:48 --> URI Class Initialized
INFO - 2017-12-30 05:44:48 --> Router Class Initialized
INFO - 2017-12-30 05:44:48 --> Output Class Initialized
INFO - 2017-12-30 05:44:48 --> Security Class Initialized
DEBUG - 2017-12-30 05:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:44:48 --> Input Class Initialized
INFO - 2017-12-30 05:44:48 --> Language Class Initialized
INFO - 2017-12-30 05:44:48 --> Loader Class Initialized
INFO - 2017-12-30 05:44:48 --> Helper loaded: url_helper
INFO - 2017-12-30 05:44:48 --> Helper loaded: form_helper
INFO - 2017-12-30 05:44:48 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:44:48 --> Form Validation Class Initialized
INFO - 2017-12-30 05:44:48 --> Model Class Initialized
INFO - 2017-12-30 05:44:48 --> Controller Class Initialized
INFO - 2017-12-30 05:44:48 --> Model Class Initialized
INFO - 2017-12-30 05:44:48 --> Model Class Initialized
INFO - 2017-12-30 05:44:48 --> Model Class Initialized
INFO - 2017-12-30 05:44:48 --> Model Class Initialized
DEBUG - 2017-12-30 05:44:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:44:49 --> Final output sent to browser
DEBUG - 2017-12-30 05:44:49 --> Total execution time: 0.1452
INFO - 2017-12-30 05:46:21 --> Config Class Initialized
INFO - 2017-12-30 05:46:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:46:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:46:21 --> Utf8 Class Initialized
INFO - 2017-12-30 05:46:21 --> URI Class Initialized
INFO - 2017-12-30 05:46:21 --> Router Class Initialized
INFO - 2017-12-30 05:46:21 --> Output Class Initialized
INFO - 2017-12-30 05:46:21 --> Security Class Initialized
DEBUG - 2017-12-30 05:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:46:21 --> Input Class Initialized
INFO - 2017-12-30 05:46:21 --> Language Class Initialized
INFO - 2017-12-30 05:46:21 --> Loader Class Initialized
INFO - 2017-12-30 05:46:21 --> Helper loaded: url_helper
INFO - 2017-12-30 05:46:21 --> Helper loaded: form_helper
INFO - 2017-12-30 05:46:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:46:21 --> Form Validation Class Initialized
INFO - 2017-12-30 05:46:21 --> Model Class Initialized
INFO - 2017-12-30 05:46:21 --> Controller Class Initialized
INFO - 2017-12-30 05:46:21 --> Model Class Initialized
INFO - 2017-12-30 05:46:21 --> Model Class Initialized
INFO - 2017-12-30 05:46:21 --> Model Class Initialized
INFO - 2017-12-30 05:46:21 --> Model Class Initialized
DEBUG - 2017-12-30 05:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:46:22 --> Final output sent to browser
DEBUG - 2017-12-30 05:46:22 --> Total execution time: 0.1465
INFO - 2017-12-30 05:46:37 --> Config Class Initialized
INFO - 2017-12-30 05:46:37 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:46:37 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:46:37 --> Utf8 Class Initialized
INFO - 2017-12-30 05:46:37 --> URI Class Initialized
INFO - 2017-12-30 05:46:37 --> Router Class Initialized
INFO - 2017-12-30 05:46:37 --> Output Class Initialized
INFO - 2017-12-30 05:46:37 --> Security Class Initialized
DEBUG - 2017-12-30 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:46:37 --> Input Class Initialized
INFO - 2017-12-30 05:46:37 --> Language Class Initialized
INFO - 2017-12-30 05:46:37 --> Loader Class Initialized
INFO - 2017-12-30 05:46:37 --> Helper loaded: url_helper
INFO - 2017-12-30 05:46:37 --> Helper loaded: form_helper
INFO - 2017-12-30 05:46:37 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:46:37 --> Form Validation Class Initialized
INFO - 2017-12-30 05:46:37 --> Model Class Initialized
INFO - 2017-12-30 05:46:37 --> Controller Class Initialized
INFO - 2017-12-30 05:46:37 --> Model Class Initialized
INFO - 2017-12-30 05:46:37 --> Model Class Initialized
INFO - 2017-12-30 05:46:37 --> Model Class Initialized
INFO - 2017-12-30 05:46:37 --> Model Class Initialized
DEBUG - 2017-12-30 05:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:46:37 --> Final output sent to browser
DEBUG - 2017-12-30 05:46:37 --> Total execution time: 0.1462
INFO - 2017-12-30 05:50:14 --> Config Class Initialized
INFO - 2017-12-30 05:50:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:14 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:14 --> URI Class Initialized
INFO - 2017-12-30 05:50:14 --> Router Class Initialized
INFO - 2017-12-30 05:50:14 --> Output Class Initialized
INFO - 2017-12-30 05:50:14 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:14 --> Input Class Initialized
INFO - 2017-12-30 05:50:14 --> Language Class Initialized
INFO - 2017-12-30 05:50:14 --> Loader Class Initialized
INFO - 2017-12-30 05:50:14 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:14 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:14 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Controller Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:14 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:14 --> Total execution time: 0.0650
INFO - 2017-12-30 05:50:14 --> Config Class Initialized
INFO - 2017-12-30 05:50:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:14 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:14 --> URI Class Initialized
INFO - 2017-12-30 05:50:14 --> Router Class Initialized
INFO - 2017-12-30 05:50:14 --> Output Class Initialized
INFO - 2017-12-30 05:50:14 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:14 --> Input Class Initialized
INFO - 2017-12-30 05:50:14 --> Language Class Initialized
INFO - 2017-12-30 05:50:14 --> Loader Class Initialized
INFO - 2017-12-30 05:50:14 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:14 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:14 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Controller Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:14 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:14 --> Total execution time: 0.0553
INFO - 2017-12-30 05:50:14 --> Config Class Initialized
INFO - 2017-12-30 05:50:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:14 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:14 --> URI Class Initialized
INFO - 2017-12-30 05:50:14 --> Router Class Initialized
INFO - 2017-12-30 05:50:14 --> Output Class Initialized
INFO - 2017-12-30 05:50:14 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:14 --> Input Class Initialized
INFO - 2017-12-30 05:50:14 --> Language Class Initialized
INFO - 2017-12-30 05:50:14 --> Loader Class Initialized
INFO - 2017-12-30 05:50:14 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:14 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:14 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Controller Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
INFO - 2017-12-30 05:50:14 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:15 --> Config Class Initialized
INFO - 2017-12-30 05:50:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:15 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:15 --> URI Class Initialized
INFO - 2017-12-30 05:50:15 --> Router Class Initialized
INFO - 2017-12-30 05:50:15 --> Output Class Initialized
INFO - 2017-12-30 05:50:15 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:15 --> Input Class Initialized
INFO - 2017-12-30 05:50:15 --> Language Class Initialized
INFO - 2017-12-30 05:50:15 --> Loader Class Initialized
INFO - 2017-12-30 05:50:15 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:15 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:15 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Controller Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:15 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:15 --> Total execution time: 0.0514
INFO - 2017-12-30 05:50:15 --> Config Class Initialized
INFO - 2017-12-30 05:50:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:15 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:15 --> URI Class Initialized
INFO - 2017-12-30 05:50:15 --> Router Class Initialized
INFO - 2017-12-30 05:50:15 --> Output Class Initialized
INFO - 2017-12-30 05:50:15 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:15 --> Input Class Initialized
INFO - 2017-12-30 05:50:15 --> Language Class Initialized
INFO - 2017-12-30 05:50:15 --> Loader Class Initialized
INFO - 2017-12-30 05:50:15 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:15 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:15 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Controller Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:15 --> Config Class Initialized
INFO - 2017-12-30 05:50:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:15 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:15 --> URI Class Initialized
INFO - 2017-12-30 05:50:15 --> Router Class Initialized
INFO - 2017-12-30 05:50:15 --> Output Class Initialized
INFO - 2017-12-30 05:50:15 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:15 --> Input Class Initialized
INFO - 2017-12-30 05:50:15 --> Language Class Initialized
INFO - 2017-12-30 05:50:15 --> Loader Class Initialized
INFO - 2017-12-30 05:50:15 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:15 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:15 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Controller Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
INFO - 2017-12-30 05:50:15 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:15 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:15 --> Total execution time: 0.0464
INFO - 2017-12-30 05:50:15 --> Config Class Initialized
INFO - 2017-12-30 05:50:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:15 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:15 --> URI Class Initialized
INFO - 2017-12-30 05:50:15 --> Router Class Initialized
INFO - 2017-12-30 05:50:15 --> Output Class Initialized
INFO - 2017-12-30 05:50:15 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:15 --> Input Class Initialized
INFO - 2017-12-30 05:50:15 --> Language Class Initialized
INFO - 2017-12-30 05:50:16 --> Loader Class Initialized
INFO - 2017-12-30 05:50:16 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:16 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:16 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
INFO - 2017-12-30 05:50:16 --> Controller Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:16 --> Config Class Initialized
INFO - 2017-12-30 05:50:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:16 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:16 --> URI Class Initialized
DEBUG - 2017-12-30 05:50:16 --> No URI present. Default controller set.
INFO - 2017-12-30 05:50:16 --> Router Class Initialized
INFO - 2017-12-30 05:50:16 --> Output Class Initialized
INFO - 2017-12-30 05:50:16 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:16 --> Input Class Initialized
INFO - 2017-12-30 05:50:16 --> Language Class Initialized
INFO - 2017-12-30 05:50:16 --> Loader Class Initialized
INFO - 2017-12-30 05:50:16 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:16 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:16 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:16 --> Model Class Initialized
INFO - 2017-12-30 05:50:16 --> Controller Class Initialized
INFO - 2017-12-30 05:50:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:16 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:16 --> Total execution time: 0.0481
INFO - 2017-12-30 05:50:18 --> Config Class Initialized
INFO - 2017-12-30 05:50:18 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:18 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:18 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:18 --> URI Class Initialized
INFO - 2017-12-30 05:50:18 --> Router Class Initialized
INFO - 2017-12-30 05:50:18 --> Output Class Initialized
INFO - 2017-12-30 05:50:18 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:18 --> Input Class Initialized
INFO - 2017-12-30 05:50:18 --> Language Class Initialized
INFO - 2017-12-30 05:50:18 --> Loader Class Initialized
INFO - 2017-12-30 05:50:18 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:18 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:18 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:18 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Controller Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 05:50:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 05:50:18 --> Final output sent to browser
DEBUG - 2017-12-30 05:50:18 --> Total execution time: 0.0585
INFO - 2017-12-30 05:50:18 --> Config Class Initialized
INFO - 2017-12-30 05:50:18 --> Hooks Class Initialized
DEBUG - 2017-12-30 05:50:18 --> UTF-8 Support Enabled
INFO - 2017-12-30 05:50:18 --> Utf8 Class Initialized
INFO - 2017-12-30 05:50:18 --> URI Class Initialized
INFO - 2017-12-30 05:50:18 --> Router Class Initialized
INFO - 2017-12-30 05:50:18 --> Output Class Initialized
INFO - 2017-12-30 05:50:18 --> Security Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 05:50:18 --> Input Class Initialized
INFO - 2017-12-30 05:50:18 --> Language Class Initialized
INFO - 2017-12-30 05:50:18 --> Loader Class Initialized
INFO - 2017-12-30 05:50:18 --> Helper loaded: url_helper
INFO - 2017-12-30 05:50:18 --> Helper loaded: form_helper
INFO - 2017-12-30 05:50:18 --> Database Driver Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 05:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 05:50:18 --> Form Validation Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Controller Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
INFO - 2017-12-30 05:50:18 --> Model Class Initialized
DEBUG - 2017-12-30 05:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:17 --> Config Class Initialized
INFO - 2017-12-30 06:03:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:17 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:17 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:17 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:17 --> Router Class Initialized
INFO - 2017-12-30 06:03:17 --> Output Class Initialized
INFO - 2017-12-30 06:03:17 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:17 --> Input Class Initialized
INFO - 2017-12-30 06:03:17 --> Language Class Initialized
INFO - 2017-12-30 06:03:17 --> Loader Class Initialized
INFO - 2017-12-30 06:03:17 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:17 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:17 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
INFO - 2017-12-30 06:03:17 --> Controller Class Initialized
INFO - 2017-12-30 06:03:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:17 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:17 --> Total execution time: 0.0414
INFO - 2017-12-30 06:03:17 --> Config Class Initialized
INFO - 2017-12-30 06:03:17 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:17 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:17 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:17 --> URI Class Initialized
INFO - 2017-12-30 06:03:17 --> Router Class Initialized
INFO - 2017-12-30 06:03:17 --> Output Class Initialized
INFO - 2017-12-30 06:03:17 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:17 --> Input Class Initialized
INFO - 2017-12-30 06:03:17 --> Language Class Initialized
INFO - 2017-12-30 06:03:17 --> Loader Class Initialized
INFO - 2017-12-30 06:03:17 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:17 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:17 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:17 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
INFO - 2017-12-30 06:03:17 --> Controller Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
INFO - 2017-12-30 06:03:17 --> Model Class Initialized
DEBUG - 2017-12-30 06:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:17 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:17 --> Total execution time: 0.0455
INFO - 2017-12-30 06:03:20 --> Config Class Initialized
INFO - 2017-12-30 06:03:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:20 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:20 --> URI Class Initialized
INFO - 2017-12-30 06:03:20 --> Router Class Initialized
INFO - 2017-12-30 06:03:20 --> Output Class Initialized
INFO - 2017-12-30 06:03:20 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:20 --> Input Class Initialized
INFO - 2017-12-30 06:03:20 --> Language Class Initialized
ERROR - 2017-12-30 06:03:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:03:20 --> Config Class Initialized
INFO - 2017-12-30 06:03:20 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:20 --> Config Class Initialized
INFO - 2017-12-30 06:03:20 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:20 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:20 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:20 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:20 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:20 --> Router Class Initialized
INFO - 2017-12-30 06:03:20 --> URI Class Initialized
INFO - 2017-12-30 06:03:20 --> Router Class Initialized
INFO - 2017-12-30 06:03:20 --> Output Class Initialized
INFO - 2017-12-30 06:03:20 --> Security Class Initialized
INFO - 2017-12-30 06:03:20 --> Output Class Initialized
DEBUG - 2017-12-30 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:20 --> Input Class Initialized
INFO - 2017-12-30 06:03:20 --> Security Class Initialized
INFO - 2017-12-30 06:03:20 --> Language Class Initialized
DEBUG - 2017-12-30 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:20 --> Input Class Initialized
ERROR - 2017-12-30 06:03:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:20 --> Language Class Initialized
ERROR - 2017-12-30 06:03:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:27 --> Config Class Initialized
INFO - 2017-12-30 06:03:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:27 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:27 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:27 --> Router Class Initialized
INFO - 2017-12-30 06:03:27 --> Output Class Initialized
INFO - 2017-12-30 06:03:27 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:27 --> Input Class Initialized
INFO - 2017-12-30 06:03:27 --> Language Class Initialized
INFO - 2017-12-30 06:03:27 --> Loader Class Initialized
INFO - 2017-12-30 06:03:27 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:27 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:27 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
INFO - 2017-12-30 06:03:27 --> Controller Class Initialized
INFO - 2017-12-30 06:03:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:27 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:27 --> Total execution time: 0.0553
INFO - 2017-12-30 06:03:27 --> Config Class Initialized
INFO - 2017-12-30 06:03:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:27 --> URI Class Initialized
INFO - 2017-12-30 06:03:27 --> Router Class Initialized
INFO - 2017-12-30 06:03:27 --> Output Class Initialized
INFO - 2017-12-30 06:03:27 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:27 --> Input Class Initialized
INFO - 2017-12-30 06:03:27 --> Language Class Initialized
ERROR - 2017-12-30 06:03:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:03:27 --> Config Class Initialized
INFO - 2017-12-30 06:03:27 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:27 --> Config Class Initialized
INFO - 2017-12-30 06:03:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:27 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:27 --> Router Class Initialized
INFO - 2017-12-30 06:03:27 --> URI Class Initialized
INFO - 2017-12-30 06:03:27 --> Router Class Initialized
INFO - 2017-12-30 06:03:27 --> Output Class Initialized
INFO - 2017-12-30 06:03:27 --> Security Class Initialized
INFO - 2017-12-30 06:03:27 --> Output Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:27 --> Security Class Initialized
INFO - 2017-12-30 06:03:27 --> Input Class Initialized
INFO - 2017-12-30 06:03:27 --> Language Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:27 --> Input Class Initialized
ERROR - 2017-12-30 06:03:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:27 --> Language Class Initialized
INFO - 2017-12-30 06:03:27 --> Config Class Initialized
INFO - 2017-12-30 06:03:27 --> Hooks Class Initialized
ERROR - 2017-12-30 06:03:27 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 06:03:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:27 --> URI Class Initialized
INFO - 2017-12-30 06:03:27 --> Router Class Initialized
INFO - 2017-12-30 06:03:27 --> Output Class Initialized
INFO - 2017-12-30 06:03:27 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:27 --> Input Class Initialized
INFO - 2017-12-30 06:03:27 --> Language Class Initialized
INFO - 2017-12-30 06:03:27 --> Loader Class Initialized
INFO - 2017-12-30 06:03:27 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:27 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:27 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
INFO - 2017-12-30 06:03:27 --> Controller Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
INFO - 2017-12-30 06:03:27 --> Model Class Initialized
DEBUG - 2017-12-30 06:03:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:27 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:27 --> Total execution time: 0.0637
INFO - 2017-12-30 06:03:51 --> Config Class Initialized
INFO - 2017-12-30 06:03:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:51 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:51 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:51 --> Router Class Initialized
INFO - 2017-12-30 06:03:51 --> Output Class Initialized
INFO - 2017-12-30 06:03:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:51 --> Input Class Initialized
INFO - 2017-12-30 06:03:51 --> Language Class Initialized
INFO - 2017-12-30 06:03:51 --> Loader Class Initialized
INFO - 2017-12-30 06:03:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
INFO - 2017-12-30 06:03:51 --> Controller Class Initialized
INFO - 2017-12-30 06:03:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:51 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:51 --> Total execution time: 0.0525
INFO - 2017-12-30 06:03:51 --> Config Class Initialized
INFO - 2017-12-30 06:03:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:51 --> URI Class Initialized
INFO - 2017-12-30 06:03:51 --> Router Class Initialized
INFO - 2017-12-30 06:03:51 --> Output Class Initialized
INFO - 2017-12-30 06:03:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:51 --> Input Class Initialized
INFO - 2017-12-30 06:03:51 --> Language Class Initialized
ERROR - 2017-12-30 06:03:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:03:51 --> Config Class Initialized
INFO - 2017-12-30 06:03:51 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:51 --> Config Class Initialized
INFO - 2017-12-30 06:03:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:51 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:51 --> URI Class Initialized
INFO - 2017-12-30 06:03:51 --> Router Class Initialized
INFO - 2017-12-30 06:03:51 --> Router Class Initialized
INFO - 2017-12-30 06:03:51 --> Output Class Initialized
INFO - 2017-12-30 06:03:51 --> Output Class Initialized
INFO - 2017-12-30 06:03:51 --> Security Class Initialized
INFO - 2017-12-30 06:03:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:51 --> Input Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:51 --> Input Class Initialized
INFO - 2017-12-30 06:03:51 --> Language Class Initialized
INFO - 2017-12-30 06:03:51 --> Language Class Initialized
ERROR - 2017-12-30 06:03:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:03:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:51 --> Config Class Initialized
INFO - 2017-12-30 06:03:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:51 --> URI Class Initialized
INFO - 2017-12-30 06:03:51 --> Router Class Initialized
INFO - 2017-12-30 06:03:51 --> Output Class Initialized
INFO - 2017-12-30 06:03:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:51 --> Input Class Initialized
INFO - 2017-12-30 06:03:51 --> Language Class Initialized
INFO - 2017-12-30 06:03:51 --> Loader Class Initialized
INFO - 2017-12-30 06:03:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
INFO - 2017-12-30 06:03:51 --> Controller Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
INFO - 2017-12-30 06:03:51 --> Model Class Initialized
DEBUG - 2017-12-30 06:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:51 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:51 --> Total execution time: 0.0495
INFO - 2017-12-30 06:03:52 --> Config Class Initialized
INFO - 2017-12-30 06:03:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:52 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:52 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:52 --> Router Class Initialized
INFO - 2017-12-30 06:03:52 --> Output Class Initialized
INFO - 2017-12-30 06:03:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:52 --> Input Class Initialized
INFO - 2017-12-30 06:03:52 --> Language Class Initialized
INFO - 2017-12-30 06:03:52 --> Loader Class Initialized
INFO - 2017-12-30 06:03:52 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:52 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:52 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
INFO - 2017-12-30 06:03:52 --> Controller Class Initialized
INFO - 2017-12-30 06:03:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:52 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:52 --> Total execution time: 0.0719
INFO - 2017-12-30 06:03:52 --> Config Class Initialized
INFO - 2017-12-30 06:03:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:52 --> URI Class Initialized
INFO - 2017-12-30 06:03:52 --> Router Class Initialized
INFO - 2017-12-30 06:03:52 --> Output Class Initialized
INFO - 2017-12-30 06:03:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:52 --> Input Class Initialized
INFO - 2017-12-30 06:03:52 --> Language Class Initialized
ERROR - 2017-12-30 06:03:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:03:52 --> Config Class Initialized
INFO - 2017-12-30 06:03:52 --> Config Class Initialized
INFO - 2017-12-30 06:03:52 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:52 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:03:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:52 --> URI Class Initialized
INFO - 2017-12-30 06:03:52 --> URI Class Initialized
INFO - 2017-12-30 06:03:52 --> Router Class Initialized
INFO - 2017-12-30 06:03:52 --> Router Class Initialized
INFO - 2017-12-30 06:03:52 --> Output Class Initialized
INFO - 2017-12-30 06:03:52 --> Output Class Initialized
INFO - 2017-12-30 06:03:52 --> Security Class Initialized
INFO - 2017-12-30 06:03:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:52 --> Input Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:52 --> Language Class Initialized
INFO - 2017-12-30 06:03:52 --> Input Class Initialized
INFO - 2017-12-30 06:03:52 --> Language Class Initialized
ERROR - 2017-12-30 06:03:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:03:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:52 --> Config Class Initialized
INFO - 2017-12-30 06:03:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:52 --> URI Class Initialized
INFO - 2017-12-30 06:03:52 --> Router Class Initialized
INFO - 2017-12-30 06:03:52 --> Output Class Initialized
INFO - 2017-12-30 06:03:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:52 --> Input Class Initialized
INFO - 2017-12-30 06:03:52 --> Language Class Initialized
INFO - 2017-12-30 06:03:52 --> Loader Class Initialized
INFO - 2017-12-30 06:03:52 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:52 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:52 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
INFO - 2017-12-30 06:03:52 --> Controller Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
INFO - 2017-12-30 06:03:52 --> Model Class Initialized
DEBUG - 2017-12-30 06:03:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:52 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:52 --> Total execution time: 0.0501
INFO - 2017-12-30 06:03:55 --> Config Class Initialized
INFO - 2017-12-30 06:03:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:55 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:55 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:55 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:55 --> Router Class Initialized
INFO - 2017-12-30 06:03:55 --> Output Class Initialized
INFO - 2017-12-30 06:03:55 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:55 --> Input Class Initialized
INFO - 2017-12-30 06:03:55 --> Language Class Initialized
INFO - 2017-12-30 06:03:55 --> Loader Class Initialized
INFO - 2017-12-30 06:03:55 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:55 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:55 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
INFO - 2017-12-30 06:03:55 --> Controller Class Initialized
INFO - 2017-12-30 06:03:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:55 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:55 --> Total execution time: 0.0565
INFO - 2017-12-30 06:03:55 --> Config Class Initialized
INFO - 2017-12-30 06:03:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:55 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:55 --> URI Class Initialized
INFO - 2017-12-30 06:03:55 --> Router Class Initialized
INFO - 2017-12-30 06:03:55 --> Output Class Initialized
INFO - 2017-12-30 06:03:55 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:55 --> Input Class Initialized
INFO - 2017-12-30 06:03:55 --> Language Class Initialized
ERROR - 2017-12-30 06:03:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:03:55 --> Config Class Initialized
INFO - 2017-12-30 06:03:55 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:55 --> Config Class Initialized
INFO - 2017-12-30 06:03:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:55 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:55 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:55 --> URI Class Initialized
INFO - 2017-12-30 06:03:55 --> URI Class Initialized
INFO - 2017-12-30 06:03:55 --> Router Class Initialized
INFO - 2017-12-30 06:03:55 --> Config Class Initialized
INFO - 2017-12-30 06:03:55 --> Router Class Initialized
INFO - 2017-12-30 06:03:55 --> Hooks Class Initialized
INFO - 2017-12-30 06:03:55 --> Output Class Initialized
INFO - 2017-12-30 06:03:55 --> Output Class Initialized
INFO - 2017-12-30 06:03:55 --> Security Class Initialized
INFO - 2017-12-30 06:03:55 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:55 --> Input Class Initialized
DEBUG - 2017-12-30 06:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:55 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:55 --> Input Class Initialized
INFO - 2017-12-30 06:03:55 --> Language Class Initialized
INFO - 2017-12-30 06:03:55 --> Language Class Initialized
INFO - 2017-12-30 06:03:55 --> URI Class Initialized
ERROR - 2017-12-30 06:03:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:03:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:03:55 --> Router Class Initialized
INFO - 2017-12-30 06:03:55 --> Output Class Initialized
INFO - 2017-12-30 06:03:55 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:55 --> Input Class Initialized
INFO - 2017-12-30 06:03:55 --> Language Class Initialized
INFO - 2017-12-30 06:03:55 --> Loader Class Initialized
INFO - 2017-12-30 06:03:55 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:55 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:55 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
INFO - 2017-12-30 06:03:55 --> Controller Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
INFO - 2017-12-30 06:03:55 --> Model Class Initialized
DEBUG - 2017-12-30 06:03:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:03:55 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:55 --> Total execution time: 0.0476
INFO - 2017-12-30 06:03:58 --> Config Class Initialized
INFO - 2017-12-30 06:03:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:03:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:03:58 --> Utf8 Class Initialized
INFO - 2017-12-30 06:03:58 --> URI Class Initialized
DEBUG - 2017-12-30 06:03:58 --> No URI present. Default controller set.
INFO - 2017-12-30 06:03:58 --> Router Class Initialized
INFO - 2017-12-30 06:03:58 --> Output Class Initialized
INFO - 2017-12-30 06:03:58 --> Security Class Initialized
DEBUG - 2017-12-30 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:03:58 --> Input Class Initialized
INFO - 2017-12-30 06:03:58 --> Language Class Initialized
INFO - 2017-12-30 06:03:58 --> Loader Class Initialized
INFO - 2017-12-30 06:03:58 --> Helper loaded: url_helper
INFO - 2017-12-30 06:03:58 --> Helper loaded: form_helper
INFO - 2017-12-30 06:03:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:03:58 --> Form Validation Class Initialized
INFO - 2017-12-30 06:03:58 --> Model Class Initialized
INFO - 2017-12-30 06:03:58 --> Controller Class Initialized
INFO - 2017-12-30 06:03:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:03:58 --> Final output sent to browser
DEBUG - 2017-12-30 06:03:58 --> Total execution time: 0.0615
INFO - 2017-12-30 06:04:02 --> Config Class Initialized
INFO - 2017-12-30 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:02 --> URI Class Initialized
INFO - 2017-12-30 06:04:02 --> Router Class Initialized
INFO - 2017-12-30 06:04:02 --> Output Class Initialized
INFO - 2017-12-30 06:04:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:02 --> Input Class Initialized
INFO - 2017-12-30 06:04:02 --> Language Class Initialized
ERROR - 2017-12-30 06:04:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:02 --> Config Class Initialized
INFO - 2017-12-30 06:04:02 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:02 --> Config Class Initialized
INFO - 2017-12-30 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:02 --> URI Class Initialized
INFO - 2017-12-30 06:04:02 --> URI Class Initialized
INFO - 2017-12-30 06:04:02 --> Router Class Initialized
INFO - 2017-12-30 06:04:02 --> Router Class Initialized
INFO - 2017-12-30 06:04:02 --> Output Class Initialized
INFO - 2017-12-30 06:04:02 --> Output Class Initialized
INFO - 2017-12-30 06:04:02 --> Security Class Initialized
INFO - 2017-12-30 06:04:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:02 --> Input Class Initialized
INFO - 2017-12-30 06:04:02 --> Input Class Initialized
INFO - 2017-12-30 06:04:02 --> Language Class Initialized
INFO - 2017-12-30 06:04:02 --> Language Class Initialized
ERROR - 2017-12-30 06:04:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:02 --> Config Class Initialized
INFO - 2017-12-30 06:04:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:02 --> URI Class Initialized
INFO - 2017-12-30 06:04:02 --> Router Class Initialized
INFO - 2017-12-30 06:04:02 --> Output Class Initialized
INFO - 2017-12-30 06:04:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:02 --> Input Class Initialized
INFO - 2017-12-30 06:04:02 --> Language Class Initialized
INFO - 2017-12-30 06:04:02 --> Loader Class Initialized
INFO - 2017-12-30 06:04:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:02 --> Model Class Initialized
INFO - 2017-12-30 06:04:02 --> Controller Class Initialized
INFO - 2017-12-30 06:04:02 --> Model Class Initialized
INFO - 2017-12-30 06:04:02 --> Model Class Initialized
INFO - 2017-12-30 06:04:02 --> Model Class Initialized
INFO - 2017-12-30 06:04:02 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:02 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:02 --> Total execution time: 0.0618
INFO - 2017-12-30 06:04:28 --> Config Class Initialized
INFO - 2017-12-30 06:04:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:28 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:28 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:28 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:28 --> Router Class Initialized
INFO - 2017-12-30 06:04:28 --> Output Class Initialized
INFO - 2017-12-30 06:04:28 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:28 --> Input Class Initialized
INFO - 2017-12-30 06:04:28 --> Language Class Initialized
INFO - 2017-12-30 06:04:28 --> Loader Class Initialized
INFO - 2017-12-30 06:04:28 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:28 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:28 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:28 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:28 --> Model Class Initialized
INFO - 2017-12-30 06:04:28 --> Controller Class Initialized
INFO - 2017-12-30 06:04:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:28 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:28 --> Total execution time: 0.0604
INFO - 2017-12-30 06:04:28 --> Config Class Initialized
INFO - 2017-12-30 06:04:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:28 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:28 --> URI Class Initialized
INFO - 2017-12-30 06:04:28 --> Router Class Initialized
INFO - 2017-12-30 06:04:28 --> Output Class Initialized
INFO - 2017-12-30 06:04:28 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:28 --> Input Class Initialized
INFO - 2017-12-30 06:04:28 --> Language Class Initialized
ERROR - 2017-12-30 06:04:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:28 --> Config Class Initialized
INFO - 2017-12-30 06:04:28 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:28 --> Config Class Initialized
INFO - 2017-12-30 06:04:28 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:28 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:04:28 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
ERROR - 2017-12-30 06:04:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
INFO - 2017-12-30 06:04:29 --> Loader Class Initialized
INFO - 2017-12-30 06:04:29 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:29 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:29 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
INFO - 2017-12-30 06:04:29 --> Controller Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:29 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
INFO - 2017-12-30 06:04:29 --> Loader Class Initialized
INFO - 2017-12-30 06:04:29 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:29 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:29 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:29 --> Model Class Initialized
INFO - 2017-12-30 06:04:29 --> Controller Class Initialized
INFO - 2017-12-30 06:04:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:29 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:29 --> Total execution time: 0.0465
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
ERROR - 2017-12-30 06:04:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
ERROR - 2017-12-30 06:04:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:29 --> Config Class Initialized
INFO - 2017-12-30 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:29 --> URI Class Initialized
INFO - 2017-12-30 06:04:29 --> Router Class Initialized
INFO - 2017-12-30 06:04:29 --> Output Class Initialized
INFO - 2017-12-30 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:29 --> Input Class Initialized
INFO - 2017-12-30 06:04:29 --> Language Class Initialized
INFO - 2017-12-30 06:04:29 --> Loader Class Initialized
INFO - 2017-12-30 06:04:29 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Controller Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:30 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Loader Class Initialized
INFO - 2017-12-30 06:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Controller Class Initialized
INFO - 2017-12-30 06:04:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:30 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:30 --> Total execution time: 0.0781
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Loader Class Initialized
INFO - 2017-12-30 06:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Controller Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:30 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Loader Class Initialized
INFO - 2017-12-30 06:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Controller Class Initialized
INFO - 2017-12-30 06:04:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:30 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:30 --> Total execution time: 0.0519
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
INFO - 2017-12-30 06:04:30 --> Loader Class Initialized
INFO - 2017-12-30 06:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Config Class Initialized
INFO - 2017-12-30 06:04:30 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:30 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:30 --> URI Class Initialized
INFO - 2017-12-30 06:04:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-30 06:04:30 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:30 --> Router Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Controller Class Initialized
INFO - 2017-12-30 06:04:30 --> Output Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Security Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Input Class Initialized
INFO - 2017-12-30 06:04:30 --> Model Class Initialized
INFO - 2017-12-30 06:04:30 --> Language Class Initialized
DEBUG - 2017-12-30 06:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:30 --> Loader Class Initialized
INFO - 2017-12-30 06:04:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Controller Class Initialized
INFO - 2017-12-30 06:04:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:31 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:31 --> Total execution time: 0.0550
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
DEBUG - 2017-12-30 06:04:31 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Loader Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: form_helper
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Loader Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:31 --> Database Driver Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: form_helper
DEBUG - 2017-12-30 06:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:31 --> Database Driver Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Controller Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Controller Class Initialized
INFO - 2017-12-30 06:04:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:31 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:31 --> Total execution time: 0.0496
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:31 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> Loader Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Database Driver Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2017-12-30 06:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Controller Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:31 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:31 --> Total execution time: 0.0517
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:31 --> Config Class Initialized
INFO - 2017-12-30 06:04:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> URI Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Router Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Output Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
INFO - 2017-12-30 06:04:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:31 --> Input Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
INFO - 2017-12-30 06:04:31 --> Language Class Initialized
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:31 --> Loader Class Initialized
INFO - 2017-12-30 06:04:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:31 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:31 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Controller Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
INFO - 2017-12-30 06:04:31 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:50 --> Config Class Initialized
INFO - 2017-12-30 06:04:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:50 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:50 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:50 --> Router Class Initialized
INFO - 2017-12-30 06:04:50 --> Output Class Initialized
INFO - 2017-12-30 06:04:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:50 --> Input Class Initialized
INFO - 2017-12-30 06:04:50 --> Language Class Initialized
INFO - 2017-12-30 06:04:50 --> Loader Class Initialized
INFO - 2017-12-30 06:04:50 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:50 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:50 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
INFO - 2017-12-30 06:04:50 --> Controller Class Initialized
INFO - 2017-12-30 06:04:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:50 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:50 --> Total execution time: 0.0544
INFO - 2017-12-30 06:04:50 --> Config Class Initialized
INFO - 2017-12-30 06:04:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:50 --> URI Class Initialized
INFO - 2017-12-30 06:04:50 --> Router Class Initialized
INFO - 2017-12-30 06:04:50 --> Output Class Initialized
INFO - 2017-12-30 06:04:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:50 --> Input Class Initialized
INFO - 2017-12-30 06:04:50 --> Language Class Initialized
ERROR - 2017-12-30 06:04:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:50 --> Config Class Initialized
INFO - 2017-12-30 06:04:50 --> Config Class Initialized
INFO - 2017-12-30 06:04:50 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:04:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:50 --> URI Class Initialized
INFO - 2017-12-30 06:04:50 --> URI Class Initialized
INFO - 2017-12-30 06:04:50 --> Router Class Initialized
INFO - 2017-12-30 06:04:50 --> Router Class Initialized
INFO - 2017-12-30 06:04:50 --> Output Class Initialized
INFO - 2017-12-30 06:04:50 --> Output Class Initialized
INFO - 2017-12-30 06:04:50 --> Security Class Initialized
INFO - 2017-12-30 06:04:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:50 --> Input Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:50 --> Language Class Initialized
INFO - 2017-12-30 06:04:50 --> Input Class Initialized
INFO - 2017-12-30 06:04:50 --> Language Class Initialized
ERROR - 2017-12-30 06:04:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:50 --> Config Class Initialized
INFO - 2017-12-30 06:04:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:50 --> URI Class Initialized
INFO - 2017-12-30 06:04:50 --> Router Class Initialized
INFO - 2017-12-30 06:04:50 --> Output Class Initialized
INFO - 2017-12-30 06:04:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:50 --> Input Class Initialized
INFO - 2017-12-30 06:04:50 --> Language Class Initialized
INFO - 2017-12-30 06:04:50 --> Loader Class Initialized
INFO - 2017-12-30 06:04:50 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:50 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:50 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
INFO - 2017-12-30 06:04:50 --> Controller Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
INFO - 2017-12-30 06:04:50 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:04:51 --> Config Class Initialized
INFO - 2017-12-30 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:51 --> URI Class Initialized
DEBUG - 2017-12-30 06:04:51 --> No URI present. Default controller set.
INFO - 2017-12-30 06:04:51 --> Router Class Initialized
INFO - 2017-12-30 06:04:51 --> Output Class Initialized
INFO - 2017-12-30 06:04:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:51 --> Input Class Initialized
INFO - 2017-12-30 06:04:51 --> Language Class Initialized
INFO - 2017-12-30 06:04:51 --> Loader Class Initialized
INFO - 2017-12-30 06:04:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
INFO - 2017-12-30 06:04:51 --> Controller Class Initialized
INFO - 2017-12-30 06:04:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:04:51 --> Final output sent to browser
DEBUG - 2017-12-30 06:04:51 --> Total execution time: 0.0556
INFO - 2017-12-30 06:04:51 --> Config Class Initialized
INFO - 2017-12-30 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:51 --> URI Class Initialized
INFO - 2017-12-30 06:04:51 --> Router Class Initialized
INFO - 2017-12-30 06:04:51 --> Output Class Initialized
INFO - 2017-12-30 06:04:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:51 --> Input Class Initialized
INFO - 2017-12-30 06:04:51 --> Language Class Initialized
ERROR - 2017-12-30 06:04:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:04:51 --> Config Class Initialized
INFO - 2017-12-30 06:04:51 --> Config Class Initialized
INFO - 2017-12-30 06:04:51 --> Hooks Class Initialized
INFO - 2017-12-30 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:51 --> URI Class Initialized
INFO - 2017-12-30 06:04:51 --> URI Class Initialized
INFO - 2017-12-30 06:04:51 --> Router Class Initialized
INFO - 2017-12-30 06:04:51 --> Router Class Initialized
INFO - 2017-12-30 06:04:51 --> Output Class Initialized
INFO - 2017-12-30 06:04:51 --> Output Class Initialized
INFO - 2017-12-30 06:04:51 --> Security Class Initialized
INFO - 2017-12-30 06:04:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:51 --> Input Class Initialized
INFO - 2017-12-30 06:04:51 --> Input Class Initialized
INFO - 2017-12-30 06:04:51 --> Language Class Initialized
INFO - 2017-12-30 06:04:51 --> Language Class Initialized
ERROR - 2017-12-30 06:04:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:04:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:04:51 --> Config Class Initialized
INFO - 2017-12-30 06:04:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:04:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:04:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:04:51 --> URI Class Initialized
INFO - 2017-12-30 06:04:51 --> Router Class Initialized
INFO - 2017-12-30 06:04:51 --> Output Class Initialized
INFO - 2017-12-30 06:04:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:04:51 --> Input Class Initialized
INFO - 2017-12-30 06:04:51 --> Language Class Initialized
INFO - 2017-12-30 06:04:51 --> Loader Class Initialized
INFO - 2017-12-30 06:04:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:04:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:04:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:04:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
INFO - 2017-12-30 06:04:51 --> Controller Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
INFO - 2017-12-30 06:04:51 --> Model Class Initialized
DEBUG - 2017-12-30 06:04:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:05:10 --> Config Class Initialized
INFO - 2017-12-30 06:05:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:05:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:05:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:05:10 --> URI Class Initialized
DEBUG - 2017-12-30 06:05:10 --> No URI present. Default controller set.
INFO - 2017-12-30 06:05:10 --> Router Class Initialized
INFO - 2017-12-30 06:05:10 --> Output Class Initialized
INFO - 2017-12-30 06:05:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:05:10 --> Input Class Initialized
INFO - 2017-12-30 06:05:10 --> Language Class Initialized
INFO - 2017-12-30 06:05:10 --> Loader Class Initialized
INFO - 2017-12-30 06:05:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:05:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:05:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:05:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
INFO - 2017-12-30 06:05:10 --> Controller Class Initialized
INFO - 2017-12-30 06:05:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:05:10 --> Final output sent to browser
DEBUG - 2017-12-30 06:05:10 --> Total execution time: 0.0635
INFO - 2017-12-30 06:05:10 --> Config Class Initialized
INFO - 2017-12-30 06:05:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:05:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:05:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:05:10 --> URI Class Initialized
INFO - 2017-12-30 06:05:10 --> Router Class Initialized
INFO - 2017-12-30 06:05:10 --> Output Class Initialized
INFO - 2017-12-30 06:05:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:05:10 --> Input Class Initialized
INFO - 2017-12-30 06:05:10 --> Language Class Initialized
ERROR - 2017-12-30 06:05:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:05:10 --> Config Class Initialized
INFO - 2017-12-30 06:05:10 --> Hooks Class Initialized
INFO - 2017-12-30 06:05:10 --> Config Class Initialized
INFO - 2017-12-30 06:05:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:05:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:05:10 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:05:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:05:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:05:10 --> URI Class Initialized
INFO - 2017-12-30 06:05:10 --> URI Class Initialized
INFO - 2017-12-30 06:05:10 --> Router Class Initialized
INFO - 2017-12-30 06:05:10 --> Router Class Initialized
INFO - 2017-12-30 06:05:10 --> Output Class Initialized
INFO - 2017-12-30 06:05:10 --> Output Class Initialized
INFO - 2017-12-30 06:05:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:05:10 --> Security Class Initialized
INFO - 2017-12-30 06:05:10 --> Input Class Initialized
INFO - 2017-12-30 06:05:10 --> Language Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:05:10 --> Input Class Initialized
INFO - 2017-12-30 06:05:10 --> Language Class Initialized
ERROR - 2017-12-30 06:05:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:05:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:05:10 --> Config Class Initialized
INFO - 2017-12-30 06:05:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:05:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:05:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:05:10 --> URI Class Initialized
INFO - 2017-12-30 06:05:10 --> Router Class Initialized
INFO - 2017-12-30 06:05:10 --> Output Class Initialized
INFO - 2017-12-30 06:05:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:05:10 --> Input Class Initialized
INFO - 2017-12-30 06:05:10 --> Language Class Initialized
INFO - 2017-12-30 06:05:10 --> Loader Class Initialized
INFO - 2017-12-30 06:05:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:05:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:05:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:05:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
INFO - 2017-12-30 06:05:10 --> Controller Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
INFO - 2017-12-30 06:05:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:05:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:06:37 --> Config Class Initialized
INFO - 2017-12-30 06:06:37 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:06:37 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:06:37 --> Utf8 Class Initialized
INFO - 2017-12-30 06:06:37 --> URI Class Initialized
DEBUG - 2017-12-30 06:06:37 --> No URI present. Default controller set.
INFO - 2017-12-30 06:06:37 --> Router Class Initialized
INFO - 2017-12-30 06:06:37 --> Output Class Initialized
INFO - 2017-12-30 06:06:37 --> Security Class Initialized
DEBUG - 2017-12-30 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:06:37 --> Input Class Initialized
INFO - 2017-12-30 06:06:37 --> Language Class Initialized
INFO - 2017-12-30 06:06:37 --> Loader Class Initialized
INFO - 2017-12-30 06:06:37 --> Helper loaded: url_helper
INFO - 2017-12-30 06:06:37 --> Helper loaded: form_helper
INFO - 2017-12-30 06:06:37 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:06:37 --> Form Validation Class Initialized
INFO - 2017-12-30 06:06:37 --> Model Class Initialized
INFO - 2017-12-30 06:06:37 --> Controller Class Initialized
INFO - 2017-12-30 06:06:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:06:37 --> Final output sent to browser
DEBUG - 2017-12-30 06:06:37 --> Total execution time: 0.0639
INFO - 2017-12-30 06:06:38 --> Config Class Initialized
INFO - 2017-12-30 06:06:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:06:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:06:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:06:38 --> URI Class Initialized
INFO - 2017-12-30 06:06:38 --> Router Class Initialized
INFO - 2017-12-30 06:06:38 --> Output Class Initialized
INFO - 2017-12-30 06:06:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:06:38 --> Input Class Initialized
INFO - 2017-12-30 06:06:38 --> Language Class Initialized
ERROR - 2017-12-30 06:06:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:06:38 --> Config Class Initialized
INFO - 2017-12-30 06:06:38 --> Hooks Class Initialized
INFO - 2017-12-30 06:06:38 --> Config Class Initialized
INFO - 2017-12-30 06:06:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:06:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:06:38 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:06:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:06:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:06:38 --> URI Class Initialized
INFO - 2017-12-30 06:06:38 --> URI Class Initialized
INFO - 2017-12-30 06:06:38 --> Router Class Initialized
INFO - 2017-12-30 06:06:38 --> Router Class Initialized
INFO - 2017-12-30 06:06:38 --> Output Class Initialized
INFO - 2017-12-30 06:06:38 --> Output Class Initialized
INFO - 2017-12-30 06:06:38 --> Security Class Initialized
INFO - 2017-12-30 06:06:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:06:38 --> Input Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:06:38 --> Input Class Initialized
INFO - 2017-12-30 06:06:38 --> Language Class Initialized
INFO - 2017-12-30 06:06:38 --> Language Class Initialized
ERROR - 2017-12-30 06:06:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:06:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:06:38 --> Config Class Initialized
INFO - 2017-12-30 06:06:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:06:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:06:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:06:38 --> URI Class Initialized
INFO - 2017-12-30 06:06:38 --> Router Class Initialized
INFO - 2017-12-30 06:06:38 --> Output Class Initialized
INFO - 2017-12-30 06:06:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:06:38 --> Input Class Initialized
INFO - 2017-12-30 06:06:38 --> Language Class Initialized
INFO - 2017-12-30 06:06:38 --> Loader Class Initialized
INFO - 2017-12-30 06:06:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:06:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:06:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:06:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:06:38 --> Model Class Initialized
INFO - 2017-12-30 06:06:38 --> Controller Class Initialized
INFO - 2017-12-30 06:06:38 --> Model Class Initialized
INFO - 2017-12-30 06:06:38 --> Model Class Initialized
INFO - 2017-12-30 06:06:38 --> Model Class Initialized
INFO - 2017-12-30 06:06:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:06:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:08:02 --> Config Class Initialized
INFO - 2017-12-30 06:08:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:02 --> URI Class Initialized
DEBUG - 2017-12-30 06:08:02 --> No URI present. Default controller set.
INFO - 2017-12-30 06:08:02 --> Router Class Initialized
INFO - 2017-12-30 06:08:02 --> Output Class Initialized
INFO - 2017-12-30 06:08:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:02 --> Input Class Initialized
INFO - 2017-12-30 06:08:02 --> Language Class Initialized
INFO - 2017-12-30 06:08:02 --> Loader Class Initialized
INFO - 2017-12-30 06:08:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
INFO - 2017-12-30 06:08:02 --> Controller Class Initialized
INFO - 2017-12-30 06:08:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:08:02 --> Final output sent to browser
DEBUG - 2017-12-30 06:08:02 --> Total execution time: 0.0683
INFO - 2017-12-30 06:08:02 --> Config Class Initialized
INFO - 2017-12-30 06:08:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:02 --> URI Class Initialized
INFO - 2017-12-30 06:08:02 --> Router Class Initialized
INFO - 2017-12-30 06:08:02 --> Output Class Initialized
INFO - 2017-12-30 06:08:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:02 --> Input Class Initialized
INFO - 2017-12-30 06:08:02 --> Language Class Initialized
INFO - 2017-12-30 06:08:02 --> Loader Class Initialized
INFO - 2017-12-30 06:08:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
INFO - 2017-12-30 06:08:02 --> Controller Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
INFO - 2017-12-30 06:08:02 --> Model Class Initialized
DEBUG - 2017-12-30 06:08:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:08:21 --> Config Class Initialized
INFO - 2017-12-30 06:08:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:21 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:21 --> URI Class Initialized
DEBUG - 2017-12-30 06:08:21 --> No URI present. Default controller set.
INFO - 2017-12-30 06:08:21 --> Router Class Initialized
INFO - 2017-12-30 06:08:21 --> Output Class Initialized
INFO - 2017-12-30 06:08:21 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:21 --> Input Class Initialized
INFO - 2017-12-30 06:08:21 --> Language Class Initialized
INFO - 2017-12-30 06:08:21 --> Loader Class Initialized
INFO - 2017-12-30 06:08:21 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:21 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:21 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
INFO - 2017-12-30 06:08:21 --> Controller Class Initialized
INFO - 2017-12-30 06:08:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:08:21 --> Final output sent to browser
DEBUG - 2017-12-30 06:08:21 --> Total execution time: 0.0646
INFO - 2017-12-30 06:08:21 --> Config Class Initialized
INFO - 2017-12-30 06:08:21 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:21 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:21 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:21 --> URI Class Initialized
INFO - 2017-12-30 06:08:21 --> Router Class Initialized
INFO - 2017-12-30 06:08:21 --> Output Class Initialized
INFO - 2017-12-30 06:08:21 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:21 --> Input Class Initialized
INFO - 2017-12-30 06:08:21 --> Language Class Initialized
INFO - 2017-12-30 06:08:21 --> Loader Class Initialized
INFO - 2017-12-30 06:08:21 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:21 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:21 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:21 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
INFO - 2017-12-30 06:08:21 --> Controller Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
INFO - 2017-12-30 06:08:21 --> Model Class Initialized
DEBUG - 2017-12-30 06:08:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:08:44 --> Config Class Initialized
INFO - 2017-12-30 06:08:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:44 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:44 --> URI Class Initialized
DEBUG - 2017-12-30 06:08:44 --> No URI present. Default controller set.
INFO - 2017-12-30 06:08:44 --> Router Class Initialized
INFO - 2017-12-30 06:08:44 --> Output Class Initialized
INFO - 2017-12-30 06:08:44 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:44 --> Input Class Initialized
INFO - 2017-12-30 06:08:44 --> Language Class Initialized
INFO - 2017-12-30 06:08:44 --> Loader Class Initialized
INFO - 2017-12-30 06:08:44 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:44 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:44 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:44 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
INFO - 2017-12-30 06:08:44 --> Controller Class Initialized
INFO - 2017-12-30 06:08:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:08:44 --> Final output sent to browser
DEBUG - 2017-12-30 06:08:44 --> Total execution time: 0.0485
INFO - 2017-12-30 06:08:44 --> Config Class Initialized
INFO - 2017-12-30 06:08:44 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:08:44 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:08:44 --> Utf8 Class Initialized
INFO - 2017-12-30 06:08:44 --> URI Class Initialized
INFO - 2017-12-30 06:08:44 --> Router Class Initialized
INFO - 2017-12-30 06:08:44 --> Output Class Initialized
INFO - 2017-12-30 06:08:44 --> Security Class Initialized
DEBUG - 2017-12-30 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:08:44 --> Input Class Initialized
INFO - 2017-12-30 06:08:44 --> Language Class Initialized
INFO - 2017-12-30 06:08:44 --> Loader Class Initialized
INFO - 2017-12-30 06:08:44 --> Helper loaded: url_helper
INFO - 2017-12-30 06:08:44 --> Helper loaded: form_helper
INFO - 2017-12-30 06:08:44 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:08:44 --> Form Validation Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
INFO - 2017-12-30 06:08:44 --> Controller Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
INFO - 2017-12-30 06:08:44 --> Model Class Initialized
DEBUG - 2017-12-30 06:08:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:09:06 --> Config Class Initialized
INFO - 2017-12-30 06:09:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:09:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:09:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:09:06 --> URI Class Initialized
DEBUG - 2017-12-30 06:09:06 --> No URI present. Default controller set.
INFO - 2017-12-30 06:09:06 --> Router Class Initialized
INFO - 2017-12-30 06:09:06 --> Output Class Initialized
INFO - 2017-12-30 06:09:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:09:06 --> Input Class Initialized
INFO - 2017-12-30 06:09:06 --> Language Class Initialized
INFO - 2017-12-30 06:09:06 --> Loader Class Initialized
INFO - 2017-12-30 06:09:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:09:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:09:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:09:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
INFO - 2017-12-30 06:09:06 --> Controller Class Initialized
INFO - 2017-12-30 06:09:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:09:06 --> Final output sent to browser
DEBUG - 2017-12-30 06:09:06 --> Total execution time: 0.0525
INFO - 2017-12-30 06:09:06 --> Config Class Initialized
INFO - 2017-12-30 06:09:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:09:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:09:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:09:06 --> URI Class Initialized
INFO - 2017-12-30 06:09:06 --> Router Class Initialized
INFO - 2017-12-30 06:09:06 --> Output Class Initialized
INFO - 2017-12-30 06:09:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:09:06 --> Input Class Initialized
INFO - 2017-12-30 06:09:06 --> Language Class Initialized
INFO - 2017-12-30 06:09:06 --> Loader Class Initialized
INFO - 2017-12-30 06:09:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:09:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:09:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:09:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
INFO - 2017-12-30 06:09:06 --> Controller Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
INFO - 2017-12-30 06:09:06 --> Model Class Initialized
DEBUG - 2017-12-30 06:09:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:09:58 --> Config Class Initialized
INFO - 2017-12-30 06:09:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:09:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:09:58 --> Utf8 Class Initialized
INFO - 2017-12-30 06:09:58 --> URI Class Initialized
DEBUG - 2017-12-30 06:09:58 --> No URI present. Default controller set.
INFO - 2017-12-30 06:09:58 --> Router Class Initialized
INFO - 2017-12-30 06:09:58 --> Output Class Initialized
INFO - 2017-12-30 06:09:58 --> Security Class Initialized
DEBUG - 2017-12-30 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:09:58 --> Input Class Initialized
INFO - 2017-12-30 06:09:58 --> Language Class Initialized
INFO - 2017-12-30 06:09:58 --> Loader Class Initialized
INFO - 2017-12-30 06:09:58 --> Helper loaded: url_helper
INFO - 2017-12-30 06:09:58 --> Helper loaded: form_helper
INFO - 2017-12-30 06:09:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:09:58 --> Form Validation Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
INFO - 2017-12-30 06:09:58 --> Controller Class Initialized
INFO - 2017-12-30 06:09:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:09:58 --> Final output sent to browser
DEBUG - 2017-12-30 06:09:58 --> Total execution time: 0.0622
INFO - 2017-12-30 06:09:58 --> Config Class Initialized
INFO - 2017-12-30 06:09:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:09:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:09:58 --> Utf8 Class Initialized
INFO - 2017-12-30 06:09:58 --> URI Class Initialized
INFO - 2017-12-30 06:09:58 --> Router Class Initialized
INFO - 2017-12-30 06:09:58 --> Output Class Initialized
INFO - 2017-12-30 06:09:58 --> Security Class Initialized
DEBUG - 2017-12-30 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:09:58 --> Input Class Initialized
INFO - 2017-12-30 06:09:58 --> Language Class Initialized
INFO - 2017-12-30 06:09:58 --> Loader Class Initialized
INFO - 2017-12-30 06:09:58 --> Helper loaded: url_helper
INFO - 2017-12-30 06:09:58 --> Helper loaded: form_helper
INFO - 2017-12-30 06:09:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:09:58 --> Form Validation Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
INFO - 2017-12-30 06:09:58 --> Controller Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
INFO - 2017-12-30 06:09:58 --> Model Class Initialized
DEBUG - 2017-12-30 06:09:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:51 --> Config Class Initialized
INFO - 2017-12-30 06:11:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:51 --> URI Class Initialized
DEBUG - 2017-12-30 06:11:51 --> No URI present. Default controller set.
INFO - 2017-12-30 06:11:51 --> Router Class Initialized
INFO - 2017-12-30 06:11:51 --> Output Class Initialized
INFO - 2017-12-30 06:11:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:51 --> Input Class Initialized
INFO - 2017-12-30 06:11:51 --> Language Class Initialized
INFO - 2017-12-30 06:11:51 --> Loader Class Initialized
INFO - 2017-12-30 06:11:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
INFO - 2017-12-30 06:11:51 --> Controller Class Initialized
INFO - 2017-12-30 06:11:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:51 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:51 --> Total execution time: 0.0655
INFO - 2017-12-30 06:11:51 --> Config Class Initialized
INFO - 2017-12-30 06:11:51 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:51 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:51 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:51 --> URI Class Initialized
INFO - 2017-12-30 06:11:51 --> Router Class Initialized
INFO - 2017-12-30 06:11:51 --> Output Class Initialized
INFO - 2017-12-30 06:11:51 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:51 --> Input Class Initialized
INFO - 2017-12-30 06:11:51 --> Language Class Initialized
INFO - 2017-12-30 06:11:51 --> Loader Class Initialized
INFO - 2017-12-30 06:11:51 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:51 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:51 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:51 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
INFO - 2017-12-30 06:11:51 --> Controller Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
INFO - 2017-12-30 06:11:51 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:53 --> Config Class Initialized
INFO - 2017-12-30 06:11:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:53 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:53 --> URI Class Initialized
INFO - 2017-12-30 06:11:53 --> Router Class Initialized
INFO - 2017-12-30 06:11:53 --> Output Class Initialized
INFO - 2017-12-30 06:11:53 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:53 --> Input Class Initialized
INFO - 2017-12-30 06:11:53 --> Language Class Initialized
INFO - 2017-12-30 06:11:53 --> Loader Class Initialized
INFO - 2017-12-30 06:11:53 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:53 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:53 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Controller Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:53 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:53 --> Total execution time: 0.0545
INFO - 2017-12-30 06:11:53 --> Config Class Initialized
INFO - 2017-12-30 06:11:53 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:53 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:53 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:53 --> URI Class Initialized
INFO - 2017-12-30 06:11:53 --> Router Class Initialized
INFO - 2017-12-30 06:11:53 --> Output Class Initialized
INFO - 2017-12-30 06:11:53 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:53 --> Input Class Initialized
INFO - 2017-12-30 06:11:53 --> Language Class Initialized
INFO - 2017-12-30 06:11:53 --> Loader Class Initialized
INFO - 2017-12-30 06:11:53 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:53 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:53 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:53 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Controller Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
INFO - 2017-12-30 06:11:53 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:54 --> Config Class Initialized
INFO - 2017-12-30 06:11:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:54 --> URI Class Initialized
DEBUG - 2017-12-30 06:11:54 --> No URI present. Default controller set.
INFO - 2017-12-30 06:11:54 --> Router Class Initialized
INFO - 2017-12-30 06:11:54 --> Output Class Initialized
INFO - 2017-12-30 06:11:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:54 --> Input Class Initialized
INFO - 2017-12-30 06:11:54 --> Language Class Initialized
INFO - 2017-12-30 06:11:54 --> Loader Class Initialized
INFO - 2017-12-30 06:11:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
INFO - 2017-12-30 06:11:54 --> Controller Class Initialized
INFO - 2017-12-30 06:11:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:54 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:54 --> Total execution time: 0.0630
INFO - 2017-12-30 06:11:54 --> Config Class Initialized
INFO - 2017-12-30 06:11:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:54 --> URI Class Initialized
INFO - 2017-12-30 06:11:54 --> Router Class Initialized
INFO - 2017-12-30 06:11:54 --> Output Class Initialized
INFO - 2017-12-30 06:11:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:54 --> Input Class Initialized
INFO - 2017-12-30 06:11:54 --> Language Class Initialized
INFO - 2017-12-30 06:11:54 --> Loader Class Initialized
INFO - 2017-12-30 06:11:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
INFO - 2017-12-30 06:11:54 --> Controller Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
INFO - 2017-12-30 06:11:54 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:55 --> Config Class Initialized
INFO - 2017-12-30 06:11:55 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:55 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:55 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:55 --> URI Class Initialized
INFO - 2017-12-30 06:11:55 --> Router Class Initialized
INFO - 2017-12-30 06:11:55 --> Output Class Initialized
INFO - 2017-12-30 06:11:55 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:55 --> Input Class Initialized
INFO - 2017-12-30 06:11:55 --> Language Class Initialized
INFO - 2017-12-30 06:11:55 --> Loader Class Initialized
INFO - 2017-12-30 06:11:55 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:55 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:55 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:55 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:55 --> Model Class Initialized
INFO - 2017-12-30 06:11:55 --> Controller Class Initialized
INFO - 2017-12-30 06:11:55 --> Model Class Initialized
INFO - 2017-12-30 06:11:55 --> Model Class Initialized
INFO - 2017-12-30 06:11:55 --> Model Class Initialized
INFO - 2017-12-30 06:11:55 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:55 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:55 --> Total execution time: 0.0630
INFO - 2017-12-30 06:11:56 --> Config Class Initialized
INFO - 2017-12-30 06:11:56 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:56 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:56 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:56 --> URI Class Initialized
DEBUG - 2017-12-30 06:11:56 --> No URI present. Default controller set.
INFO - 2017-12-30 06:11:56 --> Router Class Initialized
INFO - 2017-12-30 06:11:56 --> Output Class Initialized
INFO - 2017-12-30 06:11:56 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:56 --> Input Class Initialized
INFO - 2017-12-30 06:11:56 --> Language Class Initialized
INFO - 2017-12-30 06:11:56 --> Loader Class Initialized
INFO - 2017-12-30 06:11:56 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:56 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:56 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Controller Class Initialized
INFO - 2017-12-30 06:11:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:57 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:57 --> Total execution time: 0.0562
INFO - 2017-12-30 06:11:57 --> Config Class Initialized
INFO - 2017-12-30 06:11:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:57 --> URI Class Initialized
INFO - 2017-12-30 06:11:57 --> Router Class Initialized
INFO - 2017-12-30 06:11:57 --> Output Class Initialized
INFO - 2017-12-30 06:11:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:57 --> Input Class Initialized
INFO - 2017-12-30 06:11:57 --> Language Class Initialized
INFO - 2017-12-30 06:11:57 --> Loader Class Initialized
INFO - 2017-12-30 06:11:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Controller Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:57 --> Config Class Initialized
INFO - 2017-12-30 06:11:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:57 --> URI Class Initialized
INFO - 2017-12-30 06:11:57 --> Router Class Initialized
INFO - 2017-12-30 06:11:57 --> Output Class Initialized
INFO - 2017-12-30 06:11:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:57 --> Input Class Initialized
INFO - 2017-12-30 06:11:57 --> Language Class Initialized
INFO - 2017-12-30 06:11:57 --> Loader Class Initialized
INFO - 2017-12-30 06:11:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Controller Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
INFO - 2017-12-30 06:11:57 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:58 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:58 --> Total execution time: 0.0512
INFO - 2017-12-30 06:11:58 --> Config Class Initialized
INFO - 2017-12-30 06:11:58 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:58 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:58 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:58 --> URI Class Initialized
INFO - 2017-12-30 06:11:58 --> Router Class Initialized
INFO - 2017-12-30 06:11:58 --> Output Class Initialized
INFO - 2017-12-30 06:11:58 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:58 --> Input Class Initialized
INFO - 2017-12-30 06:11:58 --> Language Class Initialized
INFO - 2017-12-30 06:11:58 --> Loader Class Initialized
INFO - 2017-12-30 06:11:58 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:58 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:58 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:58 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:58 --> Model Class Initialized
INFO - 2017-12-30 06:11:58 --> Controller Class Initialized
INFO - 2017-12-30 06:11:58 --> Model Class Initialized
INFO - 2017-12-30 06:11:58 --> Model Class Initialized
INFO - 2017-12-30 06:11:58 --> Model Class Initialized
INFO - 2017-12-30 06:11:58 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:11:59 --> Config Class Initialized
INFO - 2017-12-30 06:11:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:59 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:59 --> URI Class Initialized
DEBUG - 2017-12-30 06:11:59 --> No URI present. Default controller set.
INFO - 2017-12-30 06:11:59 --> Router Class Initialized
INFO - 2017-12-30 06:11:59 --> Output Class Initialized
INFO - 2017-12-30 06:11:59 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:59 --> Input Class Initialized
INFO - 2017-12-30 06:11:59 --> Language Class Initialized
INFO - 2017-12-30 06:11:59 --> Loader Class Initialized
INFO - 2017-12-30 06:11:59 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:59 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:59 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
INFO - 2017-12-30 06:11:59 --> Controller Class Initialized
INFO - 2017-12-30 06:11:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:11:59 --> Final output sent to browser
DEBUG - 2017-12-30 06:11:59 --> Total execution time: 0.0493
INFO - 2017-12-30 06:11:59 --> Config Class Initialized
INFO - 2017-12-30 06:11:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:11:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:11:59 --> Utf8 Class Initialized
INFO - 2017-12-30 06:11:59 --> URI Class Initialized
INFO - 2017-12-30 06:11:59 --> Router Class Initialized
INFO - 2017-12-30 06:11:59 --> Output Class Initialized
INFO - 2017-12-30 06:11:59 --> Security Class Initialized
DEBUG - 2017-12-30 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:11:59 --> Input Class Initialized
INFO - 2017-12-30 06:11:59 --> Language Class Initialized
INFO - 2017-12-30 06:11:59 --> Loader Class Initialized
INFO - 2017-12-30 06:11:59 --> Helper loaded: url_helper
INFO - 2017-12-30 06:11:59 --> Helper loaded: form_helper
INFO - 2017-12-30 06:11:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:11:59 --> Form Validation Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
INFO - 2017-12-30 06:11:59 --> Controller Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
INFO - 2017-12-30 06:11:59 --> Model Class Initialized
DEBUG - 2017-12-30 06:11:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:12:46 --> Config Class Initialized
INFO - 2017-12-30 06:12:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:12:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:12:46 --> Utf8 Class Initialized
INFO - 2017-12-30 06:12:46 --> URI Class Initialized
INFO - 2017-12-30 06:12:46 --> Router Class Initialized
INFO - 2017-12-30 06:12:46 --> Output Class Initialized
INFO - 2017-12-30 06:12:46 --> Security Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:12:46 --> Input Class Initialized
INFO - 2017-12-30 06:12:46 --> Language Class Initialized
INFO - 2017-12-30 06:12:46 --> Loader Class Initialized
INFO - 2017-12-30 06:12:46 --> Helper loaded: url_helper
INFO - 2017-12-30 06:12:46 --> Helper loaded: form_helper
INFO - 2017-12-30 06:12:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:12:46 --> Form Validation Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
INFO - 2017-12-30 06:12:46 --> Controller Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:12:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:12:46 --> Final output sent to browser
DEBUG - 2017-12-30 06:12:46 --> Total execution time: 0.0422
INFO - 2017-12-30 06:12:46 --> Config Class Initialized
INFO - 2017-12-30 06:12:46 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:12:46 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:12:46 --> Utf8 Class Initialized
INFO - 2017-12-30 06:12:46 --> URI Class Initialized
INFO - 2017-12-30 06:12:46 --> Router Class Initialized
INFO - 2017-12-30 06:12:46 --> Output Class Initialized
INFO - 2017-12-30 06:12:46 --> Security Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:12:46 --> Input Class Initialized
INFO - 2017-12-30 06:12:46 --> Language Class Initialized
INFO - 2017-12-30 06:12:46 --> Loader Class Initialized
INFO - 2017-12-30 06:12:46 --> Helper loaded: url_helper
INFO - 2017-12-30 06:12:46 --> Helper loaded: form_helper
INFO - 2017-12-30 06:12:46 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:12:46 --> Form Validation Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
INFO - 2017-12-30 06:12:46 --> Controller Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
INFO - 2017-12-30 06:12:46 --> Model Class Initialized
DEBUG - 2017-12-30 06:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:12:47 --> Config Class Initialized
INFO - 2017-12-30 06:12:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:12:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:12:47 --> Utf8 Class Initialized
INFO - 2017-12-30 06:12:47 --> URI Class Initialized
INFO - 2017-12-30 06:12:47 --> Router Class Initialized
INFO - 2017-12-30 06:12:47 --> Output Class Initialized
INFO - 2017-12-30 06:12:47 --> Security Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:12:47 --> Input Class Initialized
INFO - 2017-12-30 06:12:47 --> Language Class Initialized
INFO - 2017-12-30 06:12:47 --> Loader Class Initialized
INFO - 2017-12-30 06:12:47 --> Helper loaded: url_helper
INFO - 2017-12-30 06:12:47 --> Helper loaded: form_helper
INFO - 2017-12-30 06:12:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:12:47 --> Form Validation Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
INFO - 2017-12-30 06:12:47 --> Controller Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:12:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:12:47 --> Final output sent to browser
DEBUG - 2017-12-30 06:12:47 --> Total execution time: 0.0517
INFO - 2017-12-30 06:12:47 --> Config Class Initialized
INFO - 2017-12-30 06:12:47 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:12:47 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:12:47 --> Utf8 Class Initialized
INFO - 2017-12-30 06:12:47 --> URI Class Initialized
INFO - 2017-12-30 06:12:47 --> Router Class Initialized
INFO - 2017-12-30 06:12:47 --> Output Class Initialized
INFO - 2017-12-30 06:12:47 --> Security Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:12:47 --> Input Class Initialized
INFO - 2017-12-30 06:12:47 --> Language Class Initialized
INFO - 2017-12-30 06:12:47 --> Loader Class Initialized
INFO - 2017-12-30 06:12:47 --> Helper loaded: url_helper
INFO - 2017-12-30 06:12:47 --> Helper loaded: form_helper
INFO - 2017-12-30 06:12:47 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:12:47 --> Form Validation Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
INFO - 2017-12-30 06:12:47 --> Controller Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
INFO - 2017-12-30 06:12:47 --> Model Class Initialized
DEBUG - 2017-12-30 06:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:01 --> Config Class Initialized
INFO - 2017-12-30 06:24:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:01 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:01 --> URI Class Initialized
INFO - 2017-12-30 06:24:01 --> Router Class Initialized
INFO - 2017-12-30 06:24:01 --> Output Class Initialized
INFO - 2017-12-30 06:24:01 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:01 --> Input Class Initialized
INFO - 2017-12-30 06:24:01 --> Language Class Initialized
INFO - 2017-12-30 06:24:01 --> Loader Class Initialized
INFO - 2017-12-30 06:24:01 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:01 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:01 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Controller Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:01 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:01 --> Total execution time: 0.0432
INFO - 2017-12-30 06:24:01 --> Config Class Initialized
INFO - 2017-12-30 06:24:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:01 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:01 --> URI Class Initialized
INFO - 2017-12-30 06:24:01 --> Router Class Initialized
INFO - 2017-12-30 06:24:01 --> Output Class Initialized
INFO - 2017-12-30 06:24:01 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:01 --> Input Class Initialized
INFO - 2017-12-30 06:24:01 --> Language Class Initialized
INFO - 2017-12-30 06:24:01 --> Loader Class Initialized
INFO - 2017-12-30 06:24:01 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:01 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:01 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Controller Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:01 --> Config Class Initialized
INFO - 2017-12-30 06:24:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:01 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:01 --> URI Class Initialized
INFO - 2017-12-30 06:24:01 --> Router Class Initialized
INFO - 2017-12-30 06:24:01 --> Output Class Initialized
INFO - 2017-12-30 06:24:01 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:01 --> Input Class Initialized
INFO - 2017-12-30 06:24:01 --> Language Class Initialized
INFO - 2017-12-30 06:24:01 --> Loader Class Initialized
INFO - 2017-12-30 06:24:01 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:01 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:01 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Controller Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:01 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:01 --> Total execution time: 0.0523
INFO - 2017-12-30 06:24:01 --> Config Class Initialized
INFO - 2017-12-30 06:24:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:01 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:01 --> URI Class Initialized
INFO - 2017-12-30 06:24:01 --> Router Class Initialized
INFO - 2017-12-30 06:24:01 --> Output Class Initialized
INFO - 2017-12-30 06:24:01 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:01 --> Input Class Initialized
INFO - 2017-12-30 06:24:01 --> Language Class Initialized
INFO - 2017-12-30 06:24:01 --> Loader Class Initialized
INFO - 2017-12-30 06:24:01 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:01 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:01 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Controller Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
INFO - 2017-12-30 06:24:01 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:03 --> Config Class Initialized
INFO - 2017-12-30 06:24:03 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:03 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:03 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:03 --> URI Class Initialized
INFO - 2017-12-30 06:24:03 --> Router Class Initialized
INFO - 2017-12-30 06:24:03 --> Output Class Initialized
INFO - 2017-12-30 06:24:03 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:03 --> Input Class Initialized
INFO - 2017-12-30 06:24:03 --> Language Class Initialized
INFO - 2017-12-30 06:24:03 --> Loader Class Initialized
INFO - 2017-12-30 06:24:03 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:03 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:03 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:03 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Controller Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:03 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:03 --> Total execution time: 0.0675
INFO - 2017-12-30 06:24:03 --> Config Class Initialized
INFO - 2017-12-30 06:24:03 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:03 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:03 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:03 --> URI Class Initialized
INFO - 2017-12-30 06:24:03 --> Router Class Initialized
INFO - 2017-12-30 06:24:03 --> Output Class Initialized
INFO - 2017-12-30 06:24:03 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:03 --> Input Class Initialized
INFO - 2017-12-30 06:24:03 --> Language Class Initialized
INFO - 2017-12-30 06:24:03 --> Loader Class Initialized
INFO - 2017-12-30 06:24:03 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:03 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:03 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:03 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Controller Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
INFO - 2017-12-30 06:24:03 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:07 --> Config Class Initialized
INFO - 2017-12-30 06:24:07 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:07 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:07 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:07 --> URI Class Initialized
INFO - 2017-12-30 06:24:07 --> Router Class Initialized
INFO - 2017-12-30 06:24:07 --> Output Class Initialized
INFO - 2017-12-30 06:24:07 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:07 --> Input Class Initialized
INFO - 2017-12-30 06:24:07 --> Language Class Initialized
INFO - 2017-12-30 06:24:07 --> Loader Class Initialized
INFO - 2017-12-30 06:24:07 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:07 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:07 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:07 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
INFO - 2017-12-30 06:24:07 --> Controller Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:07 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:07 --> Total execution time: 0.0518
INFO - 2017-12-30 06:24:07 --> Config Class Initialized
INFO - 2017-12-30 06:24:07 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:07 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:07 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:07 --> URI Class Initialized
INFO - 2017-12-30 06:24:07 --> Router Class Initialized
INFO - 2017-12-30 06:24:07 --> Output Class Initialized
INFO - 2017-12-30 06:24:07 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:07 --> Input Class Initialized
INFO - 2017-12-30 06:24:07 --> Language Class Initialized
INFO - 2017-12-30 06:24:07 --> Loader Class Initialized
INFO - 2017-12-30 06:24:07 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:07 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:07 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:07 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
INFO - 2017-12-30 06:24:07 --> Controller Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
INFO - 2017-12-30 06:24:07 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:08 --> Config Class Initialized
INFO - 2017-12-30 06:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:08 --> URI Class Initialized
INFO - 2017-12-30 06:24:08 --> Router Class Initialized
INFO - 2017-12-30 06:24:08 --> Output Class Initialized
INFO - 2017-12-30 06:24:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:08 --> Input Class Initialized
INFO - 2017-12-30 06:24:08 --> Language Class Initialized
INFO - 2017-12-30 06:24:08 --> Loader Class Initialized
INFO - 2017-12-30 06:24:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
INFO - 2017-12-30 06:24:08 --> Controller Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:08 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:08 --> Total execution time: 0.0505
INFO - 2017-12-30 06:24:08 --> Config Class Initialized
INFO - 2017-12-30 06:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:08 --> URI Class Initialized
INFO - 2017-12-30 06:24:08 --> Router Class Initialized
INFO - 2017-12-30 06:24:08 --> Output Class Initialized
INFO - 2017-12-30 06:24:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:08 --> Input Class Initialized
INFO - 2017-12-30 06:24:08 --> Language Class Initialized
INFO - 2017-12-30 06:24:08 --> Loader Class Initialized
INFO - 2017-12-30 06:24:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
INFO - 2017-12-30 06:24:08 --> Controller Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
INFO - 2017-12-30 06:24:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:09 --> Config Class Initialized
INFO - 2017-12-30 06:24:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:09 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:09 --> URI Class Initialized
INFO - 2017-12-30 06:24:09 --> Router Class Initialized
INFO - 2017-12-30 06:24:09 --> Output Class Initialized
INFO - 2017-12-30 06:24:09 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:09 --> Input Class Initialized
INFO - 2017-12-30 06:24:09 --> Language Class Initialized
INFO - 2017-12-30 06:24:09 --> Loader Class Initialized
INFO - 2017-12-30 06:24:09 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:09 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:09 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
INFO - 2017-12-30 06:24:09 --> Controller Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:09 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:09 --> Total execution time: 0.0514
INFO - 2017-12-30 06:24:09 --> Config Class Initialized
INFO - 2017-12-30 06:24:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:09 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:09 --> URI Class Initialized
INFO - 2017-12-30 06:24:09 --> Router Class Initialized
INFO - 2017-12-30 06:24:09 --> Output Class Initialized
INFO - 2017-12-30 06:24:09 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:09 --> Input Class Initialized
INFO - 2017-12-30 06:24:09 --> Language Class Initialized
INFO - 2017-12-30 06:24:09 --> Loader Class Initialized
INFO - 2017-12-30 06:24:09 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:09 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:09 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
INFO - 2017-12-30 06:24:09 --> Controller Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
INFO - 2017-12-30 06:24:09 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:10 --> Config Class Initialized
INFO - 2017-12-30 06:24:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:10 --> URI Class Initialized
INFO - 2017-12-30 06:24:10 --> Router Class Initialized
INFO - 2017-12-30 06:24:10 --> Output Class Initialized
INFO - 2017-12-30 06:24:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:10 --> Input Class Initialized
INFO - 2017-12-30 06:24:10 --> Language Class Initialized
INFO - 2017-12-30 06:24:10 --> Loader Class Initialized
INFO - 2017-12-30 06:24:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Controller Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:24:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:24:10 --> Final output sent to browser
DEBUG - 2017-12-30 06:24:10 --> Total execution time: 0.0483
INFO - 2017-12-30 06:24:10 --> Config Class Initialized
INFO - 2017-12-30 06:24:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:24:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:24:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:24:10 --> URI Class Initialized
INFO - 2017-12-30 06:24:10 --> Router Class Initialized
INFO - 2017-12-30 06:24:10 --> Output Class Initialized
INFO - 2017-12-30 06:24:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:24:10 --> Input Class Initialized
INFO - 2017-12-30 06:24:10 --> Language Class Initialized
INFO - 2017-12-30 06:24:10 --> Loader Class Initialized
INFO - 2017-12-30 06:24:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:24:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:24:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:24:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Controller Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
INFO - 2017-12-30 06:24:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:25:26 --> Config Class Initialized
INFO - 2017-12-30 06:25:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:25:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:25:26 --> Utf8 Class Initialized
INFO - 2017-12-30 06:25:26 --> URI Class Initialized
INFO - 2017-12-30 06:25:26 --> Router Class Initialized
INFO - 2017-12-30 06:25:26 --> Output Class Initialized
INFO - 2017-12-30 06:25:26 --> Security Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:25:26 --> Input Class Initialized
INFO - 2017-12-30 06:25:26 --> Language Class Initialized
INFO - 2017-12-30 06:25:26 --> Loader Class Initialized
INFO - 2017-12-30 06:25:26 --> Helper loaded: url_helper
INFO - 2017-12-30 06:25:26 --> Helper loaded: form_helper
INFO - 2017-12-30 06:25:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:25:26 --> Form Validation Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Controller Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:25:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:25:26 --> Final output sent to browser
DEBUG - 2017-12-30 06:25:26 --> Total execution time: 0.0533
INFO - 2017-12-30 06:25:26 --> Config Class Initialized
INFO - 2017-12-30 06:25:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:25:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:25:26 --> Utf8 Class Initialized
INFO - 2017-12-30 06:25:26 --> URI Class Initialized
INFO - 2017-12-30 06:25:26 --> Router Class Initialized
INFO - 2017-12-30 06:25:26 --> Output Class Initialized
INFO - 2017-12-30 06:25:26 --> Security Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:25:26 --> Input Class Initialized
INFO - 2017-12-30 06:25:26 --> Language Class Initialized
INFO - 2017-12-30 06:25:26 --> Loader Class Initialized
INFO - 2017-12-30 06:25:26 --> Helper loaded: url_helper
INFO - 2017-12-30 06:25:26 --> Helper loaded: form_helper
INFO - 2017-12-30 06:25:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:25:26 --> Form Validation Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Controller Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
INFO - 2017-12-30 06:25:26 --> Model Class Initialized
DEBUG - 2017-12-30 06:25:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:52 --> Config Class Initialized
INFO - 2017-12-30 06:26:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:52 --> URI Class Initialized
INFO - 2017-12-30 06:26:52 --> Router Class Initialized
INFO - 2017-12-30 06:26:52 --> Output Class Initialized
INFO - 2017-12-30 06:26:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:52 --> Input Class Initialized
INFO - 2017-12-30 06:26:52 --> Language Class Initialized
INFO - 2017-12-30 06:26:52 --> Loader Class Initialized
INFO - 2017-12-30 06:26:52 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:52 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:52 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Controller Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:26:52 --> Final output sent to browser
DEBUG - 2017-12-30 06:26:52 --> Total execution time: 0.0650
INFO - 2017-12-30 06:26:52 --> Config Class Initialized
INFO - 2017-12-30 06:26:52 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:52 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:52 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:52 --> URI Class Initialized
INFO - 2017-12-30 06:26:52 --> Router Class Initialized
INFO - 2017-12-30 06:26:52 --> Output Class Initialized
INFO - 2017-12-30 06:26:52 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:52 --> Input Class Initialized
INFO - 2017-12-30 06:26:52 --> Language Class Initialized
INFO - 2017-12-30 06:26:52 --> Loader Class Initialized
INFO - 2017-12-30 06:26:52 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:52 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:52 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:52 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Controller Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
INFO - 2017-12-30 06:26:52 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:54 --> Config Class Initialized
INFO - 2017-12-30 06:26:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:54 --> URI Class Initialized
INFO - 2017-12-30 06:26:54 --> Router Class Initialized
INFO - 2017-12-30 06:26:54 --> Output Class Initialized
INFO - 2017-12-30 06:26:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:54 --> Input Class Initialized
INFO - 2017-12-30 06:26:54 --> Language Class Initialized
INFO - 2017-12-30 06:26:54 --> Loader Class Initialized
INFO - 2017-12-30 06:26:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Controller Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:26:54 --> Final output sent to browser
DEBUG - 2017-12-30 06:26:54 --> Total execution time: 0.0585
INFO - 2017-12-30 06:26:54 --> Config Class Initialized
INFO - 2017-12-30 06:26:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:54 --> URI Class Initialized
INFO - 2017-12-30 06:26:54 --> Router Class Initialized
INFO - 2017-12-30 06:26:54 --> Output Class Initialized
INFO - 2017-12-30 06:26:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:54 --> Input Class Initialized
INFO - 2017-12-30 06:26:54 --> Language Class Initialized
INFO - 2017-12-30 06:26:54 --> Loader Class Initialized
INFO - 2017-12-30 06:26:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Controller Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
INFO - 2017-12-30 06:26:54 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:57 --> Config Class Initialized
INFO - 2017-12-30 06:26:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:57 --> URI Class Initialized
INFO - 2017-12-30 06:26:57 --> Router Class Initialized
INFO - 2017-12-30 06:26:57 --> Output Class Initialized
INFO - 2017-12-30 06:26:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:57 --> Input Class Initialized
INFO - 2017-12-30 06:26:57 --> Language Class Initialized
INFO - 2017-12-30 06:26:57 --> Loader Class Initialized
INFO - 2017-12-30 06:26:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Controller Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:26:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:26:57 --> Final output sent to browser
DEBUG - 2017-12-30 06:26:57 --> Total execution time: 0.0662
INFO - 2017-12-30 06:26:57 --> Config Class Initialized
INFO - 2017-12-30 06:26:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:26:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:26:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:26:57 --> URI Class Initialized
INFO - 2017-12-30 06:26:57 --> Router Class Initialized
INFO - 2017-12-30 06:26:57 --> Output Class Initialized
INFO - 2017-12-30 06:26:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:26:57 --> Input Class Initialized
INFO - 2017-12-30 06:26:57 --> Language Class Initialized
INFO - 2017-12-30 06:26:57 --> Loader Class Initialized
INFO - 2017-12-30 06:26:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:26:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:26:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:26:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Controller Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
INFO - 2017-12-30 06:26:57 --> Model Class Initialized
DEBUG - 2017-12-30 06:26:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:04 --> Config Class Initialized
INFO - 2017-12-30 06:27:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:04 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:04 --> URI Class Initialized
INFO - 2017-12-30 06:27:04 --> Router Class Initialized
INFO - 2017-12-30 06:27:04 --> Output Class Initialized
INFO - 2017-12-30 06:27:04 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:04 --> Input Class Initialized
INFO - 2017-12-30 06:27:04 --> Language Class Initialized
INFO - 2017-12-30 06:27:04 --> Loader Class Initialized
INFO - 2017-12-30 06:27:04 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:04 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:04 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Controller Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:27:04 --> Final output sent to browser
DEBUG - 2017-12-30 06:27:04 --> Total execution time: 0.0571
INFO - 2017-12-30 06:27:04 --> Config Class Initialized
INFO - 2017-12-30 06:27:04 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:04 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:04 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:04 --> URI Class Initialized
INFO - 2017-12-30 06:27:04 --> Router Class Initialized
INFO - 2017-12-30 06:27:04 --> Output Class Initialized
INFO - 2017-12-30 06:27:04 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:04 --> Input Class Initialized
INFO - 2017-12-30 06:27:04 --> Language Class Initialized
INFO - 2017-12-30 06:27:04 --> Loader Class Initialized
INFO - 2017-12-30 06:27:04 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:04 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:04 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:04 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Controller Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
INFO - 2017-12-30 06:27:04 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:11 --> Config Class Initialized
INFO - 2017-12-30 06:27:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:11 --> URI Class Initialized
INFO - 2017-12-30 06:27:11 --> Router Class Initialized
INFO - 2017-12-30 06:27:11 --> Output Class Initialized
INFO - 2017-12-30 06:27:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:11 --> Input Class Initialized
INFO - 2017-12-30 06:27:11 --> Language Class Initialized
INFO - 2017-12-30 06:27:11 --> Loader Class Initialized
INFO - 2017-12-30 06:27:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Controller Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:27:11 --> Final output sent to browser
DEBUG - 2017-12-30 06:27:11 --> Total execution time: 0.0635
INFO - 2017-12-30 06:27:11 --> Config Class Initialized
INFO - 2017-12-30 06:27:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:11 --> URI Class Initialized
INFO - 2017-12-30 06:27:11 --> Router Class Initialized
INFO - 2017-12-30 06:27:11 --> Output Class Initialized
INFO - 2017-12-30 06:27:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:11 --> Input Class Initialized
INFO - 2017-12-30 06:27:11 --> Language Class Initialized
INFO - 2017-12-30 06:27:11 --> Loader Class Initialized
INFO - 2017-12-30 06:27:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Controller Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
INFO - 2017-12-30 06:27:11 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:11 --> Config Class Initialized
INFO - 2017-12-30 06:27:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:11 --> URI Class Initialized
INFO - 2017-12-30 06:27:11 --> Router Class Initialized
INFO - 2017-12-30 06:27:11 --> Output Class Initialized
INFO - 2017-12-30 06:27:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:12 --> Input Class Initialized
INFO - 2017-12-30 06:27:12 --> Language Class Initialized
INFO - 2017-12-30 06:27:12 --> Loader Class Initialized
INFO - 2017-12-30 06:27:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Controller Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:27:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:27:12 --> Total execution time: 0.0667
INFO - 2017-12-30 06:27:12 --> Config Class Initialized
INFO - 2017-12-30 06:27:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:12 --> URI Class Initialized
INFO - 2017-12-30 06:27:12 --> Router Class Initialized
INFO - 2017-12-30 06:27:12 --> Output Class Initialized
INFO - 2017-12-30 06:27:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:12 --> Input Class Initialized
INFO - 2017-12-30 06:27:12 --> Language Class Initialized
INFO - 2017-12-30 06:27:12 --> Loader Class Initialized
INFO - 2017-12-30 06:27:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Controller Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
INFO - 2017-12-30 06:27:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:13 --> Config Class Initialized
INFO - 2017-12-30 06:27:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:13 --> URI Class Initialized
INFO - 2017-12-30 06:27:13 --> Router Class Initialized
INFO - 2017-12-30 06:27:13 --> Output Class Initialized
INFO - 2017-12-30 06:27:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:13 --> Input Class Initialized
INFO - 2017-12-30 06:27:13 --> Language Class Initialized
INFO - 2017-12-30 06:27:13 --> Loader Class Initialized
INFO - 2017-12-30 06:27:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:13 --> Model Class Initialized
INFO - 2017-12-30 06:27:14 --> Controller Class Initialized
INFO - 2017-12-30 06:27:14 --> Model Class Initialized
INFO - 2017-12-30 06:27:14 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:27:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:27:14 --> Final output sent to browser
DEBUG - 2017-12-30 06:27:14 --> Total execution time: 0.0444
INFO - 2017-12-30 06:27:14 --> Config Class Initialized
INFO - 2017-12-30 06:27:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:27:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:27:14 --> Utf8 Class Initialized
INFO - 2017-12-30 06:27:14 --> URI Class Initialized
INFO - 2017-12-30 06:27:14 --> Router Class Initialized
INFO - 2017-12-30 06:27:14 --> Output Class Initialized
INFO - 2017-12-30 06:27:14 --> Security Class Initialized
DEBUG - 2017-12-30 06:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:27:14 --> Input Class Initialized
INFO - 2017-12-30 06:27:14 --> Language Class Initialized
INFO - 2017-12-30 06:27:14 --> Loader Class Initialized
INFO - 2017-12-30 06:27:14 --> Helper loaded: url_helper
INFO - 2017-12-30 06:27:14 --> Helper loaded: form_helper
INFO - 2017-12-30 06:27:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:27:14 --> Form Validation Class Initialized
INFO - 2017-12-30 06:27:14 --> Model Class Initialized
INFO - 2017-12-30 06:27:14 --> Controller Class Initialized
INFO - 2017-12-30 06:27:14 --> Model Class Initialized
INFO - 2017-12-30 06:27:14 --> Model Class Initialized
DEBUG - 2017-12-30 06:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:01 --> Config Class Initialized
INFO - 2017-12-30 06:28:01 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:01 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:01 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:01 --> URI Class Initialized
INFO - 2017-12-30 06:28:01 --> Router Class Initialized
INFO - 2017-12-30 06:28:01 --> Output Class Initialized
INFO - 2017-12-30 06:28:01 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:01 --> Input Class Initialized
INFO - 2017-12-30 06:28:01 --> Language Class Initialized
INFO - 2017-12-30 06:28:01 --> Loader Class Initialized
INFO - 2017-12-30 06:28:01 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:01 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:01 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:01 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:01 --> Model Class Initialized
INFO - 2017-12-30 06:28:01 --> Controller Class Initialized
INFO - 2017-12-30 06:28:01 --> Model Class Initialized
INFO - 2017-12-30 06:28:01 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:01 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:01 --> Total execution time: 0.0546
INFO - 2017-12-30 06:28:02 --> Config Class Initialized
INFO - 2017-12-30 06:28:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:02 --> URI Class Initialized
INFO - 2017-12-30 06:28:02 --> Router Class Initialized
INFO - 2017-12-30 06:28:02 --> Output Class Initialized
INFO - 2017-12-30 06:28:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:02 --> Input Class Initialized
INFO - 2017-12-30 06:28:02 --> Language Class Initialized
INFO - 2017-12-30 06:28:02 --> Loader Class Initialized
INFO - 2017-12-30 06:28:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:02 --> Model Class Initialized
INFO - 2017-12-30 06:28:02 --> Controller Class Initialized
INFO - 2017-12-30 06:28:02 --> Model Class Initialized
INFO - 2017-12-30 06:28:02 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:06 --> Config Class Initialized
INFO - 2017-12-30 06:28:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:06 --> URI Class Initialized
INFO - 2017-12-30 06:28:06 --> Router Class Initialized
INFO - 2017-12-30 06:28:06 --> Output Class Initialized
INFO - 2017-12-30 06:28:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:06 --> Input Class Initialized
INFO - 2017-12-30 06:28:06 --> Language Class Initialized
INFO - 2017-12-30 06:28:06 --> Loader Class Initialized
INFO - 2017-12-30 06:28:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
INFO - 2017-12-30 06:28:06 --> Controller Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:06 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:06 --> Total execution time: 0.0537
INFO - 2017-12-30 06:28:06 --> Config Class Initialized
INFO - 2017-12-30 06:28:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:06 --> URI Class Initialized
INFO - 2017-12-30 06:28:06 --> Router Class Initialized
INFO - 2017-12-30 06:28:06 --> Output Class Initialized
INFO - 2017-12-30 06:28:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:06 --> Input Class Initialized
INFO - 2017-12-30 06:28:06 --> Language Class Initialized
INFO - 2017-12-30 06:28:06 --> Loader Class Initialized
INFO - 2017-12-30 06:28:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
INFO - 2017-12-30 06:28:06 --> Controller Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
INFO - 2017-12-30 06:28:06 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:08 --> Config Class Initialized
INFO - 2017-12-30 06:28:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:08 --> URI Class Initialized
INFO - 2017-12-30 06:28:08 --> Router Class Initialized
INFO - 2017-12-30 06:28:08 --> Output Class Initialized
INFO - 2017-12-30 06:28:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:08 --> Input Class Initialized
INFO - 2017-12-30 06:28:08 --> Language Class Initialized
INFO - 2017-12-30 06:28:08 --> Loader Class Initialized
INFO - 2017-12-30 06:28:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
INFO - 2017-12-30 06:28:08 --> Controller Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:08 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:08 --> Total execution time: 0.0528
INFO - 2017-12-30 06:28:08 --> Config Class Initialized
INFO - 2017-12-30 06:28:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:08 --> URI Class Initialized
INFO - 2017-12-30 06:28:08 --> Router Class Initialized
INFO - 2017-12-30 06:28:08 --> Output Class Initialized
INFO - 2017-12-30 06:28:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:08 --> Input Class Initialized
INFO - 2017-12-30 06:28:08 --> Language Class Initialized
INFO - 2017-12-30 06:28:08 --> Loader Class Initialized
INFO - 2017-12-30 06:28:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
INFO - 2017-12-30 06:28:08 --> Controller Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
INFO - 2017-12-30 06:28:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:10 --> Config Class Initialized
INFO - 2017-12-30 06:28:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:10 --> URI Class Initialized
INFO - 2017-12-30 06:28:10 --> Router Class Initialized
INFO - 2017-12-30 06:28:10 --> Output Class Initialized
INFO - 2017-12-30 06:28:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:10 --> Input Class Initialized
INFO - 2017-12-30 06:28:10 --> Language Class Initialized
INFO - 2017-12-30 06:28:10 --> Loader Class Initialized
INFO - 2017-12-30 06:28:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:10 --> Model Class Initialized
INFO - 2017-12-30 06:28:10 --> Controller Class Initialized
INFO - 2017-12-30 06:28:10 --> Model Class Initialized
INFO - 2017-12-30 06:28:10 --> Model Class Initialized
INFO - 2017-12-30 06:28:10 --> Model Class Initialized
INFO - 2017-12-30 06:28:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:10 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:10 --> Total execution time: 0.0602
INFO - 2017-12-30 06:28:12 --> Config Class Initialized
INFO - 2017-12-30 06:28:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:12 --> URI Class Initialized
INFO - 2017-12-30 06:28:12 --> Router Class Initialized
INFO - 2017-12-30 06:28:12 --> Output Class Initialized
INFO - 2017-12-30 06:28:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:12 --> Input Class Initialized
INFO - 2017-12-30 06:28:12 --> Language Class Initialized
INFO - 2017-12-30 06:28:12 --> Loader Class Initialized
INFO - 2017-12-30 06:28:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Controller Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:12 --> Total execution time: 0.0558
INFO - 2017-12-30 06:28:12 --> Config Class Initialized
INFO - 2017-12-30 06:28:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:12 --> URI Class Initialized
INFO - 2017-12-30 06:28:12 --> Router Class Initialized
INFO - 2017-12-30 06:28:12 --> Output Class Initialized
INFO - 2017-12-30 06:28:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:12 --> Input Class Initialized
INFO - 2017-12-30 06:28:12 --> Language Class Initialized
INFO - 2017-12-30 06:28:12 --> Loader Class Initialized
INFO - 2017-12-30 06:28:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Controller Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
INFO - 2017-12-30 06:28:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:15 --> Config Class Initialized
INFO - 2017-12-30 06:28:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:15 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:15 --> URI Class Initialized
INFO - 2017-12-30 06:28:15 --> Router Class Initialized
INFO - 2017-12-30 06:28:15 --> Output Class Initialized
INFO - 2017-12-30 06:28:15 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:15 --> Input Class Initialized
INFO - 2017-12-30 06:28:15 --> Language Class Initialized
INFO - 2017-12-30 06:28:15 --> Loader Class Initialized
INFO - 2017-12-30 06:28:15 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:15 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:15 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Controller Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:15 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:15 --> Total execution time: 0.0560
INFO - 2017-12-30 06:28:15 --> Config Class Initialized
INFO - 2017-12-30 06:28:15 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:15 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:15 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:15 --> URI Class Initialized
INFO - 2017-12-30 06:28:15 --> Router Class Initialized
INFO - 2017-12-30 06:28:15 --> Output Class Initialized
INFO - 2017-12-30 06:28:15 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:15 --> Input Class Initialized
INFO - 2017-12-30 06:28:15 --> Language Class Initialized
INFO - 2017-12-30 06:28:15 --> Loader Class Initialized
INFO - 2017-12-30 06:28:15 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:15 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:15 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:15 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Controller Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
INFO - 2017-12-30 06:28:15 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:25 --> Config Class Initialized
INFO - 2017-12-30 06:28:25 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:25 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:25 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:25 --> URI Class Initialized
INFO - 2017-12-30 06:28:25 --> Router Class Initialized
INFO - 2017-12-30 06:28:25 --> Output Class Initialized
INFO - 2017-12-30 06:28:25 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:25 --> Input Class Initialized
INFO - 2017-12-30 06:28:25 --> Language Class Initialized
INFO - 2017-12-30 06:28:25 --> Loader Class Initialized
INFO - 2017-12-30 06:28:25 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:25 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:25 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:25 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:25 --> Model Class Initialized
INFO - 2017-12-30 06:28:25 --> Controller Class Initialized
INFO - 2017-12-30 06:28:25 --> Model Class Initialized
INFO - 2017-12-30 06:28:25 --> Model Class Initialized
INFO - 2017-12-30 06:28:25 --> Model Class Initialized
INFO - 2017-12-30 06:28:25 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:28:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:28:25 --> Final output sent to browser
DEBUG - 2017-12-30 06:28:25 --> Total execution time: 0.0626
INFO - 2017-12-30 06:28:26 --> Config Class Initialized
INFO - 2017-12-30 06:28:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:28:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:28:26 --> Utf8 Class Initialized
INFO - 2017-12-30 06:28:26 --> URI Class Initialized
INFO - 2017-12-30 06:28:26 --> Router Class Initialized
INFO - 2017-12-30 06:28:26 --> Output Class Initialized
INFO - 2017-12-30 06:28:26 --> Security Class Initialized
DEBUG - 2017-12-30 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:28:26 --> Input Class Initialized
INFO - 2017-12-30 06:28:26 --> Language Class Initialized
INFO - 2017-12-30 06:28:26 --> Loader Class Initialized
INFO - 2017-12-30 06:28:26 --> Helper loaded: url_helper
INFO - 2017-12-30 06:28:26 --> Helper loaded: form_helper
INFO - 2017-12-30 06:28:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:28:26 --> Form Validation Class Initialized
INFO - 2017-12-30 06:28:26 --> Model Class Initialized
INFO - 2017-12-30 06:28:26 --> Controller Class Initialized
INFO - 2017-12-30 06:28:26 --> Model Class Initialized
INFO - 2017-12-30 06:28:26 --> Model Class Initialized
INFO - 2017-12-30 06:28:26 --> Model Class Initialized
INFO - 2017-12-30 06:28:26 --> Model Class Initialized
DEBUG - 2017-12-30 06:28:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:11 --> Config Class Initialized
INFO - 2017-12-30 06:29:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:11 --> URI Class Initialized
DEBUG - 2017-12-30 06:29:11 --> No URI present. Default controller set.
INFO - 2017-12-30 06:29:11 --> Router Class Initialized
INFO - 2017-12-30 06:29:11 --> Output Class Initialized
INFO - 2017-12-30 06:29:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:11 --> Input Class Initialized
INFO - 2017-12-30 06:29:11 --> Language Class Initialized
INFO - 2017-12-30 06:29:11 --> Loader Class Initialized
INFO - 2017-12-30 06:29:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:11 --> Model Class Initialized
INFO - 2017-12-30 06:29:11 --> Controller Class Initialized
INFO - 2017-12-30 06:29:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:29:11 --> Final output sent to browser
DEBUG - 2017-12-30 06:29:11 --> Total execution time: 0.0506
INFO - 2017-12-30 06:29:12 --> Config Class Initialized
INFO - 2017-12-30 06:29:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:12 --> URI Class Initialized
INFO - 2017-12-30 06:29:12 --> Router Class Initialized
INFO - 2017-12-30 06:29:12 --> Output Class Initialized
INFO - 2017-12-30 06:29:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:12 --> Input Class Initialized
INFO - 2017-12-30 06:29:12 --> Language Class Initialized
INFO - 2017-12-30 06:29:12 --> Loader Class Initialized
INFO - 2017-12-30 06:29:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:12 --> Model Class Initialized
INFO - 2017-12-30 06:29:12 --> Controller Class Initialized
INFO - 2017-12-30 06:29:12 --> Model Class Initialized
INFO - 2017-12-30 06:29:12 --> Model Class Initialized
INFO - 2017-12-30 06:29:12 --> Model Class Initialized
INFO - 2017-12-30 06:29:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:12 --> Config Class Initialized
INFO - 2017-12-30 06:29:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:12 --> URI Class Initialized
INFO - 2017-12-30 06:29:12 --> Router Class Initialized
INFO - 2017-12-30 06:29:12 --> Output Class Initialized
INFO - 2017-12-30 06:29:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:12 --> Input Class Initialized
INFO - 2017-12-30 06:29:12 --> Language Class Initialized
INFO - 2017-12-30 06:29:12 --> Loader Class Initialized
INFO - 2017-12-30 06:29:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Controller Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:29:13 --> Final output sent to browser
DEBUG - 2017-12-30 06:29:13 --> Total execution time: 0.0576
INFO - 2017-12-30 06:29:13 --> Config Class Initialized
INFO - 2017-12-30 06:29:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:13 --> URI Class Initialized
INFO - 2017-12-30 06:29:13 --> Router Class Initialized
INFO - 2017-12-30 06:29:13 --> Output Class Initialized
INFO - 2017-12-30 06:29:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:13 --> Input Class Initialized
INFO - 2017-12-30 06:29:13 --> Language Class Initialized
INFO - 2017-12-30 06:29:13 --> Loader Class Initialized
INFO - 2017-12-30 06:29:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Controller Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:13 --> Config Class Initialized
INFO - 2017-12-30 06:29:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:13 --> URI Class Initialized
INFO - 2017-12-30 06:29:13 --> Router Class Initialized
INFO - 2017-12-30 06:29:13 --> Output Class Initialized
INFO - 2017-12-30 06:29:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:13 --> Input Class Initialized
INFO - 2017-12-30 06:29:13 --> Language Class Initialized
INFO - 2017-12-30 06:29:13 --> Loader Class Initialized
INFO - 2017-12-30 06:29:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Controller Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:29:13 --> Final output sent to browser
DEBUG - 2017-12-30 06:29:13 --> Total execution time: 0.0548
INFO - 2017-12-30 06:29:13 --> Config Class Initialized
INFO - 2017-12-30 06:29:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:13 --> URI Class Initialized
INFO - 2017-12-30 06:29:13 --> Router Class Initialized
INFO - 2017-12-30 06:29:13 --> Output Class Initialized
INFO - 2017-12-30 06:29:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:13 --> Input Class Initialized
INFO - 2017-12-30 06:29:13 --> Language Class Initialized
INFO - 2017-12-30 06:29:13 --> Loader Class Initialized
INFO - 2017-12-30 06:29:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Controller Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
INFO - 2017-12-30 06:29:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:14 --> Config Class Initialized
INFO - 2017-12-30 06:29:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:14 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:14 --> URI Class Initialized
DEBUG - 2017-12-30 06:29:14 --> No URI present. Default controller set.
INFO - 2017-12-30 06:29:14 --> Router Class Initialized
INFO - 2017-12-30 06:29:14 --> Output Class Initialized
INFO - 2017-12-30 06:29:14 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:14 --> Input Class Initialized
INFO - 2017-12-30 06:29:14 --> Language Class Initialized
INFO - 2017-12-30 06:29:14 --> Loader Class Initialized
INFO - 2017-12-30 06:29:14 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:14 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:14 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
INFO - 2017-12-30 06:29:14 --> Controller Class Initialized
INFO - 2017-12-30 06:29:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:29:14 --> Final output sent to browser
DEBUG - 2017-12-30 06:29:14 --> Total execution time: 0.0411
INFO - 2017-12-30 06:29:14 --> Config Class Initialized
INFO - 2017-12-30 06:29:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:14 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:14 --> URI Class Initialized
INFO - 2017-12-30 06:29:14 --> Router Class Initialized
INFO - 2017-12-30 06:29:14 --> Output Class Initialized
INFO - 2017-12-30 06:29:14 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:14 --> Input Class Initialized
INFO - 2017-12-30 06:29:14 --> Language Class Initialized
INFO - 2017-12-30 06:29:14 --> Loader Class Initialized
INFO - 2017-12-30 06:29:14 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:14 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:14 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
INFO - 2017-12-30 06:29:14 --> Controller Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
INFO - 2017-12-30 06:29:14 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:29:30 --> Config Class Initialized
INFO - 2017-12-30 06:29:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:30 --> URI Class Initialized
DEBUG - 2017-12-30 06:29:30 --> No URI present. Default controller set.
INFO - 2017-12-30 06:29:30 --> Router Class Initialized
INFO - 2017-12-30 06:29:30 --> Output Class Initialized
INFO - 2017-12-30 06:29:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:30 --> Input Class Initialized
INFO - 2017-12-30 06:29:30 --> Language Class Initialized
INFO - 2017-12-30 06:29:30 --> Loader Class Initialized
INFO - 2017-12-30 06:29:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
INFO - 2017-12-30 06:29:30 --> Controller Class Initialized
INFO - 2017-12-30 06:29:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:29:30 --> Final output sent to browser
DEBUG - 2017-12-30 06:29:30 --> Total execution time: 0.0963
INFO - 2017-12-30 06:29:30 --> Config Class Initialized
INFO - 2017-12-30 06:29:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:29:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:29:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:29:30 --> URI Class Initialized
INFO - 2017-12-30 06:29:30 --> Router Class Initialized
INFO - 2017-12-30 06:29:30 --> Output Class Initialized
INFO - 2017-12-30 06:29:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:29:30 --> Input Class Initialized
INFO - 2017-12-30 06:29:30 --> Language Class Initialized
INFO - 2017-12-30 06:29:30 --> Loader Class Initialized
INFO - 2017-12-30 06:29:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:29:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:29:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:29:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
INFO - 2017-12-30 06:29:30 --> Controller Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
INFO - 2017-12-30 06:29:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:10 --> Config Class Initialized
INFO - 2017-12-30 06:34:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:10 --> URI Class Initialized
INFO - 2017-12-30 06:34:10 --> Router Class Initialized
INFO - 2017-12-30 06:34:10 --> Output Class Initialized
INFO - 2017-12-30 06:34:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:10 --> Input Class Initialized
INFO - 2017-12-30 06:34:10 --> Language Class Initialized
INFO - 2017-12-30 06:34:10 --> Loader Class Initialized
INFO - 2017-12-30 06:34:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:10 --> Model Class Initialized
INFO - 2017-12-30 06:34:10 --> Controller Class Initialized
INFO - 2017-12-30 06:34:10 --> Model Class Initialized
INFO - 2017-12-30 06:34:10 --> Model Class Initialized
INFO - 2017-12-30 06:34:10 --> Model Class Initialized
INFO - 2017-12-30 06:34:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:34:10 --> Final output sent to browser
DEBUG - 2017-12-30 06:34:10 --> Total execution time: 0.0590
INFO - 2017-12-30 06:34:11 --> Config Class Initialized
INFO - 2017-12-30 06:34:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:11 --> URI Class Initialized
INFO - 2017-12-30 06:34:11 --> Router Class Initialized
INFO - 2017-12-30 06:34:11 --> Output Class Initialized
INFO - 2017-12-30 06:34:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:11 --> Input Class Initialized
INFO - 2017-12-30 06:34:11 --> Language Class Initialized
INFO - 2017-12-30 06:34:11 --> Loader Class Initialized
INFO - 2017-12-30 06:34:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Controller Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:11 --> Config Class Initialized
INFO - 2017-12-30 06:34:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:11 --> URI Class Initialized
INFO - 2017-12-30 06:34:11 --> Router Class Initialized
INFO - 2017-12-30 06:34:11 --> Output Class Initialized
INFO - 2017-12-30 06:34:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:11 --> Input Class Initialized
INFO - 2017-12-30 06:34:11 --> Language Class Initialized
INFO - 2017-12-30 06:34:11 --> Loader Class Initialized
INFO - 2017-12-30 06:34:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Controller Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
INFO - 2017-12-30 06:34:11 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:34:11 --> Final output sent to browser
DEBUG - 2017-12-30 06:34:11 --> Total execution time: 0.0425
INFO - 2017-12-30 06:34:11 --> Config Class Initialized
INFO - 2017-12-30 06:34:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:11 --> URI Class Initialized
INFO - 2017-12-30 06:34:11 --> Router Class Initialized
INFO - 2017-12-30 06:34:11 --> Output Class Initialized
INFO - 2017-12-30 06:34:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:11 --> Input Class Initialized
INFO - 2017-12-30 06:34:11 --> Language Class Initialized
INFO - 2017-12-30 06:34:11 --> Loader Class Initialized
INFO - 2017-12-30 06:34:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Controller Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:12 --> Config Class Initialized
INFO - 2017-12-30 06:34:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:12 --> URI Class Initialized
INFO - 2017-12-30 06:34:12 --> Router Class Initialized
INFO - 2017-12-30 06:34:12 --> Output Class Initialized
INFO - 2017-12-30 06:34:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:12 --> Input Class Initialized
INFO - 2017-12-30 06:34:12 --> Language Class Initialized
INFO - 2017-12-30 06:34:12 --> Loader Class Initialized
INFO - 2017-12-30 06:34:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Controller Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:34:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:34:12 --> Total execution time: 0.0590
INFO - 2017-12-30 06:34:12 --> Config Class Initialized
INFO - 2017-12-30 06:34:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:12 --> URI Class Initialized
INFO - 2017-12-30 06:34:12 --> Router Class Initialized
INFO - 2017-12-30 06:34:12 --> Output Class Initialized
INFO - 2017-12-30 06:34:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:12 --> Input Class Initialized
INFO - 2017-12-30 06:34:12 --> Language Class Initialized
INFO - 2017-12-30 06:34:12 --> Loader Class Initialized
INFO - 2017-12-30 06:34:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Controller Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:34:12 --> Config Class Initialized
INFO - 2017-12-30 06:34:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:12 --> URI Class Initialized
DEBUG - 2017-12-30 06:34:12 --> No URI present. Default controller set.
INFO - 2017-12-30 06:34:12 --> Router Class Initialized
INFO - 2017-12-30 06:34:12 --> Output Class Initialized
INFO - 2017-12-30 06:34:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:12 --> Input Class Initialized
INFO - 2017-12-30 06:34:12 --> Language Class Initialized
INFO - 2017-12-30 06:34:12 --> Loader Class Initialized
INFO - 2017-12-30 06:34:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Controller Class Initialized
INFO - 2017-12-30 06:34:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:34:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:34:12 --> Total execution time: 0.0499
INFO - 2017-12-30 06:34:12 --> Config Class Initialized
INFO - 2017-12-30 06:34:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:34:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:34:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:34:12 --> URI Class Initialized
INFO - 2017-12-30 06:34:12 --> Router Class Initialized
INFO - 2017-12-30 06:34:12 --> Output Class Initialized
INFO - 2017-12-30 06:34:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:34:12 --> Input Class Initialized
INFO - 2017-12-30 06:34:12 --> Language Class Initialized
INFO - 2017-12-30 06:34:12 --> Loader Class Initialized
INFO - 2017-12-30 06:34:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:34:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:34:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:34:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Controller Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
INFO - 2017-12-30 06:34:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:35:12 --> Config Class Initialized
INFO - 2017-12-30 06:35:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:12 --> URI Class Initialized
DEBUG - 2017-12-30 06:35:12 --> No URI present. Default controller set.
INFO - 2017-12-30 06:35:12 --> Router Class Initialized
INFO - 2017-12-30 06:35:12 --> Output Class Initialized
INFO - 2017-12-30 06:35:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:12 --> Input Class Initialized
INFO - 2017-12-30 06:35:12 --> Language Class Initialized
INFO - 2017-12-30 06:35:12 --> Loader Class Initialized
INFO - 2017-12-30 06:35:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
INFO - 2017-12-30 06:35:12 --> Controller Class Initialized
INFO - 2017-12-30 06:35:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:35:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:35:12 --> Total execution time: 0.0498
INFO - 2017-12-30 06:35:12 --> Config Class Initialized
INFO - 2017-12-30 06:35:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:12 --> URI Class Initialized
INFO - 2017-12-30 06:35:12 --> Router Class Initialized
INFO - 2017-12-30 06:35:12 --> Output Class Initialized
INFO - 2017-12-30 06:35:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:12 --> Input Class Initialized
INFO - 2017-12-30 06:35:12 --> Language Class Initialized
INFO - 2017-12-30 06:35:12 --> Loader Class Initialized
INFO - 2017-12-30 06:35:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
INFO - 2017-12-30 06:35:12 --> Controller Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
INFO - 2017-12-30 06:35:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:35:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:35:29 --> Config Class Initialized
INFO - 2017-12-30 06:35:29 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:29 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:29 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:29 --> URI Class Initialized
DEBUG - 2017-12-30 06:35:29 --> No URI present. Default controller set.
INFO - 2017-12-30 06:35:29 --> Router Class Initialized
INFO - 2017-12-30 06:35:29 --> Output Class Initialized
INFO - 2017-12-30 06:35:29 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:29 --> Input Class Initialized
INFO - 2017-12-30 06:35:29 --> Language Class Initialized
INFO - 2017-12-30 06:35:29 --> Loader Class Initialized
INFO - 2017-12-30 06:35:29 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:29 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:29 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:29 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:29 --> Model Class Initialized
INFO - 2017-12-30 06:35:29 --> Controller Class Initialized
INFO - 2017-12-30 06:35:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:35:29 --> Final output sent to browser
DEBUG - 2017-12-30 06:35:29 --> Total execution time: 0.0644
INFO - 2017-12-30 06:35:30 --> Config Class Initialized
INFO - 2017-12-30 06:35:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:30 --> URI Class Initialized
INFO - 2017-12-30 06:35:30 --> Router Class Initialized
INFO - 2017-12-30 06:35:30 --> Output Class Initialized
INFO - 2017-12-30 06:35:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:30 --> Input Class Initialized
INFO - 2017-12-30 06:35:30 --> Language Class Initialized
INFO - 2017-12-30 06:35:30 --> Loader Class Initialized
INFO - 2017-12-30 06:35:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:30 --> Model Class Initialized
INFO - 2017-12-30 06:35:30 --> Controller Class Initialized
INFO - 2017-12-30 06:35:30 --> Model Class Initialized
INFO - 2017-12-30 06:35:30 --> Model Class Initialized
INFO - 2017-12-30 06:35:30 --> Model Class Initialized
INFO - 2017-12-30 06:35:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:35:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:35:38 --> Config Class Initialized
INFO - 2017-12-30 06:35:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:38 --> URI Class Initialized
DEBUG - 2017-12-30 06:35:38 --> No URI present. Default controller set.
INFO - 2017-12-30 06:35:38 --> Router Class Initialized
INFO - 2017-12-30 06:35:38 --> Output Class Initialized
INFO - 2017-12-30 06:35:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:38 --> Input Class Initialized
INFO - 2017-12-30 06:35:38 --> Language Class Initialized
INFO - 2017-12-30 06:35:38 --> Loader Class Initialized
INFO - 2017-12-30 06:35:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
INFO - 2017-12-30 06:35:38 --> Controller Class Initialized
INFO - 2017-12-30 06:35:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:35:38 --> Final output sent to browser
DEBUG - 2017-12-30 06:35:38 --> Total execution time: 0.0505
INFO - 2017-12-30 06:35:38 --> Config Class Initialized
INFO - 2017-12-30 06:35:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:35:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:35:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:35:38 --> URI Class Initialized
INFO - 2017-12-30 06:35:38 --> Router Class Initialized
INFO - 2017-12-30 06:35:38 --> Output Class Initialized
INFO - 2017-12-30 06:35:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:35:38 --> Input Class Initialized
INFO - 2017-12-30 06:35:38 --> Language Class Initialized
INFO - 2017-12-30 06:35:38 --> Loader Class Initialized
INFO - 2017-12-30 06:35:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:35:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:35:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:35:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
INFO - 2017-12-30 06:35:38 --> Controller Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
INFO - 2017-12-30 06:35:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:35:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:12 --> Config Class Initialized
INFO - 2017-12-30 06:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:12 --> URI Class Initialized
INFO - 2017-12-30 06:36:12 --> Router Class Initialized
INFO - 2017-12-30 06:36:12 --> Output Class Initialized
INFO - 2017-12-30 06:36:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:12 --> Input Class Initialized
INFO - 2017-12-30 06:36:12 --> Language Class Initialized
INFO - 2017-12-30 06:36:12 --> Loader Class Initialized
INFO - 2017-12-30 06:36:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
INFO - 2017-12-30 06:36:12 --> Controller Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:36:12 --> Final output sent to browser
DEBUG - 2017-12-30 06:36:12 --> Total execution time: 0.0461
INFO - 2017-12-30 06:36:12 --> Config Class Initialized
INFO - 2017-12-30 06:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:12 --> URI Class Initialized
INFO - 2017-12-30 06:36:12 --> Router Class Initialized
INFO - 2017-12-30 06:36:12 --> Output Class Initialized
INFO - 2017-12-30 06:36:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:12 --> Input Class Initialized
INFO - 2017-12-30 06:36:12 --> Language Class Initialized
INFO - 2017-12-30 06:36:12 --> Loader Class Initialized
INFO - 2017-12-30 06:36:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
INFO - 2017-12-30 06:36:12 --> Controller Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
INFO - 2017-12-30 06:36:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:13 --> Config Class Initialized
INFO - 2017-12-30 06:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:13 --> URI Class Initialized
INFO - 2017-12-30 06:36:13 --> Router Class Initialized
INFO - 2017-12-30 06:36:13 --> Output Class Initialized
INFO - 2017-12-30 06:36:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:13 --> Input Class Initialized
INFO - 2017-12-30 06:36:13 --> Language Class Initialized
INFO - 2017-12-30 06:36:13 --> Loader Class Initialized
INFO - 2017-12-30 06:36:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Controller Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:36:13 --> Final output sent to browser
DEBUG - 2017-12-30 06:36:13 --> Total execution time: 0.0519
INFO - 2017-12-30 06:36:13 --> Config Class Initialized
INFO - 2017-12-30 06:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:13 --> URI Class Initialized
INFO - 2017-12-30 06:36:13 --> Router Class Initialized
INFO - 2017-12-30 06:36:13 --> Output Class Initialized
INFO - 2017-12-30 06:36:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:13 --> Input Class Initialized
INFO - 2017-12-30 06:36:13 --> Language Class Initialized
INFO - 2017-12-30 06:36:13 --> Loader Class Initialized
INFO - 2017-12-30 06:36:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Controller Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:13 --> Config Class Initialized
INFO - 2017-12-30 06:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:13 --> URI Class Initialized
INFO - 2017-12-30 06:36:13 --> Router Class Initialized
INFO - 2017-12-30 06:36:13 --> Output Class Initialized
INFO - 2017-12-30 06:36:13 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:13 --> Input Class Initialized
INFO - 2017-12-30 06:36:13 --> Language Class Initialized
INFO - 2017-12-30 06:36:13 --> Loader Class Initialized
INFO - 2017-12-30 06:36:13 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:13 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:13 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:13 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Controller Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
INFO - 2017-12-30 06:36:13 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:36:13 --> Final output sent to browser
DEBUG - 2017-12-30 06:36:13 --> Total execution time: 0.0601
INFO - 2017-12-30 06:36:14 --> Config Class Initialized
INFO - 2017-12-30 06:36:14 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:14 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:14 --> URI Class Initialized
INFO - 2017-12-30 06:36:14 --> Router Class Initialized
INFO - 2017-12-30 06:36:14 --> Output Class Initialized
INFO - 2017-12-30 06:36:14 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:14 --> Input Class Initialized
INFO - 2017-12-30 06:36:14 --> Language Class Initialized
INFO - 2017-12-30 06:36:14 --> Loader Class Initialized
INFO - 2017-12-30 06:36:14 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:14 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:14 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:14 --> Model Class Initialized
INFO - 2017-12-30 06:36:14 --> Controller Class Initialized
INFO - 2017-12-30 06:36:14 --> Model Class Initialized
INFO - 2017-12-30 06:36:14 --> Model Class Initialized
INFO - 2017-12-30 06:36:14 --> Model Class Initialized
INFO - 2017-12-30 06:36:14 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:16 --> Config Class Initialized
INFO - 2017-12-30 06:36:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:16 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:16 --> URI Class Initialized
INFO - 2017-12-30 06:36:16 --> Router Class Initialized
INFO - 2017-12-30 06:36:16 --> Output Class Initialized
INFO - 2017-12-30 06:36:16 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:16 --> Input Class Initialized
INFO - 2017-12-30 06:36:16 --> Language Class Initialized
INFO - 2017-12-30 06:36:16 --> Loader Class Initialized
INFO - 2017-12-30 06:36:16 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:16 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:16 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Controller Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:36:16 --> Final output sent to browser
DEBUG - 2017-12-30 06:36:16 --> Total execution time: 0.0568
INFO - 2017-12-30 06:36:16 --> Config Class Initialized
INFO - 2017-12-30 06:36:16 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:16 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:16 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:16 --> URI Class Initialized
INFO - 2017-12-30 06:36:16 --> Router Class Initialized
INFO - 2017-12-30 06:36:16 --> Output Class Initialized
INFO - 2017-12-30 06:36:16 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:16 --> Input Class Initialized
INFO - 2017-12-30 06:36:16 --> Language Class Initialized
INFO - 2017-12-30 06:36:16 --> Loader Class Initialized
INFO - 2017-12-30 06:36:16 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:16 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:16 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:16 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Controller Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
INFO - 2017-12-30 06:36:16 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:23 --> Config Class Initialized
INFO - 2017-12-30 06:36:23 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:36:23 --> Utf8 Class Initialized
INFO - 2017-12-30 06:36:23 --> URI Class Initialized
INFO - 2017-12-30 06:36:23 --> Router Class Initialized
INFO - 2017-12-30 06:36:23 --> Output Class Initialized
INFO - 2017-12-30 06:36:23 --> Security Class Initialized
DEBUG - 2017-12-30 06:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:36:23 --> Input Class Initialized
INFO - 2017-12-30 06:36:23 --> Language Class Initialized
INFO - 2017-12-30 06:36:23 --> Loader Class Initialized
INFO - 2017-12-30 06:36:23 --> Helper loaded: url_helper
INFO - 2017-12-30 06:36:23 --> Helper loaded: form_helper
INFO - 2017-12-30 06:36:23 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:36:23 --> Form Validation Class Initialized
INFO - 2017-12-30 06:36:23 --> Model Class Initialized
INFO - 2017-12-30 06:36:23 --> Controller Class Initialized
INFO - 2017-12-30 06:36:23 --> Model Class Initialized
INFO - 2017-12-30 06:36:23 --> Model Class Initialized
INFO - 2017-12-30 06:36:23 --> Model Class Initialized
INFO - 2017-12-30 06:36:23 --> Model Class Initialized
DEBUG - 2017-12-30 06:36:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:36:24 --> Final output sent to browser
DEBUG - 2017-12-30 06:36:24 --> Total execution time: 0.1464
INFO - 2017-12-30 06:37:38 --> Config Class Initialized
INFO - 2017-12-30 06:37:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:37:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:37:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:37:38 --> URI Class Initialized
INFO - 2017-12-30 06:37:38 --> Router Class Initialized
INFO - 2017-12-30 06:37:38 --> Output Class Initialized
INFO - 2017-12-30 06:37:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:37:38 --> Input Class Initialized
INFO - 2017-12-30 06:37:38 --> Language Class Initialized
INFO - 2017-12-30 06:37:38 --> Loader Class Initialized
INFO - 2017-12-30 06:37:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:37:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:37:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:37:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Controller Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:37:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:37:38 --> Final output sent to browser
DEBUG - 2017-12-30 06:37:38 --> Total execution time: 0.0537
INFO - 2017-12-30 06:37:38 --> Config Class Initialized
INFO - 2017-12-30 06:37:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:37:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:37:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:37:38 --> URI Class Initialized
INFO - 2017-12-30 06:37:38 --> Router Class Initialized
INFO - 2017-12-30 06:37:38 --> Output Class Initialized
INFO - 2017-12-30 06:37:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:37:38 --> Input Class Initialized
INFO - 2017-12-30 06:37:38 --> Language Class Initialized
INFO - 2017-12-30 06:37:38 --> Loader Class Initialized
INFO - 2017-12-30 06:37:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:37:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:37:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:37:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Controller Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
INFO - 2017-12-30 06:37:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:37:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:06 --> Config Class Initialized
INFO - 2017-12-30 06:40:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:06 --> URI Class Initialized
INFO - 2017-12-30 06:40:06 --> Router Class Initialized
INFO - 2017-12-30 06:40:06 --> Output Class Initialized
INFO - 2017-12-30 06:40:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:06 --> Input Class Initialized
INFO - 2017-12-30 06:40:06 --> Language Class Initialized
INFO - 2017-12-30 06:40:06 --> Loader Class Initialized
INFO - 2017-12-30 06:40:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Controller Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:40:06 --> Final output sent to browser
DEBUG - 2017-12-30 06:40:06 --> Total execution time: 0.0620
INFO - 2017-12-30 06:40:06 --> Config Class Initialized
INFO - 2017-12-30 06:40:06 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:06 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:06 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:06 --> URI Class Initialized
INFO - 2017-12-30 06:40:06 --> Router Class Initialized
INFO - 2017-12-30 06:40:06 --> Output Class Initialized
INFO - 2017-12-30 06:40:06 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:06 --> Input Class Initialized
INFO - 2017-12-30 06:40:06 --> Language Class Initialized
INFO - 2017-12-30 06:40:06 --> Loader Class Initialized
INFO - 2017-12-30 06:40:06 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:06 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:06 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:06 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Controller Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
INFO - 2017-12-30 06:40:06 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:26 --> Config Class Initialized
INFO - 2017-12-30 06:40:26 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:26 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:26 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:26 --> URI Class Initialized
INFO - 2017-12-30 06:40:26 --> Router Class Initialized
INFO - 2017-12-30 06:40:26 --> Output Class Initialized
INFO - 2017-12-30 06:40:26 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:26 --> Input Class Initialized
INFO - 2017-12-30 06:40:26 --> Language Class Initialized
INFO - 2017-12-30 06:40:26 --> Loader Class Initialized
INFO - 2017-12-30 06:40:26 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:26 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:26 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:26 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:26 --> Model Class Initialized
INFO - 2017-12-30 06:40:26 --> Controller Class Initialized
INFO - 2017-12-30 06:40:26 --> Model Class Initialized
INFO - 2017-12-30 06:40:26 --> Model Class Initialized
INFO - 2017-12-30 06:40:26 --> Model Class Initialized
INFO - 2017-12-30 06:40:26 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:40:26 --> Final output sent to browser
DEBUG - 2017-12-30 06:40:26 --> Total execution time: 0.0593
INFO - 2017-12-30 06:40:27 --> Config Class Initialized
INFO - 2017-12-30 06:40:27 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:27 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:27 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:27 --> URI Class Initialized
INFO - 2017-12-30 06:40:27 --> Router Class Initialized
INFO - 2017-12-30 06:40:27 --> Output Class Initialized
INFO - 2017-12-30 06:40:27 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:27 --> Input Class Initialized
INFO - 2017-12-30 06:40:27 --> Language Class Initialized
INFO - 2017-12-30 06:40:27 --> Loader Class Initialized
INFO - 2017-12-30 06:40:27 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:27 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:27 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:27 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:27 --> Model Class Initialized
INFO - 2017-12-30 06:40:27 --> Controller Class Initialized
INFO - 2017-12-30 06:40:27 --> Model Class Initialized
INFO - 2017-12-30 06:40:27 --> Model Class Initialized
INFO - 2017-12-30 06:40:27 --> Model Class Initialized
INFO - 2017-12-30 06:40:27 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:38 --> Config Class Initialized
INFO - 2017-12-30 06:40:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:38 --> URI Class Initialized
INFO - 2017-12-30 06:40:38 --> Router Class Initialized
INFO - 2017-12-30 06:40:38 --> Output Class Initialized
INFO - 2017-12-30 06:40:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:38 --> Input Class Initialized
INFO - 2017-12-30 06:40:38 --> Language Class Initialized
INFO - 2017-12-30 06:40:38 --> Loader Class Initialized
INFO - 2017-12-30 06:40:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Controller Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:40:38 --> Final output sent to browser
DEBUG - 2017-12-30 06:40:38 --> Total execution time: 0.0493
INFO - 2017-12-30 06:40:38 --> Config Class Initialized
INFO - 2017-12-30 06:40:38 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:38 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:38 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:38 --> URI Class Initialized
INFO - 2017-12-30 06:40:38 --> Router Class Initialized
INFO - 2017-12-30 06:40:38 --> Output Class Initialized
INFO - 2017-12-30 06:40:38 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:38 --> Input Class Initialized
INFO - 2017-12-30 06:40:38 --> Language Class Initialized
INFO - 2017-12-30 06:40:38 --> Loader Class Initialized
INFO - 2017-12-30 06:40:38 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:38 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:38 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:38 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Controller Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
INFO - 2017-12-30 06:40:38 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:49 --> Config Class Initialized
INFO - 2017-12-30 06:40:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:49 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:49 --> URI Class Initialized
INFO - 2017-12-30 06:40:49 --> Router Class Initialized
INFO - 2017-12-30 06:40:49 --> Output Class Initialized
INFO - 2017-12-30 06:40:49 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:49 --> Input Class Initialized
INFO - 2017-12-30 06:40:49 --> Language Class Initialized
INFO - 2017-12-30 06:40:49 --> Loader Class Initialized
INFO - 2017-12-30 06:40:49 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:49 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:49 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Controller Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:40:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:40:49 --> Final output sent to browser
DEBUG - 2017-12-30 06:40:49 --> Total execution time: 0.0664
INFO - 2017-12-30 06:40:49 --> Config Class Initialized
INFO - 2017-12-30 06:40:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:40:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:40:49 --> Utf8 Class Initialized
INFO - 2017-12-30 06:40:49 --> URI Class Initialized
INFO - 2017-12-30 06:40:49 --> Router Class Initialized
INFO - 2017-12-30 06:40:49 --> Output Class Initialized
INFO - 2017-12-30 06:40:49 --> Security Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:40:49 --> Input Class Initialized
INFO - 2017-12-30 06:40:49 --> Language Class Initialized
INFO - 2017-12-30 06:40:49 --> Loader Class Initialized
INFO - 2017-12-30 06:40:49 --> Helper loaded: url_helper
INFO - 2017-12-30 06:40:49 --> Helper loaded: form_helper
INFO - 2017-12-30 06:40:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:40:49 --> Form Validation Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Controller Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
INFO - 2017-12-30 06:40:49 --> Model Class Initialized
DEBUG - 2017-12-30 06:40:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:41:18 --> Config Class Initialized
INFO - 2017-12-30 06:41:18 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:41:18 --> Utf8 Class Initialized
INFO - 2017-12-30 06:41:18 --> URI Class Initialized
INFO - 2017-12-30 06:41:18 --> Router Class Initialized
INFO - 2017-12-30 06:41:18 --> Output Class Initialized
INFO - 2017-12-30 06:41:18 --> Security Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:41:18 --> Input Class Initialized
INFO - 2017-12-30 06:41:18 --> Language Class Initialized
INFO - 2017-12-30 06:41:18 --> Loader Class Initialized
INFO - 2017-12-30 06:41:18 --> Helper loaded: url_helper
INFO - 2017-12-30 06:41:18 --> Helper loaded: form_helper
INFO - 2017-12-30 06:41:18 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:41:18 --> Form Validation Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Controller Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:41:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:41:18 --> Final output sent to browser
DEBUG - 2017-12-30 06:41:18 --> Total execution time: 0.0497
INFO - 2017-12-30 06:41:18 --> Config Class Initialized
INFO - 2017-12-30 06:41:18 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:41:18 --> Utf8 Class Initialized
INFO - 2017-12-30 06:41:18 --> URI Class Initialized
INFO - 2017-12-30 06:41:18 --> Router Class Initialized
INFO - 2017-12-30 06:41:18 --> Output Class Initialized
INFO - 2017-12-30 06:41:18 --> Security Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:41:18 --> Input Class Initialized
INFO - 2017-12-30 06:41:18 --> Language Class Initialized
INFO - 2017-12-30 06:41:18 --> Loader Class Initialized
INFO - 2017-12-30 06:41:18 --> Helper loaded: url_helper
INFO - 2017-12-30 06:41:18 --> Helper loaded: form_helper
INFO - 2017-12-30 06:41:18 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:41:18 --> Form Validation Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Controller Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
INFO - 2017-12-30 06:41:18 --> Model Class Initialized
DEBUG - 2017-12-30 06:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:08 --> Config Class Initialized
INFO - 2017-12-30 06:42:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:08 --> URI Class Initialized
INFO - 2017-12-30 06:42:08 --> Router Class Initialized
INFO - 2017-12-30 06:42:08 --> Output Class Initialized
INFO - 2017-12-30 06:42:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:08 --> Input Class Initialized
INFO - 2017-12-30 06:42:08 --> Language Class Initialized
INFO - 2017-12-30 06:42:08 --> Loader Class Initialized
INFO - 2017-12-30 06:42:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Controller Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:42:08 --> Final output sent to browser
DEBUG - 2017-12-30 06:42:08 --> Total execution time: 0.0545
INFO - 2017-12-30 06:42:08 --> Config Class Initialized
INFO - 2017-12-30 06:42:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:08 --> URI Class Initialized
INFO - 2017-12-30 06:42:08 --> Router Class Initialized
INFO - 2017-12-30 06:42:08 --> Output Class Initialized
INFO - 2017-12-30 06:42:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:08 --> Input Class Initialized
INFO - 2017-12-30 06:42:08 --> Language Class Initialized
INFO - 2017-12-30 06:42:08 --> Loader Class Initialized
INFO - 2017-12-30 06:42:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Controller Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
INFO - 2017-12-30 06:42:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:09 --> Config Class Initialized
INFO - 2017-12-30 06:42:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:09 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:09 --> URI Class Initialized
INFO - 2017-12-30 06:42:09 --> Router Class Initialized
INFO - 2017-12-30 06:42:09 --> Output Class Initialized
INFO - 2017-12-30 06:42:09 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:09 --> Input Class Initialized
INFO - 2017-12-30 06:42:09 --> Language Class Initialized
INFO - 2017-12-30 06:42:09 --> Loader Class Initialized
INFO - 2017-12-30 06:42:09 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:09 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:09 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Controller Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:42:09 --> Final output sent to browser
DEBUG - 2017-12-30 06:42:09 --> Total execution time: 0.0633
INFO - 2017-12-30 06:42:09 --> Config Class Initialized
INFO - 2017-12-30 06:42:09 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:09 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:09 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:09 --> URI Class Initialized
INFO - 2017-12-30 06:42:09 --> Router Class Initialized
INFO - 2017-12-30 06:42:09 --> Output Class Initialized
INFO - 2017-12-30 06:42:09 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:09 --> Input Class Initialized
INFO - 2017-12-30 06:42:09 --> Language Class Initialized
INFO - 2017-12-30 06:42:09 --> Loader Class Initialized
INFO - 2017-12-30 06:42:09 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:09 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:09 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:09 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Controller Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
INFO - 2017-12-30 06:42:09 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:39 --> Config Class Initialized
INFO - 2017-12-30 06:42:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:39 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:39 --> URI Class Initialized
INFO - 2017-12-30 06:42:39 --> Router Class Initialized
INFO - 2017-12-30 06:42:39 --> Output Class Initialized
INFO - 2017-12-30 06:42:39 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:39 --> Input Class Initialized
INFO - 2017-12-30 06:42:39 --> Language Class Initialized
INFO - 2017-12-30 06:42:39 --> Loader Class Initialized
INFO - 2017-12-30 06:42:39 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:39 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:39 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:39 --> Model Class Initialized
INFO - 2017-12-30 06:42:39 --> Controller Class Initialized
INFO - 2017-12-30 06:42:39 --> Model Class Initialized
INFO - 2017-12-30 06:42:39 --> Model Class Initialized
INFO - 2017-12-30 06:42:39 --> Model Class Initialized
INFO - 2017-12-30 06:42:39 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:42:39 --> Final output sent to browser
DEBUG - 2017-12-30 06:42:39 --> Total execution time: 0.0567
INFO - 2017-12-30 06:42:39 --> Config Class Initialized
INFO - 2017-12-30 06:42:39 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:39 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:39 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:39 --> URI Class Initialized
INFO - 2017-12-30 06:42:39 --> Router Class Initialized
INFO - 2017-12-30 06:42:39 --> Output Class Initialized
INFO - 2017-12-30 06:42:39 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:39 --> Input Class Initialized
INFO - 2017-12-30 06:42:39 --> Language Class Initialized
INFO - 2017-12-30 06:42:39 --> Loader Class Initialized
INFO - 2017-12-30 06:42:39 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:39 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:39 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:40 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Controller Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:40 --> Config Class Initialized
INFO - 2017-12-30 06:42:40 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:40 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:40 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:40 --> URI Class Initialized
INFO - 2017-12-30 06:42:40 --> Router Class Initialized
INFO - 2017-12-30 06:42:40 --> Output Class Initialized
INFO - 2017-12-30 06:42:40 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:40 --> Input Class Initialized
INFO - 2017-12-30 06:42:40 --> Language Class Initialized
INFO - 2017-12-30 06:42:40 --> Loader Class Initialized
INFO - 2017-12-30 06:42:40 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:40 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:40 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:40 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Controller Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
INFO - 2017-12-30 06:42:40 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:42:40 --> Final output sent to browser
DEBUG - 2017-12-30 06:42:41 --> Total execution time: 0.0665
INFO - 2017-12-30 06:42:41 --> Config Class Initialized
INFO - 2017-12-30 06:42:41 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:41 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:41 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:41 --> URI Class Initialized
INFO - 2017-12-30 06:42:41 --> Router Class Initialized
INFO - 2017-12-30 06:42:41 --> Output Class Initialized
INFO - 2017-12-30 06:42:41 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:41 --> Input Class Initialized
INFO - 2017-12-30 06:42:41 --> Language Class Initialized
INFO - 2017-12-30 06:42:41 --> Loader Class Initialized
INFO - 2017-12-30 06:42:41 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:41 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:41 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:41 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:41 --> Model Class Initialized
INFO - 2017-12-30 06:42:41 --> Controller Class Initialized
INFO - 2017-12-30 06:42:41 --> Model Class Initialized
INFO - 2017-12-30 06:42:41 --> Model Class Initialized
INFO - 2017-12-30 06:42:41 --> Model Class Initialized
INFO - 2017-12-30 06:42:41 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:45 --> Config Class Initialized
INFO - 2017-12-30 06:42:45 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:45 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:45 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:45 --> URI Class Initialized
INFO - 2017-12-30 06:42:45 --> Router Class Initialized
INFO - 2017-12-30 06:42:45 --> Output Class Initialized
INFO - 2017-12-30 06:42:45 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:45 --> Input Class Initialized
INFO - 2017-12-30 06:42:45 --> Language Class Initialized
INFO - 2017-12-30 06:42:45 --> Loader Class Initialized
INFO - 2017-12-30 06:42:45 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:45 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:45 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Controller Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:42:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:42:45 --> Final output sent to browser
DEBUG - 2017-12-30 06:42:45 --> Total execution time: 0.0643
INFO - 2017-12-30 06:42:45 --> Config Class Initialized
INFO - 2017-12-30 06:42:45 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:42:45 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:42:45 --> Utf8 Class Initialized
INFO - 2017-12-30 06:42:45 --> URI Class Initialized
INFO - 2017-12-30 06:42:45 --> Router Class Initialized
INFO - 2017-12-30 06:42:45 --> Output Class Initialized
INFO - 2017-12-30 06:42:45 --> Security Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:42:45 --> Input Class Initialized
INFO - 2017-12-30 06:42:45 --> Language Class Initialized
INFO - 2017-12-30 06:42:45 --> Loader Class Initialized
INFO - 2017-12-30 06:42:45 --> Helper loaded: url_helper
INFO - 2017-12-30 06:42:45 --> Helper loaded: form_helper
INFO - 2017-12-30 06:42:45 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:42:45 --> Form Validation Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Controller Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
INFO - 2017-12-30 06:42:45 --> Model Class Initialized
DEBUG - 2017-12-30 06:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:08 --> Config Class Initialized
INFO - 2017-12-30 06:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:08 --> URI Class Initialized
INFO - 2017-12-30 06:43:08 --> Router Class Initialized
INFO - 2017-12-30 06:43:08 --> Output Class Initialized
INFO - 2017-12-30 06:43:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:08 --> Input Class Initialized
INFO - 2017-12-30 06:43:08 --> Language Class Initialized
INFO - 2017-12-30 06:43:08 --> Loader Class Initialized
INFO - 2017-12-30 06:43:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
INFO - 2017-12-30 06:43:08 --> Controller Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:08 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:08 --> Total execution time: 0.0516
INFO - 2017-12-30 06:43:08 --> Config Class Initialized
INFO - 2017-12-30 06:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:08 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:08 --> URI Class Initialized
INFO - 2017-12-30 06:43:08 --> Router Class Initialized
INFO - 2017-12-30 06:43:08 --> Output Class Initialized
INFO - 2017-12-30 06:43:08 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:08 --> Input Class Initialized
INFO - 2017-12-30 06:43:08 --> Language Class Initialized
INFO - 2017-12-30 06:43:08 --> Loader Class Initialized
INFO - 2017-12-30 06:43:08 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:08 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:08 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
INFO - 2017-12-30 06:43:08 --> Controller Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
INFO - 2017-12-30 06:43:08 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:10 --> Config Class Initialized
INFO - 2017-12-30 06:43:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:10 --> URI Class Initialized
INFO - 2017-12-30 06:43:10 --> Router Class Initialized
INFO - 2017-12-30 06:43:10 --> Output Class Initialized
INFO - 2017-12-30 06:43:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:10 --> Input Class Initialized
INFO - 2017-12-30 06:43:10 --> Language Class Initialized
INFO - 2017-12-30 06:43:10 --> Loader Class Initialized
INFO - 2017-12-30 06:43:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Controller Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:10 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:10 --> Total execution time: 0.0497
INFO - 2017-12-30 06:43:10 --> Config Class Initialized
INFO - 2017-12-30 06:43:10 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:10 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:10 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:10 --> URI Class Initialized
INFO - 2017-12-30 06:43:10 --> Router Class Initialized
INFO - 2017-12-30 06:43:10 --> Output Class Initialized
INFO - 2017-12-30 06:43:10 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:10 --> Input Class Initialized
INFO - 2017-12-30 06:43:10 --> Language Class Initialized
INFO - 2017-12-30 06:43:10 --> Loader Class Initialized
INFO - 2017-12-30 06:43:10 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:10 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:10 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:10 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Controller Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
INFO - 2017-12-30 06:43:10 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:11 --> Config Class Initialized
INFO - 2017-12-30 06:43:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:11 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:11 --> URI Class Initialized
INFO - 2017-12-30 06:43:11 --> Router Class Initialized
INFO - 2017-12-30 06:43:11 --> Output Class Initialized
INFO - 2017-12-30 06:43:11 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:11 --> Input Class Initialized
INFO - 2017-12-30 06:43:11 --> Language Class Initialized
INFO - 2017-12-30 06:43:11 --> Loader Class Initialized
INFO - 2017-12-30 06:43:11 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:11 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:11 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:11 --> Model Class Initialized
INFO - 2017-12-30 06:43:11 --> Controller Class Initialized
INFO - 2017-12-30 06:43:11 --> Model Class Initialized
INFO - 2017-12-30 06:43:11 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:11 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:11 --> Total execution time: 0.0548
INFO - 2017-12-30 06:43:12 --> Config Class Initialized
INFO - 2017-12-30 06:43:12 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:12 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:12 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:12 --> URI Class Initialized
INFO - 2017-12-30 06:43:12 --> Router Class Initialized
INFO - 2017-12-30 06:43:12 --> Output Class Initialized
INFO - 2017-12-30 06:43:12 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:12 --> Input Class Initialized
INFO - 2017-12-30 06:43:12 --> Language Class Initialized
INFO - 2017-12-30 06:43:12 --> Loader Class Initialized
INFO - 2017-12-30 06:43:12 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:12 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:12 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:12 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:12 --> Model Class Initialized
INFO - 2017-12-30 06:43:12 --> Controller Class Initialized
INFO - 2017-12-30 06:43:12 --> Model Class Initialized
INFO - 2017-12-30 06:43:12 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:30 --> Config Class Initialized
INFO - 2017-12-30 06:43:30 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:30 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:30 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:30 --> URI Class Initialized
INFO - 2017-12-30 06:43:30 --> Router Class Initialized
INFO - 2017-12-30 06:43:30 --> Output Class Initialized
INFO - 2017-12-30 06:43:30 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:30 --> Input Class Initialized
INFO - 2017-12-30 06:43:30 --> Language Class Initialized
INFO - 2017-12-30 06:43:30 --> Loader Class Initialized
INFO - 2017-12-30 06:43:30 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:30 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:30 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:30 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:30 --> Model Class Initialized
INFO - 2017-12-30 06:43:30 --> Controller Class Initialized
INFO - 2017-12-30 06:43:30 --> Model Class Initialized
INFO - 2017-12-30 06:43:30 --> Model Class Initialized
INFO - 2017-12-30 06:43:30 --> Model Class Initialized
INFO - 2017-12-30 06:43:30 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:30 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:30 --> Total execution time: 0.0531
INFO - 2017-12-30 06:43:31 --> Config Class Initialized
INFO - 2017-12-30 06:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:31 --> URI Class Initialized
INFO - 2017-12-30 06:43:31 --> Router Class Initialized
INFO - 2017-12-30 06:43:31 --> Output Class Initialized
INFO - 2017-12-30 06:43:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:31 --> Input Class Initialized
INFO - 2017-12-30 06:43:31 --> Language Class Initialized
INFO - 2017-12-30 06:43:31 --> Loader Class Initialized
INFO - 2017-12-30 06:43:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:31 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Controller Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:31 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:31 --> Total execution time: 0.0525
INFO - 2017-12-30 06:43:31 --> Config Class Initialized
INFO - 2017-12-30 06:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:31 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:31 --> URI Class Initialized
INFO - 2017-12-30 06:43:31 --> Router Class Initialized
INFO - 2017-12-30 06:43:31 --> Output Class Initialized
INFO - 2017-12-30 06:43:31 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:31 --> Input Class Initialized
INFO - 2017-12-30 06:43:31 --> Language Class Initialized
INFO - 2017-12-30 06:43:31 --> Loader Class Initialized
INFO - 2017-12-30 06:43:31 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:31 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:31 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Controller Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
INFO - 2017-12-30 06:43:31 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:49 --> Config Class Initialized
INFO - 2017-12-30 06:43:49 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:49 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:49 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:49 --> URI Class Initialized
INFO - 2017-12-30 06:43:49 --> Router Class Initialized
INFO - 2017-12-30 06:43:49 --> Output Class Initialized
INFO - 2017-12-30 06:43:49 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:49 --> Input Class Initialized
INFO - 2017-12-30 06:43:49 --> Language Class Initialized
INFO - 2017-12-30 06:43:49 --> Loader Class Initialized
INFO - 2017-12-30 06:43:49 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:49 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:49 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:49 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:49 --> Model Class Initialized
INFO - 2017-12-30 06:43:49 --> Controller Class Initialized
INFO - 2017-12-30 06:43:49 --> Model Class Initialized
INFO - 2017-12-30 06:43:49 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:49 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:49 --> Total execution time: 0.0530
INFO - 2017-12-30 06:43:50 --> Config Class Initialized
INFO - 2017-12-30 06:43:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:50 --> URI Class Initialized
INFO - 2017-12-30 06:43:50 --> Router Class Initialized
INFO - 2017-12-30 06:43:50 --> Output Class Initialized
INFO - 2017-12-30 06:43:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:50 --> Input Class Initialized
INFO - 2017-12-30 06:43:50 --> Language Class Initialized
INFO - 2017-12-30 06:43:50 --> Loader Class Initialized
INFO - 2017-12-30 06:43:50 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:50 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:50 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:50 --> Model Class Initialized
INFO - 2017-12-30 06:43:50 --> Controller Class Initialized
INFO - 2017-12-30 06:43:50 --> Model Class Initialized
INFO - 2017-12-30 06:43:50 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:54 --> Config Class Initialized
INFO - 2017-12-30 06:43:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:54 --> URI Class Initialized
INFO - 2017-12-30 06:43:54 --> Router Class Initialized
INFO - 2017-12-30 06:43:54 --> Output Class Initialized
INFO - 2017-12-30 06:43:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:54 --> Input Class Initialized
INFO - 2017-12-30 06:43:54 --> Language Class Initialized
INFO - 2017-12-30 06:43:54 --> Loader Class Initialized
INFO - 2017-12-30 06:43:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Controller Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:54 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:54 --> Total execution time: 0.0560
INFO - 2017-12-30 06:43:54 --> Config Class Initialized
INFO - 2017-12-30 06:43:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:54 --> URI Class Initialized
INFO - 2017-12-30 06:43:54 --> Router Class Initialized
INFO - 2017-12-30 06:43:54 --> Output Class Initialized
INFO - 2017-12-30 06:43:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:54 --> Input Class Initialized
INFO - 2017-12-30 06:43:54 --> Language Class Initialized
INFO - 2017-12-30 06:43:54 --> Loader Class Initialized
INFO - 2017-12-30 06:43:54 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:54 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:54 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:54 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Controller Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
INFO - 2017-12-30 06:43:54 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:57 --> Config Class Initialized
INFO - 2017-12-30 06:43:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:57 --> URI Class Initialized
INFO - 2017-12-30 06:43:57 --> Router Class Initialized
INFO - 2017-12-30 06:43:57 --> Output Class Initialized
INFO - 2017-12-30 06:43:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:57 --> Input Class Initialized
INFO - 2017-12-30 06:43:57 --> Language Class Initialized
INFO - 2017-12-30 06:43:57 --> Loader Class Initialized
INFO - 2017-12-30 06:43:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Controller Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:43:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:43:57 --> Final output sent to browser
DEBUG - 2017-12-30 06:43:57 --> Total execution time: 0.0610
INFO - 2017-12-30 06:43:57 --> Config Class Initialized
INFO - 2017-12-30 06:43:57 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:43:57 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:43:57 --> Utf8 Class Initialized
INFO - 2017-12-30 06:43:57 --> URI Class Initialized
INFO - 2017-12-30 06:43:57 --> Router Class Initialized
INFO - 2017-12-30 06:43:57 --> Output Class Initialized
INFO - 2017-12-30 06:43:57 --> Security Class Initialized
DEBUG - 2017-12-30 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:43:57 --> Input Class Initialized
INFO - 2017-12-30 06:43:57 --> Language Class Initialized
INFO - 2017-12-30 06:43:57 --> Loader Class Initialized
INFO - 2017-12-30 06:43:57 --> Helper loaded: url_helper
INFO - 2017-12-30 06:43:57 --> Helper loaded: form_helper
INFO - 2017-12-30 06:43:57 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:43:57 --> Form Validation Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Controller Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:57 --> Model Class Initialized
INFO - 2017-12-30 06:43:58 --> Model Class Initialized
INFO - 2017-12-30 06:43:58 --> Model Class Initialized
DEBUG - 2017-12-30 06:43:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:44:50 --> Config Class Initialized
INFO - 2017-12-30 06:44:50 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:44:50 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:44:50 --> Utf8 Class Initialized
INFO - 2017-12-30 06:44:50 --> URI Class Initialized
INFO - 2017-12-30 06:44:50 --> Router Class Initialized
INFO - 2017-12-30 06:44:50 --> Output Class Initialized
INFO - 2017-12-30 06:44:50 --> Security Class Initialized
DEBUG - 2017-12-30 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:44:50 --> Input Class Initialized
INFO - 2017-12-30 06:44:50 --> Language Class Initialized
INFO - 2017-12-30 06:44:50 --> Loader Class Initialized
INFO - 2017-12-30 06:44:50 --> Helper loaded: url_helper
INFO - 2017-12-30 06:44:50 --> Helper loaded: form_helper
INFO - 2017-12-30 06:44:50 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:44:50 --> Form Validation Class Initialized
INFO - 2017-12-30 06:44:50 --> Model Class Initialized
INFO - 2017-12-30 06:44:50 --> Controller Class Initialized
INFO - 2017-12-30 06:44:50 --> Model Class Initialized
INFO - 2017-12-30 06:44:50 --> Model Class Initialized
INFO - 2017-12-30 06:44:50 --> Model Class Initialized
INFO - 2017-12-30 06:44:50 --> Model Class Initialized
DEBUG - 2017-12-30 06:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:44:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:44:50 --> Final output sent to browser
DEBUG - 2017-12-30 06:44:50 --> Total execution time: 0.0626
INFO - 2017-12-30 06:44:54 --> Config Class Initialized
INFO - 2017-12-30 06:44:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:44:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:44:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:44:54 --> URI Class Initialized
INFO - 2017-12-30 06:44:54 --> Router Class Initialized
INFO - 2017-12-30 06:44:54 --> Output Class Initialized
INFO - 2017-12-30 06:44:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:44:54 --> Input Class Initialized
INFO - 2017-12-30 06:44:54 --> Language Class Initialized
ERROR - 2017-12-30 06:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:44:54 --> Config Class Initialized
INFO - 2017-12-30 06:44:54 --> Hooks Class Initialized
INFO - 2017-12-30 06:44:54 --> Config Class Initialized
INFO - 2017-12-30 06:44:54 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:44:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:44:54 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:44:54 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:44:54 --> Utf8 Class Initialized
INFO - 2017-12-30 06:44:54 --> URI Class Initialized
INFO - 2017-12-30 06:44:54 --> URI Class Initialized
INFO - 2017-12-30 06:44:54 --> Router Class Initialized
INFO - 2017-12-30 06:44:54 --> Router Class Initialized
INFO - 2017-12-30 06:44:54 --> Output Class Initialized
INFO - 2017-12-30 06:44:54 --> Output Class Initialized
INFO - 2017-12-30 06:44:54 --> Security Class Initialized
INFO - 2017-12-30 06:44:54 --> Security Class Initialized
DEBUG - 2017-12-30 06:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:44:54 --> Input Class Initialized
INFO - 2017-12-30 06:44:54 --> Input Class Initialized
INFO - 2017-12-30 06:44:54 --> Language Class Initialized
INFO - 2017-12-30 06:44:54 --> Language Class Initialized
ERROR - 2017-12-30 06:44:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-30 06:44:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:44:59 --> Config Class Initialized
INFO - 2017-12-30 06:44:59 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:44:59 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:44:59 --> Utf8 Class Initialized
INFO - 2017-12-30 06:44:59 --> URI Class Initialized
INFO - 2017-12-30 06:44:59 --> Router Class Initialized
INFO - 2017-12-30 06:44:59 --> Output Class Initialized
INFO - 2017-12-30 06:44:59 --> Security Class Initialized
DEBUG - 2017-12-30 06:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:44:59 --> Input Class Initialized
INFO - 2017-12-30 06:44:59 --> Language Class Initialized
INFO - 2017-12-30 06:44:59 --> Loader Class Initialized
INFO - 2017-12-30 06:44:59 --> Helper loaded: url_helper
INFO - 2017-12-30 06:44:59 --> Helper loaded: form_helper
INFO - 2017-12-30 06:44:59 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:44:59 --> Form Validation Class Initialized
INFO - 2017-12-30 06:44:59 --> Model Class Initialized
INFO - 2017-12-30 06:44:59 --> Controller Class Initialized
INFO - 2017-12-30 06:44:59 --> Model Class Initialized
INFO - 2017-12-30 06:44:59 --> Model Class Initialized
INFO - 2017-12-30 06:44:59 --> Model Class Initialized
INFO - 2017-12-30 06:44:59 --> Model Class Initialized
DEBUG - 2017-12-30 06:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:45:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:45:00 --> Final output sent to browser
DEBUG - 2017-12-30 06:45:00 --> Total execution time: 0.0694
INFO - 2017-12-30 06:45:00 --> Config Class Initialized
INFO - 2017-12-30 06:45:00 --> Hooks Class Initialized
INFO - 2017-12-30 06:45:00 --> Config Class Initialized
INFO - 2017-12-30 06:45:00 --> Hooks Class Initialized
INFO - 2017-12-30 06:45:00 --> Config Class Initialized
DEBUG - 2017-12-30 06:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:00 --> Hooks Class Initialized
INFO - 2017-12-30 06:45:00 --> Utf8 Class Initialized
DEBUG - 2017-12-30 06:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:00 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:00 --> URI Class Initialized
INFO - 2017-12-30 06:45:00 --> URI Class Initialized
DEBUG - 2017-12-30 06:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:00 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:00 --> Router Class Initialized
INFO - 2017-12-30 06:45:00 --> Router Class Initialized
INFO - 2017-12-30 06:45:00 --> URI Class Initialized
INFO - 2017-12-30 06:45:00 --> Output Class Initialized
INFO - 2017-12-30 06:45:00 --> Router Class Initialized
INFO - 2017-12-30 06:45:00 --> Output Class Initialized
INFO - 2017-12-30 06:45:00 --> Security Class Initialized
INFO - 2017-12-30 06:45:00 --> Security Class Initialized
INFO - 2017-12-30 06:45:00 --> Output Class Initialized
DEBUG - 2017-12-30 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:00 --> Input Class Initialized
DEBUG - 2017-12-30 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:00 --> Input Class Initialized
INFO - 2017-12-30 06:45:00 --> Language Class Initialized
INFO - 2017-12-30 06:45:00 --> Security Class Initialized
INFO - 2017-12-30 06:45:00 --> Language Class Initialized
ERROR - 2017-12-30 06:45:00 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-30 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:00 --> Input Class Initialized
ERROR - 2017-12-30 06:45:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:45:00 --> Language Class Initialized
ERROR - 2017-12-30 06:45:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:45:02 --> Config Class Initialized
INFO - 2017-12-30 06:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:02 --> URI Class Initialized
INFO - 2017-12-30 06:45:02 --> Router Class Initialized
INFO - 2017-12-30 06:45:02 --> Output Class Initialized
INFO - 2017-12-30 06:45:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:02 --> Input Class Initialized
INFO - 2017-12-30 06:45:02 --> Language Class Initialized
INFO - 2017-12-30 06:45:02 --> Loader Class Initialized
INFO - 2017-12-30 06:45:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:45:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:45:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:45:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Controller Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:45:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 06:45:02 --> Final output sent to browser
DEBUG - 2017-12-30 06:45:02 --> Total execution time: 0.0603
INFO - 2017-12-30 06:45:02 --> Config Class Initialized
INFO - 2017-12-30 06:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:02 --> URI Class Initialized
INFO - 2017-12-30 06:45:02 --> Router Class Initialized
INFO - 2017-12-30 06:45:02 --> Output Class Initialized
INFO - 2017-12-30 06:45:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:02 --> Input Class Initialized
INFO - 2017-12-30 06:45:02 --> Language Class Initialized
ERROR - 2017-12-30 06:45:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-30 06:45:02 --> Config Class Initialized
INFO - 2017-12-30 06:45:02 --> Hooks Class Initialized
INFO - 2017-12-30 06:45:02 --> Config Class Initialized
INFO - 2017-12-30 06:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 06:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:02 --> URI Class Initialized
INFO - 2017-12-30 06:45:02 --> URI Class Initialized
INFO - 2017-12-30 06:45:02 --> Router Class Initialized
INFO - 2017-12-30 06:45:02 --> Router Class Initialized
INFO - 2017-12-30 06:45:02 --> Output Class Initialized
INFO - 2017-12-30 06:45:02 --> Output Class Initialized
INFO - 2017-12-30 06:45:02 --> Security Class Initialized
INFO - 2017-12-30 06:45:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:02 --> Input Class Initialized
INFO - 2017-12-30 06:45:02 --> Language Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:02 --> Input Class Initialized
ERROR - 2017-12-30 06:45:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:45:02 --> Language Class Initialized
ERROR - 2017-12-30 06:45:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-30 06:45:02 --> Config Class Initialized
INFO - 2017-12-30 06:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:02 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:02 --> URI Class Initialized
INFO - 2017-12-30 06:45:02 --> Router Class Initialized
INFO - 2017-12-30 06:45:02 --> Output Class Initialized
INFO - 2017-12-30 06:45:02 --> Security Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:02 --> Input Class Initialized
INFO - 2017-12-30 06:45:02 --> Language Class Initialized
INFO - 2017-12-30 06:45:02 --> Loader Class Initialized
INFO - 2017-12-30 06:45:02 --> Helper loaded: url_helper
INFO - 2017-12-30 06:45:02 --> Helper loaded: form_helper
INFO - 2017-12-30 06:45:02 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:45:02 --> Form Validation Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Controller Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
INFO - 2017-12-30 06:45:02 --> Model Class Initialized
DEBUG - 2017-12-30 06:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:45:13 --> Config Class Initialized
INFO - 2017-12-30 06:45:13 --> Hooks Class Initialized
DEBUG - 2017-12-30 06:45:13 --> UTF-8 Support Enabled
INFO - 2017-12-30 06:45:13 --> Utf8 Class Initialized
INFO - 2017-12-30 06:45:13 --> URI Class Initialized
INFO - 2017-12-30 06:45:13 --> Router Class Initialized
INFO - 2017-12-30 06:45:13 --> Output Class Initialized
INFO - 2017-12-30 06:45:14 --> Security Class Initialized
DEBUG - 2017-12-30 06:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 06:45:14 --> Input Class Initialized
INFO - 2017-12-30 06:45:14 --> Language Class Initialized
INFO - 2017-12-30 06:45:14 --> Loader Class Initialized
INFO - 2017-12-30 06:45:14 --> Helper loaded: url_helper
INFO - 2017-12-30 06:45:14 --> Helper loaded: form_helper
INFO - 2017-12-30 06:45:14 --> Database Driver Class Initialized
DEBUG - 2017-12-30 06:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 06:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 06:45:14 --> Form Validation Class Initialized
INFO - 2017-12-30 06:45:14 --> Model Class Initialized
INFO - 2017-12-30 06:45:14 --> Controller Class Initialized
INFO - 2017-12-30 06:45:14 --> Model Class Initialized
INFO - 2017-12-30 06:45:14 --> Model Class Initialized
INFO - 2017-12-30 06:45:14 --> Model Class Initialized
INFO - 2017-12-30 06:45:14 --> Model Class Initialized
DEBUG - 2017-12-30 06:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-30 06:45:14 --> Final output sent to browser
DEBUG - 2017-12-30 06:45:14 --> Total execution time: 0.1478
