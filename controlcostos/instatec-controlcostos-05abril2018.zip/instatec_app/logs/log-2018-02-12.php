<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> Loader Class Initialized
INFO - 2018-02-12 00:13:36 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:36 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:36 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Controller Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> Loader Class Initialized
INFO - 2018-02-12 00:13:36 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:36 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:36 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
INFO - 2018-02-12 00:13:36 --> Controller Class Initialized
INFO - 2018-02-12 00:13:36 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:36 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:36 --> Total execution time: 0.0384
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:36 --> Config Class Initialized
INFO - 2018-02-12 00:13:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> URI Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
INFO - 2018-02-12 00:13:36 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
INFO - 2018-02-12 00:13:36 --> Output Class Initialized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:36 --> Input Class Initialized
INFO - 2018-02-12 00:13:36 --> Language Class Initialized
ERROR - 2018-02-12 00:13:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:37 --> Config Class Initialized
INFO - 2018-02-12 00:13:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:37 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:37 --> URI Class Initialized
INFO - 2018-02-12 00:13:37 --> Router Class Initialized
INFO - 2018-02-12 00:13:37 --> Output Class Initialized
INFO - 2018-02-12 00:13:37 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:37 --> Input Class Initialized
INFO - 2018-02-12 00:13:37 --> Language Class Initialized
INFO - 2018-02-12 00:13:37 --> Loader Class Initialized
INFO - 2018-02-12 00:13:37 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:37 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:37 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:37 --> Model Class Initialized
INFO - 2018-02-12 00:13:37 --> Controller Class Initialized
INFO - 2018-02-12 00:13:37 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:38 --> No URI present. Default controller set.
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
INFO - 2018-02-12 00:13:38 --> Loader Class Initialized
INFO - 2018-02-12 00:13:38 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:38 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:38 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Controller Class Initialized
INFO - 2018-02-12 00:13:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:38 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:38 --> Total execution time: 0.0402
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:13:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:38 --> Config Class Initialized
INFO - 2018-02-12 00:13:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:38 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:38 --> URI Class Initialized
INFO - 2018-02-12 00:13:38 --> Router Class Initialized
INFO - 2018-02-12 00:13:38 --> Output Class Initialized
INFO - 2018-02-12 00:13:38 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:38 --> Input Class Initialized
INFO - 2018-02-12 00:13:38 --> Language Class Initialized
INFO - 2018-02-12 00:13:38 --> Loader Class Initialized
INFO - 2018-02-12 00:13:38 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:38 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:38 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Controller Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
INFO - 2018-02-12 00:13:38 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
INFO - 2018-02-12 00:13:40 --> Loader Class Initialized
INFO - 2018-02-12 00:13:40 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:40 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:40 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Controller Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:40 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:40 --> Total execution time: 0.0615
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
ERROR - 2018-02-12 00:13:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:40 --> Config Class Initialized
INFO - 2018-02-12 00:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:40 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:40 --> URI Class Initialized
INFO - 2018-02-12 00:13:40 --> Router Class Initialized
INFO - 2018-02-12 00:13:40 --> Output Class Initialized
INFO - 2018-02-12 00:13:40 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:40 --> Input Class Initialized
INFO - 2018-02-12 00:13:40 --> Language Class Initialized
INFO - 2018-02-12 00:13:40 --> Loader Class Initialized
INFO - 2018-02-12 00:13:40 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:40 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:40 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Controller Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
INFO - 2018-02-12 00:13:40 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Loader Class Initialized
INFO - 2018-02-12 00:13:43 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:43 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:43 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Controller Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:43 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:43 --> Total execution time: 0.0530
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:13:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:43 --> Config Class Initialized
INFO - 2018-02-12 00:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:43 --> URI Class Initialized
INFO - 2018-02-12 00:13:43 --> Router Class Initialized
INFO - 2018-02-12 00:13:43 --> Output Class Initialized
INFO - 2018-02-12 00:13:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:43 --> Input Class Initialized
INFO - 2018-02-12 00:13:43 --> Language Class Initialized
INFO - 2018-02-12 00:13:43 --> Loader Class Initialized
INFO - 2018-02-12 00:13:43 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:43 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:43 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Controller Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
INFO - 2018-02-12 00:13:43 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
INFO - 2018-02-12 00:13:47 --> Loader Class Initialized
INFO - 2018-02-12 00:13:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Controller Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:47 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:47 --> Total execution time: 0.0555
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
ERROR - 2018-02-12 00:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:47 --> Config Class Initialized
INFO - 2018-02-12 00:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:47 --> URI Class Initialized
INFO - 2018-02-12 00:13:47 --> Router Class Initialized
INFO - 2018-02-12 00:13:47 --> Output Class Initialized
INFO - 2018-02-12 00:13:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:47 --> Input Class Initialized
INFO - 2018-02-12 00:13:47 --> Language Class Initialized
INFO - 2018-02-12 00:13:47 --> Loader Class Initialized
INFO - 2018-02-12 00:13:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Controller Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
INFO - 2018-02-12 00:13:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
INFO - 2018-02-12 00:13:48 --> Loader Class Initialized
INFO - 2018-02-12 00:13:48 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:48 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:48 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Controller Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:13:48 --> Final output sent to browser
DEBUG - 2018-02-12 00:13:48 --> Total execution time: 0.0550
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
ERROR - 2018-02-12 00:13:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
INFO - 2018-02-12 00:13:48 --> Config Class Initialized
INFO - 2018-02-12 00:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:13:48 --> Utf8 Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> URI Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Router Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Output Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
INFO - 2018-02-12 00:13:48 --> Security Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Input Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
INFO - 2018-02-12 00:13:48 --> Language Class Initialized
INFO - 2018-02-12 00:13:48 --> Loader Class Initialized
INFO - 2018-02-12 00:13:48 --> Loader Class Initialized
INFO - 2018-02-12 00:13:48 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:48 --> Helper loaded: url_helper
INFO - 2018-02-12 00:13:48 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:48 --> Helper loaded: form_helper
INFO - 2018-02-12 00:13:48 --> Database Driver Class Initialized
INFO - 2018-02-12 00:13:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:13:48 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Controller Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:13:48 --> Form Validation Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Controller Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
INFO - 2018-02-12 00:13:48 --> Model Class Initialized
DEBUG - 2018-02-12 00:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Loader Class Initialized
INFO - 2018-02-12 00:14:15 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:15 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:14:15 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Controller Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:14:15 --> Final output sent to browser
DEBUG - 2018-02-12 00:14:15 --> Total execution time: 0.0704
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:14:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:15 --> Config Class Initialized
INFO - 2018-02-12 00:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> URI Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Router Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Output Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
INFO - 2018-02-12 00:14:15 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:15 --> Input Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Language Class Initialized
INFO - 2018-02-12 00:14:15 --> Loader Class Initialized
INFO - 2018-02-12 00:14:15 --> Loader Class Initialized
INFO - 2018-02-12 00:14:15 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:15 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:15 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:15 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:15 --> Database Driver Class Initialized
INFO - 2018-02-12 00:14:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:14:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:14:15 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Controller Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:14:15 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Controller Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
INFO - 2018-02-12 00:14:15 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
INFO - 2018-02-12 00:14:31 --> Loader Class Initialized
INFO - 2018-02-12 00:14:31 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:31 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:14:31 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Controller Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:14:31 --> Final output sent to browser
DEBUG - 2018-02-12 00:14:31 --> Total execution time: 0.0553
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:14:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:14:31 --> Config Class Initialized
INFO - 2018-02-12 00:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:14:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> URI Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Router Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Output Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
INFO - 2018-02-12 00:14:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:14:31 --> Input Class Initialized
INFO - 2018-02-12 00:14:31 --> Language Class Initialized
INFO - 2018-02-12 00:14:31 --> Loader Class Initialized
INFO - 2018-02-12 00:14:31 --> Loader Class Initialized
INFO - 2018-02-12 00:14:31 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:31 --> Helper loaded: url_helper
INFO - 2018-02-12 00:14:31 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:31 --> Helper loaded: form_helper
INFO - 2018-02-12 00:14:31 --> Database Driver Class Initialized
INFO - 2018-02-12 00:14:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 00:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:14:31 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Controller Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:14:31 --> Form Validation Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Controller Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
INFO - 2018-02-12 00:14:31 --> Model Class Initialized
DEBUG - 2018-02-12 00:14:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:15:18 --> Config Class Initialized
INFO - 2018-02-12 00:15:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:15:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:18 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:18 --> URI Class Initialized
INFO - 2018-02-12 00:15:18 --> Router Class Initialized
INFO - 2018-02-12 00:15:18 --> Output Class Initialized
INFO - 2018-02-12 00:15:18 --> Security Class Initialized
DEBUG - 2018-02-12 00:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:18 --> Input Class Initialized
INFO - 2018-02-12 00:15:18 --> Language Class Initialized
INFO - 2018-02-12 00:15:18 --> Loader Class Initialized
INFO - 2018-02-12 00:15:18 --> Helper loaded: url_helper
INFO - 2018-02-12 00:15:18 --> Helper loaded: form_helper
INFO - 2018-02-12 00:15:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:15:18 --> Form Validation Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
INFO - 2018-02-12 00:15:18 --> Controller Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
INFO - 2018-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2018-02-12 00:15:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:15:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:15:18 --> Final output sent to browser
DEBUG - 2018-02-12 00:15:18 --> Total execution time: 0.0835
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:15:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
INFO - 2018-02-12 00:15:19 --> Config Class Initialized
INFO - 2018-02-12 00:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:15:19 --> Utf8 Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> URI Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Router Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Output Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
INFO - 2018-02-12 00:15:19 --> Security Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:15:19 --> Input Class Initialized
INFO - 2018-02-12 00:15:19 --> Language Class Initialized
INFO - 2018-02-12 00:15:19 --> Loader Class Initialized
INFO - 2018-02-12 00:15:19 --> Helper loaded: url_helper
INFO - 2018-02-12 00:15:19 --> Loader Class Initialized
INFO - 2018-02-12 00:15:19 --> Helper loaded: form_helper
INFO - 2018-02-12 00:15:19 --> Helper loaded: url_helper
INFO - 2018-02-12 00:15:19 --> Helper loaded: form_helper
INFO - 2018-02-12 00:15:19 --> Database Driver Class Initialized
INFO - 2018-02-12 00:15:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:15:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:15:19 --> Form Validation Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Controller Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:15:19 --> Form Validation Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Controller Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
INFO - 2018-02-12 00:15:19 --> Model Class Initialized
DEBUG - 2018-02-12 00:15:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
INFO - 2018-02-12 00:17:01 --> Loader Class Initialized
INFO - 2018-02-12 00:17:01 --> Helper loaded: url_helper
INFO - 2018-02-12 00:17:01 --> Helper loaded: form_helper
INFO - 2018-02-12 00:17:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:17:01 --> Form Validation Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
INFO - 2018-02-12 00:17:01 --> Controller Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
INFO - 2018-02-12 00:17:01 --> Model Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:17:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:17:01 --> Final output sent to browser
DEBUG - 2018-02-12 00:17:01 --> Total execution time: 0.0728
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:01 --> Config Class Initialized
INFO - 2018-02-12 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
DEBUG - 2018-02-12 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> URI Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Router Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
INFO - 2018-02-12 00:17:01 --> Output Class Initialized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Security Class Initialized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
DEBUG - 2018-02-12 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:01 --> Input Class Initialized
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:17:01 --> Language Class Initialized
ERROR - 2018-02-12 00:17:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Loader Class Initialized
INFO - 2018-02-12 00:17:24 --> Helper loaded: url_helper
INFO - 2018-02-12 00:17:24 --> Helper loaded: form_helper
INFO - 2018-02-12 00:17:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:17:24 --> Form Validation Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Controller Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:17:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:17:24 --> Final output sent to browser
DEBUG - 2018-02-12 00:17:24 --> Total execution time: 0.0643
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:17:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
INFO - 2018-02-12 00:17:24 --> Config Class Initialized
INFO - 2018-02-12 00:17:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:17:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:17:24 --> Utf8 Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> URI Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Router Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Output Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
INFO - 2018-02-12 00:17:24 --> Security Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:17:24 --> Input Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Language Class Initialized
INFO - 2018-02-12 00:17:24 --> Loader Class Initialized
INFO - 2018-02-12 00:17:24 --> Loader Class Initialized
INFO - 2018-02-12 00:17:24 --> Helper loaded: url_helper
INFO - 2018-02-12 00:17:24 --> Helper loaded: url_helper
INFO - 2018-02-12 00:17:24 --> Helper loaded: form_helper
INFO - 2018-02-12 00:17:24 --> Helper loaded: form_helper
INFO - 2018-02-12 00:17:24 --> Database Driver Class Initialized
INFO - 2018-02-12 00:17:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 00:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:17:24 --> Form Validation Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Controller Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:17:24 --> Form Validation Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Controller Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
INFO - 2018-02-12 00:17:24 --> Model Class Initialized
DEBUG - 2018-02-12 00:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:42 --> Config Class Initialized
INFO - 2018-02-12 00:18:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:42 --> URI Class Initialized
INFO - 2018-02-12 00:18:42 --> Router Class Initialized
INFO - 2018-02-12 00:18:42 --> Output Class Initialized
INFO - 2018-02-12 00:18:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:42 --> Input Class Initialized
INFO - 2018-02-12 00:18:42 --> Language Class Initialized
INFO - 2018-02-12 00:18:42 --> Loader Class Initialized
INFO - 2018-02-12 00:18:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Controller Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:18:42 --> Final output sent to browser
DEBUG - 2018-02-12 00:18:42 --> Total execution time: 0.0693
INFO - 2018-02-12 00:18:42 --> Config Class Initialized
INFO - 2018-02-12 00:18:42 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:42 --> Config Class Initialized
INFO - 2018-02-12 00:18:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:18:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:42 --> URI Class Initialized
INFO - 2018-02-12 00:18:42 --> URI Class Initialized
INFO - 2018-02-12 00:18:42 --> Router Class Initialized
INFO - 2018-02-12 00:18:42 --> Router Class Initialized
INFO - 2018-02-12 00:18:42 --> Output Class Initialized
INFO - 2018-02-12 00:18:42 --> Security Class Initialized
INFO - 2018-02-12 00:18:42 --> Output Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:42 --> Input Class Initialized
INFO - 2018-02-12 00:18:42 --> Security Class Initialized
INFO - 2018-02-12 00:18:42 --> Language Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:42 --> Input Class Initialized
INFO - 2018-02-12 00:18:42 --> Language Class Initialized
INFO - 2018-02-12 00:18:42 --> Loader Class Initialized
INFO - 2018-02-12 00:18:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:42 --> Loader Class Initialized
INFO - 2018-02-12 00:18:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:42 --> Database Driver Class Initialized
INFO - 2018-02-12 00:18:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Controller Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Controller Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
INFO - 2018-02-12 00:18:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:44 --> Config Class Initialized
INFO - 2018-02-12 00:18:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:44 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:44 --> URI Class Initialized
INFO - 2018-02-12 00:18:44 --> Router Class Initialized
INFO - 2018-02-12 00:18:44 --> Output Class Initialized
INFO - 2018-02-12 00:18:44 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:44 --> Input Class Initialized
INFO - 2018-02-12 00:18:44 --> Language Class Initialized
INFO - 2018-02-12 00:18:44 --> Loader Class Initialized
INFO - 2018-02-12 00:18:44 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:44 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:44 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Controller Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:18:44 --> Final output sent to browser
DEBUG - 2018-02-12 00:18:44 --> Total execution time: 0.0612
INFO - 2018-02-12 00:18:44 --> Config Class Initialized
INFO - 2018-02-12 00:18:44 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:44 --> Config Class Initialized
INFO - 2018-02-12 00:18:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:44 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:44 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:44 --> URI Class Initialized
INFO - 2018-02-12 00:18:44 --> URI Class Initialized
INFO - 2018-02-12 00:18:44 --> Router Class Initialized
INFO - 2018-02-12 00:18:44 --> Router Class Initialized
INFO - 2018-02-12 00:18:44 --> Output Class Initialized
INFO - 2018-02-12 00:18:44 --> Output Class Initialized
INFO - 2018-02-12 00:18:44 --> Security Class Initialized
INFO - 2018-02-12 00:18:44 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:44 --> Input Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:44 --> Input Class Initialized
INFO - 2018-02-12 00:18:44 --> Language Class Initialized
INFO - 2018-02-12 00:18:44 --> Language Class Initialized
INFO - 2018-02-12 00:18:44 --> Loader Class Initialized
INFO - 2018-02-12 00:18:44 --> Loader Class Initialized
INFO - 2018-02-12 00:18:44 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:44 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:44 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:44 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:44 --> Database Driver Class Initialized
INFO - 2018-02-12 00:18:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:44 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Controller Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:44 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Controller Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
INFO - 2018-02-12 00:18:44 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:45 --> Config Class Initialized
INFO - 2018-02-12 00:18:45 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:45 --> Config Class Initialized
INFO - 2018-02-12 00:18:45 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:45 --> Config Class Initialized
INFO - 2018-02-12 00:18:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:45 --> URI Class Initialized
INFO - 2018-02-12 00:18:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:45 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:45 --> URI Class Initialized
INFO - 2018-02-12 00:18:45 --> Router Class Initialized
INFO - 2018-02-12 00:18:45 --> URI Class Initialized
INFO - 2018-02-12 00:18:45 --> Output Class Initialized
INFO - 2018-02-12 00:18:45 --> Router Class Initialized
INFO - 2018-02-12 00:18:45 --> Security Class Initialized
INFO - 2018-02-12 00:18:45 --> Router Class Initialized
INFO - 2018-02-12 00:18:45 --> Output Class Initialized
DEBUG - 2018-02-12 00:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:45 --> Input Class Initialized
INFO - 2018-02-12 00:18:45 --> Output Class Initialized
INFO - 2018-02-12 00:18:45 --> Language Class Initialized
INFO - 2018-02-12 00:18:45 --> Security Class Initialized
INFO - 2018-02-12 00:18:45 --> Security Class Initialized
ERROR - 2018-02-12 00:18:45 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 00:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:45 --> Input Class Initialized
DEBUG - 2018-02-12 00:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:45 --> Input Class Initialized
INFO - 2018-02-12 00:18:45 --> Language Class Initialized
INFO - 2018-02-12 00:18:45 --> Language Class Initialized
ERROR - 2018-02-12 00:18:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:18:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Loader Class Initialized
INFO - 2018-02-12 00:18:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Controller Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:18:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:18:47 --> Final output sent to browser
DEBUG - 2018-02-12 00:18:47 --> Total execution time: 0.0692
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:18:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:18:47 --> Config Class Initialized
INFO - 2018-02-12 00:18:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:18:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:18:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> URI Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Router Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Output Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
INFO - 2018-02-12 00:18:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:18:47 --> Input Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Language Class Initialized
INFO - 2018-02-12 00:18:47 --> Loader Class Initialized
INFO - 2018-02-12 00:18:47 --> Loader Class Initialized
INFO - 2018-02-12 00:18:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:18:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:18:47 --> Database Driver Class Initialized
INFO - 2018-02-12 00:18:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Controller Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-02-12 00:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:18:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Controller Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
INFO - 2018-02-12 00:18:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Loader Class Initialized
INFO - 2018-02-12 00:21:00 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:00 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:21:00 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Controller Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:21:00 --> Final output sent to browser
DEBUG - 2018-02-12 00:21:00 --> Total execution time: 0.0453
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:21:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:00 --> Config Class Initialized
INFO - 2018-02-12 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> URI Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Router Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Output Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
INFO - 2018-02-12 00:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:00 --> Input Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Language Class Initialized
INFO - 2018-02-12 00:21:00 --> Loader Class Initialized
INFO - 2018-02-12 00:21:00 --> Loader Class Initialized
INFO - 2018-02-12 00:21:00 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:00 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:00 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:00 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:00 --> Database Driver Class Initialized
INFO - 2018-02-12 00:21:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:00 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Controller Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:21:00 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Controller Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
INFO - 2018-02-12 00:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Loader Class Initialized
INFO - 2018-02-12 00:21:04 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:04 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:21:04 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Controller Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:21:04 --> Final output sent to browser
DEBUG - 2018-02-12 00:21:04 --> Total execution time: 0.0815
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:21:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
INFO - 2018-02-12 00:21:04 --> Config Class Initialized
INFO - 2018-02-12 00:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
DEBUG - 2018-02-12 00:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 00:21:04 --> URI Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Router Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Output Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
INFO - 2018-02-12 00:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Input Class Initialized
INFO - 2018-02-12 00:21:04 --> Language Class Initialized
INFO - 2018-02-12 00:21:04 --> Loader Class Initialized
INFO - 2018-02-12 00:21:04 --> Loader Class Initialized
INFO - 2018-02-12 00:21:04 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:04 --> Helper loaded: url_helper
INFO - 2018-02-12 00:21:04 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:04 --> Helper loaded: form_helper
INFO - 2018-02-12 00:21:04 --> Database Driver Class Initialized
INFO - 2018-02-12 00:21:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 00:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:21:04 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Controller Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:21:04 --> Form Validation Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Controller Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
INFO - 2018-02-12 00:21:04 --> Model Class Initialized
DEBUG - 2018-02-12 00:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Loader Class Initialized
INFO - 2018-02-12 00:22:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:22:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:22:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:22:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Controller Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:22:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:22:42 --> Final output sent to browser
DEBUG - 2018-02-12 00:22:42 --> Total execution time: 0.0676
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
ERROR - 2018-02-12 00:22:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
INFO - 2018-02-12 00:22:42 --> Config Class Initialized
INFO - 2018-02-12 00:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> URI Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Router Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Output Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
INFO - 2018-02-12 00:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Input Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Language Class Initialized
INFO - 2018-02-12 00:22:42 --> Loader Class Initialized
INFO - 2018-02-12 00:22:42 --> Loader Class Initialized
INFO - 2018-02-12 00:22:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:22:42 --> Helper loaded: url_helper
INFO - 2018-02-12 00:22:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:22:42 --> Helper loaded: form_helper
INFO - 2018-02-12 00:22:42 --> Database Driver Class Initialized
INFO - 2018-02-12 00:22:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 00:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:22:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Controller Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:22:42 --> Form Validation Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Controller Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
INFO - 2018-02-12 00:22:42 --> Model Class Initialized
DEBUG - 2018-02-12 00:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
INFO - 2018-02-12 00:23:01 --> Loader Class Initialized
INFO - 2018-02-12 00:23:01 --> Helper loaded: url_helper
INFO - 2018-02-12 00:23:01 --> Helper loaded: form_helper
INFO - 2018-02-12 00:23:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:23:01 --> Form Validation Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
INFO - 2018-02-12 00:23:01 --> Controller Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
INFO - 2018-02-12 00:23:01 --> Model Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:23:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:23:01 --> Final output sent to browser
DEBUG - 2018-02-12 00:23:01 --> Total execution time: 0.0686
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:23:01 --> Config Class Initialized
INFO - 2018-02-12 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
DEBUG - 2018-02-12 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> URI Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Router Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
INFO - 2018-02-12 00:23:01 --> Output Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
INFO - 2018-02-12 00:23:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
DEBUG - 2018-02-12 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
INFO - 2018-02-12 00:23:01 --> Input Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:23:01 --> Language Class Initialized
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:23:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:23:02 --> Config Class Initialized
INFO - 2018-02-12 00:23:02 --> Hooks Class Initialized
INFO - 2018-02-12 00:23:02 --> Config Class Initialized
INFO - 2018-02-12 00:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:23:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:23:02 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:02 --> Utf8 Class Initialized
INFO - 2018-02-12 00:23:02 --> URI Class Initialized
INFO - 2018-02-12 00:23:02 --> URI Class Initialized
INFO - 2018-02-12 00:23:02 --> Router Class Initialized
INFO - 2018-02-12 00:23:02 --> Router Class Initialized
INFO - 2018-02-12 00:23:02 --> Output Class Initialized
INFO - 2018-02-12 00:23:02 --> Output Class Initialized
INFO - 2018-02-12 00:23:02 --> Security Class Initialized
INFO - 2018-02-12 00:23:02 --> Security Class Initialized
DEBUG - 2018-02-12 00:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:23:02 --> Input Class Initialized
INFO - 2018-02-12 00:23:02 --> Input Class Initialized
INFO - 2018-02-12 00:23:02 --> Language Class Initialized
INFO - 2018-02-12 00:23:02 --> Language Class Initialized
INFO - 2018-02-12 00:23:02 --> Loader Class Initialized
INFO - 2018-02-12 00:23:02 --> Loader Class Initialized
INFO - 2018-02-12 00:23:02 --> Helper loaded: url_helper
INFO - 2018-02-12 00:23:02 --> Helper loaded: url_helper
INFO - 2018-02-12 00:23:02 --> Helper loaded: form_helper
INFO - 2018-02-12 00:23:02 --> Helper loaded: form_helper
INFO - 2018-02-12 00:23:02 --> Database Driver Class Initialized
INFO - 2018-02-12 00:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:23:02 --> Form Validation Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Controller Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
DEBUG - 2018-02-12 00:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-02-12 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:23:02 --> Form Validation Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Controller Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
INFO - 2018-02-12 00:23:02 --> Model Class Initialized
DEBUG - 2018-02-12 00:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:39:46 --> Config Class Initialized
INFO - 2018-02-12 00:39:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:39:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:46 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:46 --> URI Class Initialized
INFO - 2018-02-12 00:39:46 --> Router Class Initialized
INFO - 2018-02-12 00:39:46 --> Output Class Initialized
INFO - 2018-02-12 00:39:46 --> Security Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:46 --> Input Class Initialized
INFO - 2018-02-12 00:39:46 --> Language Class Initialized
INFO - 2018-02-12 00:39:46 --> Loader Class Initialized
INFO - 2018-02-12 00:39:46 --> Helper loaded: url_helper
INFO - 2018-02-12 00:39:46 --> Helper loaded: form_helper
INFO - 2018-02-12 00:39:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:39:46 --> Form Validation Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
INFO - 2018-02-12 00:39:46 --> Controller Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
INFO - 2018-02-12 00:39:46 --> Model Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:39:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:39:46 --> Final output sent to browser
DEBUG - 2018-02-12 00:39:46 --> Total execution time: 0.0763
INFO - 2018-02-12 00:39:46 --> Config Class Initialized
INFO - 2018-02-12 00:39:46 --> Hooks Class Initialized
INFO - 2018-02-12 00:39:46 --> Config Class Initialized
INFO - 2018-02-12 00:39:46 --> Config Class Initialized
INFO - 2018-02-12 00:39:46 --> Hooks Class Initialized
INFO - 2018-02-12 00:39:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:39:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:46 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:39:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:46 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:46 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:46 --> URI Class Initialized
INFO - 2018-02-12 00:39:46 --> URI Class Initialized
INFO - 2018-02-12 00:39:46 --> URI Class Initialized
INFO - 2018-02-12 00:39:46 --> Router Class Initialized
INFO - 2018-02-12 00:39:46 --> Router Class Initialized
INFO - 2018-02-12 00:39:46 --> Router Class Initialized
INFO - 2018-02-12 00:39:46 --> Output Class Initialized
INFO - 2018-02-12 00:39:46 --> Output Class Initialized
INFO - 2018-02-12 00:39:46 --> Output Class Initialized
INFO - 2018-02-12 00:39:46 --> Security Class Initialized
INFO - 2018-02-12 00:39:46 --> Security Class Initialized
INFO - 2018-02-12 00:39:46 --> Security Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:46 --> Input Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:46 --> Input Class Initialized
INFO - 2018-02-12 00:39:46 --> Language Class Initialized
DEBUG - 2018-02-12 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:46 --> Input Class Initialized
INFO - 2018-02-12 00:39:46 --> Language Class Initialized
INFO - 2018-02-12 00:39:46 --> Language Class Initialized
ERROR - 2018-02-12 00:39:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:39:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:39:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:39:47 --> Config Class Initialized
INFO - 2018-02-12 00:39:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:39:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:47 --> URI Class Initialized
INFO - 2018-02-12 00:39:47 --> Router Class Initialized
INFO - 2018-02-12 00:39:47 --> Output Class Initialized
INFO - 2018-02-12 00:39:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:47 --> Input Class Initialized
INFO - 2018-02-12 00:39:47 --> Language Class Initialized
ERROR - 2018-02-12 00:39:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:39:47 --> Config Class Initialized
INFO - 2018-02-12 00:39:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:39:47 --> Config Class Initialized
INFO - 2018-02-12 00:39:47 --> Config Class Initialized
INFO - 2018-02-12 00:39:47 --> Hooks Class Initialized
INFO - 2018-02-12 00:39:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:39:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:39:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:39:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:47 --> URI Class Initialized
INFO - 2018-02-12 00:39:47 --> URI Class Initialized
INFO - 2018-02-12 00:39:47 --> URI Class Initialized
INFO - 2018-02-12 00:39:47 --> Router Class Initialized
INFO - 2018-02-12 00:39:47 --> Router Class Initialized
INFO - 2018-02-12 00:39:47 --> Router Class Initialized
INFO - 2018-02-12 00:39:47 --> Output Class Initialized
INFO - 2018-02-12 00:39:47 --> Output Class Initialized
INFO - 2018-02-12 00:39:47 --> Output Class Initialized
INFO - 2018-02-12 00:39:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:47 --> Input Class Initialized
INFO - 2018-02-12 00:39:47 --> Security Class Initialized
INFO - 2018-02-12 00:39:47 --> Security Class Initialized
INFO - 2018-02-12 00:39:47 --> Language Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:39:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:39:47 --> Input Class Initialized
INFO - 2018-02-12 00:39:47 --> Input Class Initialized
INFO - 2018-02-12 00:39:47 --> Language Class Initialized
INFO - 2018-02-12 00:39:47 --> Language Class Initialized
ERROR - 2018-02-12 00:39:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:39:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:39:47 --> Config Class Initialized
INFO - 2018-02-12 00:39:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:39:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:39:47 --> Utf8 Class Initialized
INFO - 2018-02-12 00:39:47 --> URI Class Initialized
INFO - 2018-02-12 00:39:47 --> Router Class Initialized
INFO - 2018-02-12 00:39:47 --> Output Class Initialized
INFO - 2018-02-12 00:39:47 --> Security Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:39:47 --> Input Class Initialized
INFO - 2018-02-12 00:39:47 --> Language Class Initialized
INFO - 2018-02-12 00:39:47 --> Loader Class Initialized
INFO - 2018-02-12 00:39:47 --> Helper loaded: url_helper
INFO - 2018-02-12 00:39:47 --> Helper loaded: form_helper
INFO - 2018-02-12 00:39:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:39:47 --> Form Validation Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
INFO - 2018-02-12 00:39:47 --> Controller Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
INFO - 2018-02-12 00:39:47 --> Model Class Initialized
DEBUG - 2018-02-12 00:39:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 00:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 620
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Loader Class Initialized
INFO - 2018-02-12 00:40:36 --> Helper loaded: url_helper
INFO - 2018-02-12 00:40:36 --> Helper loaded: form_helper
INFO - 2018-02-12 00:40:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:40:36 --> Form Validation Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Controller Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:40:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:40:36 --> Final output sent to browser
DEBUG - 2018-02-12 00:40:36 --> Total execution time: 0.0829
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:40:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:40:36 --> Config Class Initialized
INFO - 2018-02-12 00:40:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:40:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:40:36 --> Utf8 Class Initialized
INFO - 2018-02-12 00:40:36 --> URI Class Initialized
INFO - 2018-02-12 00:40:36 --> Router Class Initialized
INFO - 2018-02-12 00:40:36 --> Output Class Initialized
INFO - 2018-02-12 00:40:36 --> Security Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:40:36 --> Input Class Initialized
INFO - 2018-02-12 00:40:36 --> Language Class Initialized
INFO - 2018-02-12 00:40:36 --> Loader Class Initialized
INFO - 2018-02-12 00:40:36 --> Helper loaded: url_helper
INFO - 2018-02-12 00:40:36 --> Helper loaded: form_helper
INFO - 2018-02-12 00:40:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:40:36 --> Form Validation Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Controller Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
INFO - 2018-02-12 00:40:36 --> Model Class Initialized
DEBUG - 2018-02-12 00:40:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
INFO - 2018-02-12 00:42:14 --> Loader Class Initialized
INFO - 2018-02-12 00:42:14 --> Helper loaded: url_helper
INFO - 2018-02-12 00:42:14 --> Helper loaded: form_helper
INFO - 2018-02-12 00:42:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:42:14 --> Form Validation Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Controller Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:42:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:42:14 --> Final output sent to browser
DEBUG - 2018-02-12 00:42:14 --> Total execution time: 0.0630
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:42:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:42:14 --> Config Class Initialized
INFO - 2018-02-12 00:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:14 --> URI Class Initialized
INFO - 2018-02-12 00:42:14 --> Router Class Initialized
INFO - 2018-02-12 00:42:14 --> Output Class Initialized
INFO - 2018-02-12 00:42:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:14 --> Input Class Initialized
INFO - 2018-02-12 00:42:14 --> Language Class Initialized
INFO - 2018-02-12 00:42:14 --> Loader Class Initialized
INFO - 2018-02-12 00:42:14 --> Helper loaded: url_helper
INFO - 2018-02-12 00:42:14 --> Helper loaded: form_helper
INFO - 2018-02-12 00:42:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:42:14 --> Form Validation Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Controller Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
INFO - 2018-02-12 00:42:14 --> Model Class Initialized
DEBUG - 2018-02-12 00:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
INFO - 2018-02-12 00:42:54 --> Loader Class Initialized
INFO - 2018-02-12 00:42:54 --> Helper loaded: url_helper
INFO - 2018-02-12 00:42:54 --> Helper loaded: form_helper
INFO - 2018-02-12 00:42:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:42:54 --> Form Validation Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Controller Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:42:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:42:54 --> Final output sent to browser
DEBUG - 2018-02-12 00:42:54 --> Total execution time: 0.0670
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:42:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:42:54 --> Config Class Initialized
INFO - 2018-02-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:42:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:42:54 --> Utf8 Class Initialized
INFO - 2018-02-12 00:42:54 --> URI Class Initialized
INFO - 2018-02-12 00:42:54 --> Router Class Initialized
INFO - 2018-02-12 00:42:54 --> Output Class Initialized
INFO - 2018-02-12 00:42:54 --> Security Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:42:54 --> Input Class Initialized
INFO - 2018-02-12 00:42:54 --> Language Class Initialized
INFO - 2018-02-12 00:42:54 --> Loader Class Initialized
INFO - 2018-02-12 00:42:54 --> Helper loaded: url_helper
INFO - 2018-02-12 00:42:54 --> Helper loaded: form_helper
INFO - 2018-02-12 00:42:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:42:54 --> Form Validation Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Controller Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
INFO - 2018-02-12 00:42:54 --> Model Class Initialized
DEBUG - 2018-02-12 00:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
INFO - 2018-02-12 00:48:31 --> Loader Class Initialized
INFO - 2018-02-12 00:48:31 --> Helper loaded: url_helper
INFO - 2018-02-12 00:48:31 --> Helper loaded: form_helper
INFO - 2018-02-12 00:48:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:48:31 --> Form Validation Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Controller Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:48:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:48:31 --> Final output sent to browser
DEBUG - 2018-02-12 00:48:31 --> Total execution time: 0.0884
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:48:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:48:31 --> Config Class Initialized
INFO - 2018-02-12 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:48:31 --> Utf8 Class Initialized
INFO - 2018-02-12 00:48:31 --> URI Class Initialized
INFO - 2018-02-12 00:48:31 --> Router Class Initialized
INFO - 2018-02-12 00:48:31 --> Output Class Initialized
INFO - 2018-02-12 00:48:31 --> Security Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:48:31 --> Input Class Initialized
INFO - 2018-02-12 00:48:31 --> Language Class Initialized
INFO - 2018-02-12 00:48:31 --> Loader Class Initialized
INFO - 2018-02-12 00:48:31 --> Helper loaded: url_helper
INFO - 2018-02-12 00:48:31 --> Helper loaded: form_helper
INFO - 2018-02-12 00:48:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:48:31 --> Form Validation Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Controller Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
INFO - 2018-02-12 00:48:31 --> Model Class Initialized
DEBUG - 2018-02-12 00:48:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:49:00 --> Config Class Initialized
INFO - 2018-02-12 00:49:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:00 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:00 --> URI Class Initialized
INFO - 2018-02-12 00:49:00 --> Router Class Initialized
INFO - 2018-02-12 00:49:00 --> Output Class Initialized
INFO - 2018-02-12 00:49:00 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:00 --> Input Class Initialized
INFO - 2018-02-12 00:49:00 --> Language Class Initialized
INFO - 2018-02-12 00:49:00 --> Loader Class Initialized
INFO - 2018-02-12 00:49:00 --> Helper loaded: url_helper
INFO - 2018-02-12 00:49:00 --> Helper loaded: form_helper
INFO - 2018-02-12 00:49:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:49:01 --> Form Validation Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Controller Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:49:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:49:01 --> Final output sent to browser
DEBUG - 2018-02-12 00:49:01 --> Total execution time: 0.1260
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:49:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:49:01 --> Config Class Initialized
INFO - 2018-02-12 00:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:01 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:01 --> URI Class Initialized
INFO - 2018-02-12 00:49:01 --> Router Class Initialized
INFO - 2018-02-12 00:49:01 --> Output Class Initialized
INFO - 2018-02-12 00:49:01 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:01 --> Input Class Initialized
INFO - 2018-02-12 00:49:01 --> Language Class Initialized
INFO - 2018-02-12 00:49:01 --> Loader Class Initialized
INFO - 2018-02-12 00:49:01 --> Helper loaded: url_helper
INFO - 2018-02-12 00:49:01 --> Helper loaded: form_helper
INFO - 2018-02-12 00:49:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:49:01 --> Form Validation Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Controller Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
INFO - 2018-02-12 00:49:01 --> Model Class Initialized
DEBUG - 2018-02-12 00:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
INFO - 2018-02-12 00:49:43 --> Loader Class Initialized
INFO - 2018-02-12 00:49:43 --> Helper loaded: url_helper
INFO - 2018-02-12 00:49:43 --> Helper loaded: form_helper
INFO - 2018-02-12 00:49:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:49:43 --> Form Validation Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Controller Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:49:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:49:43 --> Final output sent to browser
DEBUG - 2018-02-12 00:49:43 --> Total execution time: 0.0782
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 00:49:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 00:49:43 --> Config Class Initialized
INFO - 2018-02-12 00:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:49:43 --> Utf8 Class Initialized
INFO - 2018-02-12 00:49:43 --> URI Class Initialized
INFO - 2018-02-12 00:49:43 --> Router Class Initialized
INFO - 2018-02-12 00:49:43 --> Output Class Initialized
INFO - 2018-02-12 00:49:43 --> Security Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:49:43 --> Input Class Initialized
INFO - 2018-02-12 00:49:43 --> Language Class Initialized
INFO - 2018-02-12 00:49:43 --> Loader Class Initialized
INFO - 2018-02-12 00:49:43 --> Helper loaded: url_helper
INFO - 2018-02-12 00:49:43 --> Helper loaded: form_helper
INFO - 2018-02-12 00:49:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:49:43 --> Form Validation Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Controller Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
INFO - 2018-02-12 00:49:43 --> Model Class Initialized
DEBUG - 2018-02-12 00:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:50:32 --> Config Class Initialized
INFO - 2018-02-12 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:50:32 --> Utf8 Class Initialized
INFO - 2018-02-12 00:50:32 --> URI Class Initialized
INFO - 2018-02-12 00:50:32 --> Router Class Initialized
INFO - 2018-02-12 00:50:32 --> Output Class Initialized
INFO - 2018-02-12 00:50:32 --> Security Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:50:32 --> Input Class Initialized
INFO - 2018-02-12 00:50:32 --> Language Class Initialized
INFO - 2018-02-12 00:50:32 --> Loader Class Initialized
INFO - 2018-02-12 00:50:32 --> Helper loaded: url_helper
INFO - 2018-02-12 00:50:32 --> Helper loaded: form_helper
INFO - 2018-02-12 00:50:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:50:32 --> Form Validation Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Controller Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:50:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:50:32 --> Final output sent to browser
DEBUG - 2018-02-12 00:50:32 --> Total execution time: 0.1098
INFO - 2018-02-12 00:50:32 --> Config Class Initialized
INFO - 2018-02-12 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:50:32 --> Utf8 Class Initialized
INFO - 2018-02-12 00:50:32 --> URI Class Initialized
INFO - 2018-02-12 00:50:32 --> Router Class Initialized
INFO - 2018-02-12 00:50:32 --> Output Class Initialized
INFO - 2018-02-12 00:50:32 --> Security Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:50:32 --> Input Class Initialized
INFO - 2018-02-12 00:50:32 --> Language Class Initialized
INFO - 2018-02-12 00:50:32 --> Loader Class Initialized
INFO - 2018-02-12 00:50:32 --> Helper loaded: url_helper
INFO - 2018-02-12 00:50:32 --> Helper loaded: form_helper
INFO - 2018-02-12 00:50:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:50:32 --> Form Validation Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Controller Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
INFO - 2018-02-12 00:50:32 --> Model Class Initialized
DEBUG - 2018-02-12 00:50:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:58:12 --> Config Class Initialized
INFO - 2018-02-12 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:58:12 --> Utf8 Class Initialized
INFO - 2018-02-12 00:58:12 --> URI Class Initialized
INFO - 2018-02-12 00:58:12 --> Router Class Initialized
INFO - 2018-02-12 00:58:12 --> Output Class Initialized
INFO - 2018-02-12 00:58:12 --> Security Class Initialized
DEBUG - 2018-02-12 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:58:12 --> Input Class Initialized
INFO - 2018-02-12 00:58:12 --> Language Class Initialized
INFO - 2018-02-12 00:58:12 --> Loader Class Initialized
INFO - 2018-02-12 00:58:12 --> Helper loaded: url_helper
INFO - 2018-02-12 00:58:12 --> Helper loaded: form_helper
INFO - 2018-02-12 00:58:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:58:12 --> Form Validation Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
INFO - 2018-02-12 00:58:12 --> Controller Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
INFO - 2018-02-12 00:58:12 --> Model Class Initialized
DEBUG - 2018-02-12 00:58:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:58:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:58:12 --> Final output sent to browser
DEBUG - 2018-02-12 00:58:12 --> Total execution time: 0.0854
INFO - 2018-02-12 00:58:12 --> Config Class Initialized
INFO - 2018-02-12 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:58:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:58:13 --> Utf8 Class Initialized
INFO - 2018-02-12 00:58:13 --> URI Class Initialized
INFO - 2018-02-12 00:58:13 --> Router Class Initialized
INFO - 2018-02-12 00:58:13 --> Output Class Initialized
INFO - 2018-02-12 00:58:13 --> Security Class Initialized
DEBUG - 2018-02-12 00:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:58:13 --> Input Class Initialized
INFO - 2018-02-12 00:58:13 --> Language Class Initialized
INFO - 2018-02-12 00:58:13 --> Loader Class Initialized
INFO - 2018-02-12 00:58:13 --> Helper loaded: url_helper
INFO - 2018-02-12 00:58:13 --> Helper loaded: form_helper
INFO - 2018-02-12 00:58:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:58:13 --> Form Validation Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
INFO - 2018-02-12 00:58:13 --> Controller Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
INFO - 2018-02-12 00:58:13 --> Model Class Initialized
DEBUG - 2018-02-12 00:58:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:58:14 --> Config Class Initialized
INFO - 2018-02-12 00:58:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:58:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:58:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:58:14 --> URI Class Initialized
INFO - 2018-02-12 00:58:14 --> Router Class Initialized
INFO - 2018-02-12 00:58:14 --> Output Class Initialized
INFO - 2018-02-12 00:58:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:58:14 --> Input Class Initialized
INFO - 2018-02-12 00:58:14 --> Language Class Initialized
INFO - 2018-02-12 00:58:14 --> Loader Class Initialized
INFO - 2018-02-12 00:58:14 --> Helper loaded: url_helper
INFO - 2018-02-12 00:58:14 --> Helper loaded: form_helper
INFO - 2018-02-12 00:58:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:58:14 --> Form Validation Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Controller Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 00:58:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 00:58:14 --> Final output sent to browser
DEBUG - 2018-02-12 00:58:14 --> Total execution time: 0.1574
INFO - 2018-02-12 00:58:14 --> Config Class Initialized
INFO - 2018-02-12 00:58:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:58:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 00:58:14 --> Utf8 Class Initialized
INFO - 2018-02-12 00:58:14 --> URI Class Initialized
INFO - 2018-02-12 00:58:14 --> Router Class Initialized
INFO - 2018-02-12 00:58:14 --> Output Class Initialized
INFO - 2018-02-12 00:58:14 --> Security Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 00:58:14 --> Input Class Initialized
INFO - 2018-02-12 00:58:14 --> Language Class Initialized
INFO - 2018-02-12 00:58:14 --> Loader Class Initialized
INFO - 2018-02-12 00:58:14 --> Helper loaded: url_helper
INFO - 2018-02-12 00:58:14 --> Helper loaded: form_helper
INFO - 2018-02-12 00:58:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 00:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 00:58:14 --> Form Validation Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Controller Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
INFO - 2018-02-12 00:58:14 --> Model Class Initialized
DEBUG - 2018-02-12 00:58:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:01:06 --> Config Class Initialized
INFO - 2018-02-12 01:01:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:06 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:06 --> URI Class Initialized
INFO - 2018-02-12 01:01:06 --> Router Class Initialized
INFO - 2018-02-12 01:01:06 --> Output Class Initialized
INFO - 2018-02-12 01:01:06 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:06 --> Input Class Initialized
INFO - 2018-02-12 01:01:06 --> Language Class Initialized
INFO - 2018-02-12 01:01:06 --> Loader Class Initialized
INFO - 2018-02-12 01:01:06 --> Helper loaded: url_helper
INFO - 2018-02-12 01:01:06 --> Helper loaded: form_helper
INFO - 2018-02-12 01:01:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:01:06 --> Form Validation Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Controller Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
DEBUG - 2018-02-12 01:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:01:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:01:06 --> Final output sent to browser
DEBUG - 2018-02-12 01:01:06 --> Total execution time: 0.0907
INFO - 2018-02-12 01:01:06 --> Config Class Initialized
INFO - 2018-02-12 01:01:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:06 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:06 --> URI Class Initialized
INFO - 2018-02-12 01:01:06 --> Router Class Initialized
INFO - 2018-02-12 01:01:06 --> Output Class Initialized
INFO - 2018-02-12 01:01:06 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:06 --> Input Class Initialized
INFO - 2018-02-12 01:01:06 --> Language Class Initialized
INFO - 2018-02-12 01:01:06 --> Loader Class Initialized
INFO - 2018-02-12 01:01:06 --> Helper loaded: url_helper
INFO - 2018-02-12 01:01:06 --> Helper loaded: form_helper
INFO - 2018-02-12 01:01:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:01:06 --> Form Validation Class Initialized
INFO - 2018-02-12 01:01:06 --> Model Class Initialized
INFO - 2018-02-12 01:01:06 --> Controller Class Initialized
INFO - 2018-02-12 01:01:07 --> Model Class Initialized
INFO - 2018-02-12 01:01:07 --> Model Class Initialized
INFO - 2018-02-12 01:01:07 --> Model Class Initialized
INFO - 2018-02-12 01:01:07 --> Model Class Initialized
INFO - 2018-02-12 01:01:07 --> Model Class Initialized
DEBUG - 2018-02-12 01:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:10 --> Config Class Initialized
INFO - 2018-02-12 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> URI Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> Router Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
INFO - 2018-02-12 01:01:10 --> Output Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
INFO - 2018-02-12 01:01:10 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
DEBUG - 2018-02-12 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:10 --> Input Class Initialized
INFO - 2018-02-12 01:01:10 --> Language Class Initialized
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:01:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
INFO - 2018-02-12 01:01:22 --> Loader Class Initialized
INFO - 2018-02-12 01:01:22 --> Helper loaded: url_helper
INFO - 2018-02-12 01:01:22 --> Helper loaded: form_helper
INFO - 2018-02-12 01:01:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:01:22 --> Form Validation Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Controller Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:01:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:01:22 --> Final output sent to browser
DEBUG - 2018-02-12 01:01:22 --> Total execution time: 0.0924
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:01:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:01:22 --> Config Class Initialized
INFO - 2018-02-12 01:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:01:22 --> Utf8 Class Initialized
INFO - 2018-02-12 01:01:22 --> URI Class Initialized
INFO - 2018-02-12 01:01:22 --> Router Class Initialized
INFO - 2018-02-12 01:01:22 --> Output Class Initialized
INFO - 2018-02-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:01:22 --> Input Class Initialized
INFO - 2018-02-12 01:01:22 --> Language Class Initialized
INFO - 2018-02-12 01:01:22 --> Loader Class Initialized
INFO - 2018-02-12 01:01:22 --> Helper loaded: url_helper
INFO - 2018-02-12 01:01:22 --> Helper loaded: form_helper
INFO - 2018-02-12 01:01:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:01:22 --> Form Validation Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Controller Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
INFO - 2018-02-12 01:01:22 --> Model Class Initialized
DEBUG - 2018-02-12 01:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
INFO - 2018-02-12 01:02:01 --> Loader Class Initialized
INFO - 2018-02-12 01:02:01 --> Helper loaded: url_helper
INFO - 2018-02-12 01:02:01 --> Helper loaded: form_helper
INFO - 2018-02-12 01:02:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:02:01 --> Form Validation Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Controller Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:02:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:02:01 --> Final output sent to browser
DEBUG - 2018-02-12 01:02:01 --> Total execution time: 0.0871
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:02:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:02:01 --> Config Class Initialized
INFO - 2018-02-12 01:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:01 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:01 --> URI Class Initialized
INFO - 2018-02-12 01:02:01 --> Router Class Initialized
INFO - 2018-02-12 01:02:01 --> Output Class Initialized
INFO - 2018-02-12 01:02:01 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:01 --> Input Class Initialized
INFO - 2018-02-12 01:02:01 --> Language Class Initialized
INFO - 2018-02-12 01:02:01 --> Loader Class Initialized
INFO - 2018-02-12 01:02:01 --> Helper loaded: url_helper
INFO - 2018-02-12 01:02:01 --> Helper loaded: form_helper
INFO - 2018-02-12 01:02:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:02:01 --> Form Validation Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Controller Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
INFO - 2018-02-12 01:02:01 --> Model Class Initialized
DEBUG - 2018-02-12 01:02:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
INFO - 2018-02-12 01:02:35 --> Loader Class Initialized
INFO - 2018-02-12 01:02:35 --> Helper loaded: url_helper
INFO - 2018-02-12 01:02:35 --> Helper loaded: form_helper
INFO - 2018-02-12 01:02:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:02:35 --> Form Validation Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
INFO - 2018-02-12 01:02:35 --> Controller Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
INFO - 2018-02-12 01:02:35 --> Model Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:02:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:02:35 --> Final output sent to browser
DEBUG - 2018-02-12 01:02:35 --> Total execution time: 0.0940
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
INFO - 2018-02-12 01:02:35 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Input Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
INFO - 2018-02-12 01:02:35 --> Language Class Initialized
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:02:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:02:35 --> Config Class Initialized
INFO - 2018-02-12 01:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:02:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:02:35 --> URI Class Initialized
INFO - 2018-02-12 01:02:35 --> Router Class Initialized
INFO - 2018-02-12 01:02:35 --> Output Class Initialized
INFO - 2018-02-12 01:02:36 --> Security Class Initialized
DEBUG - 2018-02-12 01:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:02:36 --> Input Class Initialized
INFO - 2018-02-12 01:02:36 --> Language Class Initialized
INFO - 2018-02-12 01:02:36 --> Loader Class Initialized
INFO - 2018-02-12 01:02:36 --> Helper loaded: url_helper
INFO - 2018-02-12 01:02:36 --> Helper loaded: form_helper
INFO - 2018-02-12 01:02:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:02:36 --> Form Validation Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
INFO - 2018-02-12 01:02:36 --> Controller Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
INFO - 2018-02-12 01:02:36 --> Model Class Initialized
DEBUG - 2018-02-12 01:02:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
INFO - 2018-02-12 01:32:00 --> Loader Class Initialized
INFO - 2018-02-12 01:32:00 --> Helper loaded: url_helper
INFO - 2018-02-12 01:32:00 --> Helper loaded: form_helper
INFO - 2018-02-12 01:32:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:32:00 --> Form Validation Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Controller Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:32:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:32:00 --> Final output sent to browser
DEBUG - 2018-02-12 01:32:00 --> Total execution time: 0.1052
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:32:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:32:00 --> Config Class Initialized
INFO - 2018-02-12 01:32:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:32:00 --> Utf8 Class Initialized
INFO - 2018-02-12 01:32:00 --> URI Class Initialized
INFO - 2018-02-12 01:32:00 --> Router Class Initialized
INFO - 2018-02-12 01:32:00 --> Output Class Initialized
INFO - 2018-02-12 01:32:00 --> Security Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:32:00 --> Input Class Initialized
INFO - 2018-02-12 01:32:00 --> Language Class Initialized
INFO - 2018-02-12 01:32:00 --> Loader Class Initialized
INFO - 2018-02-12 01:32:00 --> Helper loaded: url_helper
INFO - 2018-02-12 01:32:00 --> Helper loaded: form_helper
INFO - 2018-02-12 01:32:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:32:00 --> Form Validation Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Controller Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
INFO - 2018-02-12 01:32:00 --> Model Class Initialized
DEBUG - 2018-02-12 01:32:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
INFO - 2018-02-12 01:34:26 --> Loader Class Initialized
INFO - 2018-02-12 01:34:26 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:26 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:26 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Controller Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:34:26 --> Final output sent to browser
DEBUG - 2018-02-12 01:34:26 --> Total execution time: 0.1256
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:34:26 --> Config Class Initialized
INFO - 2018-02-12 01:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:26 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:26 --> URI Class Initialized
INFO - 2018-02-12 01:34:26 --> Router Class Initialized
INFO - 2018-02-12 01:34:26 --> Output Class Initialized
INFO - 2018-02-12 01:34:26 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:26 --> Input Class Initialized
INFO - 2018-02-12 01:34:26 --> Language Class Initialized
INFO - 2018-02-12 01:34:26 --> Loader Class Initialized
INFO - 2018-02-12 01:34:26 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:26 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:26 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Controller Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
INFO - 2018-02-12 01:34:26 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:33 --> Config Class Initialized
INFO - 2018-02-12 01:34:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:33 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:33 --> URI Class Initialized
INFO - 2018-02-12 01:34:33 --> Router Class Initialized
INFO - 2018-02-12 01:34:33 --> Output Class Initialized
INFO - 2018-02-12 01:34:33 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:33 --> Input Class Initialized
INFO - 2018-02-12 01:34:33 --> Language Class Initialized
INFO - 2018-02-12 01:34:33 --> Loader Class Initialized
INFO - 2018-02-12 01:34:33 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:33 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:33 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:33 --> Model Class Initialized
INFO - 2018-02-12 01:34:33 --> Controller Class Initialized
INFO - 2018-02-12 01:34:33 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:34:33 --> Final output sent to browser
DEBUG - 2018-02-12 01:34:33 --> Total execution time: 0.1748
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:34:34 --> Config Class Initialized
INFO - 2018-02-12 01:34:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:34 --> URI Class Initialized
INFO - 2018-02-12 01:34:34 --> Router Class Initialized
INFO - 2018-02-12 01:34:34 --> Output Class Initialized
INFO - 2018-02-12 01:34:34 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:34 --> Input Class Initialized
INFO - 2018-02-12 01:34:34 --> Language Class Initialized
INFO - 2018-02-12 01:34:34 --> Loader Class Initialized
INFO - 2018-02-12 01:34:34 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:34 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:34 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:34 --> Model Class Initialized
INFO - 2018-02-12 01:34:34 --> Controller Class Initialized
INFO - 2018-02-12 01:34:34 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Loader Class Initialized
INFO - 2018-02-12 01:34:38 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:38 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:38 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Controller Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:34:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:34:38 --> Final output sent to browser
DEBUG - 2018-02-12 01:34:38 --> Total execution time: 0.1130
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:34:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:34:38 --> Config Class Initialized
INFO - 2018-02-12 01:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 01:34:38 --> URI Class Initialized
INFO - 2018-02-12 01:34:38 --> Router Class Initialized
INFO - 2018-02-12 01:34:38 --> Output Class Initialized
INFO - 2018-02-12 01:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:34:38 --> Input Class Initialized
INFO - 2018-02-12 01:34:38 --> Language Class Initialized
INFO - 2018-02-12 01:34:38 --> Loader Class Initialized
INFO - 2018-02-12 01:34:38 --> Helper loaded: url_helper
INFO - 2018-02-12 01:34:38 --> Helper loaded: form_helper
INFO - 2018-02-12 01:34:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:34:38 --> Form Validation Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Controller Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
INFO - 2018-02-12 01:34:38 --> Model Class Initialized
DEBUG - 2018-02-12 01:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:35:51 --> Config Class Initialized
INFO - 2018-02-12 01:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:51 --> URI Class Initialized
INFO - 2018-02-12 01:35:51 --> Router Class Initialized
INFO - 2018-02-12 01:35:51 --> Output Class Initialized
INFO - 2018-02-12 01:35:51 --> Security Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:51 --> Input Class Initialized
INFO - 2018-02-12 01:35:51 --> Language Class Initialized
INFO - 2018-02-12 01:35:51 --> Loader Class Initialized
INFO - 2018-02-12 01:35:51 --> Helper loaded: url_helper
INFO - 2018-02-12 01:35:51 --> Helper loaded: form_helper
INFO - 2018-02-12 01:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:35:51 --> Form Validation Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Controller Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:35:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:35:51 --> Final output sent to browser
DEBUG - 2018-02-12 01:35:51 --> Total execution time: 0.0903
INFO - 2018-02-12 01:35:51 --> Config Class Initialized
INFO - 2018-02-12 01:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:51 --> URI Class Initialized
INFO - 2018-02-12 01:35:51 --> Router Class Initialized
INFO - 2018-02-12 01:35:51 --> Output Class Initialized
INFO - 2018-02-12 01:35:51 --> Security Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:51 --> Input Class Initialized
INFO - 2018-02-12 01:35:51 --> Language Class Initialized
INFO - 2018-02-12 01:35:51 --> Loader Class Initialized
INFO - 2018-02-12 01:35:51 --> Helper loaded: url_helper
INFO - 2018-02-12 01:35:51 --> Helper loaded: form_helper
INFO - 2018-02-12 01:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:35:51 --> Form Validation Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Controller Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
INFO - 2018-02-12 01:35:51 --> Model Class Initialized
DEBUG - 2018-02-12 01:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
INFO - 2018-02-12 01:35:52 --> Config Class Initialized
INFO - 2018-02-12 01:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:35:52 --> Utf8 Class Initialized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> URI Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
INFO - 2018-02-12 01:35:52 --> Router Class Initialized
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
INFO - 2018-02-12 01:35:52 --> Output Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Security Class Initialized
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
INFO - 2018-02-12 01:35:52 --> Input Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
INFO - 2018-02-12 01:35:52 --> Language Class Initialized
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:35:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:39:50 --> Config Class Initialized
INFO - 2018-02-12 01:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:50 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:50 --> URI Class Initialized
INFO - 2018-02-12 01:39:50 --> Router Class Initialized
INFO - 2018-02-12 01:39:50 --> Output Class Initialized
INFO - 2018-02-12 01:39:50 --> Security Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:50 --> Input Class Initialized
INFO - 2018-02-12 01:39:50 --> Language Class Initialized
INFO - 2018-02-12 01:39:50 --> Loader Class Initialized
INFO - 2018-02-12 01:39:50 --> Helper loaded: url_helper
INFO - 2018-02-12 01:39:50 --> Helper loaded: form_helper
INFO - 2018-02-12 01:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:39:50 --> Form Validation Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Controller Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:39:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:39:50 --> Final output sent to browser
DEBUG - 2018-02-12 01:39:50 --> Total execution time: 2.3966
INFO - 2018-02-12 01:39:50 --> Config Class Initialized
INFO - 2018-02-12 01:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:50 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:50 --> URI Class Initialized
INFO - 2018-02-12 01:39:50 --> Router Class Initialized
INFO - 2018-02-12 01:39:50 --> Output Class Initialized
INFO - 2018-02-12 01:39:50 --> Security Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:50 --> Input Class Initialized
INFO - 2018-02-12 01:39:50 --> Language Class Initialized
INFO - 2018-02-12 01:39:50 --> Loader Class Initialized
INFO - 2018-02-12 01:39:50 --> Helper loaded: url_helper
INFO - 2018-02-12 01:39:50 --> Helper loaded: form_helper
INFO - 2018-02-12 01:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:39:50 --> Form Validation Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Controller Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
INFO - 2018-02-12 01:39:50 --> Model Class Initialized
DEBUG - 2018-02-12 01:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:39:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:39:50 --> Final output sent to browser
DEBUG - 2018-02-12 01:39:50 --> Total execution time: 0.1449
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
ERROR - 2018-02-12 01:39:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:39:51 --> Config Class Initialized
INFO - 2018-02-12 01:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:39:51 --> Utf8 Class Initialized
INFO - 2018-02-12 01:39:51 --> URI Class Initialized
INFO - 2018-02-12 01:39:51 --> Router Class Initialized
INFO - 2018-02-12 01:39:51 --> Output Class Initialized
INFO - 2018-02-12 01:39:51 --> Security Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:39:51 --> Input Class Initialized
INFO - 2018-02-12 01:39:51 --> Language Class Initialized
INFO - 2018-02-12 01:39:51 --> Loader Class Initialized
INFO - 2018-02-12 01:39:51 --> Helper loaded: url_helper
INFO - 2018-02-12 01:39:51 --> Helper loaded: form_helper
INFO - 2018-02-12 01:39:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:39:51 --> Form Validation Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
INFO - 2018-02-12 01:39:51 --> Controller Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
INFO - 2018-02-12 01:39:51 --> Model Class Initialized
DEBUG - 2018-02-12 01:39:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:20 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:20 --> URI Class Initialized
INFO - 2018-02-12 01:40:20 --> Router Class Initialized
INFO - 2018-02-12 01:40:20 --> Output Class Initialized
INFO - 2018-02-12 01:40:20 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:20 --> Input Class Initialized
INFO - 2018-02-12 01:40:20 --> Language Class Initialized
INFO - 2018-02-12 01:40:20 --> Loader Class Initialized
INFO - 2018-02-12 01:40:20 --> Helper loaded: url_helper
INFO - 2018-02-12 01:40:20 --> Helper loaded: form_helper
INFO - 2018-02-12 01:40:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:40:20 --> Form Validation Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
INFO - 2018-02-12 01:40:20 --> Controller Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
INFO - 2018-02-12 01:40:20 --> Model Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:40:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:40:20 --> Final output sent to browser
DEBUG - 2018-02-12 01:40:20 --> Total execution time: 0.0925
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:20 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:20 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:20 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:20 --> URI Class Initialized
INFO - 2018-02-12 01:40:20 --> URI Class Initialized
INFO - 2018-02-12 01:40:20 --> URI Class Initialized
INFO - 2018-02-12 01:40:20 --> Router Class Initialized
INFO - 2018-02-12 01:40:20 --> Router Class Initialized
INFO - 2018-02-12 01:40:20 --> Router Class Initialized
INFO - 2018-02-12 01:40:20 --> Output Class Initialized
INFO - 2018-02-12 01:40:20 --> Output Class Initialized
INFO - 2018-02-12 01:40:20 --> Output Class Initialized
INFO - 2018-02-12 01:40:20 --> Security Class Initialized
INFO - 2018-02-12 01:40:20 --> Security Class Initialized
INFO - 2018-02-12 01:40:20 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:20 --> Input Class Initialized
INFO - 2018-02-12 01:40:20 --> Input Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:20 --> Input Class Initialized
INFO - 2018-02-12 01:40:20 --> Language Class Initialized
INFO - 2018-02-12 01:40:20 --> Language Class Initialized
INFO - 2018-02-12 01:40:20 --> Language Class Initialized
ERROR - 2018-02-12 01:40:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:40:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:40:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:20 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:20 --> URI Class Initialized
INFO - 2018-02-12 01:40:20 --> Router Class Initialized
INFO - 2018-02-12 01:40:20 --> Output Class Initialized
INFO - 2018-02-12 01:40:20 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:20 --> Input Class Initialized
INFO - 2018-02-12 01:40:20 --> Language Class Initialized
ERROR - 2018-02-12 01:40:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
INFO - 2018-02-12 01:40:20 --> Config Class Initialized
INFO - 2018-02-12 01:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:21 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:21 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:21 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:21 --> URI Class Initialized
INFO - 2018-02-12 01:40:21 --> URI Class Initialized
INFO - 2018-02-12 01:40:21 --> URI Class Initialized
INFO - 2018-02-12 01:40:21 --> Router Class Initialized
INFO - 2018-02-12 01:40:21 --> Router Class Initialized
INFO - 2018-02-12 01:40:21 --> Router Class Initialized
INFO - 2018-02-12 01:40:21 --> Output Class Initialized
INFO - 2018-02-12 01:40:21 --> Output Class Initialized
INFO - 2018-02-12 01:40:21 --> Output Class Initialized
INFO - 2018-02-12 01:40:21 --> Security Class Initialized
INFO - 2018-02-12 01:40:21 --> Security Class Initialized
INFO - 2018-02-12 01:40:21 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:21 --> Input Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:21 --> Input Class Initialized
INFO - 2018-02-12 01:40:21 --> Language Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:21 --> Input Class Initialized
INFO - 2018-02-12 01:40:21 --> Language Class Initialized
ERROR - 2018-02-12 01:40:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:40:21 --> Language Class Initialized
ERROR - 2018-02-12 01:40:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:40:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:40:21 --> Config Class Initialized
INFO - 2018-02-12 01:40:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:21 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:21 --> URI Class Initialized
INFO - 2018-02-12 01:40:21 --> Router Class Initialized
INFO - 2018-02-12 01:40:21 --> Output Class Initialized
INFO - 2018-02-12 01:40:21 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:21 --> Input Class Initialized
INFO - 2018-02-12 01:40:21 --> Language Class Initialized
INFO - 2018-02-12 01:40:21 --> Loader Class Initialized
INFO - 2018-02-12 01:40:21 --> Helper loaded: url_helper
INFO - 2018-02-12 01:40:21 --> Helper loaded: form_helper
INFO - 2018-02-12 01:40:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:40:21 --> Form Validation Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
INFO - 2018-02-12 01:40:21 --> Controller Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
INFO - 2018-02-12 01:40:21 --> Model Class Initialized
DEBUG - 2018-02-12 01:40:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:40:23 --> Config Class Initialized
INFO - 2018-02-12 01:40:23 --> Hooks Class Initialized
INFO - 2018-02-12 01:40:23 --> Config Class Initialized
INFO - 2018-02-12 01:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:40:23 --> Utf8 Class Initialized
INFO - 2018-02-12 01:40:23 --> URI Class Initialized
INFO - 2018-02-12 01:40:23 --> URI Class Initialized
INFO - 2018-02-12 01:40:23 --> Router Class Initialized
INFO - 2018-02-12 01:40:23 --> Router Class Initialized
INFO - 2018-02-12 01:40:23 --> Output Class Initialized
INFO - 2018-02-12 01:40:23 --> Output Class Initialized
INFO - 2018-02-12 01:40:23 --> Security Class Initialized
INFO - 2018-02-12 01:40:23 --> Security Class Initialized
DEBUG - 2018-02-12 01:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:23 --> Input Class Initialized
DEBUG - 2018-02-12 01:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:40:23 --> Input Class Initialized
INFO - 2018-02-12 01:40:23 --> Language Class Initialized
INFO - 2018-02-12 01:40:23 --> Language Class Initialized
INFO - 2018-02-12 01:40:23 --> Loader Class Initialized
INFO - 2018-02-12 01:40:23 --> Loader Class Initialized
INFO - 2018-02-12 01:40:23 --> Helper loaded: url_helper
INFO - 2018-02-12 01:40:23 --> Helper loaded: url_helper
INFO - 2018-02-12 01:40:23 --> Helper loaded: form_helper
INFO - 2018-02-12 01:40:23 --> Helper loaded: form_helper
INFO - 2018-02-12 01:40:23 --> Database Driver Class Initialized
INFO - 2018-02-12 01:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 01:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:40:23 --> Form Validation Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Controller Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
DEBUG - 2018-02-12 01:40:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 01:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1205
ERROR - 2018-02-12 01:40:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `proyecto_id` = '1'
AND `colaborador_id` = 6' at line 2 - Invalid query: SELECT *
WHERE `proyecto_id` = '1'
AND `colaborador_id` = 6
INFO - 2018-02-12 01:40:23 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-12 01:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:40:23 --> Form Validation Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Controller Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
INFO - 2018-02-12 01:40:23 --> Model Class Initialized
DEBUG - 2018-02-12 01:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:41:54 --> Config Class Initialized
INFO - 2018-02-12 01:41:54 --> Hooks Class Initialized
INFO - 2018-02-12 01:41:54 --> Config Class Initialized
INFO - 2018-02-12 01:41:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:41:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:41:54 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:41:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:41:54 --> Utf8 Class Initialized
INFO - 2018-02-12 01:41:54 --> URI Class Initialized
INFO - 2018-02-12 01:41:54 --> URI Class Initialized
INFO - 2018-02-12 01:41:54 --> Router Class Initialized
INFO - 2018-02-12 01:41:54 --> Router Class Initialized
INFO - 2018-02-12 01:41:54 --> Output Class Initialized
INFO - 2018-02-12 01:41:54 --> Output Class Initialized
INFO - 2018-02-12 01:41:54 --> Security Class Initialized
INFO - 2018-02-12 01:41:54 --> Security Class Initialized
DEBUG - 2018-02-12 01:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:41:54 --> Input Class Initialized
INFO - 2018-02-12 01:41:54 --> Input Class Initialized
INFO - 2018-02-12 01:41:54 --> Language Class Initialized
INFO - 2018-02-12 01:41:54 --> Language Class Initialized
INFO - 2018-02-12 01:41:54 --> Loader Class Initialized
INFO - 2018-02-12 01:41:54 --> Loader Class Initialized
INFO - 2018-02-12 01:41:54 --> Helper loaded: url_helper
INFO - 2018-02-12 01:41:54 --> Helper loaded: url_helper
INFO - 2018-02-12 01:41:54 --> Helper loaded: form_helper
INFO - 2018-02-12 01:41:54 --> Helper loaded: form_helper
INFO - 2018-02-12 01:41:54 --> Database Driver Class Initialized
INFO - 2018-02-12 01:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 01:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:41:54 --> Form Validation Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Controller Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
DEBUG - 2018-02-12 01:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:41:54 --> Form Validation Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Controller Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
INFO - 2018-02-12 01:41:54 --> Model Class Initialized
DEBUG - 2018-02-12 01:41:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 01:41:54 --> Severity: Notice --> Undefined variable: estado_registro D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1212
ERROR - 2018-02-12 01:41:54 --> Query error: Column 'estado_registro' cannot be null - Invalid query: INSERT INTO `proyecto_colaborador` (`proyecto_id`, `colaborador_id`, `tipo_relacion`, `fecha_registro`, `estado_registro`) VALUES ('1', 6, 2, '2018-02-12 01:41:54', NULL)
INFO - 2018-02-12 01:41:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-12 01:42:18 --> Config Class Initialized
INFO - 2018-02-12 01:42:18 --> Hooks Class Initialized
INFO - 2018-02-12 01:42:18 --> Config Class Initialized
INFO - 2018-02-12 01:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:42:18 --> Utf8 Class Initialized
INFO - 2018-02-12 01:42:18 --> Utf8 Class Initialized
INFO - 2018-02-12 01:42:18 --> URI Class Initialized
INFO - 2018-02-12 01:42:18 --> URI Class Initialized
INFO - 2018-02-12 01:42:18 --> Router Class Initialized
INFO - 2018-02-12 01:42:18 --> Router Class Initialized
INFO - 2018-02-12 01:42:18 --> Output Class Initialized
INFO - 2018-02-12 01:42:18 --> Output Class Initialized
INFO - 2018-02-12 01:42:18 --> Security Class Initialized
INFO - 2018-02-12 01:42:18 --> Security Class Initialized
DEBUG - 2018-02-12 01:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:42:18 --> Input Class Initialized
DEBUG - 2018-02-12 01:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:42:18 --> Input Class Initialized
INFO - 2018-02-12 01:42:18 --> Language Class Initialized
INFO - 2018-02-12 01:42:18 --> Language Class Initialized
INFO - 2018-02-12 01:42:18 --> Loader Class Initialized
INFO - 2018-02-12 01:42:18 --> Loader Class Initialized
INFO - 2018-02-12 01:42:18 --> Helper loaded: url_helper
INFO - 2018-02-12 01:42:18 --> Helper loaded: url_helper
INFO - 2018-02-12 01:42:18 --> Helper loaded: form_helper
INFO - 2018-02-12 01:42:18 --> Helper loaded: form_helper
INFO - 2018-02-12 01:42:18 --> Database Driver Class Initialized
INFO - 2018-02-12 01:42:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 01:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:42:18 --> Form Validation Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Controller Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
DEBUG - 2018-02-12 01:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:42:18 --> Form Validation Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Controller Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
INFO - 2018-02-12 01:42:18 --> Model Class Initialized
DEBUG - 2018-02-12 01:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:43:34 --> Config Class Initialized
INFO - 2018-02-12 01:43:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:43:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:34 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:34 --> URI Class Initialized
INFO - 2018-02-12 01:43:34 --> Router Class Initialized
INFO - 2018-02-12 01:43:34 --> Output Class Initialized
INFO - 2018-02-12 01:43:34 --> Security Class Initialized
DEBUG - 2018-02-12 01:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:34 --> Input Class Initialized
INFO - 2018-02-12 01:43:34 --> Language Class Initialized
INFO - 2018-02-12 01:43:34 --> Loader Class Initialized
INFO - 2018-02-12 01:43:34 --> Helper loaded: url_helper
INFO - 2018-02-12 01:43:34 --> Helper loaded: form_helper
INFO - 2018-02-12 01:43:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:43:34 --> Form Validation Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
INFO - 2018-02-12 01:43:34 --> Controller Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
INFO - 2018-02-12 01:43:34 --> Model Class Initialized
DEBUG - 2018-02-12 01:43:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:43:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:43:34 --> Final output sent to browser
DEBUG - 2018-02-12 01:43:34 --> Total execution time: 0.0862
INFO - 2018-02-12 01:43:35 --> Config Class Initialized
INFO - 2018-02-12 01:43:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:43:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:35 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:35 --> URI Class Initialized
INFO - 2018-02-12 01:43:35 --> Router Class Initialized
INFO - 2018-02-12 01:43:35 --> Output Class Initialized
INFO - 2018-02-12 01:43:35 --> Security Class Initialized
DEBUG - 2018-02-12 01:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:35 --> Input Class Initialized
INFO - 2018-02-12 01:43:35 --> Language Class Initialized
INFO - 2018-02-12 01:43:35 --> Loader Class Initialized
INFO - 2018-02-12 01:43:35 --> Helper loaded: url_helper
INFO - 2018-02-12 01:43:35 --> Helper loaded: form_helper
INFO - 2018-02-12 01:43:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:43:35 --> Form Validation Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
INFO - 2018-02-12 01:43:35 --> Controller Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
INFO - 2018-02-12 01:43:35 --> Model Class Initialized
DEBUG - 2018-02-12 01:43:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Config Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
INFO - 2018-02-12 01:43:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:43:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Utf8 Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
INFO - 2018-02-12 01:43:36 --> URI Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Router Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
INFO - 2018-02-12 01:43:36 --> Output Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
INFO - 2018-02-12 01:43:36 --> Security Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
DEBUG - 2018-02-12 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:43:36 --> Input Class Initialized
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
INFO - 2018-02-12 01:43:36 --> Language Class Initialized
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:43:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
INFO - 2018-02-12 01:46:15 --> Loader Class Initialized
INFO - 2018-02-12 01:46:15 --> Helper loaded: url_helper
INFO - 2018-02-12 01:46:15 --> Helper loaded: form_helper
INFO - 2018-02-12 01:46:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:46:15 --> Form Validation Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
INFO - 2018-02-12 01:46:15 --> Controller Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
INFO - 2018-02-12 01:46:15 --> Model Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:46:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:46:15 --> Final output sent to browser
DEBUG - 2018-02-12 01:46:15 --> Total execution time: 0.0531
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> Config Class Initialized
INFO - 2018-02-12 01:46:15 --> Hooks Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
INFO - 2018-02-12 01:46:15 --> URI Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
INFO - 2018-02-12 01:46:15 --> Router Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
INFO - 2018-02-12 01:46:15 --> Output Class Initialized
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
INFO - 2018-02-12 01:46:15 --> Security Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
DEBUG - 2018-02-12 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:15 --> Input Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:46:15 --> Language Class Initialized
ERROR - 2018-02-12 01:46:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:46:16 --> Config Class Initialized
INFO - 2018-02-12 01:46:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:46:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:46:16 --> Utf8 Class Initialized
INFO - 2018-02-12 01:46:16 --> URI Class Initialized
INFO - 2018-02-12 01:46:16 --> Router Class Initialized
INFO - 2018-02-12 01:46:16 --> Output Class Initialized
INFO - 2018-02-12 01:46:16 --> Security Class Initialized
DEBUG - 2018-02-12 01:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:46:16 --> Input Class Initialized
INFO - 2018-02-12 01:46:16 --> Language Class Initialized
INFO - 2018-02-12 01:46:16 --> Loader Class Initialized
INFO - 2018-02-12 01:46:16 --> Helper loaded: url_helper
INFO - 2018-02-12 01:46:16 --> Helper loaded: form_helper
INFO - 2018-02-12 01:46:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:46:16 --> Form Validation Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
INFO - 2018-02-12 01:46:16 --> Controller Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
INFO - 2018-02-12 01:46:16 --> Model Class Initialized
DEBUG - 2018-02-12 01:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:53:39 --> Config Class Initialized
INFO - 2018-02-12 01:53:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:39 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:39 --> URI Class Initialized
INFO - 2018-02-12 01:53:39 --> Router Class Initialized
INFO - 2018-02-12 01:53:39 --> Output Class Initialized
INFO - 2018-02-12 01:53:39 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:39 --> Input Class Initialized
INFO - 2018-02-12 01:53:39 --> Language Class Initialized
INFO - 2018-02-12 01:53:39 --> Loader Class Initialized
INFO - 2018-02-12 01:53:39 --> Helper loaded: url_helper
INFO - 2018-02-12 01:53:39 --> Helper loaded: form_helper
INFO - 2018-02-12 01:53:39 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:53:39 --> Form Validation Class Initialized
INFO - 2018-02-12 01:53:39 --> Model Class Initialized
INFO - 2018-02-12 01:53:39 --> Controller Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:53:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:53:40 --> Final output sent to browser
DEBUG - 2018-02-12 01:53:40 --> Total execution time: 0.0557
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
ERROR - 2018-02-12 01:53:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:53:40 --> Config Class Initialized
INFO - 2018-02-12 01:53:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:40 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:40 --> URI Class Initialized
INFO - 2018-02-12 01:53:40 --> Router Class Initialized
INFO - 2018-02-12 01:53:40 --> Output Class Initialized
INFO - 2018-02-12 01:53:40 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:40 --> Input Class Initialized
INFO - 2018-02-12 01:53:40 --> Language Class Initialized
INFO - 2018-02-12 01:53:40 --> Loader Class Initialized
INFO - 2018-02-12 01:53:40 --> Helper loaded: url_helper
INFO - 2018-02-12 01:53:40 --> Helper loaded: form_helper
INFO - 2018-02-12 01:53:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:53:40 --> Form Validation Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Controller Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
INFO - 2018-02-12 01:53:40 --> Model Class Initialized
DEBUG - 2018-02-12 01:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:53:46 --> Config Class Initialized
INFO - 2018-02-12 01:53:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:46 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:46 --> URI Class Initialized
INFO - 2018-02-12 01:53:46 --> Router Class Initialized
INFO - 2018-02-12 01:53:46 --> Output Class Initialized
INFO - 2018-02-12 01:53:46 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:46 --> Input Class Initialized
INFO - 2018-02-12 01:53:46 --> Language Class Initialized
INFO - 2018-02-12 01:53:46 --> Loader Class Initialized
INFO - 2018-02-12 01:53:46 --> Helper loaded: url_helper
INFO - 2018-02-12 01:53:46 --> Helper loaded: form_helper
INFO - 2018-02-12 01:53:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:53:46 --> Form Validation Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
INFO - 2018-02-12 01:53:46 --> Controller Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
INFO - 2018-02-12 01:53:46 --> Model Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:53:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:53:46 --> Final output sent to browser
DEBUG - 2018-02-12 01:53:46 --> Total execution time: 0.0878
INFO - 2018-02-12 01:53:46 --> Config Class Initialized
INFO - 2018-02-12 01:53:46 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:46 --> Config Class Initialized
INFO - 2018-02-12 01:53:46 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:46 --> Config Class Initialized
DEBUG - 2018-02-12 01:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:46 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:46 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:46 --> URI Class Initialized
INFO - 2018-02-12 01:53:46 --> URI Class Initialized
DEBUG - 2018-02-12 01:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:46 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:46 --> Router Class Initialized
INFO - 2018-02-12 01:53:46 --> Router Class Initialized
INFO - 2018-02-12 01:53:46 --> URI Class Initialized
INFO - 2018-02-12 01:53:46 --> Output Class Initialized
INFO - 2018-02-12 01:53:46 --> Output Class Initialized
INFO - 2018-02-12 01:53:46 --> Router Class Initialized
INFO - 2018-02-12 01:53:46 --> Security Class Initialized
INFO - 2018-02-12 01:53:46 --> Security Class Initialized
INFO - 2018-02-12 01:53:46 --> Output Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:46 --> Input Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:46 --> Security Class Initialized
INFO - 2018-02-12 01:53:46 --> Input Class Initialized
INFO - 2018-02-12 01:53:46 --> Language Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:46 --> Language Class Initialized
INFO - 2018-02-12 01:53:46 --> Input Class Initialized
ERROR - 2018-02-12 01:53:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:53:46 --> Language Class Initialized
ERROR - 2018-02-12 01:53:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:53:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:53:46 --> Config Class Initialized
INFO - 2018-02-12 01:53:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:46 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:46 --> URI Class Initialized
INFO - 2018-02-12 01:53:46 --> Router Class Initialized
INFO - 2018-02-12 01:53:46 --> Output Class Initialized
INFO - 2018-02-12 01:53:46 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:46 --> Input Class Initialized
INFO - 2018-02-12 01:53:46 --> Language Class Initialized
ERROR - 2018-02-12 01:53:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:53:47 --> Config Class Initialized
INFO - 2018-02-12 01:53:47 --> Config Class Initialized
INFO - 2018-02-12 01:53:47 --> Config Class Initialized
INFO - 2018-02-12 01:53:47 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:47 --> Hooks Class Initialized
INFO - 2018-02-12 01:53:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:53:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:53:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:47 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:47 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:47 --> URI Class Initialized
INFO - 2018-02-12 01:53:47 --> URI Class Initialized
INFO - 2018-02-12 01:53:47 --> URI Class Initialized
INFO - 2018-02-12 01:53:47 --> Router Class Initialized
INFO - 2018-02-12 01:53:47 --> Router Class Initialized
INFO - 2018-02-12 01:53:47 --> Router Class Initialized
INFO - 2018-02-12 01:53:47 --> Output Class Initialized
INFO - 2018-02-12 01:53:47 --> Output Class Initialized
INFO - 2018-02-12 01:53:47 --> Output Class Initialized
INFO - 2018-02-12 01:53:47 --> Security Class Initialized
INFO - 2018-02-12 01:53:47 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:47 --> Security Class Initialized
INFO - 2018-02-12 01:53:47 --> Input Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:47 --> Input Class Initialized
INFO - 2018-02-12 01:53:47 --> Language Class Initialized
INFO - 2018-02-12 01:53:47 --> Language Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:47 --> Input Class Initialized
ERROR - 2018-02-12 01:53:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:53:47 --> Language Class Initialized
ERROR - 2018-02-12 01:53:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:53:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:53:47 --> Config Class Initialized
INFO - 2018-02-12 01:53:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:53:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:53:47 --> Utf8 Class Initialized
INFO - 2018-02-12 01:53:47 --> URI Class Initialized
INFO - 2018-02-12 01:53:47 --> Router Class Initialized
INFO - 2018-02-12 01:53:47 --> Output Class Initialized
INFO - 2018-02-12 01:53:47 --> Security Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:53:47 --> Input Class Initialized
INFO - 2018-02-12 01:53:47 --> Language Class Initialized
INFO - 2018-02-12 01:53:47 --> Loader Class Initialized
INFO - 2018-02-12 01:53:47 --> Helper loaded: url_helper
INFO - 2018-02-12 01:53:47 --> Helper loaded: form_helper
INFO - 2018-02-12 01:53:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:53:47 --> Form Validation Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
INFO - 2018-02-12 01:53:47 --> Controller Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
INFO - 2018-02-12 01:53:47 --> Model Class Initialized
DEBUG - 2018-02-12 01:53:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
INFO - 2018-02-12 01:57:42 --> Loader Class Initialized
INFO - 2018-02-12 01:57:42 --> Helper loaded: url_helper
INFO - 2018-02-12 01:57:42 --> Helper loaded: form_helper
INFO - 2018-02-12 01:57:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:57:42 --> Form Validation Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Controller Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:57:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:57:42 --> Final output sent to browser
DEBUG - 2018-02-12 01:57:42 --> Total execution time: 0.0966
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:57:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:57:42 --> Config Class Initialized
INFO - 2018-02-12 01:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:57:42 --> Utf8 Class Initialized
INFO - 2018-02-12 01:57:42 --> URI Class Initialized
INFO - 2018-02-12 01:57:42 --> Router Class Initialized
INFO - 2018-02-12 01:57:42 --> Output Class Initialized
INFO - 2018-02-12 01:57:42 --> Security Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:57:42 --> Input Class Initialized
INFO - 2018-02-12 01:57:42 --> Language Class Initialized
INFO - 2018-02-12 01:57:42 --> Loader Class Initialized
INFO - 2018-02-12 01:57:42 --> Helper loaded: url_helper
INFO - 2018-02-12 01:57:42 --> Helper loaded: form_helper
INFO - 2018-02-12 01:57:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:57:42 --> Form Validation Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Controller Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
INFO - 2018-02-12 01:57:42 --> Model Class Initialized
DEBUG - 2018-02-12 01:57:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 01:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 623
ERROR - 2018-02-12 01:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 623
ERROR - 2018-02-12 01:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 623
ERROR - 2018-02-12 01:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 623
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
INFO - 2018-02-12 01:58:24 --> Loader Class Initialized
INFO - 2018-02-12 01:58:24 --> Helper loaded: url_helper
INFO - 2018-02-12 01:58:24 --> Helper loaded: form_helper
INFO - 2018-02-12 01:58:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:58:24 --> Form Validation Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Controller Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:58:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:58:24 --> Final output sent to browser
DEBUG - 2018-02-12 01:58:24 --> Total execution time: 0.0839
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
ERROR - 2018-02-12 01:58:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:58:24 --> Config Class Initialized
INFO - 2018-02-12 01:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:24 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:24 --> URI Class Initialized
INFO - 2018-02-12 01:58:24 --> Router Class Initialized
INFO - 2018-02-12 01:58:24 --> Output Class Initialized
INFO - 2018-02-12 01:58:24 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:24 --> Input Class Initialized
INFO - 2018-02-12 01:58:24 --> Language Class Initialized
INFO - 2018-02-12 01:58:24 --> Loader Class Initialized
INFO - 2018-02-12 01:58:24 --> Helper loaded: url_helper
INFO - 2018-02-12 01:58:24 --> Helper loaded: form_helper
INFO - 2018-02-12 01:58:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:58:24 --> Form Validation Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Controller Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
INFO - 2018-02-12 01:58:24 --> Model Class Initialized
DEBUG - 2018-02-12 01:58:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Loader Class Initialized
INFO - 2018-02-12 01:58:56 --> Helper loaded: url_helper
INFO - 2018-02-12 01:58:56 --> Helper loaded: form_helper
INFO - 2018-02-12 01:58:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:58:56 --> Form Validation Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Controller Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:58:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:58:56 --> Final output sent to browser
DEBUG - 2018-02-12 01:58:56 --> Total execution time: 0.0862
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:58:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:58:56 --> Config Class Initialized
INFO - 2018-02-12 01:58:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:58:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:58:56 --> Utf8 Class Initialized
INFO - 2018-02-12 01:58:56 --> URI Class Initialized
INFO - 2018-02-12 01:58:56 --> Router Class Initialized
INFO - 2018-02-12 01:58:56 --> Output Class Initialized
INFO - 2018-02-12 01:58:56 --> Security Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:58:56 --> Input Class Initialized
INFO - 2018-02-12 01:58:56 --> Language Class Initialized
INFO - 2018-02-12 01:58:56 --> Loader Class Initialized
INFO - 2018-02-12 01:58:56 --> Helper loaded: url_helper
INFO - 2018-02-12 01:58:56 --> Helper loaded: form_helper
INFO - 2018-02-12 01:58:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:58:56 --> Form Validation Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Controller Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
INFO - 2018-02-12 01:58:56 --> Model Class Initialized
DEBUG - 2018-02-12 01:58:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
INFO - 2018-02-12 01:59:37 --> Loader Class Initialized
INFO - 2018-02-12 01:59:37 --> Helper loaded: url_helper
INFO - 2018-02-12 01:59:37 --> Helper loaded: form_helper
INFO - 2018-02-12 01:59:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:59:37 --> Form Validation Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Controller Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 01:59:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 01:59:37 --> Final output sent to browser
DEBUG - 2018-02-12 01:59:37 --> Total execution time: 0.1395
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 01:59:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 01:59:37 --> Config Class Initialized
INFO - 2018-02-12 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 01:59:37 --> Utf8 Class Initialized
INFO - 2018-02-12 01:59:37 --> URI Class Initialized
INFO - 2018-02-12 01:59:37 --> Router Class Initialized
INFO - 2018-02-12 01:59:37 --> Output Class Initialized
INFO - 2018-02-12 01:59:37 --> Security Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 01:59:37 --> Input Class Initialized
INFO - 2018-02-12 01:59:37 --> Language Class Initialized
INFO - 2018-02-12 01:59:37 --> Loader Class Initialized
INFO - 2018-02-12 01:59:37 --> Helper loaded: url_helper
INFO - 2018-02-12 01:59:37 --> Helper loaded: form_helper
INFO - 2018-02-12 01:59:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 01:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 01:59:37 --> Form Validation Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Controller Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
INFO - 2018-02-12 01:59:37 --> Model Class Initialized
DEBUG - 2018-02-12 01:59:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:00:46 --> Config Class Initialized
INFO - 2018-02-12 02:00:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:46 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:46 --> URI Class Initialized
INFO - 2018-02-12 02:00:46 --> Router Class Initialized
INFO - 2018-02-12 02:00:46 --> Output Class Initialized
INFO - 2018-02-12 02:00:46 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:46 --> Input Class Initialized
INFO - 2018-02-12 02:00:46 --> Language Class Initialized
INFO - 2018-02-12 02:00:46 --> Loader Class Initialized
INFO - 2018-02-12 02:00:46 --> Helper loaded: url_helper
INFO - 2018-02-12 02:00:46 --> Helper loaded: form_helper
INFO - 2018-02-12 02:00:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:00:46 --> Form Validation Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
INFO - 2018-02-12 02:00:46 --> Controller Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
INFO - 2018-02-12 02:00:46 --> Model Class Initialized
DEBUG - 2018-02-12 02:00:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:00:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:00:46 --> Final output sent to browser
DEBUG - 2018-02-12 02:00:46 --> Total execution time: 0.0543
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:00:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:00:47 --> Config Class Initialized
INFO - 2018-02-12 02:00:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:47 --> URI Class Initialized
INFO - 2018-02-12 02:00:47 --> Router Class Initialized
INFO - 2018-02-12 02:00:47 --> Output Class Initialized
INFO - 2018-02-12 02:00:47 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:47 --> Input Class Initialized
INFO - 2018-02-12 02:00:47 --> Language Class Initialized
INFO - 2018-02-12 02:00:47 --> Loader Class Initialized
INFO - 2018-02-12 02:00:47 --> Helper loaded: url_helper
INFO - 2018-02-12 02:00:47 --> Helper loaded: form_helper
INFO - 2018-02-12 02:00:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:00:47 --> Form Validation Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
INFO - 2018-02-12 02:00:47 --> Controller Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
INFO - 2018-02-12 02:00:47 --> Model Class Initialized
DEBUG - 2018-02-12 02:00:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:00:57 --> Config Class Initialized
INFO - 2018-02-12 02:00:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:57 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:57 --> URI Class Initialized
INFO - 2018-02-12 02:00:57 --> Router Class Initialized
INFO - 2018-02-12 02:00:57 --> Output Class Initialized
INFO - 2018-02-12 02:00:57 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:57 --> Input Class Initialized
INFO - 2018-02-12 02:00:57 --> Language Class Initialized
INFO - 2018-02-12 02:00:57 --> Loader Class Initialized
INFO - 2018-02-12 02:00:57 --> Helper loaded: url_helper
INFO - 2018-02-12 02:00:57 --> Helper loaded: form_helper
INFO - 2018-02-12 02:00:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:00:57 --> Form Validation Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
INFO - 2018-02-12 02:00:57 --> Controller Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
INFO - 2018-02-12 02:00:57 --> Model Class Initialized
DEBUG - 2018-02-12 02:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:00:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:00:58 --> Final output sent to browser
DEBUG - 2018-02-12 02:00:58 --> Total execution time: 0.0679
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:00:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:00:58 --> Config Class Initialized
INFO - 2018-02-12 02:00:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:00:58 --> URI Class Initialized
INFO - 2018-02-12 02:00:58 --> Router Class Initialized
INFO - 2018-02-12 02:00:58 --> Output Class Initialized
INFO - 2018-02-12 02:00:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:00:58 --> Input Class Initialized
INFO - 2018-02-12 02:00:58 --> Language Class Initialized
INFO - 2018-02-12 02:00:58 --> Loader Class Initialized
INFO - 2018-02-12 02:00:58 --> Helper loaded: url_helper
INFO - 2018-02-12 02:00:58 --> Helper loaded: form_helper
INFO - 2018-02-12 02:00:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:00:58 --> Form Validation Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
INFO - 2018-02-12 02:00:58 --> Controller Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
INFO - 2018-02-12 02:00:58 --> Model Class Initialized
DEBUG - 2018-02-12 02:00:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:01:37 --> Config Class Initialized
INFO - 2018-02-12 02:01:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:01:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:01:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:01:37 --> URI Class Initialized
INFO - 2018-02-12 02:01:37 --> Router Class Initialized
INFO - 2018-02-12 02:01:37 --> Output Class Initialized
INFO - 2018-02-12 02:01:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:01:37 --> Input Class Initialized
INFO - 2018-02-12 02:01:37 --> Language Class Initialized
INFO - 2018-02-12 02:01:37 --> Loader Class Initialized
INFO - 2018-02-12 02:01:37 --> Helper loaded: url_helper
INFO - 2018-02-12 02:01:37 --> Helper loaded: form_helper
INFO - 2018-02-12 02:01:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:01:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Controller Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:01:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:01:37 --> Final output sent to browser
DEBUG - 2018-02-12 02:01:37 --> Total execution time: 0.0649
INFO - 2018-02-12 02:01:37 --> Config Class Initialized
INFO - 2018-02-12 02:01:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:01:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:01:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:01:37 --> URI Class Initialized
INFO - 2018-02-12 02:01:37 --> Router Class Initialized
INFO - 2018-02-12 02:01:37 --> Output Class Initialized
INFO - 2018-02-12 02:01:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:01:37 --> Input Class Initialized
INFO - 2018-02-12 02:01:37 --> Language Class Initialized
INFO - 2018-02-12 02:01:37 --> Loader Class Initialized
INFO - 2018-02-12 02:01:37 --> Helper loaded: url_helper
INFO - 2018-02-12 02:01:37 --> Helper loaded: form_helper
INFO - 2018-02-12 02:01:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:01:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Controller Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
INFO - 2018-02-12 02:01:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:02:37 --> Config Class Initialized
INFO - 2018-02-12 02:02:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:02:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:02:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:02:37 --> URI Class Initialized
INFO - 2018-02-12 02:02:37 --> Router Class Initialized
INFO - 2018-02-12 02:02:37 --> Output Class Initialized
INFO - 2018-02-12 02:02:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:02:37 --> Input Class Initialized
INFO - 2018-02-12 02:02:37 --> Language Class Initialized
INFO - 2018-02-12 02:02:37 --> Loader Class Initialized
INFO - 2018-02-12 02:02:37 --> Helper loaded: url_helper
INFO - 2018-02-12 02:02:37 --> Helper loaded: form_helper
INFO - 2018-02-12 02:02:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:02:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:02:37 --> Model Class Initialized
INFO - 2018-02-12 02:02:37 --> Controller Class Initialized
INFO - 2018-02-12 02:02:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:02:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:02:37 --> Final output sent to browser
DEBUG - 2018-02-12 02:02:37 --> Total execution time: 0.0889
INFO - 2018-02-12 02:02:37 --> Config Class Initialized
INFO - 2018-02-12 02:02:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:02:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:02:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:02:37 --> URI Class Initialized
INFO - 2018-02-12 02:02:37 --> Router Class Initialized
INFO - 2018-02-12 02:02:37 --> Output Class Initialized
INFO - 2018-02-12 02:02:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:02:37 --> Input Class Initialized
INFO - 2018-02-12 02:02:37 --> Language Class Initialized
INFO - 2018-02-12 02:02:37 --> Loader Class Initialized
INFO - 2018-02-12 02:02:37 --> Helper loaded: url_helper
INFO - 2018-02-12 02:02:37 --> Helper loaded: form_helper
INFO - 2018-02-12 02:02:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:02:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:02:37 --> Model Class Initialized
INFO - 2018-02-12 02:02:37 --> Controller Class Initialized
INFO - 2018-02-12 02:02:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:02:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:02:38 --> Config Class Initialized
INFO - 2018-02-12 02:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:02:38 --> Utf8 Class Initialized
INFO - 2018-02-12 02:02:38 --> URI Class Initialized
INFO - 2018-02-12 02:02:38 --> Router Class Initialized
INFO - 2018-02-12 02:02:38 --> Output Class Initialized
INFO - 2018-02-12 02:02:38 --> Security Class Initialized
DEBUG - 2018-02-12 02:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:02:38 --> Input Class Initialized
INFO - 2018-02-12 02:02:38 --> Language Class Initialized
INFO - 2018-02-12 02:02:38 --> Loader Class Initialized
INFO - 2018-02-12 02:02:38 --> Helper loaded: url_helper
INFO - 2018-02-12 02:02:38 --> Helper loaded: form_helper
INFO - 2018-02-12 02:02:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:02:38 --> Form Validation Class Initialized
INFO - 2018-02-12 02:02:38 --> Model Class Initialized
INFO - 2018-02-12 02:02:38 --> Controller Class Initialized
INFO - 2018-02-12 02:02:38 --> Model Class Initialized
DEBUG - 2018-02-12 02:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:02:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:02:38 --> Final output sent to browser
DEBUG - 2018-02-12 02:02:38 --> Total execution time: 0.1543
INFO - 2018-02-12 02:03:30 --> Config Class Initialized
INFO - 2018-02-12 02:03:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:03:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:03:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:03:30 --> URI Class Initialized
INFO - 2018-02-12 02:03:30 --> Router Class Initialized
INFO - 2018-02-12 02:03:30 --> Output Class Initialized
INFO - 2018-02-12 02:03:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:03:30 --> Input Class Initialized
INFO - 2018-02-12 02:03:30 --> Language Class Initialized
INFO - 2018-02-12 02:03:30 --> Loader Class Initialized
INFO - 2018-02-12 02:03:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:03:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:03:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:03:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:03:30 --> Model Class Initialized
INFO - 2018-02-12 02:03:30 --> Controller Class Initialized
INFO - 2018-02-12 02:03:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:03:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:03:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:03:30 --> Total execution time: 0.4236
INFO - 2018-02-12 02:03:32 --> Config Class Initialized
INFO - 2018-02-12 02:03:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:03:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:03:32 --> Utf8 Class Initialized
INFO - 2018-02-12 02:03:32 --> URI Class Initialized
INFO - 2018-02-12 02:03:32 --> Router Class Initialized
INFO - 2018-02-12 02:03:32 --> Output Class Initialized
INFO - 2018-02-12 02:03:32 --> Security Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:03:32 --> Input Class Initialized
INFO - 2018-02-12 02:03:32 --> Language Class Initialized
INFO - 2018-02-12 02:03:32 --> Loader Class Initialized
INFO - 2018-02-12 02:03:32 --> Helper loaded: url_helper
INFO - 2018-02-12 02:03:32 --> Helper loaded: form_helper
INFO - 2018-02-12 02:03:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:03:32 --> Form Validation Class Initialized
INFO - 2018-02-12 02:03:32 --> Model Class Initialized
INFO - 2018-02-12 02:03:32 --> Controller Class Initialized
INFO - 2018-02-12 02:03:32 --> Model Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:03:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:03:32 --> Final output sent to browser
DEBUG - 2018-02-12 02:03:32 --> Total execution time: 0.0836
INFO - 2018-02-12 02:03:32 --> Config Class Initialized
INFO - 2018-02-12 02:03:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:03:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:03:32 --> Utf8 Class Initialized
INFO - 2018-02-12 02:03:32 --> URI Class Initialized
INFO - 2018-02-12 02:03:32 --> Router Class Initialized
INFO - 2018-02-12 02:03:32 --> Output Class Initialized
INFO - 2018-02-12 02:03:32 --> Security Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:03:32 --> Input Class Initialized
INFO - 2018-02-12 02:03:32 --> Language Class Initialized
INFO - 2018-02-12 02:03:32 --> Loader Class Initialized
INFO - 2018-02-12 02:03:32 --> Helper loaded: url_helper
INFO - 2018-02-12 02:03:32 --> Helper loaded: form_helper
INFO - 2018-02-12 02:03:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:03:32 --> Form Validation Class Initialized
INFO - 2018-02-12 02:03:32 --> Model Class Initialized
INFO - 2018-02-12 02:03:32 --> Controller Class Initialized
INFO - 2018-02-12 02:03:32 --> Model Class Initialized
DEBUG - 2018-02-12 02:03:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:03:40 --> Config Class Initialized
INFO - 2018-02-12 02:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:03:40 --> Utf8 Class Initialized
INFO - 2018-02-12 02:03:40 --> URI Class Initialized
INFO - 2018-02-12 02:03:40 --> Router Class Initialized
INFO - 2018-02-12 02:03:40 --> Output Class Initialized
INFO - 2018-02-12 02:03:40 --> Security Class Initialized
DEBUG - 2018-02-12 02:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:03:40 --> Input Class Initialized
INFO - 2018-02-12 02:03:40 --> Language Class Initialized
INFO - 2018-02-12 02:03:40 --> Loader Class Initialized
INFO - 2018-02-12 02:03:40 --> Helper loaded: url_helper
INFO - 2018-02-12 02:03:40 --> Helper loaded: form_helper
INFO - 2018-02-12 02:03:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:03:40 --> Form Validation Class Initialized
INFO - 2018-02-12 02:03:40 --> Model Class Initialized
INFO - 2018-02-12 02:03:40 --> Controller Class Initialized
INFO - 2018-02-12 02:03:40 --> Model Class Initialized
DEBUG - 2018-02-12 02:03:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:03:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:03:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:03:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:03:40 --> Final output sent to browser
DEBUG - 2018-02-12 02:03:40 --> Total execution time: 0.1252
INFO - 2018-02-12 02:03:45 --> Config Class Initialized
INFO - 2018-02-12 02:03:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:03:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:03:45 --> Utf8 Class Initialized
INFO - 2018-02-12 02:03:45 --> URI Class Initialized
INFO - 2018-02-12 02:03:45 --> Router Class Initialized
INFO - 2018-02-12 02:03:45 --> Output Class Initialized
INFO - 2018-02-12 02:03:45 --> Security Class Initialized
DEBUG - 2018-02-12 02:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:03:45 --> Input Class Initialized
INFO - 2018-02-12 02:03:45 --> Language Class Initialized
INFO - 2018-02-12 02:03:45 --> Loader Class Initialized
INFO - 2018-02-12 02:03:45 --> Helper loaded: url_helper
INFO - 2018-02-12 02:03:45 --> Helper loaded: form_helper
INFO - 2018-02-12 02:03:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:03:45 --> Form Validation Class Initialized
INFO - 2018-02-12 02:03:45 --> Model Class Initialized
INFO - 2018-02-12 02:03:45 --> Controller Class Initialized
INFO - 2018-02-12 02:03:45 --> Model Class Initialized
DEBUG - 2018-02-12 02:03:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:03:45 --> Severity: Warning --> Missing argument 2 for M_Colaborador::actualizar(), called in D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Colaborador.php on line 91 and defined D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 215
ERROR - 2018-02-12 02:03:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 217
ERROR - 2018-02-12 02:03:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 218
ERROR - 2018-02-12 02:03:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 219
ERROR - 2018-02-12 02:03:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 220
ERROR - 2018-02-12 02:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 220
ERROR - 2018-02-12 02:03:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
INFO - 2018-02-12 02:03:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-12 02:03:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Common.php 570
INFO - 2018-02-12 02:04:41 --> Config Class Initialized
INFO - 2018-02-12 02:04:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:04:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:04:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:04:41 --> URI Class Initialized
INFO - 2018-02-12 02:04:41 --> Router Class Initialized
INFO - 2018-02-12 02:04:41 --> Output Class Initialized
INFO - 2018-02-12 02:04:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:04:41 --> Input Class Initialized
INFO - 2018-02-12 02:04:41 --> Language Class Initialized
INFO - 2018-02-12 02:04:41 --> Loader Class Initialized
INFO - 2018-02-12 02:04:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:04:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:04:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:04:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:04:41 --> Model Class Initialized
INFO - 2018-02-12 02:04:41 --> Controller Class Initialized
INFO - 2018-02-12 02:04:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:04:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:04:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:04:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:04:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:04:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:04:41 --> Total execution time: 0.0701
INFO - 2018-02-12 02:04:45 --> Config Class Initialized
INFO - 2018-02-12 02:04:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:04:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:04:45 --> Utf8 Class Initialized
INFO - 2018-02-12 02:04:45 --> URI Class Initialized
INFO - 2018-02-12 02:04:45 --> Router Class Initialized
INFO - 2018-02-12 02:04:45 --> Output Class Initialized
INFO - 2018-02-12 02:04:45 --> Security Class Initialized
DEBUG - 2018-02-12 02:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:04:45 --> Input Class Initialized
INFO - 2018-02-12 02:04:45 --> Language Class Initialized
INFO - 2018-02-12 02:04:45 --> Loader Class Initialized
INFO - 2018-02-12 02:04:45 --> Helper loaded: url_helper
INFO - 2018-02-12 02:04:45 --> Helper loaded: form_helper
INFO - 2018-02-12 02:04:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:04:45 --> Form Validation Class Initialized
INFO - 2018-02-12 02:04:45 --> Model Class Initialized
INFO - 2018-02-12 02:04:45 --> Controller Class Initialized
INFO - 2018-02-12 02:04:45 --> Model Class Initialized
DEBUG - 2018-02-12 02:04:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:04:45 --> Severity: Warning --> Missing argument 2 for M_Colaborador::actualizar(), called in D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Colaborador.php on line 91 and defined D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 215
ERROR - 2018-02-12 02:04:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 217
ERROR - 2018-02-12 02:04:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 218
ERROR - 2018-02-12 02:04:45 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 219
ERROR - 2018-02-12 02:04:46 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 220
ERROR - 2018-02-12 02:04:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 220
ERROR - 2018-02-12 02:04:46 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
INFO - 2018-02-12 02:04:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-12 02:04:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Common.php 570
INFO - 2018-02-12 02:05:59 --> Config Class Initialized
INFO - 2018-02-12 02:05:59 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:05:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:05:59 --> Utf8 Class Initialized
INFO - 2018-02-12 02:05:59 --> URI Class Initialized
INFO - 2018-02-12 02:05:59 --> Router Class Initialized
INFO - 2018-02-12 02:05:59 --> Output Class Initialized
INFO - 2018-02-12 02:05:59 --> Security Class Initialized
DEBUG - 2018-02-12 02:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:05:59 --> Input Class Initialized
INFO - 2018-02-12 02:05:59 --> Language Class Initialized
INFO - 2018-02-12 02:05:59 --> Loader Class Initialized
INFO - 2018-02-12 02:05:59 --> Helper loaded: url_helper
INFO - 2018-02-12 02:05:59 --> Helper loaded: form_helper
INFO - 2018-02-12 02:05:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:05:59 --> Form Validation Class Initialized
INFO - 2018-02-12 02:05:59 --> Model Class Initialized
INFO - 2018-02-12 02:05:59 --> Controller Class Initialized
INFO - 2018-02-12 02:05:59 --> Model Class Initialized
DEBUG - 2018-02-12 02:05:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:05:59 --> Severity: Notice --> Undefined property: Colaborador::$m_bitacora D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-12 02:05:59 --> Severity: Error --> Call to a member function registrarEdicionBicatora() on null D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 260
INFO - 2018-02-12 02:07:35 --> Config Class Initialized
INFO - 2018-02-12 02:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:35 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:35 --> URI Class Initialized
INFO - 2018-02-12 02:07:35 --> Router Class Initialized
INFO - 2018-02-12 02:07:35 --> Output Class Initialized
INFO - 2018-02-12 02:07:35 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:35 --> Input Class Initialized
INFO - 2018-02-12 02:07:35 --> Language Class Initialized
INFO - 2018-02-12 02:07:35 --> Loader Class Initialized
INFO - 2018-02-12 02:07:35 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:35 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:35 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:35 --> Model Class Initialized
INFO - 2018-02-12 02:07:35 --> Controller Class Initialized
INFO - 2018-02-12 02:07:35 --> Model Class Initialized
INFO - 2018-02-12 02:07:35 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:07:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:07:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:07:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:07:35 --> Final output sent to browser
DEBUG - 2018-02-12 02:07:35 --> Total execution time: 0.2433
INFO - 2018-02-12 02:07:40 --> Config Class Initialized
INFO - 2018-02-12 02:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:40 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:40 --> URI Class Initialized
INFO - 2018-02-12 02:07:40 --> Router Class Initialized
INFO - 2018-02-12 02:07:40 --> Output Class Initialized
INFO - 2018-02-12 02:07:40 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:40 --> Input Class Initialized
INFO - 2018-02-12 02:07:40 --> Language Class Initialized
INFO - 2018-02-12 02:07:40 --> Loader Class Initialized
INFO - 2018-02-12 02:07:40 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:40 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:40 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:40 --> Model Class Initialized
INFO - 2018-02-12 02:07:40 --> Controller Class Initialized
INFO - 2018-02-12 02:07:40 --> Model Class Initialized
INFO - 2018-02-12 02:07:40 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:07:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:07:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:07:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:07:40 --> Final output sent to browser
DEBUG - 2018-02-12 02:07:40 --> Total execution time: 0.1784
INFO - 2018-02-12 02:07:47 --> Config Class Initialized
INFO - 2018-02-12 02:07:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:47 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:47 --> URI Class Initialized
INFO - 2018-02-12 02:07:47 --> Router Class Initialized
INFO - 2018-02-12 02:07:47 --> Output Class Initialized
INFO - 2018-02-12 02:07:47 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:47 --> Input Class Initialized
INFO - 2018-02-12 02:07:47 --> Language Class Initialized
INFO - 2018-02-12 02:07:47 --> Loader Class Initialized
INFO - 2018-02-12 02:07:47 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:47 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:47 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:47 --> Model Class Initialized
INFO - 2018-02-12 02:07:47 --> Controller Class Initialized
INFO - 2018-02-12 02:07:47 --> Model Class Initialized
INFO - 2018-02-12 02:07:47 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:07:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:07:47 --> Final output sent to browser
DEBUG - 2018-02-12 02:07:47 --> Total execution time: 0.0820
INFO - 2018-02-12 02:07:48 --> Config Class Initialized
INFO - 2018-02-12 02:07:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:48 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:48 --> URI Class Initialized
INFO - 2018-02-12 02:07:48 --> Router Class Initialized
INFO - 2018-02-12 02:07:48 --> Output Class Initialized
INFO - 2018-02-12 02:07:48 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:48 --> Input Class Initialized
INFO - 2018-02-12 02:07:48 --> Language Class Initialized
INFO - 2018-02-12 02:07:48 --> Loader Class Initialized
INFO - 2018-02-12 02:07:48 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:48 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:48 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:48 --> Model Class Initialized
INFO - 2018-02-12 02:07:48 --> Controller Class Initialized
INFO - 2018-02-12 02:07:48 --> Model Class Initialized
INFO - 2018-02-12 02:07:48 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:07:52 --> Config Class Initialized
INFO - 2018-02-12 02:07:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:52 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:52 --> URI Class Initialized
INFO - 2018-02-12 02:07:52 --> Router Class Initialized
INFO - 2018-02-12 02:07:52 --> Output Class Initialized
INFO - 2018-02-12 02:07:52 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:52 --> Input Class Initialized
INFO - 2018-02-12 02:07:52 --> Language Class Initialized
INFO - 2018-02-12 02:07:52 --> Loader Class Initialized
INFO - 2018-02-12 02:07:53 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:53 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:53 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
INFO - 2018-02-12 02:07:53 --> Controller Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:07:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:07:53 --> Final output sent to browser
DEBUG - 2018-02-12 02:07:53 --> Total execution time: 0.0674
INFO - 2018-02-12 02:07:53 --> Config Class Initialized
INFO - 2018-02-12 02:07:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:53 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:53 --> URI Class Initialized
INFO - 2018-02-12 02:07:53 --> Router Class Initialized
INFO - 2018-02-12 02:07:53 --> Output Class Initialized
INFO - 2018-02-12 02:07:53 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:53 --> Input Class Initialized
INFO - 2018-02-12 02:07:53 --> Language Class Initialized
INFO - 2018-02-12 02:07:53 --> Loader Class Initialized
INFO - 2018-02-12 02:07:53 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:53 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:53 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
INFO - 2018-02-12 02:07:53 --> Controller Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
INFO - 2018-02-12 02:07:53 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:07:57 --> Config Class Initialized
INFO - 2018-02-12 02:07:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:57 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:57 --> URI Class Initialized
INFO - 2018-02-12 02:07:57 --> Router Class Initialized
INFO - 2018-02-12 02:07:57 --> Output Class Initialized
INFO - 2018-02-12 02:07:57 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:57 --> Input Class Initialized
INFO - 2018-02-12 02:07:57 --> Language Class Initialized
INFO - 2018-02-12 02:07:57 --> Loader Class Initialized
INFO - 2018-02-12 02:07:57 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:57 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:57 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:57 --> Model Class Initialized
INFO - 2018-02-12 02:07:57 --> Controller Class Initialized
INFO - 2018-02-12 02:07:57 --> Model Class Initialized
INFO - 2018-02-12 02:07:57 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:07:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:07:57 --> Final output sent to browser
DEBUG - 2018-02-12 02:07:57 --> Total execution time: 0.0750
INFO - 2018-02-12 02:07:58 --> Config Class Initialized
INFO - 2018-02-12 02:07:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:07:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:07:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:07:58 --> URI Class Initialized
INFO - 2018-02-12 02:07:58 --> Router Class Initialized
INFO - 2018-02-12 02:07:58 --> Output Class Initialized
INFO - 2018-02-12 02:07:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:07:58 --> Input Class Initialized
INFO - 2018-02-12 02:07:58 --> Language Class Initialized
INFO - 2018-02-12 02:07:58 --> Loader Class Initialized
INFO - 2018-02-12 02:07:58 --> Helper loaded: url_helper
INFO - 2018-02-12 02:07:58 --> Helper loaded: form_helper
INFO - 2018-02-12 02:07:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:07:58 --> Form Validation Class Initialized
INFO - 2018-02-12 02:07:58 --> Model Class Initialized
INFO - 2018-02-12 02:07:58 --> Controller Class Initialized
INFO - 2018-02-12 02:07:58 --> Model Class Initialized
INFO - 2018-02-12 02:07:58 --> Model Class Initialized
DEBUG - 2018-02-12 02:07:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:01 --> Config Class Initialized
INFO - 2018-02-12 02:08:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:01 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:01 --> URI Class Initialized
INFO - 2018-02-12 02:08:01 --> Router Class Initialized
INFO - 2018-02-12 02:08:01 --> Output Class Initialized
INFO - 2018-02-12 02:08:01 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:01 --> Input Class Initialized
INFO - 2018-02-12 02:08:01 --> Language Class Initialized
INFO - 2018-02-12 02:08:01 --> Loader Class Initialized
INFO - 2018-02-12 02:08:01 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:01 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:01 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:01 --> Model Class Initialized
INFO - 2018-02-12 02:08:01 --> Controller Class Initialized
INFO - 2018-02-12 02:08:01 --> Model Class Initialized
INFO - 2018-02-12 02:08:01 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:01 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:01 --> Total execution time: 0.0950
INFO - 2018-02-12 02:08:03 --> Config Class Initialized
INFO - 2018-02-12 02:08:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:03 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:03 --> URI Class Initialized
INFO - 2018-02-12 02:08:03 --> Router Class Initialized
INFO - 2018-02-12 02:08:03 --> Output Class Initialized
INFO - 2018-02-12 02:08:03 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:03 --> Input Class Initialized
INFO - 2018-02-12 02:08:03 --> Language Class Initialized
INFO - 2018-02-12 02:08:03 --> Loader Class Initialized
INFO - 2018-02-12 02:08:03 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:03 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:03 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:03 --> Model Class Initialized
INFO - 2018-02-12 02:08:03 --> Controller Class Initialized
INFO - 2018-02-12 02:08:03 --> Model Class Initialized
INFO - 2018-02-12 02:08:03 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:04 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:04 --> Total execution time: 0.0880
INFO - 2018-02-12 02:08:04 --> Config Class Initialized
INFO - 2018-02-12 02:08:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:04 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:04 --> URI Class Initialized
INFO - 2018-02-12 02:08:04 --> Router Class Initialized
INFO - 2018-02-12 02:08:04 --> Output Class Initialized
INFO - 2018-02-12 02:08:04 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:04 --> Input Class Initialized
INFO - 2018-02-12 02:08:04 --> Language Class Initialized
INFO - 2018-02-12 02:08:04 --> Loader Class Initialized
INFO - 2018-02-12 02:08:04 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:04 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:04 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:04 --> Model Class Initialized
INFO - 2018-02-12 02:08:04 --> Controller Class Initialized
INFO - 2018-02-12 02:08:04 --> Model Class Initialized
INFO - 2018-02-12 02:08:04 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:52 --> Config Class Initialized
INFO - 2018-02-12 02:08:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:52 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:52 --> URI Class Initialized
INFO - 2018-02-12 02:08:52 --> Router Class Initialized
INFO - 2018-02-12 02:08:52 --> Output Class Initialized
INFO - 2018-02-12 02:08:52 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:52 --> Input Class Initialized
INFO - 2018-02-12 02:08:52 --> Language Class Initialized
INFO - 2018-02-12 02:08:52 --> Loader Class Initialized
INFO - 2018-02-12 02:08:52 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:52 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:52 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
INFO - 2018-02-12 02:08:52 --> Controller Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:52 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:52 --> Total execution time: 0.1198
INFO - 2018-02-12 02:08:52 --> Config Class Initialized
INFO - 2018-02-12 02:08:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:52 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:52 --> URI Class Initialized
INFO - 2018-02-12 02:08:52 --> Router Class Initialized
INFO - 2018-02-12 02:08:52 --> Output Class Initialized
INFO - 2018-02-12 02:08:52 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:52 --> Input Class Initialized
INFO - 2018-02-12 02:08:52 --> Language Class Initialized
INFO - 2018-02-12 02:08:52 --> Loader Class Initialized
INFO - 2018-02-12 02:08:52 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:52 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:52 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
INFO - 2018-02-12 02:08:52 --> Controller Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
INFO - 2018-02-12 02:08:52 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:54 --> Config Class Initialized
INFO - 2018-02-12 02:08:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:54 --> URI Class Initialized
INFO - 2018-02-12 02:08:54 --> Router Class Initialized
INFO - 2018-02-12 02:08:54 --> Output Class Initialized
INFO - 2018-02-12 02:08:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:54 --> Input Class Initialized
INFO - 2018-02-12 02:08:54 --> Language Class Initialized
INFO - 2018-02-12 02:08:54 --> Loader Class Initialized
INFO - 2018-02-12 02:08:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:54 --> Model Class Initialized
INFO - 2018-02-12 02:08:54 --> Controller Class Initialized
INFO - 2018-02-12 02:08:54 --> Model Class Initialized
INFO - 2018-02-12 02:08:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:54 --> Total execution time: 0.0991
INFO - 2018-02-12 02:08:58 --> Config Class Initialized
INFO - 2018-02-12 02:08:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:58 --> URI Class Initialized
INFO - 2018-02-12 02:08:58 --> Router Class Initialized
INFO - 2018-02-12 02:08:58 --> Output Class Initialized
INFO - 2018-02-12 02:08:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:58 --> Input Class Initialized
INFO - 2018-02-12 02:08:58 --> Language Class Initialized
INFO - 2018-02-12 02:08:58 --> Loader Class Initialized
INFO - 2018-02-12 02:08:58 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:58 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:58 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
INFO - 2018-02-12 02:08:58 --> Controller Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:58 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:58 --> Total execution time: 0.0654
INFO - 2018-02-12 02:08:58 --> Config Class Initialized
INFO - 2018-02-12 02:08:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:58 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:58 --> URI Class Initialized
INFO - 2018-02-12 02:08:58 --> Router Class Initialized
INFO - 2018-02-12 02:08:58 --> Output Class Initialized
INFO - 2018-02-12 02:08:58 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:58 --> Input Class Initialized
INFO - 2018-02-12 02:08:58 --> Language Class Initialized
INFO - 2018-02-12 02:08:58 --> Loader Class Initialized
INFO - 2018-02-12 02:08:58 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:58 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:58 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
INFO - 2018-02-12 02:08:58 --> Controller Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
INFO - 2018-02-12 02:08:58 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:59 --> Config Class Initialized
INFO - 2018-02-12 02:08:59 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:08:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:08:59 --> Utf8 Class Initialized
INFO - 2018-02-12 02:08:59 --> URI Class Initialized
INFO - 2018-02-12 02:08:59 --> Router Class Initialized
INFO - 2018-02-12 02:08:59 --> Output Class Initialized
INFO - 2018-02-12 02:08:59 --> Security Class Initialized
DEBUG - 2018-02-12 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:08:59 --> Input Class Initialized
INFO - 2018-02-12 02:08:59 --> Language Class Initialized
INFO - 2018-02-12 02:08:59 --> Loader Class Initialized
INFO - 2018-02-12 02:08:59 --> Helper loaded: url_helper
INFO - 2018-02-12 02:08:59 --> Helper loaded: form_helper
INFO - 2018-02-12 02:08:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:08:59 --> Form Validation Class Initialized
INFO - 2018-02-12 02:08:59 --> Model Class Initialized
INFO - 2018-02-12 02:08:59 --> Controller Class Initialized
INFO - 2018-02-12 02:08:59 --> Model Class Initialized
INFO - 2018-02-12 02:08:59 --> Model Class Initialized
DEBUG - 2018-02-12 02:08:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:08:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:08:59 --> Final output sent to browser
DEBUG - 2018-02-12 02:08:59 --> Total execution time: 0.1301
INFO - 2018-02-12 02:09:21 --> Config Class Initialized
INFO - 2018-02-12 02:09:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:21 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:21 --> URI Class Initialized
INFO - 2018-02-12 02:09:21 --> Router Class Initialized
INFO - 2018-02-12 02:09:21 --> Output Class Initialized
INFO - 2018-02-12 02:09:21 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:21 --> Input Class Initialized
INFO - 2018-02-12 02:09:21 --> Language Class Initialized
INFO - 2018-02-12 02:09:21 --> Loader Class Initialized
INFO - 2018-02-12 02:09:21 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:21 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:21 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:21 --> Model Class Initialized
INFO - 2018-02-12 02:09:21 --> Controller Class Initialized
INFO - 2018-02-12 02:09:21 --> Model Class Initialized
INFO - 2018-02-12 02:09:21 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:09:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:21 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:21 --> Total execution time: 0.2374
INFO - 2018-02-12 02:09:24 --> Config Class Initialized
INFO - 2018-02-12 02:09:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:24 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:24 --> URI Class Initialized
INFO - 2018-02-12 02:09:24 --> Router Class Initialized
INFO - 2018-02-12 02:09:24 --> Output Class Initialized
INFO - 2018-02-12 02:09:24 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:24 --> Input Class Initialized
INFO - 2018-02-12 02:09:24 --> Language Class Initialized
INFO - 2018-02-12 02:09:24 --> Loader Class Initialized
INFO - 2018-02-12 02:09:24 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:24 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:24 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
INFO - 2018-02-12 02:09:24 --> Controller Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:09:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:24 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:24 --> Total execution time: 0.0783
INFO - 2018-02-12 02:09:24 --> Config Class Initialized
INFO - 2018-02-12 02:09:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:24 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:24 --> URI Class Initialized
INFO - 2018-02-12 02:09:24 --> Router Class Initialized
INFO - 2018-02-12 02:09:24 --> Output Class Initialized
INFO - 2018-02-12 02:09:24 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:24 --> Input Class Initialized
INFO - 2018-02-12 02:09:24 --> Language Class Initialized
INFO - 2018-02-12 02:09:24 --> Loader Class Initialized
INFO - 2018-02-12 02:09:24 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:24 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:24 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
INFO - 2018-02-12 02:09:24 --> Controller Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
INFO - 2018-02-12 02:09:24 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:09:26 --> Config Class Initialized
INFO - 2018-02-12 02:09:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:26 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:26 --> URI Class Initialized
INFO - 2018-02-12 02:09:26 --> Router Class Initialized
INFO - 2018-02-12 02:09:26 --> Output Class Initialized
INFO - 2018-02-12 02:09:26 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:26 --> Input Class Initialized
INFO - 2018-02-12 02:09:26 --> Language Class Initialized
INFO - 2018-02-12 02:09:26 --> Loader Class Initialized
INFO - 2018-02-12 02:09:26 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:26 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:26 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:26 --> Model Class Initialized
INFO - 2018-02-12 02:09:26 --> Controller Class Initialized
INFO - 2018-02-12 02:09:26 --> Model Class Initialized
INFO - 2018-02-12 02:09:26 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:26 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:26 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:26 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:26 --> Total execution time: 0.1513
INFO - 2018-02-12 02:09:29 --> Config Class Initialized
INFO - 2018-02-12 02:09:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:29 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:29 --> URI Class Initialized
INFO - 2018-02-12 02:09:29 --> Router Class Initialized
INFO - 2018-02-12 02:09:29 --> Output Class Initialized
INFO - 2018-02-12 02:09:29 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:29 --> Input Class Initialized
INFO - 2018-02-12 02:09:29 --> Language Class Initialized
INFO - 2018-02-12 02:09:29 --> Loader Class Initialized
INFO - 2018-02-12 02:09:29 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:29 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:29 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
INFO - 2018-02-12 02:09:29 --> Controller Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:29 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:29 --> Total execution time: 0.0977
INFO - 2018-02-12 02:09:29 --> Config Class Initialized
INFO - 2018-02-12 02:09:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:29 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:29 --> URI Class Initialized
INFO - 2018-02-12 02:09:29 --> Router Class Initialized
INFO - 2018-02-12 02:09:29 --> Output Class Initialized
INFO - 2018-02-12 02:09:29 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:29 --> Input Class Initialized
INFO - 2018-02-12 02:09:29 --> Language Class Initialized
INFO - 2018-02-12 02:09:29 --> Loader Class Initialized
INFO - 2018-02-12 02:09:29 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:29 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:29 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
INFO - 2018-02-12 02:09:29 --> Controller Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
INFO - 2018-02-12 02:09:29 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:29 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:29 --> Total execution time: 0.1072
INFO - 2018-02-12 02:09:29 --> Config Class Initialized
INFO - 2018-02-12 02:09:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:29 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:29 --> URI Class Initialized
INFO - 2018-02-12 02:09:29 --> Router Class Initialized
INFO - 2018-02-12 02:09:29 --> Output Class Initialized
INFO - 2018-02-12 02:09:29 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:29 --> Input Class Initialized
INFO - 2018-02-12 02:09:29 --> Language Class Initialized
INFO - 2018-02-12 02:09:29 --> Loader Class Initialized
INFO - 2018-02-12 02:09:29 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:29 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.1153
INFO - 2018-02-12 02:09:30 --> Config Class Initialized
INFO - 2018-02-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:30 --> URI Class Initialized
INFO - 2018-02-12 02:09:30 --> Router Class Initialized
INFO - 2018-02-12 02:09:30 --> Output Class Initialized
INFO - 2018-02-12 02:09:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:30 --> Input Class Initialized
INFO - 2018-02-12 02:09:30 --> Language Class Initialized
INFO - 2018-02-12 02:09:30 --> Loader Class Initialized
INFO - 2018-02-12 02:09:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.0775
INFO - 2018-02-12 02:09:30 --> Config Class Initialized
INFO - 2018-02-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:30 --> URI Class Initialized
INFO - 2018-02-12 02:09:30 --> Router Class Initialized
INFO - 2018-02-12 02:09:30 --> Output Class Initialized
INFO - 2018-02-12 02:09:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:30 --> Input Class Initialized
INFO - 2018-02-12 02:09:30 --> Language Class Initialized
INFO - 2018-02-12 02:09:30 --> Loader Class Initialized
INFO - 2018-02-12 02:09:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.1154
INFO - 2018-02-12 02:09:30 --> Config Class Initialized
INFO - 2018-02-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:30 --> URI Class Initialized
INFO - 2018-02-12 02:09:30 --> Router Class Initialized
INFO - 2018-02-12 02:09:30 --> Output Class Initialized
INFO - 2018-02-12 02:09:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:30 --> Input Class Initialized
INFO - 2018-02-12 02:09:30 --> Language Class Initialized
INFO - 2018-02-12 02:09:30 --> Loader Class Initialized
INFO - 2018-02-12 02:09:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.0746
INFO - 2018-02-12 02:09:30 --> Config Class Initialized
INFO - 2018-02-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:30 --> URI Class Initialized
INFO - 2018-02-12 02:09:30 --> Router Class Initialized
INFO - 2018-02-12 02:09:30 --> Output Class Initialized
INFO - 2018-02-12 02:09:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:30 --> Input Class Initialized
INFO - 2018-02-12 02:09:30 --> Language Class Initialized
INFO - 2018-02-12 02:09:30 --> Loader Class Initialized
INFO - 2018-02-12 02:09:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.0605
INFO - 2018-02-12 02:09:30 --> Config Class Initialized
INFO - 2018-02-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:09:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:09:30 --> Utf8 Class Initialized
INFO - 2018-02-12 02:09:30 --> URI Class Initialized
INFO - 2018-02-12 02:09:30 --> Router Class Initialized
INFO - 2018-02-12 02:09:30 --> Output Class Initialized
INFO - 2018-02-12 02:09:30 --> Security Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:09:30 --> Input Class Initialized
INFO - 2018-02-12 02:09:30 --> Language Class Initialized
INFO - 2018-02-12 02:09:30 --> Loader Class Initialized
INFO - 2018-02-12 02:09:30 --> Helper loaded: url_helper
INFO - 2018-02-12 02:09:30 --> Helper loaded: form_helper
INFO - 2018-02-12 02:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:09:30 --> Form Validation Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Controller Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
INFO - 2018-02-12 02:09:30 --> Model Class Initialized
DEBUG - 2018-02-12 02:09:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:09:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:09:30 --> Final output sent to browser
DEBUG - 2018-02-12 02:09:30 --> Total execution time: 0.0595
INFO - 2018-02-12 02:11:12 --> Config Class Initialized
INFO - 2018-02-12 02:11:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:12 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:12 --> URI Class Initialized
INFO - 2018-02-12 02:11:12 --> Router Class Initialized
INFO - 2018-02-12 02:11:12 --> Output Class Initialized
INFO - 2018-02-12 02:11:12 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:12 --> Input Class Initialized
INFO - 2018-02-12 02:11:12 --> Language Class Initialized
INFO - 2018-02-12 02:11:12 --> Loader Class Initialized
INFO - 2018-02-12 02:11:12 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:12 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:12 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:12 --> Model Class Initialized
INFO - 2018-02-12 02:11:12 --> Controller Class Initialized
INFO - 2018-02-12 02:11:12 --> Model Class Initialized
INFO - 2018-02-12 02:11:12 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:11:12 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:11:12 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:11:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:11:12 --> Final output sent to browser
DEBUG - 2018-02-12 02:11:12 --> Total execution time: 0.0751
INFO - 2018-02-12 02:11:13 --> Config Class Initialized
INFO - 2018-02-12 02:11:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:13 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:13 --> URI Class Initialized
INFO - 2018-02-12 02:11:13 --> Router Class Initialized
INFO - 2018-02-12 02:11:13 --> Output Class Initialized
INFO - 2018-02-12 02:11:13 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:13 --> Input Class Initialized
INFO - 2018-02-12 02:11:13 --> Language Class Initialized
INFO - 2018-02-12 02:11:13 --> Loader Class Initialized
INFO - 2018-02-12 02:11:13 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:13 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:13 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
INFO - 2018-02-12 02:11:13 --> Controller Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:11:13 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:11:13 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:11:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:11:13 --> Final output sent to browser
DEBUG - 2018-02-12 02:11:13 --> Total execution time: 0.1088
INFO - 2018-02-12 02:11:13 --> Config Class Initialized
INFO - 2018-02-12 02:11:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:13 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:13 --> URI Class Initialized
INFO - 2018-02-12 02:11:13 --> Router Class Initialized
INFO - 2018-02-12 02:11:13 --> Output Class Initialized
INFO - 2018-02-12 02:11:13 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:13 --> Input Class Initialized
INFO - 2018-02-12 02:11:13 --> Language Class Initialized
INFO - 2018-02-12 02:11:13 --> Loader Class Initialized
INFO - 2018-02-12 02:11:13 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:13 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:13 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
INFO - 2018-02-12 02:11:13 --> Controller Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
INFO - 2018-02-12 02:11:13 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:11:13 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:11:13 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:11:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:11:13 --> Final output sent to browser
DEBUG - 2018-02-12 02:11:13 --> Total execution time: 0.1373
INFO - 2018-02-12 02:11:17 --> Config Class Initialized
INFO - 2018-02-12 02:11:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:17 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:17 --> URI Class Initialized
INFO - 2018-02-12 02:11:17 --> Router Class Initialized
INFO - 2018-02-12 02:11:17 --> Output Class Initialized
INFO - 2018-02-12 02:11:17 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:17 --> Input Class Initialized
INFO - 2018-02-12 02:11:17 --> Language Class Initialized
INFO - 2018-02-12 02:11:17 --> Loader Class Initialized
INFO - 2018-02-12 02:11:17 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:17 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:17 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:17 --> Model Class Initialized
INFO - 2018-02-12 02:11:17 --> Controller Class Initialized
INFO - 2018-02-12 02:11:17 --> Model Class Initialized
INFO - 2018-02-12 02:11:17 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:11:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:11:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:11:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:11:17 --> Final output sent to browser
DEBUG - 2018-02-12 02:11:17 --> Total execution time: 0.2176
INFO - 2018-02-12 02:11:19 --> Config Class Initialized
INFO - 2018-02-12 02:11:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:19 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:19 --> URI Class Initialized
INFO - 2018-02-12 02:11:19 --> Router Class Initialized
INFO - 2018-02-12 02:11:19 --> Output Class Initialized
INFO - 2018-02-12 02:11:19 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:19 --> Input Class Initialized
INFO - 2018-02-12 02:11:19 --> Language Class Initialized
INFO - 2018-02-12 02:11:19 --> Loader Class Initialized
INFO - 2018-02-12 02:11:19 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:19 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:20 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
INFO - 2018-02-12 02:11:20 --> Controller Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:11:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:11:20 --> Final output sent to browser
DEBUG - 2018-02-12 02:11:20 --> Total execution time: 0.1045
INFO - 2018-02-12 02:11:20 --> Config Class Initialized
INFO - 2018-02-12 02:11:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:11:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:11:20 --> Utf8 Class Initialized
INFO - 2018-02-12 02:11:20 --> URI Class Initialized
INFO - 2018-02-12 02:11:20 --> Router Class Initialized
INFO - 2018-02-12 02:11:20 --> Output Class Initialized
INFO - 2018-02-12 02:11:20 --> Security Class Initialized
DEBUG - 2018-02-12 02:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:11:20 --> Input Class Initialized
INFO - 2018-02-12 02:11:20 --> Language Class Initialized
INFO - 2018-02-12 02:11:20 --> Loader Class Initialized
INFO - 2018-02-12 02:11:20 --> Helper loaded: url_helper
INFO - 2018-02-12 02:11:20 --> Helper loaded: form_helper
INFO - 2018-02-12 02:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:11:20 --> Form Validation Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
INFO - 2018-02-12 02:11:20 --> Controller Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
INFO - 2018-02-12 02:11:20 --> Model Class Initialized
DEBUG - 2018-02-12 02:11:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:12:27 --> Config Class Initialized
INFO - 2018-02-12 02:12:27 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:12:27 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:12:27 --> Utf8 Class Initialized
INFO - 2018-02-12 02:12:27 --> URI Class Initialized
INFO - 2018-02-12 02:12:27 --> Router Class Initialized
INFO - 2018-02-12 02:12:27 --> Output Class Initialized
INFO - 2018-02-12 02:12:27 --> Security Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:12:27 --> Input Class Initialized
INFO - 2018-02-12 02:12:27 --> Language Class Initialized
INFO - 2018-02-12 02:12:27 --> Loader Class Initialized
INFO - 2018-02-12 02:12:27 --> Helper loaded: url_helper
INFO - 2018-02-12 02:12:27 --> Helper loaded: form_helper
INFO - 2018-02-12 02:12:27 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:12:27 --> Form Validation Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
INFO - 2018-02-12 02:12:27 --> Controller Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:12:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:12:27 --> Final output sent to browser
DEBUG - 2018-02-12 02:12:27 --> Total execution time: 0.0798
INFO - 2018-02-12 02:12:27 --> Config Class Initialized
INFO - 2018-02-12 02:12:27 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:12:27 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:12:27 --> Utf8 Class Initialized
INFO - 2018-02-12 02:12:27 --> URI Class Initialized
INFO - 2018-02-12 02:12:27 --> Router Class Initialized
INFO - 2018-02-12 02:12:27 --> Output Class Initialized
INFO - 2018-02-12 02:12:27 --> Security Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:12:27 --> Input Class Initialized
INFO - 2018-02-12 02:12:27 --> Language Class Initialized
INFO - 2018-02-12 02:12:27 --> Loader Class Initialized
INFO - 2018-02-12 02:12:27 --> Helper loaded: url_helper
INFO - 2018-02-12 02:12:27 --> Helper loaded: form_helper
INFO - 2018-02-12 02:12:27 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:12:27 --> Form Validation Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
INFO - 2018-02-12 02:12:27 --> Controller Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
INFO - 2018-02-12 02:12:27 --> Model Class Initialized
DEBUG - 2018-02-12 02:12:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:12:32 --> Config Class Initialized
INFO - 2018-02-12 02:12:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:12:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:12:32 --> Utf8 Class Initialized
INFO - 2018-02-12 02:12:32 --> URI Class Initialized
INFO - 2018-02-12 02:12:32 --> Router Class Initialized
INFO - 2018-02-12 02:12:32 --> Output Class Initialized
INFO - 2018-02-12 02:12:32 --> Security Class Initialized
DEBUG - 2018-02-12 02:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:12:32 --> Input Class Initialized
INFO - 2018-02-12 02:12:32 --> Language Class Initialized
INFO - 2018-02-12 02:12:32 --> Loader Class Initialized
INFO - 2018-02-12 02:12:32 --> Helper loaded: url_helper
INFO - 2018-02-12 02:12:32 --> Helper loaded: form_helper
INFO - 2018-02-12 02:12:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:12:32 --> Form Validation Class Initialized
INFO - 2018-02-12 02:12:32 --> Model Class Initialized
INFO - 2018-02-12 02:12:32 --> Controller Class Initialized
INFO - 2018-02-12 02:12:32 --> Model Class Initialized
INFO - 2018-02-12 02:12:32 --> Model Class Initialized
DEBUG - 2018-02-12 02:12:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:12:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:12:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:12:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:12:32 --> Final output sent to browser
DEBUG - 2018-02-12 02:12:32 --> Total execution time: 0.1218
INFO - 2018-02-12 02:12:38 --> Config Class Initialized
INFO - 2018-02-12 02:12:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:12:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:12:38 --> Utf8 Class Initialized
INFO - 2018-02-12 02:12:38 --> URI Class Initialized
INFO - 2018-02-12 02:12:38 --> Router Class Initialized
INFO - 2018-02-12 02:12:38 --> Output Class Initialized
INFO - 2018-02-12 02:12:38 --> Security Class Initialized
DEBUG - 2018-02-12 02:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:12:38 --> Input Class Initialized
INFO - 2018-02-12 02:12:38 --> Language Class Initialized
INFO - 2018-02-12 02:12:38 --> Loader Class Initialized
INFO - 2018-02-12 02:12:38 --> Helper loaded: url_helper
INFO - 2018-02-12 02:12:38 --> Helper loaded: form_helper
INFO - 2018-02-12 02:12:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:12:38 --> Form Validation Class Initialized
INFO - 2018-02-12 02:12:38 --> Model Class Initialized
INFO - 2018-02-12 02:12:38 --> Controller Class Initialized
INFO - 2018-02-12 02:12:38 --> Model Class Initialized
INFO - 2018-02-12 02:12:38 --> Model Class Initialized
DEBUG - 2018-02-12 02:12:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:12:38 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:12:38 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:12:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:12:38 --> Final output sent to browser
DEBUG - 2018-02-12 02:12:38 --> Total execution time: 0.2178
INFO - 2018-02-12 02:13:19 --> Config Class Initialized
INFO - 2018-02-12 02:13:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:13:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:13:19 --> Utf8 Class Initialized
INFO - 2018-02-12 02:13:19 --> URI Class Initialized
INFO - 2018-02-12 02:13:19 --> Router Class Initialized
INFO - 2018-02-12 02:13:19 --> Output Class Initialized
INFO - 2018-02-12 02:13:19 --> Security Class Initialized
DEBUG - 2018-02-12 02:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:13:19 --> Input Class Initialized
INFO - 2018-02-12 02:13:19 --> Language Class Initialized
INFO - 2018-02-12 02:13:19 --> Loader Class Initialized
INFO - 2018-02-12 02:13:19 --> Helper loaded: url_helper
INFO - 2018-02-12 02:13:19 --> Helper loaded: form_helper
INFO - 2018-02-12 02:13:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:13:19 --> Form Validation Class Initialized
INFO - 2018-02-12 02:13:19 --> Model Class Initialized
INFO - 2018-02-12 02:13:19 --> Controller Class Initialized
INFO - 2018-02-12 02:13:19 --> Model Class Initialized
INFO - 2018-02-12 02:13:19 --> Model Class Initialized
DEBUG - 2018-02-12 02:13:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:13:19 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:13:19 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:13:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:13:19 --> Final output sent to browser
DEBUG - 2018-02-12 02:13:19 --> Total execution time: 0.0604
INFO - 2018-02-12 02:13:24 --> Config Class Initialized
INFO - 2018-02-12 02:13:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:13:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:13:24 --> Utf8 Class Initialized
INFO - 2018-02-12 02:13:24 --> URI Class Initialized
INFO - 2018-02-12 02:13:24 --> Router Class Initialized
INFO - 2018-02-12 02:13:24 --> Output Class Initialized
INFO - 2018-02-12 02:13:24 --> Security Class Initialized
DEBUG - 2018-02-12 02:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:13:24 --> Input Class Initialized
INFO - 2018-02-12 02:13:24 --> Language Class Initialized
INFO - 2018-02-12 02:13:24 --> Loader Class Initialized
INFO - 2018-02-12 02:13:24 --> Helper loaded: url_helper
INFO - 2018-02-12 02:13:24 --> Helper loaded: form_helper
INFO - 2018-02-12 02:13:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:13:24 --> Form Validation Class Initialized
INFO - 2018-02-12 02:13:24 --> Model Class Initialized
INFO - 2018-02-12 02:13:24 --> Controller Class Initialized
INFO - 2018-02-12 02:13:24 --> Model Class Initialized
INFO - 2018-02-12 02:13:24 --> Model Class Initialized
DEBUG - 2018-02-12 02:13:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:13:24 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:13:24 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:13:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:13:24 --> Final output sent to browser
DEBUG - 2018-02-12 02:13:24 --> Total execution time: 0.1604
INFO - 2018-02-12 02:13:27 --> Config Class Initialized
INFO - 2018-02-12 02:13:27 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:13:27 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:13:27 --> Utf8 Class Initialized
INFO - 2018-02-12 02:13:27 --> URI Class Initialized
INFO - 2018-02-12 02:13:27 --> Router Class Initialized
INFO - 2018-02-12 02:13:27 --> Output Class Initialized
INFO - 2018-02-12 02:13:27 --> Security Class Initialized
DEBUG - 2018-02-12 02:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:13:27 --> Input Class Initialized
INFO - 2018-02-12 02:13:27 --> Language Class Initialized
INFO - 2018-02-12 02:13:27 --> Loader Class Initialized
INFO - 2018-02-12 02:13:27 --> Helper loaded: url_helper
INFO - 2018-02-12 02:13:27 --> Helper loaded: form_helper
INFO - 2018-02-12 02:13:27 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:13:27 --> Form Validation Class Initialized
INFO - 2018-02-12 02:13:27 --> Model Class Initialized
INFO - 2018-02-12 02:13:27 --> Controller Class Initialized
INFO - 2018-02-12 02:13:27 --> Model Class Initialized
INFO - 2018-02-12 02:13:27 --> Model Class Initialized
DEBUG - 2018-02-12 02:13:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:13:27 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-12 02:13:27 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-12 02:13:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:13:27 --> Final output sent to browser
DEBUG - 2018-02-12 02:13:27 --> Total execution time: 0.1793
INFO - 2018-02-12 02:16:25 --> Config Class Initialized
INFO - 2018-02-12 02:16:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:16:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:25 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:25 --> URI Class Initialized
INFO - 2018-02-12 02:16:25 --> Router Class Initialized
INFO - 2018-02-12 02:16:25 --> Output Class Initialized
INFO - 2018-02-12 02:16:25 --> Security Class Initialized
DEBUG - 2018-02-12 02:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:25 --> Input Class Initialized
INFO - 2018-02-12 02:16:25 --> Language Class Initialized
INFO - 2018-02-12 02:16:25 --> Loader Class Initialized
INFO - 2018-02-12 02:16:25 --> Helper loaded: url_helper
INFO - 2018-02-12 02:16:25 --> Helper loaded: form_helper
INFO - 2018-02-12 02:16:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:16:25 --> Form Validation Class Initialized
INFO - 2018-02-12 02:16:25 --> Model Class Initialized
INFO - 2018-02-12 02:16:25 --> Controller Class Initialized
INFO - 2018-02-12 02:16:25 --> Model Class Initialized
INFO - 2018-02-12 02:16:25 --> Model Class Initialized
DEBUG - 2018-02-12 02:16:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:16:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:16:25 --> Final output sent to browser
DEBUG - 2018-02-12 02:16:25 --> Total execution time: 0.0459
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Config Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
INFO - 2018-02-12 02:16:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> URI Class Initialized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> Router Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:44 --> Output Class Initialized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
INFO - 2018-02-12 02:16:44 --> Security Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
DEBUG - 2018-02-12 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:16:44 --> Input Class Initialized
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
INFO - 2018-02-12 02:16:44 --> Language Class Initialized
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:16:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:17:36 --> Config Class Initialized
INFO - 2018-02-12 02:17:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:17:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:36 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:36 --> URI Class Initialized
INFO - 2018-02-12 02:17:36 --> Router Class Initialized
INFO - 2018-02-12 02:17:36 --> Output Class Initialized
INFO - 2018-02-12 02:17:36 --> Security Class Initialized
DEBUG - 2018-02-12 02:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:36 --> Input Class Initialized
INFO - 2018-02-12 02:17:36 --> Language Class Initialized
INFO - 2018-02-12 02:17:36 --> Loader Class Initialized
INFO - 2018-02-12 02:17:36 --> Helper loaded: url_helper
INFO - 2018-02-12 02:17:36 --> Helper loaded: form_helper
INFO - 2018-02-12 02:17:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:17:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:17:37 --> Model Class Initialized
INFO - 2018-02-12 02:17:37 --> Controller Class Initialized
INFO - 2018-02-12 02:17:37 --> Model Class Initialized
INFO - 2018-02-12 02:17:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:17:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:17:37 --> Final output sent to browser
DEBUG - 2018-02-12 02:17:37 --> Total execution time: 0.0977
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Config Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
INFO - 2018-02-12 02:17:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 02:17:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:17:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> URI Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> Router Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Output Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
INFO - 2018-02-12 02:17:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
DEBUG - 2018-02-12 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
INFO - 2018-02-12 02:17:37 --> Input Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
INFO - 2018-02-12 02:17:37 --> Language Class Initialized
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 02:17:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 02:18:39 --> Config Class Initialized
INFO - 2018-02-12 02:18:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:39 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:39 --> URI Class Initialized
INFO - 2018-02-12 02:18:39 --> Router Class Initialized
INFO - 2018-02-12 02:18:39 --> Output Class Initialized
INFO - 2018-02-12 02:18:39 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:39 --> Input Class Initialized
INFO - 2018-02-12 02:18:39 --> Language Class Initialized
INFO - 2018-02-12 02:18:39 --> Loader Class Initialized
INFO - 2018-02-12 02:18:39 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:39 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:39 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:39 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:39 --> Model Class Initialized
INFO - 2018-02-12 02:18:39 --> Controller Class Initialized
INFO - 2018-02-12 02:18:39 --> Model Class Initialized
INFO - 2018-02-12 02:18:39 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:39 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:39 --> Total execution time: 0.0818
INFO - 2018-02-12 02:18:40 --> Config Class Initialized
INFO - 2018-02-12 02:18:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:40 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:40 --> URI Class Initialized
INFO - 2018-02-12 02:18:40 --> Router Class Initialized
INFO - 2018-02-12 02:18:40 --> Output Class Initialized
INFO - 2018-02-12 02:18:40 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:40 --> Input Class Initialized
INFO - 2018-02-12 02:18:40 --> Language Class Initialized
INFO - 2018-02-12 02:18:40 --> Loader Class Initialized
INFO - 2018-02-12 02:18:40 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:40 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:40 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
INFO - 2018-02-12 02:18:40 --> Controller Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:40 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:40 --> Total execution time: 0.0853
INFO - 2018-02-12 02:18:40 --> Config Class Initialized
INFO - 2018-02-12 02:18:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:40 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:40 --> URI Class Initialized
INFO - 2018-02-12 02:18:40 --> Router Class Initialized
INFO - 2018-02-12 02:18:40 --> Output Class Initialized
INFO - 2018-02-12 02:18:40 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:40 --> Input Class Initialized
INFO - 2018-02-12 02:18:40 --> Language Class Initialized
INFO - 2018-02-12 02:18:40 --> Loader Class Initialized
INFO - 2018-02-12 02:18:40 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:40 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:40 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
INFO - 2018-02-12 02:18:40 --> Controller Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
INFO - 2018-02-12 02:18:40 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:40 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:40 --> Total execution time: 0.0473
INFO - 2018-02-12 02:18:40 --> Config Class Initialized
INFO - 2018-02-12 02:18:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:40 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:40 --> URI Class Initialized
INFO - 2018-02-12 02:18:40 --> Router Class Initialized
INFO - 2018-02-12 02:18:40 --> Output Class Initialized
INFO - 2018-02-12 02:18:40 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:40 --> Input Class Initialized
INFO - 2018-02-12 02:18:40 --> Language Class Initialized
INFO - 2018-02-12 02:18:40 --> Loader Class Initialized
INFO - 2018-02-12 02:18:40 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Controller Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:41 --> Total execution time: 0.0754
INFO - 2018-02-12 02:18:41 --> Config Class Initialized
INFO - 2018-02-12 02:18:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:41 --> URI Class Initialized
INFO - 2018-02-12 02:18:41 --> Router Class Initialized
INFO - 2018-02-12 02:18:41 --> Output Class Initialized
INFO - 2018-02-12 02:18:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:41 --> Input Class Initialized
INFO - 2018-02-12 02:18:41 --> Language Class Initialized
INFO - 2018-02-12 02:18:41 --> Loader Class Initialized
INFO - 2018-02-12 02:18:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Controller Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:41 --> Total execution time: 0.1148
INFO - 2018-02-12 02:18:41 --> Config Class Initialized
INFO - 2018-02-12 02:18:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:41 --> URI Class Initialized
INFO - 2018-02-12 02:18:41 --> Router Class Initialized
INFO - 2018-02-12 02:18:41 --> Output Class Initialized
INFO - 2018-02-12 02:18:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:41 --> Input Class Initialized
INFO - 2018-02-12 02:18:41 --> Language Class Initialized
INFO - 2018-02-12 02:18:41 --> Loader Class Initialized
INFO - 2018-02-12 02:18:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Controller Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:41 --> Total execution time: 0.0566
INFO - 2018-02-12 02:18:41 --> Config Class Initialized
INFO - 2018-02-12 02:18:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:41 --> URI Class Initialized
INFO - 2018-02-12 02:18:41 --> Router Class Initialized
INFO - 2018-02-12 02:18:41 --> Output Class Initialized
INFO - 2018-02-12 02:18:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:41 --> Input Class Initialized
INFO - 2018-02-12 02:18:41 --> Language Class Initialized
INFO - 2018-02-12 02:18:41 --> Loader Class Initialized
INFO - 2018-02-12 02:18:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Controller Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:41 --> Total execution time: 0.0592
INFO - 2018-02-12 02:18:41 --> Config Class Initialized
INFO - 2018-02-12 02:18:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:41 --> URI Class Initialized
INFO - 2018-02-12 02:18:41 --> Router Class Initialized
INFO - 2018-02-12 02:18:41 --> Output Class Initialized
INFO - 2018-02-12 02:18:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:41 --> Input Class Initialized
INFO - 2018-02-12 02:18:41 --> Language Class Initialized
INFO - 2018-02-12 02:18:41 --> Loader Class Initialized
INFO - 2018-02-12 02:18:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Controller Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
INFO - 2018-02-12 02:18:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:41 --> Total execution time: 0.0675
INFO - 2018-02-12 02:18:44 --> Config Class Initialized
INFO - 2018-02-12 02:18:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:44 --> URI Class Initialized
INFO - 2018-02-12 02:18:44 --> Router Class Initialized
INFO - 2018-02-12 02:18:44 --> Output Class Initialized
INFO - 2018-02-12 02:18:44 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:44 --> Input Class Initialized
INFO - 2018-02-12 02:18:44 --> Language Class Initialized
INFO - 2018-02-12 02:18:44 --> Loader Class Initialized
INFO - 2018-02-12 02:18:44 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:44 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:44 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:44 --> Model Class Initialized
INFO - 2018-02-12 02:18:44 --> Controller Class Initialized
INFO - 2018-02-12 02:18:44 --> Model Class Initialized
INFO - 2018-02-12 02:18:44 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:18:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:18:44 --> Final output sent to browser
DEBUG - 2018-02-12 02:18:44 --> Total execution time: 0.0860
INFO - 2018-02-12 02:18:48 --> Config Class Initialized
INFO - 2018-02-12 02:18:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:18:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:18:48 --> Utf8 Class Initialized
INFO - 2018-02-12 02:18:48 --> URI Class Initialized
INFO - 2018-02-12 02:18:48 --> Router Class Initialized
INFO - 2018-02-12 02:18:48 --> Output Class Initialized
INFO - 2018-02-12 02:18:48 --> Security Class Initialized
DEBUG - 2018-02-12 02:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:18:48 --> Input Class Initialized
INFO - 2018-02-12 02:18:48 --> Language Class Initialized
INFO - 2018-02-12 02:18:48 --> Loader Class Initialized
INFO - 2018-02-12 02:18:48 --> Helper loaded: url_helper
INFO - 2018-02-12 02:18:48 --> Helper loaded: form_helper
INFO - 2018-02-12 02:18:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:18:48 --> Form Validation Class Initialized
INFO - 2018-02-12 02:18:48 --> Model Class Initialized
INFO - 2018-02-12 02:18:48 --> Controller Class Initialized
INFO - 2018-02-12 02:18:48 --> Model Class Initialized
INFO - 2018-02-12 02:18:48 --> Model Class Initialized
DEBUG - 2018-02-12 02:18:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-12 02:18:48 --> Severity: Notice --> Undefined index: moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 236
ERROR - 2018-02-12 02:18:48 --> Severity: Notice --> Undefined index: moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php 246
ERROR - 2018-02-12 02:18:48 --> Query error: Column 'moneda_id' cannot be null - Invalid query: INSERT INTO `colaborador_costo_hora` (`costo_hora`, `moneda_id`, `fecha_registro`, `estado_costo`, `colaborador_id`) VALUES ('1500.00', NULL, '2018-02-12 02:18:48', 1, '16')
INFO - 2018-02-12 02:18:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-12 02:19:20 --> Config Class Initialized
INFO - 2018-02-12 02:19:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:19:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:19:20 --> Utf8 Class Initialized
INFO - 2018-02-12 02:19:20 --> URI Class Initialized
INFO - 2018-02-12 02:19:20 --> Router Class Initialized
INFO - 2018-02-12 02:19:20 --> Output Class Initialized
INFO - 2018-02-12 02:19:20 --> Security Class Initialized
DEBUG - 2018-02-12 02:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:19:20 --> Input Class Initialized
INFO - 2018-02-12 02:19:20 --> Language Class Initialized
INFO - 2018-02-12 02:19:20 --> Loader Class Initialized
INFO - 2018-02-12 02:19:20 --> Helper loaded: url_helper
INFO - 2018-02-12 02:19:20 --> Helper loaded: form_helper
INFO - 2018-02-12 02:19:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:19:20 --> Form Validation Class Initialized
INFO - 2018-02-12 02:19:20 --> Model Class Initialized
INFO - 2018-02-12 02:19:20 --> Controller Class Initialized
INFO - 2018-02-12 02:19:20 --> Model Class Initialized
INFO - 2018-02-12 02:19:20 --> Model Class Initialized
DEBUG - 2018-02-12 02:19:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:19:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:19:20 --> Final output sent to browser
DEBUG - 2018-02-12 02:19:20 --> Total execution time: 0.1869
INFO - 2018-02-12 02:19:33 --> Config Class Initialized
INFO - 2018-02-12 02:19:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:19:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:19:33 --> Utf8 Class Initialized
INFO - 2018-02-12 02:19:33 --> URI Class Initialized
INFO - 2018-02-12 02:19:33 --> Router Class Initialized
INFO - 2018-02-12 02:19:33 --> Output Class Initialized
INFO - 2018-02-12 02:19:33 --> Security Class Initialized
DEBUG - 2018-02-12 02:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:19:33 --> Input Class Initialized
INFO - 2018-02-12 02:19:33 --> Language Class Initialized
INFO - 2018-02-12 02:19:33 --> Loader Class Initialized
INFO - 2018-02-12 02:19:33 --> Helper loaded: url_helper
INFO - 2018-02-12 02:19:33 --> Helper loaded: form_helper
INFO - 2018-02-12 02:19:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:19:33 --> Form Validation Class Initialized
INFO - 2018-02-12 02:19:33 --> Model Class Initialized
INFO - 2018-02-12 02:19:33 --> Controller Class Initialized
INFO - 2018-02-12 02:19:33 --> Model Class Initialized
INFO - 2018-02-12 02:19:33 --> Model Class Initialized
DEBUG - 2018-02-12 02:19:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:19:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:19:33 --> Final output sent to browser
DEBUG - 2018-02-12 02:19:33 --> Total execution time: 0.0463
INFO - 2018-02-12 02:19:37 --> Config Class Initialized
INFO - 2018-02-12 02:19:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:19:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:19:37 --> Utf8 Class Initialized
INFO - 2018-02-12 02:19:37 --> URI Class Initialized
INFO - 2018-02-12 02:19:37 --> Router Class Initialized
INFO - 2018-02-12 02:19:37 --> Output Class Initialized
INFO - 2018-02-12 02:19:37 --> Security Class Initialized
DEBUG - 2018-02-12 02:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:19:37 --> Input Class Initialized
INFO - 2018-02-12 02:19:37 --> Language Class Initialized
INFO - 2018-02-12 02:19:37 --> Loader Class Initialized
INFO - 2018-02-12 02:19:37 --> Helper loaded: url_helper
INFO - 2018-02-12 02:19:37 --> Helper loaded: form_helper
INFO - 2018-02-12 02:19:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:19:37 --> Form Validation Class Initialized
INFO - 2018-02-12 02:19:37 --> Model Class Initialized
INFO - 2018-02-12 02:19:37 --> Controller Class Initialized
INFO - 2018-02-12 02:19:37 --> Model Class Initialized
INFO - 2018-02-12 02:19:37 --> Model Class Initialized
DEBUG - 2018-02-12 02:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:19:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:19:37 --> Final output sent to browser
DEBUG - 2018-02-12 02:19:37 --> Total execution time: 0.0454
INFO - 2018-02-12 02:19:41 --> Config Class Initialized
INFO - 2018-02-12 02:19:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:19:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:19:41 --> Utf8 Class Initialized
INFO - 2018-02-12 02:19:41 --> URI Class Initialized
INFO - 2018-02-12 02:19:41 --> Router Class Initialized
INFO - 2018-02-12 02:19:41 --> Output Class Initialized
INFO - 2018-02-12 02:19:41 --> Security Class Initialized
DEBUG - 2018-02-12 02:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:19:41 --> Input Class Initialized
INFO - 2018-02-12 02:19:41 --> Language Class Initialized
INFO - 2018-02-12 02:19:41 --> Loader Class Initialized
INFO - 2018-02-12 02:19:41 --> Helper loaded: url_helper
INFO - 2018-02-12 02:19:41 --> Helper loaded: form_helper
INFO - 2018-02-12 02:19:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:19:41 --> Form Validation Class Initialized
INFO - 2018-02-12 02:19:41 --> Model Class Initialized
INFO - 2018-02-12 02:19:41 --> Controller Class Initialized
INFO - 2018-02-12 02:19:41 --> Model Class Initialized
INFO - 2018-02-12 02:19:41 --> Model Class Initialized
DEBUG - 2018-02-12 02:19:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:19:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:19:41 --> Final output sent to browser
DEBUG - 2018-02-12 02:19:41 --> Total execution time: 0.0566
INFO - 2018-02-12 02:19:54 --> Config Class Initialized
INFO - 2018-02-12 02:19:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:19:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:19:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:19:54 --> URI Class Initialized
INFO - 2018-02-12 02:19:54 --> Router Class Initialized
INFO - 2018-02-12 02:19:54 --> Output Class Initialized
INFO - 2018-02-12 02:19:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:19:54 --> Input Class Initialized
INFO - 2018-02-12 02:19:54 --> Language Class Initialized
INFO - 2018-02-12 02:19:54 --> Loader Class Initialized
INFO - 2018-02-12 02:19:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:19:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:19:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:19:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:19:54 --> Model Class Initialized
INFO - 2018-02-12 02:19:54 --> Controller Class Initialized
INFO - 2018-02-12 02:19:54 --> Model Class Initialized
INFO - 2018-02-12 02:19:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:19:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:19:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:19:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:19:54 --> Total execution time: 0.1902
INFO - 2018-02-12 02:20:52 --> Config Class Initialized
INFO - 2018-02-12 02:20:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:20:52 --> Utf8 Class Initialized
INFO - 2018-02-12 02:20:52 --> URI Class Initialized
INFO - 2018-02-12 02:20:52 --> Router Class Initialized
INFO - 2018-02-12 02:20:52 --> Output Class Initialized
INFO - 2018-02-12 02:20:52 --> Security Class Initialized
DEBUG - 2018-02-12 02:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:20:52 --> Input Class Initialized
INFO - 2018-02-12 02:20:52 --> Language Class Initialized
INFO - 2018-02-12 02:20:52 --> Loader Class Initialized
INFO - 2018-02-12 02:20:52 --> Helper loaded: url_helper
INFO - 2018-02-12 02:20:52 --> Helper loaded: form_helper
INFO - 2018-02-12 02:20:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:20:52 --> Form Validation Class Initialized
INFO - 2018-02-12 02:20:52 --> Model Class Initialized
INFO - 2018-02-12 02:20:52 --> Controller Class Initialized
INFO - 2018-02-12 02:20:52 --> Model Class Initialized
INFO - 2018-02-12 02:20:52 --> Model Class Initialized
DEBUG - 2018-02-12 02:20:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:20:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:20:52 --> Final output sent to browser
DEBUG - 2018-02-12 02:20:52 --> Total execution time: 0.0538
INFO - 2018-02-12 02:21:19 --> Config Class Initialized
INFO - 2018-02-12 02:21:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:19 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:19 --> URI Class Initialized
INFO - 2018-02-12 02:21:19 --> Router Class Initialized
INFO - 2018-02-12 02:21:19 --> Output Class Initialized
INFO - 2018-02-12 02:21:19 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:19 --> Input Class Initialized
INFO - 2018-02-12 02:21:19 --> Language Class Initialized
INFO - 2018-02-12 02:21:19 --> Loader Class Initialized
INFO - 2018-02-12 02:21:19 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:19 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:19 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:19 --> Model Class Initialized
INFO - 2018-02-12 02:21:19 --> Controller Class Initialized
INFO - 2018-02-12 02:21:19 --> Model Class Initialized
INFO - 2018-02-12 02:21:19 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:19 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:19 --> Total execution time: 0.0693
INFO - 2018-02-12 02:21:20 --> Config Class Initialized
INFO - 2018-02-12 02:21:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:20 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:20 --> URI Class Initialized
INFO - 2018-02-12 02:21:20 --> Router Class Initialized
INFO - 2018-02-12 02:21:20 --> Output Class Initialized
INFO - 2018-02-12 02:21:20 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:20 --> Input Class Initialized
INFO - 2018-02-12 02:21:20 --> Language Class Initialized
INFO - 2018-02-12 02:21:20 --> Loader Class Initialized
INFO - 2018-02-12 02:21:20 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:20 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:20 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
INFO - 2018-02-12 02:21:20 --> Controller Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:20 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:20 --> Total execution time: 0.0895
INFO - 2018-02-12 02:21:20 --> Config Class Initialized
INFO - 2018-02-12 02:21:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:20 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:20 --> URI Class Initialized
INFO - 2018-02-12 02:21:20 --> Router Class Initialized
INFO - 2018-02-12 02:21:20 --> Output Class Initialized
INFO - 2018-02-12 02:21:20 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:20 --> Input Class Initialized
INFO - 2018-02-12 02:21:20 --> Language Class Initialized
INFO - 2018-02-12 02:21:20 --> Loader Class Initialized
INFO - 2018-02-12 02:21:20 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:20 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:20 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
INFO - 2018-02-12 02:21:20 --> Controller Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
INFO - 2018-02-12 02:21:20 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:20 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:20 --> Total execution time: 0.0763
INFO - 2018-02-12 02:21:21 --> Config Class Initialized
INFO - 2018-02-12 02:21:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:21 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:21 --> URI Class Initialized
INFO - 2018-02-12 02:21:21 --> Router Class Initialized
INFO - 2018-02-12 02:21:21 --> Output Class Initialized
INFO - 2018-02-12 02:21:21 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:21 --> Input Class Initialized
INFO - 2018-02-12 02:21:21 --> Language Class Initialized
INFO - 2018-02-12 02:21:21 --> Loader Class Initialized
INFO - 2018-02-12 02:21:21 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:21 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:21 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
INFO - 2018-02-12 02:21:21 --> Controller Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:21 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:21 --> Total execution time: 0.0757
INFO - 2018-02-12 02:21:21 --> Config Class Initialized
INFO - 2018-02-12 02:21:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:21 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:21 --> URI Class Initialized
INFO - 2018-02-12 02:21:21 --> Router Class Initialized
INFO - 2018-02-12 02:21:21 --> Output Class Initialized
INFO - 2018-02-12 02:21:21 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:21 --> Input Class Initialized
INFO - 2018-02-12 02:21:21 --> Language Class Initialized
INFO - 2018-02-12 02:21:21 --> Loader Class Initialized
INFO - 2018-02-12 02:21:21 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:21 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:21 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
INFO - 2018-02-12 02:21:21 --> Controller Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
INFO - 2018-02-12 02:21:21 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:21 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:21 --> Total execution time: 0.1026
INFO - 2018-02-12 02:21:52 --> Config Class Initialized
INFO - 2018-02-12 02:21:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:52 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:52 --> URI Class Initialized
INFO - 2018-02-12 02:21:52 --> Router Class Initialized
INFO - 2018-02-12 02:21:52 --> Output Class Initialized
INFO - 2018-02-12 02:21:52 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:52 --> Input Class Initialized
INFO - 2018-02-12 02:21:52 --> Language Class Initialized
INFO - 2018-02-12 02:21:52 --> Loader Class Initialized
INFO - 2018-02-12 02:21:52 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:52 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:52 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:52 --> Model Class Initialized
INFO - 2018-02-12 02:21:52 --> Controller Class Initialized
INFO - 2018-02-12 02:21:52 --> Model Class Initialized
INFO - 2018-02-12 02:21:52 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:52 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:52 --> Total execution time: 0.0885
INFO - 2018-02-12 02:21:53 --> Config Class Initialized
INFO - 2018-02-12 02:21:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:53 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:53 --> URI Class Initialized
INFO - 2018-02-12 02:21:53 --> Router Class Initialized
INFO - 2018-02-12 02:21:53 --> Output Class Initialized
INFO - 2018-02-12 02:21:53 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:53 --> Input Class Initialized
INFO - 2018-02-12 02:21:53 --> Language Class Initialized
INFO - 2018-02-12 02:21:53 --> Loader Class Initialized
INFO - 2018-02-12 02:21:53 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:53 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:53 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
INFO - 2018-02-12 02:21:53 --> Controller Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:53 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:53 --> Total execution time: 0.0784
INFO - 2018-02-12 02:21:53 --> Config Class Initialized
INFO - 2018-02-12 02:21:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:53 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:53 --> URI Class Initialized
INFO - 2018-02-12 02:21:53 --> Router Class Initialized
INFO - 2018-02-12 02:21:53 --> Output Class Initialized
INFO - 2018-02-12 02:21:53 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:53 --> Input Class Initialized
INFO - 2018-02-12 02:21:53 --> Language Class Initialized
INFO - 2018-02-12 02:21:53 --> Loader Class Initialized
INFO - 2018-02-12 02:21:53 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:53 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:53 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
INFO - 2018-02-12 02:21:53 --> Controller Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
INFO - 2018-02-12 02:21:53 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:53 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:53 --> Total execution time: 0.0886
INFO - 2018-02-12 02:21:54 --> Config Class Initialized
INFO - 2018-02-12 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:54 --> URI Class Initialized
INFO - 2018-02-12 02:21:54 --> Router Class Initialized
INFO - 2018-02-12 02:21:54 --> Output Class Initialized
INFO - 2018-02-12 02:21:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:54 --> Input Class Initialized
INFO - 2018-02-12 02:21:54 --> Language Class Initialized
INFO - 2018-02-12 02:21:54 --> Loader Class Initialized
INFO - 2018-02-12 02:21:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Controller Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:54 --> Total execution time: 0.0887
INFO - 2018-02-12 02:21:54 --> Config Class Initialized
INFO - 2018-02-12 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:54 --> URI Class Initialized
INFO - 2018-02-12 02:21:54 --> Router Class Initialized
INFO - 2018-02-12 02:21:54 --> Output Class Initialized
INFO - 2018-02-12 02:21:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:54 --> Input Class Initialized
INFO - 2018-02-12 02:21:54 --> Language Class Initialized
INFO - 2018-02-12 02:21:54 --> Loader Class Initialized
INFO - 2018-02-12 02:21:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Controller Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:54 --> Total execution time: 0.0527
INFO - 2018-02-12 02:21:54 --> Config Class Initialized
INFO - 2018-02-12 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:54 --> URI Class Initialized
INFO - 2018-02-12 02:21:54 --> Router Class Initialized
INFO - 2018-02-12 02:21:54 --> Output Class Initialized
INFO - 2018-02-12 02:21:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:54 --> Input Class Initialized
INFO - 2018-02-12 02:21:54 --> Language Class Initialized
INFO - 2018-02-12 02:21:54 --> Loader Class Initialized
INFO - 2018-02-12 02:21:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Controller Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:54 --> Total execution time: 0.0729
INFO - 2018-02-12 02:21:54 --> Config Class Initialized
INFO - 2018-02-12 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:54 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:54 --> URI Class Initialized
INFO - 2018-02-12 02:21:54 --> Router Class Initialized
INFO - 2018-02-12 02:21:54 --> Output Class Initialized
INFO - 2018-02-12 02:21:54 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:54 --> Input Class Initialized
INFO - 2018-02-12 02:21:54 --> Language Class Initialized
INFO - 2018-02-12 02:21:54 --> Loader Class Initialized
INFO - 2018-02-12 02:21:54 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:54 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:54 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Controller Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
INFO - 2018-02-12 02:21:54 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:54 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:54 --> Total execution time: 0.0465
INFO - 2018-02-12 02:21:59 --> Config Class Initialized
INFO - 2018-02-12 02:21:59 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:59 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:59 --> URI Class Initialized
INFO - 2018-02-12 02:21:59 --> Router Class Initialized
INFO - 2018-02-12 02:21:59 --> Output Class Initialized
INFO - 2018-02-12 02:21:59 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:59 --> Input Class Initialized
INFO - 2018-02-12 02:21:59 --> Language Class Initialized
INFO - 2018-02-12 02:21:59 --> Loader Class Initialized
INFO - 2018-02-12 02:21:59 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:59 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:59 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
INFO - 2018-02-12 02:21:59 --> Controller Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:59 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:59 --> Total execution time: 0.1942
INFO - 2018-02-12 02:21:59 --> Config Class Initialized
INFO - 2018-02-12 02:21:59 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:21:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:21:59 --> Utf8 Class Initialized
INFO - 2018-02-12 02:21:59 --> URI Class Initialized
INFO - 2018-02-12 02:21:59 --> Router Class Initialized
INFO - 2018-02-12 02:21:59 --> Output Class Initialized
INFO - 2018-02-12 02:21:59 --> Security Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:21:59 --> Input Class Initialized
INFO - 2018-02-12 02:21:59 --> Language Class Initialized
INFO - 2018-02-12 02:21:59 --> Loader Class Initialized
INFO - 2018-02-12 02:21:59 --> Helper loaded: url_helper
INFO - 2018-02-12 02:21:59 --> Helper loaded: form_helper
INFO - 2018-02-12 02:21:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:21:59 --> Form Validation Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
INFO - 2018-02-12 02:21:59 --> Controller Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
INFO - 2018-02-12 02:21:59 --> Model Class Initialized
DEBUG - 2018-02-12 02:21:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:21:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:21:59 --> Final output sent to browser
DEBUG - 2018-02-12 02:21:59 --> Total execution time: 0.1491
INFO - 2018-02-12 02:22:43 --> Config Class Initialized
INFO - 2018-02-12 02:22:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:22:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:22:43 --> Utf8 Class Initialized
INFO - 2018-02-12 02:22:43 --> URI Class Initialized
INFO - 2018-02-12 02:22:43 --> Router Class Initialized
INFO - 2018-02-12 02:22:43 --> Output Class Initialized
INFO - 2018-02-12 02:22:43 --> Security Class Initialized
DEBUG - 2018-02-12 02:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:22:43 --> Input Class Initialized
INFO - 2018-02-12 02:22:43 --> Language Class Initialized
INFO - 2018-02-12 02:22:43 --> Loader Class Initialized
INFO - 2018-02-12 02:22:43 --> Helper loaded: url_helper
INFO - 2018-02-12 02:22:43 --> Helper loaded: form_helper
INFO - 2018-02-12 02:22:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:22:43 --> Form Validation Class Initialized
INFO - 2018-02-12 02:22:43 --> Model Class Initialized
INFO - 2018-02-12 02:22:43 --> Controller Class Initialized
INFO - 2018-02-12 02:22:43 --> Model Class Initialized
INFO - 2018-02-12 02:22:43 --> Model Class Initialized
DEBUG - 2018-02-12 02:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:22:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:22:43 --> Final output sent to browser
DEBUG - 2018-02-12 02:22:43 --> Total execution time: 0.0941
INFO - 2018-02-12 02:22:44 --> Config Class Initialized
INFO - 2018-02-12 02:22:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:22:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:22:44 --> Utf8 Class Initialized
INFO - 2018-02-12 02:22:44 --> URI Class Initialized
INFO - 2018-02-12 02:22:44 --> Router Class Initialized
INFO - 2018-02-12 02:22:44 --> Output Class Initialized
INFO - 2018-02-12 02:22:44 --> Security Class Initialized
DEBUG - 2018-02-12 02:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:22:44 --> Input Class Initialized
INFO - 2018-02-12 02:22:44 --> Language Class Initialized
INFO - 2018-02-12 02:22:44 --> Loader Class Initialized
INFO - 2018-02-12 02:22:44 --> Helper loaded: url_helper
INFO - 2018-02-12 02:22:44 --> Helper loaded: form_helper
INFO - 2018-02-12 02:22:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:22:44 --> Form Validation Class Initialized
INFO - 2018-02-12 02:22:44 --> Model Class Initialized
INFO - 2018-02-12 02:22:44 --> Controller Class Initialized
INFO - 2018-02-12 02:22:44 --> Model Class Initialized
INFO - 2018-02-12 02:22:44 --> Model Class Initialized
DEBUG - 2018-02-12 02:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:22:46 --> Config Class Initialized
INFO - 2018-02-12 02:22:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 02:22:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 02:22:46 --> Utf8 Class Initialized
INFO - 2018-02-12 02:22:46 --> URI Class Initialized
INFO - 2018-02-12 02:22:46 --> Router Class Initialized
INFO - 2018-02-12 02:22:46 --> Output Class Initialized
INFO - 2018-02-12 02:22:46 --> Security Class Initialized
DEBUG - 2018-02-12 02:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 02:22:46 --> Input Class Initialized
INFO - 2018-02-12 02:22:46 --> Language Class Initialized
INFO - 2018-02-12 02:22:46 --> Loader Class Initialized
INFO - 2018-02-12 02:22:46 --> Helper loaded: url_helper
INFO - 2018-02-12 02:22:46 --> Helper loaded: form_helper
INFO - 2018-02-12 02:22:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 02:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 02:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 02:22:46 --> Form Validation Class Initialized
INFO - 2018-02-12 02:22:46 --> Model Class Initialized
INFO - 2018-02-12 02:22:46 --> Controller Class Initialized
INFO - 2018-02-12 02:22:46 --> Model Class Initialized
INFO - 2018-02-12 02:22:46 --> Model Class Initialized
DEBUG - 2018-02-12 02:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 02:22:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 02:22:46 --> Final output sent to browser
DEBUG - 2018-02-12 02:22:46 --> Total execution time: 0.0874
INFO - 2018-02-12 07:10:30 --> Config Class Initialized
INFO - 2018-02-12 07:10:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:30 --> URI Class Initialized
INFO - 2018-02-12 07:10:30 --> Router Class Initialized
INFO - 2018-02-12 07:10:30 --> Output Class Initialized
INFO - 2018-02-12 07:10:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:30 --> Input Class Initialized
INFO - 2018-02-12 07:10:30 --> Language Class Initialized
INFO - 2018-02-12 07:10:30 --> Loader Class Initialized
INFO - 2018-02-12 07:10:30 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:30 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:30 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:30 --> Model Class Initialized
INFO - 2018-02-12 07:10:30 --> Controller Class Initialized
INFO - 2018-02-12 07:10:30 --> Model Class Initialized
INFO - 2018-02-12 07:10:30 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:30 --> Config Class Initialized
INFO - 2018-02-12 07:10:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:30 --> URI Class Initialized
INFO - 2018-02-12 07:10:30 --> Router Class Initialized
INFO - 2018-02-12 07:10:30 --> Output Class Initialized
INFO - 2018-02-12 07:10:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:30 --> Input Class Initialized
INFO - 2018-02-12 07:10:30 --> Language Class Initialized
INFO - 2018-02-12 07:10:30 --> Loader Class Initialized
INFO - 2018-02-12 07:10:30 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:30 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:30 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:30 --> Model Class Initialized
INFO - 2018-02-12 07:10:30 --> Controller Class Initialized
INFO - 2018-02-12 07:10:30 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:30 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:30 --> Total execution time: 0.0398
INFO - 2018-02-12 07:10:32 --> Config Class Initialized
INFO - 2018-02-12 07:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:32 --> URI Class Initialized
INFO - 2018-02-12 07:10:32 --> Router Class Initialized
INFO - 2018-02-12 07:10:32 --> Output Class Initialized
INFO - 2018-02-12 07:10:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:32 --> Input Class Initialized
INFO - 2018-02-12 07:10:32 --> Language Class Initialized
INFO - 2018-02-12 07:10:32 --> Loader Class Initialized
INFO - 2018-02-12 07:10:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Controller Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 07:10:32 --> Config Class Initialized
INFO - 2018-02-12 07:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:32 --> URI Class Initialized
DEBUG - 2018-02-12 07:10:32 --> No URI present. Default controller set.
INFO - 2018-02-12 07:10:32 --> Router Class Initialized
INFO - 2018-02-12 07:10:32 --> Output Class Initialized
INFO - 2018-02-12 07:10:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:32 --> Input Class Initialized
INFO - 2018-02-12 07:10:32 --> Language Class Initialized
INFO - 2018-02-12 07:10:32 --> Loader Class Initialized
INFO - 2018-02-12 07:10:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Controller Class Initialized
INFO - 2018-02-12 07:10:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:32 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:32 --> Total execution time: 0.0611
INFO - 2018-02-12 07:10:32 --> Config Class Initialized
INFO - 2018-02-12 07:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:32 --> URI Class Initialized
INFO - 2018-02-12 07:10:32 --> Router Class Initialized
INFO - 2018-02-12 07:10:32 --> Output Class Initialized
INFO - 2018-02-12 07:10:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:32 --> Input Class Initialized
INFO - 2018-02-12 07:10:32 --> Language Class Initialized
INFO - 2018-02-12 07:10:32 --> Loader Class Initialized
INFO - 2018-02-12 07:10:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Controller Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
INFO - 2018-02-12 07:10:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:35 --> Config Class Initialized
INFO - 2018-02-12 07:10:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:35 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:35 --> URI Class Initialized
INFO - 2018-02-12 07:10:35 --> Router Class Initialized
INFO - 2018-02-12 07:10:35 --> Output Class Initialized
INFO - 2018-02-12 07:10:35 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:35 --> Input Class Initialized
INFO - 2018-02-12 07:10:35 --> Language Class Initialized
INFO - 2018-02-12 07:10:35 --> Loader Class Initialized
INFO - 2018-02-12 07:10:35 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:35 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:35 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
INFO - 2018-02-12 07:10:35 --> Controller Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
INFO - 2018-02-12 07:10:35 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:35 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:35 --> Total execution time: 0.0799
INFO - 2018-02-12 07:10:36 --> Config Class Initialized
INFO - 2018-02-12 07:10:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:36 --> URI Class Initialized
INFO - 2018-02-12 07:10:36 --> Router Class Initialized
INFO - 2018-02-12 07:10:36 --> Output Class Initialized
INFO - 2018-02-12 07:10:36 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:36 --> Input Class Initialized
INFO - 2018-02-12 07:10:36 --> Language Class Initialized
INFO - 2018-02-12 07:10:36 --> Loader Class Initialized
INFO - 2018-02-12 07:10:36 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:36 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:36 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
INFO - 2018-02-12 07:10:36 --> Controller Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
INFO - 2018-02-12 07:10:36 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:37 --> Config Class Initialized
INFO - 2018-02-12 07:10:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:37 --> URI Class Initialized
INFO - 2018-02-12 07:10:37 --> Router Class Initialized
INFO - 2018-02-12 07:10:37 --> Output Class Initialized
INFO - 2018-02-12 07:10:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:37 --> Input Class Initialized
INFO - 2018-02-12 07:10:37 --> Language Class Initialized
INFO - 2018-02-12 07:10:37 --> Loader Class Initialized
INFO - 2018-02-12 07:10:37 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:37 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:37 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Controller Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:37 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:37 --> Total execution time: 0.0498
INFO - 2018-02-12 07:10:37 --> Config Class Initialized
INFO - 2018-02-12 07:10:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:37 --> URI Class Initialized
INFO - 2018-02-12 07:10:37 --> Router Class Initialized
INFO - 2018-02-12 07:10:37 --> Output Class Initialized
INFO - 2018-02-12 07:10:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:37 --> Input Class Initialized
INFO - 2018-02-12 07:10:37 --> Language Class Initialized
INFO - 2018-02-12 07:10:37 --> Loader Class Initialized
INFO - 2018-02-12 07:10:37 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:37 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:37 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Controller Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
INFO - 2018-02-12 07:10:37 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:41 --> Config Class Initialized
INFO - 2018-02-12 07:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:41 --> URI Class Initialized
INFO - 2018-02-12 07:10:41 --> Router Class Initialized
INFO - 2018-02-12 07:10:41 --> Output Class Initialized
INFO - 2018-02-12 07:10:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:41 --> Input Class Initialized
INFO - 2018-02-12 07:10:41 --> Language Class Initialized
INFO - 2018-02-12 07:10:41 --> Loader Class Initialized
INFO - 2018-02-12 07:10:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Controller Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:41 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:41 --> Total execution time: 0.0760
INFO - 2018-02-12 07:10:41 --> Config Class Initialized
INFO - 2018-02-12 07:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:41 --> URI Class Initialized
INFO - 2018-02-12 07:10:41 --> Router Class Initialized
INFO - 2018-02-12 07:10:41 --> Output Class Initialized
INFO - 2018-02-12 07:10:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:41 --> Input Class Initialized
INFO - 2018-02-12 07:10:41 --> Language Class Initialized
INFO - 2018-02-12 07:10:41 --> Loader Class Initialized
INFO - 2018-02-12 07:10:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Controller Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:41 --> Config Class Initialized
INFO - 2018-02-12 07:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:41 --> URI Class Initialized
INFO - 2018-02-12 07:10:41 --> Router Class Initialized
INFO - 2018-02-12 07:10:41 --> Output Class Initialized
INFO - 2018-02-12 07:10:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:41 --> Input Class Initialized
INFO - 2018-02-12 07:10:41 --> Language Class Initialized
INFO - 2018-02-12 07:10:41 --> Loader Class Initialized
INFO - 2018-02-12 07:10:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Controller Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:41 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:41 --> Total execution time: 0.0640
INFO - 2018-02-12 07:10:41 --> Config Class Initialized
INFO - 2018-02-12 07:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:41 --> URI Class Initialized
INFO - 2018-02-12 07:10:41 --> Router Class Initialized
INFO - 2018-02-12 07:10:41 --> Output Class Initialized
INFO - 2018-02-12 07:10:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:41 --> Input Class Initialized
INFO - 2018-02-12 07:10:41 --> Language Class Initialized
INFO - 2018-02-12 07:10:41 --> Loader Class Initialized
INFO - 2018-02-12 07:10:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Controller Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
INFO - 2018-02-12 07:10:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:42 --> Total execution time: 0.0536
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:42 --> Total execution time: 0.0621
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:42 --> Total execution time: 0.0640
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:42 --> Total execution time: 0.0572
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Controller Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
INFO - 2018-02-12 07:10:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:42 --> Total execution time: 0.0516
INFO - 2018-02-12 07:10:42 --> Config Class Initialized
INFO - 2018-02-12 07:10:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:42 --> URI Class Initialized
INFO - 2018-02-12 07:10:42 --> Router Class Initialized
INFO - 2018-02-12 07:10:42 --> Output Class Initialized
INFO - 2018-02-12 07:10:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:42 --> Input Class Initialized
INFO - 2018-02-12 07:10:42 --> Language Class Initialized
INFO - 2018-02-12 07:10:42 --> Loader Class Initialized
INFO - 2018-02-12 07:10:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> Config Class Initialized
INFO - 2018-02-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:43 --> URI Class Initialized
INFO - 2018-02-12 07:10:43 --> Router Class Initialized
INFO - 2018-02-12 07:10:43 --> Output Class Initialized
INFO - 2018-02-12 07:10:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:43 --> Input Class Initialized
INFO - 2018-02-12 07:10:43 --> Language Class Initialized
INFO - 2018-02-12 07:10:43 --> Loader Class Initialized
INFO - 2018-02-12 07:10:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:43 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:43 --> Total execution time: 0.0516
INFO - 2018-02-12 07:10:43 --> Config Class Initialized
INFO - 2018-02-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:43 --> URI Class Initialized
INFO - 2018-02-12 07:10:43 --> Router Class Initialized
INFO - 2018-02-12 07:10:43 --> Output Class Initialized
INFO - 2018-02-12 07:10:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:43 --> Input Class Initialized
INFO - 2018-02-12 07:10:43 --> Language Class Initialized
INFO - 2018-02-12 07:10:43 --> Loader Class Initialized
INFO - 2018-02-12 07:10:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> Config Class Initialized
INFO - 2018-02-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:43 --> URI Class Initialized
INFO - 2018-02-12 07:10:43 --> Router Class Initialized
INFO - 2018-02-12 07:10:43 --> Output Class Initialized
INFO - 2018-02-12 07:10:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:43 --> Input Class Initialized
INFO - 2018-02-12 07:10:43 --> Language Class Initialized
INFO - 2018-02-12 07:10:43 --> Loader Class Initialized
INFO - 2018-02-12 07:10:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:43 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:43 --> Total execution time: 0.0705
INFO - 2018-02-12 07:10:43 --> Config Class Initialized
INFO - 2018-02-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:43 --> URI Class Initialized
INFO - 2018-02-12 07:10:43 --> Router Class Initialized
INFO - 2018-02-12 07:10:43 --> Output Class Initialized
INFO - 2018-02-12 07:10:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:43 --> Input Class Initialized
INFO - 2018-02-12 07:10:43 --> Language Class Initialized
INFO - 2018-02-12 07:10:43 --> Loader Class Initialized
INFO - 2018-02-12 07:10:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> Config Class Initialized
INFO - 2018-02-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:43 --> URI Class Initialized
INFO - 2018-02-12 07:10:43 --> Router Class Initialized
INFO - 2018-02-12 07:10:43 --> Output Class Initialized
INFO - 2018-02-12 07:10:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:43 --> Input Class Initialized
INFO - 2018-02-12 07:10:43 --> Language Class Initialized
INFO - 2018-02-12 07:10:43 --> Loader Class Initialized
INFO - 2018-02-12 07:10:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Controller Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
INFO - 2018-02-12 07:10:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:10:43 --> Final output sent to browser
DEBUG - 2018-02-12 07:10:43 --> Total execution time: 0.0621
INFO - 2018-02-12 07:10:44 --> Config Class Initialized
INFO - 2018-02-12 07:10:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:44 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:44 --> URI Class Initialized
INFO - 2018-02-12 07:10:44 --> Router Class Initialized
INFO - 2018-02-12 07:10:44 --> Output Class Initialized
INFO - 2018-02-12 07:10:44 --> Security Class Initialized
DEBUG - 2018-02-12 07:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:44 --> Input Class Initialized
INFO - 2018-02-12 07:10:44 --> Language Class Initialized
INFO - 2018-02-12 07:10:44 --> Loader Class Initialized
INFO - 2018-02-12 07:10:44 --> Helper loaded: url_helper
INFO - 2018-02-12 07:10:44 --> Helper loaded: form_helper
INFO - 2018-02-12 07:10:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:10:44 --> Form Validation Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
INFO - 2018-02-12 07:10:44 --> Controller Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
INFO - 2018-02-12 07:10:44 --> Model Class Initialized
DEBUG - 2018-02-12 07:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:10:57 --> Config Class Initialized
INFO - 2018-02-12 07:10:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:10:57 --> Config Class Initialized
INFO - 2018-02-12 07:10:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:10:57 --> Config Class Initialized
INFO - 2018-02-12 07:10:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:10:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:57 --> URI Class Initialized
DEBUG - 2018-02-12 07:10:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:10:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:10:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:10:57 --> Router Class Initialized
INFO - 2018-02-12 07:10:57 --> URI Class Initialized
INFO - 2018-02-12 07:10:57 --> URI Class Initialized
INFO - 2018-02-12 07:10:57 --> Output Class Initialized
INFO - 2018-02-12 07:10:57 --> Router Class Initialized
INFO - 2018-02-12 07:10:57 --> Router Class Initialized
INFO - 2018-02-12 07:10:57 --> Security Class Initialized
INFO - 2018-02-12 07:10:57 --> Output Class Initialized
INFO - 2018-02-12 07:10:57 --> Output Class Initialized
DEBUG - 2018-02-12 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:57 --> Input Class Initialized
INFO - 2018-02-12 07:10:57 --> Security Class Initialized
INFO - 2018-02-12 07:10:57 --> Security Class Initialized
INFO - 2018-02-12 07:10:57 --> Language Class Initialized
DEBUG - 2018-02-12 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:57 --> Input Class Initialized
ERROR - 2018-02-12 07:10:57 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:10:57 --> Input Class Initialized
INFO - 2018-02-12 07:10:57 --> Language Class Initialized
INFO - 2018-02-12 07:10:57 --> Language Class Initialized
ERROR - 2018-02-12 07:10:57 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:10:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
INFO - 2018-02-12 07:11:00 --> Loader Class Initialized
INFO - 2018-02-12 07:11:00 --> Helper loaded: url_helper
INFO - 2018-02-12 07:11:00 --> Helper loaded: form_helper
INFO - 2018-02-12 07:11:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:11:00 --> Form Validation Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Controller Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:11:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:11:00 --> Final output sent to browser
DEBUG - 2018-02-12 07:11:00 --> Total execution time: 0.0567
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
ERROR - 2018-02-12 07:11:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:11:00 --> Config Class Initialized
INFO - 2018-02-12 07:11:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:11:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:11:00 --> URI Class Initialized
INFO - 2018-02-12 07:11:00 --> Router Class Initialized
INFO - 2018-02-12 07:11:00 --> Output Class Initialized
INFO - 2018-02-12 07:11:00 --> Security Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:11:00 --> Input Class Initialized
INFO - 2018-02-12 07:11:00 --> Language Class Initialized
INFO - 2018-02-12 07:11:00 --> Loader Class Initialized
INFO - 2018-02-12 07:11:00 --> Helper loaded: url_helper
INFO - 2018-02-12 07:11:00 --> Helper loaded: form_helper
INFO - 2018-02-12 07:11:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:11:00 --> Form Validation Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Controller Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
INFO - 2018-02-12 07:11:00 --> Model Class Initialized
DEBUG - 2018-02-12 07:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:14 --> Config Class Initialized
INFO - 2018-02-12 07:12:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:14 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:14 --> URI Class Initialized
INFO - 2018-02-12 07:12:14 --> Router Class Initialized
INFO - 2018-02-12 07:12:14 --> Output Class Initialized
INFO - 2018-02-12 07:12:14 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:14 --> Input Class Initialized
INFO - 2018-02-12 07:12:14 --> Language Class Initialized
INFO - 2018-02-12 07:12:14 --> Loader Class Initialized
INFO - 2018-02-12 07:12:14 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:14 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:14 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
INFO - 2018-02-12 07:12:14 --> Controller Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
INFO - 2018-02-12 07:12:14 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:12:14 --> Final output sent to browser
DEBUG - 2018-02-12 07:12:14 --> Total execution time: 0.0513
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:12:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:12:15 --> Config Class Initialized
INFO - 2018-02-12 07:12:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:15 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:15 --> URI Class Initialized
INFO - 2018-02-12 07:12:15 --> Router Class Initialized
INFO - 2018-02-12 07:12:15 --> Output Class Initialized
INFO - 2018-02-12 07:12:15 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:15 --> Input Class Initialized
INFO - 2018-02-12 07:12:15 --> Language Class Initialized
INFO - 2018-02-12 07:12:15 --> Loader Class Initialized
INFO - 2018-02-12 07:12:15 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:15 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:15 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
INFO - 2018-02-12 07:12:15 --> Controller Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
INFO - 2018-02-12 07:12:15 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
INFO - 2018-02-12 07:12:17 --> Loader Class Initialized
INFO - 2018-02-12 07:12:17 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:17 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:17 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Controller Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:12:17 --> Final output sent to browser
DEBUG - 2018-02-12 07:12:17 --> Total execution time: 0.0528
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:12:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:12:17 --> Config Class Initialized
INFO - 2018-02-12 07:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:17 --> URI Class Initialized
INFO - 2018-02-12 07:12:17 --> Router Class Initialized
INFO - 2018-02-12 07:12:17 --> Output Class Initialized
INFO - 2018-02-12 07:12:17 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:17 --> Input Class Initialized
INFO - 2018-02-12 07:12:17 --> Language Class Initialized
INFO - 2018-02-12 07:12:17 --> Loader Class Initialized
INFO - 2018-02-12 07:12:17 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:17 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:17 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Controller Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
INFO - 2018-02-12 07:12:17 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Loader Class Initialized
INFO - 2018-02-12 07:12:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Controller Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:12:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:12:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:12:42 --> Total execution time: 0.0922
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:12:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:12:42 --> Config Class Initialized
INFO - 2018-02-12 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:12:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:12:42 --> URI Class Initialized
INFO - 2018-02-12 07:12:42 --> Router Class Initialized
INFO - 2018-02-12 07:12:42 --> Output Class Initialized
INFO - 2018-02-12 07:12:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:12:42 --> Input Class Initialized
INFO - 2018-02-12 07:12:42 --> Language Class Initialized
INFO - 2018-02-12 07:12:42 --> Loader Class Initialized
INFO - 2018-02-12 07:12:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:12:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:12:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Controller Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
INFO - 2018-02-12 07:12:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:13:07 --> Config Class Initialized
INFO - 2018-02-12 07:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:07 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:07 --> URI Class Initialized
INFO - 2018-02-12 07:13:07 --> Router Class Initialized
INFO - 2018-02-12 07:13:07 --> Output Class Initialized
INFO - 2018-02-12 07:13:07 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:07 --> Input Class Initialized
INFO - 2018-02-12 07:13:07 --> Language Class Initialized
INFO - 2018-02-12 07:13:07 --> Loader Class Initialized
INFO - 2018-02-12 07:13:07 --> Helper loaded: url_helper
INFO - 2018-02-12 07:13:07 --> Helper loaded: form_helper
INFO - 2018-02-12 07:13:07 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:13:07 --> Form Validation Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
INFO - 2018-02-12 07:13:07 --> Controller Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
INFO - 2018-02-12 07:13:07 --> Model Class Initialized
DEBUG - 2018-02-12 07:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:13:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:13:07 --> Final output sent to browser
DEBUG - 2018-02-12 07:13:07 --> Total execution time: 0.0959
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:13:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:13:08 --> Config Class Initialized
INFO - 2018-02-12 07:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:08 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:08 --> URI Class Initialized
INFO - 2018-02-12 07:13:08 --> Router Class Initialized
INFO - 2018-02-12 07:13:08 --> Output Class Initialized
INFO - 2018-02-12 07:13:08 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:08 --> Input Class Initialized
INFO - 2018-02-12 07:13:08 --> Language Class Initialized
INFO - 2018-02-12 07:13:08 --> Loader Class Initialized
INFO - 2018-02-12 07:13:08 --> Helper loaded: url_helper
INFO - 2018-02-12 07:13:08 --> Helper loaded: form_helper
INFO - 2018-02-12 07:13:08 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:13:08 --> Form Validation Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
INFO - 2018-02-12 07:13:08 --> Controller Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
INFO - 2018-02-12 07:13:08 --> Model Class Initialized
DEBUG - 2018-02-12 07:13:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:13:24 --> Config Class Initialized
INFO - 2018-02-12 07:13:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:24 --> URI Class Initialized
INFO - 2018-02-12 07:13:24 --> Router Class Initialized
INFO - 2018-02-12 07:13:24 --> Output Class Initialized
INFO - 2018-02-12 07:13:24 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:24 --> Input Class Initialized
INFO - 2018-02-12 07:13:24 --> Language Class Initialized
INFO - 2018-02-12 07:13:24 --> Loader Class Initialized
INFO - 2018-02-12 07:13:24 --> Helper loaded: url_helper
INFO - 2018-02-12 07:13:24 --> Helper loaded: form_helper
INFO - 2018-02-12 07:13:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:13:24 --> Form Validation Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
INFO - 2018-02-12 07:13:24 --> Controller Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
INFO - 2018-02-12 07:13:24 --> Model Class Initialized
DEBUG - 2018-02-12 07:13:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:13:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:13:25 --> Final output sent to browser
DEBUG - 2018-02-12 07:13:25 --> Total execution time: 0.1526
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
ERROR - 2018-02-12 07:13:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:13:25 --> Config Class Initialized
INFO - 2018-02-12 07:13:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:13:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:13:25 --> URI Class Initialized
INFO - 2018-02-12 07:13:25 --> Router Class Initialized
INFO - 2018-02-12 07:13:25 --> Output Class Initialized
INFO - 2018-02-12 07:13:25 --> Security Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:13:25 --> Input Class Initialized
INFO - 2018-02-12 07:13:25 --> Language Class Initialized
INFO - 2018-02-12 07:13:25 --> Loader Class Initialized
INFO - 2018-02-12 07:13:25 --> Helper loaded: url_helper
INFO - 2018-02-12 07:13:25 --> Helper loaded: form_helper
INFO - 2018-02-12 07:13:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:13:25 --> Form Validation Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
INFO - 2018-02-12 07:13:25 --> Controller Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
INFO - 2018-02-12 07:13:25 --> Model Class Initialized
DEBUG - 2018-02-12 07:13:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:15:30 --> Config Class Initialized
INFO - 2018-02-12 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:30 --> URI Class Initialized
INFO - 2018-02-12 07:15:30 --> Router Class Initialized
INFO - 2018-02-12 07:15:30 --> Output Class Initialized
INFO - 2018-02-12 07:15:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:30 --> Input Class Initialized
INFO - 2018-02-12 07:15:30 --> Language Class Initialized
INFO - 2018-02-12 07:15:30 --> Loader Class Initialized
INFO - 2018-02-12 07:15:30 --> Helper loaded: url_helper
INFO - 2018-02-12 07:15:30 --> Helper loaded: form_helper
INFO - 2018-02-12 07:15:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:15:30 --> Form Validation Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
INFO - 2018-02-12 07:15:30 --> Controller Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
INFO - 2018-02-12 07:15:30 --> Model Class Initialized
DEBUG - 2018-02-12 07:15:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:15:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:15:30 --> Final output sent to browser
DEBUG - 2018-02-12 07:15:30 --> Total execution time: 0.1195
INFO - 2018-02-12 07:15:30 --> Config Class Initialized
INFO - 2018-02-12 07:15:30 --> Hooks Class Initialized
INFO - 2018-02-12 07:15:30 --> Config Class Initialized
INFO - 2018-02-12 07:15:30 --> Hooks Class Initialized
INFO - 2018-02-12 07:15:30 --> Config Class Initialized
INFO - 2018-02-12 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:30 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:30 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:30 --> URI Class Initialized
INFO - 2018-02-12 07:15:30 --> URI Class Initialized
INFO - 2018-02-12 07:15:30 --> URI Class Initialized
INFO - 2018-02-12 07:15:30 --> Router Class Initialized
INFO - 2018-02-12 07:15:30 --> Router Class Initialized
INFO - 2018-02-12 07:15:30 --> Router Class Initialized
INFO - 2018-02-12 07:15:30 --> Output Class Initialized
INFO - 2018-02-12 07:15:30 --> Output Class Initialized
INFO - 2018-02-12 07:15:30 --> Output Class Initialized
INFO - 2018-02-12 07:15:30 --> Security Class Initialized
INFO - 2018-02-12 07:15:30 --> Security Class Initialized
INFO - 2018-02-12 07:15:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:30 --> Input Class Initialized
DEBUG - 2018-02-12 07:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:30 --> Input Class Initialized
INFO - 2018-02-12 07:15:30 --> Input Class Initialized
INFO - 2018-02-12 07:15:30 --> Language Class Initialized
INFO - 2018-02-12 07:15:30 --> Language Class Initialized
INFO - 2018-02-12 07:15:30 --> Language Class Initialized
ERROR - 2018-02-12 07:15:30 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:15:30 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:15:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:15:30 --> Config Class Initialized
INFO - 2018-02-12 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:30 --> URI Class Initialized
INFO - 2018-02-12 07:15:30 --> Router Class Initialized
INFO - 2018-02-12 07:15:30 --> Output Class Initialized
INFO - 2018-02-12 07:15:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:31 --> Input Class Initialized
INFO - 2018-02-12 07:15:31 --> Language Class Initialized
ERROR - 2018-02-12 07:15:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:15:31 --> Config Class Initialized
INFO - 2018-02-12 07:15:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:15:31 --> Config Class Initialized
INFO - 2018-02-12 07:15:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:15:31 --> Config Class Initialized
INFO - 2018-02-12 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:31 --> URI Class Initialized
INFO - 2018-02-12 07:15:31 --> URI Class Initialized
INFO - 2018-02-12 07:15:31 --> URI Class Initialized
INFO - 2018-02-12 07:15:31 --> Router Class Initialized
INFO - 2018-02-12 07:15:31 --> Router Class Initialized
INFO - 2018-02-12 07:15:31 --> Router Class Initialized
INFO - 2018-02-12 07:15:31 --> Output Class Initialized
INFO - 2018-02-12 07:15:31 --> Output Class Initialized
INFO - 2018-02-12 07:15:31 --> Output Class Initialized
INFO - 2018-02-12 07:15:31 --> Security Class Initialized
INFO - 2018-02-12 07:15:31 --> Security Class Initialized
INFO - 2018-02-12 07:15:31 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:31 --> Input Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:31 --> Input Class Initialized
INFO - 2018-02-12 07:15:31 --> Language Class Initialized
INFO - 2018-02-12 07:15:31 --> Input Class Initialized
INFO - 2018-02-12 07:15:31 --> Language Class Initialized
INFO - 2018-02-12 07:15:31 --> Language Class Initialized
ERROR - 2018-02-12 07:15:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:15:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:15:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:15:31 --> Config Class Initialized
INFO - 2018-02-12 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:15:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:15:31 --> URI Class Initialized
INFO - 2018-02-12 07:15:31 --> Router Class Initialized
INFO - 2018-02-12 07:15:31 --> Output Class Initialized
INFO - 2018-02-12 07:15:31 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:15:31 --> Input Class Initialized
INFO - 2018-02-12 07:15:31 --> Language Class Initialized
INFO - 2018-02-12 07:15:31 --> Loader Class Initialized
INFO - 2018-02-12 07:15:31 --> Helper loaded: url_helper
INFO - 2018-02-12 07:15:31 --> Helper loaded: form_helper
INFO - 2018-02-12 07:15:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:15:31 --> Form Validation Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
INFO - 2018-02-12 07:15:31 --> Controller Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
INFO - 2018-02-12 07:15:31 --> Model Class Initialized
DEBUG - 2018-02-12 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Loader Class Initialized
INFO - 2018-02-12 07:16:03 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:03 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:03 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Controller Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:03 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:03 --> Total execution time: 0.0970
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:03 --> Config Class Initialized
INFO - 2018-02-12 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:03 --> URI Class Initialized
INFO - 2018-02-12 07:16:03 --> Router Class Initialized
INFO - 2018-02-12 07:16:03 --> Output Class Initialized
INFO - 2018-02-12 07:16:03 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:03 --> Input Class Initialized
INFO - 2018-02-12 07:16:03 --> Language Class Initialized
INFO - 2018-02-12 07:16:03 --> Loader Class Initialized
INFO - 2018-02-12 07:16:03 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:03 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:03 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Controller Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
INFO - 2018-02-12 07:16:03 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:18 --> Config Class Initialized
INFO - 2018-02-12 07:16:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:18 --> URI Class Initialized
INFO - 2018-02-12 07:16:18 --> Router Class Initialized
INFO - 2018-02-12 07:16:18 --> Output Class Initialized
INFO - 2018-02-12 07:16:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:18 --> Input Class Initialized
INFO - 2018-02-12 07:16:18 --> Language Class Initialized
INFO - 2018-02-12 07:16:18 --> Loader Class Initialized
INFO - 2018-02-12 07:16:18 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:18 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:18 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
INFO - 2018-02-12 07:16:18 --> Controller Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
INFO - 2018-02-12 07:16:18 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:18 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:18 --> Total execution time: 0.0920
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:19 --> Config Class Initialized
INFO - 2018-02-12 07:16:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:19 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:19 --> URI Class Initialized
INFO - 2018-02-12 07:16:19 --> Router Class Initialized
INFO - 2018-02-12 07:16:19 --> Output Class Initialized
INFO - 2018-02-12 07:16:19 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:19 --> Input Class Initialized
INFO - 2018-02-12 07:16:19 --> Language Class Initialized
INFO - 2018-02-12 07:16:19 --> Loader Class Initialized
INFO - 2018-02-12 07:16:19 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:19 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:19 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
INFO - 2018-02-12 07:16:19 --> Controller Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
INFO - 2018-02-12 07:16:19 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
INFO - 2018-02-12 07:16:41 --> Loader Class Initialized
INFO - 2018-02-12 07:16:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Controller Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:41 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:41 --> Total execution time: 0.0582
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:41 --> Config Class Initialized
INFO - 2018-02-12 07:16:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:41 --> URI Class Initialized
INFO - 2018-02-12 07:16:41 --> Router Class Initialized
INFO - 2018-02-12 07:16:41 --> Output Class Initialized
INFO - 2018-02-12 07:16:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:41 --> Input Class Initialized
INFO - 2018-02-12 07:16:41 --> Language Class Initialized
INFO - 2018-02-12 07:16:41 --> Loader Class Initialized
INFO - 2018-02-12 07:16:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Controller Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
INFO - 2018-02-12 07:16:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
INFO - 2018-02-12 07:16:43 --> Loader Class Initialized
INFO - 2018-02-12 07:16:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Controller Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:43 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:43 --> Total execution time: 0.0507
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:43 --> Config Class Initialized
INFO - 2018-02-12 07:16:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:43 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:43 --> URI Class Initialized
INFO - 2018-02-12 07:16:43 --> Router Class Initialized
INFO - 2018-02-12 07:16:43 --> Output Class Initialized
INFO - 2018-02-12 07:16:43 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:43 --> Input Class Initialized
INFO - 2018-02-12 07:16:43 --> Language Class Initialized
INFO - 2018-02-12 07:16:43 --> Loader Class Initialized
INFO - 2018-02-12 07:16:43 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:43 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:43 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Controller Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
INFO - 2018-02-12 07:16:43 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:45 --> Config Class Initialized
INFO - 2018-02-12 07:16:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:45 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:45 --> URI Class Initialized
INFO - 2018-02-12 07:16:45 --> Router Class Initialized
INFO - 2018-02-12 07:16:45 --> Output Class Initialized
INFO - 2018-02-12 07:16:45 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:45 --> Input Class Initialized
INFO - 2018-02-12 07:16:45 --> Language Class Initialized
INFO - 2018-02-12 07:16:45 --> Loader Class Initialized
INFO - 2018-02-12 07:16:45 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:45 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:45 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
INFO - 2018-02-12 07:16:45 --> Controller Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
INFO - 2018-02-12 07:16:45 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:45 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:45 --> Total execution time: 0.0541
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:16:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> Config Class Initialized
INFO - 2018-02-12 07:16:46 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
DEBUG - 2018-02-12 07:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:46 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> URI Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Router Class Initialized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Output Class Initialized
INFO - 2018-02-12 07:16:46 --> Security Class Initialized
INFO - 2018-02-12 07:16:46 --> Loader Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:46 --> Input Class Initialized
INFO - 2018-02-12 07:16:46 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:46 --> Language Class Initialized
INFO - 2018-02-12 07:16:46 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:46 --> Loader Class Initialized
INFO - 2018-02-12 07:16:46 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:46 --> Database Driver Class Initialized
INFO - 2018-02-12 07:16:46 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 07:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:46 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Controller Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:46 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Controller Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
INFO - 2018-02-12 07:16:46 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> Router Class Initialized
INFO - 2018-02-12 07:16:54 --> Output Class Initialized
INFO - 2018-02-12 07:16:54 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:54 --> Input Class Initialized
INFO - 2018-02-12 07:16:54 --> Language Class Initialized
INFO - 2018-02-12 07:16:54 --> Loader Class Initialized
INFO - 2018-02-12 07:16:54 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:54 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:54 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
INFO - 2018-02-12 07:16:54 --> Controller Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
INFO - 2018-02-12 07:16:54 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:54 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:54 --> Total execution time: 0.3689
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> Router Class Initialized
INFO - 2018-02-12 07:16:54 --> Router Class Initialized
INFO - 2018-02-12 07:16:54 --> Router Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:54 --> Output Class Initialized
INFO - 2018-02-12 07:16:54 --> Output Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> Output Class Initialized
INFO - 2018-02-12 07:16:54 --> Security Class Initialized
INFO - 2018-02-12 07:16:54 --> Security Class Initialized
INFO - 2018-02-12 07:16:54 --> Router Class Initialized
INFO - 2018-02-12 07:16:54 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:54 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:54 --> Input Class Initialized
INFO - 2018-02-12 07:16:54 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:54 --> Output Class Initialized
INFO - 2018-02-12 07:16:54 --> Input Class Initialized
INFO - 2018-02-12 07:16:54 --> Language Class Initialized
INFO - 2018-02-12 07:16:54 --> Language Class Initialized
ERROR - 2018-02-12 07:16:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:54 --> Security Class Initialized
ERROR - 2018-02-12 07:16:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:16:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:54 --> Input Class Initialized
INFO - 2018-02-12 07:16:54 --> Language Class Initialized
ERROR - 2018-02-12 07:16:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:54 --> Config Class Initialized
INFO - 2018-02-12 07:16:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:54 --> URI Class Initialized
INFO - 2018-02-12 07:16:54 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:55 --> Router Class Initialized
INFO - 2018-02-12 07:16:55 --> URI Class Initialized
INFO - 2018-02-12 07:16:55 --> Router Class Initialized
INFO - 2018-02-12 07:16:55 --> Output Class Initialized
INFO - 2018-02-12 07:16:55 --> Router Class Initialized
INFO - 2018-02-12 07:16:55 --> Output Class Initialized
INFO - 2018-02-12 07:16:55 --> Security Class Initialized
INFO - 2018-02-12 07:16:55 --> Security Class Initialized
INFO - 2018-02-12 07:16:55 --> Output Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:55 --> Input Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:55 --> Input Class Initialized
INFO - 2018-02-12 07:16:55 --> Security Class Initialized
INFO - 2018-02-12 07:16:55 --> Language Class Initialized
INFO - 2018-02-12 07:16:55 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:16:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:55 --> Input Class Initialized
ERROR - 2018-02-12 07:16:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:55 --> Language Class Initialized
ERROR - 2018-02-12 07:16:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:55 --> Config Class Initialized
INFO - 2018-02-12 07:16:55 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:55 --> Config Class Initialized
INFO - 2018-02-12 07:16:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:55 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:55 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:55 --> URI Class Initialized
INFO - 2018-02-12 07:16:55 --> URI Class Initialized
INFO - 2018-02-12 07:16:55 --> Router Class Initialized
INFO - 2018-02-12 07:16:55 --> Router Class Initialized
INFO - 2018-02-12 07:16:55 --> Output Class Initialized
INFO - 2018-02-12 07:16:55 --> Output Class Initialized
INFO - 2018-02-12 07:16:55 --> Security Class Initialized
INFO - 2018-02-12 07:16:55 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:55 --> Input Class Initialized
INFO - 2018-02-12 07:16:55 --> Input Class Initialized
INFO - 2018-02-12 07:16:55 --> Language Class Initialized
INFO - 2018-02-12 07:16:55 --> Language Class Initialized
INFO - 2018-02-12 07:16:55 --> Loader Class Initialized
INFO - 2018-02-12 07:16:55 --> Loader Class Initialized
INFO - 2018-02-12 07:16:55 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:55 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:55 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:55 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:55 --> Database Driver Class Initialized
INFO - 2018-02-12 07:16:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 07:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:55 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Controller Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:55 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Controller Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
INFO - 2018-02-12 07:16:55 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
INFO - 2018-02-12 07:16:57 --> Loader Class Initialized
INFO - 2018-02-12 07:16:57 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:57 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:57 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Controller Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:16:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:16:57 --> Final output sent to browser
DEBUG - 2018-02-12 07:16:57 --> Total execution time: 0.0658
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
ERROR - 2018-02-12 07:16:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:16:57 --> Config Class Initialized
INFO - 2018-02-12 07:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:16:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:16:57 --> URI Class Initialized
INFO - 2018-02-12 07:16:57 --> Router Class Initialized
INFO - 2018-02-12 07:16:57 --> Output Class Initialized
INFO - 2018-02-12 07:16:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:16:57 --> Input Class Initialized
INFO - 2018-02-12 07:16:57 --> Language Class Initialized
INFO - 2018-02-12 07:16:57 --> Loader Class Initialized
INFO - 2018-02-12 07:16:57 --> Helper loaded: url_helper
INFO - 2018-02-12 07:16:57 --> Helper loaded: form_helper
INFO - 2018-02-12 07:16:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:16:57 --> Form Validation Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Controller Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
INFO - 2018-02-12 07:16:57 --> Model Class Initialized
DEBUG - 2018-02-12 07:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Loader Class Initialized
INFO - 2018-02-12 07:17:01 --> Helper loaded: url_helper
INFO - 2018-02-12 07:17:01 --> Helper loaded: form_helper
INFO - 2018-02-12 07:17:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:17:01 --> Form Validation Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Controller Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:17:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:17:01 --> Final output sent to browser
DEBUG - 2018-02-12 07:17:01 --> Total execution time: 0.0704
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:17:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:17:01 --> Config Class Initialized
INFO - 2018-02-12 07:17:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:01 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:01 --> URI Class Initialized
INFO - 2018-02-12 07:17:01 --> Router Class Initialized
INFO - 2018-02-12 07:17:01 --> Output Class Initialized
INFO - 2018-02-12 07:17:01 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:01 --> Input Class Initialized
INFO - 2018-02-12 07:17:01 --> Language Class Initialized
INFO - 2018-02-12 07:17:01 --> Loader Class Initialized
INFO - 2018-02-12 07:17:01 --> Helper loaded: url_helper
INFO - 2018-02-12 07:17:01 --> Helper loaded: form_helper
INFO - 2018-02-12 07:17:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:17:01 --> Form Validation Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Controller Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
INFO - 2018-02-12 07:17:01 --> Model Class Initialized
DEBUG - 2018-02-12 07:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:17:20 --> Config Class Initialized
INFO - 2018-02-12 07:17:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:17:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:20 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:20 --> URI Class Initialized
INFO - 2018-02-12 07:17:20 --> Router Class Initialized
INFO - 2018-02-12 07:17:20 --> Output Class Initialized
INFO - 2018-02-12 07:17:20 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:20 --> Input Class Initialized
INFO - 2018-02-12 07:17:20 --> Language Class Initialized
INFO - 2018-02-12 07:17:20 --> Loader Class Initialized
INFO - 2018-02-12 07:17:20 --> Helper loaded: url_helper
INFO - 2018-02-12 07:17:20 --> Helper loaded: form_helper
INFO - 2018-02-12 07:17:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:17:20 --> Form Validation Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
INFO - 2018-02-12 07:17:20 --> Controller Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
INFO - 2018-02-12 07:17:20 --> Model Class Initialized
DEBUG - 2018-02-12 07:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:17:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:17:20 --> Final output sent to browser
DEBUG - 2018-02-12 07:17:20 --> Total execution time: 0.0681
INFO - 2018-02-12 07:17:21 --> Config Class Initialized
INFO - 2018-02-12 07:17:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:17:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:17:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:17:21 --> URI Class Initialized
INFO - 2018-02-12 07:17:21 --> Router Class Initialized
INFO - 2018-02-12 07:17:21 --> Output Class Initialized
INFO - 2018-02-12 07:17:21 --> Security Class Initialized
DEBUG - 2018-02-12 07:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:17:21 --> Input Class Initialized
INFO - 2018-02-12 07:17:21 --> Language Class Initialized
INFO - 2018-02-12 07:17:21 --> Loader Class Initialized
INFO - 2018-02-12 07:17:21 --> Helper loaded: url_helper
INFO - 2018-02-12 07:17:21 --> Helper loaded: form_helper
INFO - 2018-02-12 07:17:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:17:21 --> Form Validation Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
INFO - 2018-02-12 07:17:21 --> Controller Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
INFO - 2018-02-12 07:17:21 --> Model Class Initialized
DEBUG - 2018-02-12 07:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:13 --> Config Class Initialized
INFO - 2018-02-12 07:20:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:13 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:13 --> URI Class Initialized
INFO - 2018-02-12 07:20:13 --> Router Class Initialized
INFO - 2018-02-12 07:20:13 --> Output Class Initialized
INFO - 2018-02-12 07:20:13 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:13 --> Input Class Initialized
INFO - 2018-02-12 07:20:13 --> Language Class Initialized
INFO - 2018-02-12 07:20:13 --> Loader Class Initialized
INFO - 2018-02-12 07:20:13 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:13 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:13 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Controller Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:20:13 --> Final output sent to browser
DEBUG - 2018-02-12 07:20:13 --> Total execution time: 0.1218
INFO - 2018-02-12 07:20:13 --> Config Class Initialized
INFO - 2018-02-12 07:20:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:13 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:13 --> URI Class Initialized
INFO - 2018-02-12 07:20:13 --> Router Class Initialized
INFO - 2018-02-12 07:20:13 --> Output Class Initialized
INFO - 2018-02-12 07:20:13 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:13 --> Input Class Initialized
INFO - 2018-02-12 07:20:13 --> Language Class Initialized
INFO - 2018-02-12 07:20:13 --> Loader Class Initialized
INFO - 2018-02-12 07:20:13 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:13 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:13 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Controller Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
INFO - 2018-02-12 07:20:13 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Config Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> URI Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
INFO - 2018-02-12 07:20:17 --> Router Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Output Class Initialized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
INFO - 2018-02-12 07:20:17 --> Security Class Initialized
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
DEBUG - 2018-02-12 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:17 --> Input Class Initialized
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
INFO - 2018-02-12 07:20:17 --> Language Class Initialized
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:20:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
INFO - 2018-02-12 07:20:37 --> Loader Class Initialized
INFO - 2018-02-12 07:20:37 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:37 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:37 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Controller Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:20:37 --> Final output sent to browser
DEBUG - 2018-02-12 07:20:37 --> Total execution time: 0.0959
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:20:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:20:37 --> Config Class Initialized
INFO - 2018-02-12 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:37 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:37 --> URI Class Initialized
INFO - 2018-02-12 07:20:37 --> Router Class Initialized
INFO - 2018-02-12 07:20:37 --> Output Class Initialized
INFO - 2018-02-12 07:20:37 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:37 --> Input Class Initialized
INFO - 2018-02-12 07:20:37 --> Language Class Initialized
INFO - 2018-02-12 07:20:37 --> Loader Class Initialized
INFO - 2018-02-12 07:20:37 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:37 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:37 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Controller Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
INFO - 2018-02-12 07:20:37 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:44 --> Config Class Initialized
INFO - 2018-02-12 07:20:44 --> Hooks Class Initialized
INFO - 2018-02-12 07:20:44 --> Config Class Initialized
INFO - 2018-02-12 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:44 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:44 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:44 --> URI Class Initialized
INFO - 2018-02-12 07:20:44 --> URI Class Initialized
INFO - 2018-02-12 07:20:44 --> Router Class Initialized
INFO - 2018-02-12 07:20:44 --> Router Class Initialized
INFO - 2018-02-12 07:20:44 --> Output Class Initialized
INFO - 2018-02-12 07:20:44 --> Output Class Initialized
INFO - 2018-02-12 07:20:44 --> Security Class Initialized
INFO - 2018-02-12 07:20:44 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:44 --> Input Class Initialized
INFO - 2018-02-12 07:20:44 --> Input Class Initialized
INFO - 2018-02-12 07:20:44 --> Language Class Initialized
INFO - 2018-02-12 07:20:44 --> Language Class Initialized
INFO - 2018-02-12 07:20:44 --> Loader Class Initialized
INFO - 2018-02-12 07:20:44 --> Loader Class Initialized
INFO - 2018-02-12 07:20:44 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:44 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:44 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:44 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:44 --> Database Driver Class Initialized
INFO - 2018-02-12 07:20:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 07:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:44 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Controller Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:44 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Controller Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
INFO - 2018-02-12 07:20:44 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:48 --> Config Class Initialized
INFO - 2018-02-12 07:20:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:48 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:48 --> URI Class Initialized
INFO - 2018-02-12 07:20:48 --> Router Class Initialized
INFO - 2018-02-12 07:20:48 --> Output Class Initialized
INFO - 2018-02-12 07:20:48 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:48 --> Input Class Initialized
INFO - 2018-02-12 07:20:48 --> Language Class Initialized
INFO - 2018-02-12 07:20:48 --> Loader Class Initialized
INFO - 2018-02-12 07:20:48 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:48 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:48 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
INFO - 2018-02-12 07:20:48 --> Controller Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
INFO - 2018-02-12 07:20:48 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:20:48 --> Final output sent to browser
DEBUG - 2018-02-12 07:20:48 --> Total execution time: 0.0736
INFO - 2018-02-12 07:20:49 --> Config Class Initialized
INFO - 2018-02-12 07:20:49 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:49 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:49 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:49 --> URI Class Initialized
INFO - 2018-02-12 07:20:49 --> Router Class Initialized
INFO - 2018-02-12 07:20:49 --> Output Class Initialized
INFO - 2018-02-12 07:20:49 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:49 --> Input Class Initialized
INFO - 2018-02-12 07:20:49 --> Language Class Initialized
INFO - 2018-02-12 07:20:49 --> Loader Class Initialized
INFO - 2018-02-12 07:20:49 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:49 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:49 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:49 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
INFO - 2018-02-12 07:20:49 --> Controller Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
INFO - 2018-02-12 07:20:49 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:53 --> Config Class Initialized
INFO - 2018-02-12 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:53 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:53 --> URI Class Initialized
INFO - 2018-02-12 07:20:53 --> Router Class Initialized
INFO - 2018-02-12 07:20:53 --> Output Class Initialized
INFO - 2018-02-12 07:20:53 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:53 --> Input Class Initialized
INFO - 2018-02-12 07:20:53 --> Language Class Initialized
INFO - 2018-02-12 07:20:53 --> Loader Class Initialized
INFO - 2018-02-12 07:20:53 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:53 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:53 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Controller Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:20:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:20:53 --> Final output sent to browser
DEBUG - 2018-02-12 07:20:53 --> Total execution time: 0.0549
INFO - 2018-02-12 07:20:53 --> Config Class Initialized
INFO - 2018-02-12 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:20:53 --> Utf8 Class Initialized
INFO - 2018-02-12 07:20:53 --> URI Class Initialized
INFO - 2018-02-12 07:20:53 --> Router Class Initialized
INFO - 2018-02-12 07:20:53 --> Output Class Initialized
INFO - 2018-02-12 07:20:53 --> Security Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:20:53 --> Input Class Initialized
INFO - 2018-02-12 07:20:53 --> Language Class Initialized
INFO - 2018-02-12 07:20:53 --> Loader Class Initialized
INFO - 2018-02-12 07:20:53 --> Helper loaded: url_helper
INFO - 2018-02-12 07:20:53 --> Helper loaded: form_helper
INFO - 2018-02-12 07:20:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:20:53 --> Form Validation Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Controller Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
INFO - 2018-02-12 07:20:53 --> Model Class Initialized
DEBUG - 2018-02-12 07:20:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:21:00 --> Config Class Initialized
INFO - 2018-02-12 07:21:00 --> Hooks Class Initialized
INFO - 2018-02-12 07:21:00 --> Config Class Initialized
INFO - 2018-02-12 07:21:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:21:00 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:21:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:21:00 --> Utf8 Class Initialized
INFO - 2018-02-12 07:21:00 --> URI Class Initialized
INFO - 2018-02-12 07:21:00 --> URI Class Initialized
INFO - 2018-02-12 07:21:00 --> Router Class Initialized
INFO - 2018-02-12 07:21:00 --> Router Class Initialized
INFO - 2018-02-12 07:21:00 --> Output Class Initialized
INFO - 2018-02-12 07:21:00 --> Output Class Initialized
INFO - 2018-02-12 07:21:00 --> Security Class Initialized
INFO - 2018-02-12 07:21:00 --> Security Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:21:00 --> Input Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:21:00 --> Language Class Initialized
INFO - 2018-02-12 07:21:00 --> Input Class Initialized
INFO - 2018-02-12 07:21:00 --> Language Class Initialized
INFO - 2018-02-12 07:21:00 --> Loader Class Initialized
INFO - 2018-02-12 07:21:00 --> Loader Class Initialized
INFO - 2018-02-12 07:21:00 --> Helper loaded: url_helper
INFO - 2018-02-12 07:21:00 --> Helper loaded: url_helper
INFO - 2018-02-12 07:21:00 --> Helper loaded: form_helper
INFO - 2018-02-12 07:21:00 --> Helper loaded: form_helper
INFO - 2018-02-12 07:21:00 --> Database Driver Class Initialized
INFO - 2018-02-12 07:21:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:21:00 --> Form Validation Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Controller Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:21:00 --> Form Validation Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Controller Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
INFO - 2018-02-12 07:21:00 --> Model Class Initialized
DEBUG - 2018-02-12 07:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:21:03 --> Config Class Initialized
INFO - 2018-02-12 07:21:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:21:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:21:03 --> Utf8 Class Initialized
INFO - 2018-02-12 07:21:03 --> URI Class Initialized
INFO - 2018-02-12 07:21:03 --> Router Class Initialized
INFO - 2018-02-12 07:21:03 --> Output Class Initialized
INFO - 2018-02-12 07:21:03 --> Security Class Initialized
DEBUG - 2018-02-12 07:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:21:03 --> Input Class Initialized
INFO - 2018-02-12 07:21:03 --> Language Class Initialized
INFO - 2018-02-12 07:21:03 --> Loader Class Initialized
INFO - 2018-02-12 07:21:03 --> Helper loaded: url_helper
INFO - 2018-02-12 07:21:03 --> Helper loaded: form_helper
INFO - 2018-02-12 07:21:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:21:03 --> Form Validation Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
INFO - 2018-02-12 07:21:03 --> Controller Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
INFO - 2018-02-12 07:21:03 --> Model Class Initialized
DEBUG - 2018-02-12 07:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:21:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:21:03 --> Final output sent to browser
DEBUG - 2018-02-12 07:21:03 --> Total execution time: 0.0736
INFO - 2018-02-12 07:21:04 --> Config Class Initialized
INFO - 2018-02-12 07:21:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:21:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:21:04 --> Utf8 Class Initialized
INFO - 2018-02-12 07:21:04 --> URI Class Initialized
INFO - 2018-02-12 07:21:04 --> Router Class Initialized
INFO - 2018-02-12 07:21:04 --> Output Class Initialized
INFO - 2018-02-12 07:21:04 --> Security Class Initialized
DEBUG - 2018-02-12 07:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:21:04 --> Input Class Initialized
INFO - 2018-02-12 07:21:04 --> Language Class Initialized
INFO - 2018-02-12 07:21:04 --> Loader Class Initialized
INFO - 2018-02-12 07:21:04 --> Helper loaded: url_helper
INFO - 2018-02-12 07:21:04 --> Helper loaded: form_helper
INFO - 2018-02-12 07:21:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:21:04 --> Form Validation Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
INFO - 2018-02-12 07:21:04 --> Controller Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
INFO - 2018-02-12 07:21:04 --> Model Class Initialized
DEBUG - 2018-02-12 07:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:26 --> Config Class Initialized
INFO - 2018-02-12 07:22:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:26 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:26 --> URI Class Initialized
INFO - 2018-02-12 07:22:26 --> Router Class Initialized
INFO - 2018-02-12 07:22:26 --> Output Class Initialized
INFO - 2018-02-12 07:22:26 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:26 --> Input Class Initialized
INFO - 2018-02-12 07:22:26 --> Language Class Initialized
INFO - 2018-02-12 07:22:26 --> Loader Class Initialized
INFO - 2018-02-12 07:22:26 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:26 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:26 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
INFO - 2018-02-12 07:22:26 --> Controller Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:26 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:26 --> Total execution time: 0.0541
INFO - 2018-02-12 07:22:26 --> Config Class Initialized
INFO - 2018-02-12 07:22:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:26 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:26 --> URI Class Initialized
INFO - 2018-02-12 07:22:26 --> Router Class Initialized
INFO - 2018-02-12 07:22:26 --> Output Class Initialized
INFO - 2018-02-12 07:22:26 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:26 --> Input Class Initialized
INFO - 2018-02-12 07:22:26 --> Language Class Initialized
INFO - 2018-02-12 07:22:26 --> Loader Class Initialized
INFO - 2018-02-12 07:22:26 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:26 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:26 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
INFO - 2018-02-12 07:22:26 --> Controller Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
INFO - 2018-02-12 07:22:26 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:28 --> Config Class Initialized
INFO - 2018-02-12 07:22:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:28 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:28 --> URI Class Initialized
INFO - 2018-02-12 07:22:28 --> Router Class Initialized
INFO - 2018-02-12 07:22:28 --> Output Class Initialized
INFO - 2018-02-12 07:22:28 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:28 --> Input Class Initialized
INFO - 2018-02-12 07:22:28 --> Language Class Initialized
INFO - 2018-02-12 07:22:28 --> Loader Class Initialized
INFO - 2018-02-12 07:22:28 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:28 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:28 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:28 --> Model Class Initialized
INFO - 2018-02-12 07:22:28 --> Controller Class Initialized
INFO - 2018-02-12 07:22:28 --> Model Class Initialized
INFO - 2018-02-12 07:22:28 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:28 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:28 --> Total execution time: 0.0558
INFO - 2018-02-12 07:22:31 --> Config Class Initialized
INFO - 2018-02-12 07:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:31 --> URI Class Initialized
INFO - 2018-02-12 07:22:31 --> Router Class Initialized
INFO - 2018-02-12 07:22:31 --> Output Class Initialized
INFO - 2018-02-12 07:22:31 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:31 --> Input Class Initialized
INFO - 2018-02-12 07:22:31 --> Language Class Initialized
INFO - 2018-02-12 07:22:31 --> Loader Class Initialized
INFO - 2018-02-12 07:22:31 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:31 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Controller Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:32 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:32 --> Total execution time: 0.0788
INFO - 2018-02-12 07:22:32 --> Config Class Initialized
INFO - 2018-02-12 07:22:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:32 --> URI Class Initialized
INFO - 2018-02-12 07:22:32 --> Router Class Initialized
INFO - 2018-02-12 07:22:32 --> Output Class Initialized
INFO - 2018-02-12 07:22:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:32 --> Input Class Initialized
INFO - 2018-02-12 07:22:32 --> Language Class Initialized
INFO - 2018-02-12 07:22:32 --> Loader Class Initialized
INFO - 2018-02-12 07:22:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Controller Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:32 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:32 --> Total execution time: 0.0586
INFO - 2018-02-12 07:22:32 --> Config Class Initialized
INFO - 2018-02-12 07:22:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:32 --> URI Class Initialized
INFO - 2018-02-12 07:22:32 --> Router Class Initialized
INFO - 2018-02-12 07:22:32 --> Output Class Initialized
INFO - 2018-02-12 07:22:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:32 --> Input Class Initialized
INFO - 2018-02-12 07:22:32 --> Language Class Initialized
INFO - 2018-02-12 07:22:32 --> Loader Class Initialized
INFO - 2018-02-12 07:22:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Controller Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
INFO - 2018-02-12 07:22:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:32 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:32 --> Total execution time: 0.0531
INFO - 2018-02-12 07:22:33 --> Config Class Initialized
INFO - 2018-02-12 07:22:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:33 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:33 --> URI Class Initialized
INFO - 2018-02-12 07:22:33 --> Router Class Initialized
INFO - 2018-02-12 07:22:33 --> Output Class Initialized
INFO - 2018-02-12 07:22:33 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:33 --> Input Class Initialized
INFO - 2018-02-12 07:22:33 --> Language Class Initialized
INFO - 2018-02-12 07:22:33 --> Loader Class Initialized
INFO - 2018-02-12 07:22:33 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:33 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:33 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:33 --> Model Class Initialized
INFO - 2018-02-12 07:22:33 --> Controller Class Initialized
INFO - 2018-02-12 07:22:33 --> Model Class Initialized
INFO - 2018-02-12 07:22:33 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:33 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:33 --> Total execution time: 0.0608
INFO - 2018-02-12 07:22:36 --> Config Class Initialized
INFO - 2018-02-12 07:22:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:36 --> URI Class Initialized
INFO - 2018-02-12 07:22:36 --> Router Class Initialized
INFO - 2018-02-12 07:22:36 --> Output Class Initialized
INFO - 2018-02-12 07:22:36 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:36 --> Input Class Initialized
INFO - 2018-02-12 07:22:36 --> Language Class Initialized
INFO - 2018-02-12 07:22:36 --> Loader Class Initialized
INFO - 2018-02-12 07:22:36 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:36 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:36 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:36 --> Model Class Initialized
INFO - 2018-02-12 07:22:36 --> Controller Class Initialized
INFO - 2018-02-12 07:22:36 --> Model Class Initialized
INFO - 2018-02-12 07:22:36 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:36 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:36 --> Total execution time: 0.1434
INFO - 2018-02-12 07:22:42 --> Config Class Initialized
INFO - 2018-02-12 07:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:22:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:22:42 --> URI Class Initialized
INFO - 2018-02-12 07:22:42 --> Router Class Initialized
INFO - 2018-02-12 07:22:42 --> Output Class Initialized
INFO - 2018-02-12 07:22:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:22:42 --> Input Class Initialized
INFO - 2018-02-12 07:22:42 --> Language Class Initialized
INFO - 2018-02-12 07:22:42 --> Loader Class Initialized
INFO - 2018-02-12 07:22:42 --> Helper loaded: url_helper
INFO - 2018-02-12 07:22:42 --> Helper loaded: form_helper
INFO - 2018-02-12 07:22:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:22:42 --> Form Validation Class Initialized
INFO - 2018-02-12 07:22:42 --> Model Class Initialized
INFO - 2018-02-12 07:22:42 --> Controller Class Initialized
INFO - 2018-02-12 07:22:42 --> Model Class Initialized
INFO - 2018-02-12 07:22:42 --> Model Class Initialized
DEBUG - 2018-02-12 07:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:22:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:22:42 --> Final output sent to browser
DEBUG - 2018-02-12 07:22:42 --> Total execution time: 0.1231
INFO - 2018-02-12 07:25:20 --> Config Class Initialized
INFO - 2018-02-12 07:25:20 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:20 --> Config Class Initialized
INFO - 2018-02-12 07:25:20 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:20 --> Config Class Initialized
INFO - 2018-02-12 07:25:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:20 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:20 --> URI Class Initialized
INFO - 2018-02-12 07:25:20 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:20 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:20 --> URI Class Initialized
INFO - 2018-02-12 07:25:20 --> URI Class Initialized
INFO - 2018-02-12 07:25:20 --> Router Class Initialized
INFO - 2018-02-12 07:25:20 --> Router Class Initialized
INFO - 2018-02-12 07:25:20 --> Router Class Initialized
INFO - 2018-02-12 07:25:20 --> Output Class Initialized
INFO - 2018-02-12 07:25:20 --> Output Class Initialized
INFO - 2018-02-12 07:25:20 --> Output Class Initialized
INFO - 2018-02-12 07:25:20 --> Security Class Initialized
INFO - 2018-02-12 07:25:20 --> Security Class Initialized
INFO - 2018-02-12 07:25:20 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:20 --> Input Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:20 --> Language Class Initialized
INFO - 2018-02-12 07:25:20 --> Input Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:20 --> Input Class Initialized
INFO - 2018-02-12 07:25:20 --> Language Class Initialized
INFO - 2018-02-12 07:25:20 --> Language Class Initialized
ERROR - 2018-02-12 07:25:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:25:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:25:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:25:20 --> Config Class Initialized
INFO - 2018-02-12 07:25:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:20 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:20 --> URI Class Initialized
INFO - 2018-02-12 07:25:20 --> Router Class Initialized
INFO - 2018-02-12 07:25:20 --> Output Class Initialized
INFO - 2018-02-12 07:25:20 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:20 --> Input Class Initialized
INFO - 2018-02-12 07:25:20 --> Language Class Initialized
INFO - 2018-02-12 07:25:20 --> Loader Class Initialized
INFO - 2018-02-12 07:25:20 --> Helper loaded: url_helper
INFO - 2018-02-12 07:25:20 --> Helper loaded: form_helper
INFO - 2018-02-12 07:25:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:25:20 --> Form Validation Class Initialized
INFO - 2018-02-12 07:25:20 --> Model Class Initialized
INFO - 2018-02-12 07:25:20 --> Controller Class Initialized
INFO - 2018-02-12 07:25:20 --> Model Class Initialized
INFO - 2018-02-12 07:25:20 --> Model Class Initialized
DEBUG - 2018-02-12 07:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:25:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:25:21 --> Final output sent to browser
DEBUG - 2018-02-12 07:25:21 --> Total execution time: 0.1356
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Config Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
DEBUG - 2018-02-12 07:25:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:21 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> URI Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
INFO - 2018-02-12 07:25:21 --> Router Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
INFO - 2018-02-12 07:25:21 --> Output Class Initialized
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
INFO - 2018-02-12 07:25:21 --> Security Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:21 --> Input Class Initialized
INFO - 2018-02-12 07:25:21 --> Language Class Initialized
ERROR - 2018-02-12 07:25:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:25:23 --> Config Class Initialized
INFO - 2018-02-12 07:25:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:23 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:23 --> URI Class Initialized
INFO - 2018-02-12 07:25:23 --> Router Class Initialized
INFO - 2018-02-12 07:25:23 --> Output Class Initialized
INFO - 2018-02-12 07:25:23 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:23 --> Input Class Initialized
INFO - 2018-02-12 07:25:23 --> Language Class Initialized
INFO - 2018-02-12 07:25:23 --> Loader Class Initialized
INFO - 2018-02-12 07:25:23 --> Helper loaded: url_helper
INFO - 2018-02-12 07:25:23 --> Helper loaded: form_helper
INFO - 2018-02-12 07:25:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:25:23 --> Form Validation Class Initialized
INFO - 2018-02-12 07:25:23 --> Model Class Initialized
INFO - 2018-02-12 07:25:23 --> Controller Class Initialized
INFO - 2018-02-12 07:25:23 --> Model Class Initialized
INFO - 2018-02-12 07:25:23 --> Model Class Initialized
DEBUG - 2018-02-12 07:25:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:25:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:25:23 --> Final output sent to browser
DEBUG - 2018-02-12 07:25:23 --> Total execution time: 0.1468
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
INFO - 2018-02-12 07:25:24 --> Config Class Initialized
INFO - 2018-02-12 07:25:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
DEBUG - 2018-02-12 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:25:24 --> Utf8 Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> URI Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
INFO - 2018-02-12 07:25:24 --> Router Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
INFO - 2018-02-12 07:25:24 --> Output Class Initialized
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
INFO - 2018-02-12 07:25:24 --> Security Class Initialized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-12 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:25:24 --> Input Class Initialized
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:25:24 --> Language Class Initialized
ERROR - 2018-02-12 07:25:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Loader Class Initialized
INFO - 2018-02-12 07:26:02 --> Helper loaded: url_helper
INFO - 2018-02-12 07:26:02 --> Helper loaded: form_helper
INFO - 2018-02-12 07:26:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:26:02 --> Form Validation Class Initialized
INFO - 2018-02-12 07:26:02 --> Model Class Initialized
INFO - 2018-02-12 07:26:02 --> Controller Class Initialized
INFO - 2018-02-12 07:26:02 --> Model Class Initialized
INFO - 2018-02-12 07:26:02 --> Model Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:26:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:26:02 --> Final output sent to browser
DEBUG - 2018-02-12 07:26:02 --> Total execution time: 0.1289
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:02 --> Config Class Initialized
INFO - 2018-02-12 07:26:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> URI Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Router Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Output Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
INFO - 2018-02-12 07:26:02 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Input Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
INFO - 2018-02-12 07:26:02 --> Language Class Initialized
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:26:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
INFO - 2018-02-12 07:26:36 --> Loader Class Initialized
INFO - 2018-02-12 07:26:36 --> Helper loaded: url_helper
INFO - 2018-02-12 07:26:36 --> Helper loaded: form_helper
INFO - 2018-02-12 07:26:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:26:36 --> Form Validation Class Initialized
INFO - 2018-02-12 07:26:36 --> Model Class Initialized
INFO - 2018-02-12 07:26:36 --> Controller Class Initialized
INFO - 2018-02-12 07:26:36 --> Model Class Initialized
INFO - 2018-02-12 07:26:36 --> Model Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:26:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:26:36 --> Final output sent to browser
DEBUG - 2018-02-12 07:26:36 --> Total execution time: 0.2307
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:36 --> Config Class Initialized
INFO - 2018-02-12 07:26:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> URI Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Router Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Output Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
INFO - 2018-02-12 07:26:36 --> Security Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
DEBUG - 2018-02-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:36 --> Input Class Initialized
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:26:36 --> Language Class Initialized
ERROR - 2018-02-12 07:26:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:26:44 --> Config Class Initialized
INFO - 2018-02-12 07:26:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:44 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:44 --> URI Class Initialized
INFO - 2018-02-12 07:26:44 --> Router Class Initialized
INFO - 2018-02-12 07:26:44 --> Output Class Initialized
INFO - 2018-02-12 07:26:44 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:44 --> Input Class Initialized
INFO - 2018-02-12 07:26:44 --> Language Class Initialized
INFO - 2018-02-12 07:26:44 --> Loader Class Initialized
INFO - 2018-02-12 07:26:44 --> Helper loaded: url_helper
INFO - 2018-02-12 07:26:44 --> Helper loaded: form_helper
INFO - 2018-02-12 07:26:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:26:44 --> Form Validation Class Initialized
INFO - 2018-02-12 07:26:44 --> Model Class Initialized
INFO - 2018-02-12 07:26:44 --> Controller Class Initialized
INFO - 2018-02-12 07:26:44 --> Model Class Initialized
INFO - 2018-02-12 07:26:44 --> Model Class Initialized
DEBUG - 2018-02-12 07:26:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:26:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:26:44 --> Final output sent to browser
DEBUG - 2018-02-12 07:26:44 --> Total execution time: 0.1760
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Config Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
INFO - 2018-02-12 07:26:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:45 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> URI Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Router Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
INFO - 2018-02-12 07:26:45 --> Output Class Initialized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
DEBUG - 2018-02-12 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:45 --> Input Class Initialized
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:26:45 --> Language Class Initialized
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:26:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:27:41 --> Config Class Initialized
INFO - 2018-02-12 07:27:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:41 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:41 --> URI Class Initialized
INFO - 2018-02-12 07:27:41 --> Router Class Initialized
INFO - 2018-02-12 07:27:41 --> Output Class Initialized
INFO - 2018-02-12 07:27:41 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:41 --> Input Class Initialized
INFO - 2018-02-12 07:27:41 --> Language Class Initialized
INFO - 2018-02-12 07:27:41 --> Loader Class Initialized
INFO - 2018-02-12 07:27:41 --> Helper loaded: url_helper
INFO - 2018-02-12 07:27:41 --> Helper loaded: form_helper
INFO - 2018-02-12 07:27:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:27:41 --> Form Validation Class Initialized
INFO - 2018-02-12 07:27:41 --> Model Class Initialized
INFO - 2018-02-12 07:27:41 --> Controller Class Initialized
INFO - 2018-02-12 07:27:41 --> Model Class Initialized
INFO - 2018-02-12 07:27:41 --> Model Class Initialized
DEBUG - 2018-02-12 07:27:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:27:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:27:41 --> Final output sent to browser
DEBUG - 2018-02-12 07:27:41 --> Total execution time: 0.2308
INFO - 2018-02-12 07:27:41 --> Config Class Initialized
INFO - 2018-02-12 07:27:41 --> Config Class Initialized
INFO - 2018-02-12 07:27:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:27:41 --> Hooks Class Initialized
INFO - 2018-02-12 07:27:42 --> Config Class Initialized
INFO - 2018-02-12 07:27:42 --> Config Class Initialized
INFO - 2018-02-12 07:27:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:27:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:27:42 --> Config Class Initialized
INFO - 2018-02-12 07:27:42 --> Config Class Initialized
INFO - 2018-02-12 07:27:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:27:42 --> Hooks Class Initialized
INFO - 2018-02-12 07:27:42 --> Config Class Initialized
INFO - 2018-02-12 07:27:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
DEBUG - 2018-02-12 07:27:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:42 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> URI Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Router Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Output Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
INFO - 2018-02-12 07:27:42 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
DEBUG - 2018-02-12 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
INFO - 2018-02-12 07:27:42 --> Input Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
INFO - 2018-02-12 07:27:42 --> Language Class Initialized
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:27:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:28:30 --> Config Class Initialized
INFO - 2018-02-12 07:28:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:30 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:30 --> URI Class Initialized
INFO - 2018-02-12 07:28:30 --> Router Class Initialized
INFO - 2018-02-12 07:28:30 --> Output Class Initialized
INFO - 2018-02-12 07:28:30 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:30 --> Input Class Initialized
INFO - 2018-02-12 07:28:30 --> Language Class Initialized
INFO - 2018-02-12 07:28:30 --> Loader Class Initialized
INFO - 2018-02-12 07:28:30 --> Helper loaded: url_helper
INFO - 2018-02-12 07:28:30 --> Helper loaded: form_helper
INFO - 2018-02-12 07:28:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:28:30 --> Form Validation Class Initialized
INFO - 2018-02-12 07:28:30 --> Model Class Initialized
INFO - 2018-02-12 07:28:30 --> Controller Class Initialized
INFO - 2018-02-12 07:28:30 --> Model Class Initialized
INFO - 2018-02-12 07:28:30 --> Model Class Initialized
DEBUG - 2018-02-12 07:28:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:28:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:28:30 --> Final output sent to browser
DEBUG - 2018-02-12 07:28:30 --> Total execution time: 0.1264
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
ERROR - 2018-02-12 07:28:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:28:31 --> Config Class Initialized
INFO - 2018-02-12 07:28:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:31 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:31 --> URI Class Initialized
INFO - 2018-02-12 07:28:31 --> Router Class Initialized
INFO - 2018-02-12 07:28:31 --> Output Class Initialized
INFO - 2018-02-12 07:28:31 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:31 --> Input Class Initialized
INFO - 2018-02-12 07:28:31 --> Language Class Initialized
INFO - 2018-02-12 07:28:31 --> Loader Class Initialized
INFO - 2018-02-12 07:28:31 --> Helper loaded: url_helper
INFO - 2018-02-12 07:28:31 --> Helper loaded: form_helper
INFO - 2018-02-12 07:28:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:28:31 --> Form Validation Class Initialized
INFO - 2018-02-12 07:28:31 --> Model Class Initialized
INFO - 2018-02-12 07:28:31 --> Controller Class Initialized
INFO - 2018-02-12 07:28:31 --> Model Class Initialized
INFO - 2018-02-12 07:28:31 --> Model Class Initialized
DEBUG - 2018-02-12 07:28:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:28:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:28:31 --> Final output sent to browser
DEBUG - 2018-02-12 07:28:31 --> Total execution time: 0.1166
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Loader Class Initialized
INFO - 2018-02-12 07:28:32 --> Helper loaded: url_helper
INFO - 2018-02-12 07:28:32 --> Helper loaded: form_helper
INFO - 2018-02-12 07:28:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:28:32 --> Form Validation Class Initialized
INFO - 2018-02-12 07:28:32 --> Model Class Initialized
INFO - 2018-02-12 07:28:32 --> Controller Class Initialized
INFO - 2018-02-12 07:28:32 --> Model Class Initialized
INFO - 2018-02-12 07:28:32 --> Model Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:28:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:28:32 --> Final output sent to browser
DEBUG - 2018-02-12 07:28:32 --> Total execution time: 0.1168
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
INFO - 2018-02-12 07:28:32 --> Config Class Initialized
INFO - 2018-02-12 07:28:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:28:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:28:32 --> Utf8 Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> URI Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Router Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Output Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
INFO - 2018-02-12 07:28:32 --> Security Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
DEBUG - 2018-02-12 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Input Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
INFO - 2018-02-12 07:28:32 --> Language Class Initialized
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:28:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
INFO - 2018-02-12 07:30:12 --> Loader Class Initialized
INFO - 2018-02-12 07:30:12 --> Helper loaded: url_helper
INFO - 2018-02-12 07:30:12 --> Helper loaded: form_helper
INFO - 2018-02-12 07:30:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:30:12 --> Form Validation Class Initialized
INFO - 2018-02-12 07:30:12 --> Model Class Initialized
INFO - 2018-02-12 07:30:12 --> Controller Class Initialized
INFO - 2018-02-12 07:30:12 --> Model Class Initialized
INFO - 2018-02-12 07:30:12 --> Model Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:30:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:30:12 --> Final output sent to browser
DEBUG - 2018-02-12 07:30:12 --> Total execution time: 0.1714
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:12 --> Config Class Initialized
INFO - 2018-02-12 07:30:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> URI Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Router Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Output Class Initialized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Security Class Initialized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
DEBUG - 2018-02-12 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:12 --> Input Class Initialized
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:30:12 --> Language Class Initialized
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:30:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
INFO - 2018-02-12 07:30:18 --> Loader Class Initialized
INFO - 2018-02-12 07:30:18 --> Helper loaded: url_helper
INFO - 2018-02-12 07:30:18 --> Helper loaded: form_helper
INFO - 2018-02-12 07:30:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 07:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:30:18 --> Form Validation Class Initialized
INFO - 2018-02-12 07:30:18 --> Model Class Initialized
INFO - 2018-02-12 07:30:18 --> Controller Class Initialized
INFO - 2018-02-12 07:30:18 --> Model Class Initialized
INFO - 2018-02-12 07:30:18 --> Model Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-12 07:30:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-12 07:30:18 --> Final output sent to browser
DEBUG - 2018-02-12 07:30:18 --> Total execution time: 0.1349
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Config Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> URI Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Router Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Output Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
DEBUG - 2018-02-12 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
INFO - 2018-02-12 07:30:18 --> Input Class Initialized
INFO - 2018-02-12 07:30:18 --> Language Class Initialized
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-12 07:30:18 --> 404 Page Not Found: Instatec_pub/css
