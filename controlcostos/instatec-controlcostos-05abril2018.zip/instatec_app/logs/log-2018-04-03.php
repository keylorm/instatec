<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-03 21:55:30 --> Config Class Initialized
INFO - 2018-04-03 21:55:30 --> Hooks Class Initialized
DEBUG - 2018-04-03 21:55:30 --> UTF-8 Support Enabled
INFO - 2018-04-03 21:55:30 --> Utf8 Class Initialized
INFO - 2018-04-03 21:55:30 --> URI Class Initialized
DEBUG - 2018-04-03 21:55:30 --> No URI present. Default controller set.
INFO - 2018-04-03 21:55:30 --> Router Class Initialized
INFO - 2018-04-03 21:55:30 --> Output Class Initialized
INFO - 2018-04-03 21:55:30 --> Security Class Initialized
DEBUG - 2018-04-03 21:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 21:55:30 --> Input Class Initialized
INFO - 2018-04-03 21:55:30 --> Language Class Initialized
INFO - 2018-04-03 21:55:30 --> Loader Class Initialized
INFO - 2018-04-03 21:55:30 --> Helper loaded: url_helper
INFO - 2018-04-03 21:55:30 --> Helper loaded: form_helper
INFO - 2018-04-03 21:55:30 --> Database Driver Class Initialized
DEBUG - 2018-04-03 21:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 21:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 21:55:30 --> Form Validation Class Initialized
INFO - 2018-04-03 21:55:30 --> Model Class Initialized
INFO - 2018-04-03 21:55:30 --> Controller Class Initialized
INFO - 2018-04-03 21:55:31 --> Config Class Initialized
INFO - 2018-04-03 21:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-03 21:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-03 21:55:31 --> Utf8 Class Initialized
INFO - 2018-04-03 21:55:31 --> URI Class Initialized
INFO - 2018-04-03 21:55:31 --> Router Class Initialized
INFO - 2018-04-03 21:55:31 --> Output Class Initialized
INFO - 2018-04-03 21:55:31 --> Security Class Initialized
DEBUG - 2018-04-03 21:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 21:55:31 --> Input Class Initialized
INFO - 2018-04-03 21:55:31 --> Language Class Initialized
INFO - 2018-04-03 21:55:31 --> Loader Class Initialized
INFO - 2018-04-03 21:55:31 --> Helper loaded: url_helper
INFO - 2018-04-03 21:55:31 --> Helper loaded: form_helper
INFO - 2018-04-03 21:55:31 --> Database Driver Class Initialized
DEBUG - 2018-04-03 21:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 21:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 21:55:31 --> Form Validation Class Initialized
INFO - 2018-04-03 21:55:31 --> Model Class Initialized
INFO - 2018-04-03 21:55:31 --> Controller Class Initialized
INFO - 2018-04-03 21:55:31 --> Model Class Initialized
DEBUG - 2018-04-03 21:55:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 21:55:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 21:55:31 --> Final output sent to browser
DEBUG - 2018-04-03 21:55:31 --> Total execution time: 0.0582
INFO - 2018-04-03 21:55:32 --> Config Class Initialized
INFO - 2018-04-03 21:55:32 --> Hooks Class Initialized
DEBUG - 2018-04-03 21:55:32 --> UTF-8 Support Enabled
INFO - 2018-04-03 21:55:32 --> Utf8 Class Initialized
INFO - 2018-04-03 21:55:32 --> URI Class Initialized
INFO - 2018-04-03 21:55:32 --> Router Class Initialized
INFO - 2018-04-03 21:55:32 --> Output Class Initialized
INFO - 2018-04-03 21:55:32 --> Security Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 21:55:32 --> Input Class Initialized
INFO - 2018-04-03 21:55:32 --> Language Class Initialized
INFO - 2018-04-03 21:55:32 --> Loader Class Initialized
INFO - 2018-04-03 21:55:32 --> Helper loaded: url_helper
INFO - 2018-04-03 21:55:32 --> Helper loaded: form_helper
INFO - 2018-04-03 21:55:32 --> Database Driver Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 21:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 21:55:32 --> Form Validation Class Initialized
INFO - 2018-04-03 21:55:32 --> Model Class Initialized
INFO - 2018-04-03 21:55:32 --> Controller Class Initialized
INFO - 2018-04-03 21:55:32 --> Model Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 21:55:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-03 21:55:32 --> Config Class Initialized
INFO - 2018-04-03 21:55:32 --> Hooks Class Initialized
DEBUG - 2018-04-03 21:55:32 --> UTF-8 Support Enabled
INFO - 2018-04-03 21:55:32 --> Utf8 Class Initialized
INFO - 2018-04-03 21:55:32 --> URI Class Initialized
DEBUG - 2018-04-03 21:55:32 --> No URI present. Default controller set.
INFO - 2018-04-03 21:55:32 --> Router Class Initialized
INFO - 2018-04-03 21:55:32 --> Output Class Initialized
INFO - 2018-04-03 21:55:32 --> Security Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 21:55:32 --> Input Class Initialized
INFO - 2018-04-03 21:55:32 --> Language Class Initialized
INFO - 2018-04-03 21:55:32 --> Loader Class Initialized
INFO - 2018-04-03 21:55:32 --> Helper loaded: url_helper
INFO - 2018-04-03 21:55:32 --> Helper loaded: form_helper
INFO - 2018-04-03 21:55:32 --> Database Driver Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 21:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 21:55:32 --> Form Validation Class Initialized
INFO - 2018-04-03 21:55:32 --> Model Class Initialized
INFO - 2018-04-03 21:55:32 --> Controller Class Initialized
INFO - 2018-04-03 21:55:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 21:55:32 --> Final output sent to browser
DEBUG - 2018-04-03 21:55:32 --> Total execution time: 0.0457
INFO - 2018-04-03 21:55:32 --> Config Class Initialized
INFO - 2018-04-03 21:55:32 --> Hooks Class Initialized
DEBUG - 2018-04-03 21:55:32 --> UTF-8 Support Enabled
INFO - 2018-04-03 21:55:32 --> Utf8 Class Initialized
INFO - 2018-04-03 21:55:32 --> URI Class Initialized
INFO - 2018-04-03 21:55:32 --> Router Class Initialized
INFO - 2018-04-03 21:55:32 --> Output Class Initialized
INFO - 2018-04-03 21:55:32 --> Security Class Initialized
DEBUG - 2018-04-03 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 21:55:32 --> Input Class Initialized
INFO - 2018-04-03 21:55:32 --> Language Class Initialized
INFO - 2018-04-03 21:55:32 --> Loader Class Initialized
INFO - 2018-04-03 21:55:33 --> Helper loaded: url_helper
INFO - 2018-04-03 21:55:33 --> Helper loaded: form_helper
INFO - 2018-04-03 21:55:33 --> Database Driver Class Initialized
DEBUG - 2018-04-03 21:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 21:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 21:55:33 --> Form Validation Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
INFO - 2018-04-03 21:55:33 --> Controller Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
INFO - 2018-04-03 21:55:33 --> Model Class Initialized
DEBUG - 2018-04-03 21:55:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:11:36 --> Config Class Initialized
INFO - 2018-04-03 22:11:36 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:11:37 --> Utf8 Class Initialized
INFO - 2018-04-03 22:11:37 --> URI Class Initialized
DEBUG - 2018-04-03 22:11:37 --> No URI present. Default controller set.
INFO - 2018-04-03 22:11:37 --> Router Class Initialized
INFO - 2018-04-03 22:11:37 --> Output Class Initialized
INFO - 2018-04-03 22:11:37 --> Security Class Initialized
DEBUG - 2018-04-03 22:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:11:37 --> Input Class Initialized
INFO - 2018-04-03 22:11:37 --> Language Class Initialized
INFO - 2018-04-03 22:11:37 --> Loader Class Initialized
INFO - 2018-04-03 22:11:37 --> Helper loaded: url_helper
INFO - 2018-04-03 22:11:37 --> Helper loaded: form_helper
INFO - 2018-04-03 22:11:37 --> Database Driver Class Initialized
ERROR - 2018-04-03 22:11:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No se puede establecer una conexi�n ya que el equipo de destino deneg� expresamente dicha conexi�n.
 D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-03 22:11:39 --> Unable to connect to the database
INFO - 2018-04-03 22:11:39 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-03 22:53:19 --> Config Class Initialized
INFO - 2018-04-03 22:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:19 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:19 --> URI Class Initialized
DEBUG - 2018-04-03 22:53:19 --> No URI present. Default controller set.
INFO - 2018-04-03 22:53:19 --> Router Class Initialized
INFO - 2018-04-03 22:53:19 --> Output Class Initialized
INFO - 2018-04-03 22:53:19 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:19 --> Input Class Initialized
INFO - 2018-04-03 22:53:19 --> Language Class Initialized
INFO - 2018-04-03 22:53:19 --> Loader Class Initialized
INFO - 2018-04-03 22:53:19 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:19 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:19 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:19 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:19 --> Model Class Initialized
INFO - 2018-04-03 22:53:19 --> Controller Class Initialized
INFO - 2018-04-03 22:53:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:20 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:20 --> Total execution time: 0.4549
INFO - 2018-04-03 22:53:20 --> Config Class Initialized
INFO - 2018-04-03 22:53:20 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:20 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:20 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:20 --> URI Class Initialized
INFO - 2018-04-03 22:53:20 --> Router Class Initialized
INFO - 2018-04-03 22:53:20 --> Output Class Initialized
INFO - 2018-04-03 22:53:20 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:20 --> Input Class Initialized
INFO - 2018-04-03 22:53:20 --> Language Class Initialized
INFO - 2018-04-03 22:53:20 --> Loader Class Initialized
INFO - 2018-04-03 22:53:20 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:20 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:20 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:20 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
INFO - 2018-04-03 22:53:20 --> Controller Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
INFO - 2018-04-03 22:53:20 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:22 --> Config Class Initialized
INFO - 2018-04-03 22:53:22 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:22 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:22 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:22 --> URI Class Initialized
INFO - 2018-04-03 22:53:22 --> Router Class Initialized
INFO - 2018-04-03 22:53:22 --> Output Class Initialized
INFO - 2018-04-03 22:53:22 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:22 --> Input Class Initialized
INFO - 2018-04-03 22:53:22 --> Language Class Initialized
INFO - 2018-04-03 22:53:22 --> Loader Class Initialized
INFO - 2018-04-03 22:53:22 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:22 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:22 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:22 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
INFO - 2018-04-03 22:53:22 --> Controller Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:22 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:22 --> Total execution time: 0.0839
INFO - 2018-04-03 22:53:22 --> Config Class Initialized
INFO - 2018-04-03 22:53:22 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:22 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:22 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:22 --> URI Class Initialized
INFO - 2018-04-03 22:53:22 --> Router Class Initialized
INFO - 2018-04-03 22:53:22 --> Output Class Initialized
INFO - 2018-04-03 22:53:22 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:22 --> Input Class Initialized
INFO - 2018-04-03 22:53:22 --> Language Class Initialized
INFO - 2018-04-03 22:53:22 --> Loader Class Initialized
INFO - 2018-04-03 22:53:22 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:22 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:22 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:22 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
INFO - 2018-04-03 22:53:22 --> Controller Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
INFO - 2018-04-03 22:53:22 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:23 --> Config Class Initialized
INFO - 2018-04-03 22:53:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:23 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:23 --> URI Class Initialized
INFO - 2018-04-03 22:53:23 --> Router Class Initialized
INFO - 2018-04-03 22:53:23 --> Output Class Initialized
INFO - 2018-04-03 22:53:23 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:23 --> Input Class Initialized
INFO - 2018-04-03 22:53:23 --> Language Class Initialized
INFO - 2018-04-03 22:53:23 --> Loader Class Initialized
INFO - 2018-04-03 22:53:23 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:23 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:23 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:23 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Controller Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:23 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:23 --> Total execution time: 0.0922
INFO - 2018-04-03 22:53:23 --> Config Class Initialized
INFO - 2018-04-03 22:53:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:23 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:23 --> URI Class Initialized
INFO - 2018-04-03 22:53:23 --> Router Class Initialized
INFO - 2018-04-03 22:53:23 --> Output Class Initialized
INFO - 2018-04-03 22:53:23 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:23 --> Input Class Initialized
INFO - 2018-04-03 22:53:23 --> Language Class Initialized
INFO - 2018-04-03 22:53:23 --> Loader Class Initialized
INFO - 2018-04-03 22:53:23 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:23 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:23 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:23 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Controller Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
INFO - 2018-04-03 22:53:23 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:25 --> Config Class Initialized
INFO - 2018-04-03 22:53:25 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:25 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:25 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:25 --> URI Class Initialized
INFO - 2018-04-03 22:53:25 --> Router Class Initialized
INFO - 2018-04-03 22:53:25 --> Output Class Initialized
INFO - 2018-04-03 22:53:25 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:25 --> Input Class Initialized
INFO - 2018-04-03 22:53:25 --> Language Class Initialized
INFO - 2018-04-03 22:53:25 --> Loader Class Initialized
INFO - 2018-04-03 22:53:25 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:25 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:25 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:25 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:25 --> Model Class Initialized
INFO - 2018-04-03 22:53:25 --> Controller Class Initialized
INFO - 2018-04-03 22:53:25 --> Model Class Initialized
INFO - 2018-04-03 22:53:25 --> Model Class Initialized
INFO - 2018-04-03 22:53:25 --> Model Class Initialized
INFO - 2018-04-03 22:53:25 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:25 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:25 --> Total execution time: 0.1678
INFO - 2018-04-03 22:53:26 --> Config Class Initialized
INFO - 2018-04-03 22:53:26 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:26 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:26 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:26 --> URI Class Initialized
INFO - 2018-04-03 22:53:26 --> Router Class Initialized
INFO - 2018-04-03 22:53:26 --> Output Class Initialized
INFO - 2018-04-03 22:53:26 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:26 --> Input Class Initialized
INFO - 2018-04-03 22:53:26 --> Language Class Initialized
INFO - 2018-04-03 22:53:26 --> Loader Class Initialized
INFO - 2018-04-03 22:53:26 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:26 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:26 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:26 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:26 --> Model Class Initialized
INFO - 2018-04-03 22:53:26 --> Controller Class Initialized
INFO - 2018-04-03 22:53:26 --> Model Class Initialized
INFO - 2018-04-03 22:53:26 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:26 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:26 --> Total execution time: 0.0675
INFO - 2018-04-03 22:53:26 --> Config Class Initialized
INFO - 2018-04-03 22:53:26 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:26 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:26 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:27 --> URI Class Initialized
INFO - 2018-04-03 22:53:27 --> Router Class Initialized
INFO - 2018-04-03 22:53:27 --> Output Class Initialized
INFO - 2018-04-03 22:53:27 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:27 --> Input Class Initialized
INFO - 2018-04-03 22:53:27 --> Language Class Initialized
INFO - 2018-04-03 22:53:27 --> Loader Class Initialized
INFO - 2018-04-03 22:53:27 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:27 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:27 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:27 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:27 --> Model Class Initialized
INFO - 2018-04-03 22:53:27 --> Controller Class Initialized
INFO - 2018-04-03 22:53:27 --> Model Class Initialized
INFO - 2018-04-03 22:53:27 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:28 --> Config Class Initialized
INFO - 2018-04-03 22:53:28 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:28 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:28 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:28 --> URI Class Initialized
INFO - 2018-04-03 22:53:28 --> Router Class Initialized
INFO - 2018-04-03 22:53:28 --> Output Class Initialized
INFO - 2018-04-03 22:53:28 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:28 --> Input Class Initialized
INFO - 2018-04-03 22:53:28 --> Language Class Initialized
INFO - 2018-04-03 22:53:28 --> Loader Class Initialized
INFO - 2018-04-03 22:53:28 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:28 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:28 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:28 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Controller Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:28 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:28 --> Total execution time: 0.0571
INFO - 2018-04-03 22:53:28 --> Config Class Initialized
INFO - 2018-04-03 22:53:28 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:28 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:28 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:28 --> URI Class Initialized
INFO - 2018-04-03 22:53:28 --> Router Class Initialized
INFO - 2018-04-03 22:53:28 --> Output Class Initialized
INFO - 2018-04-03 22:53:28 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:28 --> Input Class Initialized
INFO - 2018-04-03 22:53:28 --> Language Class Initialized
INFO - 2018-04-03 22:53:28 --> Loader Class Initialized
INFO - 2018-04-03 22:53:28 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:28 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:28 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:28 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Controller Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
INFO - 2018-04-03 22:53:28 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:29 --> Config Class Initialized
INFO - 2018-04-03 22:53:29 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:53:29 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:53:29 --> Utf8 Class Initialized
INFO - 2018-04-03 22:53:29 --> URI Class Initialized
INFO - 2018-04-03 22:53:29 --> Router Class Initialized
INFO - 2018-04-03 22:53:29 --> Output Class Initialized
INFO - 2018-04-03 22:53:29 --> Security Class Initialized
DEBUG - 2018-04-03 22:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:53:29 --> Input Class Initialized
INFO - 2018-04-03 22:53:29 --> Language Class Initialized
INFO - 2018-04-03 22:53:29 --> Loader Class Initialized
INFO - 2018-04-03 22:53:29 --> Helper loaded: url_helper
INFO - 2018-04-03 22:53:29 --> Helper loaded: form_helper
INFO - 2018-04-03 22:53:29 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:53:29 --> Form Validation Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
INFO - 2018-04-03 22:53:29 --> Controller Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
INFO - 2018-04-03 22:53:29 --> Model Class Initialized
DEBUG - 2018-04-03 22:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:53:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:53:29 --> Final output sent to browser
DEBUG - 2018-04-03 22:53:29 --> Total execution time: 0.1004
INFO - 2018-04-03 22:54:14 --> Config Class Initialized
INFO - 2018-04-03 22:54:14 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:54:14 --> Utf8 Class Initialized
INFO - 2018-04-03 22:54:14 --> URI Class Initialized
INFO - 2018-04-03 22:54:14 --> Router Class Initialized
INFO - 2018-04-03 22:54:14 --> Output Class Initialized
INFO - 2018-04-03 22:54:14 --> Security Class Initialized
DEBUG - 2018-04-03 22:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:54:14 --> Input Class Initialized
INFO - 2018-04-03 22:54:14 --> Language Class Initialized
INFO - 2018-04-03 22:54:14 --> Loader Class Initialized
INFO - 2018-04-03 22:54:14 --> Helper loaded: url_helper
INFO - 2018-04-03 22:54:14 --> Helper loaded: form_helper
INFO - 2018-04-03 22:54:14 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:54:14 --> Form Validation Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
INFO - 2018-04-03 22:54:14 --> Controller Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
INFO - 2018-04-03 22:54:14 --> Model Class Initialized
DEBUG - 2018-04-03 22:54:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:54:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:54:14 --> Final output sent to browser
DEBUG - 2018-04-03 22:54:14 --> Total execution time: 0.0455
INFO - 2018-04-03 22:54:15 --> Config Class Initialized
INFO - 2018-04-03 22:54:15 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:54:15 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:54:15 --> Utf8 Class Initialized
INFO - 2018-04-03 22:54:15 --> URI Class Initialized
INFO - 2018-04-03 22:54:15 --> Router Class Initialized
INFO - 2018-04-03 22:54:15 --> Output Class Initialized
INFO - 2018-04-03 22:54:15 --> Security Class Initialized
DEBUG - 2018-04-03 22:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:54:15 --> Input Class Initialized
INFO - 2018-04-03 22:54:15 --> Language Class Initialized
INFO - 2018-04-03 22:54:15 --> Loader Class Initialized
INFO - 2018-04-03 22:54:15 --> Helper loaded: url_helper
INFO - 2018-04-03 22:54:15 --> Helper loaded: form_helper
INFO - 2018-04-03 22:54:15 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:54:15 --> Form Validation Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
INFO - 2018-04-03 22:54:15 --> Controller Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
INFO - 2018-04-03 22:54:15 --> Model Class Initialized
DEBUG - 2018-04-03 22:54:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:54:16 --> Config Class Initialized
INFO - 2018-04-03 22:54:16 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:54:16 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:54:16 --> Utf8 Class Initialized
INFO - 2018-04-03 22:54:16 --> URI Class Initialized
INFO - 2018-04-03 22:54:16 --> Router Class Initialized
INFO - 2018-04-03 22:54:16 --> Output Class Initialized
INFO - 2018-04-03 22:54:16 --> Security Class Initialized
DEBUG - 2018-04-03 22:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:54:16 --> Input Class Initialized
INFO - 2018-04-03 22:54:16 --> Language Class Initialized
INFO - 2018-04-03 22:54:16 --> Loader Class Initialized
INFO - 2018-04-03 22:54:16 --> Helper loaded: url_helper
INFO - 2018-04-03 22:54:16 --> Helper loaded: form_helper
INFO - 2018-04-03 22:54:16 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:54:16 --> Form Validation Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
INFO - 2018-04-03 22:54:16 --> Controller Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
INFO - 2018-04-03 22:54:16 --> Model Class Initialized
DEBUG - 2018-04-03 22:54:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 22:54:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 22:54:17 --> Final output sent to browser
DEBUG - 2018-04-03 22:54:17 --> Total execution time: 0.3266
INFO - 2018-04-03 22:54:17 --> Config Class Initialized
INFO - 2018-04-03 22:54:17 --> Hooks Class Initialized
DEBUG - 2018-04-03 22:54:17 --> UTF-8 Support Enabled
INFO - 2018-04-03 22:54:17 --> Utf8 Class Initialized
INFO - 2018-04-03 22:54:17 --> URI Class Initialized
INFO - 2018-04-03 22:54:17 --> Router Class Initialized
INFO - 2018-04-03 22:54:17 --> Output Class Initialized
INFO - 2018-04-03 22:54:17 --> Security Class Initialized
DEBUG - 2018-04-03 22:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 22:54:17 --> Input Class Initialized
INFO - 2018-04-03 22:54:17 --> Language Class Initialized
INFO - 2018-04-03 22:54:17 --> Loader Class Initialized
INFO - 2018-04-03 22:54:17 --> Helper loaded: url_helper
INFO - 2018-04-03 22:54:17 --> Helper loaded: form_helper
INFO - 2018-04-03 22:54:17 --> Database Driver Class Initialized
DEBUG - 2018-04-03 22:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 22:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 22:54:17 --> Form Validation Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
INFO - 2018-04-03 22:54:17 --> Controller Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
INFO - 2018-04-03 22:54:17 --> Model Class Initialized
DEBUG - 2018-04-03 22:54:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:02:27 --> Config Class Initialized
INFO - 2018-04-03 23:02:27 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:02:27 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:02:27 --> Utf8 Class Initialized
INFO - 2018-04-03 23:02:27 --> URI Class Initialized
INFO - 2018-04-03 23:02:27 --> Router Class Initialized
INFO - 2018-04-03 23:02:27 --> Output Class Initialized
INFO - 2018-04-03 23:02:27 --> Security Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:02:27 --> Input Class Initialized
INFO - 2018-04-03 23:02:27 --> Language Class Initialized
INFO - 2018-04-03 23:02:27 --> Loader Class Initialized
INFO - 2018-04-03 23:02:27 --> Helper loaded: url_helper
INFO - 2018-04-03 23:02:27 --> Helper loaded: form_helper
INFO - 2018-04-03 23:02:27 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:02:27 --> Form Validation Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
INFO - 2018-04-03 23:02:27 --> Controller Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:02:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:02:27 --> Final output sent to browser
DEBUG - 2018-04-03 23:02:27 --> Total execution time: 0.0508
INFO - 2018-04-03 23:02:27 --> Config Class Initialized
INFO - 2018-04-03 23:02:27 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:02:27 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:02:27 --> Utf8 Class Initialized
INFO - 2018-04-03 23:02:27 --> URI Class Initialized
INFO - 2018-04-03 23:02:27 --> Router Class Initialized
INFO - 2018-04-03 23:02:27 --> Output Class Initialized
INFO - 2018-04-03 23:02:27 --> Security Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:02:27 --> Input Class Initialized
INFO - 2018-04-03 23:02:27 --> Language Class Initialized
INFO - 2018-04-03 23:02:27 --> Loader Class Initialized
INFO - 2018-04-03 23:02:27 --> Helper loaded: url_helper
INFO - 2018-04-03 23:02:27 --> Helper loaded: form_helper
INFO - 2018-04-03 23:02:27 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:02:27 --> Form Validation Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
INFO - 2018-04-03 23:02:27 --> Controller Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
INFO - 2018-04-03 23:02:27 --> Model Class Initialized
DEBUG - 2018-04-03 23:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:02:28 --> Config Class Initialized
INFO - 2018-04-03 23:02:28 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:02:28 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:02:28 --> Utf8 Class Initialized
INFO - 2018-04-03 23:02:28 --> URI Class Initialized
INFO - 2018-04-03 23:02:28 --> Router Class Initialized
INFO - 2018-04-03 23:02:28 --> Output Class Initialized
INFO - 2018-04-03 23:02:28 --> Security Class Initialized
DEBUG - 2018-04-03 23:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:02:28 --> Input Class Initialized
INFO - 2018-04-03 23:02:28 --> Language Class Initialized
INFO - 2018-04-03 23:02:28 --> Loader Class Initialized
INFO - 2018-04-03 23:02:28 --> Helper loaded: url_helper
INFO - 2018-04-03 23:02:28 --> Helper loaded: form_helper
INFO - 2018-04-03 23:02:28 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:02:28 --> Form Validation Class Initialized
INFO - 2018-04-03 23:02:28 --> Model Class Initialized
INFO - 2018-04-03 23:02:28 --> Controller Class Initialized
INFO - 2018-04-03 23:02:28 --> Model Class Initialized
INFO - 2018-04-03 23:02:28 --> Model Class Initialized
DEBUG - 2018-04-03 23:02:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:02:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:02:28 --> Final output sent to browser
DEBUG - 2018-04-03 23:02:28 --> Total execution time: 0.0732
INFO - 2018-04-03 23:03:21 --> Config Class Initialized
INFO - 2018-04-03 23:03:21 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:21 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:21 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:21 --> URI Class Initialized
INFO - 2018-04-03 23:03:21 --> Router Class Initialized
INFO - 2018-04-03 23:03:21 --> Output Class Initialized
INFO - 2018-04-03 23:03:21 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:21 --> Input Class Initialized
INFO - 2018-04-03 23:03:21 --> Language Class Initialized
INFO - 2018-04-03 23:03:21 --> Loader Class Initialized
INFO - 2018-04-03 23:03:21 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:21 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:21 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:21 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:21 --> Model Class Initialized
INFO - 2018-04-03 23:03:21 --> Controller Class Initialized
INFO - 2018-04-03 23:03:21 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:03:21 --> Final output sent to browser
DEBUG - 2018-04-03 23:03:21 --> Total execution time: 0.3723
INFO - 2018-04-03 23:03:21 --> Config Class Initialized
INFO - 2018-04-03 23:03:21 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:21 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:21 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:21 --> URI Class Initialized
INFO - 2018-04-03 23:03:21 --> Router Class Initialized
INFO - 2018-04-03 23:03:21 --> Output Class Initialized
INFO - 2018-04-03 23:03:21 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:21 --> Input Class Initialized
INFO - 2018-04-03 23:03:21 --> Language Class Initialized
INFO - 2018-04-03 23:03:21 --> Loader Class Initialized
INFO - 2018-04-03 23:03:21 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:21 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:21 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:21 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:21 --> Model Class Initialized
INFO - 2018-04-03 23:03:21 --> Controller Class Initialized
INFO - 2018-04-03 23:03:21 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:22 --> Config Class Initialized
INFO - 2018-04-03 23:03:22 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:22 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:22 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:22 --> URI Class Initialized
INFO - 2018-04-03 23:03:22 --> Router Class Initialized
INFO - 2018-04-03 23:03:22 --> Output Class Initialized
INFO - 2018-04-03 23:03:22 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:22 --> Input Class Initialized
INFO - 2018-04-03 23:03:22 --> Language Class Initialized
INFO - 2018-04-03 23:03:22 --> Loader Class Initialized
INFO - 2018-04-03 23:03:22 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:22 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:22 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:22 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:22 --> Model Class Initialized
INFO - 2018-04-03 23:03:22 --> Controller Class Initialized
INFO - 2018-04-03 23:03:22 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:03:22 --> Final output sent to browser
DEBUG - 2018-04-03 23:03:22 --> Total execution time: 0.0922
INFO - 2018-04-03 23:03:57 --> Config Class Initialized
INFO - 2018-04-03 23:03:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:57 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:57 --> URI Class Initialized
INFO - 2018-04-03 23:03:57 --> Router Class Initialized
INFO - 2018-04-03 23:03:57 --> Output Class Initialized
INFO - 2018-04-03 23:03:57 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:57 --> Input Class Initialized
INFO - 2018-04-03 23:03:57 --> Language Class Initialized
INFO - 2018-04-03 23:03:57 --> Loader Class Initialized
INFO - 2018-04-03 23:03:57 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:57 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:57 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:57 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
INFO - 2018-04-03 23:03:57 --> Controller Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:03:57 --> Final output sent to browser
DEBUG - 2018-04-03 23:03:57 --> Total execution time: 0.0517
INFO - 2018-04-03 23:03:57 --> Config Class Initialized
INFO - 2018-04-03 23:03:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:57 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:57 --> URI Class Initialized
INFO - 2018-04-03 23:03:57 --> Router Class Initialized
INFO - 2018-04-03 23:03:57 --> Output Class Initialized
INFO - 2018-04-03 23:03:57 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:57 --> Input Class Initialized
INFO - 2018-04-03 23:03:57 --> Language Class Initialized
INFO - 2018-04-03 23:03:57 --> Loader Class Initialized
INFO - 2018-04-03 23:03:57 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:57 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:57 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:57 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
INFO - 2018-04-03 23:03:57 --> Controller Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
INFO - 2018-04-03 23:03:57 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:58 --> Config Class Initialized
INFO - 2018-04-03 23:03:58 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:03:58 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:03:58 --> Utf8 Class Initialized
INFO - 2018-04-03 23:03:58 --> URI Class Initialized
INFO - 2018-04-03 23:03:58 --> Router Class Initialized
INFO - 2018-04-03 23:03:58 --> Output Class Initialized
INFO - 2018-04-03 23:03:58 --> Security Class Initialized
DEBUG - 2018-04-03 23:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:03:58 --> Input Class Initialized
INFO - 2018-04-03 23:03:58 --> Language Class Initialized
INFO - 2018-04-03 23:03:58 --> Loader Class Initialized
INFO - 2018-04-03 23:03:58 --> Helper loaded: url_helper
INFO - 2018-04-03 23:03:58 --> Helper loaded: form_helper
INFO - 2018-04-03 23:03:58 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:03:58 --> Form Validation Class Initialized
INFO - 2018-04-03 23:03:58 --> Model Class Initialized
INFO - 2018-04-03 23:03:58 --> Controller Class Initialized
INFO - 2018-04-03 23:03:58 --> Model Class Initialized
INFO - 2018-04-03 23:03:58 --> Model Class Initialized
DEBUG - 2018-04-03 23:03:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:03:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:03:58 --> Final output sent to browser
DEBUG - 2018-04-03 23:03:58 --> Total execution time: 0.3291
INFO - 2018-04-03 23:04:00 --> Config Class Initialized
INFO - 2018-04-03 23:04:00 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:00 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:00 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:00 --> URI Class Initialized
INFO - 2018-04-03 23:04:00 --> Router Class Initialized
INFO - 2018-04-03 23:04:00 --> Output Class Initialized
INFO - 2018-04-03 23:04:00 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:00 --> Input Class Initialized
INFO - 2018-04-03 23:04:00 --> Language Class Initialized
INFO - 2018-04-03 23:04:00 --> Loader Class Initialized
INFO - 2018-04-03 23:04:00 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:00 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:00 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:00 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
INFO - 2018-04-03 23:04:00 --> Controller Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:04:00 --> Final output sent to browser
DEBUG - 2018-04-03 23:04:00 --> Total execution time: 0.0413
INFO - 2018-04-03 23:04:00 --> Config Class Initialized
INFO - 2018-04-03 23:04:00 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:00 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:00 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:00 --> URI Class Initialized
INFO - 2018-04-03 23:04:00 --> Router Class Initialized
INFO - 2018-04-03 23:04:00 --> Output Class Initialized
INFO - 2018-04-03 23:04:00 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:00 --> Input Class Initialized
INFO - 2018-04-03 23:04:00 --> Language Class Initialized
INFO - 2018-04-03 23:04:00 --> Loader Class Initialized
INFO - 2018-04-03 23:04:00 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:00 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:00 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:00 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
INFO - 2018-04-03 23:04:00 --> Controller Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
INFO - 2018-04-03 23:04:00 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:03 --> Config Class Initialized
INFO - 2018-04-03 23:04:03 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:03 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:03 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:03 --> URI Class Initialized
INFO - 2018-04-03 23:04:03 --> Router Class Initialized
INFO - 2018-04-03 23:04:03 --> Output Class Initialized
INFO - 2018-04-03 23:04:03 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:03 --> Input Class Initialized
INFO - 2018-04-03 23:04:03 --> Language Class Initialized
INFO - 2018-04-03 23:04:03 --> Loader Class Initialized
INFO - 2018-04-03 23:04:03 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:03 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:03 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:03 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:03 --> Model Class Initialized
INFO - 2018-04-03 23:04:03 --> Controller Class Initialized
INFO - 2018-04-03 23:04:03 --> Model Class Initialized
INFO - 2018-04-03 23:04:03 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:03 --> Model Class Initialized
INFO - 2018-04-03 23:04:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:04:03 --> Final output sent to browser
DEBUG - 2018-04-03 23:04:03 --> Total execution time: 0.3359
INFO - 2018-04-03 23:04:08 --> Config Class Initialized
INFO - 2018-04-03 23:04:08 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:08 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:08 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:08 --> URI Class Initialized
INFO - 2018-04-03 23:04:08 --> Router Class Initialized
INFO - 2018-04-03 23:04:08 --> Output Class Initialized
INFO - 2018-04-03 23:04:08 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:08 --> Input Class Initialized
INFO - 2018-04-03 23:04:08 --> Language Class Initialized
INFO - 2018-04-03 23:04:08 --> Loader Class Initialized
INFO - 2018-04-03 23:04:08 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:08 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:08 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:08 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
INFO - 2018-04-03 23:04:08 --> Controller Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:04:08 --> Final output sent to browser
DEBUG - 2018-04-03 23:04:08 --> Total execution time: 0.0385
INFO - 2018-04-03 23:04:08 --> Config Class Initialized
INFO - 2018-04-03 23:04:08 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:08 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:08 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:08 --> URI Class Initialized
INFO - 2018-04-03 23:04:08 --> Router Class Initialized
INFO - 2018-04-03 23:04:08 --> Output Class Initialized
INFO - 2018-04-03 23:04:08 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:08 --> Input Class Initialized
INFO - 2018-04-03 23:04:08 --> Language Class Initialized
INFO - 2018-04-03 23:04:08 --> Loader Class Initialized
INFO - 2018-04-03 23:04:08 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:08 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:08 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:08 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
INFO - 2018-04-03 23:04:08 --> Controller Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
INFO - 2018-04-03 23:04:08 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:12 --> Config Class Initialized
INFO - 2018-04-03 23:04:12 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:04:12 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:04:12 --> Utf8 Class Initialized
INFO - 2018-04-03 23:04:12 --> URI Class Initialized
INFO - 2018-04-03 23:04:12 --> Router Class Initialized
INFO - 2018-04-03 23:04:12 --> Output Class Initialized
INFO - 2018-04-03 23:04:12 --> Security Class Initialized
DEBUG - 2018-04-03 23:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:04:12 --> Input Class Initialized
INFO - 2018-04-03 23:04:12 --> Language Class Initialized
INFO - 2018-04-03 23:04:12 --> Loader Class Initialized
INFO - 2018-04-03 23:04:12 --> Helper loaded: url_helper
INFO - 2018-04-03 23:04:12 --> Helper loaded: form_helper
INFO - 2018-04-03 23:04:12 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:04:13 --> Form Validation Class Initialized
INFO - 2018-04-03 23:04:13 --> Model Class Initialized
INFO - 2018-04-03 23:04:13 --> Controller Class Initialized
INFO - 2018-04-03 23:04:13 --> Model Class Initialized
INFO - 2018-04-03 23:04:13 --> Model Class Initialized
DEBUG - 2018-04-03 23:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:04:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:04:13 --> Final output sent to browser
DEBUG - 2018-04-03 23:04:13 --> Total execution time: 0.0512
INFO - 2018-04-03 23:16:22 --> Config Class Initialized
INFO - 2018-04-03 23:16:22 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:16:22 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:16:22 --> Utf8 Class Initialized
INFO - 2018-04-03 23:16:22 --> URI Class Initialized
INFO - 2018-04-03 23:16:22 --> Router Class Initialized
INFO - 2018-04-03 23:16:22 --> Output Class Initialized
INFO - 2018-04-03 23:16:22 --> Security Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:16:22 --> Input Class Initialized
INFO - 2018-04-03 23:16:22 --> Language Class Initialized
INFO - 2018-04-03 23:16:22 --> Loader Class Initialized
INFO - 2018-04-03 23:16:22 --> Helper loaded: url_helper
INFO - 2018-04-03 23:16:22 --> Helper loaded: form_helper
INFO - 2018-04-03 23:16:22 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:16:22 --> Form Validation Class Initialized
INFO - 2018-04-03 23:16:22 --> Model Class Initialized
INFO - 2018-04-03 23:16:22 --> Controller Class Initialized
INFO - 2018-04-03 23:16:22 --> Model Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:16:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:16:22 --> Final output sent to browser
DEBUG - 2018-04-03 23:16:22 --> Total execution time: 0.0433
INFO - 2018-04-03 23:16:22 --> Config Class Initialized
INFO - 2018-04-03 23:16:22 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:16:22 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:16:22 --> Utf8 Class Initialized
INFO - 2018-04-03 23:16:22 --> URI Class Initialized
INFO - 2018-04-03 23:16:22 --> Router Class Initialized
INFO - 2018-04-03 23:16:22 --> Output Class Initialized
INFO - 2018-04-03 23:16:22 --> Security Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:16:22 --> Input Class Initialized
INFO - 2018-04-03 23:16:22 --> Language Class Initialized
INFO - 2018-04-03 23:16:22 --> Loader Class Initialized
INFO - 2018-04-03 23:16:22 --> Helper loaded: url_helper
INFO - 2018-04-03 23:16:22 --> Helper loaded: form_helper
INFO - 2018-04-03 23:16:22 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:16:22 --> Form Validation Class Initialized
INFO - 2018-04-03 23:16:22 --> Model Class Initialized
INFO - 2018-04-03 23:16:22 --> Controller Class Initialized
INFO - 2018-04-03 23:16:22 --> Model Class Initialized
DEBUG - 2018-04-03 23:16:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:16:31 --> Config Class Initialized
INFO - 2018-04-03 23:16:31 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:16:31 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:16:31 --> Utf8 Class Initialized
INFO - 2018-04-03 23:16:31 --> URI Class Initialized
INFO - 2018-04-03 23:16:31 --> Router Class Initialized
INFO - 2018-04-03 23:16:31 --> Output Class Initialized
INFO - 2018-04-03 23:16:31 --> Security Class Initialized
DEBUG - 2018-04-03 23:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:16:31 --> Input Class Initialized
INFO - 2018-04-03 23:16:31 --> Language Class Initialized
INFO - 2018-04-03 23:16:31 --> Loader Class Initialized
INFO - 2018-04-03 23:16:31 --> Helper loaded: url_helper
INFO - 2018-04-03 23:16:31 --> Helper loaded: form_helper
INFO - 2018-04-03 23:16:31 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:16:31 --> Form Validation Class Initialized
INFO - 2018-04-03 23:16:31 --> Model Class Initialized
INFO - 2018-04-03 23:16:31 --> Controller Class Initialized
INFO - 2018-04-03 23:16:31 --> Model Class Initialized
DEBUG - 2018-04-03 23:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:16:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:16:31 --> Final output sent to browser
DEBUG - 2018-04-03 23:16:31 --> Total execution time: 0.0416
INFO - 2018-04-03 23:32:09 --> Config Class Initialized
INFO - 2018-04-03 23:32:09 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:32:09 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:32:09 --> Utf8 Class Initialized
INFO - 2018-04-03 23:32:09 --> URI Class Initialized
INFO - 2018-04-03 23:32:09 --> Router Class Initialized
INFO - 2018-04-03 23:32:09 --> Output Class Initialized
INFO - 2018-04-03 23:32:09 --> Security Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:32:09 --> Input Class Initialized
INFO - 2018-04-03 23:32:09 --> Language Class Initialized
INFO - 2018-04-03 23:32:09 --> Loader Class Initialized
INFO - 2018-04-03 23:32:09 --> Helper loaded: url_helper
INFO - 2018-04-03 23:32:09 --> Helper loaded: form_helper
INFO - 2018-04-03 23:32:09 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:32:09 --> Form Validation Class Initialized
INFO - 2018-04-03 23:32:09 --> Model Class Initialized
INFO - 2018-04-03 23:32:09 --> Controller Class Initialized
INFO - 2018-04-03 23:32:09 --> Model Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:32:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:32:09 --> Final output sent to browser
DEBUG - 2018-04-03 23:32:09 --> Total execution time: 0.0418
INFO - 2018-04-03 23:32:09 --> Config Class Initialized
INFO - 2018-04-03 23:32:09 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:32:09 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:32:09 --> Utf8 Class Initialized
INFO - 2018-04-03 23:32:09 --> URI Class Initialized
INFO - 2018-04-03 23:32:09 --> Router Class Initialized
INFO - 2018-04-03 23:32:09 --> Output Class Initialized
INFO - 2018-04-03 23:32:09 --> Security Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:32:09 --> Input Class Initialized
INFO - 2018-04-03 23:32:09 --> Language Class Initialized
INFO - 2018-04-03 23:32:09 --> Loader Class Initialized
INFO - 2018-04-03 23:32:09 --> Helper loaded: url_helper
INFO - 2018-04-03 23:32:09 --> Helper loaded: form_helper
INFO - 2018-04-03 23:32:09 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:32:09 --> Form Validation Class Initialized
INFO - 2018-04-03 23:32:09 --> Model Class Initialized
INFO - 2018-04-03 23:32:09 --> Controller Class Initialized
INFO - 2018-04-03 23:32:09 --> Model Class Initialized
DEBUG - 2018-04-03 23:32:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:40:02 --> Config Class Initialized
INFO - 2018-04-03 23:40:02 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:40:02 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:40:02 --> Utf8 Class Initialized
INFO - 2018-04-03 23:40:02 --> URI Class Initialized
INFO - 2018-04-03 23:40:02 --> Router Class Initialized
INFO - 2018-04-03 23:40:02 --> Output Class Initialized
INFO - 2018-04-03 23:40:02 --> Security Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:40:02 --> Input Class Initialized
INFO - 2018-04-03 23:40:02 --> Language Class Initialized
INFO - 2018-04-03 23:40:02 --> Loader Class Initialized
INFO - 2018-04-03 23:40:02 --> Helper loaded: url_helper
INFO - 2018-04-03 23:40:02 --> Helper loaded: form_helper
INFO - 2018-04-03 23:40:02 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:40:02 --> Form Validation Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
INFO - 2018-04-03 23:40:02 --> Controller Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:40:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:40:02 --> Final output sent to browser
DEBUG - 2018-04-03 23:40:02 --> Total execution time: 0.0423
INFO - 2018-04-03 23:40:02 --> Config Class Initialized
INFO - 2018-04-03 23:40:02 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:40:02 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:40:02 --> Utf8 Class Initialized
INFO - 2018-04-03 23:40:02 --> URI Class Initialized
INFO - 2018-04-03 23:40:02 --> Router Class Initialized
INFO - 2018-04-03 23:40:02 --> Output Class Initialized
INFO - 2018-04-03 23:40:02 --> Security Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:40:02 --> Input Class Initialized
INFO - 2018-04-03 23:40:02 --> Language Class Initialized
INFO - 2018-04-03 23:40:02 --> Loader Class Initialized
INFO - 2018-04-03 23:40:02 --> Helper loaded: url_helper
INFO - 2018-04-03 23:40:02 --> Helper loaded: form_helper
INFO - 2018-04-03 23:40:02 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:40:02 --> Form Validation Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
INFO - 2018-04-03 23:40:02 --> Controller Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
INFO - 2018-04-03 23:40:02 --> Model Class Initialized
DEBUG - 2018-04-03 23:40:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:40:05 --> Config Class Initialized
INFO - 2018-04-03 23:40:05 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:40:05 --> Utf8 Class Initialized
INFO - 2018-04-03 23:40:05 --> URI Class Initialized
INFO - 2018-04-03 23:40:05 --> Router Class Initialized
INFO - 2018-04-03 23:40:05 --> Output Class Initialized
INFO - 2018-04-03 23:40:05 --> Security Class Initialized
DEBUG - 2018-04-03 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:40:05 --> Input Class Initialized
INFO - 2018-04-03 23:40:05 --> Language Class Initialized
INFO - 2018-04-03 23:40:05 --> Loader Class Initialized
INFO - 2018-04-03 23:40:05 --> Helper loaded: url_helper
INFO - 2018-04-03 23:40:05 --> Helper loaded: form_helper
INFO - 2018-04-03 23:40:05 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:40:05 --> Form Validation Class Initialized
INFO - 2018-04-03 23:40:05 --> Model Class Initialized
INFO - 2018-04-03 23:40:05 --> Controller Class Initialized
INFO - 2018-04-03 23:40:05 --> Model Class Initialized
INFO - 2018-04-03 23:40:05 --> Model Class Initialized
DEBUG - 2018-04-03 23:40:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:40:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:40:05 --> Final output sent to browser
DEBUG - 2018-04-03 23:40:05 --> Total execution time: 0.0570
INFO - 2018-04-03 23:51:23 --> Config Class Initialized
INFO - 2018-04-03 23:51:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:51:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:51:23 --> Utf8 Class Initialized
INFO - 2018-04-03 23:51:23 --> URI Class Initialized
INFO - 2018-04-03 23:51:23 --> Router Class Initialized
INFO - 2018-04-03 23:51:23 --> Output Class Initialized
INFO - 2018-04-03 23:51:23 --> Security Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:51:23 --> Input Class Initialized
INFO - 2018-04-03 23:51:23 --> Language Class Initialized
INFO - 2018-04-03 23:51:23 --> Loader Class Initialized
INFO - 2018-04-03 23:51:23 --> Helper loaded: url_helper
INFO - 2018-04-03 23:51:23 --> Helper loaded: form_helper
INFO - 2018-04-03 23:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:51:23 --> Form Validation Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
INFO - 2018-04-03 23:51:23 --> Controller Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:51:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:51:23 --> Final output sent to browser
DEBUG - 2018-04-03 23:51:23 --> Total execution time: 0.0516
INFO - 2018-04-03 23:51:23 --> Config Class Initialized
INFO - 2018-04-03 23:51:23 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:51:23 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:51:23 --> Utf8 Class Initialized
INFO - 2018-04-03 23:51:23 --> URI Class Initialized
INFO - 2018-04-03 23:51:23 --> Router Class Initialized
INFO - 2018-04-03 23:51:23 --> Output Class Initialized
INFO - 2018-04-03 23:51:23 --> Security Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:51:23 --> Input Class Initialized
INFO - 2018-04-03 23:51:23 --> Language Class Initialized
INFO - 2018-04-03 23:51:23 --> Loader Class Initialized
INFO - 2018-04-03 23:51:23 --> Helper loaded: url_helper
INFO - 2018-04-03 23:51:23 --> Helper loaded: form_helper
INFO - 2018-04-03 23:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:51:23 --> Form Validation Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
INFO - 2018-04-03 23:51:23 --> Controller Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
INFO - 2018-04-03 23:51:23 --> Model Class Initialized
DEBUG - 2018-04-03 23:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:56:57 --> Config Class Initialized
INFO - 2018-04-03 23:56:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:56:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:56:57 --> Utf8 Class Initialized
INFO - 2018-04-03 23:56:57 --> URI Class Initialized
INFO - 2018-04-03 23:56:57 --> Router Class Initialized
INFO - 2018-04-03 23:56:57 --> Output Class Initialized
INFO - 2018-04-03 23:56:57 --> Security Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:56:57 --> Input Class Initialized
INFO - 2018-04-03 23:56:57 --> Language Class Initialized
INFO - 2018-04-03 23:56:57 --> Loader Class Initialized
INFO - 2018-04-03 23:56:57 --> Helper loaded: url_helper
INFO - 2018-04-03 23:56:57 --> Helper loaded: form_helper
INFO - 2018-04-03 23:56:57 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:56:57 --> Form Validation Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
INFO - 2018-04-03 23:56:57 --> Controller Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:56:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:56:57 --> Final output sent to browser
DEBUG - 2018-04-03 23:56:57 --> Total execution time: 0.0513
INFO - 2018-04-03 23:56:57 --> Config Class Initialized
INFO - 2018-04-03 23:56:57 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:56:57 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:56:57 --> Utf8 Class Initialized
INFO - 2018-04-03 23:56:57 --> URI Class Initialized
INFO - 2018-04-03 23:56:57 --> Router Class Initialized
INFO - 2018-04-03 23:56:57 --> Output Class Initialized
INFO - 2018-04-03 23:56:57 --> Security Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:56:57 --> Input Class Initialized
INFO - 2018-04-03 23:56:57 --> Language Class Initialized
INFO - 2018-04-03 23:56:57 --> Loader Class Initialized
INFO - 2018-04-03 23:56:57 --> Helper loaded: url_helper
INFO - 2018-04-03 23:56:57 --> Helper loaded: form_helper
INFO - 2018-04-03 23:56:57 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:56:57 --> Form Validation Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
INFO - 2018-04-03 23:56:57 --> Controller Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
INFO - 2018-04-03 23:56:57 --> Model Class Initialized
DEBUG - 2018-04-03 23:56:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:56:58 --> Config Class Initialized
INFO - 2018-04-03 23:56:58 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:56:58 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:56:58 --> Utf8 Class Initialized
INFO - 2018-04-03 23:56:58 --> URI Class Initialized
INFO - 2018-04-03 23:56:58 --> Router Class Initialized
INFO - 2018-04-03 23:56:58 --> Output Class Initialized
INFO - 2018-04-03 23:56:58 --> Security Class Initialized
DEBUG - 2018-04-03 23:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:56:58 --> Input Class Initialized
INFO - 2018-04-03 23:56:58 --> Language Class Initialized
INFO - 2018-04-03 23:56:58 --> Loader Class Initialized
INFO - 2018-04-03 23:56:58 --> Helper loaded: url_helper
INFO - 2018-04-03 23:56:58 --> Helper loaded: form_helper
INFO - 2018-04-03 23:56:58 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:56:58 --> Form Validation Class Initialized
INFO - 2018-04-03 23:56:58 --> Model Class Initialized
INFO - 2018-04-03 23:56:58 --> Controller Class Initialized
INFO - 2018-04-03 23:56:58 --> Model Class Initialized
INFO - 2018-04-03 23:56:58 --> Model Class Initialized
DEBUG - 2018-04-03 23:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:56:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:56:58 --> Final output sent to browser
DEBUG - 2018-04-03 23:56:58 --> Total execution time: 0.0419
INFO - 2018-04-03 23:59:13 --> Config Class Initialized
INFO - 2018-04-03 23:59:13 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:59:13 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:59:13 --> Utf8 Class Initialized
INFO - 2018-04-03 23:59:13 --> URI Class Initialized
INFO - 2018-04-03 23:59:13 --> Router Class Initialized
INFO - 2018-04-03 23:59:13 --> Output Class Initialized
INFO - 2018-04-03 23:59:13 --> Security Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:59:13 --> Input Class Initialized
INFO - 2018-04-03 23:59:13 --> Language Class Initialized
INFO - 2018-04-03 23:59:13 --> Loader Class Initialized
INFO - 2018-04-03 23:59:13 --> Helper loaded: url_helper
INFO - 2018-04-03 23:59:13 --> Helper loaded: form_helper
INFO - 2018-04-03 23:59:13 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:59:13 --> Form Validation Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
INFO - 2018-04-03 23:59:13 --> Controller Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-03 23:59:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-03 23:59:13 --> Final output sent to browser
DEBUG - 2018-04-03 23:59:13 --> Total execution time: 0.0513
INFO - 2018-04-03 23:59:13 --> Config Class Initialized
INFO - 2018-04-03 23:59:13 --> Hooks Class Initialized
DEBUG - 2018-04-03 23:59:13 --> UTF-8 Support Enabled
INFO - 2018-04-03 23:59:13 --> Utf8 Class Initialized
INFO - 2018-04-03 23:59:13 --> URI Class Initialized
INFO - 2018-04-03 23:59:13 --> Router Class Initialized
INFO - 2018-04-03 23:59:13 --> Output Class Initialized
INFO - 2018-04-03 23:59:13 --> Security Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 23:59:13 --> Input Class Initialized
INFO - 2018-04-03 23:59:13 --> Language Class Initialized
INFO - 2018-04-03 23:59:13 --> Loader Class Initialized
INFO - 2018-04-03 23:59:13 --> Helper loaded: url_helper
INFO - 2018-04-03 23:59:13 --> Helper loaded: form_helper
INFO - 2018-04-03 23:59:13 --> Database Driver Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 23:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 23:59:13 --> Form Validation Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
INFO - 2018-04-03 23:59:13 --> Controller Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
INFO - 2018-04-03 23:59:13 --> Model Class Initialized
DEBUG - 2018-04-03 23:59:13 --> Form_validation class already loaded. Second attempt ignored.
