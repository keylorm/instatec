<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-15 23:33:02 --> Config Class Initialized
INFO - 2018-03-15 23:33:02 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:02 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:02 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:02 --> URI Class Initialized
INFO - 2018-03-15 23:33:02 --> Router Class Initialized
INFO - 2018-03-15 23:33:02 --> Output Class Initialized
INFO - 2018-03-15 23:33:02 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:02 --> Input Class Initialized
INFO - 2018-03-15 23:33:05 --> Language Class Initialized
INFO - 2018-03-15 23:33:05 --> Loader Class Initialized
INFO - 2018-03-15 23:33:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:05 --> Model Class Initialized
INFO - 2018-03-15 23:33:05 --> Controller Class Initialized
INFO - 2018-03-15 23:33:05 --> Model Class Initialized
INFO - 2018-03-15 23:33:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:05 --> Config Class Initialized
INFO - 2018-03-15 23:33:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:05 --> URI Class Initialized
INFO - 2018-03-15 23:33:05 --> Router Class Initialized
INFO - 2018-03-15 23:33:05 --> Output Class Initialized
INFO - 2018-03-15 23:33:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:05 --> Input Class Initialized
INFO - 2018-03-15 23:33:05 --> Language Class Initialized
INFO - 2018-03-15 23:33:05 --> Loader Class Initialized
INFO - 2018-03-15 23:33:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:05 --> Model Class Initialized
INFO - 2018-03-15 23:33:05 --> Controller Class Initialized
INFO - 2018-03-15 23:33:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:33:05 --> Final output sent to browser
DEBUG - 2018-03-15 23:33:05 --> Total execution time: 0.0419
INFO - 2018-03-15 23:33:06 --> Config Class Initialized
INFO - 2018-03-15 23:33:06 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:06 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:06 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:06 --> URI Class Initialized
INFO - 2018-03-15 23:33:06 --> Router Class Initialized
INFO - 2018-03-15 23:33:06 --> Output Class Initialized
INFO - 2018-03-15 23:33:06 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:06 --> Input Class Initialized
INFO - 2018-03-15 23:33:06 --> Language Class Initialized
INFO - 2018-03-15 23:33:06 --> Loader Class Initialized
INFO - 2018-03-15 23:33:06 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:06 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:06 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:06 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:06 --> Model Class Initialized
INFO - 2018-03-15 23:33:06 --> Controller Class Initialized
INFO - 2018-03-15 23:33:06 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-15 23:33:06 --> Config Class Initialized
INFO - 2018-03-15 23:33:06 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:06 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:06 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:06 --> URI Class Initialized
DEBUG - 2018-03-15 23:33:06 --> No URI present. Default controller set.
INFO - 2018-03-15 23:33:06 --> Router Class Initialized
INFO - 2018-03-15 23:33:06 --> Output Class Initialized
INFO - 2018-03-15 23:33:06 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:06 --> Input Class Initialized
INFO - 2018-03-15 23:33:06 --> Language Class Initialized
INFO - 2018-03-15 23:33:06 --> Loader Class Initialized
INFO - 2018-03-15 23:33:06 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:06 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:06 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:06 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:06 --> Model Class Initialized
INFO - 2018-03-15 23:33:06 --> Controller Class Initialized
INFO - 2018-03-15 23:33:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:33:07 --> Final output sent to browser
DEBUG - 2018-03-15 23:33:07 --> Total execution time: 0.0481
INFO - 2018-03-15 23:33:07 --> Config Class Initialized
INFO - 2018-03-15 23:33:07 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:07 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:07 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:07 --> URI Class Initialized
INFO - 2018-03-15 23:33:07 --> Router Class Initialized
INFO - 2018-03-15 23:33:07 --> Output Class Initialized
INFO - 2018-03-15 23:33:07 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:07 --> Input Class Initialized
INFO - 2018-03-15 23:33:07 --> Language Class Initialized
INFO - 2018-03-15 23:33:07 --> Loader Class Initialized
INFO - 2018-03-15 23:33:07 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:07 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:07 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:07 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
INFO - 2018-03-15 23:33:07 --> Controller Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
INFO - 2018-03-15 23:33:07 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:09 --> Config Class Initialized
INFO - 2018-03-15 23:33:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:09 --> URI Class Initialized
INFO - 2018-03-15 23:33:09 --> Router Class Initialized
INFO - 2018-03-15 23:33:09 --> Output Class Initialized
INFO - 2018-03-15 23:33:09 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:09 --> Input Class Initialized
INFO - 2018-03-15 23:33:09 --> Language Class Initialized
INFO - 2018-03-15 23:33:09 --> Loader Class Initialized
INFO - 2018-03-15 23:33:09 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:09 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:09 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:09 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:09 --> Model Class Initialized
INFO - 2018-03-15 23:33:09 --> Controller Class Initialized
INFO - 2018-03-15 23:33:09 --> Model Class Initialized
INFO - 2018-03-15 23:33:09 --> Model Class Initialized
INFO - 2018-03-15 23:33:09 --> Model Class Initialized
INFO - 2018-03-15 23:33:09 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:33:09 --> Final output sent to browser
DEBUG - 2018-03-15 23:33:09 --> Total execution time: 0.0601
INFO - 2018-03-15 23:33:11 --> Config Class Initialized
INFO - 2018-03-15 23:33:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:11 --> URI Class Initialized
INFO - 2018-03-15 23:33:11 --> Router Class Initialized
INFO - 2018-03-15 23:33:11 --> Output Class Initialized
INFO - 2018-03-15 23:33:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:11 --> Input Class Initialized
INFO - 2018-03-15 23:33:11 --> Language Class Initialized
INFO - 2018-03-15 23:33:11 --> Loader Class Initialized
INFO - 2018-03-15 23:33:11 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:11 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:11 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:11 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
INFO - 2018-03-15 23:33:11 --> Controller Class Initialized
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:11 --> Model Class Initialized
INFO - 2018-03-15 23:33:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:33:11 --> Final output sent to browser
DEBUG - 2018-03-15 23:33:11 --> Total execution time: 0.0581
INFO - 2018-03-15 23:33:14 --> Config Class Initialized
INFO - 2018-03-15 23:33:14 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:14 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:14 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:14 --> URI Class Initialized
INFO - 2018-03-15 23:33:14 --> Router Class Initialized
INFO - 2018-03-15 23:33:14 --> Output Class Initialized
INFO - 2018-03-15 23:33:14 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:14 --> Input Class Initialized
INFO - 2018-03-15 23:33:14 --> Language Class Initialized
INFO - 2018-03-15 23:33:14 --> Loader Class Initialized
INFO - 2018-03-15 23:33:14 --> Helper loaded: url_helper
INFO - 2018-03-15 23:33:14 --> Helper loaded: form_helper
INFO - 2018-03-15 23:33:15 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:33:15 --> Form Validation Class Initialized
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
INFO - 2018-03-15 23:33:15 --> Controller Class Initialized
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
DEBUG - 2018-03-15 23:33:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:33:15 --> Model Class Initialized
INFO - 2018-03-15 23:33:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:33:15 --> Final output sent to browser
DEBUG - 2018-03-15 23:33:15 --> Total execution time: 0.0546
INFO - 2018-03-15 23:33:15 --> Config Class Initialized
INFO - 2018-03-15 23:33:15 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:15 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:15 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:15 --> URI Class Initialized
INFO - 2018-03-15 23:33:15 --> Router Class Initialized
INFO - 2018-03-15 23:33:15 --> Output Class Initialized
INFO - 2018-03-15 23:33:15 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:15 --> Input Class Initialized
INFO - 2018-03-15 23:33:15 --> Language Class Initialized
ERROR - 2018-03-15 23:33:15 --> 404 Page Not Found: Reportes/colaborador
INFO - 2018-03-15 23:33:19 --> Config Class Initialized
INFO - 2018-03-15 23:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:19 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:19 --> URI Class Initialized
INFO - 2018-03-15 23:33:19 --> Router Class Initialized
INFO - 2018-03-15 23:33:19 --> Output Class Initialized
INFO - 2018-03-15 23:33:19 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:19 --> Input Class Initialized
INFO - 2018-03-15 23:33:19 --> Language Class Initialized
ERROR - 2018-03-15 23:33:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:33:19 --> Config Class Initialized
INFO - 2018-03-15 23:33:19 --> Config Class Initialized
INFO - 2018-03-15 23:33:19 --> Hooks Class Initialized
INFO - 2018-03-15 23:33:19 --> Hooks Class Initialized
INFO - 2018-03-15 23:33:19 --> Config Class Initialized
INFO - 2018-03-15 23:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:33:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:19 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:33:19 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:19 --> Utf8 Class Initialized
INFO - 2018-03-15 23:33:19 --> URI Class Initialized
INFO - 2018-03-15 23:33:19 --> URI Class Initialized
INFO - 2018-03-15 23:33:19 --> URI Class Initialized
INFO - 2018-03-15 23:33:19 --> Router Class Initialized
INFO - 2018-03-15 23:33:19 --> Router Class Initialized
INFO - 2018-03-15 23:33:19 --> Router Class Initialized
INFO - 2018-03-15 23:33:19 --> Output Class Initialized
INFO - 2018-03-15 23:33:19 --> Output Class Initialized
INFO - 2018-03-15 23:33:19 --> Security Class Initialized
INFO - 2018-03-15 23:33:19 --> Security Class Initialized
INFO - 2018-03-15 23:33:19 --> Output Class Initialized
DEBUG - 2018-03-15 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:19 --> Security Class Initialized
DEBUG - 2018-03-15 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:19 --> Input Class Initialized
INFO - 2018-03-15 23:33:19 --> Input Class Initialized
INFO - 2018-03-15 23:33:19 --> Language Class Initialized
DEBUG - 2018-03-15 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:33:19 --> Language Class Initialized
INFO - 2018-03-15 23:33:19 --> Input Class Initialized
ERROR - 2018-03-15 23:33:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:33:19 --> Language Class Initialized
ERROR - 2018-03-15 23:33:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:33:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Loader Class Initialized
INFO - 2018-03-15 23:34:09 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:09 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:09 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:09 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:09 --> Model Class Initialized
INFO - 2018-03-15 23:34:09 --> Controller Class Initialized
INFO - 2018-03-15 23:34:09 --> Model Class Initialized
INFO - 2018-03-15 23:34:09 --> Model Class Initialized
INFO - 2018-03-15 23:34:09 --> Model Class Initialized
INFO - 2018-03-15 23:34:09 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:09 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:09 --> Total execution time: 0.0557
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> Config Class Initialized
INFO - 2018-03-15 23:34:09 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> URI Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
INFO - 2018-03-15 23:34:09 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Output Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
INFO - 2018-03-15 23:34:09 --> Security Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:09 --> Input Class Initialized
INFO - 2018-03-15 23:34:09 --> Language Class Initialized
ERROR - 2018-03-15 23:34:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
INFO - 2018-03-15 23:34:11 --> Loader Class Initialized
INFO - 2018-03-15 23:34:11 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:11 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:11 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:11 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:11 --> Model Class Initialized
INFO - 2018-03-15 23:34:11 --> Controller Class Initialized
INFO - 2018-03-15 23:34:11 --> Model Class Initialized
INFO - 2018-03-15 23:34:11 --> Model Class Initialized
INFO - 2018-03-15 23:34:11 --> Model Class Initialized
INFO - 2018-03-15 23:34:11 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:11 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:11 --> Total execution time: 0.0988
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:11 --> Config Class Initialized
INFO - 2018-03-15 23:34:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:11 --> URI Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Router Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Output Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
INFO - 2018-03-15 23:34:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:11 --> Input Class Initialized
INFO - 2018-03-15 23:34:11 --> Language Class Initialized
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:34:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
INFO - 2018-03-15 23:34:25 --> Loader Class Initialized
INFO - 2018-03-15 23:34:25 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:25 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:25 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:25 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:25 --> Model Class Initialized
INFO - 2018-03-15 23:34:25 --> Controller Class Initialized
INFO - 2018-03-15 23:34:25 --> Model Class Initialized
INFO - 2018-03-15 23:34:25 --> Model Class Initialized
INFO - 2018-03-15 23:34:25 --> Model Class Initialized
INFO - 2018-03-15 23:34:25 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:25 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:25 --> Total execution time: 0.0528
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:25 --> Config Class Initialized
INFO - 2018-03-15 23:34:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> URI Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
INFO - 2018-03-15 23:34:25 --> Router Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
INFO - 2018-03-15 23:34:25 --> Output Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
INFO - 2018-03-15 23:34:25 --> Security Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:25 --> Input Class Initialized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:25 --> Language Class Initialized
ERROR - 2018-03-15 23:34:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:27 --> Config Class Initialized
INFO - 2018-03-15 23:34:27 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:27 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:27 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:27 --> URI Class Initialized
INFO - 2018-03-15 23:34:27 --> Router Class Initialized
INFO - 2018-03-15 23:34:27 --> Output Class Initialized
INFO - 2018-03-15 23:34:27 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:27 --> Input Class Initialized
INFO - 2018-03-15 23:34:27 --> Language Class Initialized
INFO - 2018-03-15 23:34:27 --> Loader Class Initialized
INFO - 2018-03-15 23:34:27 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:27 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:27 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:27 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:27 --> Model Class Initialized
INFO - 2018-03-15 23:34:27 --> Controller Class Initialized
INFO - 2018-03-15 23:34:27 --> Model Class Initialized
INFO - 2018-03-15 23:34:27 --> Model Class Initialized
INFO - 2018-03-15 23:34:27 --> Model Class Initialized
INFO - 2018-03-15 23:34:27 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:27 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:27 --> Total execution time: 0.0494
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:28 --> Config Class Initialized
INFO - 2018-03-15 23:34:28 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:28 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:28 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:28 --> URI Class Initialized
INFO - 2018-03-15 23:34:28 --> Router Class Initialized
INFO - 2018-03-15 23:34:28 --> Output Class Initialized
INFO - 2018-03-15 23:34:28 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:28 --> Input Class Initialized
INFO - 2018-03-15 23:34:28 --> Language Class Initialized
ERROR - 2018-03-15 23:34:28 --> 404 Page Not Found: Reportes/proyecto
INFO - 2018-03-15 23:34:42 --> Config Class Initialized
INFO - 2018-03-15 23:34:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:42 --> URI Class Initialized
INFO - 2018-03-15 23:34:42 --> Router Class Initialized
INFO - 2018-03-15 23:34:42 --> Output Class Initialized
INFO - 2018-03-15 23:34:42 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:42 --> Input Class Initialized
INFO - 2018-03-15 23:34:42 --> Language Class Initialized
INFO - 2018-03-15 23:34:42 --> Loader Class Initialized
INFO - 2018-03-15 23:34:42 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:42 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:42 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:42 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:42 --> Model Class Initialized
INFO - 2018-03-15 23:34:42 --> Controller Class Initialized
INFO - 2018-03-15 23:34:42 --> Model Class Initialized
INFO - 2018-03-15 23:34:42 --> Model Class Initialized
INFO - 2018-03-15 23:34:42 --> Model Class Initialized
INFO - 2018-03-15 23:34:42 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:42 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:42 --> Total execution time: 0.0506
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:34:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:43 --> Config Class Initialized
INFO - 2018-03-15 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:43 --> URI Class Initialized
INFO - 2018-03-15 23:34:43 --> Router Class Initialized
INFO - 2018-03-15 23:34:43 --> Output Class Initialized
INFO - 2018-03-15 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:43 --> Input Class Initialized
INFO - 2018-03-15 23:34:43 --> Language Class Initialized
INFO - 2018-03-15 23:34:43 --> Loader Class Initialized
INFO - 2018-03-15 23:34:43 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:43 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:43 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:43 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
INFO - 2018-03-15 23:34:43 --> Controller Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
INFO - 2018-03-15 23:34:43 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> Loader Class Initialized
INFO - 2018-03-15 23:34:45 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:45 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:45 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:45 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:45 --> Model Class Initialized
INFO - 2018-03-15 23:34:45 --> Controller Class Initialized
INFO - 2018-03-15 23:34:45 --> Model Class Initialized
INFO - 2018-03-15 23:34:45 --> Model Class Initialized
INFO - 2018-03-15 23:34:45 --> Model Class Initialized
INFO - 2018-03-15 23:34:45 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:45 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:45 --> Total execution time: 0.0516
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:45 --> Config Class Initialized
INFO - 2018-03-15 23:34:45 --> Hooks Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
INFO - 2018-03-15 23:34:45 --> URI Class Initialized
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
INFO - 2018-03-15 23:34:45 --> Router Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
INFO - 2018-03-15 23:34:45 --> Output Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:45 --> Input Class Initialized
INFO - 2018-03-15 23:34:45 --> Language Class Initialized
ERROR - 2018-03-15 23:34:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:46 --> Config Class Initialized
INFO - 2018-03-15 23:34:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:46 --> URI Class Initialized
INFO - 2018-03-15 23:34:46 --> Router Class Initialized
INFO - 2018-03-15 23:34:46 --> Output Class Initialized
INFO - 2018-03-15 23:34:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:46 --> Input Class Initialized
INFO - 2018-03-15 23:34:46 --> Language Class Initialized
INFO - 2018-03-15 23:34:46 --> Loader Class Initialized
INFO - 2018-03-15 23:34:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:34:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:34:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:34:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
INFO - 2018-03-15 23:34:46 --> Controller Class Initialized
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:34:46 --> Model Class Initialized
INFO - 2018-03-15 23:34:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:34:46 --> Final output sent to browser
DEBUG - 2018-03-15 23:34:46 --> Total execution time: 0.0635
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:34:47 --> Config Class Initialized
INFO - 2018-03-15 23:34:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:34:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:34:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:34:47 --> URI Class Initialized
INFO - 2018-03-15 23:34:47 --> Router Class Initialized
INFO - 2018-03-15 23:34:47 --> Output Class Initialized
INFO - 2018-03-15 23:34:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:34:47 --> Input Class Initialized
INFO - 2018-03-15 23:34:47 --> Language Class Initialized
ERROR - 2018-03-15 23:34:47 --> 404 Page Not Found: Reportes/colaborador
INFO - 2018-03-15 23:35:20 --> Config Class Initialized
INFO - 2018-03-15 23:35:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:20 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
INFO - 2018-03-15 23:35:21 --> Loader Class Initialized
INFO - 2018-03-15 23:35:21 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:21 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:21 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:21 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:21 --> Model Class Initialized
INFO - 2018-03-15 23:35:21 --> Controller Class Initialized
INFO - 2018-03-15 23:35:21 --> Model Class Initialized
INFO - 2018-03-15 23:35:21 --> Model Class Initialized
INFO - 2018-03-15 23:35:21 --> Model Class Initialized
INFO - 2018-03-15 23:35:21 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:35:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:35:21 --> Final output sent to browser
DEBUG - 2018-03-15 23:35:21 --> Total execution time: 0.0510
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Config Class Initialized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:21 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:21 --> URI Class Initialized
INFO - 2018-03-15 23:35:21 --> Router Class Initialized
INFO - 2018-03-15 23:35:21 --> Output Class Initialized
INFO - 2018-03-15 23:35:21 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:21 --> Input Class Initialized
INFO - 2018-03-15 23:35:21 --> Language Class Initialized
ERROR - 2018-03-15 23:35:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Loader Class Initialized
INFO - 2018-03-15 23:35:22 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:22 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:22 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:22 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Controller Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:35:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:35:22 --> Final output sent to browser
DEBUG - 2018-03-15 23:35:22 --> Total execution time: 0.0494
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
ERROR - 2018-03-15 23:35:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:22 --> Config Class Initialized
INFO - 2018-03-15 23:35:22 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:22 --> URI Class Initialized
INFO - 2018-03-15 23:35:22 --> Router Class Initialized
INFO - 2018-03-15 23:35:22 --> Output Class Initialized
INFO - 2018-03-15 23:35:22 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:22 --> Input Class Initialized
INFO - 2018-03-15 23:35:22 --> Language Class Initialized
INFO - 2018-03-15 23:35:22 --> Loader Class Initialized
INFO - 2018-03-15 23:35:22 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:22 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:22 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:22 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Controller Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
INFO - 2018-03-15 23:35:22 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:35:23 --> Config Class Initialized
INFO - 2018-03-15 23:35:23 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:23 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:23 --> URI Class Initialized
INFO - 2018-03-15 23:35:23 --> Router Class Initialized
INFO - 2018-03-15 23:35:23 --> Output Class Initialized
INFO - 2018-03-15 23:35:23 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:23 --> Input Class Initialized
INFO - 2018-03-15 23:35:23 --> Language Class Initialized
INFO - 2018-03-15 23:35:23 --> Loader Class Initialized
INFO - 2018-03-15 23:35:23 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:23 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:23 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:23 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:23 --> Model Class Initialized
INFO - 2018-03-15 23:35:23 --> Controller Class Initialized
INFO - 2018-03-15 23:35:23 --> Model Class Initialized
INFO - 2018-03-15 23:35:23 --> Model Class Initialized
INFO - 2018-03-15 23:35:23 --> Model Class Initialized
INFO - 2018-03-15 23:35:23 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:35:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:35:23 --> Final output sent to browser
DEBUG - 2018-03-15 23:35:23 --> Total execution time: 0.0505
INFO - 2018-03-15 23:35:23 --> Config Class Initialized
INFO - 2018-03-15 23:35:23 --> Config Class Initialized
INFO - 2018-03-15 23:35:23 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:23 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:23 --> Config Class Initialized
INFO - 2018-03-15 23:35:23 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:23 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:23 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:23 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:23 --> URI Class Initialized
INFO - 2018-03-15 23:35:23 --> Config Class Initialized
INFO - 2018-03-15 23:35:23 --> URI Class Initialized
INFO - 2018-03-15 23:35:23 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:23 --> URI Class Initialized
INFO - 2018-03-15 23:35:23 --> Router Class Initialized
INFO - 2018-03-15 23:35:23 --> Router Class Initialized
INFO - 2018-03-15 23:35:23 --> Router Class Initialized
INFO - 2018-03-15 23:35:23 --> Output Class Initialized
DEBUG - 2018-03-15 23:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:23 --> Output Class Initialized
INFO - 2018-03-15 23:35:24 --> Output Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
INFO - 2018-03-15 23:35:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
INFO - 2018-03-15 23:35:24 --> Config Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:24 --> URI Class Initialized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Config Class Initialized
INFO - 2018-03-15 23:35:24 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Router Class Initialized
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:24 --> Utf8 Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:24 --> Output Class Initialized
INFO - 2018-03-15 23:35:24 --> URI Class Initialized
DEBUG - 2018-03-15 23:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
INFO - 2018-03-15 23:35:24 --> URI Class Initialized
INFO - 2018-03-15 23:35:24 --> Router Class Initialized
INFO - 2018-03-15 23:35:24 --> Router Class Initialized
INFO - 2018-03-15 23:35:24 --> Output Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
INFO - 2018-03-15 23:35:24 --> Output Class Initialized
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
INFO - 2018-03-15 23:35:24 --> Config Class Initialized
INFO - 2018-03-15 23:35:24 --> Hooks Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:24 --> URI Class Initialized
INFO - 2018-03-15 23:35:24 --> Router Class Initialized
INFO - 2018-03-15 23:35:24 --> Output Class Initialized
INFO - 2018-03-15 23:35:24 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:24 --> Input Class Initialized
INFO - 2018-03-15 23:35:24 --> Language Class Initialized
ERROR - 2018-03-15 23:35:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Loader Class Initialized
INFO - 2018-03-15 23:35:35 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:35 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:35 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:35 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Controller Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:35:35 --> Final output sent to browser
DEBUG - 2018-03-15 23:35:35 --> Total execution time: 0.0493
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:35:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:35:35 --> Config Class Initialized
INFO - 2018-03-15 23:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:35:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:35:35 --> URI Class Initialized
INFO - 2018-03-15 23:35:35 --> Router Class Initialized
INFO - 2018-03-15 23:35:35 --> Output Class Initialized
INFO - 2018-03-15 23:35:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:35:35 --> Input Class Initialized
INFO - 2018-03-15 23:35:35 --> Language Class Initialized
INFO - 2018-03-15 23:35:35 --> Loader Class Initialized
INFO - 2018-03-15 23:35:35 --> Helper loaded: url_helper
INFO - 2018-03-15 23:35:35 --> Helper loaded: form_helper
INFO - 2018-03-15 23:35:35 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:35:35 --> Form Validation Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Controller Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
INFO - 2018-03-15 23:35:35 --> Model Class Initialized
DEBUG - 2018-03-15 23:35:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:36:46 --> Config Class Initialized
INFO - 2018-03-15 23:36:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:36:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:36:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:36:46 --> URI Class Initialized
INFO - 2018-03-15 23:36:46 --> Router Class Initialized
INFO - 2018-03-15 23:36:46 --> Output Class Initialized
INFO - 2018-03-15 23:36:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:36:46 --> Input Class Initialized
INFO - 2018-03-15 23:36:46 --> Language Class Initialized
INFO - 2018-03-15 23:36:46 --> Loader Class Initialized
INFO - 2018-03-15 23:36:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:36:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:36:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:36:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Controller Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:36:46 --> Final output sent to browser
DEBUG - 2018-03-15 23:36:46 --> Total execution time: 0.0498
INFO - 2018-03-15 23:36:46 --> Config Class Initialized
INFO - 2018-03-15 23:36:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:36:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:36:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:36:46 --> URI Class Initialized
INFO - 2018-03-15 23:36:46 --> Router Class Initialized
INFO - 2018-03-15 23:36:46 --> Output Class Initialized
INFO - 2018-03-15 23:36:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:36:46 --> Input Class Initialized
INFO - 2018-03-15 23:36:46 --> Language Class Initialized
INFO - 2018-03-15 23:36:46 --> Loader Class Initialized
INFO - 2018-03-15 23:36:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:36:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:36:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:36:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Controller Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
INFO - 2018-03-15 23:36:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:37:43 --> Config Class Initialized
INFO - 2018-03-15 23:37:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:37:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:37:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:37:43 --> URI Class Initialized
INFO - 2018-03-15 23:37:43 --> Router Class Initialized
INFO - 2018-03-15 23:37:43 --> Output Class Initialized
INFO - 2018-03-15 23:37:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:37:43 --> Input Class Initialized
INFO - 2018-03-15 23:37:43 --> Language Class Initialized
INFO - 2018-03-15 23:37:43 --> Loader Class Initialized
INFO - 2018-03-15 23:37:43 --> Helper loaded: url_helper
INFO - 2018-03-15 23:37:43 --> Helper loaded: form_helper
INFO - 2018-03-15 23:37:43 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:37:43 --> Form Validation Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Controller Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:37:43 --> Final output sent to browser
DEBUG - 2018-03-15 23:37:43 --> Total execution time: 0.1239
INFO - 2018-03-15 23:37:43 --> Config Class Initialized
INFO - 2018-03-15 23:37:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:37:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:37:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:37:43 --> URI Class Initialized
INFO - 2018-03-15 23:37:43 --> Router Class Initialized
INFO - 2018-03-15 23:37:43 --> Output Class Initialized
INFO - 2018-03-15 23:37:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:37:43 --> Input Class Initialized
INFO - 2018-03-15 23:37:43 --> Language Class Initialized
INFO - 2018-03-15 23:37:43 --> Loader Class Initialized
INFO - 2018-03-15 23:37:43 --> Helper loaded: url_helper
INFO - 2018-03-15 23:37:43 --> Helper loaded: form_helper
INFO - 2018-03-15 23:37:43 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:37:43 --> Form Validation Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Controller Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
INFO - 2018-03-15 23:37:43 --> Model Class Initialized
DEBUG - 2018-03-15 23:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:37:46 --> Config Class Initialized
INFO - 2018-03-15 23:37:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:37:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:37:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:37:46 --> URI Class Initialized
INFO - 2018-03-15 23:37:46 --> Router Class Initialized
INFO - 2018-03-15 23:37:46 --> Output Class Initialized
INFO - 2018-03-15 23:37:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:37:46 --> Input Class Initialized
INFO - 2018-03-15 23:37:46 --> Language Class Initialized
INFO - 2018-03-15 23:37:46 --> Loader Class Initialized
INFO - 2018-03-15 23:37:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:37:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:37:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:37:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Controller Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:37:46 --> Final output sent to browser
DEBUG - 2018-03-15 23:37:46 --> Total execution time: 0.0847
INFO - 2018-03-15 23:37:46 --> Config Class Initialized
INFO - 2018-03-15 23:37:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:37:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:37:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:37:46 --> URI Class Initialized
INFO - 2018-03-15 23:37:46 --> Router Class Initialized
INFO - 2018-03-15 23:37:46 --> Output Class Initialized
INFO - 2018-03-15 23:37:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:37:46 --> Input Class Initialized
INFO - 2018-03-15 23:37:46 --> Language Class Initialized
INFO - 2018-03-15 23:37:46 --> Loader Class Initialized
INFO - 2018-03-15 23:37:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:37:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:37:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:37:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Controller Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
INFO - 2018-03-15 23:37:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:37:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:38:22 --> Config Class Initialized
INFO - 2018-03-15 23:38:22 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:38:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:38:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:38:22 --> URI Class Initialized
INFO - 2018-03-15 23:38:22 --> Router Class Initialized
INFO - 2018-03-15 23:38:22 --> Output Class Initialized
INFO - 2018-03-15 23:38:22 --> Security Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:38:22 --> Input Class Initialized
INFO - 2018-03-15 23:38:22 --> Language Class Initialized
INFO - 2018-03-15 23:38:22 --> Loader Class Initialized
INFO - 2018-03-15 23:38:22 --> Helper loaded: url_helper
INFO - 2018-03-15 23:38:22 --> Helper loaded: form_helper
INFO - 2018-03-15 23:38:22 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:38:22 --> Form Validation Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Controller Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:38:22 --> Final output sent to browser
DEBUG - 2018-03-15 23:38:22 --> Total execution time: 0.0957
INFO - 2018-03-15 23:38:22 --> Config Class Initialized
INFO - 2018-03-15 23:38:22 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:38:22 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:38:22 --> Utf8 Class Initialized
INFO - 2018-03-15 23:38:22 --> URI Class Initialized
INFO - 2018-03-15 23:38:22 --> Router Class Initialized
INFO - 2018-03-15 23:38:22 --> Output Class Initialized
INFO - 2018-03-15 23:38:22 --> Security Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:38:22 --> Input Class Initialized
INFO - 2018-03-15 23:38:22 --> Language Class Initialized
INFO - 2018-03-15 23:38:22 --> Loader Class Initialized
INFO - 2018-03-15 23:38:22 --> Helper loaded: url_helper
INFO - 2018-03-15 23:38:22 --> Helper loaded: form_helper
INFO - 2018-03-15 23:38:22 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:38:22 --> Form Validation Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Controller Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
INFO - 2018-03-15 23:38:22 --> Model Class Initialized
DEBUG - 2018-03-15 23:38:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:01 --> Config Class Initialized
INFO - 2018-03-15 23:39:01 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:01 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:01 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:01 --> URI Class Initialized
INFO - 2018-03-15 23:39:01 --> Router Class Initialized
INFO - 2018-03-15 23:39:01 --> Output Class Initialized
INFO - 2018-03-15 23:39:01 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:01 --> Input Class Initialized
INFO - 2018-03-15 23:39:01 --> Language Class Initialized
INFO - 2018-03-15 23:39:01 --> Loader Class Initialized
INFO - 2018-03-15 23:39:01 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:01 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:01 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:01 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Controller Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:39:01 --> Final output sent to browser
DEBUG - 2018-03-15 23:39:01 --> Total execution time: 0.1152
INFO - 2018-03-15 23:39:01 --> Config Class Initialized
INFO - 2018-03-15 23:39:01 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:01 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:01 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:01 --> URI Class Initialized
INFO - 2018-03-15 23:39:01 --> Router Class Initialized
INFO - 2018-03-15 23:39:01 --> Output Class Initialized
INFO - 2018-03-15 23:39:01 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:01 --> Input Class Initialized
INFO - 2018-03-15 23:39:01 --> Language Class Initialized
INFO - 2018-03-15 23:39:01 --> Loader Class Initialized
INFO - 2018-03-15 23:39:01 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:01 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:01 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:01 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Controller Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
INFO - 2018-03-15 23:39:01 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:31 --> Config Class Initialized
INFO - 2018-03-15 23:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:31 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:31 --> URI Class Initialized
INFO - 2018-03-15 23:39:31 --> Router Class Initialized
INFO - 2018-03-15 23:39:31 --> Output Class Initialized
INFO - 2018-03-15 23:39:31 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:31 --> Input Class Initialized
INFO - 2018-03-15 23:39:31 --> Language Class Initialized
INFO - 2018-03-15 23:39:31 --> Loader Class Initialized
INFO - 2018-03-15 23:39:31 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:31 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:31 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:31 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:31 --> Model Class Initialized
INFO - 2018-03-15 23:39:31 --> Controller Class Initialized
INFO - 2018-03-15 23:39:31 --> Model Class Initialized
INFO - 2018-03-15 23:39:31 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:34 --> Config Class Initialized
INFO - 2018-03-15 23:39:34 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:34 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:34 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:34 --> URI Class Initialized
INFO - 2018-03-15 23:39:34 --> Router Class Initialized
INFO - 2018-03-15 23:39:34 --> Output Class Initialized
INFO - 2018-03-15 23:39:34 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:34 --> Input Class Initialized
INFO - 2018-03-15 23:39:34 --> Language Class Initialized
INFO - 2018-03-15 23:39:34 --> Loader Class Initialized
INFO - 2018-03-15 23:39:34 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:34 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:34 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:34 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:34 --> Model Class Initialized
INFO - 2018-03-15 23:39:34 --> Controller Class Initialized
INFO - 2018-03-15 23:39:34 --> Model Class Initialized
INFO - 2018-03-15 23:39:34 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:36 --> Config Class Initialized
INFO - 2018-03-15 23:39:36 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:36 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:36 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:36 --> URI Class Initialized
INFO - 2018-03-15 23:39:36 --> Router Class Initialized
INFO - 2018-03-15 23:39:36 --> Output Class Initialized
INFO - 2018-03-15 23:39:36 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:36 --> Input Class Initialized
INFO - 2018-03-15 23:39:36 --> Language Class Initialized
INFO - 2018-03-15 23:39:36 --> Loader Class Initialized
INFO - 2018-03-15 23:39:36 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:36 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:36 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:36 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:36 --> Model Class Initialized
INFO - 2018-03-15 23:39:36 --> Controller Class Initialized
INFO - 2018-03-15 23:39:36 --> Model Class Initialized
INFO - 2018-03-15 23:39:36 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:38 --> Config Class Initialized
INFO - 2018-03-15 23:39:38 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:38 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:38 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:38 --> URI Class Initialized
INFO - 2018-03-15 23:39:38 --> Router Class Initialized
INFO - 2018-03-15 23:39:38 --> Output Class Initialized
INFO - 2018-03-15 23:39:38 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:38 --> Input Class Initialized
INFO - 2018-03-15 23:39:38 --> Language Class Initialized
INFO - 2018-03-15 23:39:38 --> Loader Class Initialized
INFO - 2018-03-15 23:39:38 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:38 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:38 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:38 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:38 --> Model Class Initialized
INFO - 2018-03-15 23:39:38 --> Controller Class Initialized
INFO - 2018-03-15 23:39:38 --> Model Class Initialized
INFO - 2018-03-15 23:39:38 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:42 --> Config Class Initialized
INFO - 2018-03-15 23:39:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:42 --> URI Class Initialized
INFO - 2018-03-15 23:39:42 --> Router Class Initialized
INFO - 2018-03-15 23:39:42 --> Output Class Initialized
INFO - 2018-03-15 23:39:42 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:42 --> Input Class Initialized
INFO - 2018-03-15 23:39:42 --> Language Class Initialized
INFO - 2018-03-15 23:39:42 --> Loader Class Initialized
INFO - 2018-03-15 23:39:42 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:42 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:42 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:42 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:42 --> Model Class Initialized
INFO - 2018-03-15 23:39:42 --> Controller Class Initialized
INFO - 2018-03-15 23:39:42 --> Model Class Initialized
INFO - 2018-03-15 23:39:42 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:43 --> Config Class Initialized
INFO - 2018-03-15 23:39:43 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:43 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:43 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:43 --> URI Class Initialized
INFO - 2018-03-15 23:39:43 --> Router Class Initialized
INFO - 2018-03-15 23:39:43 --> Output Class Initialized
INFO - 2018-03-15 23:39:43 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:43 --> Input Class Initialized
INFO - 2018-03-15 23:39:43 --> Language Class Initialized
INFO - 2018-03-15 23:39:43 --> Loader Class Initialized
INFO - 2018-03-15 23:39:43 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:43 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:43 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:43 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:43 --> Model Class Initialized
INFO - 2018-03-15 23:39:43 --> Controller Class Initialized
INFO - 2018-03-15 23:39:43 --> Model Class Initialized
INFO - 2018-03-15 23:39:43 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:45 --> Config Class Initialized
INFO - 2018-03-15 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:45 --> URI Class Initialized
INFO - 2018-03-15 23:39:45 --> Router Class Initialized
INFO - 2018-03-15 23:39:45 --> Output Class Initialized
INFO - 2018-03-15 23:39:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:45 --> Input Class Initialized
INFO - 2018-03-15 23:39:45 --> Language Class Initialized
INFO - 2018-03-15 23:39:45 --> Loader Class Initialized
INFO - 2018-03-15 23:39:45 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:45 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:45 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:45 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:45 --> Model Class Initialized
INFO - 2018-03-15 23:39:45 --> Controller Class Initialized
INFO - 2018-03-15 23:39:45 --> Model Class Initialized
INFO - 2018-03-15 23:39:45 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:39:45 --> Final output sent to browser
DEBUG - 2018-03-15 23:39:45 --> Total execution time: 0.0445
INFO - 2018-03-15 23:39:45 --> Config Class Initialized
INFO - 2018-03-15 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:45 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:45 --> URI Class Initialized
INFO - 2018-03-15 23:39:45 --> Router Class Initialized
INFO - 2018-03-15 23:39:45 --> Output Class Initialized
INFO - 2018-03-15 23:39:45 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:45 --> Input Class Initialized
INFO - 2018-03-15 23:39:45 --> Language Class Initialized
INFO - 2018-03-15 23:39:45 --> Loader Class Initialized
INFO - 2018-03-15 23:39:45 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:45 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:45 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:45 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:45 --> Model Class Initialized
INFO - 2018-03-15 23:39:45 --> Controller Class Initialized
INFO - 2018-03-15 23:39:45 --> Model Class Initialized
INFO - 2018-03-15 23:39:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:51 --> Config Class Initialized
INFO - 2018-03-15 23:39:51 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:51 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:51 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:51 --> URI Class Initialized
INFO - 2018-03-15 23:39:51 --> Router Class Initialized
INFO - 2018-03-15 23:39:51 --> Output Class Initialized
INFO - 2018-03-15 23:39:51 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:51 --> Input Class Initialized
INFO - 2018-03-15 23:39:51 --> Language Class Initialized
INFO - 2018-03-15 23:39:51 --> Loader Class Initialized
INFO - 2018-03-15 23:39:51 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:51 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:51 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:51 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:51 --> Model Class Initialized
INFO - 2018-03-15 23:39:51 --> Controller Class Initialized
INFO - 2018-03-15 23:39:51 --> Model Class Initialized
INFO - 2018-03-15 23:39:51 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:53 --> Config Class Initialized
INFO - 2018-03-15 23:39:53 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:53 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:53 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:53 --> URI Class Initialized
INFO - 2018-03-15 23:39:53 --> Router Class Initialized
INFO - 2018-03-15 23:39:53 --> Output Class Initialized
INFO - 2018-03-15 23:39:53 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:53 --> Input Class Initialized
INFO - 2018-03-15 23:39:53 --> Language Class Initialized
INFO - 2018-03-15 23:39:53 --> Loader Class Initialized
INFO - 2018-03-15 23:39:53 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:53 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:53 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:53 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
INFO - 2018-03-15 23:39:53 --> Controller Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:53 --> Config Class Initialized
INFO - 2018-03-15 23:39:53 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:53 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:53 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:53 --> URI Class Initialized
INFO - 2018-03-15 23:39:53 --> Router Class Initialized
INFO - 2018-03-15 23:39:53 --> Output Class Initialized
INFO - 2018-03-15 23:39:53 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:53 --> Input Class Initialized
INFO - 2018-03-15 23:39:53 --> Language Class Initialized
INFO - 2018-03-15 23:39:53 --> Loader Class Initialized
INFO - 2018-03-15 23:39:53 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:53 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:53 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:53 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
INFO - 2018-03-15 23:39:53 --> Controller Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
INFO - 2018-03-15 23:39:53 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:54 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:54 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Controller Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:54 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:54 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Controller Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:54 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:54 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Controller Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:54 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:54 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Controller Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:54 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:54 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Controller Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
INFO - 2018-03-15 23:39:54 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:39:54 --> Config Class Initialized
INFO - 2018-03-15 23:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:39:54 --> Utf8 Class Initialized
INFO - 2018-03-15 23:39:54 --> URI Class Initialized
INFO - 2018-03-15 23:39:54 --> Router Class Initialized
INFO - 2018-03-15 23:39:54 --> Output Class Initialized
INFO - 2018-03-15 23:39:54 --> Security Class Initialized
DEBUG - 2018-03-15 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:39:54 --> Input Class Initialized
INFO - 2018-03-15 23:39:54 --> Language Class Initialized
INFO - 2018-03-15 23:39:54 --> Loader Class Initialized
INFO - 2018-03-15 23:39:54 --> Helper loaded: url_helper
INFO - 2018-03-15 23:39:54 --> Helper loaded: form_helper
INFO - 2018-03-15 23:39:55 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:39:55 --> Form Validation Class Initialized
INFO - 2018-03-15 23:39:55 --> Model Class Initialized
INFO - 2018-03-15 23:39:55 --> Controller Class Initialized
INFO - 2018-03-15 23:39:55 --> Model Class Initialized
INFO - 2018-03-15 23:39:55 --> Model Class Initialized
DEBUG - 2018-03-15 23:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> Config Class Initialized
INFO - 2018-03-15 23:40:30 --> Hooks Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
DEBUG - 2018-03-15 23:40:30 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:30 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
INFO - 2018-03-15 23:40:30 --> URI Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Router Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
INFO - 2018-03-15 23:40:30 --> Output Class Initialized
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
INFO - 2018-03-15 23:40:30 --> Security Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
DEBUG - 2018-03-15 23:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:30 --> Input Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:40:30 --> Language Class Initialized
ERROR - 2018-03-15 23:40:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:40:32 --> Config Class Initialized
INFO - 2018-03-15 23:40:32 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:33 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:33 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:33 --> URI Class Initialized
INFO - 2018-03-15 23:40:33 --> Router Class Initialized
INFO - 2018-03-15 23:40:33 --> Output Class Initialized
INFO - 2018-03-15 23:40:33 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:33 --> Input Class Initialized
INFO - 2018-03-15 23:40:33 --> Language Class Initialized
INFO - 2018-03-15 23:40:33 --> Loader Class Initialized
INFO - 2018-03-15 23:40:33 --> Helper loaded: url_helper
INFO - 2018-03-15 23:40:33 --> Helper loaded: form_helper
INFO - 2018-03-15 23:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:40:33 --> Form Validation Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
INFO - 2018-03-15 23:40:33 --> Controller Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:40:33 --> Config Class Initialized
INFO - 2018-03-15 23:40:33 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:33 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:33 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:33 --> URI Class Initialized
INFO - 2018-03-15 23:40:33 --> Router Class Initialized
INFO - 2018-03-15 23:40:33 --> Output Class Initialized
INFO - 2018-03-15 23:40:33 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:33 --> Input Class Initialized
INFO - 2018-03-15 23:40:33 --> Language Class Initialized
INFO - 2018-03-15 23:40:33 --> Loader Class Initialized
INFO - 2018-03-15 23:40:33 --> Helper loaded: url_helper
INFO - 2018-03-15 23:40:33 --> Helper loaded: form_helper
INFO - 2018-03-15 23:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:40:33 --> Form Validation Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
INFO - 2018-03-15 23:40:33 --> Controller Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
INFO - 2018-03-15 23:40:33 --> Model Class Initialized
DEBUG - 2018-03-15 23:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:40:34 --> Config Class Initialized
INFO - 2018-03-15 23:40:34 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:34 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:34 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:34 --> URI Class Initialized
INFO - 2018-03-15 23:40:34 --> Router Class Initialized
INFO - 2018-03-15 23:40:34 --> Output Class Initialized
INFO - 2018-03-15 23:40:34 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:34 --> Input Class Initialized
INFO - 2018-03-15 23:40:34 --> Language Class Initialized
INFO - 2018-03-15 23:40:34 --> Loader Class Initialized
INFO - 2018-03-15 23:40:34 --> Helper loaded: url_helper
INFO - 2018-03-15 23:40:34 --> Helper loaded: form_helper
INFO - 2018-03-15 23:40:34 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:40:34 --> Form Validation Class Initialized
INFO - 2018-03-15 23:40:34 --> Model Class Initialized
INFO - 2018-03-15 23:40:34 --> Controller Class Initialized
INFO - 2018-03-15 23:40:34 --> Model Class Initialized
INFO - 2018-03-15 23:40:34 --> Model Class Initialized
DEBUG - 2018-03-15 23:40:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:40:36 --> Config Class Initialized
INFO - 2018-03-15 23:40:36 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:40:36 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:40:36 --> Utf8 Class Initialized
INFO - 2018-03-15 23:40:36 --> URI Class Initialized
INFO - 2018-03-15 23:40:36 --> Router Class Initialized
INFO - 2018-03-15 23:40:36 --> Output Class Initialized
INFO - 2018-03-15 23:40:36 --> Security Class Initialized
DEBUG - 2018-03-15 23:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:40:36 --> Input Class Initialized
INFO - 2018-03-15 23:40:36 --> Language Class Initialized
INFO - 2018-03-15 23:40:36 --> Loader Class Initialized
INFO - 2018-03-15 23:40:36 --> Helper loaded: url_helper
INFO - 2018-03-15 23:40:36 --> Helper loaded: form_helper
INFO - 2018-03-15 23:40:36 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:40:36 --> Form Validation Class Initialized
INFO - 2018-03-15 23:40:36 --> Model Class Initialized
INFO - 2018-03-15 23:40:36 --> Controller Class Initialized
INFO - 2018-03-15 23:40:36 --> Model Class Initialized
INFO - 2018-03-15 23:40:36 --> Model Class Initialized
DEBUG - 2018-03-15 23:40:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:16 --> Config Class Initialized
INFO - 2018-03-15 23:41:16 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:16 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:16 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:16 --> URI Class Initialized
INFO - 2018-03-15 23:41:16 --> Router Class Initialized
INFO - 2018-03-15 23:41:16 --> Output Class Initialized
INFO - 2018-03-15 23:41:16 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:16 --> Input Class Initialized
INFO - 2018-03-15 23:41:16 --> Language Class Initialized
INFO - 2018-03-15 23:41:16 --> Loader Class Initialized
INFO - 2018-03-15 23:41:16 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:16 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:16 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:16 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:16 --> Model Class Initialized
INFO - 2018-03-15 23:41:16 --> Controller Class Initialized
INFO - 2018-03-15 23:41:16 --> Model Class Initialized
INFO - 2018-03-15 23:41:16 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:41:16 --> Final output sent to browser
DEBUG - 2018-03-15 23:41:16 --> Total execution time: 0.1376
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:41:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:41:17 --> Config Class Initialized
INFO - 2018-03-15 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:17 --> URI Class Initialized
INFO - 2018-03-15 23:41:17 --> Router Class Initialized
INFO - 2018-03-15 23:41:17 --> Output Class Initialized
INFO - 2018-03-15 23:41:17 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:17 --> Input Class Initialized
INFO - 2018-03-15 23:41:17 --> Language Class Initialized
INFO - 2018-03-15 23:41:17 --> Loader Class Initialized
INFO - 2018-03-15 23:41:17 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:17 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:17 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:17 --> Model Class Initialized
INFO - 2018-03-15 23:41:17 --> Controller Class Initialized
INFO - 2018-03-15 23:41:17 --> Model Class Initialized
INFO - 2018-03-15 23:41:17 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:24 --> Config Class Initialized
INFO - 2018-03-15 23:41:24 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:24 --> URI Class Initialized
INFO - 2018-03-15 23:41:24 --> Router Class Initialized
INFO - 2018-03-15 23:41:24 --> Output Class Initialized
INFO - 2018-03-15 23:41:24 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:24 --> Input Class Initialized
INFO - 2018-03-15 23:41:24 --> Language Class Initialized
INFO - 2018-03-15 23:41:24 --> Loader Class Initialized
INFO - 2018-03-15 23:41:24 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:24 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:24 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:24 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
INFO - 2018-03-15 23:41:24 --> Controller Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:24 --> Config Class Initialized
INFO - 2018-03-15 23:41:24 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:24 --> URI Class Initialized
INFO - 2018-03-15 23:41:24 --> Router Class Initialized
INFO - 2018-03-15 23:41:24 --> Output Class Initialized
INFO - 2018-03-15 23:41:24 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:24 --> Input Class Initialized
INFO - 2018-03-15 23:41:24 --> Language Class Initialized
INFO - 2018-03-15 23:41:24 --> Loader Class Initialized
INFO - 2018-03-15 23:41:24 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:24 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:24 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:24 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
INFO - 2018-03-15 23:41:24 --> Controller Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
INFO - 2018-03-15 23:41:24 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:25 --> Config Class Initialized
INFO - 2018-03-15 23:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:25 --> URI Class Initialized
INFO - 2018-03-15 23:41:25 --> Router Class Initialized
INFO - 2018-03-15 23:41:25 --> Output Class Initialized
INFO - 2018-03-15 23:41:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:25 --> Input Class Initialized
INFO - 2018-03-15 23:41:25 --> Language Class Initialized
INFO - 2018-03-15 23:41:25 --> Loader Class Initialized
INFO - 2018-03-15 23:41:25 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:25 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:25 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:25 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Controller Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:25 --> Config Class Initialized
INFO - 2018-03-15 23:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:25 --> URI Class Initialized
INFO - 2018-03-15 23:41:25 --> Router Class Initialized
INFO - 2018-03-15 23:41:25 --> Output Class Initialized
INFO - 2018-03-15 23:41:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:25 --> Input Class Initialized
INFO - 2018-03-15 23:41:25 --> Language Class Initialized
INFO - 2018-03-15 23:41:25 --> Loader Class Initialized
INFO - 2018-03-15 23:41:25 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:25 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:25 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:25 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Controller Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:25 --> Config Class Initialized
INFO - 2018-03-15 23:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:25 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:25 --> URI Class Initialized
INFO - 2018-03-15 23:41:25 --> Router Class Initialized
INFO - 2018-03-15 23:41:25 --> Output Class Initialized
INFO - 2018-03-15 23:41:25 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:25 --> Input Class Initialized
INFO - 2018-03-15 23:41:25 --> Language Class Initialized
INFO - 2018-03-15 23:41:25 --> Loader Class Initialized
INFO - 2018-03-15 23:41:25 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:25 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:25 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:25 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Controller Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
INFO - 2018-03-15 23:41:25 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:27 --> Config Class Initialized
INFO - 2018-03-15 23:41:27 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:27 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:27 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:27 --> URI Class Initialized
INFO - 2018-03-15 23:41:27 --> Router Class Initialized
INFO - 2018-03-15 23:41:27 --> Output Class Initialized
INFO - 2018-03-15 23:41:27 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:27 --> Input Class Initialized
INFO - 2018-03-15 23:41:27 --> Language Class Initialized
INFO - 2018-03-15 23:41:27 --> Loader Class Initialized
INFO - 2018-03-15 23:41:27 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:27 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:27 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:27 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:27 --> Model Class Initialized
INFO - 2018-03-15 23:41:27 --> Controller Class Initialized
INFO - 2018-03-15 23:41:27 --> Model Class Initialized
INFO - 2018-03-15 23:41:27 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:31 --> Config Class Initialized
INFO - 2018-03-15 23:41:31 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:31 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:31 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:31 --> URI Class Initialized
INFO - 2018-03-15 23:41:31 --> Router Class Initialized
INFO - 2018-03-15 23:41:31 --> Output Class Initialized
INFO - 2018-03-15 23:41:31 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:31 --> Input Class Initialized
INFO - 2018-03-15 23:41:31 --> Language Class Initialized
INFO - 2018-03-15 23:41:31 --> Loader Class Initialized
INFO - 2018-03-15 23:41:31 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:31 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:31 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:31 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:31 --> Model Class Initialized
INFO - 2018-03-15 23:41:31 --> Controller Class Initialized
INFO - 2018-03-15 23:41:31 --> Model Class Initialized
INFO - 2018-03-15 23:41:31 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:46 --> Config Class Initialized
INFO - 2018-03-15 23:41:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:46 --> URI Class Initialized
INFO - 2018-03-15 23:41:46 --> Router Class Initialized
INFO - 2018-03-15 23:41:46 --> Output Class Initialized
INFO - 2018-03-15 23:41:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:46 --> Input Class Initialized
INFO - 2018-03-15 23:41:46 --> Language Class Initialized
INFO - 2018-03-15 23:41:46 --> Loader Class Initialized
INFO - 2018-03-15 23:41:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:46 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:46 --> Model Class Initialized
INFO - 2018-03-15 23:41:46 --> Controller Class Initialized
INFO - 2018-03-15 23:41:46 --> Model Class Initialized
INFO - 2018-03-15 23:41:46 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:41:46 --> Final output sent to browser
DEBUG - 2018-03-15 23:41:46 --> Total execution time: 0.0833
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:41:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:41:47 --> Config Class Initialized
INFO - 2018-03-15 23:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:47 --> URI Class Initialized
INFO - 2018-03-15 23:41:47 --> Router Class Initialized
INFO - 2018-03-15 23:41:47 --> Output Class Initialized
INFO - 2018-03-15 23:41:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:47 --> Input Class Initialized
INFO - 2018-03-15 23:41:47 --> Language Class Initialized
INFO - 2018-03-15 23:41:47 --> Loader Class Initialized
INFO - 2018-03-15 23:41:47 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:47 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:47 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:47 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:47 --> Model Class Initialized
INFO - 2018-03-15 23:41:47 --> Controller Class Initialized
INFO - 2018-03-15 23:41:47 --> Model Class Initialized
INFO - 2018-03-15 23:41:47 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:50 --> Config Class Initialized
INFO - 2018-03-15 23:41:50 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:50 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:50 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:50 --> URI Class Initialized
INFO - 2018-03-15 23:41:50 --> Router Class Initialized
INFO - 2018-03-15 23:41:50 --> Output Class Initialized
INFO - 2018-03-15 23:41:50 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:50 --> Input Class Initialized
INFO - 2018-03-15 23:41:50 --> Language Class Initialized
INFO - 2018-03-15 23:41:50 --> Loader Class Initialized
INFO - 2018-03-15 23:41:50 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:50 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:50 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:50 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:50 --> Model Class Initialized
INFO - 2018-03-15 23:41:50 --> Controller Class Initialized
INFO - 2018-03-15 23:41:50 --> Model Class Initialized
INFO - 2018-03-15 23:41:50 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:53 --> Config Class Initialized
INFO - 2018-03-15 23:41:53 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:53 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:53 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:53 --> URI Class Initialized
INFO - 2018-03-15 23:41:53 --> Router Class Initialized
INFO - 2018-03-15 23:41:53 --> Output Class Initialized
INFO - 2018-03-15 23:41:53 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:53 --> Input Class Initialized
INFO - 2018-03-15 23:41:53 --> Language Class Initialized
INFO - 2018-03-15 23:41:53 --> Loader Class Initialized
INFO - 2018-03-15 23:41:53 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:53 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:53 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:53 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:53 --> Model Class Initialized
INFO - 2018-03-15 23:41:53 --> Controller Class Initialized
INFO - 2018-03-15 23:41:53 --> Model Class Initialized
INFO - 2018-03-15 23:41:53 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:55 --> Config Class Initialized
INFO - 2018-03-15 23:41:55 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:55 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:55 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:55 --> URI Class Initialized
INFO - 2018-03-15 23:41:55 --> Router Class Initialized
INFO - 2018-03-15 23:41:55 --> Output Class Initialized
INFO - 2018-03-15 23:41:55 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:55 --> Input Class Initialized
INFO - 2018-03-15 23:41:55 --> Language Class Initialized
INFO - 2018-03-15 23:41:55 --> Loader Class Initialized
INFO - 2018-03-15 23:41:55 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:55 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:55 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:55 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:55 --> Model Class Initialized
INFO - 2018-03-15 23:41:55 --> Controller Class Initialized
INFO - 2018-03-15 23:41:56 --> Model Class Initialized
INFO - 2018-03-15 23:41:56 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:58 --> Config Class Initialized
INFO - 2018-03-15 23:41:58 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:58 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:58 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:58 --> URI Class Initialized
INFO - 2018-03-15 23:41:58 --> Router Class Initialized
INFO - 2018-03-15 23:41:58 --> Output Class Initialized
INFO - 2018-03-15 23:41:58 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:58 --> Input Class Initialized
INFO - 2018-03-15 23:41:58 --> Language Class Initialized
INFO - 2018-03-15 23:41:58 --> Loader Class Initialized
INFO - 2018-03-15 23:41:58 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:58 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:58 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:58 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
INFO - 2018-03-15 23:41:58 --> Controller Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:41:58 --> Config Class Initialized
INFO - 2018-03-15 23:41:58 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:41:58 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:41:58 --> Utf8 Class Initialized
INFO - 2018-03-15 23:41:58 --> URI Class Initialized
INFO - 2018-03-15 23:41:58 --> Router Class Initialized
INFO - 2018-03-15 23:41:58 --> Output Class Initialized
INFO - 2018-03-15 23:41:58 --> Security Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:41:58 --> Input Class Initialized
INFO - 2018-03-15 23:41:58 --> Language Class Initialized
INFO - 2018-03-15 23:41:58 --> Loader Class Initialized
INFO - 2018-03-15 23:41:58 --> Helper loaded: url_helper
INFO - 2018-03-15 23:41:58 --> Helper loaded: form_helper
INFO - 2018-03-15 23:41:58 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:41:58 --> Form Validation Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
INFO - 2018-03-15 23:41:58 --> Controller Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
INFO - 2018-03-15 23:41:58 --> Model Class Initialized
DEBUG - 2018-03-15 23:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:03 --> Config Class Initialized
INFO - 2018-03-15 23:42:03 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:03 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:03 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:03 --> URI Class Initialized
INFO - 2018-03-15 23:42:03 --> Router Class Initialized
INFO - 2018-03-15 23:42:03 --> Output Class Initialized
INFO - 2018-03-15 23:42:03 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:03 --> Input Class Initialized
INFO - 2018-03-15 23:42:03 --> Language Class Initialized
INFO - 2018-03-15 23:42:03 --> Loader Class Initialized
INFO - 2018-03-15 23:42:03 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:03 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:03 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:03 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:03 --> Model Class Initialized
INFO - 2018-03-15 23:42:03 --> Controller Class Initialized
INFO - 2018-03-15 23:42:03 --> Model Class Initialized
INFO - 2018-03-15 23:42:03 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:05 --> Config Class Initialized
INFO - 2018-03-15 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:05 --> URI Class Initialized
INFO - 2018-03-15 23:42:05 --> Router Class Initialized
INFO - 2018-03-15 23:42:05 --> Output Class Initialized
INFO - 2018-03-15 23:42:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:05 --> Input Class Initialized
INFO - 2018-03-15 23:42:05 --> Language Class Initialized
INFO - 2018-03-15 23:42:05 --> Loader Class Initialized
INFO - 2018-03-15 23:42:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
INFO - 2018-03-15 23:42:05 --> Controller Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:05 --> Config Class Initialized
INFO - 2018-03-15 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:05 --> URI Class Initialized
INFO - 2018-03-15 23:42:05 --> Router Class Initialized
INFO - 2018-03-15 23:42:05 --> Output Class Initialized
INFO - 2018-03-15 23:42:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:05 --> Input Class Initialized
INFO - 2018-03-15 23:42:05 --> Language Class Initialized
INFO - 2018-03-15 23:42:05 --> Loader Class Initialized
INFO - 2018-03-15 23:42:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
INFO - 2018-03-15 23:42:05 --> Controller Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
INFO - 2018-03-15 23:42:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
INFO - 2018-03-15 23:42:49 --> Loader Class Initialized
INFO - 2018-03-15 23:42:49 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:49 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:49 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:49 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
INFO - 2018-03-15 23:42:49 --> Controller Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:42:49 --> Final output sent to browser
DEBUG - 2018-03-15 23:42:49 --> Total execution time: 0.1124
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:42:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:42:49 --> Config Class Initialized
INFO - 2018-03-15 23:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:49 --> URI Class Initialized
INFO - 2018-03-15 23:42:49 --> Router Class Initialized
INFO - 2018-03-15 23:42:49 --> Output Class Initialized
INFO - 2018-03-15 23:42:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:49 --> Input Class Initialized
INFO - 2018-03-15 23:42:49 --> Language Class Initialized
INFO - 2018-03-15 23:42:49 --> Loader Class Initialized
INFO - 2018-03-15 23:42:49 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:49 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:49 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:49 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
INFO - 2018-03-15 23:42:49 --> Controller Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
INFO - 2018-03-15 23:42:49 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:55 --> Config Class Initialized
INFO - 2018-03-15 23:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:55 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:55 --> URI Class Initialized
INFO - 2018-03-15 23:42:55 --> Router Class Initialized
INFO - 2018-03-15 23:42:55 --> Output Class Initialized
INFO - 2018-03-15 23:42:55 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:55 --> Input Class Initialized
INFO - 2018-03-15 23:42:55 --> Language Class Initialized
INFO - 2018-03-15 23:42:55 --> Loader Class Initialized
INFO - 2018-03-15 23:42:55 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:55 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:55 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:55 --> Model Class Initialized
INFO - 2018-03-15 23:42:55 --> Controller Class Initialized
INFO - 2018-03-15 23:42:55 --> Model Class Initialized
INFO - 2018-03-15 23:42:55 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:42:57 --> Config Class Initialized
INFO - 2018-03-15 23:42:57 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:42:57 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:42:57 --> Utf8 Class Initialized
INFO - 2018-03-15 23:42:57 --> URI Class Initialized
INFO - 2018-03-15 23:42:57 --> Router Class Initialized
INFO - 2018-03-15 23:42:57 --> Output Class Initialized
INFO - 2018-03-15 23:42:57 --> Security Class Initialized
DEBUG - 2018-03-15 23:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:42:57 --> Input Class Initialized
INFO - 2018-03-15 23:42:57 --> Language Class Initialized
INFO - 2018-03-15 23:42:57 --> Loader Class Initialized
INFO - 2018-03-15 23:42:57 --> Helper loaded: url_helper
INFO - 2018-03-15 23:42:57 --> Helper loaded: form_helper
INFO - 2018-03-15 23:42:57 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:42:57 --> Form Validation Class Initialized
INFO - 2018-03-15 23:42:57 --> Model Class Initialized
INFO - 2018-03-15 23:42:57 --> Controller Class Initialized
INFO - 2018-03-15 23:42:57 --> Model Class Initialized
INFO - 2018-03-15 23:42:57 --> Model Class Initialized
DEBUG - 2018-03-15 23:42:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:44:31 --> Config Class Initialized
INFO - 2018-03-15 23:44:31 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:44:31 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:44:31 --> Utf8 Class Initialized
INFO - 2018-03-15 23:44:31 --> URI Class Initialized
INFO - 2018-03-15 23:44:31 --> Router Class Initialized
INFO - 2018-03-15 23:44:31 --> Output Class Initialized
INFO - 2018-03-15 23:44:31 --> Security Class Initialized
DEBUG - 2018-03-15 23:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:44:31 --> Input Class Initialized
INFO - 2018-03-15 23:44:31 --> Language Class Initialized
INFO - 2018-03-15 23:44:31 --> Loader Class Initialized
INFO - 2018-03-15 23:44:31 --> Helper loaded: url_helper
INFO - 2018-03-15 23:44:31 --> Helper loaded: form_helper
INFO - 2018-03-15 23:44:31 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:44:31 --> Form Validation Class Initialized
INFO - 2018-03-15 23:44:31 --> Model Class Initialized
INFO - 2018-03-15 23:44:31 --> Controller Class Initialized
INFO - 2018-03-15 23:44:31 --> Model Class Initialized
INFO - 2018-03-15 23:44:31 --> Model Class Initialized
DEBUG - 2018-03-15 23:44:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:44:32 --> Config Class Initialized
INFO - 2018-03-15 23:44:32 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:44:32 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:44:32 --> Utf8 Class Initialized
INFO - 2018-03-15 23:44:32 --> URI Class Initialized
INFO - 2018-03-15 23:44:32 --> Router Class Initialized
INFO - 2018-03-15 23:44:32 --> Output Class Initialized
INFO - 2018-03-15 23:44:32 --> Security Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:44:32 --> Input Class Initialized
INFO - 2018-03-15 23:44:32 --> Language Class Initialized
INFO - 2018-03-15 23:44:32 --> Loader Class Initialized
INFO - 2018-03-15 23:44:32 --> Helper loaded: url_helper
INFO - 2018-03-15 23:44:32 --> Helper loaded: form_helper
INFO - 2018-03-15 23:44:32 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:44:32 --> Form Validation Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
INFO - 2018-03-15 23:44:32 --> Controller Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:44:32 --> Config Class Initialized
INFO - 2018-03-15 23:44:32 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:44:32 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:44:32 --> Utf8 Class Initialized
INFO - 2018-03-15 23:44:32 --> URI Class Initialized
INFO - 2018-03-15 23:44:32 --> Router Class Initialized
INFO - 2018-03-15 23:44:32 --> Output Class Initialized
INFO - 2018-03-15 23:44:32 --> Security Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:44:32 --> Input Class Initialized
INFO - 2018-03-15 23:44:32 --> Language Class Initialized
INFO - 2018-03-15 23:44:32 --> Loader Class Initialized
INFO - 2018-03-15 23:44:32 --> Helper loaded: url_helper
INFO - 2018-03-15 23:44:32 --> Helper loaded: form_helper
INFO - 2018-03-15 23:44:32 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:44:32 --> Form Validation Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
INFO - 2018-03-15 23:44:32 --> Controller Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
INFO - 2018-03-15 23:44:32 --> Model Class Initialized
DEBUG - 2018-03-15 23:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
INFO - 2018-03-15 23:52:35 --> Loader Class Initialized
INFO - 2018-03-15 23:52:35 --> Helper loaded: url_helper
INFO - 2018-03-15 23:52:35 --> Helper loaded: form_helper
INFO - 2018-03-15 23:52:35 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:52:35 --> Form Validation Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
INFO - 2018-03-15 23:52:35 --> Controller Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:52:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:52:35 --> Final output sent to browser
DEBUG - 2018-03-15 23:52:35 --> Total execution time: 0.1043
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:52:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:52:35 --> Config Class Initialized
INFO - 2018-03-15 23:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:35 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:35 --> URI Class Initialized
INFO - 2018-03-15 23:52:35 --> Router Class Initialized
INFO - 2018-03-15 23:52:35 --> Output Class Initialized
INFO - 2018-03-15 23:52:35 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:35 --> Input Class Initialized
INFO - 2018-03-15 23:52:35 --> Language Class Initialized
INFO - 2018-03-15 23:52:35 --> Loader Class Initialized
INFO - 2018-03-15 23:52:35 --> Helper loaded: url_helper
INFO - 2018-03-15 23:52:35 --> Helper loaded: form_helper
INFO - 2018-03-15 23:52:35 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:52:35 --> Form Validation Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
INFO - 2018-03-15 23:52:35 --> Controller Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
INFO - 2018-03-15 23:52:35 --> Model Class Initialized
DEBUG - 2018-03-15 23:52:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:52:52 --> Config Class Initialized
INFO - 2018-03-15 23:52:52 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:52 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:52 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:52 --> URI Class Initialized
INFO - 2018-03-15 23:52:52 --> Router Class Initialized
INFO - 2018-03-15 23:52:52 --> Output Class Initialized
INFO - 2018-03-15 23:52:52 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:52 --> Input Class Initialized
INFO - 2018-03-15 23:52:52 --> Language Class Initialized
INFO - 2018-03-15 23:52:52 --> Loader Class Initialized
INFO - 2018-03-15 23:52:52 --> Helper loaded: url_helper
INFO - 2018-03-15 23:52:52 --> Helper loaded: form_helper
INFO - 2018-03-15 23:52:52 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:52:52 --> Form Validation Class Initialized
INFO - 2018-03-15 23:52:52 --> Model Class Initialized
INFO - 2018-03-15 23:52:52 --> Controller Class Initialized
INFO - 2018-03-15 23:52:52 --> Model Class Initialized
INFO - 2018-03-15 23:52:52 --> Model Class Initialized
DEBUG - 2018-03-15 23:52:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:52:55 --> Config Class Initialized
INFO - 2018-03-15 23:52:55 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:52:55 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:52:55 --> Utf8 Class Initialized
INFO - 2018-03-15 23:52:55 --> URI Class Initialized
INFO - 2018-03-15 23:52:55 --> Router Class Initialized
INFO - 2018-03-15 23:52:55 --> Output Class Initialized
INFO - 2018-03-15 23:52:55 --> Security Class Initialized
DEBUG - 2018-03-15 23:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:52:55 --> Input Class Initialized
INFO - 2018-03-15 23:52:55 --> Language Class Initialized
INFO - 2018-03-15 23:52:55 --> Loader Class Initialized
INFO - 2018-03-15 23:52:55 --> Helper loaded: url_helper
INFO - 2018-03-15 23:52:55 --> Helper loaded: form_helper
INFO - 2018-03-15 23:52:55 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:52:55 --> Form Validation Class Initialized
INFO - 2018-03-15 23:52:55 --> Model Class Initialized
INFO - 2018-03-15 23:52:55 --> Controller Class Initialized
INFO - 2018-03-15 23:52:55 --> Model Class Initialized
INFO - 2018-03-15 23:52:55 --> Model Class Initialized
DEBUG - 2018-03-15 23:52:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:10 --> Config Class Initialized
INFO - 2018-03-15 23:54:10 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:10 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:10 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:10 --> URI Class Initialized
INFO - 2018-03-15 23:54:10 --> Router Class Initialized
INFO - 2018-03-15 23:54:10 --> Output Class Initialized
INFO - 2018-03-15 23:54:10 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:10 --> Input Class Initialized
INFO - 2018-03-15 23:54:10 --> Language Class Initialized
INFO - 2018-03-15 23:54:10 --> Loader Class Initialized
INFO - 2018-03-15 23:54:10 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:10 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:10 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:10 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:10 --> Model Class Initialized
INFO - 2018-03-15 23:54:10 --> Controller Class Initialized
INFO - 2018-03-15 23:54:10 --> Model Class Initialized
INFO - 2018-03-15 23:54:10 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:54:10 --> Final output sent to browser
DEBUG - 2018-03-15 23:54:10 --> Total execution time: 0.0905
INFO - 2018-03-15 23:54:10 --> Config Class Initialized
INFO - 2018-03-15 23:54:10 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:10 --> Config Class Initialized
INFO - 2018-03-15 23:54:10 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:10 --> Config Class Initialized
INFO - 2018-03-15 23:54:10 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:10 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:10 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:54:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:54:10 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:10 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:10 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:10 --> URI Class Initialized
INFO - 2018-03-15 23:54:10 --> URI Class Initialized
INFO - 2018-03-15 23:54:10 --> URI Class Initialized
INFO - 2018-03-15 23:54:10 --> Router Class Initialized
INFO - 2018-03-15 23:54:10 --> Router Class Initialized
INFO - 2018-03-15 23:54:10 --> Router Class Initialized
INFO - 2018-03-15 23:54:10 --> Output Class Initialized
INFO - 2018-03-15 23:54:10 --> Output Class Initialized
INFO - 2018-03-15 23:54:10 --> Output Class Initialized
INFO - 2018-03-15 23:54:10 --> Security Class Initialized
INFO - 2018-03-15 23:54:10 --> Security Class Initialized
INFO - 2018-03-15 23:54:10 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:10 --> Input Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:10 --> Input Class Initialized
INFO - 2018-03-15 23:54:10 --> Language Class Initialized
DEBUG - 2018-03-15 23:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:10 --> Input Class Initialized
INFO - 2018-03-15 23:54:10 --> Language Class Initialized
INFO - 2018-03-15 23:54:10 --> Language Class Initialized
ERROR - 2018-03-15 23:54:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:54:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:54:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:54:10 --> Config Class Initialized
INFO - 2018-03-15 23:54:10 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:11 --> URI Class Initialized
INFO - 2018-03-15 23:54:11 --> Router Class Initialized
INFO - 2018-03-15 23:54:11 --> Output Class Initialized
INFO - 2018-03-15 23:54:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:11 --> Input Class Initialized
INFO - 2018-03-15 23:54:11 --> Language Class Initialized
ERROR - 2018-03-15 23:54:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:54:11 --> Config Class Initialized
INFO - 2018-03-15 23:54:11 --> Config Class Initialized
INFO - 2018-03-15 23:54:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:11 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:11 --> Config Class Initialized
INFO - 2018-03-15 23:54:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:54:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:54:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:11 --> URI Class Initialized
INFO - 2018-03-15 23:54:11 --> URI Class Initialized
INFO - 2018-03-15 23:54:11 --> URI Class Initialized
INFO - 2018-03-15 23:54:11 --> Router Class Initialized
INFO - 2018-03-15 23:54:11 --> Router Class Initialized
INFO - 2018-03-15 23:54:11 --> Router Class Initialized
INFO - 2018-03-15 23:54:11 --> Output Class Initialized
INFO - 2018-03-15 23:54:11 --> Output Class Initialized
INFO - 2018-03-15 23:54:11 --> Output Class Initialized
INFO - 2018-03-15 23:54:11 --> Security Class Initialized
INFO - 2018-03-15 23:54:11 --> Security Class Initialized
INFO - 2018-03-15 23:54:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:11 --> Input Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:11 --> Input Class Initialized
INFO - 2018-03-15 23:54:11 --> Input Class Initialized
INFO - 2018-03-15 23:54:11 --> Language Class Initialized
INFO - 2018-03-15 23:54:11 --> Language Class Initialized
INFO - 2018-03-15 23:54:11 --> Language Class Initialized
ERROR - 2018-03-15 23:54:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:54:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:54:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:54:11 --> Config Class Initialized
INFO - 2018-03-15 23:54:11 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:11 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:11 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:11 --> URI Class Initialized
INFO - 2018-03-15 23:54:11 --> Router Class Initialized
INFO - 2018-03-15 23:54:11 --> Output Class Initialized
INFO - 2018-03-15 23:54:11 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:11 --> Input Class Initialized
INFO - 2018-03-15 23:54:11 --> Language Class Initialized
INFO - 2018-03-15 23:54:11 --> Loader Class Initialized
INFO - 2018-03-15 23:54:11 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:11 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:11 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:11 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:11 --> Model Class Initialized
INFO - 2018-03-15 23:54:11 --> Controller Class Initialized
INFO - 2018-03-15 23:54:11 --> Model Class Initialized
INFO - 2018-03-15 23:54:11 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:20 --> Config Class Initialized
INFO - 2018-03-15 23:54:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:20 --> URI Class Initialized
INFO - 2018-03-15 23:54:20 --> Router Class Initialized
INFO - 2018-03-15 23:54:20 --> Output Class Initialized
INFO - 2018-03-15 23:54:20 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:20 --> Input Class Initialized
INFO - 2018-03-15 23:54:20 --> Language Class Initialized
INFO - 2018-03-15 23:54:20 --> Loader Class Initialized
INFO - 2018-03-15 23:54:20 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:20 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:20 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:20 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:20 --> Model Class Initialized
INFO - 2018-03-15 23:54:20 --> Controller Class Initialized
INFO - 2018-03-15 23:54:20 --> Model Class Initialized
INFO - 2018-03-15 23:54:20 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:38 --> Config Class Initialized
INFO - 2018-03-15 23:54:38 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:38 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:38 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:38 --> URI Class Initialized
INFO - 2018-03-15 23:54:38 --> Router Class Initialized
INFO - 2018-03-15 23:54:38 --> Output Class Initialized
INFO - 2018-03-15 23:54:38 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:38 --> Input Class Initialized
INFO - 2018-03-15 23:54:38 --> Language Class Initialized
INFO - 2018-03-15 23:54:38 --> Loader Class Initialized
INFO - 2018-03-15 23:54:38 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:38 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:38 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:38 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:38 --> Model Class Initialized
INFO - 2018-03-15 23:54:38 --> Controller Class Initialized
INFO - 2018-03-15 23:54:38 --> Model Class Initialized
INFO - 2018-03-15 23:54:38 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
INFO - 2018-03-15 23:54:42 --> Loader Class Initialized
INFO - 2018-03-15 23:54:42 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:42 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:42 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:42 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
INFO - 2018-03-15 23:54:42 --> Controller Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:54:42 --> Final output sent to browser
DEBUG - 2018-03-15 23:54:42 --> Total execution time: 0.0690
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
ERROR - 2018-03-15 23:54:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:54:42 --> Config Class Initialized
INFO - 2018-03-15 23:54:42 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:42 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:42 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:42 --> URI Class Initialized
INFO - 2018-03-15 23:54:42 --> Router Class Initialized
INFO - 2018-03-15 23:54:42 --> Output Class Initialized
INFO - 2018-03-15 23:54:42 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:42 --> Input Class Initialized
INFO - 2018-03-15 23:54:42 --> Language Class Initialized
INFO - 2018-03-15 23:54:42 --> Loader Class Initialized
INFO - 2018-03-15 23:54:42 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:42 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:42 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:42 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
INFO - 2018-03-15 23:54:42 --> Controller Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
INFO - 2018-03-15 23:54:42 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:46 --> Config Class Initialized
INFO - 2018-03-15 23:54:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:46 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:46 --> URI Class Initialized
INFO - 2018-03-15 23:54:46 --> Router Class Initialized
INFO - 2018-03-15 23:54:46 --> Output Class Initialized
INFO - 2018-03-15 23:54:46 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:46 --> Input Class Initialized
INFO - 2018-03-15 23:54:46 --> Language Class Initialized
INFO - 2018-03-15 23:54:46 --> Loader Class Initialized
INFO - 2018-03-15 23:54:46 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:46 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:47 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:47 --> Model Class Initialized
INFO - 2018-03-15 23:54:47 --> Controller Class Initialized
INFO - 2018-03-15 23:54:47 --> Model Class Initialized
INFO - 2018-03-15 23:54:47 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:54:49 --> Config Class Initialized
INFO - 2018-03-15 23:54:49 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:54:49 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:54:49 --> Utf8 Class Initialized
INFO - 2018-03-15 23:54:49 --> URI Class Initialized
INFO - 2018-03-15 23:54:49 --> Router Class Initialized
INFO - 2018-03-15 23:54:49 --> Output Class Initialized
INFO - 2018-03-15 23:54:49 --> Security Class Initialized
DEBUG - 2018-03-15 23:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:54:49 --> Input Class Initialized
INFO - 2018-03-15 23:54:49 --> Language Class Initialized
INFO - 2018-03-15 23:54:49 --> Loader Class Initialized
INFO - 2018-03-15 23:54:49 --> Helper loaded: url_helper
INFO - 2018-03-15 23:54:49 --> Helper loaded: form_helper
INFO - 2018-03-15 23:54:49 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:54:49 --> Form Validation Class Initialized
INFO - 2018-03-15 23:54:49 --> Model Class Initialized
INFO - 2018-03-15 23:54:49 --> Controller Class Initialized
INFO - 2018-03-15 23:54:49 --> Model Class Initialized
INFO - 2018-03-15 23:54:49 --> Model Class Initialized
DEBUG - 2018-03-15 23:54:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
INFO - 2018-03-15 23:55:39 --> Loader Class Initialized
INFO - 2018-03-15 23:55:39 --> Helper loaded: url_helper
INFO - 2018-03-15 23:55:39 --> Helper loaded: form_helper
INFO - 2018-03-15 23:55:39 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:55:39 --> Form Validation Class Initialized
INFO - 2018-03-15 23:55:39 --> Model Class Initialized
INFO - 2018-03-15 23:55:39 --> Controller Class Initialized
INFO - 2018-03-15 23:55:39 --> Model Class Initialized
INFO - 2018-03-15 23:55:39 --> Model Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:55:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:55:39 --> Final output sent to browser
DEBUG - 2018-03-15 23:55:39 --> Total execution time: 0.0603
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:55:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:55:39 --> Config Class Initialized
INFO - 2018-03-15 23:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:39 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:39 --> URI Class Initialized
INFO - 2018-03-15 23:55:39 --> Router Class Initialized
INFO - 2018-03-15 23:55:39 --> Output Class Initialized
INFO - 2018-03-15 23:55:39 --> Security Class Initialized
DEBUG - 2018-03-15 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:39 --> Input Class Initialized
INFO - 2018-03-15 23:55:39 --> Language Class Initialized
INFO - 2018-03-15 23:55:39 --> Loader Class Initialized
INFO - 2018-03-15 23:55:39 --> Helper loaded: url_helper
INFO - 2018-03-15 23:55:39 --> Helper loaded: form_helper
INFO - 2018-03-15 23:55:39 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:55:40 --> Form Validation Class Initialized
INFO - 2018-03-15 23:55:40 --> Model Class Initialized
INFO - 2018-03-15 23:55:40 --> Controller Class Initialized
INFO - 2018-03-15 23:55:40 --> Model Class Initialized
INFO - 2018-03-15 23:55:40 --> Model Class Initialized
DEBUG - 2018-03-15 23:55:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:55:50 --> Config Class Initialized
INFO - 2018-03-15 23:55:50 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:55:50 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:55:50 --> Utf8 Class Initialized
INFO - 2018-03-15 23:55:50 --> URI Class Initialized
INFO - 2018-03-15 23:55:50 --> Router Class Initialized
INFO - 2018-03-15 23:55:50 --> Output Class Initialized
INFO - 2018-03-15 23:55:50 --> Security Class Initialized
DEBUG - 2018-03-15 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:55:50 --> Input Class Initialized
INFO - 2018-03-15 23:55:50 --> Language Class Initialized
INFO - 2018-03-15 23:55:50 --> Loader Class Initialized
INFO - 2018-03-15 23:55:50 --> Helper loaded: url_helper
INFO - 2018-03-15 23:55:50 --> Helper loaded: form_helper
INFO - 2018-03-15 23:55:50 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:55:50 --> Form Validation Class Initialized
INFO - 2018-03-15 23:55:50 --> Model Class Initialized
INFO - 2018-03-15 23:55:50 --> Controller Class Initialized
INFO - 2018-03-15 23:55:50 --> Model Class Initialized
INFO - 2018-03-15 23:55:50 --> Model Class Initialized
DEBUG - 2018-03-15 23:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:58:00 --> Config Class Initialized
INFO - 2018-03-15 23:58:00 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:00 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:00 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:00 --> URI Class Initialized
INFO - 2018-03-15 23:58:00 --> Router Class Initialized
INFO - 2018-03-15 23:58:00 --> Output Class Initialized
INFO - 2018-03-15 23:58:00 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:00 --> Input Class Initialized
INFO - 2018-03-15 23:58:00 --> Language Class Initialized
INFO - 2018-03-15 23:58:00 --> Loader Class Initialized
INFO - 2018-03-15 23:58:00 --> Helper loaded: url_helper
INFO - 2018-03-15 23:58:00 --> Helper loaded: form_helper
INFO - 2018-03-15 23:58:00 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:58:00 --> Form Validation Class Initialized
INFO - 2018-03-15 23:58:00 --> Model Class Initialized
INFO - 2018-03-15 23:58:00 --> Controller Class Initialized
INFO - 2018-03-15 23:58:00 --> Model Class Initialized
INFO - 2018-03-15 23:58:00 --> Model Class Initialized
DEBUG - 2018-03-15 23:58:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:58:36 --> Config Class Initialized
INFO - 2018-03-15 23:58:36 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:36 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:36 --> URI Class Initialized
INFO - 2018-03-15 23:58:36 --> Router Class Initialized
INFO - 2018-03-15 23:58:36 --> Output Class Initialized
INFO - 2018-03-15 23:58:36 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:36 --> Input Class Initialized
INFO - 2018-03-15 23:58:36 --> Language Class Initialized
INFO - 2018-03-15 23:58:36 --> Loader Class Initialized
INFO - 2018-03-15 23:58:36 --> Helper loaded: url_helper
INFO - 2018-03-15 23:58:36 --> Helper loaded: form_helper
INFO - 2018-03-15 23:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:58:36 --> Form Validation Class Initialized
INFO - 2018-03-15 23:58:36 --> Model Class Initialized
INFO - 2018-03-15 23:58:36 --> Controller Class Initialized
INFO - 2018-03-15 23:58:36 --> Model Class Initialized
INFO - 2018-03-15 23:58:36 --> Model Class Initialized
DEBUG - 2018-03-15 23:58:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
INFO - 2018-03-15 23:58:47 --> Loader Class Initialized
INFO - 2018-03-15 23:58:47 --> Helper loaded: url_helper
INFO - 2018-03-15 23:58:47 --> Helper loaded: form_helper
INFO - 2018-03-15 23:58:47 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:58:47 --> Form Validation Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
INFO - 2018-03-15 23:58:47 --> Controller Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:58:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:58:47 --> Final output sent to browser
DEBUG - 2018-03-15 23:58:47 --> Total execution time: 0.0653
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
ERROR - 2018-03-15 23:58:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:58:47 --> Config Class Initialized
INFO - 2018-03-15 23:58:47 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:47 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:47 --> URI Class Initialized
INFO - 2018-03-15 23:58:47 --> Router Class Initialized
INFO - 2018-03-15 23:58:47 --> Output Class Initialized
INFO - 2018-03-15 23:58:47 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:47 --> Input Class Initialized
INFO - 2018-03-15 23:58:47 --> Language Class Initialized
INFO - 2018-03-15 23:58:47 --> Loader Class Initialized
INFO - 2018-03-15 23:58:47 --> Helper loaded: url_helper
INFO - 2018-03-15 23:58:47 --> Helper loaded: form_helper
INFO - 2018-03-15 23:58:47 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:58:47 --> Form Validation Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
INFO - 2018-03-15 23:58:47 --> Controller Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
INFO - 2018-03-15 23:58:47 --> Model Class Initialized
DEBUG - 2018-03-15 23:58:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:58:52 --> Config Class Initialized
INFO - 2018-03-15 23:58:52 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:58:52 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:58:52 --> Utf8 Class Initialized
INFO - 2018-03-15 23:58:52 --> URI Class Initialized
INFO - 2018-03-15 23:58:52 --> Router Class Initialized
INFO - 2018-03-15 23:58:52 --> Output Class Initialized
INFO - 2018-03-15 23:58:52 --> Security Class Initialized
DEBUG - 2018-03-15 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:58:52 --> Input Class Initialized
INFO - 2018-03-15 23:58:52 --> Language Class Initialized
INFO - 2018-03-15 23:58:52 --> Loader Class Initialized
INFO - 2018-03-15 23:58:52 --> Helper loaded: url_helper
INFO - 2018-03-15 23:58:52 --> Helper loaded: form_helper
INFO - 2018-03-15 23:58:52 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:58:52 --> Form Validation Class Initialized
INFO - 2018-03-15 23:58:52 --> Model Class Initialized
INFO - 2018-03-15 23:58:52 --> Controller Class Initialized
INFO - 2018-03-15 23:58:52 --> Model Class Initialized
INFO - 2018-03-15 23:58:52 --> Model Class Initialized
DEBUG - 2018-03-15 23:58:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Loader Class Initialized
INFO - 2018-03-15 23:59:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
INFO - 2018-03-15 23:59:05 --> Controller Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:59:05 --> Final output sent to browser
DEBUG - 2018-03-15 23:59:05 --> Total execution time: 0.0513
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-15 23:59:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:59:05 --> Config Class Initialized
INFO - 2018-03-15 23:59:05 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:05 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:05 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:05 --> URI Class Initialized
INFO - 2018-03-15 23:59:05 --> Router Class Initialized
INFO - 2018-03-15 23:59:05 --> Output Class Initialized
INFO - 2018-03-15 23:59:05 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:05 --> Input Class Initialized
INFO - 2018-03-15 23:59:05 --> Language Class Initialized
INFO - 2018-03-15 23:59:05 --> Loader Class Initialized
INFO - 2018-03-15 23:59:05 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:05 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:05 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:05 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
INFO - 2018-03-15 23:59:05 --> Controller Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
INFO - 2018-03-15 23:59:05 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:09 --> Config Class Initialized
INFO - 2018-03-15 23:59:09 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:09 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:09 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:09 --> URI Class Initialized
INFO - 2018-03-15 23:59:09 --> Router Class Initialized
INFO - 2018-03-15 23:59:09 --> Output Class Initialized
INFO - 2018-03-15 23:59:09 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:09 --> Input Class Initialized
INFO - 2018-03-15 23:59:09 --> Language Class Initialized
INFO - 2018-03-15 23:59:09 --> Loader Class Initialized
INFO - 2018-03-15 23:59:09 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:09 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:09 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:09 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:09 --> Model Class Initialized
INFO - 2018-03-15 23:59:09 --> Controller Class Initialized
INFO - 2018-03-15 23:59:09 --> Model Class Initialized
INFO - 2018-03-15 23:59:09 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:12 --> Config Class Initialized
INFO - 2018-03-15 23:59:12 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:12 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:12 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:12 --> URI Class Initialized
INFO - 2018-03-15 23:59:12 --> Router Class Initialized
INFO - 2018-03-15 23:59:12 --> Output Class Initialized
INFO - 2018-03-15 23:59:12 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:12 --> Input Class Initialized
INFO - 2018-03-15 23:59:12 --> Language Class Initialized
INFO - 2018-03-15 23:59:12 --> Loader Class Initialized
INFO - 2018-03-15 23:59:12 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:12 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:13 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:13 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:13 --> Model Class Initialized
INFO - 2018-03-15 23:59:13 --> Controller Class Initialized
INFO - 2018-03-15 23:59:13 --> Model Class Initialized
INFO - 2018-03-15 23:59:13 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
INFO - 2018-03-15 23:59:18 --> Loader Class Initialized
INFO - 2018-03-15 23:59:18 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:18 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:18 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:18 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:18 --> Model Class Initialized
INFO - 2018-03-15 23:59:18 --> Controller Class Initialized
INFO - 2018-03-15 23:59:18 --> Model Class Initialized
INFO - 2018-03-15 23:59:18 --> Model Class Initialized
INFO - 2018-03-15 23:59:18 --> Model Class Initialized
INFO - 2018-03-15 23:59:18 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:59:18 --> Final output sent to browser
DEBUG - 2018-03-15 23:59:18 --> Total execution time: 0.0658
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:18 --> Config Class Initialized
INFO - 2018-03-15 23:59:18 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:18 --> Utf8 Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> URI Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
INFO - 2018-03-15 23:59:18 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Output Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
INFO - 2018-03-15 23:59:18 --> Security Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:18 --> Input Class Initialized
INFO - 2018-03-15 23:59:18 --> Language Class Initialized
ERROR - 2018-03-15 23:59:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:59:19 --> Config Class Initialized
INFO - 2018-03-15 23:59:19 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:19 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:19 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:19 --> URI Class Initialized
INFO - 2018-03-15 23:59:19 --> Router Class Initialized
INFO - 2018-03-15 23:59:19 --> Output Class Initialized
INFO - 2018-03-15 23:59:19 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:19 --> Input Class Initialized
INFO - 2018-03-15 23:59:19 --> Language Class Initialized
INFO - 2018-03-15 23:59:19 --> Loader Class Initialized
INFO - 2018-03-15 23:59:19 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:19 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:19 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:19 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
INFO - 2018-03-15 23:59:19 --> Controller Class Initialized
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:19 --> Model Class Initialized
INFO - 2018-03-15 23:59:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-15 23:59:19 --> Final output sent to browser
DEBUG - 2018-03-15 23:59:19 --> Total execution time: 0.0783
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
ERROR - 2018-03-15 23:59:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-15 23:59:20 --> Config Class Initialized
INFO - 2018-03-15 23:59:20 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:20 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:20 --> URI Class Initialized
INFO - 2018-03-15 23:59:20 --> Router Class Initialized
INFO - 2018-03-15 23:59:20 --> Output Class Initialized
INFO - 2018-03-15 23:59:20 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:20 --> Input Class Initialized
INFO - 2018-03-15 23:59:20 --> Language Class Initialized
INFO - 2018-03-15 23:59:20 --> Loader Class Initialized
INFO - 2018-03-15 23:59:20 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:20 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:20 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:20 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:20 --> Model Class Initialized
INFO - 2018-03-15 23:59:20 --> Controller Class Initialized
INFO - 2018-03-15 23:59:20 --> Model Class Initialized
INFO - 2018-03-15 23:59:20 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:24 --> Config Class Initialized
INFO - 2018-03-15 23:59:24 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:24 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:24 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:24 --> URI Class Initialized
INFO - 2018-03-15 23:59:24 --> Router Class Initialized
INFO - 2018-03-15 23:59:24 --> Output Class Initialized
INFO - 2018-03-15 23:59:24 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:24 --> Input Class Initialized
INFO - 2018-03-15 23:59:24 --> Language Class Initialized
INFO - 2018-03-15 23:59:24 --> Loader Class Initialized
INFO - 2018-03-15 23:59:24 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:24 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:24 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:24 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:24 --> Model Class Initialized
INFO - 2018-03-15 23:59:24 --> Controller Class Initialized
INFO - 2018-03-15 23:59:24 --> Model Class Initialized
INFO - 2018-03-15 23:59:24 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-15 23:59:27 --> Config Class Initialized
INFO - 2018-03-15 23:59:27 --> Hooks Class Initialized
DEBUG - 2018-03-15 23:59:27 --> UTF-8 Support Enabled
INFO - 2018-03-15 23:59:27 --> Utf8 Class Initialized
INFO - 2018-03-15 23:59:27 --> URI Class Initialized
INFO - 2018-03-15 23:59:27 --> Router Class Initialized
INFO - 2018-03-15 23:59:27 --> Output Class Initialized
INFO - 2018-03-15 23:59:27 --> Security Class Initialized
DEBUG - 2018-03-15 23:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 23:59:27 --> Input Class Initialized
INFO - 2018-03-15 23:59:27 --> Language Class Initialized
INFO - 2018-03-15 23:59:27 --> Loader Class Initialized
INFO - 2018-03-15 23:59:27 --> Helper loaded: url_helper
INFO - 2018-03-15 23:59:27 --> Helper loaded: form_helper
INFO - 2018-03-15 23:59:27 --> Database Driver Class Initialized
DEBUG - 2018-03-15 23:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 23:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 23:59:27 --> Form Validation Class Initialized
INFO - 2018-03-15 23:59:27 --> Model Class Initialized
INFO - 2018-03-15 23:59:27 --> Controller Class Initialized
INFO - 2018-03-15 23:59:27 --> Model Class Initialized
INFO - 2018-03-15 23:59:27 --> Model Class Initialized
DEBUG - 2018-03-15 23:59:27 --> Form_validation class already loaded. Second attempt ignored.
