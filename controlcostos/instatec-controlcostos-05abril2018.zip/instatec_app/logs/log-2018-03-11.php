<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-11 16:52:24 --> Config Class Initialized
INFO - 2018-03-11 16:52:24 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:52:24 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:52:24 --> Utf8 Class Initialized
INFO - 2018-03-11 16:52:24 --> URI Class Initialized
INFO - 2018-03-11 16:52:25 --> Router Class Initialized
INFO - 2018-03-11 16:52:25 --> Output Class Initialized
INFO - 2018-03-11 16:52:25 --> Security Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:52:25 --> Input Class Initialized
INFO - 2018-03-11 16:52:25 --> Language Class Initialized
INFO - 2018-03-11 16:52:25 --> Loader Class Initialized
INFO - 2018-03-11 16:52:25 --> Helper loaded: url_helper
INFO - 2018-03-11 16:52:25 --> Helper loaded: form_helper
INFO - 2018-03-11 16:52:25 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:52:25 --> Form Validation Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Controller Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:52:25 --> Config Class Initialized
INFO - 2018-03-11 16:52:25 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:52:25 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:52:25 --> Utf8 Class Initialized
INFO - 2018-03-11 16:52:25 --> URI Class Initialized
INFO - 2018-03-11 16:52:25 --> Router Class Initialized
INFO - 2018-03-11 16:52:25 --> Output Class Initialized
INFO - 2018-03-11 16:52:25 --> Security Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:52:25 --> Input Class Initialized
INFO - 2018-03-11 16:52:25 --> Language Class Initialized
INFO - 2018-03-11 16:52:25 --> Loader Class Initialized
INFO - 2018-03-11 16:52:25 --> Helper loaded: url_helper
INFO - 2018-03-11 16:52:25 --> Helper loaded: form_helper
INFO - 2018-03-11 16:52:25 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:52:25 --> Form Validation Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
INFO - 2018-03-11 16:52:25 --> Controller Class Initialized
INFO - 2018-03-11 16:52:25 --> Model Class Initialized
DEBUG - 2018-03-11 16:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:52:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 16:52:25 --> Final output sent to browser
DEBUG - 2018-03-11 16:52:25 --> Total execution time: 0.1542
INFO - 2018-03-11 16:53:21 --> Config Class Initialized
INFO - 2018-03-11 16:53:21 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:53:21 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:53:21 --> Utf8 Class Initialized
INFO - 2018-03-11 16:53:21 --> URI Class Initialized
INFO - 2018-03-11 16:53:21 --> Router Class Initialized
INFO - 2018-03-11 16:53:21 --> Output Class Initialized
INFO - 2018-03-11 16:53:21 --> Security Class Initialized
DEBUG - 2018-03-11 16:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:53:21 --> Input Class Initialized
INFO - 2018-03-11 16:53:21 --> Language Class Initialized
INFO - 2018-03-11 16:53:21 --> Loader Class Initialized
INFO - 2018-03-11 16:53:21 --> Helper loaded: url_helper
INFO - 2018-03-11 16:53:21 --> Helper loaded: form_helper
INFO - 2018-03-11 16:53:21 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:53:21 --> Form Validation Class Initialized
INFO - 2018-03-11 16:53:21 --> Model Class Initialized
INFO - 2018-03-11 16:53:21 --> Controller Class Initialized
INFO - 2018-03-11 16:53:21 --> Model Class Initialized
DEBUG - 2018-03-11 16:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:53:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-11 16:53:21 --> Config Class Initialized
INFO - 2018-03-11 16:53:21 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:53:21 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:53:21 --> Utf8 Class Initialized
INFO - 2018-03-11 16:53:21 --> URI Class Initialized
DEBUG - 2018-03-11 16:53:21 --> No URI present. Default controller set.
INFO - 2018-03-11 16:53:21 --> Router Class Initialized
INFO - 2018-03-11 16:53:21 --> Output Class Initialized
INFO - 2018-03-11 16:53:21 --> Security Class Initialized
DEBUG - 2018-03-11 16:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:53:21 --> Input Class Initialized
INFO - 2018-03-11 16:53:21 --> Language Class Initialized
INFO - 2018-03-11 16:53:21 --> Loader Class Initialized
INFO - 2018-03-11 16:53:21 --> Helper loaded: url_helper
INFO - 2018-03-11 16:53:21 --> Helper loaded: form_helper
INFO - 2018-03-11 16:53:21 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:53:21 --> Form Validation Class Initialized
INFO - 2018-03-11 16:53:21 --> Model Class Initialized
INFO - 2018-03-11 16:53:21 --> Controller Class Initialized
INFO - 2018-03-11 16:53:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 16:53:21 --> Final output sent to browser
DEBUG - 2018-03-11 16:53:21 --> Total execution time: 0.1451
INFO - 2018-03-11 16:53:22 --> Config Class Initialized
INFO - 2018-03-11 16:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:53:22 --> Utf8 Class Initialized
INFO - 2018-03-11 16:53:22 --> URI Class Initialized
INFO - 2018-03-11 16:53:22 --> Router Class Initialized
INFO - 2018-03-11 16:53:22 --> Output Class Initialized
INFO - 2018-03-11 16:53:22 --> Security Class Initialized
DEBUG - 2018-03-11 16:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:53:22 --> Input Class Initialized
INFO - 2018-03-11 16:53:22 --> Language Class Initialized
INFO - 2018-03-11 16:53:22 --> Loader Class Initialized
INFO - 2018-03-11 16:53:22 --> Helper loaded: url_helper
INFO - 2018-03-11 16:53:22 --> Helper loaded: form_helper
INFO - 2018-03-11 16:53:22 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:53:22 --> Form Validation Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
INFO - 2018-03-11 16:53:22 --> Controller Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
INFO - 2018-03-11 16:53:22 --> Model Class Initialized
DEBUG - 2018-03-11 16:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:53:26 --> Config Class Initialized
INFO - 2018-03-11 16:53:26 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:53:26 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:53:26 --> Utf8 Class Initialized
INFO - 2018-03-11 16:53:26 --> URI Class Initialized
INFO - 2018-03-11 16:53:26 --> Router Class Initialized
INFO - 2018-03-11 16:53:26 --> Output Class Initialized
INFO - 2018-03-11 16:53:26 --> Security Class Initialized
DEBUG - 2018-03-11 16:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:53:26 --> Input Class Initialized
INFO - 2018-03-11 16:53:26 --> Language Class Initialized
INFO - 2018-03-11 16:53:26 --> Loader Class Initialized
INFO - 2018-03-11 16:53:26 --> Helper loaded: url_helper
INFO - 2018-03-11 16:53:26 --> Helper loaded: form_helper
INFO - 2018-03-11 16:53:26 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:53:26 --> Form Validation Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
INFO - 2018-03-11 16:53:26 --> Controller Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
INFO - 2018-03-11 16:53:26 --> Model Class Initialized
DEBUG - 2018-03-11 16:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:53:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 16:53:26 --> Final output sent to browser
DEBUG - 2018-03-11 16:53:26 --> Total execution time: 0.2647
INFO - 2018-03-11 16:53:27 --> Config Class Initialized
INFO - 2018-03-11 16:53:27 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:53:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:53:27 --> Utf8 Class Initialized
INFO - 2018-03-11 16:53:27 --> URI Class Initialized
INFO - 2018-03-11 16:53:27 --> Router Class Initialized
INFO - 2018-03-11 16:53:27 --> Output Class Initialized
INFO - 2018-03-11 16:53:27 --> Security Class Initialized
DEBUG - 2018-03-11 16:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:53:27 --> Input Class Initialized
INFO - 2018-03-11 16:53:27 --> Language Class Initialized
INFO - 2018-03-11 16:53:27 --> Loader Class Initialized
INFO - 2018-03-11 16:53:27 --> Helper loaded: url_helper
INFO - 2018-03-11 16:53:27 --> Helper loaded: form_helper
INFO - 2018-03-11 16:53:27 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:53:27 --> Form Validation Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
INFO - 2018-03-11 16:53:27 --> Controller Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
INFO - 2018-03-11 16:53:27 --> Model Class Initialized
DEBUG - 2018-03-11 16:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:55:56 --> Config Class Initialized
INFO - 2018-03-11 16:55:56 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:55:56 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:55:56 --> Utf8 Class Initialized
INFO - 2018-03-11 16:55:56 --> URI Class Initialized
INFO - 2018-03-11 16:55:56 --> Router Class Initialized
INFO - 2018-03-11 16:55:56 --> Output Class Initialized
INFO - 2018-03-11 16:55:56 --> Security Class Initialized
DEBUG - 2018-03-11 16:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:55:56 --> Input Class Initialized
INFO - 2018-03-11 16:55:56 --> Language Class Initialized
INFO - 2018-03-11 16:55:56 --> Loader Class Initialized
INFO - 2018-03-11 16:55:56 --> Helper loaded: url_helper
INFO - 2018-03-11 16:55:56 --> Helper loaded: form_helper
INFO - 2018-03-11 16:55:56 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:55:56 --> Form Validation Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
INFO - 2018-03-11 16:55:56 --> Controller Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
INFO - 2018-03-11 16:55:56 --> Model Class Initialized
DEBUG - 2018-03-11 16:55:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:55:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 16:55:57 --> Final output sent to browser
DEBUG - 2018-03-11 16:55:57 --> Total execution time: 0.3446
INFO - 2018-03-11 16:55:57 --> Config Class Initialized
INFO - 2018-03-11 16:55:57 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:55:57 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:55:57 --> Utf8 Class Initialized
INFO - 2018-03-11 16:55:57 --> URI Class Initialized
INFO - 2018-03-11 16:55:57 --> Router Class Initialized
INFO - 2018-03-11 16:55:57 --> Output Class Initialized
INFO - 2018-03-11 16:55:57 --> Security Class Initialized
DEBUG - 2018-03-11 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:55:57 --> Input Class Initialized
INFO - 2018-03-11 16:55:57 --> Language Class Initialized
INFO - 2018-03-11 16:55:57 --> Loader Class Initialized
INFO - 2018-03-11 16:55:57 --> Helper loaded: url_helper
INFO - 2018-03-11 16:55:57 --> Helper loaded: form_helper
INFO - 2018-03-11 16:55:57 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:55:57 --> Form Validation Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
INFO - 2018-03-11 16:55:57 --> Controller Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
INFO - 2018-03-11 16:55:57 --> Model Class Initialized
DEBUG - 2018-03-11 16:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:56:01 --> Config Class Initialized
INFO - 2018-03-11 16:56:01 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:56:01 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:56:01 --> Utf8 Class Initialized
INFO - 2018-03-11 16:56:01 --> URI Class Initialized
INFO - 2018-03-11 16:56:01 --> Router Class Initialized
INFO - 2018-03-11 16:56:01 --> Output Class Initialized
INFO - 2018-03-11 16:56:01 --> Security Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:56:01 --> Input Class Initialized
INFO - 2018-03-11 16:56:01 --> Language Class Initialized
INFO - 2018-03-11 16:56:01 --> Loader Class Initialized
INFO - 2018-03-11 16:56:01 --> Helper loaded: url_helper
INFO - 2018-03-11 16:56:01 --> Helper loaded: form_helper
INFO - 2018-03-11 16:56:01 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:56:01 --> Form Validation Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Controller Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 16:56:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 16:56:01 --> Final output sent to browser
DEBUG - 2018-03-11 16:56:01 --> Total execution time: 0.0684
INFO - 2018-03-11 16:56:01 --> Config Class Initialized
INFO - 2018-03-11 16:56:01 --> Hooks Class Initialized
DEBUG - 2018-03-11 16:56:01 --> UTF-8 Support Enabled
INFO - 2018-03-11 16:56:01 --> Utf8 Class Initialized
INFO - 2018-03-11 16:56:01 --> URI Class Initialized
INFO - 2018-03-11 16:56:01 --> Router Class Initialized
INFO - 2018-03-11 16:56:01 --> Output Class Initialized
INFO - 2018-03-11 16:56:01 --> Security Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 16:56:01 --> Input Class Initialized
INFO - 2018-03-11 16:56:01 --> Language Class Initialized
INFO - 2018-03-11 16:56:01 --> Loader Class Initialized
INFO - 2018-03-11 16:56:01 --> Helper loaded: url_helper
INFO - 2018-03-11 16:56:01 --> Helper loaded: form_helper
INFO - 2018-03-11 16:56:01 --> Database Driver Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 16:56:01 --> Form Validation Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Controller Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
INFO - 2018-03-11 16:56:01 --> Model Class Initialized
DEBUG - 2018-03-11 16:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:16:19 --> Config Class Initialized
INFO - 2018-03-11 17:16:19 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:16:19 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:16:19 --> Utf8 Class Initialized
INFO - 2018-03-11 17:16:19 --> URI Class Initialized
INFO - 2018-03-11 17:16:19 --> Router Class Initialized
INFO - 2018-03-11 17:16:19 --> Output Class Initialized
INFO - 2018-03-11 17:16:19 --> Security Class Initialized
DEBUG - 2018-03-11 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:16:19 --> Input Class Initialized
INFO - 2018-03-11 17:16:19 --> Language Class Initialized
INFO - 2018-03-11 17:16:19 --> Loader Class Initialized
INFO - 2018-03-11 17:16:19 --> Helper loaded: url_helper
INFO - 2018-03-11 17:16:19 --> Helper loaded: form_helper
INFO - 2018-03-11 17:16:19 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:16:19 --> Form Validation Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
INFO - 2018-03-11 17:16:19 --> Controller Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
INFO - 2018-03-11 17:16:19 --> Model Class Initialized
DEBUG - 2018-03-11 17:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:16:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:16:20 --> Final output sent to browser
DEBUG - 2018-03-11 17:16:20 --> Total execution time: 0.3648
INFO - 2018-03-11 17:16:20 --> Config Class Initialized
INFO - 2018-03-11 17:16:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:16:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:16:20 --> Utf8 Class Initialized
INFO - 2018-03-11 17:16:20 --> URI Class Initialized
INFO - 2018-03-11 17:16:20 --> Router Class Initialized
INFO - 2018-03-11 17:16:20 --> Output Class Initialized
INFO - 2018-03-11 17:16:20 --> Security Class Initialized
DEBUG - 2018-03-11 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:16:20 --> Input Class Initialized
INFO - 2018-03-11 17:16:20 --> Language Class Initialized
INFO - 2018-03-11 17:16:20 --> Loader Class Initialized
INFO - 2018-03-11 17:16:20 --> Helper loaded: url_helper
INFO - 2018-03-11 17:16:20 --> Helper loaded: form_helper
INFO - 2018-03-11 17:16:20 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:16:20 --> Form Validation Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
INFO - 2018-03-11 17:16:20 --> Controller Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
INFO - 2018-03-11 17:16:20 --> Model Class Initialized
DEBUG - 2018-03-11 17:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:16:28 --> Config Class Initialized
INFO - 2018-03-11 17:16:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:16:28 --> Utf8 Class Initialized
INFO - 2018-03-11 17:16:28 --> URI Class Initialized
INFO - 2018-03-11 17:16:28 --> Router Class Initialized
INFO - 2018-03-11 17:16:28 --> Output Class Initialized
INFO - 2018-03-11 17:16:28 --> Security Class Initialized
DEBUG - 2018-03-11 17:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:16:28 --> Input Class Initialized
INFO - 2018-03-11 17:16:28 --> Language Class Initialized
INFO - 2018-03-11 17:16:28 --> Loader Class Initialized
INFO - 2018-03-11 17:16:28 --> Helper loaded: url_helper
INFO - 2018-03-11 17:16:28 --> Helper loaded: form_helper
INFO - 2018-03-11 17:16:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:16:29 --> Form Validation Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Controller Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
DEBUG - 2018-03-11 17:16:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:16:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:16:29 --> Final output sent to browser
DEBUG - 2018-03-11 17:16:29 --> Total execution time: 0.1133
INFO - 2018-03-11 17:16:29 --> Config Class Initialized
INFO - 2018-03-11 17:16:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:16:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:16:29 --> Utf8 Class Initialized
INFO - 2018-03-11 17:16:29 --> URI Class Initialized
INFO - 2018-03-11 17:16:29 --> Router Class Initialized
INFO - 2018-03-11 17:16:29 --> Output Class Initialized
INFO - 2018-03-11 17:16:29 --> Security Class Initialized
DEBUG - 2018-03-11 17:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:16:29 --> Input Class Initialized
INFO - 2018-03-11 17:16:29 --> Language Class Initialized
INFO - 2018-03-11 17:16:29 --> Loader Class Initialized
INFO - 2018-03-11 17:16:29 --> Helper loaded: url_helper
INFO - 2018-03-11 17:16:29 --> Helper loaded: form_helper
INFO - 2018-03-11 17:16:29 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:16:29 --> Form Validation Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Controller Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
INFO - 2018-03-11 17:16:29 --> Model Class Initialized
DEBUG - 2018-03-11 17:16:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:17:02 --> Config Class Initialized
INFO - 2018-03-11 17:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:02 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:02 --> URI Class Initialized
INFO - 2018-03-11 17:17:02 --> Router Class Initialized
INFO - 2018-03-11 17:17:02 --> Output Class Initialized
INFO - 2018-03-11 17:17:02 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:02 --> Input Class Initialized
INFO - 2018-03-11 17:17:02 --> Language Class Initialized
INFO - 2018-03-11 17:17:02 --> Loader Class Initialized
INFO - 2018-03-11 17:17:02 --> Helper loaded: url_helper
INFO - 2018-03-11 17:17:02 --> Helper loaded: form_helper
INFO - 2018-03-11 17:17:02 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:17:02 --> Form Validation Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Controller Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:17:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:17:02 --> Final output sent to browser
DEBUG - 2018-03-11 17:17:02 --> Total execution time: 0.0788
INFO - 2018-03-11 17:17:02 --> Config Class Initialized
INFO - 2018-03-11 17:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:02 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:02 --> URI Class Initialized
INFO - 2018-03-11 17:17:02 --> Router Class Initialized
INFO - 2018-03-11 17:17:02 --> Output Class Initialized
INFO - 2018-03-11 17:17:02 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:02 --> Input Class Initialized
INFO - 2018-03-11 17:17:02 --> Language Class Initialized
INFO - 2018-03-11 17:17:02 --> Loader Class Initialized
INFO - 2018-03-11 17:17:02 --> Helper loaded: url_helper
INFO - 2018-03-11 17:17:02 --> Helper loaded: form_helper
INFO - 2018-03-11 17:17:02 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:17:02 --> Form Validation Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Controller Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
INFO - 2018-03-11 17:17:02 --> Model Class Initialized
DEBUG - 2018-03-11 17:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:17:04 --> Config Class Initialized
INFO - 2018-03-11 17:17:04 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:17:04 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:04 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:04 --> URI Class Initialized
INFO - 2018-03-11 17:17:04 --> Router Class Initialized
INFO - 2018-03-11 17:17:04 --> Output Class Initialized
INFO - 2018-03-11 17:17:04 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:04 --> Input Class Initialized
INFO - 2018-03-11 17:17:04 --> Language Class Initialized
INFO - 2018-03-11 17:17:04 --> Loader Class Initialized
INFO - 2018-03-11 17:17:04 --> Helper loaded: url_helper
INFO - 2018-03-11 17:17:04 --> Helper loaded: form_helper
INFO - 2018-03-11 17:17:04 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:17:04 --> Form Validation Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Controller Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:17:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:17:04 --> Final output sent to browser
DEBUG - 2018-03-11 17:17:04 --> Total execution time: 0.0747
INFO - 2018-03-11 17:17:04 --> Config Class Initialized
INFO - 2018-03-11 17:17:04 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:17:04 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:04 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:04 --> URI Class Initialized
INFO - 2018-03-11 17:17:04 --> Router Class Initialized
INFO - 2018-03-11 17:17:04 --> Output Class Initialized
INFO - 2018-03-11 17:17:04 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:04 --> Input Class Initialized
INFO - 2018-03-11 17:17:04 --> Language Class Initialized
INFO - 2018-03-11 17:17:04 --> Loader Class Initialized
INFO - 2018-03-11 17:17:04 --> Helper loaded: url_helper
INFO - 2018-03-11 17:17:04 --> Helper loaded: form_helper
INFO - 2018-03-11 17:17:04 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:17:04 --> Form Validation Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Controller Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
INFO - 2018-03-11 17:17:04 --> Model Class Initialized
DEBUG - 2018-03-11 17:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:17:22 --> Config Class Initialized
INFO - 2018-03-11 17:17:22 --> Hooks Class Initialized
INFO - 2018-03-11 17:17:22 --> Config Class Initialized
INFO - 2018-03-11 17:17:22 --> Config Class Initialized
INFO - 2018-03-11 17:17:22 --> Hooks Class Initialized
INFO - 2018-03-11 17:17:22 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:22 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:22 --> URI Class Initialized
DEBUG - 2018-03-11 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:17:22 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:22 --> Utf8 Class Initialized
INFO - 2018-03-11 17:17:22 --> Router Class Initialized
INFO - 2018-03-11 17:17:22 --> URI Class Initialized
INFO - 2018-03-11 17:17:22 --> URI Class Initialized
INFO - 2018-03-11 17:17:22 --> Output Class Initialized
INFO - 2018-03-11 17:17:22 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:22 --> Input Class Initialized
INFO - 2018-03-11 17:17:22 --> Language Class Initialized
INFO - 2018-03-11 17:17:22 --> Router Class Initialized
INFO - 2018-03-11 17:17:22 --> Router Class Initialized
INFO - 2018-03-11 17:17:22 --> Output Class Initialized
INFO - 2018-03-11 17:17:22 --> Output Class Initialized
INFO - 2018-03-11 17:17:22 --> Security Class Initialized
INFO - 2018-03-11 17:17:22 --> Security Class Initialized
DEBUG - 2018-03-11 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:22 --> Input Class Initialized
INFO - 2018-03-11 17:17:22 --> Language Class Initialized
DEBUG - 2018-03-11 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:17:22 --> Input Class Initialized
INFO - 2018-03-11 17:17:22 --> Language Class Initialized
ERROR - 2018-03-11 17:17:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:17:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:17:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
INFO - 2018-03-11 17:39:55 --> Loader Class Initialized
INFO - 2018-03-11 17:39:55 --> Helper loaded: url_helper
INFO - 2018-03-11 17:39:55 --> Helper loaded: form_helper
INFO - 2018-03-11 17:39:55 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:39:55 --> Form Validation Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Controller Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:39:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:39:55 --> Final output sent to browser
DEBUG - 2018-03-11 17:39:55 --> Total execution time: 0.0589
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:39:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:39:55 --> Config Class Initialized
INFO - 2018-03-11 17:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:55 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:55 --> URI Class Initialized
INFO - 2018-03-11 17:39:55 --> Router Class Initialized
INFO - 2018-03-11 17:39:55 --> Output Class Initialized
INFO - 2018-03-11 17:39:55 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:55 --> Input Class Initialized
INFO - 2018-03-11 17:39:55 --> Language Class Initialized
INFO - 2018-03-11 17:39:55 --> Loader Class Initialized
INFO - 2018-03-11 17:39:55 --> Helper loaded: url_helper
INFO - 2018-03-11 17:39:55 --> Helper loaded: form_helper
INFO - 2018-03-11 17:39:55 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:39:55 --> Form Validation Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Controller Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
INFO - 2018-03-11 17:39:55 --> Model Class Initialized
DEBUG - 2018-03-11 17:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
INFO - 2018-03-11 17:39:58 --> Loader Class Initialized
INFO - 2018-03-11 17:39:58 --> Helper loaded: url_helper
INFO - 2018-03-11 17:39:58 --> Helper loaded: form_helper
INFO - 2018-03-11 17:39:58 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:39:58 --> Form Validation Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Controller Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:39:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:39:58 --> Final output sent to browser
DEBUG - 2018-03-11 17:39:58 --> Total execution time: 0.0796
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:39:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:39:58 --> Config Class Initialized
INFO - 2018-03-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:39:58 --> Utf8 Class Initialized
INFO - 2018-03-11 17:39:58 --> URI Class Initialized
INFO - 2018-03-11 17:39:58 --> Router Class Initialized
INFO - 2018-03-11 17:39:58 --> Output Class Initialized
INFO - 2018-03-11 17:39:58 --> Security Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:39:58 --> Input Class Initialized
INFO - 2018-03-11 17:39:58 --> Language Class Initialized
INFO - 2018-03-11 17:39:58 --> Loader Class Initialized
INFO - 2018-03-11 17:39:58 --> Helper loaded: url_helper
INFO - 2018-03-11 17:39:58 --> Helper loaded: form_helper
INFO - 2018-03-11 17:39:58 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:39:58 --> Form Validation Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Controller Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
INFO - 2018-03-11 17:39:58 --> Model Class Initialized
DEBUG - 2018-03-11 17:39:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Loader Class Initialized
INFO - 2018-03-11 17:40:48 --> Helper loaded: url_helper
INFO - 2018-03-11 17:40:48 --> Helper loaded: form_helper
INFO - 2018-03-11 17:40:48 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:40:48 --> Form Validation Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Controller Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:40:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:40:48 --> Final output sent to browser
DEBUG - 2018-03-11 17:40:48 --> Total execution time: 0.0795
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:40:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:40:48 --> Config Class Initialized
INFO - 2018-03-11 17:40:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:40:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:40:48 --> URI Class Initialized
INFO - 2018-03-11 17:40:48 --> Router Class Initialized
INFO - 2018-03-11 17:40:48 --> Output Class Initialized
INFO - 2018-03-11 17:40:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:40:48 --> Input Class Initialized
INFO - 2018-03-11 17:40:48 --> Language Class Initialized
INFO - 2018-03-11 17:40:48 --> Loader Class Initialized
INFO - 2018-03-11 17:40:48 --> Helper loaded: url_helper
INFO - 2018-03-11 17:40:48 --> Helper loaded: form_helper
INFO - 2018-03-11 17:40:48 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:40:48 --> Form Validation Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Controller Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
INFO - 2018-03-11 17:40:48 --> Model Class Initialized
DEBUG - 2018-03-11 17:40:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:29 --> Config Class Initialized
INFO - 2018-03-11 17:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:29 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:29 --> URI Class Initialized
INFO - 2018-03-11 17:41:29 --> Router Class Initialized
INFO - 2018-03-11 17:41:29 --> Output Class Initialized
INFO - 2018-03-11 17:41:29 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:29 --> Input Class Initialized
INFO - 2018-03-11 17:41:29 --> Language Class Initialized
INFO - 2018-03-11 17:41:29 --> Loader Class Initialized
INFO - 2018-03-11 17:41:29 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:29 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:29 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:29 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
INFO - 2018-03-11 17:41:29 --> Controller Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
INFO - 2018-03-11 17:41:29 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:41:29 --> Final output sent to browser
DEBUG - 2018-03-11 17:41:29 --> Total execution time: 0.0743
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:41:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:41:30 --> Config Class Initialized
INFO - 2018-03-11 17:41:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:30 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:30 --> URI Class Initialized
INFO - 2018-03-11 17:41:30 --> Router Class Initialized
INFO - 2018-03-11 17:41:30 --> Output Class Initialized
INFO - 2018-03-11 17:41:30 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:30 --> Input Class Initialized
INFO - 2018-03-11 17:41:30 --> Language Class Initialized
INFO - 2018-03-11 17:41:30 --> Loader Class Initialized
INFO - 2018-03-11 17:41:30 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:30 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:30 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:30 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
INFO - 2018-03-11 17:41:30 --> Controller Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
INFO - 2018-03-11 17:41:30 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
INFO - 2018-03-11 17:41:34 --> Loader Class Initialized
INFO - 2018-03-11 17:41:34 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:34 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:34 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:34 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Controller Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:41:34 --> Final output sent to browser
DEBUG - 2018-03-11 17:41:34 --> Total execution time: 0.0740
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Config Class Initialized
INFO - 2018-03-11 17:41:34 --> Hooks Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
DEBUG - 2018-03-11 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> URI Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
INFO - 2018-03-11 17:41:34 --> Router Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Output Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Security Class Initialized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:34 --> Input Class Initialized
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:41:34 --> Language Class Initialized
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:41:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:41:34 --> Loader Class Initialized
INFO - 2018-03-11 17:41:34 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:34 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:34 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:34 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Controller Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
INFO - 2018-03-11 17:41:34 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:41 --> Config Class Initialized
INFO - 2018-03-11 17:41:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:41 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:41 --> URI Class Initialized
INFO - 2018-03-11 17:41:41 --> Router Class Initialized
INFO - 2018-03-11 17:41:41 --> Output Class Initialized
INFO - 2018-03-11 17:41:41 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:41 --> Input Class Initialized
INFO - 2018-03-11 17:41:41 --> Language Class Initialized
INFO - 2018-03-11 17:41:41 --> Loader Class Initialized
INFO - 2018-03-11 17:41:41 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:41 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:41 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:41 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
INFO - 2018-03-11 17:41:41 --> Controller Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
INFO - 2018-03-11 17:41:41 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:41:44 --> Config Class Initialized
INFO - 2018-03-11 17:41:44 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:41:44 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:41:44 --> Utf8 Class Initialized
INFO - 2018-03-11 17:41:44 --> URI Class Initialized
INFO - 2018-03-11 17:41:44 --> Router Class Initialized
INFO - 2018-03-11 17:41:44 --> Output Class Initialized
INFO - 2018-03-11 17:41:44 --> Security Class Initialized
DEBUG - 2018-03-11 17:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:41:44 --> Input Class Initialized
INFO - 2018-03-11 17:41:44 --> Language Class Initialized
INFO - 2018-03-11 17:41:44 --> Loader Class Initialized
INFO - 2018-03-11 17:41:44 --> Helper loaded: url_helper
INFO - 2018-03-11 17:41:44 --> Helper loaded: form_helper
INFO - 2018-03-11 17:41:44 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:41:44 --> Form Validation Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
INFO - 2018-03-11 17:41:44 --> Controller Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
INFO - 2018-03-11 17:41:44 --> Model Class Initialized
DEBUG - 2018-03-11 17:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:43:40 --> Config Class Initialized
INFO - 2018-03-11 17:43:40 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:43:40 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:40 --> Utf8 Class Initialized
INFO - 2018-03-11 17:43:40 --> URI Class Initialized
INFO - 2018-03-11 17:43:40 --> Router Class Initialized
INFO - 2018-03-11 17:43:40 --> Output Class Initialized
INFO - 2018-03-11 17:43:40 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:40 --> Input Class Initialized
INFO - 2018-03-11 17:43:40 --> Language Class Initialized
INFO - 2018-03-11 17:43:40 --> Loader Class Initialized
INFO - 2018-03-11 17:43:40 --> Helper loaded: url_helper
INFO - 2018-03-11 17:43:40 --> Helper loaded: form_helper
INFO - 2018-03-11 17:43:40 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:43:40 --> Form Validation Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Controller Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:43:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:43:40 --> Final output sent to browser
DEBUG - 2018-03-11 17:43:40 --> Total execution time: 0.0714
INFO - 2018-03-11 17:43:40 --> Config Class Initialized
INFO - 2018-03-11 17:43:40 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:43:40 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:40 --> Utf8 Class Initialized
INFO - 2018-03-11 17:43:40 --> URI Class Initialized
INFO - 2018-03-11 17:43:40 --> Router Class Initialized
INFO - 2018-03-11 17:43:40 --> Output Class Initialized
INFO - 2018-03-11 17:43:40 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:40 --> Input Class Initialized
INFO - 2018-03-11 17:43:40 --> Language Class Initialized
INFO - 2018-03-11 17:43:40 --> Loader Class Initialized
INFO - 2018-03-11 17:43:40 --> Helper loaded: url_helper
INFO - 2018-03-11 17:43:40 --> Helper loaded: form_helper
INFO - 2018-03-11 17:43:40 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:43:40 --> Form Validation Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Controller Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
INFO - 2018-03-11 17:43:40 --> Model Class Initialized
DEBUG - 2018-03-11 17:43:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:43:44 --> Config Class Initialized
INFO - 2018-03-11 17:43:44 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:43:44 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:44 --> Utf8 Class Initialized
INFO - 2018-03-11 17:43:44 --> URI Class Initialized
INFO - 2018-03-11 17:43:44 --> Router Class Initialized
INFO - 2018-03-11 17:43:44 --> Output Class Initialized
INFO - 2018-03-11 17:43:44 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:44 --> Input Class Initialized
INFO - 2018-03-11 17:43:44 --> Language Class Initialized
INFO - 2018-03-11 17:43:44 --> Loader Class Initialized
INFO - 2018-03-11 17:43:44 --> Helper loaded: url_helper
INFO - 2018-03-11 17:43:44 --> Helper loaded: form_helper
INFO - 2018-03-11 17:43:44 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:43:44 --> Form Validation Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Controller Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:43:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:43:44 --> Final output sent to browser
DEBUG - 2018-03-11 17:43:44 --> Total execution time: 0.0768
INFO - 2018-03-11 17:43:44 --> Config Class Initialized
INFO - 2018-03-11 17:43:44 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:43:44 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:44 --> Utf8 Class Initialized
INFO - 2018-03-11 17:43:44 --> URI Class Initialized
INFO - 2018-03-11 17:43:44 --> Router Class Initialized
INFO - 2018-03-11 17:43:44 --> Output Class Initialized
INFO - 2018-03-11 17:43:44 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:44 --> Input Class Initialized
INFO - 2018-03-11 17:43:44 --> Language Class Initialized
INFO - 2018-03-11 17:43:44 --> Loader Class Initialized
INFO - 2018-03-11 17:43:44 --> Helper loaded: url_helper
INFO - 2018-03-11 17:43:44 --> Helper loaded: form_helper
INFO - 2018-03-11 17:43:44 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:43:44 --> Form Validation Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Controller Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
INFO - 2018-03-11 17:43:44 --> Model Class Initialized
DEBUG - 2018-03-11 17:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:43:51 --> Config Class Initialized
INFO - 2018-03-11 17:43:51 --> Hooks Class Initialized
INFO - 2018-03-11 17:43:51 --> Config Class Initialized
INFO - 2018-03-11 17:43:51 --> Hooks Class Initialized
INFO - 2018-03-11 17:43:51 --> Config Class Initialized
INFO - 2018-03-11 17:43:51 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:43:51 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:51 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:43:51 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:51 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:43:51 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:43:51 --> Utf8 Class Initialized
INFO - 2018-03-11 17:43:51 --> URI Class Initialized
INFO - 2018-03-11 17:43:51 --> URI Class Initialized
INFO - 2018-03-11 17:43:51 --> URI Class Initialized
INFO - 2018-03-11 17:43:51 --> Router Class Initialized
INFO - 2018-03-11 17:43:51 --> Router Class Initialized
INFO - 2018-03-11 17:43:51 --> Output Class Initialized
INFO - 2018-03-11 17:43:51 --> Output Class Initialized
INFO - 2018-03-11 17:43:51 --> Security Class Initialized
INFO - 2018-03-11 17:43:51 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:51 --> Input Class Initialized
INFO - 2018-03-11 17:43:51 --> Router Class Initialized
INFO - 2018-03-11 17:43:51 --> Input Class Initialized
INFO - 2018-03-11 17:43:51 --> Language Class Initialized
INFO - 2018-03-11 17:43:51 --> Language Class Initialized
INFO - 2018-03-11 17:43:51 --> Output Class Initialized
ERROR - 2018-03-11 17:43:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:43:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:43:51 --> Security Class Initialized
DEBUG - 2018-03-11 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:43:51 --> Input Class Initialized
INFO - 2018-03-11 17:43:51 --> Language Class Initialized
ERROR - 2018-03-11 17:43:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:47:45 --> Config Class Initialized
INFO - 2018-03-11 17:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:45 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:45 --> URI Class Initialized
INFO - 2018-03-11 17:47:45 --> Router Class Initialized
INFO - 2018-03-11 17:47:45 --> Output Class Initialized
INFO - 2018-03-11 17:47:45 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:45 --> Input Class Initialized
INFO - 2018-03-11 17:47:45 --> Language Class Initialized
INFO - 2018-03-11 17:47:45 --> Loader Class Initialized
INFO - 2018-03-11 17:47:45 --> Helper loaded: url_helper
INFO - 2018-03-11 17:47:45 --> Helper loaded: form_helper
INFO - 2018-03-11 17:47:45 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:47:45 --> Form Validation Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Controller Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:47:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:47:45 --> Final output sent to browser
DEBUG - 2018-03-11 17:47:45 --> Total execution time: 0.0699
INFO - 2018-03-11 17:47:45 --> Config Class Initialized
INFO - 2018-03-11 17:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:45 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:45 --> URI Class Initialized
INFO - 2018-03-11 17:47:45 --> Router Class Initialized
INFO - 2018-03-11 17:47:45 --> Output Class Initialized
INFO - 2018-03-11 17:47:45 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:45 --> Input Class Initialized
INFO - 2018-03-11 17:47:45 --> Language Class Initialized
INFO - 2018-03-11 17:47:45 --> Loader Class Initialized
INFO - 2018-03-11 17:47:45 --> Helper loaded: url_helper
INFO - 2018-03-11 17:47:45 --> Helper loaded: form_helper
INFO - 2018-03-11 17:47:45 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:47:45 --> Form Validation Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Controller Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
INFO - 2018-03-11 17:47:45 --> Model Class Initialized
DEBUG - 2018-03-11 17:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
INFO - 2018-03-11 17:47:48 --> Loader Class Initialized
INFO - 2018-03-11 17:47:48 --> Helper loaded: url_helper
INFO - 2018-03-11 17:47:48 --> Helper loaded: form_helper
INFO - 2018-03-11 17:47:48 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:47:48 --> Form Validation Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
INFO - 2018-03-11 17:47:48 --> Controller Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
INFO - 2018-03-11 17:47:48 --> Model Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:47:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:47:48 --> Final output sent to browser
DEBUG - 2018-03-11 17:47:48 --> Total execution time: 0.0567
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:47:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:47:48 --> Config Class Initialized
INFO - 2018-03-11 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:47:48 --> Utf8 Class Initialized
INFO - 2018-03-11 17:47:48 --> URI Class Initialized
INFO - 2018-03-11 17:47:48 --> Router Class Initialized
INFO - 2018-03-11 17:47:48 --> Output Class Initialized
INFO - 2018-03-11 17:47:48 --> Security Class Initialized
DEBUG - 2018-03-11 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:47:48 --> Input Class Initialized
INFO - 2018-03-11 17:47:48 --> Language Class Initialized
INFO - 2018-03-11 17:47:48 --> Loader Class Initialized
INFO - 2018-03-11 17:47:48 --> Helper loaded: url_helper
INFO - 2018-03-11 17:47:48 --> Helper loaded: form_helper
INFO - 2018-03-11 17:47:49 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:47:49 --> Form Validation Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
INFO - 2018-03-11 17:47:49 --> Controller Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
INFO - 2018-03-11 17:47:49 --> Model Class Initialized
DEBUG - 2018-03-11 17:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:48:10 --> Config Class Initialized
INFO - 2018-03-11 17:48:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:10 --> URI Class Initialized
INFO - 2018-03-11 17:48:10 --> Router Class Initialized
INFO - 2018-03-11 17:48:10 --> Output Class Initialized
INFO - 2018-03-11 17:48:10 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:10 --> Input Class Initialized
INFO - 2018-03-11 17:48:10 --> Language Class Initialized
INFO - 2018-03-11 17:48:10 --> Loader Class Initialized
INFO - 2018-03-11 17:48:10 --> Helper loaded: url_helper
INFO - 2018-03-11 17:48:10 --> Helper loaded: form_helper
INFO - 2018-03-11 17:48:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:48:10 --> Form Validation Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
INFO - 2018-03-11 17:48:10 --> Controller Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
INFO - 2018-03-11 17:48:10 --> Model Class Initialized
DEBUG - 2018-03-11 17:48:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:48:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:48:10 --> Final output sent to browser
DEBUG - 2018-03-11 17:48:10 --> Total execution time: 0.0598
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:48:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:48:11 --> Config Class Initialized
INFO - 2018-03-11 17:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:11 --> URI Class Initialized
INFO - 2018-03-11 17:48:11 --> Router Class Initialized
INFO - 2018-03-11 17:48:11 --> Output Class Initialized
INFO - 2018-03-11 17:48:11 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:11 --> Input Class Initialized
INFO - 2018-03-11 17:48:11 --> Language Class Initialized
INFO - 2018-03-11 17:48:11 --> Loader Class Initialized
INFO - 2018-03-11 17:48:11 --> Helper loaded: url_helper
INFO - 2018-03-11 17:48:11 --> Helper loaded: form_helper
INFO - 2018-03-11 17:48:11 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:48:11 --> Form Validation Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
INFO - 2018-03-11 17:48:11 --> Controller Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
INFO - 2018-03-11 17:48:11 --> Model Class Initialized
DEBUG - 2018-03-11 17:48:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:48:32 --> Config Class Initialized
INFO - 2018-03-11 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:32 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:32 --> URI Class Initialized
INFO - 2018-03-11 17:48:32 --> Router Class Initialized
INFO - 2018-03-11 17:48:32 --> Output Class Initialized
INFO - 2018-03-11 17:48:32 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:32 --> Input Class Initialized
INFO - 2018-03-11 17:48:32 --> Language Class Initialized
INFO - 2018-03-11 17:48:32 --> Loader Class Initialized
INFO - 2018-03-11 17:48:32 --> Helper loaded: url_helper
INFO - 2018-03-11 17:48:32 --> Helper loaded: form_helper
INFO - 2018-03-11 17:48:32 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:48:32 --> Form Validation Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
INFO - 2018-03-11 17:48:32 --> Controller Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
INFO - 2018-03-11 17:48:32 --> Model Class Initialized
DEBUG - 2018-03-11 17:48:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:48:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:48:32 --> Final output sent to browser
DEBUG - 2018-03-11 17:48:32 --> Total execution time: 0.0648
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
ERROR - 2018-03-11 17:48:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:48:33 --> Config Class Initialized
INFO - 2018-03-11 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:48:33 --> Utf8 Class Initialized
INFO - 2018-03-11 17:48:33 --> URI Class Initialized
INFO - 2018-03-11 17:48:33 --> Router Class Initialized
INFO - 2018-03-11 17:48:33 --> Output Class Initialized
INFO - 2018-03-11 17:48:33 --> Security Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:48:33 --> Input Class Initialized
INFO - 2018-03-11 17:48:33 --> Language Class Initialized
INFO - 2018-03-11 17:48:33 --> Loader Class Initialized
INFO - 2018-03-11 17:48:33 --> Helper loaded: url_helper
INFO - 2018-03-11 17:48:33 --> Helper loaded: form_helper
INFO - 2018-03-11 17:48:33 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:48:33 --> Form Validation Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
INFO - 2018-03-11 17:48:33 --> Controller Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
INFO - 2018-03-11 17:48:33 --> Model Class Initialized
DEBUG - 2018-03-11 17:48:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
INFO - 2018-03-11 17:49:00 --> Loader Class Initialized
INFO - 2018-03-11 17:49:00 --> Helper loaded: url_helper
INFO - 2018-03-11 17:49:00 --> Helper loaded: form_helper
INFO - 2018-03-11 17:49:00 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:49:00 --> Form Validation Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Controller Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:49:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:49:00 --> Final output sent to browser
DEBUG - 2018-03-11 17:49:00 --> Total execution time: 0.0781
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:49:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:49:00 --> Config Class Initialized
INFO - 2018-03-11 17:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:49:00 --> Utf8 Class Initialized
INFO - 2018-03-11 17:49:00 --> URI Class Initialized
INFO - 2018-03-11 17:49:00 --> Router Class Initialized
INFO - 2018-03-11 17:49:00 --> Output Class Initialized
INFO - 2018-03-11 17:49:00 --> Security Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:49:00 --> Input Class Initialized
INFO - 2018-03-11 17:49:00 --> Language Class Initialized
INFO - 2018-03-11 17:49:00 --> Loader Class Initialized
INFO - 2018-03-11 17:49:00 --> Helper loaded: url_helper
INFO - 2018-03-11 17:49:00 --> Helper loaded: form_helper
INFO - 2018-03-11 17:49:00 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:49:00 --> Form Validation Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Controller Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
INFO - 2018-03-11 17:49:00 --> Model Class Initialized
DEBUG - 2018-03-11 17:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
INFO - 2018-03-11 17:59:10 --> Loader Class Initialized
INFO - 2018-03-11 17:59:10 --> Helper loaded: url_helper
INFO - 2018-03-11 17:59:10 --> Helper loaded: form_helper
INFO - 2018-03-11 17:59:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:59:10 --> Form Validation Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
INFO - 2018-03-11 17:59:10 --> Controller Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
INFO - 2018-03-11 17:59:10 --> Model Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 17:59:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 17:59:10 --> Final output sent to browser
DEBUG - 2018-03-11 17:59:10 --> Total execution time: 0.0604
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
INFO - 2018-03-11 17:59:10 --> Config Class Initialized
INFO - 2018-03-11 17:59:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 17:59:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:10 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> URI Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Router Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
INFO - 2018-03-11 17:59:10 --> Output Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
INFO - 2018-03-11 17:59:10 --> Security Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
DEBUG - 2018-03-11 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:10 --> Input Class Initialized
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
INFO - 2018-03-11 17:59:10 --> Language Class Initialized
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 17:59:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 17:59:11 --> Config Class Initialized
INFO - 2018-03-11 17:59:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 17:59:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 17:59:11 --> Utf8 Class Initialized
INFO - 2018-03-11 17:59:11 --> URI Class Initialized
INFO - 2018-03-11 17:59:11 --> Router Class Initialized
INFO - 2018-03-11 17:59:11 --> Output Class Initialized
INFO - 2018-03-11 17:59:11 --> Security Class Initialized
DEBUG - 2018-03-11 17:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 17:59:11 --> Input Class Initialized
INFO - 2018-03-11 17:59:11 --> Language Class Initialized
INFO - 2018-03-11 17:59:11 --> Loader Class Initialized
INFO - 2018-03-11 17:59:11 --> Helper loaded: url_helper
INFO - 2018-03-11 17:59:11 --> Helper loaded: form_helper
INFO - 2018-03-11 17:59:11 --> Database Driver Class Initialized
DEBUG - 2018-03-11 17:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 17:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 17:59:11 --> Form Validation Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
INFO - 2018-03-11 17:59:11 --> Controller Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
INFO - 2018-03-11 17:59:11 --> Model Class Initialized
DEBUG - 2018-03-11 17:59:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined offset: 14 D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined offset: 16 D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 628
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 619
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 624
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 619
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 624
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 619
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 624
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 619
ERROR - 2018-03-11 17:59:11 --> Severity: Notice --> Undefined index: total_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 624
INFO - 2018-03-11 18:00:52 --> Config Class Initialized
INFO - 2018-03-11 18:00:52 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:00:52 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:00:52 --> Utf8 Class Initialized
INFO - 2018-03-11 18:00:52 --> URI Class Initialized
INFO - 2018-03-11 18:00:52 --> Router Class Initialized
INFO - 2018-03-11 18:00:52 --> Output Class Initialized
INFO - 2018-03-11 18:00:52 --> Security Class Initialized
DEBUG - 2018-03-11 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:00:52 --> Input Class Initialized
INFO - 2018-03-11 18:00:52 --> Language Class Initialized
INFO - 2018-03-11 18:00:52 --> Loader Class Initialized
INFO - 2018-03-11 18:00:52 --> Helper loaded: url_helper
INFO - 2018-03-11 18:00:52 --> Helper loaded: form_helper
INFO - 2018-03-11 18:00:52 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:00:52 --> Form Validation Class Initialized
INFO - 2018-03-11 18:00:52 --> Model Class Initialized
INFO - 2018-03-11 18:00:52 --> Controller Class Initialized
ERROR - 2018-03-11 18:00:52 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 619
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
INFO - 2018-03-11 18:01:10 --> Loader Class Initialized
INFO - 2018-03-11 18:01:10 --> Helper loaded: url_helper
INFO - 2018-03-11 18:01:10 --> Helper loaded: form_helper
INFO - 2018-03-11 18:01:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:01:10 --> Form Validation Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Controller Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:01:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:01:10 --> Final output sent to browser
DEBUG - 2018-03-11 18:01:10 --> Total execution time: 0.0733
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
ERROR - 2018-03-11 18:01:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:01:10 --> Config Class Initialized
INFO - 2018-03-11 18:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:01:10 --> Utf8 Class Initialized
INFO - 2018-03-11 18:01:10 --> URI Class Initialized
INFO - 2018-03-11 18:01:10 --> Router Class Initialized
INFO - 2018-03-11 18:01:10 --> Output Class Initialized
INFO - 2018-03-11 18:01:10 --> Security Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:01:10 --> Input Class Initialized
INFO - 2018-03-11 18:01:10 --> Language Class Initialized
INFO - 2018-03-11 18:01:10 --> Loader Class Initialized
INFO - 2018-03-11 18:01:10 --> Helper loaded: url_helper
INFO - 2018-03-11 18:01:10 --> Helper loaded: form_helper
INFO - 2018-03-11 18:01:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:01:10 --> Form Validation Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Controller Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
INFO - 2018-03-11 18:01:10 --> Model Class Initialized
DEBUG - 2018-03-11 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:02:31 --> Config Class Initialized
INFO - 2018-03-11 18:02:31 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:02:31 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:31 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:31 --> URI Class Initialized
INFO - 2018-03-11 18:02:31 --> Router Class Initialized
INFO - 2018-03-11 18:02:31 --> Output Class Initialized
INFO - 2018-03-11 18:02:31 --> Security Class Initialized
DEBUG - 2018-03-11 18:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:31 --> Input Class Initialized
INFO - 2018-03-11 18:02:31 --> Language Class Initialized
INFO - 2018-03-11 18:02:31 --> Loader Class Initialized
INFO - 2018-03-11 18:02:31 --> Helper loaded: url_helper
INFO - 2018-03-11 18:02:31 --> Helper loaded: form_helper
INFO - 2018-03-11 18:02:31 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:02:31 --> Form Validation Class Initialized
INFO - 2018-03-11 18:02:31 --> Model Class Initialized
INFO - 2018-03-11 18:02:31 --> Controller Class Initialized
INFO - 2018-03-11 18:02:31 --> Model Class Initialized
INFO - 2018-03-11 18:02:31 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:02:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:02:32 --> Final output sent to browser
DEBUG - 2018-03-11 18:02:32 --> Total execution time: 0.0861
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:02:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:02:32 --> Config Class Initialized
INFO - 2018-03-11 18:02:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:02:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:02:32 --> Utf8 Class Initialized
INFO - 2018-03-11 18:02:32 --> URI Class Initialized
INFO - 2018-03-11 18:02:32 --> Router Class Initialized
INFO - 2018-03-11 18:02:32 --> Output Class Initialized
INFO - 2018-03-11 18:02:32 --> Security Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:02:32 --> Input Class Initialized
INFO - 2018-03-11 18:02:32 --> Language Class Initialized
INFO - 2018-03-11 18:02:32 --> Loader Class Initialized
INFO - 2018-03-11 18:02:32 --> Helper loaded: url_helper
INFO - 2018-03-11 18:02:32 --> Helper loaded: form_helper
INFO - 2018-03-11 18:02:32 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:02:32 --> Form Validation Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Controller Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
INFO - 2018-03-11 18:02:32 --> Model Class Initialized
DEBUG - 2018-03-11 18:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:03:02 --> Config Class Initialized
INFO - 2018-03-11 18:03:02 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:03:02 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:02 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:02 --> URI Class Initialized
INFO - 2018-03-11 18:03:02 --> Router Class Initialized
INFO - 2018-03-11 18:03:02 --> Output Class Initialized
INFO - 2018-03-11 18:03:02 --> Security Class Initialized
DEBUG - 2018-03-11 18:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:02 --> Input Class Initialized
INFO - 2018-03-11 18:03:02 --> Language Class Initialized
INFO - 2018-03-11 18:03:02 --> Loader Class Initialized
INFO - 2018-03-11 18:03:02 --> Helper loaded: url_helper
INFO - 2018-03-11 18:03:02 --> Helper loaded: form_helper
INFO - 2018-03-11 18:03:02 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:03:02 --> Form Validation Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
INFO - 2018-03-11 18:03:02 --> Controller Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
INFO - 2018-03-11 18:03:02 --> Model Class Initialized
DEBUG - 2018-03-11 18:03:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:03:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:03:02 --> Final output sent to browser
DEBUG - 2018-03-11 18:03:02 --> Total execution time: 0.0758
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
ERROR - 2018-03-11 18:03:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:03:03 --> Config Class Initialized
INFO - 2018-03-11 18:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:03:03 --> Utf8 Class Initialized
INFO - 2018-03-11 18:03:03 --> URI Class Initialized
INFO - 2018-03-11 18:03:03 --> Router Class Initialized
INFO - 2018-03-11 18:03:03 --> Output Class Initialized
INFO - 2018-03-11 18:03:03 --> Security Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:03:03 --> Input Class Initialized
INFO - 2018-03-11 18:03:03 --> Language Class Initialized
INFO - 2018-03-11 18:03:03 --> Loader Class Initialized
INFO - 2018-03-11 18:03:03 --> Helper loaded: url_helper
INFO - 2018-03-11 18:03:03 --> Helper loaded: form_helper
INFO - 2018-03-11 18:03:03 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:03:03 --> Form Validation Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
INFO - 2018-03-11 18:03:03 --> Controller Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
INFO - 2018-03-11 18:03:03 --> Model Class Initialized
DEBUG - 2018-03-11 18:03:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:09:15 --> Config Class Initialized
INFO - 2018-03-11 18:09:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:15 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:15 --> URI Class Initialized
INFO - 2018-03-11 18:09:15 --> Router Class Initialized
INFO - 2018-03-11 18:09:15 --> Output Class Initialized
INFO - 2018-03-11 18:09:15 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:15 --> Input Class Initialized
INFO - 2018-03-11 18:09:15 --> Language Class Initialized
INFO - 2018-03-11 18:09:15 --> Loader Class Initialized
INFO - 2018-03-11 18:09:15 --> Helper loaded: url_helper
INFO - 2018-03-11 18:09:15 --> Helper loaded: form_helper
INFO - 2018-03-11 18:09:15 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:09:15 --> Form Validation Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
INFO - 2018-03-11 18:09:15 --> Controller Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
INFO - 2018-03-11 18:09:15 --> Model Class Initialized
DEBUG - 2018-03-11 18:09:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:09:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:09:15 --> Final output sent to browser
DEBUG - 2018-03-11 18:09:15 --> Total execution time: 0.0838
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:09:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:09:16 --> Config Class Initialized
INFO - 2018-03-11 18:09:16 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:16 --> URI Class Initialized
INFO - 2018-03-11 18:09:16 --> Router Class Initialized
INFO - 2018-03-11 18:09:16 --> Output Class Initialized
INFO - 2018-03-11 18:09:16 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:16 --> Input Class Initialized
INFO - 2018-03-11 18:09:16 --> Language Class Initialized
INFO - 2018-03-11 18:09:16 --> Loader Class Initialized
INFO - 2018-03-11 18:09:16 --> Helper loaded: url_helper
INFO - 2018-03-11 18:09:16 --> Helper loaded: form_helper
INFO - 2018-03-11 18:09:16 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:09:16 --> Form Validation Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
INFO - 2018-03-11 18:09:16 --> Controller Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
INFO - 2018-03-11 18:09:16 --> Model Class Initialized
DEBUG - 2018-03-11 18:09:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 627
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 626
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 636
ERROR - 2018-03-11 18:09:16 --> Severity: Notice --> Undefined property: stdClass::$colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
INFO - 2018-03-11 18:09:54 --> Config Class Initialized
INFO - 2018-03-11 18:09:54 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:54 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:54 --> URI Class Initialized
INFO - 2018-03-11 18:09:54 --> Router Class Initialized
INFO - 2018-03-11 18:09:54 --> Output Class Initialized
INFO - 2018-03-11 18:09:54 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:54 --> Input Class Initialized
INFO - 2018-03-11 18:09:54 --> Language Class Initialized
INFO - 2018-03-11 18:09:54 --> Loader Class Initialized
INFO - 2018-03-11 18:09:54 --> Helper loaded: url_helper
INFO - 2018-03-11 18:09:54 --> Helper loaded: form_helper
INFO - 2018-03-11 18:09:54 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:09:54 --> Form Validation Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
INFO - 2018-03-11 18:09:54 --> Controller Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
INFO - 2018-03-11 18:09:54 --> Model Class Initialized
DEBUG - 2018-03-11 18:09:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:09:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:09:54 --> Final output sent to browser
DEBUG - 2018-03-11 18:09:54 --> Total execution time: 0.0829
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:09:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:09:55 --> Config Class Initialized
INFO - 2018-03-11 18:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:09:55 --> Utf8 Class Initialized
INFO - 2018-03-11 18:09:55 --> URI Class Initialized
INFO - 2018-03-11 18:09:55 --> Router Class Initialized
INFO - 2018-03-11 18:09:55 --> Output Class Initialized
INFO - 2018-03-11 18:09:55 --> Security Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:09:55 --> Input Class Initialized
INFO - 2018-03-11 18:09:55 --> Language Class Initialized
INFO - 2018-03-11 18:09:55 --> Loader Class Initialized
INFO - 2018-03-11 18:09:55 --> Helper loaded: url_helper
INFO - 2018-03-11 18:09:55 --> Helper loaded: form_helper
INFO - 2018-03-11 18:09:55 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:09:55 --> Form Validation Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
INFO - 2018-03-11 18:09:55 --> Controller Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
INFO - 2018-03-11 18:09:55 --> Model Class Initialized
DEBUG - 2018-03-11 18:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
INFO - 2018-03-11 18:21:41 --> Loader Class Initialized
INFO - 2018-03-11 18:21:41 --> Helper loaded: url_helper
INFO - 2018-03-11 18:21:41 --> Helper loaded: form_helper
INFO - 2018-03-11 18:21:41 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:21:41 --> Form Validation Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Controller Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:21:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:21:41 --> Final output sent to browser
DEBUG - 2018-03-11 18:21:41 --> Total execution time: 0.0507
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:21:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:21:41 --> Config Class Initialized
INFO - 2018-03-11 18:21:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:21:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:21:41 --> Utf8 Class Initialized
INFO - 2018-03-11 18:21:41 --> URI Class Initialized
INFO - 2018-03-11 18:21:41 --> Router Class Initialized
INFO - 2018-03-11 18:21:41 --> Output Class Initialized
INFO - 2018-03-11 18:21:41 --> Security Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:21:41 --> Input Class Initialized
INFO - 2018-03-11 18:21:41 --> Language Class Initialized
INFO - 2018-03-11 18:21:41 --> Loader Class Initialized
INFO - 2018-03-11 18:21:41 --> Helper loaded: url_helper
INFO - 2018-03-11 18:21:41 --> Helper loaded: form_helper
INFO - 2018-03-11 18:21:41 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:21:41 --> Form Validation Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Controller Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
INFO - 2018-03-11 18:21:41 --> Model Class Initialized
DEBUG - 2018-03-11 18:21:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
INFO - 2018-03-11 18:22:28 --> Loader Class Initialized
INFO - 2018-03-11 18:22:28 --> Helper loaded: url_helper
INFO - 2018-03-11 18:22:28 --> Helper loaded: form_helper
INFO - 2018-03-11 18:22:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:22:28 --> Form Validation Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Controller Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 18:22:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 18:22:28 --> Final output sent to browser
DEBUG - 2018-03-11 18:22:28 --> Total execution time: 0.0582
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 18:22:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 18:22:28 --> Config Class Initialized
INFO - 2018-03-11 18:22:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 18:22:28 --> Utf8 Class Initialized
INFO - 2018-03-11 18:22:28 --> URI Class Initialized
INFO - 2018-03-11 18:22:28 --> Router Class Initialized
INFO - 2018-03-11 18:22:28 --> Output Class Initialized
INFO - 2018-03-11 18:22:28 --> Security Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 18:22:28 --> Input Class Initialized
INFO - 2018-03-11 18:22:28 --> Language Class Initialized
INFO - 2018-03-11 18:22:28 --> Loader Class Initialized
INFO - 2018-03-11 18:22:28 --> Helper loaded: url_helper
INFO - 2018-03-11 18:22:28 --> Helper loaded: form_helper
INFO - 2018-03-11 18:22:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 18:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 18:22:28 --> Form Validation Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Controller Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
INFO - 2018-03-11 18:22:28 --> Model Class Initialized
DEBUG - 2018-03-11 18:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:23 --> Config Class Initialized
INFO - 2018-03-11 23:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:23 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:23 --> URI Class Initialized
INFO - 2018-03-11 23:19:23 --> Router Class Initialized
INFO - 2018-03-11 23:19:23 --> Output Class Initialized
INFO - 2018-03-11 23:19:23 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:23 --> Input Class Initialized
INFO - 2018-03-11 23:19:23 --> Language Class Initialized
INFO - 2018-03-11 23:19:23 --> Loader Class Initialized
INFO - 2018-03-11 23:19:23 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:23 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:23 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:24 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
INFO - 2018-03-11 23:19:24 --> Controller Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
INFO - 2018-03-11 23:19:24 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:26 --> Config Class Initialized
INFO - 2018-03-11 23:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:26 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:26 --> URI Class Initialized
INFO - 2018-03-11 23:19:26 --> Router Class Initialized
INFO - 2018-03-11 23:19:26 --> Output Class Initialized
INFO - 2018-03-11 23:19:26 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:26 --> Input Class Initialized
INFO - 2018-03-11 23:19:26 --> Language Class Initialized
INFO - 2018-03-11 23:19:26 --> Loader Class Initialized
INFO - 2018-03-11 23:19:26 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:26 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:26 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:26 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:26 --> Model Class Initialized
INFO - 2018-03-11 23:19:26 --> Controller Class Initialized
INFO - 2018-03-11 23:19:26 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:19:26 --> Final output sent to browser
DEBUG - 2018-03-11 23:19:26 --> Total execution time: 2.7464
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
INFO - 2018-03-11 23:19:27 --> Config Class Initialized
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
INFO - 2018-03-11 23:19:27 --> Hooks Class Initialized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
DEBUG - 2018-03-11 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
INFO - 2018-03-11 23:19:27 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
INFO - 2018-03-11 23:19:27 --> URI Class Initialized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:27 --> Router Class Initialized
INFO - 2018-03-11 23:19:27 --> Output Class Initialized
INFO - 2018-03-11 23:19:27 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:27 --> Input Class Initialized
INFO - 2018-03-11 23:19:27 --> Language Class Initialized
ERROR - 2018-03-11 23:19:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:19:28 --> Config Class Initialized
INFO - 2018-03-11 23:19:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:28 --> URI Class Initialized
INFO - 2018-03-11 23:19:28 --> Router Class Initialized
INFO - 2018-03-11 23:19:28 --> Output Class Initialized
INFO - 2018-03-11 23:19:28 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:28 --> Input Class Initialized
INFO - 2018-03-11 23:19:28 --> Language Class Initialized
INFO - 2018-03-11 23:19:28 --> Loader Class Initialized
INFO - 2018-03-11 23:19:28 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:28 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:28 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:28 --> Model Class Initialized
INFO - 2018-03-11 23:19:28 --> Controller Class Initialized
INFO - 2018-03-11 23:19:28 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
DEBUG - 2018-03-11 23:19:29 --> No URI present. Default controller set.
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
INFO - 2018-03-11 23:19:29 --> Loader Class Initialized
INFO - 2018-03-11 23:19:29 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:29 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:29 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:29 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Controller Class Initialized
INFO - 2018-03-11 23:19:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:19:29 --> Final output sent to browser
DEBUG - 2018-03-11 23:19:29 --> Total execution time: 0.0780
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:19:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:19:29 --> Config Class Initialized
INFO - 2018-03-11 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:29 --> URI Class Initialized
INFO - 2018-03-11 23:19:29 --> Router Class Initialized
INFO - 2018-03-11 23:19:29 --> Output Class Initialized
INFO - 2018-03-11 23:19:29 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:29 --> Input Class Initialized
INFO - 2018-03-11 23:19:29 --> Language Class Initialized
INFO - 2018-03-11 23:19:29 --> Loader Class Initialized
INFO - 2018-03-11 23:19:29 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:29 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:29 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:29 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Controller Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
INFO - 2018-03-11 23:19:29 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:36 --> Config Class Initialized
INFO - 2018-03-11 23:19:36 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:36 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:36 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:36 --> URI Class Initialized
INFO - 2018-03-11 23:19:36 --> Router Class Initialized
INFO - 2018-03-11 23:19:36 --> Output Class Initialized
INFO - 2018-03-11 23:19:36 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:36 --> Input Class Initialized
INFO - 2018-03-11 23:19:36 --> Language Class Initialized
INFO - 2018-03-11 23:19:36 --> Loader Class Initialized
INFO - 2018-03-11 23:19:36 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:36 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:36 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:36 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
INFO - 2018-03-11 23:19:36 --> Controller Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
INFO - 2018-03-11 23:19:36 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:19:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:19:36 --> Final output sent to browser
DEBUG - 2018-03-11 23:19:36 --> Total execution time: 0.0727
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:19:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:19:37 --> Config Class Initialized
INFO - 2018-03-11 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:19:37 --> URI Class Initialized
INFO - 2018-03-11 23:19:37 --> Router Class Initialized
INFO - 2018-03-11 23:19:37 --> Output Class Initialized
INFO - 2018-03-11 23:19:37 --> Security Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:19:37 --> Input Class Initialized
INFO - 2018-03-11 23:19:37 --> Language Class Initialized
INFO - 2018-03-11 23:19:37 --> Loader Class Initialized
INFO - 2018-03-11 23:19:37 --> Helper loaded: url_helper
INFO - 2018-03-11 23:19:37 --> Helper loaded: form_helper
INFO - 2018-03-11 23:19:37 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:19:37 --> Form Validation Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
INFO - 2018-03-11 23:19:37 --> Controller Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
INFO - 2018-03-11 23:19:37 --> Model Class Initialized
DEBUG - 2018-03-11 23:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:20:33 --> Config Class Initialized
INFO - 2018-03-11 23:20:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:20:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:33 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:33 --> URI Class Initialized
INFO - 2018-03-11 23:20:33 --> Router Class Initialized
INFO - 2018-03-11 23:20:33 --> Output Class Initialized
INFO - 2018-03-11 23:20:33 --> Security Class Initialized
DEBUG - 2018-03-11 23:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:33 --> Input Class Initialized
INFO - 2018-03-11 23:20:33 --> Language Class Initialized
INFO - 2018-03-11 23:20:33 --> Loader Class Initialized
INFO - 2018-03-11 23:20:33 --> Helper loaded: url_helper
INFO - 2018-03-11 23:20:33 --> Helper loaded: form_helper
INFO - 2018-03-11 23:20:33 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:20:33 --> Form Validation Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
INFO - 2018-03-11 23:20:33 --> Controller Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
INFO - 2018-03-11 23:20:33 --> Model Class Initialized
DEBUG - 2018-03-11 23:20:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:20:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:20:33 --> Final output sent to browser
DEBUG - 2018-03-11 23:20:33 --> Total execution time: 0.0564
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:20:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:20:34 --> Config Class Initialized
INFO - 2018-03-11 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:20:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:20:34 --> URI Class Initialized
INFO - 2018-03-11 23:20:34 --> Router Class Initialized
INFO - 2018-03-11 23:20:34 --> Output Class Initialized
INFO - 2018-03-11 23:20:34 --> Security Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:20:34 --> Input Class Initialized
INFO - 2018-03-11 23:20:34 --> Language Class Initialized
INFO - 2018-03-11 23:20:34 --> Loader Class Initialized
INFO - 2018-03-11 23:20:34 --> Helper loaded: url_helper
INFO - 2018-03-11 23:20:34 --> Helper loaded: form_helper
INFO - 2018-03-11 23:20:34 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:20:34 --> Form Validation Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
INFO - 2018-03-11 23:20:34 --> Controller Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
INFO - 2018-03-11 23:20:34 --> Model Class Initialized
DEBUG - 2018-03-11 23:20:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:03 --> Loader Class Initialized
INFO - 2018-03-11 23:21:03 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:03 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:03 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:03 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
INFO - 2018-03-11 23:21:03 --> Controller Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
INFO - 2018-03-11 23:21:03 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:21:03 --> Final output sent to browser
DEBUG - 2018-03-11 23:21:03 --> Total execution time: 0.1375
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:21:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:21:03 --> Config Class Initialized
INFO - 2018-03-11 23:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:03 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:03 --> URI Class Initialized
INFO - 2018-03-11 23:21:03 --> Router Class Initialized
INFO - 2018-03-11 23:21:03 --> Output Class Initialized
INFO - 2018-03-11 23:21:03 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:03 --> Input Class Initialized
INFO - 2018-03-11 23:21:03 --> Language Class Initialized
INFO - 2018-03-11 23:21:04 --> Loader Class Initialized
INFO - 2018-03-11 23:21:04 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:04 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:04 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:04 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
INFO - 2018-03-11 23:21:04 --> Controller Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
INFO - 2018-03-11 23:21:04 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
INFO - 2018-03-11 23:21:10 --> Loader Class Initialized
INFO - 2018-03-11 23:21:10 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:10 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:10 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:10 --> Controller Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:21:10 --> Final output sent to browser
DEBUG - 2018-03-11 23:21:10 --> Total execution time: 0.1593
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
ERROR - 2018-03-11 23:21:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:21:10 --> Config Class Initialized
INFO - 2018-03-11 23:21:10 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:10 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:10 --> URI Class Initialized
INFO - 2018-03-11 23:21:10 --> Router Class Initialized
INFO - 2018-03-11 23:21:10 --> Output Class Initialized
INFO - 2018-03-11 23:21:10 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:10 --> Input Class Initialized
INFO - 2018-03-11 23:21:10 --> Language Class Initialized
INFO - 2018-03-11 23:21:10 --> Loader Class Initialized
INFO - 2018-03-11 23:21:10 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:10 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:10 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:10 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:10 --> Model Class Initialized
INFO - 2018-03-11 23:21:11 --> Controller Class Initialized
INFO - 2018-03-11 23:21:11 --> Model Class Initialized
INFO - 2018-03-11 23:21:11 --> Model Class Initialized
INFO - 2018-03-11 23:21:11 --> Model Class Initialized
INFO - 2018-03-11 23:21:11 --> Model Class Initialized
INFO - 2018-03-11 23:21:11 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:33 --> Config Class Initialized
INFO - 2018-03-11 23:21:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:33 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:33 --> URI Class Initialized
INFO - 2018-03-11 23:21:33 --> Router Class Initialized
INFO - 2018-03-11 23:21:33 --> Output Class Initialized
INFO - 2018-03-11 23:21:33 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:33 --> Input Class Initialized
INFO - 2018-03-11 23:21:33 --> Language Class Initialized
INFO - 2018-03-11 23:21:34 --> Loader Class Initialized
INFO - 2018-03-11 23:21:34 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:34 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:34 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:34 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Controller Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:21:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:21:34 --> Final output sent to browser
DEBUG - 2018-03-11 23:21:34 --> Total execution time: 0.1325
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:21:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:21:34 --> Config Class Initialized
INFO - 2018-03-11 23:21:34 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:21:34 --> Utf8 Class Initialized
INFO - 2018-03-11 23:21:34 --> URI Class Initialized
INFO - 2018-03-11 23:21:34 --> Router Class Initialized
INFO - 2018-03-11 23:21:34 --> Output Class Initialized
INFO - 2018-03-11 23:21:34 --> Security Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:21:34 --> Input Class Initialized
INFO - 2018-03-11 23:21:34 --> Language Class Initialized
INFO - 2018-03-11 23:21:34 --> Loader Class Initialized
INFO - 2018-03-11 23:21:34 --> Helper loaded: url_helper
INFO - 2018-03-11 23:21:34 --> Helper loaded: form_helper
INFO - 2018-03-11 23:21:34 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:21:34 --> Form Validation Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Controller Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
INFO - 2018-03-11 23:21:34 --> Model Class Initialized
DEBUG - 2018-03-11 23:21:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Loader Class Initialized
INFO - 2018-03-11 23:22:15 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:15 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:15 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:15 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Controller Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:22:15 --> Final output sent to browser
DEBUG - 2018-03-11 23:22:15 --> Total execution time: 0.0926
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:22:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:22:15 --> Config Class Initialized
INFO - 2018-03-11 23:22:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:15 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:15 --> URI Class Initialized
INFO - 2018-03-11 23:22:15 --> Router Class Initialized
INFO - 2018-03-11 23:22:15 --> Output Class Initialized
INFO - 2018-03-11 23:22:15 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:15 --> Input Class Initialized
INFO - 2018-03-11 23:22:15 --> Language Class Initialized
INFO - 2018-03-11 23:22:15 --> Loader Class Initialized
INFO - 2018-03-11 23:22:15 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:15 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:15 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:15 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Controller Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
INFO - 2018-03-11 23:22:15 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:20 --> Config Class Initialized
INFO - 2018-03-11 23:22:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:20 --> URI Class Initialized
INFO - 2018-03-11 23:22:20 --> Router Class Initialized
INFO - 2018-03-11 23:22:20 --> Output Class Initialized
INFO - 2018-03-11 23:22:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:20 --> Input Class Initialized
INFO - 2018-03-11 23:22:20 --> Language Class Initialized
INFO - 2018-03-11 23:22:20 --> Loader Class Initialized
INFO - 2018-03-11 23:22:20 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:20 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:20 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:20 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Controller Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:22:20 --> Final output sent to browser
DEBUG - 2018-03-11 23:22:20 --> Total execution time: 0.1766
INFO - 2018-03-11 23:22:20 --> Config Class Initialized
INFO - 2018-03-11 23:22:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:20 --> URI Class Initialized
INFO - 2018-03-11 23:22:20 --> Router Class Initialized
INFO - 2018-03-11 23:22:20 --> Output Class Initialized
INFO - 2018-03-11 23:22:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:20 --> Input Class Initialized
INFO - 2018-03-11 23:22:20 --> Language Class Initialized
INFO - 2018-03-11 23:22:20 --> Loader Class Initialized
INFO - 2018-03-11 23:22:20 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:20 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:20 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:20 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Controller Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
INFO - 2018-03-11 23:22:20 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:37 --> Config Class Initialized
INFO - 2018-03-11 23:22:37 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:37 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:37 --> URI Class Initialized
INFO - 2018-03-11 23:22:37 --> Router Class Initialized
INFO - 2018-03-11 23:22:37 --> Output Class Initialized
INFO - 2018-03-11 23:22:37 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:37 --> Input Class Initialized
INFO - 2018-03-11 23:22:37 --> Language Class Initialized
INFO - 2018-03-11 23:22:37 --> Loader Class Initialized
INFO - 2018-03-11 23:22:37 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:37 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:37 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:37 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
INFO - 2018-03-11 23:22:37 --> Controller Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
INFO - 2018-03-11 23:22:37 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:22:37 --> Final output sent to browser
DEBUG - 2018-03-11 23:22:37 --> Total execution time: 0.2959
INFO - 2018-03-11 23:22:38 --> Config Class Initialized
INFO - 2018-03-11 23:22:38 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:38 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:38 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:38 --> URI Class Initialized
INFO - 2018-03-11 23:22:38 --> Router Class Initialized
INFO - 2018-03-11 23:22:38 --> Output Class Initialized
INFO - 2018-03-11 23:22:38 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:38 --> Input Class Initialized
INFO - 2018-03-11 23:22:38 --> Language Class Initialized
INFO - 2018-03-11 23:22:38 --> Loader Class Initialized
INFO - 2018-03-11 23:22:38 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:38 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:38 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:38 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
INFO - 2018-03-11 23:22:38 --> Controller Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
INFO - 2018-03-11 23:22:38 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:41 --> Config Class Initialized
INFO - 2018-03-11 23:22:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:41 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:41 --> URI Class Initialized
INFO - 2018-03-11 23:22:41 --> Router Class Initialized
INFO - 2018-03-11 23:22:41 --> Output Class Initialized
INFO - 2018-03-11 23:22:41 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:41 --> Input Class Initialized
INFO - 2018-03-11 23:22:41 --> Language Class Initialized
INFO - 2018-03-11 23:22:41 --> Loader Class Initialized
INFO - 2018-03-11 23:22:41 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:41 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:41 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:41 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
INFO - 2018-03-11 23:22:41 --> Controller Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
INFO - 2018-03-11 23:22:41 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:22:41 --> Final output sent to browser
DEBUG - 2018-03-11 23:22:41 --> Total execution time: 0.1504
INFO - 2018-03-11 23:22:42 --> Config Class Initialized
INFO - 2018-03-11 23:22:42 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:42 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:42 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:42 --> URI Class Initialized
INFO - 2018-03-11 23:22:42 --> Router Class Initialized
INFO - 2018-03-11 23:22:42 --> Output Class Initialized
INFO - 2018-03-11 23:22:42 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:42 --> Input Class Initialized
INFO - 2018-03-11 23:22:42 --> Language Class Initialized
INFO - 2018-03-11 23:22:42 --> Loader Class Initialized
INFO - 2018-03-11 23:22:42 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:42 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:42 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:42 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
INFO - 2018-03-11 23:22:42 --> Controller Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
INFO - 2018-03-11 23:22:42 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:43 --> Config Class Initialized
INFO - 2018-03-11 23:22:43 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:43 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:43 --> URI Class Initialized
INFO - 2018-03-11 23:22:43 --> Router Class Initialized
INFO - 2018-03-11 23:22:43 --> Output Class Initialized
INFO - 2018-03-11 23:22:43 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:43 --> Input Class Initialized
INFO - 2018-03-11 23:22:43 --> Language Class Initialized
INFO - 2018-03-11 23:22:43 --> Loader Class Initialized
INFO - 2018-03-11 23:22:43 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:43 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:43 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:43 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Controller Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:22:43 --> Final output sent to browser
DEBUG - 2018-03-11 23:22:43 --> Total execution time: 0.1657
INFO - 2018-03-11 23:22:43 --> Config Class Initialized
INFO - 2018-03-11 23:22:43 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:43 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:43 --> URI Class Initialized
INFO - 2018-03-11 23:22:43 --> Router Class Initialized
INFO - 2018-03-11 23:22:43 --> Output Class Initialized
INFO - 2018-03-11 23:22:43 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:43 --> Input Class Initialized
INFO - 2018-03-11 23:22:43 --> Language Class Initialized
INFO - 2018-03-11 23:22:43 --> Loader Class Initialized
INFO - 2018-03-11 23:22:43 --> Helper loaded: url_helper
INFO - 2018-03-11 23:22:43 --> Helper loaded: form_helper
INFO - 2018-03-11 23:22:43 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:22:43 --> Form Validation Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Controller Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:43 --> Model Class Initialized
INFO - 2018-03-11 23:22:44 --> Model Class Initialized
INFO - 2018-03-11 23:22:44 --> Model Class Initialized
INFO - 2018-03-11 23:22:44 --> Model Class Initialized
DEBUG - 2018-03-11 23:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:22:47 --> Config Class Initialized
INFO - 2018-03-11 23:22:47 --> Config Class Initialized
INFO - 2018-03-11 23:22:47 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:47 --> Config Class Initialized
INFO - 2018-03-11 23:22:47 --> Hooks Class Initialized
INFO - 2018-03-11 23:22:47 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:22:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:22:47 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:47 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:47 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:22:47 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:22:47 --> Utf8 Class Initialized
INFO - 2018-03-11 23:22:47 --> URI Class Initialized
INFO - 2018-03-11 23:22:47 --> URI Class Initialized
INFO - 2018-03-11 23:22:47 --> URI Class Initialized
INFO - 2018-03-11 23:22:47 --> Router Class Initialized
INFO - 2018-03-11 23:22:48 --> Router Class Initialized
INFO - 2018-03-11 23:22:48 --> Router Class Initialized
INFO - 2018-03-11 23:22:48 --> Output Class Initialized
INFO - 2018-03-11 23:22:48 --> Output Class Initialized
INFO - 2018-03-11 23:22:48 --> Output Class Initialized
INFO - 2018-03-11 23:22:48 --> Security Class Initialized
INFO - 2018-03-11 23:22:48 --> Security Class Initialized
INFO - 2018-03-11 23:22:48 --> Security Class Initialized
DEBUG - 2018-03-11 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:48 --> Input Class Initialized
INFO - 2018-03-11 23:22:48 --> Input Class Initialized
DEBUG - 2018-03-11 23:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:22:48 --> Language Class Initialized
INFO - 2018-03-11 23:22:48 --> Language Class Initialized
INFO - 2018-03-11 23:22:48 --> Input Class Initialized
INFO - 2018-03-11 23:22:48 --> Language Class Initialized
ERROR - 2018-03-11 23:22:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:22:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:22:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
INFO - 2018-03-11 23:50:20 --> Loader Class Initialized
INFO - 2018-03-11 23:50:20 --> Helper loaded: url_helper
INFO - 2018-03-11 23:50:20 --> Helper loaded: form_helper
INFO - 2018-03-11 23:50:20 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:50:20 --> Form Validation Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Controller Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:50:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:50:20 --> Final output sent to browser
DEBUG - 2018-03-11 23:50:20 --> Total execution time: 0.0739
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:50:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:50:20 --> Config Class Initialized
INFO - 2018-03-11 23:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:50:20 --> Utf8 Class Initialized
INFO - 2018-03-11 23:50:20 --> URI Class Initialized
INFO - 2018-03-11 23:50:20 --> Router Class Initialized
INFO - 2018-03-11 23:50:20 --> Output Class Initialized
INFO - 2018-03-11 23:50:20 --> Security Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:50:20 --> Input Class Initialized
INFO - 2018-03-11 23:50:20 --> Language Class Initialized
INFO - 2018-03-11 23:50:20 --> Loader Class Initialized
INFO - 2018-03-11 23:50:20 --> Helper loaded: url_helper
INFO - 2018-03-11 23:50:20 --> Helper loaded: form_helper
INFO - 2018-03-11 23:50:20 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:50:20 --> Form Validation Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Controller Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
INFO - 2018-03-11 23:50:20 --> Model Class Initialized
DEBUG - 2018-03-11 23:50:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:51:29 --> Config Class Initialized
INFO - 2018-03-11 23:51:29 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:51:29 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:29 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:29 --> URI Class Initialized
INFO - 2018-03-11 23:51:29 --> Router Class Initialized
INFO - 2018-03-11 23:51:29 --> Output Class Initialized
INFO - 2018-03-11 23:51:29 --> Security Class Initialized
DEBUG - 2018-03-11 23:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:29 --> Input Class Initialized
INFO - 2018-03-11 23:51:29 --> Language Class Initialized
INFO - 2018-03-11 23:51:29 --> Loader Class Initialized
INFO - 2018-03-11 23:51:29 --> Helper loaded: url_helper
INFO - 2018-03-11 23:51:29 --> Helper loaded: form_helper
INFO - 2018-03-11 23:51:29 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:51:29 --> Form Validation Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
INFO - 2018-03-11 23:51:29 --> Controller Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
INFO - 2018-03-11 23:51:29 --> Model Class Initialized
DEBUG - 2018-03-11 23:51:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:51:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:51:29 --> Final output sent to browser
DEBUG - 2018-03-11 23:51:29 --> Total execution time: 0.0842
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:51:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:51:30 --> Config Class Initialized
INFO - 2018-03-11 23:51:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:51:30 --> Utf8 Class Initialized
INFO - 2018-03-11 23:51:30 --> URI Class Initialized
INFO - 2018-03-11 23:51:30 --> Router Class Initialized
INFO - 2018-03-11 23:51:30 --> Output Class Initialized
INFO - 2018-03-11 23:51:30 --> Security Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:51:30 --> Input Class Initialized
INFO - 2018-03-11 23:51:30 --> Language Class Initialized
INFO - 2018-03-11 23:51:30 --> Loader Class Initialized
INFO - 2018-03-11 23:51:30 --> Helper loaded: url_helper
INFO - 2018-03-11 23:51:30 --> Helper loaded: form_helper
INFO - 2018-03-11 23:51:30 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:51:30 --> Form Validation Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
INFO - 2018-03-11 23:51:30 --> Controller Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
INFO - 2018-03-11 23:51:30 --> Model Class Initialized
DEBUG - 2018-03-11 23:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
INFO - 2018-03-11 23:57:54 --> Loader Class Initialized
INFO - 2018-03-11 23:57:54 --> Helper loaded: url_helper
INFO - 2018-03-11 23:57:54 --> Helper loaded: form_helper
INFO - 2018-03-11 23:57:54 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:57:54 --> Form Validation Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Controller Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:57:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:57:54 --> Final output sent to browser
DEBUG - 2018-03-11 23:57:54 --> Total execution time: 0.0607
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
ERROR - 2018-03-11 23:57:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:57:54 --> Config Class Initialized
INFO - 2018-03-11 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:57:54 --> Utf8 Class Initialized
INFO - 2018-03-11 23:57:54 --> URI Class Initialized
INFO - 2018-03-11 23:57:54 --> Router Class Initialized
INFO - 2018-03-11 23:57:54 --> Output Class Initialized
INFO - 2018-03-11 23:57:54 --> Security Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:57:54 --> Input Class Initialized
INFO - 2018-03-11 23:57:54 --> Language Class Initialized
INFO - 2018-03-11 23:57:54 --> Loader Class Initialized
INFO - 2018-03-11 23:57:54 --> Helper loaded: url_helper
INFO - 2018-03-11 23:57:54 --> Helper loaded: form_helper
INFO - 2018-03-11 23:57:54 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:57:54 --> Form Validation Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Controller Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
INFO - 2018-03-11 23:57:54 --> Model Class Initialized
DEBUG - 2018-03-11 23:57:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
INFO - 2018-03-11 23:58:28 --> Loader Class Initialized
INFO - 2018-03-11 23:58:28 --> Helper loaded: url_helper
INFO - 2018-03-11 23:58:28 --> Helper loaded: form_helper
INFO - 2018-03-11 23:58:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:58:28 --> Form Validation Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Controller Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-11 23:58:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-11 23:58:28 --> Final output sent to browser
DEBUG - 2018-03-11 23:58:28 --> Total execution time: 0.0769
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-11 23:58:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-11 23:58:28 --> Config Class Initialized
INFO - 2018-03-11 23:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 23:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 23:58:28 --> Utf8 Class Initialized
INFO - 2018-03-11 23:58:28 --> URI Class Initialized
INFO - 2018-03-11 23:58:28 --> Router Class Initialized
INFO - 2018-03-11 23:58:28 --> Output Class Initialized
INFO - 2018-03-11 23:58:28 --> Security Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 23:58:28 --> Input Class Initialized
INFO - 2018-03-11 23:58:28 --> Language Class Initialized
INFO - 2018-03-11 23:58:28 --> Loader Class Initialized
INFO - 2018-03-11 23:58:28 --> Helper loaded: url_helper
INFO - 2018-03-11 23:58:28 --> Helper loaded: form_helper
INFO - 2018-03-11 23:58:28 --> Database Driver Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-11 23:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-11 23:58:28 --> Form Validation Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Controller Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
INFO - 2018-03-11 23:58:28 --> Model Class Initialized
DEBUG - 2018-03-11 23:58:28 --> Form_validation class already loaded. Second attempt ignored.
