<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:36 --> Loader Class Initialized
INFO - 2018-03-23 00:00:36 --> Helper loaded: url_helper
INFO - 2018-03-23 00:00:36 --> Helper loaded: form_helper
INFO - 2018-03-23 00:00:36 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:00:36 --> Form Validation Class Initialized
INFO - 2018-03-23 00:00:36 --> Model Class Initialized
INFO - 2018-03-23 00:00:36 --> Controller Class Initialized
INFO - 2018-03-23 00:00:36 --> Model Class Initialized
INFO - 2018-03-23 00:00:36 --> Model Class Initialized
INFO - 2018-03-23 00:00:36 --> Model Class Initialized
INFO - 2018-03-23 00:00:36 --> Model Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:00:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:00:36 --> Final output sent to browser
DEBUG - 2018-03-23 00:00:36 --> Total execution time: 0.0756
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:00:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:00:36 --> Config Class Initialized
INFO - 2018-03-23 00:00:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:00:36 --> URI Class Initialized
INFO - 2018-03-23 00:00:36 --> Router Class Initialized
INFO - 2018-03-23 00:00:36 --> Output Class Initialized
INFO - 2018-03-23 00:00:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:00:36 --> Input Class Initialized
INFO - 2018-03-23 00:00:36 --> Language Class Initialized
INFO - 2018-03-23 00:00:37 --> Loader Class Initialized
INFO - 2018-03-23 00:00:37 --> Helper loaded: url_helper
INFO - 2018-03-23 00:00:37 --> Helper loaded: form_helper
INFO - 2018-03-23 00:00:37 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:00:37 --> Form Validation Class Initialized
INFO - 2018-03-23 00:00:37 --> Model Class Initialized
INFO - 2018-03-23 00:00:37 --> Controller Class Initialized
INFO - 2018-03-23 00:00:37 --> Model Class Initialized
INFO - 2018-03-23 00:00:37 --> Model Class Initialized
INFO - 2018-03-23 00:00:37 --> Model Class Initialized
INFO - 2018-03-23 00:00:37 --> Model Class Initialized
DEBUG - 2018-03-23 00:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:06:22 --> Config Class Initialized
INFO - 2018-03-23 00:06:22 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:06:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:22 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:22 --> URI Class Initialized
INFO - 2018-03-23 00:06:22 --> Router Class Initialized
INFO - 2018-03-23 00:06:22 --> Output Class Initialized
INFO - 2018-03-23 00:06:22 --> Security Class Initialized
DEBUG - 2018-03-23 00:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:22 --> Input Class Initialized
INFO - 2018-03-23 00:06:22 --> Language Class Initialized
INFO - 2018-03-23 00:06:22 --> Loader Class Initialized
INFO - 2018-03-23 00:06:22 --> Helper loaded: url_helper
INFO - 2018-03-23 00:06:22 --> Helper loaded: form_helper
INFO - 2018-03-23 00:06:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:06:22 --> Form Validation Class Initialized
INFO - 2018-03-23 00:06:22 --> Model Class Initialized
INFO - 2018-03-23 00:06:22 --> Controller Class Initialized
INFO - 2018-03-23 00:06:22 --> Model Class Initialized
INFO - 2018-03-23 00:06:22 --> Model Class Initialized
INFO - 2018-03-23 00:06:22 --> Model Class Initialized
INFO - 2018-03-23 00:06:22 --> Model Class Initialized
DEBUG - 2018-03-23 00:06:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:06:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:06:22 --> Final output sent to browser
DEBUG - 2018-03-23 00:06:22 --> Total execution time: 0.1226
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:06:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:06:23 --> Config Class Initialized
INFO - 2018-03-23 00:06:23 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:06:23 --> Utf8 Class Initialized
INFO - 2018-03-23 00:06:23 --> URI Class Initialized
INFO - 2018-03-23 00:06:23 --> Router Class Initialized
INFO - 2018-03-23 00:06:23 --> Output Class Initialized
INFO - 2018-03-23 00:06:23 --> Security Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:06:23 --> Input Class Initialized
INFO - 2018-03-23 00:06:23 --> Language Class Initialized
INFO - 2018-03-23 00:06:23 --> Loader Class Initialized
INFO - 2018-03-23 00:06:23 --> Helper loaded: url_helper
INFO - 2018-03-23 00:06:23 --> Helper loaded: form_helper
INFO - 2018-03-23 00:06:23 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:06:23 --> Form Validation Class Initialized
INFO - 2018-03-23 00:06:23 --> Model Class Initialized
INFO - 2018-03-23 00:06:23 --> Controller Class Initialized
INFO - 2018-03-23 00:06:23 --> Model Class Initialized
INFO - 2018-03-23 00:06:23 --> Model Class Initialized
INFO - 2018-03-23 00:06:23 --> Model Class Initialized
INFO - 2018-03-23 00:06:23 --> Model Class Initialized
DEBUG - 2018-03-23 00:06:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
INFO - 2018-03-23 00:07:05 --> Loader Class Initialized
INFO - 2018-03-23 00:07:05 --> Helper loaded: url_helper
INFO - 2018-03-23 00:07:05 --> Helper loaded: form_helper
INFO - 2018-03-23 00:07:05 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:07:05 --> Form Validation Class Initialized
INFO - 2018-03-23 00:07:05 --> Model Class Initialized
INFO - 2018-03-23 00:07:05 --> Controller Class Initialized
INFO - 2018-03-23 00:07:05 --> Model Class Initialized
INFO - 2018-03-23 00:07:05 --> Model Class Initialized
INFO - 2018-03-23 00:07:05 --> Model Class Initialized
INFO - 2018-03-23 00:07:05 --> Model Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:07:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:07:05 --> Final output sent to browser
DEBUG - 2018-03-23 00:07:05 --> Total execution time: 0.1037
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
ERROR - 2018-03-23 00:07:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:07:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
ERROR - 2018-03-23 00:07:05 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
ERROR - 2018-03-23 00:07:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Config Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
INFO - 2018-03-23 00:07:05 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> URI Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Router Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Output Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
INFO - 2018-03-23 00:07:05 --> Security Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
DEBUG - 2018-03-23 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:05 --> Input Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
INFO - 2018-03-23 00:07:05 --> Language Class Initialized
ERROR - 2018-03-23 00:07:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:07:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:07:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:07:06 --> Config Class Initialized
INFO - 2018-03-23 00:07:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:07:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:07:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:07:06 --> URI Class Initialized
INFO - 2018-03-23 00:07:06 --> Router Class Initialized
INFO - 2018-03-23 00:07:06 --> Output Class Initialized
INFO - 2018-03-23 00:07:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:07:06 --> Input Class Initialized
INFO - 2018-03-23 00:07:06 --> Language Class Initialized
INFO - 2018-03-23 00:07:06 --> Loader Class Initialized
INFO - 2018-03-23 00:07:06 --> Helper loaded: url_helper
INFO - 2018-03-23 00:07:06 --> Helper loaded: form_helper
INFO - 2018-03-23 00:07:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:07:06 --> Form Validation Class Initialized
INFO - 2018-03-23 00:07:06 --> Model Class Initialized
INFO - 2018-03-23 00:07:06 --> Controller Class Initialized
INFO - 2018-03-23 00:07:06 --> Model Class Initialized
INFO - 2018-03-23 00:07:06 --> Model Class Initialized
INFO - 2018-03-23 00:07:06 --> Model Class Initialized
INFO - 2018-03-23 00:07:06 --> Model Class Initialized
DEBUG - 2018-03-23 00:07:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
INFO - 2018-03-23 00:08:25 --> Loader Class Initialized
INFO - 2018-03-23 00:08:25 --> Helper loaded: url_helper
INFO - 2018-03-23 00:08:25 --> Helper loaded: form_helper
INFO - 2018-03-23 00:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:08:25 --> Form Validation Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Controller Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:08:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:08:25 --> Final output sent to browser
DEBUG - 2018-03-23 00:08:25 --> Total execution time: 0.0656
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
ERROR - 2018-03-23 00:08:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:08:25 --> Config Class Initialized
INFO - 2018-03-23 00:08:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:25 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:25 --> URI Class Initialized
INFO - 2018-03-23 00:08:25 --> Router Class Initialized
INFO - 2018-03-23 00:08:25 --> Output Class Initialized
INFO - 2018-03-23 00:08:25 --> Security Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:25 --> Input Class Initialized
INFO - 2018-03-23 00:08:25 --> Language Class Initialized
INFO - 2018-03-23 00:08:25 --> Loader Class Initialized
INFO - 2018-03-23 00:08:25 --> Helper loaded: url_helper
INFO - 2018-03-23 00:08:25 --> Helper loaded: form_helper
INFO - 2018-03-23 00:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:08:25 --> Form Validation Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Controller Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
INFO - 2018-03-23 00:08:25 --> Model Class Initialized
DEBUG - 2018-03-23 00:08:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Loader Class Initialized
INFO - 2018-03-23 00:08:54 --> Helper loaded: url_helper
INFO - 2018-03-23 00:08:54 --> Helper loaded: form_helper
INFO - 2018-03-23 00:08:54 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:08:54 --> Form Validation Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Controller Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:08:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:08:54 --> Final output sent to browser
DEBUG - 2018-03-23 00:08:54 --> Total execution time: 0.1736
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
ERROR - 2018-03-23 00:08:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:08:54 --> Config Class Initialized
INFO - 2018-03-23 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:08:54 --> Utf8 Class Initialized
INFO - 2018-03-23 00:08:54 --> URI Class Initialized
INFO - 2018-03-23 00:08:54 --> Router Class Initialized
INFO - 2018-03-23 00:08:54 --> Output Class Initialized
INFO - 2018-03-23 00:08:54 --> Security Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:08:54 --> Input Class Initialized
INFO - 2018-03-23 00:08:54 --> Language Class Initialized
INFO - 2018-03-23 00:08:54 --> Loader Class Initialized
INFO - 2018-03-23 00:08:54 --> Helper loaded: url_helper
INFO - 2018-03-23 00:08:54 --> Helper loaded: form_helper
INFO - 2018-03-23 00:08:54 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:08:54 --> Form Validation Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Controller Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
INFO - 2018-03-23 00:08:54 --> Model Class Initialized
DEBUG - 2018-03-23 00:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:09:35 --> Config Class Initialized
INFO - 2018-03-23 00:09:35 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:35 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:35 --> URI Class Initialized
INFO - 2018-03-23 00:09:35 --> Router Class Initialized
INFO - 2018-03-23 00:09:35 --> Output Class Initialized
INFO - 2018-03-23 00:09:35 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:35 --> Input Class Initialized
INFO - 2018-03-23 00:09:35 --> Language Class Initialized
INFO - 2018-03-23 00:09:35 --> Loader Class Initialized
INFO - 2018-03-23 00:09:35 --> Helper loaded: url_helper
INFO - 2018-03-23 00:09:35 --> Helper loaded: form_helper
INFO - 2018-03-23 00:09:35 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:09:35 --> Form Validation Class Initialized
INFO - 2018-03-23 00:09:35 --> Model Class Initialized
INFO - 2018-03-23 00:09:35 --> Controller Class Initialized
INFO - 2018-03-23 00:09:35 --> Model Class Initialized
INFO - 2018-03-23 00:09:35 --> Model Class Initialized
INFO - 2018-03-23 00:09:35 --> Model Class Initialized
INFO - 2018-03-23 00:09:35 --> Model Class Initialized
DEBUG - 2018-03-23 00:09:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:09:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:09:35 --> Final output sent to browser
DEBUG - 2018-03-23 00:09:35 --> Total execution time: 0.1005
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
ERROR - 2018-03-23 00:09:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:09:36 --> Config Class Initialized
INFO - 2018-03-23 00:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:36 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:36 --> URI Class Initialized
INFO - 2018-03-23 00:09:36 --> Router Class Initialized
INFO - 2018-03-23 00:09:36 --> Output Class Initialized
INFO - 2018-03-23 00:09:36 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:36 --> Input Class Initialized
INFO - 2018-03-23 00:09:36 --> Language Class Initialized
INFO - 2018-03-23 00:09:36 --> Loader Class Initialized
INFO - 2018-03-23 00:09:36 --> Helper loaded: url_helper
INFO - 2018-03-23 00:09:36 --> Helper loaded: form_helper
INFO - 2018-03-23 00:09:36 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:09:36 --> Form Validation Class Initialized
INFO - 2018-03-23 00:09:36 --> Model Class Initialized
INFO - 2018-03-23 00:09:36 --> Controller Class Initialized
INFO - 2018-03-23 00:09:36 --> Model Class Initialized
INFO - 2018-03-23 00:09:36 --> Model Class Initialized
INFO - 2018-03-23 00:09:36 --> Model Class Initialized
INFO - 2018-03-23 00:09:36 --> Model Class Initialized
DEBUG - 2018-03-23 00:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
INFO - 2018-03-23 00:09:55 --> Loader Class Initialized
INFO - 2018-03-23 00:09:55 --> Helper loaded: url_helper
INFO - 2018-03-23 00:09:55 --> Helper loaded: form_helper
INFO - 2018-03-23 00:09:55 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:09:55 --> Form Validation Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Controller Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:09:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:09:55 --> Final output sent to browser
DEBUG - 2018-03-23 00:09:55 --> Total execution time: 0.1169
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
ERROR - 2018-03-23 00:09:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:09:55 --> Config Class Initialized
INFO - 2018-03-23 00:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:09:55 --> Utf8 Class Initialized
INFO - 2018-03-23 00:09:55 --> URI Class Initialized
INFO - 2018-03-23 00:09:55 --> Router Class Initialized
INFO - 2018-03-23 00:09:55 --> Output Class Initialized
INFO - 2018-03-23 00:09:55 --> Security Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:09:55 --> Input Class Initialized
INFO - 2018-03-23 00:09:55 --> Language Class Initialized
INFO - 2018-03-23 00:09:55 --> Loader Class Initialized
INFO - 2018-03-23 00:09:55 --> Helper loaded: url_helper
INFO - 2018-03-23 00:09:55 --> Helper loaded: form_helper
INFO - 2018-03-23 00:09:55 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:09:55 --> Form Validation Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Controller Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
INFO - 2018-03-23 00:09:55 --> Model Class Initialized
DEBUG - 2018-03-23 00:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Loader Class Initialized
INFO - 2018-03-23 00:12:17 --> Helper loaded: url_helper
INFO - 2018-03-23 00:12:17 --> Helper loaded: form_helper
INFO - 2018-03-23 00:12:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:12:17 --> Form Validation Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Controller Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:12:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:12:17 --> Final output sent to browser
DEBUG - 2018-03-23 00:12:17 --> Total execution time: 0.0641
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:12:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:12:17 --> Config Class Initialized
INFO - 2018-03-23 00:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:12:17 --> Utf8 Class Initialized
INFO - 2018-03-23 00:12:17 --> URI Class Initialized
INFO - 2018-03-23 00:12:17 --> Router Class Initialized
INFO - 2018-03-23 00:12:17 --> Output Class Initialized
INFO - 2018-03-23 00:12:17 --> Security Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:12:17 --> Input Class Initialized
INFO - 2018-03-23 00:12:17 --> Language Class Initialized
INFO - 2018-03-23 00:12:17 --> Loader Class Initialized
INFO - 2018-03-23 00:12:17 --> Helper loaded: url_helper
INFO - 2018-03-23 00:12:17 --> Helper loaded: form_helper
INFO - 2018-03-23 00:12:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:12:17 --> Form Validation Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Controller Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
INFO - 2018-03-23 00:12:17 --> Model Class Initialized
DEBUG - 2018-03-23 00:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:13:05 --> Config Class Initialized
INFO - 2018-03-23 00:13:05 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:13:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:05 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:05 --> URI Class Initialized
INFO - 2018-03-23 00:13:05 --> Router Class Initialized
INFO - 2018-03-23 00:13:05 --> Output Class Initialized
INFO - 2018-03-23 00:13:05 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:05 --> Input Class Initialized
INFO - 2018-03-23 00:13:05 --> Language Class Initialized
INFO - 2018-03-23 00:13:05 --> Loader Class Initialized
INFO - 2018-03-23 00:13:05 --> Helper loaded: url_helper
INFO - 2018-03-23 00:13:05 --> Helper loaded: form_helper
INFO - 2018-03-23 00:13:05 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:13:05 --> Form Validation Class Initialized
INFO - 2018-03-23 00:13:05 --> Model Class Initialized
INFO - 2018-03-23 00:13:05 --> Controller Class Initialized
INFO - 2018-03-23 00:13:05 --> Model Class Initialized
INFO - 2018-03-23 00:13:05 --> Model Class Initialized
INFO - 2018-03-23 00:13:05 --> Model Class Initialized
INFO - 2018-03-23 00:13:05 --> Model Class Initialized
DEBUG - 2018-03-23 00:13:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:13:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:13:05 --> Final output sent to browser
DEBUG - 2018-03-23 00:13:05 --> Total execution time: 0.0800
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:13:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:13:06 --> Config Class Initialized
INFO - 2018-03-23 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:13:06 --> Utf8 Class Initialized
INFO - 2018-03-23 00:13:06 --> URI Class Initialized
INFO - 2018-03-23 00:13:06 --> Router Class Initialized
INFO - 2018-03-23 00:13:06 --> Output Class Initialized
INFO - 2018-03-23 00:13:06 --> Security Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:13:06 --> Input Class Initialized
INFO - 2018-03-23 00:13:06 --> Language Class Initialized
INFO - 2018-03-23 00:13:06 --> Loader Class Initialized
INFO - 2018-03-23 00:13:06 --> Helper loaded: url_helper
INFO - 2018-03-23 00:13:06 --> Helper loaded: form_helper
INFO - 2018-03-23 00:13:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:13:06 --> Form Validation Class Initialized
INFO - 2018-03-23 00:13:06 --> Model Class Initialized
INFO - 2018-03-23 00:13:06 --> Controller Class Initialized
INFO - 2018-03-23 00:13:06 --> Model Class Initialized
INFO - 2018-03-23 00:13:06 --> Model Class Initialized
INFO - 2018-03-23 00:13:06 --> Model Class Initialized
INFO - 2018-03-23 00:13:06 --> Model Class Initialized
DEBUG - 2018-03-23 00:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
INFO - 2018-03-23 00:16:28 --> Loader Class Initialized
INFO - 2018-03-23 00:16:28 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:28 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:28 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:28 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Controller Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:16:28 --> Final output sent to browser
DEBUG - 2018-03-23 00:16:28 --> Total execution time: 0.1672
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:16:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:16:28 --> Config Class Initialized
INFO - 2018-03-23 00:16:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:28 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:28 --> URI Class Initialized
INFO - 2018-03-23 00:16:28 --> Router Class Initialized
INFO - 2018-03-23 00:16:28 --> Output Class Initialized
INFO - 2018-03-23 00:16:28 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:28 --> Input Class Initialized
INFO - 2018-03-23 00:16:28 --> Language Class Initialized
INFO - 2018-03-23 00:16:28 --> Loader Class Initialized
INFO - 2018-03-23 00:16:28 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:28 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:28 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:28 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Controller Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
INFO - 2018-03-23 00:16:28 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
INFO - 2018-03-23 00:16:40 --> Loader Class Initialized
INFO - 2018-03-23 00:16:40 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:40 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:40 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:40 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:40 --> Model Class Initialized
INFO - 2018-03-23 00:16:40 --> Controller Class Initialized
INFO - 2018-03-23 00:16:40 --> Model Class Initialized
INFO - 2018-03-23 00:16:40 --> Model Class Initialized
INFO - 2018-03-23 00:16:40 --> Model Class Initialized
INFO - 2018-03-23 00:16:40 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:16:40 --> Final output sent to browser
DEBUG - 2018-03-23 00:16:40 --> Total execution time: 0.0986
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:40 --> Config Class Initialized
INFO - 2018-03-23 00:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
DEBUG - 2018-03-23 00:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:40 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> URI Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Router Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Output Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
INFO - 2018-03-23 00:16:40 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Input Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
INFO - 2018-03-23 00:16:40 --> Language Class Initialized
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:16:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:16:41 --> Config Class Initialized
INFO - 2018-03-23 00:16:41 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:41 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:41 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:41 --> URI Class Initialized
INFO - 2018-03-23 00:16:41 --> Router Class Initialized
INFO - 2018-03-23 00:16:41 --> Output Class Initialized
INFO - 2018-03-23 00:16:41 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:41 --> Input Class Initialized
INFO - 2018-03-23 00:16:41 --> Language Class Initialized
INFO - 2018-03-23 00:16:41 --> Loader Class Initialized
INFO - 2018-03-23 00:16:41 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:41 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:41 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:41 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:41 --> Model Class Initialized
INFO - 2018-03-23 00:16:41 --> Controller Class Initialized
INFO - 2018-03-23 00:16:41 --> Model Class Initialized
INFO - 2018-03-23 00:16:41 --> Model Class Initialized
INFO - 2018-03-23 00:16:41 --> Model Class Initialized
INFO - 2018-03-23 00:16:41 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:46 --> Config Class Initialized
INFO - 2018-03-23 00:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:46 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:46 --> URI Class Initialized
INFO - 2018-03-23 00:16:46 --> Router Class Initialized
INFO - 2018-03-23 00:16:46 --> Output Class Initialized
INFO - 2018-03-23 00:16:46 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:46 --> Input Class Initialized
INFO - 2018-03-23 00:16:46 --> Language Class Initialized
INFO - 2018-03-23 00:16:46 --> Loader Class Initialized
INFO - 2018-03-23 00:16:46 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:46 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:46 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:46 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:46 --> Model Class Initialized
INFO - 2018-03-23 00:16:46 --> Controller Class Initialized
INFO - 2018-03-23 00:16:46 --> Model Class Initialized
INFO - 2018-03-23 00:16:46 --> Model Class Initialized
INFO - 2018-03-23 00:16:46 --> Model Class Initialized
INFO - 2018-03-23 00:16:46 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 00:16:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 00:16:46 --> Final output sent to browser
DEBUG - 2018-03-23 00:16:46 --> Total execution time: 0.1302
INFO - 2018-03-23 00:16:46 --> Config Class Initialized
INFO - 2018-03-23 00:16:46 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:46 --> Config Class Initialized
INFO - 2018-03-23 00:16:46 --> Config Class Initialized
INFO - 2018-03-23 00:16:46 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:46 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:46 --> URI Class Initialized
DEBUG - 2018-03-23 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:46 --> Config Class Initialized
INFO - 2018-03-23 00:16:46 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:46 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:46 --> Router Class Initialized
INFO - 2018-03-23 00:16:46 --> URI Class Initialized
INFO - 2018-03-23 00:16:46 --> URI Class Initialized
INFO - 2018-03-23 00:16:46 --> Output Class Initialized
DEBUG - 2018-03-23 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:46 --> Router Class Initialized
INFO - 2018-03-23 00:16:46 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:46 --> Router Class Initialized
INFO - 2018-03-23 00:16:46 --> Security Class Initialized
INFO - 2018-03-23 00:16:46 --> URI Class Initialized
INFO - 2018-03-23 00:16:46 --> Output Class Initialized
DEBUG - 2018-03-23 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:46 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Router Class Initialized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 00:16:47 --> Config Class Initialized
INFO - 2018-03-23 00:16:47 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:47 --> Config Class Initialized
INFO - 2018-03-23 00:16:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:47 --> Config Class Initialized
INFO - 2018-03-23 00:16:47 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:47 --> Hooks Class Initialized
INFO - 2018-03-23 00:16:47 --> URI Class Initialized
DEBUG - 2018-03-23 00:16:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:47 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:47 --> Router Class Initialized
DEBUG - 2018-03-23 00:16:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:47 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:47 --> URI Class Initialized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
INFO - 2018-03-23 00:16:47 --> URI Class Initialized
INFO - 2018-03-23 00:16:47 --> Router Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
INFO - 2018-03-23 00:16:47 --> Router Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 00:16:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 00:16:47 --> Config Class Initialized
INFO - 2018-03-23 00:16:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 00:16:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 00:16:47 --> Utf8 Class Initialized
INFO - 2018-03-23 00:16:47 --> URI Class Initialized
INFO - 2018-03-23 00:16:47 --> Router Class Initialized
INFO - 2018-03-23 00:16:47 --> Output Class Initialized
INFO - 2018-03-23 00:16:47 --> Security Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 00:16:47 --> Input Class Initialized
INFO - 2018-03-23 00:16:47 --> Language Class Initialized
INFO - 2018-03-23 00:16:47 --> Loader Class Initialized
INFO - 2018-03-23 00:16:47 --> Helper loaded: url_helper
INFO - 2018-03-23 00:16:47 --> Helper loaded: form_helper
INFO - 2018-03-23 00:16:47 --> Database Driver Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 00:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 00:16:47 --> Form Validation Class Initialized
INFO - 2018-03-23 00:16:47 --> Model Class Initialized
INFO - 2018-03-23 00:16:47 --> Controller Class Initialized
INFO - 2018-03-23 00:16:47 --> Model Class Initialized
INFO - 2018-03-23 00:16:47 --> Model Class Initialized
INFO - 2018-03-23 00:16:47 --> Model Class Initialized
INFO - 2018-03-23 00:16:47 --> Model Class Initialized
DEBUG - 2018-03-23 00:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
INFO - 2018-03-23 23:27:06 --> Loader Class Initialized
INFO - 2018-03-23 23:27:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
INFO - 2018-03-23 23:27:06 --> Controller Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
INFO - 2018-03-23 23:27:06 --> Loader Class Initialized
INFO - 2018-03-23 23:27:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
INFO - 2018-03-23 23:27:06 --> Controller Class Initialized
INFO - 2018-03-23 23:27:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:27:06 --> Final output sent to browser
DEBUG - 2018-03-23 23:27:06 --> Total execution time: 0.1076
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
INFO - 2018-03-23 23:27:06 --> Config Class Initialized
INFO - 2018-03-23 23:27:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
DEBUG - 2018-03-23 23:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
INFO - 2018-03-23 23:27:06 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Router Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
INFO - 2018-03-23 23:27:06 --> Output Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:06 --> Input Class Initialized
INFO - 2018-03-23 23:27:06 --> Language Class Initialized
ERROR - 2018-03-23 23:27:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:08 --> Config Class Initialized
INFO - 2018-03-23 23:27:08 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:08 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:08 --> URI Class Initialized
INFO - 2018-03-23 23:27:08 --> Router Class Initialized
INFO - 2018-03-23 23:27:08 --> Output Class Initialized
INFO - 2018-03-23 23:27:08 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:08 --> Input Class Initialized
INFO - 2018-03-23 23:27:08 --> Language Class Initialized
INFO - 2018-03-23 23:27:08 --> Loader Class Initialized
INFO - 2018-03-23 23:27:08 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:08 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:08 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:08 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:08 --> Model Class Initialized
INFO - 2018-03-23 23:27:08 --> Controller Class Initialized
INFO - 2018-03-23 23:27:08 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:09 --> No URI present. Default controller set.
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
INFO - 2018-03-23 23:27:09 --> Loader Class Initialized
INFO - 2018-03-23 23:27:09 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:09 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:09 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:09 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Controller Class Initialized
INFO - 2018-03-23 23:27:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:27:09 --> Final output sent to browser
DEBUG - 2018-03-23 23:27:09 --> Total execution time: 0.0895
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
ERROR - 2018-03-23 23:27:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:09 --> Config Class Initialized
INFO - 2018-03-23 23:27:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:09 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:09 --> URI Class Initialized
INFO - 2018-03-23 23:27:09 --> Router Class Initialized
INFO - 2018-03-23 23:27:09 --> Output Class Initialized
INFO - 2018-03-23 23:27:09 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:09 --> Input Class Initialized
INFO - 2018-03-23 23:27:09 --> Language Class Initialized
INFO - 2018-03-23 23:27:09 --> Loader Class Initialized
INFO - 2018-03-23 23:27:09 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:09 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:09 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:09 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Controller Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
INFO - 2018-03-23 23:27:09 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:10 --> Config Class Initialized
INFO - 2018-03-23 23:27:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:10 --> URI Class Initialized
INFO - 2018-03-23 23:27:10 --> Router Class Initialized
INFO - 2018-03-23 23:27:10 --> Output Class Initialized
INFO - 2018-03-23 23:27:10 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:10 --> Input Class Initialized
INFO - 2018-03-23 23:27:10 --> Language Class Initialized
INFO - 2018-03-23 23:27:10 --> Loader Class Initialized
INFO - 2018-03-23 23:27:11 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:11 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:11 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:11 --> Model Class Initialized
INFO - 2018-03-23 23:27:11 --> Controller Class Initialized
INFO - 2018-03-23 23:27:11 --> Model Class Initialized
INFO - 2018-03-23 23:27:11 --> Model Class Initialized
INFO - 2018-03-23 23:27:11 --> Model Class Initialized
INFO - 2018-03-23 23:27:11 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:27:11 --> Final output sent to browser
DEBUG - 2018-03-23 23:27:11 --> Total execution time: 0.0509
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:11 --> Config Class Initialized
INFO - 2018-03-23 23:27:11 --> Hooks Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 23:27:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:11 --> URI Class Initialized
INFO - 2018-03-23 23:27:11 --> Router Class Initialized
INFO - 2018-03-23 23:27:11 --> Output Class Initialized
INFO - 2018-03-23 23:27:11 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:11 --> Input Class Initialized
INFO - 2018-03-23 23:27:11 --> Language Class Initialized
ERROR - 2018-03-23 23:27:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:12 --> Config Class Initialized
INFO - 2018-03-23 23:27:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:12 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:12 --> URI Class Initialized
INFO - 2018-03-23 23:27:12 --> Router Class Initialized
INFO - 2018-03-23 23:27:12 --> Output Class Initialized
INFO - 2018-03-23 23:27:12 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:12 --> Input Class Initialized
INFO - 2018-03-23 23:27:12 --> Language Class Initialized
INFO - 2018-03-23 23:27:12 --> Loader Class Initialized
INFO - 2018-03-23 23:27:12 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:12 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:12 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:12 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:12 --> Model Class Initialized
INFO - 2018-03-23 23:27:12 --> Controller Class Initialized
INFO - 2018-03-23 23:27:12 --> Model Class Initialized
INFO - 2018-03-23 23:27:12 --> Model Class Initialized
INFO - 2018-03-23 23:27:12 --> Model Class Initialized
INFO - 2018-03-23 23:27:12 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:27:12 --> Final output sent to browser
DEBUG - 2018-03-23 23:27:12 --> Total execution time: 0.0546
INFO - 2018-03-23 23:27:12 --> Config Class Initialized
INFO - 2018-03-23 23:27:12 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:12 --> Config Class Initialized
INFO - 2018-03-23 23:27:12 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:12 --> Config Class Initialized
INFO - 2018-03-23 23:27:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Config Class Initialized
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:13 --> Config Class Initialized
INFO - 2018-03-23 23:27:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:13 --> Config Class Initialized
INFO - 2018-03-23 23:27:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:13 --> Config Class Initialized
INFO - 2018-03-23 23:27:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
ERROR - 2018-03-23 23:27:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:13 --> Config Class Initialized
INFO - 2018-03-23 23:27:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:13 --> URI Class Initialized
INFO - 2018-03-23 23:27:13 --> Router Class Initialized
INFO - 2018-03-23 23:27:13 --> Output Class Initialized
INFO - 2018-03-23 23:27:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:13 --> Input Class Initialized
INFO - 2018-03-23 23:27:13 --> Language Class Initialized
INFO - 2018-03-23 23:27:13 --> Loader Class Initialized
INFO - 2018-03-23 23:27:13 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:13 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:13 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
INFO - 2018-03-23 23:27:13 --> Controller Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
INFO - 2018-03-23 23:27:13 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
INFO - 2018-03-23 23:27:16 --> Loader Class Initialized
INFO - 2018-03-23 23:27:16 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:16 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:16 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:16 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Controller Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:27:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:27:16 --> Final output sent to browser
DEBUG - 2018-03-23 23:27:16 --> Total execution time: 0.0635
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:27:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:27:16 --> Config Class Initialized
INFO - 2018-03-23 23:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-23 23:27:16 --> URI Class Initialized
INFO - 2018-03-23 23:27:16 --> Router Class Initialized
INFO - 2018-03-23 23:27:16 --> Output Class Initialized
INFO - 2018-03-23 23:27:16 --> Security Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:27:16 --> Input Class Initialized
INFO - 2018-03-23 23:27:16 --> Language Class Initialized
INFO - 2018-03-23 23:27:16 --> Loader Class Initialized
INFO - 2018-03-23 23:27:16 --> Helper loaded: url_helper
INFO - 2018-03-23 23:27:16 --> Helper loaded: form_helper
INFO - 2018-03-23 23:27:16 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:27:16 --> Form Validation Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Controller Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
INFO - 2018-03-23 23:27:16 --> Model Class Initialized
DEBUG - 2018-03-23 23:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:32:41 --> Config Class Initialized
INFO - 2018-03-23 23:32:41 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:41 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:41 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:41 --> URI Class Initialized
INFO - 2018-03-23 23:32:41 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Loader Class Initialized
INFO - 2018-03-23 23:32:42 --> Helper loaded: url_helper
INFO - 2018-03-23 23:32:42 --> Helper loaded: form_helper
INFO - 2018-03-23 23:32:42 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:32:42 --> Form Validation Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Controller Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:32:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:32:42 --> Final output sent to browser
DEBUG - 2018-03-23 23:32:42 --> Total execution time: 0.1231
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
ERROR - 2018-03-23 23:32:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:32:42 --> Config Class Initialized
INFO - 2018-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:42 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:42 --> URI Class Initialized
INFO - 2018-03-23 23:32:42 --> Router Class Initialized
INFO - 2018-03-23 23:32:42 --> Output Class Initialized
INFO - 2018-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:42 --> Input Class Initialized
INFO - 2018-03-23 23:32:42 --> Language Class Initialized
INFO - 2018-03-23 23:32:42 --> Loader Class Initialized
INFO - 2018-03-23 23:32:42 --> Helper loaded: url_helper
INFO - 2018-03-23 23:32:42 --> Helper loaded: form_helper
INFO - 2018-03-23 23:32:42 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:32:42 --> Form Validation Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Controller Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
INFO - 2018-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2018-03-23 23:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
INFO - 2018-03-23 23:32:54 --> Loader Class Initialized
INFO - 2018-03-23 23:32:54 --> Helper loaded: url_helper
INFO - 2018-03-23 23:32:54 --> Helper loaded: form_helper
INFO - 2018-03-23 23:32:54 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:32:54 --> Form Validation Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Controller Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:32:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:32:54 --> Final output sent to browser
DEBUG - 2018-03-23 23:32:54 --> Total execution time: 0.0934
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
ERROR - 2018-03-23 23:32:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:32:54 --> Config Class Initialized
INFO - 2018-03-23 23:32:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:32:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:32:54 --> Utf8 Class Initialized
INFO - 2018-03-23 23:32:54 --> URI Class Initialized
INFO - 2018-03-23 23:32:54 --> Router Class Initialized
INFO - 2018-03-23 23:32:54 --> Output Class Initialized
INFO - 2018-03-23 23:32:54 --> Security Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:32:54 --> Input Class Initialized
INFO - 2018-03-23 23:32:54 --> Language Class Initialized
INFO - 2018-03-23 23:32:54 --> Loader Class Initialized
INFO - 2018-03-23 23:32:54 --> Helper loaded: url_helper
INFO - 2018-03-23 23:32:54 --> Helper loaded: form_helper
INFO - 2018-03-23 23:32:54 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:32:54 --> Form Validation Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Controller Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
INFO - 2018-03-23 23:32:54 --> Model Class Initialized
DEBUG - 2018-03-23 23:32:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:35:53 --> Config Class Initialized
INFO - 2018-03-23 23:35:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:35:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:35:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:35:53 --> URI Class Initialized
INFO - 2018-03-23 23:35:53 --> Router Class Initialized
INFO - 2018-03-23 23:35:53 --> Output Class Initialized
INFO - 2018-03-23 23:35:53 --> Security Class Initialized
DEBUG - 2018-03-23 23:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:35:53 --> Input Class Initialized
INFO - 2018-03-23 23:35:53 --> Language Class Initialized
INFO - 2018-03-23 23:35:53 --> Loader Class Initialized
INFO - 2018-03-23 23:35:53 --> Helper loaded: url_helper
INFO - 2018-03-23 23:35:53 --> Helper loaded: form_helper
INFO - 2018-03-23 23:35:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:35:53 --> Form Validation Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
INFO - 2018-03-23 23:35:53 --> Controller Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
INFO - 2018-03-23 23:35:53 --> Model Class Initialized
DEBUG - 2018-03-23 23:35:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:35:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:35:54 --> Final output sent to browser
DEBUG - 2018-03-23 23:35:54 --> Total execution time: 0.3148
INFO - 2018-03-23 23:35:55 --> Config Class Initialized
INFO - 2018-03-23 23:35:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:35:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:35:55 --> Utf8 Class Initialized
INFO - 2018-03-23 23:35:55 --> URI Class Initialized
INFO - 2018-03-23 23:35:55 --> Router Class Initialized
INFO - 2018-03-23 23:35:55 --> Output Class Initialized
INFO - 2018-03-23 23:35:55 --> Security Class Initialized
DEBUG - 2018-03-23 23:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:35:55 --> Input Class Initialized
INFO - 2018-03-23 23:35:55 --> Language Class Initialized
INFO - 2018-03-23 23:35:55 --> Loader Class Initialized
INFO - 2018-03-23 23:35:55 --> Helper loaded: url_helper
INFO - 2018-03-23 23:35:55 --> Helper loaded: form_helper
INFO - 2018-03-23 23:35:55 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:35:55 --> Form Validation Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
INFO - 2018-03-23 23:35:55 --> Controller Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
INFO - 2018-03-23 23:35:55 --> Model Class Initialized
DEBUG - 2018-03-23 23:35:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:35:57 --> Config Class Initialized
INFO - 2018-03-23 23:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:35:57 --> Utf8 Class Initialized
INFO - 2018-03-23 23:35:57 --> URI Class Initialized
INFO - 2018-03-23 23:35:57 --> Router Class Initialized
INFO - 2018-03-23 23:35:57 --> Output Class Initialized
INFO - 2018-03-23 23:35:57 --> Security Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:35:57 --> Input Class Initialized
INFO - 2018-03-23 23:35:57 --> Language Class Initialized
INFO - 2018-03-23 23:35:57 --> Loader Class Initialized
INFO - 2018-03-23 23:35:57 --> Helper loaded: url_helper
INFO - 2018-03-23 23:35:57 --> Helper loaded: form_helper
INFO - 2018-03-23 23:35:57 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:35:57 --> Form Validation Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Controller Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:35:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:35:57 --> Final output sent to browser
DEBUG - 2018-03-23 23:35:57 --> Total execution time: 0.1389
INFO - 2018-03-23 23:35:57 --> Config Class Initialized
INFO - 2018-03-23 23:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:35:57 --> Utf8 Class Initialized
INFO - 2018-03-23 23:35:57 --> URI Class Initialized
INFO - 2018-03-23 23:35:57 --> Router Class Initialized
INFO - 2018-03-23 23:35:57 --> Output Class Initialized
INFO - 2018-03-23 23:35:57 --> Security Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:35:57 --> Input Class Initialized
INFO - 2018-03-23 23:35:57 --> Language Class Initialized
INFO - 2018-03-23 23:35:57 --> Loader Class Initialized
INFO - 2018-03-23 23:35:57 --> Helper loaded: url_helper
INFO - 2018-03-23 23:35:57 --> Helper loaded: form_helper
INFO - 2018-03-23 23:35:57 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:35:57 --> Form Validation Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Controller Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
INFO - 2018-03-23 23:35:57 --> Model Class Initialized
DEBUG - 2018-03-23 23:35:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:36:06 --> Config Class Initialized
INFO - 2018-03-23 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:36:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:36:06 --> URI Class Initialized
INFO - 2018-03-23 23:36:06 --> Router Class Initialized
INFO - 2018-03-23 23:36:06 --> Output Class Initialized
INFO - 2018-03-23 23:36:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:36:06 --> Input Class Initialized
INFO - 2018-03-23 23:36:06 --> Language Class Initialized
INFO - 2018-03-23 23:36:06 --> Loader Class Initialized
INFO - 2018-03-23 23:36:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:36:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:36:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:36:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Controller Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:36:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:36:06 --> Final output sent to browser
DEBUG - 2018-03-23 23:36:06 --> Total execution time: 0.1000
INFO - 2018-03-23 23:36:06 --> Config Class Initialized
INFO - 2018-03-23 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:36:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:36:06 --> URI Class Initialized
INFO - 2018-03-23 23:36:06 --> Router Class Initialized
INFO - 2018-03-23 23:36:06 --> Output Class Initialized
INFO - 2018-03-23 23:36:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:36:06 --> Input Class Initialized
INFO - 2018-03-23 23:36:06 --> Language Class Initialized
INFO - 2018-03-23 23:36:06 --> Loader Class Initialized
INFO - 2018-03-23 23:36:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:36:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:36:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:36:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Controller Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
INFO - 2018-03-23 23:36:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:36:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:36:11 --> Config Class Initialized
INFO - 2018-03-23 23:36:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:36:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:36:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:36:11 --> URI Class Initialized
INFO - 2018-03-23 23:36:11 --> Router Class Initialized
INFO - 2018-03-23 23:36:12 --> Output Class Initialized
INFO - 2018-03-23 23:36:12 --> Security Class Initialized
DEBUG - 2018-03-23 23:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:36:12 --> Input Class Initialized
INFO - 2018-03-23 23:36:12 --> Language Class Initialized
INFO - 2018-03-23 23:36:12 --> Loader Class Initialized
INFO - 2018-03-23 23:36:12 --> Helper loaded: url_helper
INFO - 2018-03-23 23:36:12 --> Helper loaded: form_helper
INFO - 2018-03-23 23:36:12 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:36:12 --> Form Validation Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
INFO - 2018-03-23 23:36:12 --> Controller Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
INFO - 2018-03-23 23:36:12 --> Model Class Initialized
DEBUG - 2018-03-23 23:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
INFO - 2018-03-23 23:38:47 --> Loader Class Initialized
INFO - 2018-03-23 23:38:47 --> Helper loaded: url_helper
INFO - 2018-03-23 23:38:47 --> Helper loaded: form_helper
INFO - 2018-03-23 23:38:47 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:38:47 --> Form Validation Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Controller Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:38:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:38:47 --> Final output sent to browser
DEBUG - 2018-03-23 23:38:47 --> Total execution time: 0.1191
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:38:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:38:47 --> Config Class Initialized
INFO - 2018-03-23 23:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:38:47 --> Utf8 Class Initialized
INFO - 2018-03-23 23:38:47 --> URI Class Initialized
INFO - 2018-03-23 23:38:47 --> Router Class Initialized
INFO - 2018-03-23 23:38:47 --> Output Class Initialized
INFO - 2018-03-23 23:38:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:38:47 --> Input Class Initialized
INFO - 2018-03-23 23:38:47 --> Language Class Initialized
INFO - 2018-03-23 23:38:47 --> Loader Class Initialized
INFO - 2018-03-23 23:38:47 --> Helper loaded: url_helper
INFO - 2018-03-23 23:38:47 --> Helper loaded: form_helper
INFO - 2018-03-23 23:38:47 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:38:47 --> Form Validation Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Controller Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
INFO - 2018-03-23 23:38:47 --> Model Class Initialized
DEBUG - 2018-03-23 23:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
INFO - 2018-03-23 23:39:11 --> Loader Class Initialized
INFO - 2018-03-23 23:39:11 --> Helper loaded: url_helper
INFO - 2018-03-23 23:39:11 --> Helper loaded: form_helper
INFO - 2018-03-23 23:39:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:39:11 --> Form Validation Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Controller Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:39:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:39:11 --> Final output sent to browser
DEBUG - 2018-03-23 23:39:11 --> Total execution time: 0.0748
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:39:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:39:11 --> Config Class Initialized
INFO - 2018-03-23 23:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:11 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:11 --> URI Class Initialized
INFO - 2018-03-23 23:39:11 --> Router Class Initialized
INFO - 2018-03-23 23:39:11 --> Output Class Initialized
INFO - 2018-03-23 23:39:11 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:11 --> Input Class Initialized
INFO - 2018-03-23 23:39:11 --> Language Class Initialized
INFO - 2018-03-23 23:39:11 --> Loader Class Initialized
INFO - 2018-03-23 23:39:11 --> Helper loaded: url_helper
INFO - 2018-03-23 23:39:11 --> Helper loaded: form_helper
INFO - 2018-03-23 23:39:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:39:11 --> Form Validation Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Controller Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
INFO - 2018-03-23 23:39:11 --> Model Class Initialized
DEBUG - 2018-03-23 23:39:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
ERROR - 2018-03-23 23:39:11 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1686
INFO - 2018-03-23 23:39:27 --> Config Class Initialized
INFO - 2018-03-23 23:39:27 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:27 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:27 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:27 --> URI Class Initialized
INFO - 2018-03-23 23:39:27 --> Router Class Initialized
INFO - 2018-03-23 23:39:27 --> Output Class Initialized
INFO - 2018-03-23 23:39:27 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:27 --> Input Class Initialized
INFO - 2018-03-23 23:39:27 --> Language Class Initialized
INFO - 2018-03-23 23:39:27 --> Loader Class Initialized
INFO - 2018-03-23 23:39:27 --> Helper loaded: url_helper
INFO - 2018-03-23 23:39:27 --> Helper loaded: form_helper
INFO - 2018-03-23 23:39:27 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:39:27 --> Form Validation Class Initialized
INFO - 2018-03-23 23:39:27 --> Model Class Initialized
INFO - 2018-03-23 23:39:27 --> Controller Class Initialized
INFO - 2018-03-23 23:39:27 --> Model Class Initialized
INFO - 2018-03-23 23:39:27 --> Model Class Initialized
INFO - 2018-03-23 23:39:27 --> Model Class Initialized
INFO - 2018-03-23 23:39:27 --> Model Class Initialized
DEBUG - 2018-03-23 23:39:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:39:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:39:27 --> Final output sent to browser
DEBUG - 2018-03-23 23:39:27 --> Total execution time: 0.1726
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
ERROR - 2018-03-23 23:39:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:39:28 --> Config Class Initialized
INFO - 2018-03-23 23:39:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 23:39:28 --> URI Class Initialized
INFO - 2018-03-23 23:39:28 --> Router Class Initialized
INFO - 2018-03-23 23:39:28 --> Output Class Initialized
INFO - 2018-03-23 23:39:28 --> Security Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:39:28 --> Input Class Initialized
INFO - 2018-03-23 23:39:28 --> Language Class Initialized
INFO - 2018-03-23 23:39:28 --> Loader Class Initialized
INFO - 2018-03-23 23:39:28 --> Helper loaded: url_helper
INFO - 2018-03-23 23:39:28 --> Helper loaded: form_helper
INFO - 2018-03-23 23:39:28 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:39:28 --> Form Validation Class Initialized
INFO - 2018-03-23 23:39:28 --> Model Class Initialized
INFO - 2018-03-23 23:39:28 --> Controller Class Initialized
INFO - 2018-03-23 23:39:28 --> Model Class Initialized
INFO - 2018-03-23 23:39:28 --> Model Class Initialized
INFO - 2018-03-23 23:39:28 --> Model Class Initialized
INFO - 2018-03-23 23:39:28 --> Model Class Initialized
DEBUG - 2018-03-23 23:39:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
ERROR - 2018-03-23 23:39:28 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1687
INFO - 2018-03-23 23:40:12 --> Config Class Initialized
INFO - 2018-03-23 23:40:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:12 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:12 --> URI Class Initialized
INFO - 2018-03-23 23:40:12 --> Router Class Initialized
INFO - 2018-03-23 23:40:12 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Loader Class Initialized
INFO - 2018-03-23 23:40:13 --> Helper loaded: url_helper
INFO - 2018-03-23 23:40:13 --> Helper loaded: form_helper
INFO - 2018-03-23 23:40:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:40:13 --> Form Validation Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Controller Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:40:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:40:13 --> Final output sent to browser
DEBUG - 2018-03-23 23:40:13 --> Total execution time: 0.1742
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
ERROR - 2018-03-23 23:40:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:40:13 --> Config Class Initialized
INFO - 2018-03-23 23:40:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:13 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:13 --> URI Class Initialized
INFO - 2018-03-23 23:40:13 --> Router Class Initialized
INFO - 2018-03-23 23:40:13 --> Output Class Initialized
INFO - 2018-03-23 23:40:13 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:13 --> Input Class Initialized
INFO - 2018-03-23 23:40:13 --> Language Class Initialized
INFO - 2018-03-23 23:40:13 --> Loader Class Initialized
INFO - 2018-03-23 23:40:13 --> Helper loaded: url_helper
INFO - 2018-03-23 23:40:13 --> Helper loaded: form_helper
INFO - 2018-03-23 23:40:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:40:13 --> Form Validation Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Controller Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
INFO - 2018-03-23 23:40:13 --> Model Class Initialized
DEBUG - 2018-03-23 23:40:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Loader Class Initialized
INFO - 2018-03-23 23:40:37 --> Helper loaded: url_helper
INFO - 2018-03-23 23:40:37 --> Helper loaded: form_helper
INFO - 2018-03-23 23:40:37 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:40:37 --> Form Validation Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Controller Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:40:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:40:37 --> Final output sent to browser
DEBUG - 2018-03-23 23:40:37 --> Total execution time: 0.1144
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:40:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:40:37 --> Config Class Initialized
INFO - 2018-03-23 23:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:40:37 --> Utf8 Class Initialized
INFO - 2018-03-23 23:40:37 --> URI Class Initialized
INFO - 2018-03-23 23:40:37 --> Router Class Initialized
INFO - 2018-03-23 23:40:37 --> Output Class Initialized
INFO - 2018-03-23 23:40:37 --> Security Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:40:37 --> Input Class Initialized
INFO - 2018-03-23 23:40:37 --> Language Class Initialized
INFO - 2018-03-23 23:40:37 --> Loader Class Initialized
INFO - 2018-03-23 23:40:37 --> Helper loaded: url_helper
INFO - 2018-03-23 23:40:37 --> Helper loaded: form_helper
INFO - 2018-03-23 23:40:37 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:40:37 --> Form Validation Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Controller Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
INFO - 2018-03-23 23:40:37 --> Model Class Initialized
DEBUG - 2018-03-23 23:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:53:34 --> Config Class Initialized
INFO - 2018-03-23 23:53:34 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:53:34 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:34 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:34 --> URI Class Initialized
INFO - 2018-03-23 23:53:34 --> Router Class Initialized
INFO - 2018-03-23 23:53:34 --> Output Class Initialized
INFO - 2018-03-23 23:53:34 --> Security Class Initialized
DEBUG - 2018-03-23 23:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:34 --> Input Class Initialized
INFO - 2018-03-23 23:53:34 --> Language Class Initialized
INFO - 2018-03-23 23:53:34 --> Loader Class Initialized
INFO - 2018-03-23 23:53:34 --> Helper loaded: url_helper
INFO - 2018-03-23 23:53:34 --> Helper loaded: form_helper
INFO - 2018-03-23 23:53:34 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:53:34 --> Form Validation Class Initialized
INFO - 2018-03-23 23:53:34 --> Model Class Initialized
INFO - 2018-03-23 23:53:34 --> Controller Class Initialized
INFO - 2018-03-23 23:53:34 --> Model Class Initialized
INFO - 2018-03-23 23:53:34 --> Model Class Initialized
INFO - 2018-03-23 23:53:34 --> Model Class Initialized
INFO - 2018-03-23 23:53:34 --> Model Class Initialized
DEBUG - 2018-03-23 23:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:53:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:53:34 --> Final output sent to browser
DEBUG - 2018-03-23 23:53:34 --> Total execution time: 0.1136
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
ERROR - 2018-03-23 23:53:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:53:35 --> Config Class Initialized
INFO - 2018-03-23 23:53:35 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:53:35 --> Utf8 Class Initialized
INFO - 2018-03-23 23:53:35 --> URI Class Initialized
INFO - 2018-03-23 23:53:35 --> Router Class Initialized
INFO - 2018-03-23 23:53:35 --> Output Class Initialized
INFO - 2018-03-23 23:53:35 --> Security Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:53:35 --> Input Class Initialized
INFO - 2018-03-23 23:53:35 --> Language Class Initialized
INFO - 2018-03-23 23:53:35 --> Loader Class Initialized
INFO - 2018-03-23 23:53:35 --> Helper loaded: url_helper
INFO - 2018-03-23 23:53:35 --> Helper loaded: form_helper
INFO - 2018-03-23 23:53:35 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:53:35 --> Form Validation Class Initialized
INFO - 2018-03-23 23:53:35 --> Model Class Initialized
INFO - 2018-03-23 23:53:35 --> Controller Class Initialized
INFO - 2018-03-23 23:53:35 --> Model Class Initialized
INFO - 2018-03-23 23:53:35 --> Model Class Initialized
INFO - 2018-03-23 23:53:35 --> Model Class Initialized
INFO - 2018-03-23 23:53:35 --> Model Class Initialized
DEBUG - 2018-03-23 23:53:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:54:33 --> Config Class Initialized
INFO - 2018-03-23 23:54:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:33 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:33 --> URI Class Initialized
INFO - 2018-03-23 23:54:33 --> Router Class Initialized
INFO - 2018-03-23 23:54:33 --> Output Class Initialized
INFO - 2018-03-23 23:54:33 --> Security Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:33 --> Input Class Initialized
INFO - 2018-03-23 23:54:33 --> Language Class Initialized
INFO - 2018-03-23 23:54:33 --> Loader Class Initialized
INFO - 2018-03-23 23:54:33 --> Helper loaded: url_helper
INFO - 2018-03-23 23:54:33 --> Helper loaded: form_helper
INFO - 2018-03-23 23:54:33 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:54:33 --> Form Validation Class Initialized
INFO - 2018-03-23 23:54:33 --> Model Class Initialized
INFO - 2018-03-23 23:54:33 --> Controller Class Initialized
INFO - 2018-03-23 23:54:33 --> Model Class Initialized
INFO - 2018-03-23 23:54:33 --> Model Class Initialized
INFO - 2018-03-23 23:54:33 --> Model Class Initialized
INFO - 2018-03-23 23:54:33 --> Model Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:54:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:54:33 --> Final output sent to browser
DEBUG - 2018-03-23 23:54:33 --> Total execution time: 0.1649
INFO - 2018-03-23 23:54:33 --> Config Class Initialized
INFO - 2018-03-23 23:54:33 --> Hooks Class Initialized
INFO - 2018-03-23 23:54:33 --> Config Class Initialized
INFO - 2018-03-23 23:54:33 --> Hooks Class Initialized
INFO - 2018-03-23 23:54:33 --> Config Class Initialized
INFO - 2018-03-23 23:54:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:33 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:33 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:33 --> Config Class Initialized
INFO - 2018-03-23 23:54:33 --> URI Class Initialized
DEBUG - 2018-03-23 23:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:33 --> Hooks Class Initialized
INFO - 2018-03-23 23:54:33 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:33 --> URI Class Initialized
INFO - 2018-03-23 23:54:33 --> Router Class Initialized
INFO - 2018-03-23 23:54:33 --> URI Class Initialized
DEBUG - 2018-03-23 23:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:33 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:33 --> Router Class Initialized
INFO - 2018-03-23 23:54:33 --> Output Class Initialized
INFO - 2018-03-23 23:54:33 --> Router Class Initialized
INFO - 2018-03-23 23:54:33 --> URI Class Initialized
INFO - 2018-03-23 23:54:33 --> Output Class Initialized
INFO - 2018-03-23 23:54:33 --> Security Class Initialized
INFO - 2018-03-23 23:54:33 --> Output Class Initialized
INFO - 2018-03-23 23:54:33 --> Security Class Initialized
INFO - 2018-03-23 23:54:33 --> Router Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:33 --> Input Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:33 --> Security Class Initialized
INFO - 2018-03-23 23:54:33 --> Language Class Initialized
INFO - 2018-03-23 23:54:33 --> Input Class Initialized
INFO - 2018-03-23 23:54:33 --> Output Class Initialized
INFO - 2018-03-23 23:54:33 --> Language Class Initialized
ERROR - 2018-03-23 23:54:33 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:33 --> Input Class Initialized
INFO - 2018-03-23 23:54:33 --> Security Class Initialized
ERROR - 2018-03-23 23:54:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:54:33 --> Language Class Initialized
DEBUG - 2018-03-23 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:33 --> Input Class Initialized
ERROR - 2018-03-23 23:54:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:54:33 --> Language Class Initialized
ERROR - 2018-03-23 23:54:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:54:34 --> Config Class Initialized
INFO - 2018-03-23 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-23 23:54:34 --> Config Class Initialized
INFO - 2018-03-23 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-23 23:54:34 --> Config Class Initialized
INFO - 2018-03-23 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:54:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:34 --> URI Class Initialized
INFO - 2018-03-23 23:54:34 --> URI Class Initialized
DEBUG - 2018-03-23 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:34 --> Router Class Initialized
INFO - 2018-03-23 23:54:34 --> Router Class Initialized
INFO - 2018-03-23 23:54:34 --> URI Class Initialized
INFO - 2018-03-23 23:54:34 --> Output Class Initialized
INFO - 2018-03-23 23:54:34 --> Output Class Initialized
INFO - 2018-03-23 23:54:34 --> Router Class Initialized
INFO - 2018-03-23 23:54:34 --> Security Class Initialized
INFO - 2018-03-23 23:54:34 --> Security Class Initialized
INFO - 2018-03-23 23:54:34 --> Output Class Initialized
DEBUG - 2018-03-23 23:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:34 --> Input Class Initialized
INFO - 2018-03-23 23:54:34 --> Input Class Initialized
INFO - 2018-03-23 23:54:34 --> Security Class Initialized
INFO - 2018-03-23 23:54:34 --> Language Class Initialized
INFO - 2018-03-23 23:54:34 --> Language Class Initialized
DEBUG - 2018-03-23 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:34 --> Input Class Initialized
ERROR - 2018-03-23 23:54:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:54:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:54:34 --> Language Class Initialized
ERROR - 2018-03-23 23:54:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:54:34 --> Config Class Initialized
INFO - 2018-03-23 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-23 23:54:34 --> URI Class Initialized
INFO - 2018-03-23 23:54:34 --> Router Class Initialized
INFO - 2018-03-23 23:54:34 --> Output Class Initialized
INFO - 2018-03-23 23:54:34 --> Security Class Initialized
DEBUG - 2018-03-23 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:54:34 --> Input Class Initialized
INFO - 2018-03-23 23:54:34 --> Language Class Initialized
INFO - 2018-03-23 23:54:34 --> Loader Class Initialized
INFO - 2018-03-23 23:54:34 --> Helper loaded: url_helper
INFO - 2018-03-23 23:54:34 --> Helper loaded: form_helper
INFO - 2018-03-23 23:54:34 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:54:34 --> Form Validation Class Initialized
INFO - 2018-03-23 23:54:34 --> Model Class Initialized
INFO - 2018-03-23 23:54:34 --> Controller Class Initialized
INFO - 2018-03-23 23:54:34 --> Model Class Initialized
INFO - 2018-03-23 23:54:34 --> Model Class Initialized
INFO - 2018-03-23 23:54:34 --> Model Class Initialized
INFO - 2018-03-23 23:54:34 --> Model Class Initialized
DEBUG - 2018-03-23 23:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
INFO - 2018-03-23 23:56:10 --> Loader Class Initialized
INFO - 2018-03-23 23:56:10 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:10 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:10 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:10 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Controller Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:56:10 --> Final output sent to browser
DEBUG - 2018-03-23 23:56:10 --> Total execution time: 0.0868
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:56:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:10 --> Config Class Initialized
INFO - 2018-03-23 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:10 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:10 --> URI Class Initialized
INFO - 2018-03-23 23:56:10 --> Router Class Initialized
INFO - 2018-03-23 23:56:10 --> Output Class Initialized
INFO - 2018-03-23 23:56:10 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:10 --> Input Class Initialized
INFO - 2018-03-23 23:56:10 --> Language Class Initialized
INFO - 2018-03-23 23:56:10 --> Loader Class Initialized
INFO - 2018-03-23 23:56:10 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:10 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:10 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:10 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Controller Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
INFO - 2018-03-23 23:56:10 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
INFO - 2018-03-23 23:56:46 --> Loader Class Initialized
INFO - 2018-03-23 23:56:46 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:46 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:46 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:46 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:46 --> Model Class Initialized
INFO - 2018-03-23 23:56:46 --> Controller Class Initialized
INFO - 2018-03-23 23:56:46 --> Model Class Initialized
INFO - 2018-03-23 23:56:46 --> Model Class Initialized
INFO - 2018-03-23 23:56:46 --> Model Class Initialized
INFO - 2018-03-23 23:56:46 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:56:46 --> Final output sent to browser
DEBUG - 2018-03-23 23:56:46 --> Total execution time: 0.0816
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
INFO - 2018-03-23 23:56:46 --> URI Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:46 --> Router Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:46 --> Output Class Initialized
INFO - 2018-03-23 23:56:46 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:46 --> Input Class Initialized
INFO - 2018-03-23 23:56:46 --> Language Class Initialized
ERROR - 2018-03-23 23:56:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:46 --> Config Class Initialized
INFO - 2018-03-23 23:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:46 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:47 --> URI Class Initialized
INFO - 2018-03-23 23:56:47 --> Router Class Initialized
INFO - 2018-03-23 23:56:47 --> Output Class Initialized
INFO - 2018-03-23 23:56:47 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:47 --> Input Class Initialized
INFO - 2018-03-23 23:56:47 --> Language Class Initialized
INFO - 2018-03-23 23:56:47 --> Loader Class Initialized
INFO - 2018-03-23 23:56:47 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:47 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:47 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:47 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:47 --> Model Class Initialized
INFO - 2018-03-23 23:56:47 --> Controller Class Initialized
INFO - 2018-03-23 23:56:47 --> Model Class Initialized
INFO - 2018-03-23 23:56:47 --> Model Class Initialized
INFO - 2018-03-23 23:56:47 --> Model Class Initialized
INFO - 2018-03-23 23:56:47 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
INFO - 2018-03-23 23:56:53 --> Loader Class Initialized
INFO - 2018-03-23 23:56:53 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:53 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:53 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Controller Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:56:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:56:53 --> Final output sent to browser
DEBUG - 2018-03-23 23:56:53 --> Total execution time: 0.0567
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
ERROR - 2018-03-23 23:56:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:56:53 --> Config Class Initialized
INFO - 2018-03-23 23:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:56:53 --> Utf8 Class Initialized
INFO - 2018-03-23 23:56:53 --> URI Class Initialized
INFO - 2018-03-23 23:56:53 --> Router Class Initialized
INFO - 2018-03-23 23:56:53 --> Output Class Initialized
INFO - 2018-03-23 23:56:53 --> Security Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:56:53 --> Input Class Initialized
INFO - 2018-03-23 23:56:53 --> Language Class Initialized
INFO - 2018-03-23 23:56:53 --> Loader Class Initialized
INFO - 2018-03-23 23:56:53 --> Helper loaded: url_helper
INFO - 2018-03-23 23:56:53 --> Helper loaded: form_helper
INFO - 2018-03-23 23:56:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:56:53 --> Form Validation Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Controller Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
INFO - 2018-03-23 23:56:53 --> Model Class Initialized
DEBUG - 2018-03-23 23:56:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
INFO - 2018-03-23 23:57:06 --> Loader Class Initialized
INFO - 2018-03-23 23:57:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:57:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:57:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:57:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Controller Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:57:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:57:06 --> Final output sent to browser
DEBUG - 2018-03-23 23:57:06 --> Total execution time: 0.1524
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:57:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:57:06 --> Config Class Initialized
INFO - 2018-03-23 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:57:06 --> Utf8 Class Initialized
INFO - 2018-03-23 23:57:06 --> URI Class Initialized
INFO - 2018-03-23 23:57:06 --> Router Class Initialized
INFO - 2018-03-23 23:57:06 --> Output Class Initialized
INFO - 2018-03-23 23:57:06 --> Security Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:57:06 --> Input Class Initialized
INFO - 2018-03-23 23:57:06 --> Language Class Initialized
INFO - 2018-03-23 23:57:06 --> Loader Class Initialized
INFO - 2018-03-23 23:57:06 --> Helper loaded: url_helper
INFO - 2018-03-23 23:57:06 --> Helper loaded: form_helper
INFO - 2018-03-23 23:57:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:57:06 --> Form Validation Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Controller Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
INFO - 2018-03-23 23:57:06 --> Model Class Initialized
DEBUG - 2018-03-23 23:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:58:24 --> Config Class Initialized
INFO - 2018-03-23 23:58:24 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:58:24 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:24 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:24 --> URI Class Initialized
INFO - 2018-03-23 23:58:24 --> Router Class Initialized
INFO - 2018-03-23 23:58:24 --> Output Class Initialized
INFO - 2018-03-23 23:58:24 --> Security Class Initialized
DEBUG - 2018-03-23 23:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:24 --> Input Class Initialized
INFO - 2018-03-23 23:58:24 --> Language Class Initialized
INFO - 2018-03-23 23:58:24 --> Loader Class Initialized
INFO - 2018-03-23 23:58:24 --> Helper loaded: url_helper
INFO - 2018-03-23 23:58:24 --> Helper loaded: form_helper
INFO - 2018-03-23 23:58:24 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:58:24 --> Form Validation Class Initialized
INFO - 2018-03-23 23:58:24 --> Model Class Initialized
INFO - 2018-03-23 23:58:24 --> Controller Class Initialized
INFO - 2018-03-23 23:58:24 --> Model Class Initialized
INFO - 2018-03-23 23:58:24 --> Model Class Initialized
INFO - 2018-03-23 23:58:24 --> Model Class Initialized
INFO - 2018-03-23 23:58:24 --> Model Class Initialized
DEBUG - 2018-03-23 23:58:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-23 23:58:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-23 23:58:24 --> Final output sent to browser
DEBUG - 2018-03-23 23:58:24 --> Total execution time: 0.1331
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-23 23:58:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-23 23:58:25 --> Config Class Initialized
INFO - 2018-03-23 23:58:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 23:58:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 23:58:25 --> Utf8 Class Initialized
INFO - 2018-03-23 23:58:25 --> URI Class Initialized
INFO - 2018-03-23 23:58:25 --> Router Class Initialized
INFO - 2018-03-23 23:58:25 --> Output Class Initialized
INFO - 2018-03-23 23:58:25 --> Security Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 23:58:25 --> Input Class Initialized
INFO - 2018-03-23 23:58:25 --> Language Class Initialized
INFO - 2018-03-23 23:58:25 --> Loader Class Initialized
INFO - 2018-03-23 23:58:25 --> Helper loaded: url_helper
INFO - 2018-03-23 23:58:25 --> Helper loaded: form_helper
INFO - 2018-03-23 23:58:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 23:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 23:58:25 --> Form Validation Class Initialized
INFO - 2018-03-23 23:58:25 --> Model Class Initialized
INFO - 2018-03-23 23:58:25 --> Controller Class Initialized
INFO - 2018-03-23 23:58:25 --> Model Class Initialized
INFO - 2018-03-23 23:58:25 --> Model Class Initialized
INFO - 2018-03-23 23:58:25 --> Model Class Initialized
INFO - 2018-03-23 23:58:25 --> Model Class Initialized
DEBUG - 2018-03-23 23:58:25 --> Form_validation class already loaded. Second attempt ignored.
