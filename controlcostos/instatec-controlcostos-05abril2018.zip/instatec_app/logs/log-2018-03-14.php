<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-14 23:09:15 --> Config Class Initialized
INFO - 2018-03-14 23:09:15 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:09:15 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:09:15 --> Utf8 Class Initialized
INFO - 2018-03-14 23:09:16 --> URI Class Initialized
INFO - 2018-03-14 23:09:16 --> Router Class Initialized
INFO - 2018-03-14 23:09:16 --> Output Class Initialized
INFO - 2018-03-14 23:09:16 --> Security Class Initialized
DEBUG - 2018-03-14 23:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:09:16 --> Input Class Initialized
INFO - 2018-03-14 23:09:16 --> Language Class Initialized
ERROR - 2018-03-14 23:09:16 --> 404 Page Not Found: Reportes/horas-por-trabajador
INFO - 2018-03-14 23:19:17 --> Config Class Initialized
INFO - 2018-03-14 23:19:17 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:17 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:17 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:17 --> URI Class Initialized
INFO - 2018-03-14 23:19:17 --> Router Class Initialized
INFO - 2018-03-14 23:19:17 --> Output Class Initialized
INFO - 2018-03-14 23:19:17 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:17 --> Input Class Initialized
INFO - 2018-03-14 23:19:17 --> Language Class Initialized
INFO - 2018-03-14 23:19:17 --> Loader Class Initialized
INFO - 2018-03-14 23:19:17 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:17 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:18 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:18 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
INFO - 2018-03-14 23:19:18 --> Controller Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:18 --> Config Class Initialized
INFO - 2018-03-14 23:19:18 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:18 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:18 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:18 --> URI Class Initialized
INFO - 2018-03-14 23:19:18 --> Router Class Initialized
INFO - 2018-03-14 23:19:18 --> Output Class Initialized
INFO - 2018-03-14 23:19:18 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:18 --> Input Class Initialized
INFO - 2018-03-14 23:19:18 --> Language Class Initialized
INFO - 2018-03-14 23:19:18 --> Loader Class Initialized
INFO - 2018-03-14 23:19:18 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:18 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:18 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:18 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
INFO - 2018-03-14 23:19:18 --> Controller Class Initialized
INFO - 2018-03-14 23:19:18 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:19:18 --> Final output sent to browser
DEBUG - 2018-03-14 23:19:18 --> Total execution time: 0.1216
INFO - 2018-03-14 23:19:20 --> Config Class Initialized
INFO - 2018-03-14 23:19:20 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:20 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:20 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:20 --> URI Class Initialized
INFO - 2018-03-14 23:19:20 --> Router Class Initialized
INFO - 2018-03-14 23:19:20 --> Output Class Initialized
INFO - 2018-03-14 23:19:20 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:20 --> Input Class Initialized
INFO - 2018-03-14 23:19:20 --> Language Class Initialized
INFO - 2018-03-14 23:19:20 --> Loader Class Initialized
INFO - 2018-03-14 23:19:20 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:20 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:20 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:20 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Controller Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-14 23:19:20 --> Config Class Initialized
INFO - 2018-03-14 23:19:20 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:20 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:20 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:20 --> URI Class Initialized
DEBUG - 2018-03-14 23:19:20 --> No URI present. Default controller set.
INFO - 2018-03-14 23:19:20 --> Router Class Initialized
INFO - 2018-03-14 23:19:20 --> Output Class Initialized
INFO - 2018-03-14 23:19:20 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:20 --> Input Class Initialized
INFO - 2018-03-14 23:19:20 --> Language Class Initialized
INFO - 2018-03-14 23:19:20 --> Loader Class Initialized
INFO - 2018-03-14 23:19:20 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:20 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:20 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:20 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Controller Class Initialized
INFO - 2018-03-14 23:19:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:19:20 --> Final output sent to browser
DEBUG - 2018-03-14 23:19:20 --> Total execution time: 0.0552
INFO - 2018-03-14 23:19:20 --> Config Class Initialized
INFO - 2018-03-14 23:19:20 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:20 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:20 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:20 --> URI Class Initialized
INFO - 2018-03-14 23:19:20 --> Router Class Initialized
INFO - 2018-03-14 23:19:20 --> Output Class Initialized
INFO - 2018-03-14 23:19:20 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:20 --> Input Class Initialized
INFO - 2018-03-14 23:19:20 --> Language Class Initialized
INFO - 2018-03-14 23:19:20 --> Loader Class Initialized
INFO - 2018-03-14 23:19:20 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:20 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:20 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:20 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Controller Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
INFO - 2018-03-14 23:19:20 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:22 --> Config Class Initialized
INFO - 2018-03-14 23:19:22 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:22 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:22 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:22 --> URI Class Initialized
INFO - 2018-03-14 23:19:22 --> Router Class Initialized
INFO - 2018-03-14 23:19:22 --> Output Class Initialized
INFO - 2018-03-14 23:19:22 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:22 --> Input Class Initialized
INFO - 2018-03-14 23:19:22 --> Language Class Initialized
INFO - 2018-03-14 23:19:22 --> Loader Class Initialized
INFO - 2018-03-14 23:19:22 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:22 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:22 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:22 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:22 --> Model Class Initialized
INFO - 2018-03-14 23:19:22 --> Controller Class Initialized
INFO - 2018-03-14 23:19:22 --> Model Class Initialized
INFO - 2018-03-14 23:19:22 --> Model Class Initialized
INFO - 2018-03-14 23:19:22 --> Model Class Initialized
INFO - 2018-03-14 23:19:22 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:19:22 --> Final output sent to browser
DEBUG - 2018-03-14 23:19:22 --> Total execution time: 0.1219
INFO - 2018-03-14 23:19:25 --> Config Class Initialized
INFO - 2018-03-14 23:19:25 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:19:25 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:19:25 --> Utf8 Class Initialized
INFO - 2018-03-14 23:19:25 --> URI Class Initialized
INFO - 2018-03-14 23:19:25 --> Router Class Initialized
INFO - 2018-03-14 23:19:25 --> Output Class Initialized
INFO - 2018-03-14 23:19:25 --> Security Class Initialized
DEBUG - 2018-03-14 23:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:19:25 --> Input Class Initialized
INFO - 2018-03-14 23:19:25 --> Language Class Initialized
INFO - 2018-03-14 23:19:25 --> Loader Class Initialized
INFO - 2018-03-14 23:19:25 --> Helper loaded: url_helper
INFO - 2018-03-14 23:19:25 --> Helper loaded: form_helper
INFO - 2018-03-14 23:19:25 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:19:25 --> Form Validation Class Initialized
INFO - 2018-03-14 23:19:25 --> Model Class Initialized
INFO - 2018-03-14 23:19:25 --> Controller Class Initialized
INFO - 2018-03-14 23:19:25 --> Model Class Initialized
INFO - 2018-03-14 23:19:25 --> Model Class Initialized
INFO - 2018-03-14 23:19:25 --> Model Class Initialized
INFO - 2018-03-14 23:19:25 --> Model Class Initialized
DEBUG - 2018-03-14 23:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:19:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:19:25 --> Final output sent to browser
DEBUG - 2018-03-14 23:19:25 --> Total execution time: 0.0971
INFO - 2018-03-14 23:29:45 --> Config Class Initialized
INFO - 2018-03-14 23:29:45 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:45 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:45 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:45 --> URI Class Initialized
INFO - 2018-03-14 23:29:45 --> Router Class Initialized
INFO - 2018-03-14 23:29:45 --> Output Class Initialized
INFO - 2018-03-14 23:29:45 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:45 --> Input Class Initialized
INFO - 2018-03-14 23:29:45 --> Language Class Initialized
INFO - 2018-03-14 23:29:45 --> Loader Class Initialized
INFO - 2018-03-14 23:29:45 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:45 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:45 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:45 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
INFO - 2018-03-14 23:29:45 --> Controller Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
INFO - 2018-03-14 23:29:45 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:29:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:29:46 --> Final output sent to browser
DEBUG - 2018-03-14 23:29:46 --> Total execution time: 0.3818
INFO - 2018-03-14 23:29:46 --> Config Class Initialized
INFO - 2018-03-14 23:29:46 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:46 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:46 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:46 --> URI Class Initialized
INFO - 2018-03-14 23:29:46 --> Router Class Initialized
INFO - 2018-03-14 23:29:46 --> Output Class Initialized
INFO - 2018-03-14 23:29:46 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:46 --> Input Class Initialized
INFO - 2018-03-14 23:29:46 --> Language Class Initialized
INFO - 2018-03-14 23:29:46 --> Loader Class Initialized
INFO - 2018-03-14 23:29:46 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:46 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:46 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:46 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
INFO - 2018-03-14 23:29:46 --> Controller Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
INFO - 2018-03-14 23:29:46 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:29:47 --> Config Class Initialized
INFO - 2018-03-14 23:29:47 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:47 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:47 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:47 --> URI Class Initialized
INFO - 2018-03-14 23:29:47 --> Router Class Initialized
INFO - 2018-03-14 23:29:47 --> Output Class Initialized
INFO - 2018-03-14 23:29:47 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:47 --> Input Class Initialized
INFO - 2018-03-14 23:29:47 --> Language Class Initialized
INFO - 2018-03-14 23:29:47 --> Loader Class Initialized
INFO - 2018-03-14 23:29:47 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:47 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:47 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:47 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
INFO - 2018-03-14 23:29:47 --> Controller Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
INFO - 2018-03-14 23:29:47 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:29:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:29:47 --> Final output sent to browser
DEBUG - 2018-03-14 23:29:47 --> Total execution time: 0.0916
INFO - 2018-03-14 23:29:48 --> Config Class Initialized
INFO - 2018-03-14 23:29:48 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:48 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:48 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:48 --> URI Class Initialized
INFO - 2018-03-14 23:29:48 --> Router Class Initialized
INFO - 2018-03-14 23:29:48 --> Output Class Initialized
INFO - 2018-03-14 23:29:48 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:48 --> Input Class Initialized
INFO - 2018-03-14 23:29:48 --> Language Class Initialized
INFO - 2018-03-14 23:29:48 --> Loader Class Initialized
INFO - 2018-03-14 23:29:48 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:48 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:48 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:48 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
INFO - 2018-03-14 23:29:48 --> Controller Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
INFO - 2018-03-14 23:29:48 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:29:58 --> Config Class Initialized
INFO - 2018-03-14 23:29:58 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:58 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:58 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:58 --> URI Class Initialized
INFO - 2018-03-14 23:29:58 --> Router Class Initialized
INFO - 2018-03-14 23:29:58 --> Output Class Initialized
INFO - 2018-03-14 23:29:58 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:58 --> Input Class Initialized
INFO - 2018-03-14 23:29:58 --> Language Class Initialized
INFO - 2018-03-14 23:29:58 --> Loader Class Initialized
INFO - 2018-03-14 23:29:58 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:58 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:58 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:58 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
INFO - 2018-03-14 23:29:58 --> Controller Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:29:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:29:58 --> Final output sent to browser
DEBUG - 2018-03-14 23:29:58 --> Total execution time: 0.1252
INFO - 2018-03-14 23:29:58 --> Config Class Initialized
INFO - 2018-03-14 23:29:58 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:29:58 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:29:58 --> Utf8 Class Initialized
INFO - 2018-03-14 23:29:58 --> URI Class Initialized
INFO - 2018-03-14 23:29:58 --> Router Class Initialized
INFO - 2018-03-14 23:29:58 --> Output Class Initialized
INFO - 2018-03-14 23:29:58 --> Security Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:29:58 --> Input Class Initialized
INFO - 2018-03-14 23:29:58 --> Language Class Initialized
INFO - 2018-03-14 23:29:58 --> Loader Class Initialized
INFO - 2018-03-14 23:29:58 --> Helper loaded: url_helper
INFO - 2018-03-14 23:29:58 --> Helper loaded: form_helper
INFO - 2018-03-14 23:29:58 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:29:58 --> Form Validation Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
INFO - 2018-03-14 23:29:58 --> Controller Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
INFO - 2018-03-14 23:29:58 --> Model Class Initialized
DEBUG - 2018-03-14 23:29:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:30:01 --> Config Class Initialized
INFO - 2018-03-14 23:30:01 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:30:01 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:30:01 --> Utf8 Class Initialized
INFO - 2018-03-14 23:30:01 --> URI Class Initialized
INFO - 2018-03-14 23:30:01 --> Router Class Initialized
INFO - 2018-03-14 23:30:01 --> Output Class Initialized
INFO - 2018-03-14 23:30:01 --> Security Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:30:01 --> Input Class Initialized
INFO - 2018-03-14 23:30:01 --> Language Class Initialized
INFO - 2018-03-14 23:30:01 --> Loader Class Initialized
INFO - 2018-03-14 23:30:01 --> Helper loaded: url_helper
INFO - 2018-03-14 23:30:01 --> Helper loaded: form_helper
INFO - 2018-03-14 23:30:01 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:30:01 --> Form Validation Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
INFO - 2018-03-14 23:30:01 --> Controller Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-14 23:30:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-14 23:30:01 --> Final output sent to browser
DEBUG - 2018-03-14 23:30:01 --> Total execution time: 0.0547
INFO - 2018-03-14 23:30:01 --> Config Class Initialized
INFO - 2018-03-14 23:30:01 --> Hooks Class Initialized
DEBUG - 2018-03-14 23:30:01 --> UTF-8 Support Enabled
INFO - 2018-03-14 23:30:01 --> Utf8 Class Initialized
INFO - 2018-03-14 23:30:01 --> URI Class Initialized
INFO - 2018-03-14 23:30:01 --> Router Class Initialized
INFO - 2018-03-14 23:30:01 --> Output Class Initialized
INFO - 2018-03-14 23:30:01 --> Security Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 23:30:01 --> Input Class Initialized
INFO - 2018-03-14 23:30:01 --> Language Class Initialized
INFO - 2018-03-14 23:30:01 --> Loader Class Initialized
INFO - 2018-03-14 23:30:01 --> Helper loaded: url_helper
INFO - 2018-03-14 23:30:01 --> Helper loaded: form_helper
INFO - 2018-03-14 23:30:01 --> Database Driver Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 23:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 23:30:01 --> Form Validation Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
INFO - 2018-03-14 23:30:01 --> Controller Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
INFO - 2018-03-14 23:30:01 --> Model Class Initialized
DEBUG - 2018-03-14 23:30:01 --> Form_validation class already loaded. Second attempt ignored.
