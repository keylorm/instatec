<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-26 22:52:23 --> Config Class Initialized
INFO - 2018-03-26 22:52:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:23 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:23 --> URI Class Initialized
INFO - 2018-03-26 22:52:23 --> Router Class Initialized
INFO - 2018-03-26 22:52:23 --> Output Class Initialized
INFO - 2018-03-26 22:52:23 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:23 --> Input Class Initialized
INFO - 2018-03-26 22:52:23 --> Language Class Initialized
INFO - 2018-03-26 22:52:24 --> Loader Class Initialized
INFO - 2018-03-26 22:52:24 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:24 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:24 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:24 --> Form Validation Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
INFO - 2018-03-26 22:52:24 --> Controller Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
DEBUG - 2018-03-26 22:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 22:52:24 --> Config Class Initialized
INFO - 2018-03-26 22:52:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:24 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:24 --> URI Class Initialized
INFO - 2018-03-26 22:52:24 --> Router Class Initialized
INFO - 2018-03-26 22:52:24 --> Output Class Initialized
INFO - 2018-03-26 22:52:24 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:24 --> Input Class Initialized
INFO - 2018-03-26 22:52:24 --> Language Class Initialized
INFO - 2018-03-26 22:52:24 --> Loader Class Initialized
INFO - 2018-03-26 22:52:24 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:24 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:24 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:24 --> Form Validation Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
INFO - 2018-03-26 22:52:24 --> Controller Class Initialized
INFO - 2018-03-26 22:52:24 --> Model Class Initialized
DEBUG - 2018-03-26 22:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 22:52:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 22:52:24 --> Final output sent to browser
DEBUG - 2018-03-26 22:52:24 --> Total execution time: 0.1761
INFO - 2018-03-26 22:52:26 --> Config Class Initialized
INFO - 2018-03-26 22:52:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:26 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:26 --> URI Class Initialized
INFO - 2018-03-26 22:52:26 --> Router Class Initialized
INFO - 2018-03-26 22:52:26 --> Output Class Initialized
INFO - 2018-03-26 22:52:26 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:26 --> Input Class Initialized
INFO - 2018-03-26 22:52:26 --> Language Class Initialized
INFO - 2018-03-26 22:52:26 --> Loader Class Initialized
INFO - 2018-03-26 22:52:26 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:26 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:26 --> Form Validation Class Initialized
INFO - 2018-03-26 22:52:26 --> Model Class Initialized
INFO - 2018-03-26 22:52:26 --> Controller Class Initialized
INFO - 2018-03-26 22:52:26 --> Model Class Initialized
DEBUG - 2018-03-26 22:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 22:52:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 22:52:26 --> Config Class Initialized
INFO - 2018-03-26 22:52:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:26 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:26 --> URI Class Initialized
DEBUG - 2018-03-26 22:52:26 --> No URI present. Default controller set.
INFO - 2018-03-26 22:52:26 --> Router Class Initialized
INFO - 2018-03-26 22:52:26 --> Output Class Initialized
INFO - 2018-03-26 22:52:26 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:26 --> Input Class Initialized
INFO - 2018-03-26 22:52:26 --> Language Class Initialized
INFO - 2018-03-26 22:52:27 --> Loader Class Initialized
INFO - 2018-03-26 22:52:27 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:27 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:27 --> Form Validation Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Controller Class Initialized
INFO - 2018-03-26 22:52:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 22:52:27 --> Final output sent to browser
DEBUG - 2018-03-26 22:52:27 --> Total execution time: 0.1164
INFO - 2018-03-26 22:52:27 --> Config Class Initialized
INFO - 2018-03-26 22:52:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:27 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:27 --> URI Class Initialized
INFO - 2018-03-26 22:52:27 --> Router Class Initialized
INFO - 2018-03-26 22:52:27 --> Output Class Initialized
INFO - 2018-03-26 22:52:27 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:27 --> Input Class Initialized
INFO - 2018-03-26 22:52:27 --> Language Class Initialized
INFO - 2018-03-26 22:52:27 --> Loader Class Initialized
INFO - 2018-03-26 22:52:27 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:27 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:27 --> Form Validation Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Controller Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
INFO - 2018-03-26 22:52:27 --> Model Class Initialized
DEBUG - 2018-03-26 22:52:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:02:37 --> Config Class Initialized
INFO - 2018-03-26 23:02:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:02:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:02:37 --> Utf8 Class Initialized
INFO - 2018-03-26 23:02:37 --> URI Class Initialized
INFO - 2018-03-26 23:02:37 --> Router Class Initialized
INFO - 2018-03-26 23:02:37 --> Output Class Initialized
INFO - 2018-03-26 23:02:37 --> Security Class Initialized
DEBUG - 2018-03-26 23:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:02:37 --> Input Class Initialized
INFO - 2018-03-26 23:02:37 --> Language Class Initialized
INFO - 2018-03-26 23:02:37 --> Loader Class Initialized
INFO - 2018-03-26 23:02:37 --> Helper loaded: url_helper
INFO - 2018-03-26 23:02:37 --> Helper loaded: form_helper
INFO - 2018-03-26 23:02:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:02:37 --> Form Validation Class Initialized
INFO - 2018-03-26 23:02:37 --> Model Class Initialized
INFO - 2018-03-26 23:02:37 --> Controller Class Initialized
INFO - 2018-03-26 23:02:37 --> Model Class Initialized
INFO - 2018-03-26 23:02:37 --> Model Class Initialized
INFO - 2018-03-26 23:02:37 --> Model Class Initialized
INFO - 2018-03-26 23:02:37 --> Model Class Initialized
DEBUG - 2018-03-26 23:02:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:02:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:02:40 --> Final output sent to browser
DEBUG - 2018-03-26 23:02:40 --> Total execution time: 2.7165
INFO - 2018-03-26 23:04:51 --> Config Class Initialized
INFO - 2018-03-26 23:04:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:04:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:04:51 --> Utf8 Class Initialized
INFO - 2018-03-26 23:04:51 --> URI Class Initialized
INFO - 2018-03-26 23:04:51 --> Router Class Initialized
INFO - 2018-03-26 23:04:51 --> Output Class Initialized
INFO - 2018-03-26 23:04:51 --> Security Class Initialized
DEBUG - 2018-03-26 23:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:04:51 --> Input Class Initialized
INFO - 2018-03-26 23:04:51 --> Language Class Initialized
INFO - 2018-03-26 23:04:51 --> Loader Class Initialized
INFO - 2018-03-26 23:04:51 --> Helper loaded: url_helper
INFO - 2018-03-26 23:04:51 --> Helper loaded: form_helper
INFO - 2018-03-26 23:04:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:04:51 --> Form Validation Class Initialized
INFO - 2018-03-26 23:04:51 --> Model Class Initialized
INFO - 2018-03-26 23:04:51 --> Controller Class Initialized
INFO - 2018-03-26 23:04:51 --> Model Class Initialized
INFO - 2018-03-26 23:04:51 --> Model Class Initialized
INFO - 2018-03-26 23:04:51 --> Model Class Initialized
INFO - 2018-03-26 23:04:51 --> Model Class Initialized
DEBUG - 2018-03-26 23:04:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:04:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:04:51 --> Final output sent to browser
DEBUG - 2018-03-26 23:04:51 --> Total execution time: 0.0959
INFO - 2018-03-26 23:04:53 --> Config Class Initialized
INFO - 2018-03-26 23:04:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:04:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:04:53 --> Utf8 Class Initialized
INFO - 2018-03-26 23:04:53 --> URI Class Initialized
INFO - 2018-03-26 23:04:53 --> Router Class Initialized
INFO - 2018-03-26 23:04:53 --> Output Class Initialized
INFO - 2018-03-26 23:04:53 --> Security Class Initialized
DEBUG - 2018-03-26 23:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:04:53 --> Input Class Initialized
INFO - 2018-03-26 23:04:53 --> Language Class Initialized
INFO - 2018-03-26 23:04:53 --> Loader Class Initialized
INFO - 2018-03-26 23:04:53 --> Helper loaded: url_helper
INFO - 2018-03-26 23:04:53 --> Helper loaded: form_helper
INFO - 2018-03-26 23:04:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:04:53 --> Form Validation Class Initialized
INFO - 2018-03-26 23:04:53 --> Model Class Initialized
INFO - 2018-03-26 23:04:53 --> Controller Class Initialized
INFO - 2018-03-26 23:04:53 --> Model Class Initialized
INFO - 2018-03-26 23:04:53 --> Model Class Initialized
INFO - 2018-03-26 23:04:53 --> Model Class Initialized
INFO - 2018-03-26 23:04:53 --> Model Class Initialized
DEBUG - 2018-03-26 23:04:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:04:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:04:53 --> Final output sent to browser
DEBUG - 2018-03-26 23:04:53 --> Total execution time: 0.0863
INFO - 2018-03-26 23:04:54 --> Config Class Initialized
INFO - 2018-03-26 23:04:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:04:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:04:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:04:54 --> URI Class Initialized
INFO - 2018-03-26 23:04:54 --> Router Class Initialized
INFO - 2018-03-26 23:04:54 --> Output Class Initialized
INFO - 2018-03-26 23:04:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:04:54 --> Input Class Initialized
INFO - 2018-03-26 23:04:54 --> Language Class Initialized
INFO - 2018-03-26 23:04:54 --> Loader Class Initialized
INFO - 2018-03-26 23:04:54 --> Helper loaded: url_helper
INFO - 2018-03-26 23:04:54 --> Helper loaded: form_helper
INFO - 2018-03-26 23:04:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:04:54 --> Form Validation Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Controller Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:04:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:04:54 --> Final output sent to browser
DEBUG - 2018-03-26 23:04:54 --> Total execution time: 0.0931
INFO - 2018-03-26 23:04:54 --> Config Class Initialized
INFO - 2018-03-26 23:04:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:04:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:04:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:04:54 --> URI Class Initialized
INFO - 2018-03-26 23:04:54 --> Router Class Initialized
INFO - 2018-03-26 23:04:54 --> Output Class Initialized
INFO - 2018-03-26 23:04:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:04:54 --> Input Class Initialized
INFO - 2018-03-26 23:04:54 --> Language Class Initialized
INFO - 2018-03-26 23:04:54 --> Loader Class Initialized
INFO - 2018-03-26 23:04:54 --> Helper loaded: url_helper
INFO - 2018-03-26 23:04:54 --> Helper loaded: form_helper
INFO - 2018-03-26 23:04:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:04:54 --> Form Validation Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Controller Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
INFO - 2018-03-26 23:04:54 --> Model Class Initialized
DEBUG - 2018-03-26 23:04:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:04:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:04:54 --> Final output sent to browser
DEBUG - 2018-03-26 23:04:54 --> Total execution time: 0.1051
INFO - 2018-03-26 23:09:53 --> Config Class Initialized
INFO - 2018-03-26 23:09:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:09:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:09:53 --> Utf8 Class Initialized
INFO - 2018-03-26 23:09:53 --> URI Class Initialized
INFO - 2018-03-26 23:09:53 --> Router Class Initialized
INFO - 2018-03-26 23:09:53 --> Output Class Initialized
INFO - 2018-03-26 23:09:53 --> Security Class Initialized
DEBUG - 2018-03-26 23:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:09:53 --> Input Class Initialized
INFO - 2018-03-26 23:09:53 --> Language Class Initialized
INFO - 2018-03-26 23:09:53 --> Loader Class Initialized
INFO - 2018-03-26 23:09:53 --> Helper loaded: url_helper
INFO - 2018-03-26 23:09:53 --> Helper loaded: form_helper
INFO - 2018-03-26 23:09:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:09:53 --> Form Validation Class Initialized
INFO - 2018-03-26 23:09:53 --> Model Class Initialized
INFO - 2018-03-26 23:09:53 --> Controller Class Initialized
INFO - 2018-03-26 23:09:53 --> Model Class Initialized
INFO - 2018-03-26 23:09:53 --> Model Class Initialized
INFO - 2018-03-26 23:09:53 --> Model Class Initialized
INFO - 2018-03-26 23:09:53 --> Model Class Initialized
DEBUG - 2018-03-26 23:09:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:09:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:09:53 --> Final output sent to browser
DEBUG - 2018-03-26 23:09:53 --> Total execution time: 0.0838
INFO - 2018-03-26 23:10:20 --> Config Class Initialized
INFO - 2018-03-26 23:10:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:10:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:10:20 --> Utf8 Class Initialized
INFO - 2018-03-26 23:10:20 --> URI Class Initialized
INFO - 2018-03-26 23:10:20 --> Router Class Initialized
INFO - 2018-03-26 23:10:20 --> Output Class Initialized
INFO - 2018-03-26 23:10:20 --> Security Class Initialized
DEBUG - 2018-03-26 23:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:10:20 --> Input Class Initialized
INFO - 2018-03-26 23:10:20 --> Language Class Initialized
INFO - 2018-03-26 23:10:20 --> Loader Class Initialized
INFO - 2018-03-26 23:10:20 --> Helper loaded: url_helper
INFO - 2018-03-26 23:10:20 --> Helper loaded: form_helper
INFO - 2018-03-26 23:10:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:10:20 --> Form Validation Class Initialized
INFO - 2018-03-26 23:10:20 --> Model Class Initialized
INFO - 2018-03-26 23:10:20 --> Controller Class Initialized
INFO - 2018-03-26 23:10:20 --> Model Class Initialized
INFO - 2018-03-26 23:10:20 --> Model Class Initialized
INFO - 2018-03-26 23:10:20 --> Model Class Initialized
INFO - 2018-03-26 23:10:20 --> Model Class Initialized
DEBUG - 2018-03-26 23:10:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:10:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:10:20 --> Final output sent to browser
DEBUG - 2018-03-26 23:10:20 --> Total execution time: 0.1243
INFO - 2018-03-26 23:26:54 --> Config Class Initialized
INFO - 2018-03-26 23:26:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:26:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:26:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:26:54 --> URI Class Initialized
INFO - 2018-03-26 23:26:54 --> Router Class Initialized
INFO - 2018-03-26 23:26:54 --> Output Class Initialized
INFO - 2018-03-26 23:26:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:26:54 --> Input Class Initialized
INFO - 2018-03-26 23:26:54 --> Language Class Initialized
INFO - 2018-03-26 23:26:55 --> Loader Class Initialized
INFO - 2018-03-26 23:26:55 --> Helper loaded: url_helper
INFO - 2018-03-26 23:26:55 --> Helper loaded: form_helper
INFO - 2018-03-26 23:26:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:26:55 --> Form Validation Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Controller Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
DEBUG - 2018-03-26 23:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:26:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:26:55 --> Final output sent to browser
DEBUG - 2018-03-26 23:26:55 --> Total execution time: 0.3444
INFO - 2018-03-26 23:26:55 --> Config Class Initialized
INFO - 2018-03-26 23:26:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:26:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:26:55 --> Utf8 Class Initialized
INFO - 2018-03-26 23:26:55 --> URI Class Initialized
INFO - 2018-03-26 23:26:55 --> Router Class Initialized
INFO - 2018-03-26 23:26:55 --> Output Class Initialized
INFO - 2018-03-26 23:26:55 --> Security Class Initialized
DEBUG - 2018-03-26 23:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:26:55 --> Input Class Initialized
INFO - 2018-03-26 23:26:55 --> Language Class Initialized
INFO - 2018-03-26 23:26:55 --> Loader Class Initialized
INFO - 2018-03-26 23:26:55 --> Helper loaded: url_helper
INFO - 2018-03-26 23:26:55 --> Helper loaded: form_helper
INFO - 2018-03-26 23:26:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:26:55 --> Form Validation Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Controller Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
INFO - 2018-03-26 23:26:55 --> Model Class Initialized
DEBUG - 2018-03-26 23:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:27:00 --> Config Class Initialized
INFO - 2018-03-26 23:27:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:27:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:00 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:00 --> URI Class Initialized
INFO - 2018-03-26 23:27:00 --> Router Class Initialized
INFO - 2018-03-26 23:27:00 --> Output Class Initialized
INFO - 2018-03-26 23:27:00 --> Security Class Initialized
DEBUG - 2018-03-26 23:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:00 --> Input Class Initialized
INFO - 2018-03-26 23:27:00 --> Language Class Initialized
INFO - 2018-03-26 23:27:00 --> Loader Class Initialized
INFO - 2018-03-26 23:27:00 --> Helper loaded: url_helper
INFO - 2018-03-26 23:27:00 --> Helper loaded: form_helper
INFO - 2018-03-26 23:27:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:27:00 --> Form Validation Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
INFO - 2018-03-26 23:27:00 --> Controller Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
INFO - 2018-03-26 23:27:00 --> Model Class Initialized
DEBUG - 2018-03-26 23:27:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:27:08 --> Config Class Initialized
INFO - 2018-03-26 23:27:08 --> Hooks Class Initialized
INFO - 2018-03-26 23:27:08 --> Config Class Initialized
INFO - 2018-03-26 23:27:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:08 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:08 --> URI Class Initialized
DEBUG - 2018-03-26 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:08 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:08 --> Router Class Initialized
INFO - 2018-03-26 23:27:08 --> URI Class Initialized
INFO - 2018-03-26 23:27:08 --> Output Class Initialized
INFO - 2018-03-26 23:27:08 --> Router Class Initialized
INFO - 2018-03-26 23:27:08 --> Security Class Initialized
INFO - 2018-03-26 23:27:08 --> Output Class Initialized
DEBUG - 2018-03-26 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:08 --> Input Class Initialized
INFO - 2018-03-26 23:27:08 --> Security Class Initialized
INFO - 2018-03-26 23:27:08 --> Language Class Initialized
DEBUG - 2018-03-26 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:08 --> Input Class Initialized
INFO - 2018-03-26 23:27:08 --> Language Class Initialized
INFO - 2018-03-26 23:27:08 --> Config Class Initialized
INFO - 2018-03-26 23:27:08 --> Config Class Initialized
INFO - 2018-03-26 23:27:08 --> Hooks Class Initialized
INFO - 2018-03-26 23:27:08 --> Hooks Class Initialized
INFO - 2018-03-26 23:27:08 --> Config Class Initialized
INFO - 2018-03-26 23:27:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:08 --> Utf8 Class Initialized
DEBUG - 2018-03-26 23:27:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 23:27:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:08 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:08 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:08 --> URI Class Initialized
INFO - 2018-03-26 23:27:08 --> URI Class Initialized
INFO - 2018-03-26 23:27:08 --> URI Class Initialized
INFO - 2018-03-26 23:27:08 --> Router Class Initialized
INFO - 2018-03-26 23:27:08 --> Router Class Initialized
INFO - 2018-03-26 23:27:08 --> Router Class Initialized
INFO - 2018-03-26 23:27:08 --> Output Class Initialized
INFO - 2018-03-26 23:27:08 --> Output Class Initialized
INFO - 2018-03-26 23:27:08 --> Security Class Initialized
INFO - 2018-03-26 23:27:08 --> Security Class Initialized
INFO - 2018-03-26 23:27:08 --> Output Class Initialized
DEBUG - 2018-03-26 23:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-26 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:08 --> Input Class Initialized
INFO - 2018-03-26 23:27:08 --> Security Class Initialized
INFO - 2018-03-26 23:27:08 --> Input Class Initialized
INFO - 2018-03-26 23:27:08 --> Language Class Initialized
INFO - 2018-03-26 23:27:08 --> Language Class Initialized
DEBUG - 2018-03-26 23:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:08 --> Input Class Initialized
INFO - 2018-03-26 23:27:08 --> Language Class Initialized
ERROR - 2018-03-26 23:27:08 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-26 23:27:08 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-26 23:27:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-26 23:27:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-26 23:27:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-26 23:27:16 --> Config Class Initialized
INFO - 2018-03-26 23:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:27:16 --> Utf8 Class Initialized
INFO - 2018-03-26 23:27:16 --> URI Class Initialized
INFO - 2018-03-26 23:27:16 --> Router Class Initialized
INFO - 2018-03-26 23:27:16 --> Output Class Initialized
INFO - 2018-03-26 23:27:16 --> Security Class Initialized
DEBUG - 2018-03-26 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:27:16 --> Input Class Initialized
INFO - 2018-03-26 23:27:16 --> Language Class Initialized
INFO - 2018-03-26 23:27:16 --> Loader Class Initialized
INFO - 2018-03-26 23:27:16 --> Helper loaded: url_helper
INFO - 2018-03-26 23:27:16 --> Helper loaded: form_helper
INFO - 2018-03-26 23:27:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:27:16 --> Form Validation Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
INFO - 2018-03-26 23:27:16 --> Controller Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
INFO - 2018-03-26 23:27:16 --> Model Class Initialized
DEBUG - 2018-03-26 23:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:29:31 --> Config Class Initialized
INFO - 2018-03-26 23:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:31 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:31 --> URI Class Initialized
INFO - 2018-03-26 23:29:31 --> Router Class Initialized
INFO - 2018-03-26 23:29:31 --> Output Class Initialized
INFO - 2018-03-26 23:29:31 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:31 --> Input Class Initialized
INFO - 2018-03-26 23:29:31 --> Language Class Initialized
INFO - 2018-03-26 23:29:31 --> Loader Class Initialized
INFO - 2018-03-26 23:29:31 --> Helper loaded: url_helper
INFO - 2018-03-26 23:29:31 --> Helper loaded: form_helper
INFO - 2018-03-26 23:29:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:29:31 --> Form Validation Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Controller Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:29:31 --> Final output sent to browser
DEBUG - 2018-03-26 23:29:31 --> Total execution time: 0.0560
INFO - 2018-03-26 23:29:31 --> Config Class Initialized
INFO - 2018-03-26 23:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:31 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:31 --> URI Class Initialized
INFO - 2018-03-26 23:29:31 --> Router Class Initialized
INFO - 2018-03-26 23:29:31 --> Output Class Initialized
INFO - 2018-03-26 23:29:31 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:31 --> Input Class Initialized
INFO - 2018-03-26 23:29:31 --> Language Class Initialized
INFO - 2018-03-26 23:29:31 --> Loader Class Initialized
INFO - 2018-03-26 23:29:31 --> Helper loaded: url_helper
INFO - 2018-03-26 23:29:31 --> Helper loaded: form_helper
INFO - 2018-03-26 23:29:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:29:31 --> Form Validation Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Controller Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
INFO - 2018-03-26 23:29:31 --> Model Class Initialized
DEBUG - 2018-03-26 23:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:29:31 --> Final output sent to browser
DEBUG - 2018-03-26 23:29:31 --> Total execution time: 0.0476
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Loader Class Initialized
INFO - 2018-03-26 23:29:54 --> Helper loaded: url_helper
INFO - 2018-03-26 23:29:54 --> Helper loaded: form_helper
INFO - 2018-03-26 23:29:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:29:54 --> Form Validation Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Controller Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:29:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-26 23:29:54 --> Final output sent to browser
DEBUG - 2018-03-26 23:29:54 --> Total execution time: 0.0694
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
ERROR - 2018-03-26 23:29:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-26 23:29:54 --> Config Class Initialized
INFO - 2018-03-26 23:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:54 --> URI Class Initialized
INFO - 2018-03-26 23:29:54 --> Router Class Initialized
INFO - 2018-03-26 23:29:54 --> Output Class Initialized
INFO - 2018-03-26 23:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:54 --> Input Class Initialized
INFO - 2018-03-26 23:29:54 --> Language Class Initialized
INFO - 2018-03-26 23:29:54 --> Loader Class Initialized
INFO - 2018-03-26 23:29:54 --> Helper loaded: url_helper
INFO - 2018-03-26 23:29:54 --> Helper loaded: form_helper
INFO - 2018-03-26 23:29:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:29:54 --> Form Validation Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Controller Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
INFO - 2018-03-26 23:29:54 --> Model Class Initialized
DEBUG - 2018-03-26 23:29:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:29:59 --> Config Class Initialized
INFO - 2018-03-26 23:29:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:29:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:29:59 --> Utf8 Class Initialized
INFO - 2018-03-26 23:29:59 --> URI Class Initialized
INFO - 2018-03-26 23:29:59 --> Router Class Initialized
INFO - 2018-03-26 23:29:59 --> Output Class Initialized
INFO - 2018-03-26 23:29:59 --> Security Class Initialized
DEBUG - 2018-03-26 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:29:59 --> Input Class Initialized
INFO - 2018-03-26 23:29:59 --> Language Class Initialized
INFO - 2018-03-26 23:29:59 --> Loader Class Initialized
INFO - 2018-03-26 23:29:59 --> Helper loaded: url_helper
INFO - 2018-03-26 23:29:59 --> Helper loaded: form_helper
INFO - 2018-03-26 23:29:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:29:59 --> Form Validation Class Initialized
INFO - 2018-03-26 23:29:59 --> Model Class Initialized
INFO - 2018-03-26 23:29:59 --> Controller Class Initialized
INFO - 2018-03-26 23:29:59 --> Model Class Initialized
INFO - 2018-03-26 23:29:59 --> Model Class Initialized
INFO - 2018-03-26 23:29:59 --> Model Class Initialized
INFO - 2018-03-26 23:29:59 --> Model Class Initialized
DEBUG - 2018-03-26 23:29:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:30:00 --> Final output sent to browser
DEBUG - 2018-03-26 23:30:00 --> Total execution time: 0.9391
INFO - 2018-03-26 23:30:12 --> Config Class Initialized
INFO - 2018-03-26 23:30:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 23:30:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 23:30:12 --> Utf8 Class Initialized
INFO - 2018-03-26 23:30:12 --> URI Class Initialized
INFO - 2018-03-26 23:30:12 --> Router Class Initialized
INFO - 2018-03-26 23:30:12 --> Output Class Initialized
INFO - 2018-03-26 23:30:12 --> Security Class Initialized
DEBUG - 2018-03-26 23:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 23:30:12 --> Input Class Initialized
INFO - 2018-03-26 23:30:12 --> Language Class Initialized
INFO - 2018-03-26 23:30:12 --> Loader Class Initialized
INFO - 2018-03-26 23:30:12 --> Helper loaded: url_helper
INFO - 2018-03-26 23:30:12 --> Helper loaded: form_helper
INFO - 2018-03-26 23:30:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 23:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 23:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 23:30:12 --> Form Validation Class Initialized
INFO - 2018-03-26 23:30:12 --> Model Class Initialized
INFO - 2018-03-26 23:30:12 --> Controller Class Initialized
INFO - 2018-03-26 23:30:12 --> Model Class Initialized
INFO - 2018-03-26 23:30:12 --> Model Class Initialized
INFO - 2018-03-26 23:30:12 --> Model Class Initialized
INFO - 2018-03-26 23:30:12 --> Model Class Initialized
DEBUG - 2018-03-26 23:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-26 23:30:12 --> Final output sent to browser
DEBUG - 2018-03-26 23:30:12 --> Total execution time: 0.1549
