<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-25 05:31:06 --> Config Class Initialized
INFO - 2018-01-25 05:31:06 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:06 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:06 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:06 --> URI Class Initialized
INFO - 2018-01-25 05:31:06 --> Router Class Initialized
INFO - 2018-01-25 05:31:06 --> Output Class Initialized
INFO - 2018-01-25 05:31:06 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:06 --> Input Class Initialized
INFO - 2018-01-25 05:31:06 --> Language Class Initialized
INFO - 2018-01-25 05:31:06 --> Loader Class Initialized
INFO - 2018-01-25 05:31:06 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:06 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:06 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:06 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:06 --> Model Class Initialized
INFO - 2018-01-25 05:31:06 --> Controller Class Initialized
INFO - 2018-01-25 05:31:06 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:06 --> Config Class Initialized
INFO - 2018-01-25 05:31:06 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:06 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:06 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:06 --> URI Class Initialized
INFO - 2018-01-25 05:31:06 --> Router Class Initialized
INFO - 2018-01-25 05:31:06 --> Output Class Initialized
INFO - 2018-01-25 05:31:06 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:06 --> Input Class Initialized
INFO - 2018-01-25 05:31:06 --> Language Class Initialized
INFO - 2018-01-25 05:31:06 --> Loader Class Initialized
INFO - 2018-01-25 05:31:06 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:06 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:06 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:06 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:06 --> Model Class Initialized
INFO - 2018-01-25 05:31:06 --> Controller Class Initialized
INFO - 2018-01-25 05:31:06 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:06 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:06 --> Total execution time: 0.1085
INFO - 2018-01-25 05:31:09 --> Config Class Initialized
INFO - 2018-01-25 05:31:09 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:09 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:09 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:09 --> URI Class Initialized
INFO - 2018-01-25 05:31:09 --> Router Class Initialized
INFO - 2018-01-25 05:31:09 --> Output Class Initialized
INFO - 2018-01-25 05:31:09 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:09 --> Input Class Initialized
INFO - 2018-01-25 05:31:09 --> Language Class Initialized
INFO - 2018-01-25 05:31:09 --> Loader Class Initialized
INFO - 2018-01-25 05:31:09 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:09 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:09 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:09 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Controller Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-25 05:31:09 --> Config Class Initialized
INFO - 2018-01-25 05:31:09 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:09 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:09 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:09 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:09 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:09 --> Router Class Initialized
INFO - 2018-01-25 05:31:09 --> Output Class Initialized
INFO - 2018-01-25 05:31:09 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:09 --> Input Class Initialized
INFO - 2018-01-25 05:31:09 --> Language Class Initialized
INFO - 2018-01-25 05:31:09 --> Loader Class Initialized
INFO - 2018-01-25 05:31:09 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:09 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:09 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:09 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Controller Class Initialized
INFO - 2018-01-25 05:31:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:09 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:09 --> Total execution time: 0.0837
INFO - 2018-01-25 05:31:09 --> Config Class Initialized
INFO - 2018-01-25 05:31:09 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:09 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:09 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:09 --> URI Class Initialized
INFO - 2018-01-25 05:31:09 --> Router Class Initialized
INFO - 2018-01-25 05:31:09 --> Output Class Initialized
INFO - 2018-01-25 05:31:09 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:09 --> Input Class Initialized
INFO - 2018-01-25 05:31:09 --> Language Class Initialized
INFO - 2018-01-25 05:31:09 --> Loader Class Initialized
INFO - 2018-01-25 05:31:09 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:09 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:09 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:09 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Controller Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
INFO - 2018-01-25 05:31:09 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:12 --> Config Class Initialized
INFO - 2018-01-25 05:31:12 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:12 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:12 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:12 --> URI Class Initialized
INFO - 2018-01-25 05:31:12 --> Router Class Initialized
INFO - 2018-01-25 05:31:12 --> Output Class Initialized
INFO - 2018-01-25 05:31:12 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:12 --> Input Class Initialized
INFO - 2018-01-25 05:31:12 --> Language Class Initialized
INFO - 2018-01-25 05:31:12 --> Loader Class Initialized
INFO - 2018-01-25 05:31:12 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:12 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:12 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:12 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:12 --> Model Class Initialized
INFO - 2018-01-25 05:31:12 --> Controller Class Initialized
INFO - 2018-01-25 05:31:12 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:12 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:12 --> Total execution time: 0.0379
INFO - 2018-01-25 05:31:12 --> Config Class Initialized
INFO - 2018-01-25 05:31:12 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:12 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:12 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:12 --> URI Class Initialized
INFO - 2018-01-25 05:31:12 --> Router Class Initialized
INFO - 2018-01-25 05:31:12 --> Output Class Initialized
INFO - 2018-01-25 05:31:12 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:12 --> Input Class Initialized
INFO - 2018-01-25 05:31:12 --> Language Class Initialized
INFO - 2018-01-25 05:31:12 --> Loader Class Initialized
INFO - 2018-01-25 05:31:12 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:12 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:12 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:12 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:12 --> Model Class Initialized
INFO - 2018-01-25 05:31:12 --> Controller Class Initialized
INFO - 2018-01-25 05:31:12 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:19 --> Config Class Initialized
INFO - 2018-01-25 05:31:19 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:19 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:19 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:19 --> URI Class Initialized
INFO - 2018-01-25 05:31:19 --> Router Class Initialized
INFO - 2018-01-25 05:31:19 --> Output Class Initialized
INFO - 2018-01-25 05:31:19 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:19 --> Input Class Initialized
INFO - 2018-01-25 05:31:19 --> Language Class Initialized
INFO - 2018-01-25 05:31:19 --> Loader Class Initialized
INFO - 2018-01-25 05:31:19 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:19 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:19 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:19 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:19 --> Model Class Initialized
INFO - 2018-01-25 05:31:19 --> Controller Class Initialized
INFO - 2018-01-25 05:31:19 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:19 --> Config Class Initialized
INFO - 2018-01-25 05:31:19 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:19 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:19 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:19 --> URI Class Initialized
INFO - 2018-01-25 05:31:19 --> Router Class Initialized
INFO - 2018-01-25 05:31:19 --> Output Class Initialized
INFO - 2018-01-25 05:31:19 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:19 --> Input Class Initialized
INFO - 2018-01-25 05:31:19 --> Language Class Initialized
INFO - 2018-01-25 05:31:19 --> Loader Class Initialized
INFO - 2018-01-25 05:31:19 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:19 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:19 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:19 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:19 --> Model Class Initialized
INFO - 2018-01-25 05:31:19 --> Controller Class Initialized
INFO - 2018-01-25 05:31:19 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:19 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:19 --> Total execution time: 0.0513
INFO - 2018-01-25 05:31:23 --> Config Class Initialized
INFO - 2018-01-25 05:31:23 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:23 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:23 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:23 --> URI Class Initialized
INFO - 2018-01-25 05:31:23 --> Router Class Initialized
INFO - 2018-01-25 05:31:23 --> Output Class Initialized
INFO - 2018-01-25 05:31:23 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:23 --> Input Class Initialized
INFO - 2018-01-25 05:31:23 --> Language Class Initialized
INFO - 2018-01-25 05:31:23 --> Loader Class Initialized
INFO - 2018-01-25 05:31:23 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:23 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:23 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:23 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:23 --> Model Class Initialized
INFO - 2018-01-25 05:31:23 --> Controller Class Initialized
INFO - 2018-01-25 05:31:23 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-25 05:31:24 --> Config Class Initialized
INFO - 2018-01-25 05:31:24 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:24 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:24 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:24 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:24 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:24 --> Router Class Initialized
INFO - 2018-01-25 05:31:24 --> Output Class Initialized
INFO - 2018-01-25 05:31:24 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:24 --> Input Class Initialized
INFO - 2018-01-25 05:31:24 --> Language Class Initialized
INFO - 2018-01-25 05:31:24 --> Loader Class Initialized
INFO - 2018-01-25 05:31:24 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:24 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:24 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:24 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
INFO - 2018-01-25 05:31:24 --> Controller Class Initialized
INFO - 2018-01-25 05:31:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:24 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:24 --> Total execution time: 0.0478
INFO - 2018-01-25 05:31:24 --> Config Class Initialized
INFO - 2018-01-25 05:31:24 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:24 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:24 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:24 --> URI Class Initialized
INFO - 2018-01-25 05:31:24 --> Router Class Initialized
INFO - 2018-01-25 05:31:24 --> Output Class Initialized
INFO - 2018-01-25 05:31:24 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:24 --> Input Class Initialized
INFO - 2018-01-25 05:31:24 --> Language Class Initialized
INFO - 2018-01-25 05:31:24 --> Loader Class Initialized
INFO - 2018-01-25 05:31:24 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:24 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:24 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:24 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
INFO - 2018-01-25 05:31:24 --> Controller Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
INFO - 2018-01-25 05:31:24 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:30 --> Config Class Initialized
INFO - 2018-01-25 05:31:30 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:30 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:30 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:30 --> URI Class Initialized
INFO - 2018-01-25 05:31:30 --> Router Class Initialized
INFO - 2018-01-25 05:31:30 --> Output Class Initialized
INFO - 2018-01-25 05:31:30 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:30 --> Input Class Initialized
INFO - 2018-01-25 05:31:30 --> Language Class Initialized
INFO - 2018-01-25 05:31:30 --> Loader Class Initialized
INFO - 2018-01-25 05:31:30 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:30 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:30 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:30 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
INFO - 2018-01-25 05:31:30 --> Controller Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:30 --> Config Class Initialized
INFO - 2018-01-25 05:31:30 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:30 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:30 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:30 --> URI Class Initialized
INFO - 2018-01-25 05:31:30 --> Router Class Initialized
INFO - 2018-01-25 05:31:30 --> Output Class Initialized
INFO - 2018-01-25 05:31:30 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:30 --> Input Class Initialized
INFO - 2018-01-25 05:31:30 --> Language Class Initialized
INFO - 2018-01-25 05:31:30 --> Loader Class Initialized
INFO - 2018-01-25 05:31:30 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:30 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:30 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:30 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:30 --> Model Class Initialized
INFO - 2018-01-25 05:31:30 --> Controller Class Initialized
INFO - 2018-01-25 05:31:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:30 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:30 --> Total execution time: 0.0769
INFO - 2018-01-25 05:31:31 --> Config Class Initialized
INFO - 2018-01-25 05:31:31 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:31 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:31 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:31 --> URI Class Initialized
INFO - 2018-01-25 05:31:31 --> Router Class Initialized
INFO - 2018-01-25 05:31:31 --> Output Class Initialized
INFO - 2018-01-25 05:31:31 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:31 --> Input Class Initialized
INFO - 2018-01-25 05:31:31 --> Language Class Initialized
INFO - 2018-01-25 05:31:31 --> Loader Class Initialized
INFO - 2018-01-25 05:31:31 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:31 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:31 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:31 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
INFO - 2018-01-25 05:31:31 --> Controller Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:31 --> Config Class Initialized
INFO - 2018-01-25 05:31:31 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:31 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:31 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:31 --> URI Class Initialized
INFO - 2018-01-25 05:31:31 --> Router Class Initialized
INFO - 2018-01-25 05:31:31 --> Output Class Initialized
INFO - 2018-01-25 05:31:31 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:31 --> Input Class Initialized
INFO - 2018-01-25 05:31:31 --> Language Class Initialized
INFO - 2018-01-25 05:31:31 --> Loader Class Initialized
INFO - 2018-01-25 05:31:31 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:31 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:31 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:31 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:31 --> Model Class Initialized
INFO - 2018-01-25 05:31:31 --> Controller Class Initialized
INFO - 2018-01-25 05:31:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:31 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:31 --> Total execution time: 0.0475
INFO - 2018-01-25 05:31:33 --> Config Class Initialized
INFO - 2018-01-25 05:31:33 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:33 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:33 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:33 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:33 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:33 --> Router Class Initialized
INFO - 2018-01-25 05:31:33 --> Output Class Initialized
INFO - 2018-01-25 05:31:33 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:33 --> Input Class Initialized
INFO - 2018-01-25 05:31:33 --> Language Class Initialized
INFO - 2018-01-25 05:31:33 --> Loader Class Initialized
INFO - 2018-01-25 05:31:33 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:33 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:33 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:33 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
INFO - 2018-01-25 05:31:33 --> Controller Class Initialized
INFO - 2018-01-25 05:31:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:33 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:33 --> Total execution time: 0.0526
INFO - 2018-01-25 05:31:33 --> Config Class Initialized
INFO - 2018-01-25 05:31:33 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:33 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:33 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:33 --> URI Class Initialized
INFO - 2018-01-25 05:31:33 --> Router Class Initialized
INFO - 2018-01-25 05:31:33 --> Output Class Initialized
INFO - 2018-01-25 05:31:33 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:33 --> Input Class Initialized
INFO - 2018-01-25 05:31:33 --> Language Class Initialized
INFO - 2018-01-25 05:31:33 --> Loader Class Initialized
INFO - 2018-01-25 05:31:33 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:33 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:33 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:33 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
INFO - 2018-01-25 05:31:33 --> Controller Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
INFO - 2018-01-25 05:31:33 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:34 --> Config Class Initialized
INFO - 2018-01-25 05:31:34 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:34 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:34 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:34 --> URI Class Initialized
INFO - 2018-01-25 05:31:34 --> Router Class Initialized
INFO - 2018-01-25 05:31:34 --> Output Class Initialized
INFO - 2018-01-25 05:31:34 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:34 --> Input Class Initialized
INFO - 2018-01-25 05:31:34 --> Language Class Initialized
INFO - 2018-01-25 05:31:34 --> Loader Class Initialized
INFO - 2018-01-25 05:31:34 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:34 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:34 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:34 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
INFO - 2018-01-25 05:31:34 --> Controller Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:34 --> Config Class Initialized
INFO - 2018-01-25 05:31:34 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:34 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:34 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:34 --> URI Class Initialized
INFO - 2018-01-25 05:31:34 --> Router Class Initialized
INFO - 2018-01-25 05:31:34 --> Output Class Initialized
INFO - 2018-01-25 05:31:34 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:34 --> Input Class Initialized
INFO - 2018-01-25 05:31:34 --> Language Class Initialized
INFO - 2018-01-25 05:31:34 --> Loader Class Initialized
INFO - 2018-01-25 05:31:34 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:34 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:34 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:34 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:34 --> Model Class Initialized
INFO - 2018-01-25 05:31:34 --> Controller Class Initialized
INFO - 2018-01-25 05:31:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:34 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:34 --> Total execution time: 0.0604
INFO - 2018-01-25 05:31:35 --> Config Class Initialized
INFO - 2018-01-25 05:31:35 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:35 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:35 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:35 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:35 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:35 --> Router Class Initialized
INFO - 2018-01-25 05:31:35 --> Output Class Initialized
INFO - 2018-01-25 05:31:35 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:35 --> Input Class Initialized
INFO - 2018-01-25 05:31:35 --> Language Class Initialized
INFO - 2018-01-25 05:31:35 --> Loader Class Initialized
INFO - 2018-01-25 05:31:35 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:35 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:35 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:35 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
INFO - 2018-01-25 05:31:35 --> Controller Class Initialized
INFO - 2018-01-25 05:31:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:35 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:35 --> Total execution time: 0.0548
INFO - 2018-01-25 05:31:35 --> Config Class Initialized
INFO - 2018-01-25 05:31:35 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:35 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:35 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:35 --> URI Class Initialized
INFO - 2018-01-25 05:31:35 --> Router Class Initialized
INFO - 2018-01-25 05:31:35 --> Output Class Initialized
INFO - 2018-01-25 05:31:35 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:35 --> Input Class Initialized
INFO - 2018-01-25 05:31:35 --> Language Class Initialized
INFO - 2018-01-25 05:31:35 --> Loader Class Initialized
INFO - 2018-01-25 05:31:35 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:35 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:35 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:35 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
INFO - 2018-01-25 05:31:35 --> Controller Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
INFO - 2018-01-25 05:31:35 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:36 --> Config Class Initialized
INFO - 2018-01-25 05:31:36 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:36 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:36 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:36 --> URI Class Initialized
INFO - 2018-01-25 05:31:36 --> Router Class Initialized
INFO - 2018-01-25 05:31:36 --> Output Class Initialized
INFO - 2018-01-25 05:31:36 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:36 --> Input Class Initialized
INFO - 2018-01-25 05:31:36 --> Language Class Initialized
INFO - 2018-01-25 05:31:36 --> Loader Class Initialized
INFO - 2018-01-25 05:31:36 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:36 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:36 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:36 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
INFO - 2018-01-25 05:31:36 --> Controller Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:36 --> Config Class Initialized
INFO - 2018-01-25 05:31:36 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:36 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:36 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:36 --> URI Class Initialized
INFO - 2018-01-25 05:31:36 --> Router Class Initialized
INFO - 2018-01-25 05:31:36 --> Output Class Initialized
INFO - 2018-01-25 05:31:36 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:36 --> Input Class Initialized
INFO - 2018-01-25 05:31:36 --> Language Class Initialized
INFO - 2018-01-25 05:31:36 --> Loader Class Initialized
INFO - 2018-01-25 05:31:36 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:36 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:36 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:36 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:36 --> Model Class Initialized
INFO - 2018-01-25 05:31:36 --> Controller Class Initialized
INFO - 2018-01-25 05:31:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:36 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:36 --> Total execution time: 0.0704
INFO - 2018-01-25 05:31:37 --> Config Class Initialized
INFO - 2018-01-25 05:31:37 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:37 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:37 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:37 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:37 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:37 --> Router Class Initialized
INFO - 2018-01-25 05:31:37 --> Output Class Initialized
INFO - 2018-01-25 05:31:37 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:37 --> Input Class Initialized
INFO - 2018-01-25 05:31:37 --> Language Class Initialized
INFO - 2018-01-25 05:31:37 --> Loader Class Initialized
INFO - 2018-01-25 05:31:37 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:37 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:37 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:37 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
INFO - 2018-01-25 05:31:37 --> Controller Class Initialized
INFO - 2018-01-25 05:31:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:37 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:37 --> Total execution time: 0.0484
INFO - 2018-01-25 05:31:37 --> Config Class Initialized
INFO - 2018-01-25 05:31:37 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:37 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:37 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:37 --> URI Class Initialized
INFO - 2018-01-25 05:31:37 --> Router Class Initialized
INFO - 2018-01-25 05:31:37 --> Output Class Initialized
INFO - 2018-01-25 05:31:37 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:37 --> Input Class Initialized
INFO - 2018-01-25 05:31:37 --> Language Class Initialized
INFO - 2018-01-25 05:31:37 --> Loader Class Initialized
INFO - 2018-01-25 05:31:37 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:37 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:37 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:37 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
INFO - 2018-01-25 05:31:37 --> Controller Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
INFO - 2018-01-25 05:31:37 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:39 --> Config Class Initialized
INFO - 2018-01-25 05:31:39 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:39 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:39 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:39 --> URI Class Initialized
INFO - 2018-01-25 05:31:39 --> Router Class Initialized
INFO - 2018-01-25 05:31:39 --> Output Class Initialized
INFO - 2018-01-25 05:31:39 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:39 --> Input Class Initialized
INFO - 2018-01-25 05:31:39 --> Language Class Initialized
INFO - 2018-01-25 05:31:39 --> Loader Class Initialized
INFO - 2018-01-25 05:31:39 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:39 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:39 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:39 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:39 --> Model Class Initialized
INFO - 2018-01-25 05:31:39 --> Controller Class Initialized
INFO - 2018-01-25 05:31:39 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:39 --> Config Class Initialized
INFO - 2018-01-25 05:31:39 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:39 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:39 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:39 --> URI Class Initialized
INFO - 2018-01-25 05:31:39 --> Router Class Initialized
INFO - 2018-01-25 05:31:39 --> Output Class Initialized
INFO - 2018-01-25 05:31:39 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:39 --> Input Class Initialized
INFO - 2018-01-25 05:31:39 --> Language Class Initialized
INFO - 2018-01-25 05:31:39 --> Loader Class Initialized
INFO - 2018-01-25 05:31:39 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:39 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:39 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:39 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:39 --> Model Class Initialized
INFO - 2018-01-25 05:31:39 --> Controller Class Initialized
INFO - 2018-01-25 05:31:39 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:39 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:39 --> Total execution time: 0.0578
INFO - 2018-01-25 05:31:43 --> Config Class Initialized
INFO - 2018-01-25 05:31:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:43 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:43 --> URI Class Initialized
INFO - 2018-01-25 05:31:43 --> Router Class Initialized
INFO - 2018-01-25 05:31:43 --> Output Class Initialized
INFO - 2018-01-25 05:31:43 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:43 --> Input Class Initialized
INFO - 2018-01-25 05:31:43 --> Language Class Initialized
INFO - 2018-01-25 05:31:43 --> Loader Class Initialized
INFO - 2018-01-25 05:31:43 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:43 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:43 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Controller Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 05:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-25 05:31:43 --> Config Class Initialized
INFO - 2018-01-25 05:31:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:43 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:43 --> URI Class Initialized
DEBUG - 2018-01-25 05:31:43 --> No URI present. Default controller set.
INFO - 2018-01-25 05:31:43 --> Router Class Initialized
INFO - 2018-01-25 05:31:43 --> Output Class Initialized
INFO - 2018-01-25 05:31:43 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:43 --> Input Class Initialized
INFO - 2018-01-25 05:31:43 --> Language Class Initialized
INFO - 2018-01-25 05:31:43 --> Loader Class Initialized
INFO - 2018-01-25 05:31:43 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:43 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:43 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Controller Class Initialized
INFO - 2018-01-25 05:31:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 05:31:43 --> Final output sent to browser
DEBUG - 2018-01-25 05:31:43 --> Total execution time: 0.0787
INFO - 2018-01-25 05:31:43 --> Config Class Initialized
INFO - 2018-01-25 05:31:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 05:31:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 05:31:43 --> Utf8 Class Initialized
INFO - 2018-01-25 05:31:43 --> URI Class Initialized
INFO - 2018-01-25 05:31:43 --> Router Class Initialized
INFO - 2018-01-25 05:31:43 --> Output Class Initialized
INFO - 2018-01-25 05:31:43 --> Security Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 05:31:43 --> Input Class Initialized
INFO - 2018-01-25 05:31:43 --> Language Class Initialized
INFO - 2018-01-25 05:31:43 --> Loader Class Initialized
INFO - 2018-01-25 05:31:43 --> Helper loaded: url_helper
INFO - 2018-01-25 05:31:43 --> Helper loaded: form_helper
INFO - 2018-01-25 05:31:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 05:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 05:31:43 --> Form Validation Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Controller Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
INFO - 2018-01-25 05:31:43 --> Model Class Initialized
DEBUG - 2018-01-25 05:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 07:04:58 --> Config Class Initialized
INFO - 2018-01-25 07:04:58 --> Hooks Class Initialized
DEBUG - 2018-01-25 07:04:58 --> UTF-8 Support Enabled
INFO - 2018-01-25 07:04:58 --> Utf8 Class Initialized
INFO - 2018-01-25 07:04:58 --> URI Class Initialized
DEBUG - 2018-01-25 07:04:58 --> No URI present. Default controller set.
INFO - 2018-01-25 07:04:58 --> Router Class Initialized
INFO - 2018-01-25 07:04:58 --> Output Class Initialized
INFO - 2018-01-25 07:04:58 --> Security Class Initialized
DEBUG - 2018-01-25 07:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 07:04:58 --> Input Class Initialized
INFO - 2018-01-25 07:04:58 --> Language Class Initialized
INFO - 2018-01-25 07:04:58 --> Loader Class Initialized
INFO - 2018-01-25 07:04:58 --> Helper loaded: url_helper
INFO - 2018-01-25 07:04:58 --> Helper loaded: form_helper
INFO - 2018-01-25 07:04:58 --> Database Driver Class Initialized
DEBUG - 2018-01-25 07:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 07:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 07:04:58 --> Form Validation Class Initialized
INFO - 2018-01-25 07:04:58 --> Model Class Initialized
INFO - 2018-01-25 07:04:58 --> Controller Class Initialized
INFO - 2018-01-25 07:04:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 07:04:58 --> Final output sent to browser
DEBUG - 2018-01-25 07:04:58 --> Total execution time: 0.1061
INFO - 2018-01-25 07:05:01 --> Config Class Initialized
INFO - 2018-01-25 07:05:01 --> Hooks Class Initialized
DEBUG - 2018-01-25 07:05:01 --> UTF-8 Support Enabled
INFO - 2018-01-25 07:05:01 --> Utf8 Class Initialized
INFO - 2018-01-25 07:05:01 --> URI Class Initialized
INFO - 2018-01-25 07:05:01 --> Router Class Initialized
INFO - 2018-01-25 07:05:01 --> Output Class Initialized
INFO - 2018-01-25 07:05:01 --> Security Class Initialized
DEBUG - 2018-01-25 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 07:05:01 --> Input Class Initialized
INFO - 2018-01-25 07:05:01 --> Language Class Initialized
INFO - 2018-01-25 07:05:01 --> Loader Class Initialized
INFO - 2018-01-25 07:05:01 --> Helper loaded: url_helper
INFO - 2018-01-25 07:05:01 --> Helper loaded: form_helper
INFO - 2018-01-25 07:05:01 --> Database Driver Class Initialized
DEBUG - 2018-01-25 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 07:05:01 --> Form Validation Class Initialized
INFO - 2018-01-25 07:05:01 --> Model Class Initialized
INFO - 2018-01-25 07:05:01 --> Controller Class Initialized
INFO - 2018-01-25 07:05:01 --> Model Class Initialized
INFO - 2018-01-25 07:05:01 --> Model Class Initialized
INFO - 2018-01-25 07:05:01 --> Model Class Initialized
INFO - 2018-01-25 07:05:01 --> Model Class Initialized
DEBUG - 2018-01-25 07:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:07:32 --> Config Class Initialized
INFO - 2018-01-25 08:07:32 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:07:32 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:07:32 --> Utf8 Class Initialized
INFO - 2018-01-25 08:07:32 --> URI Class Initialized
INFO - 2018-01-25 08:07:32 --> Router Class Initialized
INFO - 2018-01-25 08:07:32 --> Output Class Initialized
INFO - 2018-01-25 08:07:32 --> Security Class Initialized
DEBUG - 2018-01-25 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:07:32 --> Input Class Initialized
INFO - 2018-01-25 08:07:32 --> Language Class Initialized
INFO - 2018-01-25 08:07:32 --> Loader Class Initialized
INFO - 2018-01-25 08:07:32 --> Helper loaded: url_helper
INFO - 2018-01-25 08:07:32 --> Helper loaded: form_helper
INFO - 2018-01-25 08:07:33 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:07:33 --> Form Validation Class Initialized
INFO - 2018-01-25 08:07:33 --> Model Class Initialized
INFO - 2018-01-25 08:07:33 --> Controller Class Initialized
INFO - 2018-01-25 08:07:33 --> Model Class Initialized
DEBUG - 2018-01-25 08:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:07:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:07:33 --> Final output sent to browser
DEBUG - 2018-01-25 08:07:33 --> Total execution time: 0.4491
INFO - 2018-01-25 08:07:33 --> Config Class Initialized
INFO - 2018-01-25 08:07:33 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:07:33 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:07:33 --> Utf8 Class Initialized
INFO - 2018-01-25 08:07:33 --> URI Class Initialized
INFO - 2018-01-25 08:07:33 --> Router Class Initialized
INFO - 2018-01-25 08:07:33 --> Output Class Initialized
INFO - 2018-01-25 08:07:33 --> Security Class Initialized
DEBUG - 2018-01-25 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:07:33 --> Input Class Initialized
INFO - 2018-01-25 08:07:33 --> Language Class Initialized
INFO - 2018-01-25 08:07:33 --> Loader Class Initialized
INFO - 2018-01-25 08:07:33 --> Helper loaded: url_helper
INFO - 2018-01-25 08:07:33 --> Helper loaded: form_helper
INFO - 2018-01-25 08:07:33 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:07:33 --> Form Validation Class Initialized
INFO - 2018-01-25 08:07:33 --> Model Class Initialized
INFO - 2018-01-25 08:07:33 --> Controller Class Initialized
INFO - 2018-01-25 08:07:33 --> Model Class Initialized
DEBUG - 2018-01-25 08:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:07:34 --> Config Class Initialized
INFO - 2018-01-25 08:07:34 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:07:34 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:07:34 --> Utf8 Class Initialized
INFO - 2018-01-25 08:07:34 --> URI Class Initialized
INFO - 2018-01-25 08:07:34 --> Router Class Initialized
INFO - 2018-01-25 08:07:34 --> Output Class Initialized
INFO - 2018-01-25 08:07:34 --> Security Class Initialized
DEBUG - 2018-01-25 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:07:34 --> Input Class Initialized
INFO - 2018-01-25 08:07:34 --> Language Class Initialized
ERROR - 2018-01-25 08:07:34 --> 404 Page Not Found: Usuario/editarUsuario
INFO - 2018-01-25 08:07:35 --> Config Class Initialized
INFO - 2018-01-25 08:07:35 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:07:35 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:07:35 --> Utf8 Class Initialized
INFO - 2018-01-25 08:07:35 --> URI Class Initialized
INFO - 2018-01-25 08:07:35 --> Router Class Initialized
INFO - 2018-01-25 08:07:35 --> Output Class Initialized
INFO - 2018-01-25 08:07:35 --> Security Class Initialized
DEBUG - 2018-01-25 08:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:07:35 --> Input Class Initialized
INFO - 2018-01-25 08:07:35 --> Language Class Initialized
INFO - 2018-01-25 08:07:35 --> Loader Class Initialized
INFO - 2018-01-25 08:07:35 --> Helper loaded: url_helper
INFO - 2018-01-25 08:07:35 --> Helper loaded: form_helper
INFO - 2018-01-25 08:07:35 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:07:35 --> Form Validation Class Initialized
INFO - 2018-01-25 08:07:35 --> Model Class Initialized
INFO - 2018-01-25 08:07:35 --> Controller Class Initialized
INFO - 2018-01-25 08:07:35 --> Model Class Initialized
DEBUG - 2018-01-25 08:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:07:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:07:35 --> Final output sent to browser
DEBUG - 2018-01-25 08:07:35 --> Total execution time: 0.0390
INFO - 2018-01-25 08:07:36 --> Config Class Initialized
INFO - 2018-01-25 08:07:36 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:07:36 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:07:36 --> Utf8 Class Initialized
INFO - 2018-01-25 08:07:36 --> URI Class Initialized
INFO - 2018-01-25 08:07:36 --> Router Class Initialized
INFO - 2018-01-25 08:07:36 --> Output Class Initialized
INFO - 2018-01-25 08:07:36 --> Security Class Initialized
DEBUG - 2018-01-25 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:07:36 --> Input Class Initialized
INFO - 2018-01-25 08:07:36 --> Language Class Initialized
INFO - 2018-01-25 08:07:36 --> Loader Class Initialized
INFO - 2018-01-25 08:07:36 --> Helper loaded: url_helper
INFO - 2018-01-25 08:07:36 --> Helper loaded: form_helper
INFO - 2018-01-25 08:07:36 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:07:36 --> Form Validation Class Initialized
INFO - 2018-01-25 08:07:36 --> Model Class Initialized
INFO - 2018-01-25 08:07:36 --> Controller Class Initialized
INFO - 2018-01-25 08:07:36 --> Model Class Initialized
DEBUG - 2018-01-25 08:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:29:43 --> Config Class Initialized
INFO - 2018-01-25 08:29:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:29:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:29:43 --> Utf8 Class Initialized
INFO - 2018-01-25 08:29:43 --> URI Class Initialized
INFO - 2018-01-25 08:29:43 --> Router Class Initialized
INFO - 2018-01-25 08:29:43 --> Output Class Initialized
INFO - 2018-01-25 08:29:43 --> Security Class Initialized
DEBUG - 2018-01-25 08:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:29:43 --> Input Class Initialized
INFO - 2018-01-25 08:29:43 --> Language Class Initialized
INFO - 2018-01-25 08:29:43 --> Loader Class Initialized
INFO - 2018-01-25 08:29:43 --> Helper loaded: url_helper
INFO - 2018-01-25 08:29:43 --> Helper loaded: form_helper
INFO - 2018-01-25 08:29:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:29:43 --> Form Validation Class Initialized
INFO - 2018-01-25 08:29:43 --> Model Class Initialized
INFO - 2018-01-25 08:29:43 --> Controller Class Initialized
INFO - 2018-01-25 08:29:43 --> Model Class Initialized
DEBUG - 2018-01-25 08:29:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-25 08:29:43 --> Query error: Column 'usuario_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario_id` = '1'
INFO - 2018-01-25 08:29:43 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-25 08:30:04 --> Config Class Initialized
INFO - 2018-01-25 08:30:04 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:04 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:04 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:04 --> URI Class Initialized
INFO - 2018-01-25 08:30:04 --> Router Class Initialized
INFO - 2018-01-25 08:30:04 --> Output Class Initialized
INFO - 2018-01-25 08:30:04 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:04 --> Input Class Initialized
INFO - 2018-01-25 08:30:04 --> Language Class Initialized
INFO - 2018-01-25 08:30:04 --> Loader Class Initialized
INFO - 2018-01-25 08:30:04 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:04 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:04 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:04 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:04 --> Model Class Initialized
INFO - 2018-01-25 08:30:04 --> Controller Class Initialized
INFO - 2018-01-25 08:30:04 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:30:04 --> Final output sent to browser
DEBUG - 2018-01-25 08:30:04 --> Total execution time: 0.1129
INFO - 2018-01-25 08:30:15 --> Config Class Initialized
INFO - 2018-01-25 08:30:15 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:15 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:15 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:15 --> URI Class Initialized
INFO - 2018-01-25 08:30:15 --> Router Class Initialized
INFO - 2018-01-25 08:30:15 --> Output Class Initialized
INFO - 2018-01-25 08:30:15 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:15 --> Input Class Initialized
INFO - 2018-01-25 08:30:15 --> Language Class Initialized
INFO - 2018-01-25 08:30:15 --> Loader Class Initialized
INFO - 2018-01-25 08:30:15 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:15 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:15 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:15 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:15 --> Model Class Initialized
INFO - 2018-01-25 08:30:15 --> Controller Class Initialized
INFO - 2018-01-25 08:30:15 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:30:15 --> Final output sent to browser
DEBUG - 2018-01-25 08:30:15 --> Total execution time: 0.0508
INFO - 2018-01-25 08:30:15 --> Config Class Initialized
INFO - 2018-01-25 08:30:15 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:15 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:15 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:15 --> URI Class Initialized
INFO - 2018-01-25 08:30:15 --> Router Class Initialized
INFO - 2018-01-25 08:30:15 --> Output Class Initialized
INFO - 2018-01-25 08:30:15 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:15 --> Input Class Initialized
INFO - 2018-01-25 08:30:15 --> Language Class Initialized
INFO - 2018-01-25 08:30:15 --> Loader Class Initialized
INFO - 2018-01-25 08:30:15 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:15 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:15 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:15 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:15 --> Model Class Initialized
INFO - 2018-01-25 08:30:15 --> Controller Class Initialized
INFO - 2018-01-25 08:30:15 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:17 --> Config Class Initialized
INFO - 2018-01-25 08:30:17 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:17 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:17 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:17 --> URI Class Initialized
INFO - 2018-01-25 08:30:17 --> Router Class Initialized
INFO - 2018-01-25 08:30:17 --> Output Class Initialized
INFO - 2018-01-25 08:30:17 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:17 --> Input Class Initialized
INFO - 2018-01-25 08:30:17 --> Language Class Initialized
INFO - 2018-01-25 08:30:17 --> Loader Class Initialized
INFO - 2018-01-25 08:30:17 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:17 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:17 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:17 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:17 --> Model Class Initialized
INFO - 2018-01-25 08:30:17 --> Controller Class Initialized
INFO - 2018-01-25 08:30:17 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:30:17 --> Final output sent to browser
DEBUG - 2018-01-25 08:30:17 --> Total execution time: 0.0497
INFO - 2018-01-25 08:30:48 --> Config Class Initialized
INFO - 2018-01-25 08:30:48 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:48 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:48 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:48 --> URI Class Initialized
INFO - 2018-01-25 08:30:48 --> Router Class Initialized
INFO - 2018-01-25 08:30:48 --> Output Class Initialized
INFO - 2018-01-25 08:30:48 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:48 --> Input Class Initialized
INFO - 2018-01-25 08:30:48 --> Language Class Initialized
INFO - 2018-01-25 08:30:48 --> Loader Class Initialized
INFO - 2018-01-25 08:30:48 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:48 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:48 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:48 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:48 --> Model Class Initialized
INFO - 2018-01-25 08:30:48 --> Controller Class Initialized
INFO - 2018-01-25 08:30:48 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:30:48 --> Final output sent to browser
DEBUG - 2018-01-25 08:30:48 --> Total execution time: 0.0502
INFO - 2018-01-25 08:30:58 --> Config Class Initialized
INFO - 2018-01-25 08:30:58 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:58 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:58 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:58 --> URI Class Initialized
INFO - 2018-01-25 08:30:58 --> Router Class Initialized
INFO - 2018-01-25 08:30:58 --> Output Class Initialized
INFO - 2018-01-25 08:30:58 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:58 --> Input Class Initialized
INFO - 2018-01-25 08:30:58 --> Language Class Initialized
INFO - 2018-01-25 08:30:58 --> Loader Class Initialized
INFO - 2018-01-25 08:30:58 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:58 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:58 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:58 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:58 --> Model Class Initialized
INFO - 2018-01-25 08:30:58 --> Controller Class Initialized
INFO - 2018-01-25 08:30:58 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-25 08:30:58 --> Severity: Notice --> Undefined property: Usuario::$m_cliente D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Usuario.php 85
ERROR - 2018-01-25 08:30:58 --> Severity: Error --> Call to a member function actualizar() on null D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Usuario.php 85
INFO - 2018-01-25 08:30:59 --> Config Class Initialized
INFO - 2018-01-25 08:30:59 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:30:59 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:30:59 --> Utf8 Class Initialized
INFO - 2018-01-25 08:30:59 --> URI Class Initialized
INFO - 2018-01-25 08:30:59 --> Router Class Initialized
INFO - 2018-01-25 08:30:59 --> Output Class Initialized
INFO - 2018-01-25 08:30:59 --> Security Class Initialized
DEBUG - 2018-01-25 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:30:59 --> Input Class Initialized
INFO - 2018-01-25 08:30:59 --> Language Class Initialized
INFO - 2018-01-25 08:30:59 --> Loader Class Initialized
INFO - 2018-01-25 08:30:59 --> Helper loaded: url_helper
INFO - 2018-01-25 08:30:59 --> Helper loaded: form_helper
INFO - 2018-01-25 08:30:59 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:30:59 --> Form Validation Class Initialized
INFO - 2018-01-25 08:30:59 --> Model Class Initialized
INFO - 2018-01-25 08:30:59 --> Controller Class Initialized
INFO - 2018-01-25 08:30:59 --> Model Class Initialized
DEBUG - 2018-01-25 08:30:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:30:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:30:59 --> Final output sent to browser
DEBUG - 2018-01-25 08:30:59 --> Total execution time: 0.0389
INFO - 2018-01-25 08:31:02 --> Config Class Initialized
INFO - 2018-01-25 08:31:02 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:02 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:02 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:02 --> URI Class Initialized
INFO - 2018-01-25 08:31:02 --> Router Class Initialized
INFO - 2018-01-25 08:31:02 --> Output Class Initialized
INFO - 2018-01-25 08:31:02 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:02 --> Input Class Initialized
INFO - 2018-01-25 08:31:02 --> Language Class Initialized
INFO - 2018-01-25 08:31:02 --> Loader Class Initialized
INFO - 2018-01-25 08:31:02 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:02 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:02 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:02 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:02 --> Model Class Initialized
INFO - 2018-01-25 08:31:02 --> Controller Class Initialized
INFO - 2018-01-25 08:31:02 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:02 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:02 --> Total execution time: 0.0376
INFO - 2018-01-25 08:31:02 --> Config Class Initialized
INFO - 2018-01-25 08:31:02 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:02 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:02 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:02 --> URI Class Initialized
INFO - 2018-01-25 08:31:02 --> Router Class Initialized
INFO - 2018-01-25 08:31:02 --> Output Class Initialized
INFO - 2018-01-25 08:31:02 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:02 --> Input Class Initialized
INFO - 2018-01-25 08:31:02 --> Language Class Initialized
INFO - 2018-01-25 08:31:02 --> Loader Class Initialized
INFO - 2018-01-25 08:31:02 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:02 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:02 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:02 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:02 --> Model Class Initialized
INFO - 2018-01-25 08:31:02 --> Controller Class Initialized
INFO - 2018-01-25 08:31:02 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:04 --> Config Class Initialized
INFO - 2018-01-25 08:31:04 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:04 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:04 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:04 --> URI Class Initialized
INFO - 2018-01-25 08:31:04 --> Router Class Initialized
INFO - 2018-01-25 08:31:04 --> Output Class Initialized
INFO - 2018-01-25 08:31:04 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:04 --> Input Class Initialized
INFO - 2018-01-25 08:31:04 --> Language Class Initialized
INFO - 2018-01-25 08:31:04 --> Loader Class Initialized
INFO - 2018-01-25 08:31:04 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:04 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:04 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:04 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:04 --> Model Class Initialized
INFO - 2018-01-25 08:31:04 --> Controller Class Initialized
INFO - 2018-01-25 08:31:04 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:04 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:04 --> Total execution time: 0.0377
INFO - 2018-01-25 08:31:04 --> Config Class Initialized
INFO - 2018-01-25 08:31:04 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:04 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:04 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:04 --> URI Class Initialized
INFO - 2018-01-25 08:31:04 --> Router Class Initialized
INFO - 2018-01-25 08:31:04 --> Output Class Initialized
INFO - 2018-01-25 08:31:04 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:04 --> Input Class Initialized
INFO - 2018-01-25 08:31:04 --> Language Class Initialized
INFO - 2018-01-25 08:31:04 --> Loader Class Initialized
INFO - 2018-01-25 08:31:04 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:04 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:04 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:04 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:04 --> Model Class Initialized
INFO - 2018-01-25 08:31:04 --> Controller Class Initialized
INFO - 2018-01-25 08:31:04 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:04 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:04 --> Total execution time: 0.0495
INFO - 2018-01-25 08:31:04 --> Config Class Initialized
INFO - 2018-01-25 08:31:04 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:04 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:04 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:04 --> URI Class Initialized
INFO - 2018-01-25 08:31:04 --> Router Class Initialized
INFO - 2018-01-25 08:31:04 --> Output Class Initialized
INFO - 2018-01-25 08:31:04 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:04 --> Input Class Initialized
INFO - 2018-01-25 08:31:04 --> Language Class Initialized
INFO - 2018-01-25 08:31:04 --> Loader Class Initialized
INFO - 2018-01-25 08:31:05 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:05 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:05 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:05 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:05 --> Model Class Initialized
INFO - 2018-01-25 08:31:05 --> Controller Class Initialized
INFO - 2018-01-25 08:31:05 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:07 --> Config Class Initialized
INFO - 2018-01-25 08:31:07 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:07 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:07 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:07 --> URI Class Initialized
INFO - 2018-01-25 08:31:07 --> Router Class Initialized
INFO - 2018-01-25 08:31:07 --> Output Class Initialized
INFO - 2018-01-25 08:31:07 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:07 --> Input Class Initialized
INFO - 2018-01-25 08:31:07 --> Language Class Initialized
INFO - 2018-01-25 08:31:07 --> Loader Class Initialized
INFO - 2018-01-25 08:31:07 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:07 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:07 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:07 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:07 --> Model Class Initialized
INFO - 2018-01-25 08:31:07 --> Controller Class Initialized
INFO - 2018-01-25 08:31:07 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:07 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:07 --> Total execution time: 0.0383
INFO - 2018-01-25 08:31:10 --> Config Class Initialized
INFO - 2018-01-25 08:31:10 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:10 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:10 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:10 --> URI Class Initialized
INFO - 2018-01-25 08:31:10 --> Router Class Initialized
INFO - 2018-01-25 08:31:10 --> Output Class Initialized
INFO - 2018-01-25 08:31:10 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:10 --> Input Class Initialized
INFO - 2018-01-25 08:31:10 --> Language Class Initialized
INFO - 2018-01-25 08:31:10 --> Loader Class Initialized
INFO - 2018-01-25 08:31:10 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:10 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:10 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:10 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:10 --> Model Class Initialized
INFO - 2018-01-25 08:31:10 --> Controller Class Initialized
INFO - 2018-01-25 08:31:10 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:10 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:10 --> Total execution time: 0.0400
INFO - 2018-01-25 08:31:10 --> Config Class Initialized
INFO - 2018-01-25 08:31:10 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:10 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:10 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:10 --> URI Class Initialized
INFO - 2018-01-25 08:31:10 --> Router Class Initialized
INFO - 2018-01-25 08:31:10 --> Output Class Initialized
INFO - 2018-01-25 08:31:10 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:10 --> Input Class Initialized
INFO - 2018-01-25 08:31:10 --> Language Class Initialized
INFO - 2018-01-25 08:31:10 --> Loader Class Initialized
INFO - 2018-01-25 08:31:10 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:10 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:10 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:10 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:10 --> Model Class Initialized
INFO - 2018-01-25 08:31:10 --> Controller Class Initialized
INFO - 2018-01-25 08:31:10 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:11 --> Config Class Initialized
INFO - 2018-01-25 08:31:11 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:31:11 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:31:11 --> Utf8 Class Initialized
INFO - 2018-01-25 08:31:11 --> URI Class Initialized
INFO - 2018-01-25 08:31:11 --> Router Class Initialized
INFO - 2018-01-25 08:31:11 --> Output Class Initialized
INFO - 2018-01-25 08:31:11 --> Security Class Initialized
DEBUG - 2018-01-25 08:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:31:11 --> Input Class Initialized
INFO - 2018-01-25 08:31:11 --> Language Class Initialized
INFO - 2018-01-25 08:31:11 --> Loader Class Initialized
INFO - 2018-01-25 08:31:11 --> Helper loaded: url_helper
INFO - 2018-01-25 08:31:11 --> Helper loaded: form_helper
INFO - 2018-01-25 08:31:11 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:31:11 --> Form Validation Class Initialized
INFO - 2018-01-25 08:31:11 --> Model Class Initialized
INFO - 2018-01-25 08:31:11 --> Controller Class Initialized
INFO - 2018-01-25 08:31:11 --> Model Class Initialized
DEBUG - 2018-01-25 08:31:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:31:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:31:11 --> Final output sent to browser
DEBUG - 2018-01-25 08:31:11 --> Total execution time: 0.0403
INFO - 2018-01-25 08:46:08 --> Config Class Initialized
INFO - 2018-01-25 08:46:08 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:08 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:08 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:08 --> URI Class Initialized
INFO - 2018-01-25 08:46:08 --> Router Class Initialized
INFO - 2018-01-25 08:46:08 --> Output Class Initialized
INFO - 2018-01-25 08:46:08 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:08 --> Input Class Initialized
INFO - 2018-01-25 08:46:08 --> Language Class Initialized
INFO - 2018-01-25 08:46:08 --> Loader Class Initialized
INFO - 2018-01-25 08:46:08 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:08 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:08 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:08 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:08 --> Model Class Initialized
INFO - 2018-01-25 08:46:08 --> Controller Class Initialized
INFO - 2018-01-25 08:46:08 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:46:08 --> Final output sent to browser
DEBUG - 2018-01-25 08:46:08 --> Total execution time: 0.0400
INFO - 2018-01-25 08:46:15 --> Config Class Initialized
INFO - 2018-01-25 08:46:15 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:15 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:15 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:15 --> URI Class Initialized
INFO - 2018-01-25 08:46:15 --> Router Class Initialized
INFO - 2018-01-25 08:46:15 --> Output Class Initialized
INFO - 2018-01-25 08:46:15 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:15 --> Input Class Initialized
INFO - 2018-01-25 08:46:15 --> Language Class Initialized
INFO - 2018-01-25 08:46:15 --> Loader Class Initialized
INFO - 2018-01-25 08:46:15 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:15 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:15 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:15 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:15 --> Model Class Initialized
INFO - 2018-01-25 08:46:15 --> Controller Class Initialized
INFO - 2018-01-25 08:46:15 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:46:15 --> Final output sent to browser
DEBUG - 2018-01-25 08:46:15 --> Total execution time: 0.0433
INFO - 2018-01-25 08:46:21 --> Config Class Initialized
INFO - 2018-01-25 08:46:21 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:21 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:21 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:21 --> URI Class Initialized
INFO - 2018-01-25 08:46:21 --> Router Class Initialized
INFO - 2018-01-25 08:46:21 --> Output Class Initialized
INFO - 2018-01-25 08:46:21 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:21 --> Input Class Initialized
INFO - 2018-01-25 08:46:21 --> Language Class Initialized
INFO - 2018-01-25 08:46:21 --> Loader Class Initialized
INFO - 2018-01-25 08:46:21 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:21 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:21 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:21 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:21 --> Model Class Initialized
INFO - 2018-01-25 08:46:21 --> Controller Class Initialized
INFO - 2018-01-25 08:46:21 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:46:21 --> Final output sent to browser
DEBUG - 2018-01-25 08:46:21 --> Total execution time: 0.0382
INFO - 2018-01-25 08:46:30 --> Config Class Initialized
INFO - 2018-01-25 08:46:30 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:30 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:30 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:30 --> URI Class Initialized
INFO - 2018-01-25 08:46:30 --> Router Class Initialized
INFO - 2018-01-25 08:46:30 --> Output Class Initialized
INFO - 2018-01-25 08:46:30 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:30 --> Input Class Initialized
INFO - 2018-01-25 08:46:30 --> Language Class Initialized
INFO - 2018-01-25 08:46:30 --> Loader Class Initialized
INFO - 2018-01-25 08:46:30 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:30 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:30 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:30 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:30 --> Model Class Initialized
INFO - 2018-01-25 08:46:30 --> Controller Class Initialized
INFO - 2018-01-25 08:46:30 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:46:30 --> Final output sent to browser
DEBUG - 2018-01-25 08:46:30 --> Total execution time: 0.0498
INFO - 2018-01-25 08:46:30 --> Config Class Initialized
INFO - 2018-01-25 08:46:30 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:30 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:30 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:30 --> URI Class Initialized
INFO - 2018-01-25 08:46:30 --> Router Class Initialized
INFO - 2018-01-25 08:46:30 --> Output Class Initialized
INFO - 2018-01-25 08:46:30 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:30 --> Input Class Initialized
INFO - 2018-01-25 08:46:30 --> Language Class Initialized
INFO - 2018-01-25 08:46:30 --> Loader Class Initialized
INFO - 2018-01-25 08:46:30 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:30 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:30 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:30 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:30 --> Model Class Initialized
INFO - 2018-01-25 08:46:30 --> Controller Class Initialized
INFO - 2018-01-25 08:46:30 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:33 --> Config Class Initialized
INFO - 2018-01-25 08:46:33 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:46:33 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:46:33 --> Utf8 Class Initialized
INFO - 2018-01-25 08:46:33 --> URI Class Initialized
INFO - 2018-01-25 08:46:33 --> Router Class Initialized
INFO - 2018-01-25 08:46:33 --> Output Class Initialized
INFO - 2018-01-25 08:46:33 --> Security Class Initialized
DEBUG - 2018-01-25 08:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:46:33 --> Input Class Initialized
INFO - 2018-01-25 08:46:33 --> Language Class Initialized
INFO - 2018-01-25 08:46:33 --> Loader Class Initialized
INFO - 2018-01-25 08:46:33 --> Helper loaded: url_helper
INFO - 2018-01-25 08:46:33 --> Helper loaded: form_helper
INFO - 2018-01-25 08:46:33 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:46:33 --> Form Validation Class Initialized
INFO - 2018-01-25 08:46:33 --> Model Class Initialized
INFO - 2018-01-25 08:46:33 --> Controller Class Initialized
INFO - 2018-01-25 08:46:33 --> Model Class Initialized
DEBUG - 2018-01-25 08:46:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:46:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:46:33 --> Final output sent to browser
DEBUG - 2018-01-25 08:46:33 --> Total execution time: 0.0396
INFO - 2018-01-25 08:47:25 --> Config Class Initialized
INFO - 2018-01-25 08:47:25 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:47:25 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:47:25 --> Utf8 Class Initialized
INFO - 2018-01-25 08:47:25 --> URI Class Initialized
INFO - 2018-01-25 08:47:25 --> Router Class Initialized
INFO - 2018-01-25 08:47:25 --> Output Class Initialized
INFO - 2018-01-25 08:47:25 --> Security Class Initialized
DEBUG - 2018-01-25 08:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:47:25 --> Input Class Initialized
INFO - 2018-01-25 08:47:25 --> Language Class Initialized
INFO - 2018-01-25 08:47:25 --> Loader Class Initialized
INFO - 2018-01-25 08:47:25 --> Helper loaded: url_helper
INFO - 2018-01-25 08:47:25 --> Helper loaded: form_helper
INFO - 2018-01-25 08:47:25 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:47:25 --> Form Validation Class Initialized
INFO - 2018-01-25 08:47:25 --> Model Class Initialized
INFO - 2018-01-25 08:47:25 --> Controller Class Initialized
INFO - 2018-01-25 08:47:25 --> Model Class Initialized
DEBUG - 2018-01-25 08:47:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:47:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:47:25 --> Final output sent to browser
DEBUG - 2018-01-25 08:47:25 --> Total execution time: 0.0568
INFO - 2018-01-25 08:50:06 --> Config Class Initialized
INFO - 2018-01-25 08:50:06 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:50:06 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:50:06 --> Utf8 Class Initialized
INFO - 2018-01-25 08:50:06 --> URI Class Initialized
INFO - 2018-01-25 08:50:06 --> Router Class Initialized
INFO - 2018-01-25 08:50:06 --> Output Class Initialized
INFO - 2018-01-25 08:50:06 --> Security Class Initialized
DEBUG - 2018-01-25 08:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:50:06 --> Input Class Initialized
INFO - 2018-01-25 08:50:06 --> Language Class Initialized
INFO - 2018-01-25 08:50:06 --> Loader Class Initialized
INFO - 2018-01-25 08:50:06 --> Helper loaded: url_helper
INFO - 2018-01-25 08:50:06 --> Helper loaded: form_helper
INFO - 2018-01-25 08:50:06 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:50:06 --> Form Validation Class Initialized
INFO - 2018-01-25 08:50:06 --> Model Class Initialized
INFO - 2018-01-25 08:50:06 --> Controller Class Initialized
INFO - 2018-01-25 08:50:06 --> Model Class Initialized
DEBUG - 2018-01-25 08:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:51:13 --> Config Class Initialized
INFO - 2018-01-25 08:51:13 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:51:13 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:51:13 --> Utf8 Class Initialized
INFO - 2018-01-25 08:51:13 --> URI Class Initialized
INFO - 2018-01-25 08:51:13 --> Router Class Initialized
INFO - 2018-01-25 08:51:13 --> Output Class Initialized
INFO - 2018-01-25 08:51:13 --> Security Class Initialized
DEBUG - 2018-01-25 08:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:51:13 --> Input Class Initialized
INFO - 2018-01-25 08:51:13 --> Language Class Initialized
INFO - 2018-01-25 08:51:13 --> Loader Class Initialized
INFO - 2018-01-25 08:51:13 --> Helper loaded: url_helper
INFO - 2018-01-25 08:51:13 --> Helper loaded: form_helper
INFO - 2018-01-25 08:51:13 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:51:13 --> Form Validation Class Initialized
INFO - 2018-01-25 08:51:13 --> Model Class Initialized
INFO - 2018-01-25 08:51:13 --> Controller Class Initialized
INFO - 2018-01-25 08:51:13 --> Model Class Initialized
DEBUG - 2018-01-25 08:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:51:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:51:13 --> Final output sent to browser
DEBUG - 2018-01-25 08:51:13 --> Total execution time: 0.0424
INFO - 2018-01-25 08:55:35 --> Config Class Initialized
INFO - 2018-01-25 08:55:35 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:55:35 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:55:35 --> Utf8 Class Initialized
INFO - 2018-01-25 08:55:35 --> URI Class Initialized
INFO - 2018-01-25 08:55:35 --> Router Class Initialized
INFO - 2018-01-25 08:55:35 --> Output Class Initialized
INFO - 2018-01-25 08:55:35 --> Security Class Initialized
DEBUG - 2018-01-25 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:55:35 --> Input Class Initialized
INFO - 2018-01-25 08:55:35 --> Language Class Initialized
INFO - 2018-01-25 08:55:35 --> Loader Class Initialized
INFO - 2018-01-25 08:55:35 --> Helper loaded: url_helper
INFO - 2018-01-25 08:55:35 --> Helper loaded: form_helper
INFO - 2018-01-25 08:55:35 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:55:35 --> Form Validation Class Initialized
INFO - 2018-01-25 08:55:35 --> Model Class Initialized
INFO - 2018-01-25 08:55:35 --> Controller Class Initialized
INFO - 2018-01-25 08:55:35 --> Model Class Initialized
DEBUG - 2018-01-25 08:55:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:55:45 --> Config Class Initialized
INFO - 2018-01-25 08:55:45 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:55:45 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:55:45 --> Utf8 Class Initialized
INFO - 2018-01-25 08:55:45 --> URI Class Initialized
INFO - 2018-01-25 08:55:45 --> Router Class Initialized
INFO - 2018-01-25 08:55:45 --> Output Class Initialized
INFO - 2018-01-25 08:55:45 --> Security Class Initialized
DEBUG - 2018-01-25 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:55:45 --> Input Class Initialized
INFO - 2018-01-25 08:55:45 --> Language Class Initialized
INFO - 2018-01-25 08:55:45 --> Loader Class Initialized
INFO - 2018-01-25 08:55:45 --> Helper loaded: url_helper
INFO - 2018-01-25 08:55:45 --> Helper loaded: form_helper
INFO - 2018-01-25 08:55:45 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:55:45 --> Form Validation Class Initialized
INFO - 2018-01-25 08:55:45 --> Model Class Initialized
INFO - 2018-01-25 08:55:45 --> Controller Class Initialized
INFO - 2018-01-25 08:55:45 --> Model Class Initialized
DEBUG - 2018-01-25 08:55:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:55:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:55:45 --> Final output sent to browser
DEBUG - 2018-01-25 08:55:45 --> Total execution time: 0.1915
INFO - 2018-01-25 08:55:51 --> Config Class Initialized
INFO - 2018-01-25 08:55:51 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:55:51 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:55:51 --> Utf8 Class Initialized
INFO - 2018-01-25 08:55:51 --> URI Class Initialized
INFO - 2018-01-25 08:55:51 --> Router Class Initialized
INFO - 2018-01-25 08:55:51 --> Output Class Initialized
INFO - 2018-01-25 08:55:51 --> Security Class Initialized
DEBUG - 2018-01-25 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:55:51 --> Input Class Initialized
INFO - 2018-01-25 08:55:51 --> Language Class Initialized
INFO - 2018-01-25 08:55:51 --> Loader Class Initialized
INFO - 2018-01-25 08:55:51 --> Helper loaded: url_helper
INFO - 2018-01-25 08:55:51 --> Helper loaded: form_helper
INFO - 2018-01-25 08:55:51 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:55:51 --> Form Validation Class Initialized
INFO - 2018-01-25 08:55:51 --> Model Class Initialized
INFO - 2018-01-25 08:55:51 --> Controller Class Initialized
INFO - 2018-01-25 08:55:51 --> Model Class Initialized
DEBUG - 2018-01-25 08:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:55:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:55:51 --> Final output sent to browser
DEBUG - 2018-01-25 08:55:51 --> Total execution time: 0.1992
INFO - 2018-01-25 08:55:57 --> Config Class Initialized
INFO - 2018-01-25 08:55:57 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:55:57 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:55:57 --> Utf8 Class Initialized
INFO - 2018-01-25 08:55:57 --> URI Class Initialized
INFO - 2018-01-25 08:55:57 --> Router Class Initialized
INFO - 2018-01-25 08:55:57 --> Output Class Initialized
INFO - 2018-01-25 08:55:57 --> Security Class Initialized
DEBUG - 2018-01-25 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:55:57 --> Input Class Initialized
INFO - 2018-01-25 08:55:57 --> Language Class Initialized
INFO - 2018-01-25 08:55:57 --> Loader Class Initialized
INFO - 2018-01-25 08:55:57 --> Helper loaded: url_helper
INFO - 2018-01-25 08:55:57 --> Helper loaded: form_helper
INFO - 2018-01-25 08:55:57 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:55:57 --> Form Validation Class Initialized
INFO - 2018-01-25 08:55:57 --> Model Class Initialized
INFO - 2018-01-25 08:55:57 --> Controller Class Initialized
INFO - 2018-01-25 08:55:57 --> Model Class Initialized
DEBUG - 2018-01-25 08:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:55:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:55:57 --> Final output sent to browser
DEBUG - 2018-01-25 08:55:58 --> Total execution time: 0.1947
INFO - 2018-01-25 08:56:01 --> Config Class Initialized
INFO - 2018-01-25 08:56:01 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:01 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:01 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:01 --> URI Class Initialized
INFO - 2018-01-25 08:56:01 --> Router Class Initialized
INFO - 2018-01-25 08:56:01 --> Output Class Initialized
INFO - 2018-01-25 08:56:01 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:01 --> Input Class Initialized
INFO - 2018-01-25 08:56:01 --> Language Class Initialized
INFO - 2018-01-25 08:56:01 --> Loader Class Initialized
INFO - 2018-01-25 08:56:01 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:01 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:01 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:01 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:01 --> Model Class Initialized
INFO - 2018-01-25 08:56:01 --> Controller Class Initialized
INFO - 2018-01-25 08:56:01 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:01 --> Model Class Initialized
INFO - 2018-01-25 08:56:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:01 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:01 --> Total execution time: 0.2324
INFO - 2018-01-25 08:56:07 --> Config Class Initialized
INFO - 2018-01-25 08:56:07 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:07 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:07 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:07 --> URI Class Initialized
INFO - 2018-01-25 08:56:07 --> Router Class Initialized
INFO - 2018-01-25 08:56:07 --> Output Class Initialized
INFO - 2018-01-25 08:56:07 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:07 --> Input Class Initialized
INFO - 2018-01-25 08:56:07 --> Language Class Initialized
INFO - 2018-01-25 08:56:07 --> Loader Class Initialized
INFO - 2018-01-25 08:56:07 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:07 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:07 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:07 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:07 --> Model Class Initialized
INFO - 2018-01-25 08:56:07 --> Controller Class Initialized
INFO - 2018-01-25 08:56:07 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:07 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:07 --> Total execution time: 0.2040
INFO - 2018-01-25 08:56:11 --> Config Class Initialized
INFO - 2018-01-25 08:56:11 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:11 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:11 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:11 --> URI Class Initialized
INFO - 2018-01-25 08:56:11 --> Router Class Initialized
INFO - 2018-01-25 08:56:11 --> Output Class Initialized
INFO - 2018-01-25 08:56:11 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:11 --> Input Class Initialized
INFO - 2018-01-25 08:56:11 --> Language Class Initialized
INFO - 2018-01-25 08:56:11 --> Loader Class Initialized
INFO - 2018-01-25 08:56:11 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:11 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:11 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:11 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:11 --> Model Class Initialized
INFO - 2018-01-25 08:56:11 --> Controller Class Initialized
INFO - 2018-01-25 08:56:11 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:11 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:11 --> Total execution time: 0.1792
INFO - 2018-01-25 08:56:12 --> Config Class Initialized
INFO - 2018-01-25 08:56:12 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:12 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:12 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:12 --> URI Class Initialized
INFO - 2018-01-25 08:56:12 --> Router Class Initialized
INFO - 2018-01-25 08:56:12 --> Output Class Initialized
INFO - 2018-01-25 08:56:12 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:12 --> Input Class Initialized
INFO - 2018-01-25 08:56:12 --> Language Class Initialized
INFO - 2018-01-25 08:56:12 --> Loader Class Initialized
INFO - 2018-01-25 08:56:12 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:12 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:12 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:12 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:12 --> Model Class Initialized
INFO - 2018-01-25 08:56:12 --> Controller Class Initialized
INFO - 2018-01-25 08:56:12 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:12 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:12 --> Total execution time: 0.0372
INFO - 2018-01-25 08:56:13 --> Config Class Initialized
INFO - 2018-01-25 08:56:13 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:13 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:13 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:13 --> URI Class Initialized
INFO - 2018-01-25 08:56:13 --> Router Class Initialized
INFO - 2018-01-25 08:56:13 --> Output Class Initialized
INFO - 2018-01-25 08:56:13 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:13 --> Input Class Initialized
INFO - 2018-01-25 08:56:13 --> Language Class Initialized
INFO - 2018-01-25 08:56:13 --> Loader Class Initialized
INFO - 2018-01-25 08:56:13 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:13 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:13 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:13 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:13 --> Model Class Initialized
INFO - 2018-01-25 08:56:13 --> Controller Class Initialized
INFO - 2018-01-25 08:56:13 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:15 --> Config Class Initialized
INFO - 2018-01-25 08:56:15 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:15 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:15 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:15 --> URI Class Initialized
INFO - 2018-01-25 08:56:15 --> Router Class Initialized
INFO - 2018-01-25 08:56:15 --> Output Class Initialized
INFO - 2018-01-25 08:56:15 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:15 --> Input Class Initialized
INFO - 2018-01-25 08:56:15 --> Language Class Initialized
INFO - 2018-01-25 08:56:15 --> Loader Class Initialized
INFO - 2018-01-25 08:56:15 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:15 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:15 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:15 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:15 --> Model Class Initialized
INFO - 2018-01-25 08:56:15 --> Controller Class Initialized
INFO - 2018-01-25 08:56:15 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:15 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:15 --> Total execution time: 0.0524
INFO - 2018-01-25 08:56:17 --> Config Class Initialized
INFO - 2018-01-25 08:56:17 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:17 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:17 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:17 --> URI Class Initialized
INFO - 2018-01-25 08:56:17 --> Router Class Initialized
INFO - 2018-01-25 08:56:17 --> Output Class Initialized
INFO - 2018-01-25 08:56:17 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:17 --> Input Class Initialized
INFO - 2018-01-25 08:56:17 --> Language Class Initialized
INFO - 2018-01-25 08:56:17 --> Loader Class Initialized
INFO - 2018-01-25 08:56:17 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:17 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:17 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:17 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:17 --> Model Class Initialized
INFO - 2018-01-25 08:56:17 --> Controller Class Initialized
INFO - 2018-01-25 08:56:17 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:17 --> Model Class Initialized
INFO - 2018-01-25 08:56:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:18 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:18 --> Total execution time: 0.2543
INFO - 2018-01-25 08:56:20 --> Config Class Initialized
INFO - 2018-01-25 08:56:20 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:20 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:20 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:20 --> URI Class Initialized
INFO - 2018-01-25 08:56:20 --> Router Class Initialized
INFO - 2018-01-25 08:56:20 --> Output Class Initialized
INFO - 2018-01-25 08:56:20 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:20 --> Input Class Initialized
INFO - 2018-01-25 08:56:20 --> Language Class Initialized
INFO - 2018-01-25 08:56:20 --> Loader Class Initialized
INFO - 2018-01-25 08:56:20 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:20 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:20 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:20 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:20 --> Model Class Initialized
INFO - 2018-01-25 08:56:20 --> Controller Class Initialized
INFO - 2018-01-25 08:56:20 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:20 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:20 --> Total execution time: 0.0469
INFO - 2018-01-25 08:56:20 --> Config Class Initialized
INFO - 2018-01-25 08:56:20 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:20 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:20 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:21 --> URI Class Initialized
INFO - 2018-01-25 08:56:21 --> Router Class Initialized
INFO - 2018-01-25 08:56:21 --> Output Class Initialized
INFO - 2018-01-25 08:56:21 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:21 --> Input Class Initialized
INFO - 2018-01-25 08:56:21 --> Language Class Initialized
INFO - 2018-01-25 08:56:21 --> Loader Class Initialized
INFO - 2018-01-25 08:56:21 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:21 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:21 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:21 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:21 --> Model Class Initialized
INFO - 2018-01-25 08:56:21 --> Controller Class Initialized
INFO - 2018-01-25 08:56:21 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:24 --> Config Class Initialized
INFO - 2018-01-25 08:56:24 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:24 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:24 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:24 --> URI Class Initialized
INFO - 2018-01-25 08:56:24 --> Router Class Initialized
INFO - 2018-01-25 08:56:24 --> Output Class Initialized
INFO - 2018-01-25 08:56:24 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:24 --> Input Class Initialized
INFO - 2018-01-25 08:56:24 --> Language Class Initialized
INFO - 2018-01-25 08:56:24 --> Loader Class Initialized
INFO - 2018-01-25 08:56:24 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:24 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:24 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:24 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:24 --> Model Class Initialized
INFO - 2018-01-25 08:56:24 --> Controller Class Initialized
INFO - 2018-01-25 08:56:24 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:24 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:24 --> Total execution time: 0.0457
INFO - 2018-01-25 08:56:24 --> Config Class Initialized
INFO - 2018-01-25 08:56:24 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:24 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:24 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:24 --> URI Class Initialized
INFO - 2018-01-25 08:56:24 --> Router Class Initialized
INFO - 2018-01-25 08:56:24 --> Output Class Initialized
INFO - 2018-01-25 08:56:24 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:24 --> Input Class Initialized
INFO - 2018-01-25 08:56:24 --> Language Class Initialized
INFO - 2018-01-25 08:56:24 --> Loader Class Initialized
INFO - 2018-01-25 08:56:24 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:24 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:24 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:24 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:24 --> Model Class Initialized
INFO - 2018-01-25 08:56:24 --> Controller Class Initialized
INFO - 2018-01-25 08:56:24 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:31 --> Config Class Initialized
INFO - 2018-01-25 08:56:31 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:31 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:31 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:31 --> URI Class Initialized
INFO - 2018-01-25 08:56:31 --> Router Class Initialized
INFO - 2018-01-25 08:56:31 --> Output Class Initialized
INFO - 2018-01-25 08:56:31 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:31 --> Input Class Initialized
INFO - 2018-01-25 08:56:31 --> Language Class Initialized
INFO - 2018-01-25 08:56:31 --> Loader Class Initialized
INFO - 2018-01-25 08:56:31 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:31 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:31 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:31 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:31 --> Model Class Initialized
INFO - 2018-01-25 08:56:31 --> Controller Class Initialized
INFO - 2018-01-25 08:56:31 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:35 --> Config Class Initialized
INFO - 2018-01-25 08:56:35 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:35 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:35 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:35 --> URI Class Initialized
INFO - 2018-01-25 08:56:35 --> Router Class Initialized
INFO - 2018-01-25 08:56:35 --> Output Class Initialized
INFO - 2018-01-25 08:56:35 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:35 --> Input Class Initialized
INFO - 2018-01-25 08:56:35 --> Language Class Initialized
INFO - 2018-01-25 08:56:35 --> Loader Class Initialized
INFO - 2018-01-25 08:56:35 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:35 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:35 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:35 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:35 --> Model Class Initialized
INFO - 2018-01-25 08:56:35 --> Controller Class Initialized
INFO - 2018-01-25 08:56:35 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:37 --> Config Class Initialized
INFO - 2018-01-25 08:56:37 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:37 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:37 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:37 --> URI Class Initialized
INFO - 2018-01-25 08:56:37 --> Router Class Initialized
INFO - 2018-01-25 08:56:37 --> Output Class Initialized
INFO - 2018-01-25 08:56:37 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:37 --> Input Class Initialized
INFO - 2018-01-25 08:56:37 --> Language Class Initialized
INFO - 2018-01-25 08:56:37 --> Loader Class Initialized
INFO - 2018-01-25 08:56:37 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:37 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:37 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:37 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:37 --> Model Class Initialized
INFO - 2018-01-25 08:56:37 --> Controller Class Initialized
INFO - 2018-01-25 08:56:37 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:43 --> Config Class Initialized
INFO - 2018-01-25 08:56:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:43 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:43 --> URI Class Initialized
INFO - 2018-01-25 08:56:43 --> Router Class Initialized
INFO - 2018-01-25 08:56:43 --> Output Class Initialized
INFO - 2018-01-25 08:56:43 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:43 --> Input Class Initialized
INFO - 2018-01-25 08:56:43 --> Language Class Initialized
INFO - 2018-01-25 08:56:43 --> Loader Class Initialized
INFO - 2018-01-25 08:56:43 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:43 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:43 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:43 --> Model Class Initialized
INFO - 2018-01-25 08:56:43 --> Controller Class Initialized
INFO - 2018-01-25 08:56:43 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:43 --> Config Class Initialized
INFO - 2018-01-25 08:56:43 --> Hooks Class Initialized
DEBUG - 2018-01-25 08:56:43 --> UTF-8 Support Enabled
INFO - 2018-01-25 08:56:43 --> Utf8 Class Initialized
INFO - 2018-01-25 08:56:43 --> URI Class Initialized
INFO - 2018-01-25 08:56:43 --> Router Class Initialized
INFO - 2018-01-25 08:56:43 --> Output Class Initialized
INFO - 2018-01-25 08:56:43 --> Security Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-25 08:56:43 --> Input Class Initialized
INFO - 2018-01-25 08:56:43 --> Language Class Initialized
INFO - 2018-01-25 08:56:43 --> Loader Class Initialized
INFO - 2018-01-25 08:56:43 --> Helper loaded: url_helper
INFO - 2018-01-25 08:56:43 --> Helper loaded: form_helper
INFO - 2018-01-25 08:56:43 --> Database Driver Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-25 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-25 08:56:43 --> Form Validation Class Initialized
INFO - 2018-01-25 08:56:43 --> Model Class Initialized
INFO - 2018-01-25 08:56:43 --> Controller Class Initialized
INFO - 2018-01-25 08:56:43 --> Model Class Initialized
DEBUG - 2018-01-25 08:56:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-25 08:56:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-25 08:56:43 --> Final output sent to browser
DEBUG - 2018-01-25 08:56:43 --> Total execution time: 0.0555
