<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-22 20:50:01 --> Config Class Initialized
INFO - 2018-03-22 20:50:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:50:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:50:01 --> Utf8 Class Initialized
INFO - 2018-03-22 20:50:01 --> URI Class Initialized
INFO - 2018-03-22 20:50:01 --> Router Class Initialized
INFO - 2018-03-22 20:50:01 --> Output Class Initialized
INFO - 2018-03-22 20:50:01 --> Security Class Initialized
DEBUG - 2018-03-22 20:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:50:01 --> Input Class Initialized
INFO - 2018-03-22 20:50:01 --> Language Class Initialized
INFO - 2018-03-22 20:50:01 --> Loader Class Initialized
INFO - 2018-03-22 20:50:01 --> Helper loaded: url_helper
INFO - 2018-03-22 20:50:01 --> Helper loaded: form_helper
INFO - 2018-03-22 20:50:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:50:01 --> Form Validation Class Initialized
INFO - 2018-03-22 20:50:01 --> Model Class Initialized
INFO - 2018-03-22 20:50:01 --> Controller Class Initialized
INFO - 2018-03-22 20:50:01 --> Model Class Initialized
INFO - 2018-03-22 20:50:01 --> Model Class Initialized
INFO - 2018-03-22 20:50:01 --> Model Class Initialized
INFO - 2018-03-22 20:50:02 --> Model Class Initialized
DEBUG - 2018-03-22 20:50:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:50:02 --> Config Class Initialized
INFO - 2018-03-22 20:50:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:50:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:50:02 --> Utf8 Class Initialized
INFO - 2018-03-22 20:50:02 --> URI Class Initialized
INFO - 2018-03-22 20:50:02 --> Router Class Initialized
INFO - 2018-03-22 20:50:02 --> Output Class Initialized
INFO - 2018-03-22 20:50:02 --> Security Class Initialized
DEBUG - 2018-03-22 20:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:50:02 --> Input Class Initialized
INFO - 2018-03-22 20:50:02 --> Language Class Initialized
INFO - 2018-03-22 20:50:02 --> Loader Class Initialized
INFO - 2018-03-22 20:50:02 --> Helper loaded: url_helper
INFO - 2018-03-22 20:50:02 --> Helper loaded: form_helper
INFO - 2018-03-22 20:50:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:50:02 --> Form Validation Class Initialized
INFO - 2018-03-22 20:50:02 --> Model Class Initialized
INFO - 2018-03-22 20:50:02 --> Controller Class Initialized
INFO - 2018-03-22 20:50:02 --> Model Class Initialized
DEBUG - 2018-03-22 20:50:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:50:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:50:02 --> Final output sent to browser
DEBUG - 2018-03-22 20:50:02 --> Total execution time: 0.1480
INFO - 2018-03-22 20:50:03 --> Config Class Initialized
INFO - 2018-03-22 20:50:03 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:50:03 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:50:03 --> Utf8 Class Initialized
INFO - 2018-03-22 20:50:03 --> URI Class Initialized
INFO - 2018-03-22 20:50:03 --> Router Class Initialized
INFO - 2018-03-22 20:50:03 --> Output Class Initialized
INFO - 2018-03-22 20:50:03 --> Security Class Initialized
DEBUG - 2018-03-22 20:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:50:03 --> Input Class Initialized
INFO - 2018-03-22 20:50:03 --> Language Class Initialized
INFO - 2018-03-22 20:50:03 --> Loader Class Initialized
INFO - 2018-03-22 20:50:03 --> Helper loaded: url_helper
INFO - 2018-03-22 20:50:03 --> Helper loaded: form_helper
INFO - 2018-03-22 20:50:03 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:50:03 --> Form Validation Class Initialized
INFO - 2018-03-22 20:50:03 --> Model Class Initialized
INFO - 2018-03-22 20:50:03 --> Controller Class Initialized
INFO - 2018-03-22 20:50:03 --> Model Class Initialized
DEBUG - 2018-03-22 20:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:50:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 20:50:04 --> Config Class Initialized
INFO - 2018-03-22 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:50:04 --> Utf8 Class Initialized
INFO - 2018-03-22 20:50:04 --> URI Class Initialized
DEBUG - 2018-03-22 20:50:04 --> No URI present. Default controller set.
INFO - 2018-03-22 20:50:04 --> Router Class Initialized
INFO - 2018-03-22 20:50:04 --> Output Class Initialized
INFO - 2018-03-22 20:50:04 --> Security Class Initialized
DEBUG - 2018-03-22 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:50:04 --> Input Class Initialized
INFO - 2018-03-22 20:50:04 --> Language Class Initialized
INFO - 2018-03-22 20:50:04 --> Loader Class Initialized
INFO - 2018-03-22 20:50:04 --> Helper loaded: url_helper
INFO - 2018-03-22 20:50:04 --> Helper loaded: form_helper
INFO - 2018-03-22 20:50:04 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:50:04 --> Form Validation Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Controller Class Initialized
INFO - 2018-03-22 20:50:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:50:04 --> Final output sent to browser
DEBUG - 2018-03-22 20:50:04 --> Total execution time: 0.0730
INFO - 2018-03-22 20:50:04 --> Config Class Initialized
INFO - 2018-03-22 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:50:04 --> Utf8 Class Initialized
INFO - 2018-03-22 20:50:04 --> URI Class Initialized
INFO - 2018-03-22 20:50:04 --> Router Class Initialized
INFO - 2018-03-22 20:50:04 --> Output Class Initialized
INFO - 2018-03-22 20:50:04 --> Security Class Initialized
DEBUG - 2018-03-22 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:50:04 --> Input Class Initialized
INFO - 2018-03-22 20:50:04 --> Language Class Initialized
INFO - 2018-03-22 20:50:04 --> Loader Class Initialized
INFO - 2018-03-22 20:50:04 --> Helper loaded: url_helper
INFO - 2018-03-22 20:50:04 --> Helper loaded: form_helper
INFO - 2018-03-22 20:50:04 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:50:04 --> Form Validation Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Controller Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
INFO - 2018-03-22 20:50:04 --> Model Class Initialized
DEBUG - 2018-03-22 20:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:57:21 --> Config Class Initialized
INFO - 2018-03-22 20:57:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:57:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:57:21 --> Utf8 Class Initialized
INFO - 2018-03-22 20:57:21 --> URI Class Initialized
INFO - 2018-03-22 20:57:21 --> Router Class Initialized
INFO - 2018-03-22 20:57:21 --> Output Class Initialized
INFO - 2018-03-22 20:57:21 --> Security Class Initialized
DEBUG - 2018-03-22 20:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:57:21 --> Input Class Initialized
INFO - 2018-03-22 20:57:21 --> Language Class Initialized
INFO - 2018-03-22 20:57:21 --> Loader Class Initialized
INFO - 2018-03-22 20:57:21 --> Helper loaded: url_helper
INFO - 2018-03-22 20:57:21 --> Helper loaded: form_helper
INFO - 2018-03-22 20:57:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:57:21 --> Form Validation Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
INFO - 2018-03-22 20:57:21 --> Controller Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
INFO - 2018-03-22 20:57:21 --> Model Class Initialized
DEBUG - 2018-03-22 20:57:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:57:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:57:22 --> Final output sent to browser
DEBUG - 2018-03-22 20:57:22 --> Total execution time: 0.3412
INFO - 2018-03-22 20:57:22 --> Config Class Initialized
INFO - 2018-03-22 20:57:22 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:57:22 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:57:22 --> Utf8 Class Initialized
INFO - 2018-03-22 20:57:22 --> URI Class Initialized
INFO - 2018-03-22 20:57:22 --> Router Class Initialized
INFO - 2018-03-22 20:57:22 --> Output Class Initialized
INFO - 2018-03-22 20:57:22 --> Security Class Initialized
DEBUG - 2018-03-22 20:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:57:22 --> Input Class Initialized
INFO - 2018-03-22 20:57:22 --> Language Class Initialized
INFO - 2018-03-22 20:57:22 --> Loader Class Initialized
INFO - 2018-03-22 20:57:22 --> Helper loaded: url_helper
INFO - 2018-03-22 20:57:22 --> Helper loaded: form_helper
INFO - 2018-03-22 20:57:22 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:57:22 --> Form Validation Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
INFO - 2018-03-22 20:57:22 --> Controller Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
INFO - 2018-03-22 20:57:22 --> Model Class Initialized
DEBUG - 2018-03-22 20:57:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:57:24 --> Config Class Initialized
INFO - 2018-03-22 20:57:24 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:57:24 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:57:24 --> Utf8 Class Initialized
INFO - 2018-03-22 20:57:24 --> URI Class Initialized
INFO - 2018-03-22 20:57:24 --> Router Class Initialized
INFO - 2018-03-22 20:57:24 --> Output Class Initialized
INFO - 2018-03-22 20:57:24 --> Security Class Initialized
DEBUG - 2018-03-22 20:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:57:24 --> Input Class Initialized
INFO - 2018-03-22 20:57:24 --> Language Class Initialized
INFO - 2018-03-22 20:57:24 --> Loader Class Initialized
INFO - 2018-03-22 20:57:24 --> Helper loaded: url_helper
INFO - 2018-03-22 20:57:24 --> Helper loaded: form_helper
INFO - 2018-03-22 20:57:24 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:57:24 --> Form Validation Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
INFO - 2018-03-22 20:57:24 --> Controller Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
INFO - 2018-03-22 20:57:24 --> Model Class Initialized
DEBUG - 2018-03-22 20:57:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:57:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:57:24 --> Final output sent to browser
DEBUG - 2018-03-22 20:57:24 --> Total execution time: 0.0956
INFO - 2018-03-22 20:57:25 --> Config Class Initialized
INFO - 2018-03-22 20:57:25 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:57:25 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:57:25 --> Utf8 Class Initialized
INFO - 2018-03-22 20:57:25 --> URI Class Initialized
INFO - 2018-03-22 20:57:25 --> Router Class Initialized
INFO - 2018-03-22 20:57:25 --> Output Class Initialized
INFO - 2018-03-22 20:57:25 --> Security Class Initialized
DEBUG - 2018-03-22 20:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:57:25 --> Input Class Initialized
INFO - 2018-03-22 20:57:25 --> Language Class Initialized
INFO - 2018-03-22 20:57:25 --> Loader Class Initialized
INFO - 2018-03-22 20:57:25 --> Helper loaded: url_helper
INFO - 2018-03-22 20:57:25 --> Helper loaded: form_helper
INFO - 2018-03-22 20:57:25 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:57:25 --> Form Validation Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
INFO - 2018-03-22 20:57:25 --> Controller Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
INFO - 2018-03-22 20:57:25 --> Model Class Initialized
DEBUG - 2018-03-22 20:57:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:29 --> Config Class Initialized
INFO - 2018-03-22 20:59:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:29 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:29 --> URI Class Initialized
INFO - 2018-03-22 20:59:29 --> Router Class Initialized
INFO - 2018-03-22 20:59:29 --> Output Class Initialized
INFO - 2018-03-22 20:59:29 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:29 --> Input Class Initialized
INFO - 2018-03-22 20:59:29 --> Language Class Initialized
INFO - 2018-03-22 20:59:29 --> Loader Class Initialized
INFO - 2018-03-22 20:59:29 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:29 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:29 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Controller Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:59:29 --> Final output sent to browser
DEBUG - 2018-03-22 20:59:29 --> Total execution time: 0.3448
INFO - 2018-03-22 20:59:29 --> Config Class Initialized
INFO - 2018-03-22 20:59:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:29 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:29 --> URI Class Initialized
INFO - 2018-03-22 20:59:29 --> Router Class Initialized
INFO - 2018-03-22 20:59:29 --> Output Class Initialized
INFO - 2018-03-22 20:59:29 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:29 --> Input Class Initialized
INFO - 2018-03-22 20:59:29 --> Language Class Initialized
INFO - 2018-03-22 20:59:29 --> Loader Class Initialized
INFO - 2018-03-22 20:59:29 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:29 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:29 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Controller Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
INFO - 2018-03-22 20:59:29 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:31 --> Config Class Initialized
INFO - 2018-03-22 20:59:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:31 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:31 --> URI Class Initialized
INFO - 2018-03-22 20:59:31 --> Router Class Initialized
INFO - 2018-03-22 20:59:31 --> Output Class Initialized
INFO - 2018-03-22 20:59:31 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:31 --> Input Class Initialized
INFO - 2018-03-22 20:59:31 --> Language Class Initialized
INFO - 2018-03-22 20:59:31 --> Loader Class Initialized
INFO - 2018-03-22 20:59:31 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:31 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:31 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
INFO - 2018-03-22 20:59:31 --> Controller Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
INFO - 2018-03-22 20:59:31 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:59:31 --> Final output sent to browser
DEBUG - 2018-03-22 20:59:31 --> Total execution time: 0.0578
INFO - 2018-03-22 20:59:31 --> Config Class Initialized
INFO - 2018-03-22 20:59:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:31 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:31 --> URI Class Initialized
INFO - 2018-03-22 20:59:31 --> Router Class Initialized
INFO - 2018-03-22 20:59:31 --> Output Class Initialized
INFO - 2018-03-22 20:59:31 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:31 --> Input Class Initialized
INFO - 2018-03-22 20:59:31 --> Language Class Initialized
INFO - 2018-03-22 20:59:31 --> Loader Class Initialized
INFO - 2018-03-22 20:59:32 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:32 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:32 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
INFO - 2018-03-22 20:59:32 --> Controller Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
INFO - 2018-03-22 20:59:32 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:35 --> Config Class Initialized
INFO - 2018-03-22 20:59:35 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:35 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:35 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:35 --> URI Class Initialized
INFO - 2018-03-22 20:59:35 --> Router Class Initialized
INFO - 2018-03-22 20:59:35 --> Output Class Initialized
INFO - 2018-03-22 20:59:35 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:35 --> Input Class Initialized
INFO - 2018-03-22 20:59:35 --> Language Class Initialized
INFO - 2018-03-22 20:59:35 --> Loader Class Initialized
INFO - 2018-03-22 20:59:35 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:35 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:35 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:35 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Controller Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:59:35 --> Final output sent to browser
DEBUG - 2018-03-22 20:59:35 --> Total execution time: 0.0859
INFO - 2018-03-22 20:59:35 --> Config Class Initialized
INFO - 2018-03-22 20:59:35 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:35 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:35 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:35 --> URI Class Initialized
INFO - 2018-03-22 20:59:35 --> Router Class Initialized
INFO - 2018-03-22 20:59:35 --> Output Class Initialized
INFO - 2018-03-22 20:59:35 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:35 --> Input Class Initialized
INFO - 2018-03-22 20:59:35 --> Language Class Initialized
INFO - 2018-03-22 20:59:35 --> Loader Class Initialized
INFO - 2018-03-22 20:59:35 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:35 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:35 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:35 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Controller Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
INFO - 2018-03-22 20:59:35 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:38 --> Config Class Initialized
INFO - 2018-03-22 20:59:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:38 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:38 --> URI Class Initialized
INFO - 2018-03-22 20:59:38 --> Router Class Initialized
INFO - 2018-03-22 20:59:38 --> Output Class Initialized
INFO - 2018-03-22 20:59:38 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:38 --> Input Class Initialized
INFO - 2018-03-22 20:59:38 --> Language Class Initialized
INFO - 2018-03-22 20:59:38 --> Loader Class Initialized
INFO - 2018-03-22 20:59:38 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:38 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:38 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:38 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Controller Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 20:59:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 20:59:38 --> Final output sent to browser
DEBUG - 2018-03-22 20:59:38 --> Total execution time: 0.0709
INFO - 2018-03-22 20:59:38 --> Config Class Initialized
INFO - 2018-03-22 20:59:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 20:59:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 20:59:38 --> Utf8 Class Initialized
INFO - 2018-03-22 20:59:38 --> URI Class Initialized
INFO - 2018-03-22 20:59:38 --> Router Class Initialized
INFO - 2018-03-22 20:59:38 --> Output Class Initialized
INFO - 2018-03-22 20:59:38 --> Security Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 20:59:38 --> Input Class Initialized
INFO - 2018-03-22 20:59:38 --> Language Class Initialized
INFO - 2018-03-22 20:59:38 --> Loader Class Initialized
INFO - 2018-03-22 20:59:38 --> Helper loaded: url_helper
INFO - 2018-03-22 20:59:38 --> Helper loaded: form_helper
INFO - 2018-03-22 20:59:38 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:59:38 --> Form Validation Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Controller Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
INFO - 2018-03-22 20:59:38 --> Model Class Initialized
DEBUG - 2018-03-22 20:59:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:09:29 --> Config Class Initialized
INFO - 2018-03-22 21:09:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:09:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:09:29 --> Utf8 Class Initialized
INFO - 2018-03-22 21:09:29 --> URI Class Initialized
INFO - 2018-03-22 21:09:29 --> Router Class Initialized
INFO - 2018-03-22 21:09:29 --> Output Class Initialized
INFO - 2018-03-22 21:09:29 --> Security Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:09:29 --> Input Class Initialized
INFO - 2018-03-22 21:09:29 --> Language Class Initialized
INFO - 2018-03-22 21:09:29 --> Loader Class Initialized
INFO - 2018-03-22 21:09:29 --> Helper loaded: url_helper
INFO - 2018-03-22 21:09:29 --> Helper loaded: form_helper
INFO - 2018-03-22 21:09:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:09:29 --> Form Validation Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Controller Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:09:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:09:29 --> Final output sent to browser
DEBUG - 2018-03-22 21:09:29 --> Total execution time: 0.0762
INFO - 2018-03-22 21:09:29 --> Config Class Initialized
INFO - 2018-03-22 21:09:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:09:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:09:29 --> Utf8 Class Initialized
INFO - 2018-03-22 21:09:29 --> URI Class Initialized
INFO - 2018-03-22 21:09:29 --> Router Class Initialized
INFO - 2018-03-22 21:09:29 --> Output Class Initialized
INFO - 2018-03-22 21:09:29 --> Security Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:09:29 --> Input Class Initialized
INFO - 2018-03-22 21:09:29 --> Language Class Initialized
INFO - 2018-03-22 21:09:29 --> Loader Class Initialized
INFO - 2018-03-22 21:09:29 --> Helper loaded: url_helper
INFO - 2018-03-22 21:09:29 --> Helper loaded: form_helper
INFO - 2018-03-22 21:09:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:09:29 --> Form Validation Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Controller Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
INFO - 2018-03-22 21:09:29 --> Model Class Initialized
DEBUG - 2018-03-22 21:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:23:52 --> Config Class Initialized
INFO - 2018-03-22 21:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:23:52 --> Utf8 Class Initialized
INFO - 2018-03-22 21:23:52 --> URI Class Initialized
INFO - 2018-03-22 21:23:52 --> Router Class Initialized
INFO - 2018-03-22 21:23:52 --> Output Class Initialized
INFO - 2018-03-22 21:23:52 --> Security Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:23:52 --> Input Class Initialized
INFO - 2018-03-22 21:23:52 --> Language Class Initialized
INFO - 2018-03-22 21:23:52 --> Loader Class Initialized
INFO - 2018-03-22 21:23:52 --> Helper loaded: url_helper
INFO - 2018-03-22 21:23:52 --> Helper loaded: form_helper
INFO - 2018-03-22 21:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:23:52 --> Form Validation Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Controller Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:23:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:23:52 --> Final output sent to browser
DEBUG - 2018-03-22 21:23:52 --> Total execution time: 0.1025
INFO - 2018-03-22 21:23:52 --> Config Class Initialized
INFO - 2018-03-22 21:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:23:52 --> Utf8 Class Initialized
INFO - 2018-03-22 21:23:52 --> URI Class Initialized
INFO - 2018-03-22 21:23:52 --> Router Class Initialized
INFO - 2018-03-22 21:23:52 --> Output Class Initialized
INFO - 2018-03-22 21:23:52 --> Security Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:23:52 --> Input Class Initialized
INFO - 2018-03-22 21:23:52 --> Language Class Initialized
INFO - 2018-03-22 21:23:52 --> Loader Class Initialized
INFO - 2018-03-22 21:23:52 --> Helper loaded: url_helper
INFO - 2018-03-22 21:23:52 --> Helper loaded: form_helper
INFO - 2018-03-22 21:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:23:52 --> Form Validation Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Controller Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
INFO - 2018-03-22 21:23:52 --> Model Class Initialized
DEBUG - 2018-03-22 21:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:24:05 --> Config Class Initialized
INFO - 2018-03-22 21:24:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:24:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:24:05 --> Utf8 Class Initialized
INFO - 2018-03-22 21:24:05 --> URI Class Initialized
INFO - 2018-03-22 21:24:05 --> Router Class Initialized
INFO - 2018-03-22 21:24:05 --> Output Class Initialized
INFO - 2018-03-22 21:24:06 --> Security Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:24:06 --> Input Class Initialized
INFO - 2018-03-22 21:24:06 --> Language Class Initialized
INFO - 2018-03-22 21:24:06 --> Loader Class Initialized
INFO - 2018-03-22 21:24:06 --> Helper loaded: url_helper
INFO - 2018-03-22 21:24:06 --> Helper loaded: form_helper
INFO - 2018-03-22 21:24:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:24:06 --> Form Validation Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Controller Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:24:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:24:06 --> Final output sent to browser
DEBUG - 2018-03-22 21:24:06 --> Total execution time: 0.1211
INFO - 2018-03-22 21:24:06 --> Config Class Initialized
INFO - 2018-03-22 21:24:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:24:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:24:06 --> Utf8 Class Initialized
INFO - 2018-03-22 21:24:06 --> URI Class Initialized
INFO - 2018-03-22 21:24:06 --> Router Class Initialized
INFO - 2018-03-22 21:24:06 --> Output Class Initialized
INFO - 2018-03-22 21:24:06 --> Security Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:24:06 --> Input Class Initialized
INFO - 2018-03-22 21:24:06 --> Language Class Initialized
INFO - 2018-03-22 21:24:06 --> Loader Class Initialized
INFO - 2018-03-22 21:24:06 --> Helper loaded: url_helper
INFO - 2018-03-22 21:24:06 --> Helper loaded: form_helper
INFO - 2018-03-22 21:24:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:24:06 --> Form Validation Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Controller Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
INFO - 2018-03-22 21:24:06 --> Model Class Initialized
DEBUG - 2018-03-22 21:24:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:24:08 --> Config Class Initialized
INFO - 2018-03-22 21:24:08 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:24:08 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:24:08 --> Utf8 Class Initialized
INFO - 2018-03-22 21:24:08 --> URI Class Initialized
INFO - 2018-03-22 21:24:08 --> Router Class Initialized
INFO - 2018-03-22 21:24:08 --> Output Class Initialized
INFO - 2018-03-22 21:24:08 --> Security Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:24:08 --> Input Class Initialized
INFO - 2018-03-22 21:24:08 --> Language Class Initialized
INFO - 2018-03-22 21:24:08 --> Loader Class Initialized
INFO - 2018-03-22 21:24:08 --> Helper loaded: url_helper
INFO - 2018-03-22 21:24:08 --> Helper loaded: form_helper
INFO - 2018-03-22 21:24:08 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:24:08 --> Form Validation Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Controller Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:24:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:24:08 --> Final output sent to browser
DEBUG - 2018-03-22 21:24:08 --> Total execution time: 0.1375
INFO - 2018-03-22 21:24:08 --> Config Class Initialized
INFO - 2018-03-22 21:24:08 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:24:08 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:24:08 --> Utf8 Class Initialized
INFO - 2018-03-22 21:24:08 --> URI Class Initialized
INFO - 2018-03-22 21:24:08 --> Router Class Initialized
INFO - 2018-03-22 21:24:08 --> Output Class Initialized
INFO - 2018-03-22 21:24:08 --> Security Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:24:08 --> Input Class Initialized
INFO - 2018-03-22 21:24:08 --> Language Class Initialized
INFO - 2018-03-22 21:24:08 --> Loader Class Initialized
INFO - 2018-03-22 21:24:08 --> Helper loaded: url_helper
INFO - 2018-03-22 21:24:08 --> Helper loaded: form_helper
INFO - 2018-03-22 21:24:08 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:24:08 --> Form Validation Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Controller Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
INFO - 2018-03-22 21:24:08 --> Model Class Initialized
DEBUG - 2018-03-22 21:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:25:21 --> Config Class Initialized
INFO - 2018-03-22 21:25:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:25:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:21 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:21 --> URI Class Initialized
INFO - 2018-03-22 21:25:21 --> Router Class Initialized
INFO - 2018-03-22 21:25:21 --> Output Class Initialized
INFO - 2018-03-22 21:25:21 --> Security Class Initialized
DEBUG - 2018-03-22 21:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:21 --> Input Class Initialized
INFO - 2018-03-22 21:25:21 --> Language Class Initialized
INFO - 2018-03-22 21:25:21 --> Loader Class Initialized
INFO - 2018-03-22 21:25:21 --> Helper loaded: url_helper
INFO - 2018-03-22 21:25:21 --> Helper loaded: form_helper
INFO - 2018-03-22 21:25:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:25:21 --> Form Validation Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
INFO - 2018-03-22 21:25:21 --> Controller Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
INFO - 2018-03-22 21:25:21 --> Model Class Initialized
DEBUG - 2018-03-22 21:25:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:25:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:25:21 --> Final output sent to browser
DEBUG - 2018-03-22 21:25:21 --> Total execution time: 0.0984
INFO - 2018-03-22 21:25:22 --> Config Class Initialized
INFO - 2018-03-22 21:25:22 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:25:22 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:22 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:22 --> URI Class Initialized
INFO - 2018-03-22 21:25:22 --> Router Class Initialized
INFO - 2018-03-22 21:25:22 --> Output Class Initialized
INFO - 2018-03-22 21:25:22 --> Security Class Initialized
DEBUG - 2018-03-22 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:22 --> Input Class Initialized
INFO - 2018-03-22 21:25:22 --> Language Class Initialized
INFO - 2018-03-22 21:25:22 --> Loader Class Initialized
INFO - 2018-03-22 21:25:22 --> Helper loaded: url_helper
INFO - 2018-03-22 21:25:22 --> Helper loaded: form_helper
INFO - 2018-03-22 21:25:22 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:25:22 --> Form Validation Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
INFO - 2018-03-22 21:25:22 --> Controller Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
INFO - 2018-03-22 21:25:22 --> Model Class Initialized
DEBUG - 2018-03-22 21:25:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:25:26 --> Config Class Initialized
INFO - 2018-03-22 21:25:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:25:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:25:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:25:26 --> URI Class Initialized
INFO - 2018-03-22 21:25:26 --> Router Class Initialized
INFO - 2018-03-22 21:25:26 --> Output Class Initialized
INFO - 2018-03-22 21:25:26 --> Security Class Initialized
DEBUG - 2018-03-22 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:25:26 --> Input Class Initialized
INFO - 2018-03-22 21:25:26 --> Language Class Initialized
ERROR - 2018-03-22 21:25:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
INFO - 2018-03-22 21:29:18 --> Loader Class Initialized
INFO - 2018-03-22 21:29:18 --> Helper loaded: url_helper
INFO - 2018-03-22 21:29:18 --> Helper loaded: form_helper
INFO - 2018-03-22 21:29:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:29:18 --> Form Validation Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Controller Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:29:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:29:18 --> Final output sent to browser
DEBUG - 2018-03-22 21:29:18 --> Total execution time: 0.1157
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
ERROR - 2018-03-22 21:29:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:29:18 --> Config Class Initialized
INFO - 2018-03-22 21:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:29:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:29:18 --> URI Class Initialized
INFO - 2018-03-22 21:29:18 --> Router Class Initialized
INFO - 2018-03-22 21:29:18 --> Output Class Initialized
INFO - 2018-03-22 21:29:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:29:18 --> Input Class Initialized
INFO - 2018-03-22 21:29:18 --> Language Class Initialized
INFO - 2018-03-22 21:29:18 --> Loader Class Initialized
INFO - 2018-03-22 21:29:18 --> Helper loaded: url_helper
INFO - 2018-03-22 21:29:18 --> Helper loaded: form_helper
INFO - 2018-03-22 21:29:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:29:18 --> Form Validation Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Controller Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
INFO - 2018-03-22 21:29:18 --> Model Class Initialized
DEBUG - 2018-03-22 21:29:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:37:55 --> Config Class Initialized
INFO - 2018-03-22 21:37:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:37:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:55 --> URI Class Initialized
INFO - 2018-03-22 21:37:55 --> Router Class Initialized
INFO - 2018-03-22 21:37:55 --> Output Class Initialized
INFO - 2018-03-22 21:37:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:55 --> Input Class Initialized
INFO - 2018-03-22 21:37:55 --> Language Class Initialized
INFO - 2018-03-22 21:37:55 --> Loader Class Initialized
INFO - 2018-03-22 21:37:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:37:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:37:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:37:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
INFO - 2018-03-22 21:37:55 --> Controller Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
INFO - 2018-03-22 21:37:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:37:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:37:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:37:56 --> Final output sent to browser
DEBUG - 2018-03-22 21:37:56 --> Total execution time: 0.1284
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
ERROR - 2018-03-22 21:37:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:37:56 --> Config Class Initialized
INFO - 2018-03-22 21:37:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:37:56 --> URI Class Initialized
INFO - 2018-03-22 21:37:56 --> Router Class Initialized
INFO - 2018-03-22 21:37:56 --> Output Class Initialized
INFO - 2018-03-22 21:37:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:37:56 --> Input Class Initialized
INFO - 2018-03-22 21:37:56 --> Language Class Initialized
INFO - 2018-03-22 21:37:56 --> Loader Class Initialized
INFO - 2018-03-22 21:37:56 --> Helper loaded: url_helper
INFO - 2018-03-22 21:37:56 --> Helper loaded: form_helper
INFO - 2018-03-22 21:37:56 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:37:56 --> Form Validation Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
INFO - 2018-03-22 21:37:56 --> Controller Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
INFO - 2018-03-22 21:37:56 --> Model Class Initialized
DEBUG - 2018-03-22 21:37:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
INFO - 2018-03-22 21:38:50 --> Loader Class Initialized
INFO - 2018-03-22 21:38:50 --> Helper loaded: url_helper
INFO - 2018-03-22 21:38:50 --> Helper loaded: form_helper
INFO - 2018-03-22 21:38:50 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:38:50 --> Form Validation Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Controller Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:38:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:38:50 --> Final output sent to browser
DEBUG - 2018-03-22 21:38:50 --> Total execution time: 0.2035
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
ERROR - 2018-03-22 21:38:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:38:50 --> Config Class Initialized
INFO - 2018-03-22 21:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:38:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:38:50 --> URI Class Initialized
INFO - 2018-03-22 21:38:50 --> Router Class Initialized
INFO - 2018-03-22 21:38:50 --> Output Class Initialized
INFO - 2018-03-22 21:38:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:38:50 --> Input Class Initialized
INFO - 2018-03-22 21:38:50 --> Language Class Initialized
INFO - 2018-03-22 21:38:50 --> Loader Class Initialized
INFO - 2018-03-22 21:38:50 --> Helper loaded: url_helper
INFO - 2018-03-22 21:38:50 --> Helper loaded: form_helper
INFO - 2018-03-22 21:38:50 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:38:50 --> Form Validation Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Controller Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
INFO - 2018-03-22 21:38:50 --> Model Class Initialized
DEBUG - 2018-03-22 21:38:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:39:17 --> Config Class Initialized
INFO - 2018-03-22 21:39:17 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:39:17 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:39:17 --> Utf8 Class Initialized
INFO - 2018-03-22 21:39:17 --> URI Class Initialized
INFO - 2018-03-22 21:39:17 --> Router Class Initialized
INFO - 2018-03-22 21:39:17 --> Output Class Initialized
INFO - 2018-03-22 21:39:17 --> Security Class Initialized
DEBUG - 2018-03-22 21:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:39:17 --> Input Class Initialized
INFO - 2018-03-22 21:39:17 --> Language Class Initialized
INFO - 2018-03-22 21:39:17 --> Loader Class Initialized
INFO - 2018-03-22 21:39:17 --> Helper loaded: url_helper
INFO - 2018-03-22 21:39:17 --> Helper loaded: form_helper
INFO - 2018-03-22 21:39:17 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:39:17 --> Form Validation Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
INFO - 2018-03-22 21:39:17 --> Controller Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
INFO - 2018-03-22 21:39:17 --> Model Class Initialized
DEBUG - 2018-03-22 21:39:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:39:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:39:17 --> Final output sent to browser
DEBUG - 2018-03-22 21:39:17 --> Total execution time: 0.6434
INFO - 2018-03-22 21:39:18 --> Config Class Initialized
INFO - 2018-03-22 21:39:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:39:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:39:18 --> Utf8 Class Initialized
INFO - 2018-03-22 21:39:18 --> URI Class Initialized
INFO - 2018-03-22 21:39:18 --> Router Class Initialized
INFO - 2018-03-22 21:39:18 --> Output Class Initialized
INFO - 2018-03-22 21:39:18 --> Security Class Initialized
DEBUG - 2018-03-22 21:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:39:18 --> Input Class Initialized
INFO - 2018-03-22 21:39:18 --> Language Class Initialized
INFO - 2018-03-22 21:39:18 --> Loader Class Initialized
INFO - 2018-03-22 21:39:18 --> Helper loaded: url_helper
INFO - 2018-03-22 21:39:18 --> Helper loaded: form_helper
INFO - 2018-03-22 21:39:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:39:18 --> Form Validation Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
INFO - 2018-03-22 21:39:18 --> Controller Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
INFO - 2018-03-22 21:39:18 --> Model Class Initialized
DEBUG - 2018-03-22 21:39:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:39:25 --> Config Class Initialized
INFO - 2018-03-22 21:39:25 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:39:25 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:39:25 --> Utf8 Class Initialized
INFO - 2018-03-22 21:39:25 --> URI Class Initialized
INFO - 2018-03-22 21:39:25 --> Router Class Initialized
INFO - 2018-03-22 21:39:25 --> Output Class Initialized
INFO - 2018-03-22 21:39:25 --> Security Class Initialized
DEBUG - 2018-03-22 21:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:39:25 --> Input Class Initialized
INFO - 2018-03-22 21:39:25 --> Language Class Initialized
INFO - 2018-03-22 21:39:25 --> Loader Class Initialized
INFO - 2018-03-22 21:39:25 --> Helper loaded: url_helper
INFO - 2018-03-22 21:39:25 --> Helper loaded: form_helper
INFO - 2018-03-22 21:39:25 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:39:25 --> Form Validation Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
INFO - 2018-03-22 21:39:25 --> Controller Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
INFO - 2018-03-22 21:39:25 --> Model Class Initialized
DEBUG - 2018-03-22 21:39:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:39:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:39:26 --> Final output sent to browser
DEBUG - 2018-03-22 21:39:26 --> Total execution time: 0.5511
INFO - 2018-03-22 21:39:26 --> Config Class Initialized
INFO - 2018-03-22 21:39:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:39:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:39:26 --> Utf8 Class Initialized
INFO - 2018-03-22 21:39:26 --> URI Class Initialized
INFO - 2018-03-22 21:39:26 --> Router Class Initialized
INFO - 2018-03-22 21:39:26 --> Output Class Initialized
INFO - 2018-03-22 21:39:26 --> Security Class Initialized
DEBUG - 2018-03-22 21:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:39:26 --> Input Class Initialized
INFO - 2018-03-22 21:39:26 --> Language Class Initialized
INFO - 2018-03-22 21:39:26 --> Loader Class Initialized
INFO - 2018-03-22 21:39:26 --> Helper loaded: url_helper
INFO - 2018-03-22 21:39:26 --> Helper loaded: form_helper
INFO - 2018-03-22 21:39:26 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:39:26 --> Form Validation Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
INFO - 2018-03-22 21:39:26 --> Controller Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
INFO - 2018-03-22 21:39:26 --> Model Class Initialized
DEBUG - 2018-03-22 21:39:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:44:50 --> Config Class Initialized
INFO - 2018-03-22 21:44:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:44:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:44:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:44:50 --> URI Class Initialized
INFO - 2018-03-22 21:44:50 --> Router Class Initialized
INFO - 2018-03-22 21:44:50 --> Output Class Initialized
INFO - 2018-03-22 21:44:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:44:50 --> Input Class Initialized
INFO - 2018-03-22 21:44:50 --> Language Class Initialized
INFO - 2018-03-22 21:44:50 --> Loader Class Initialized
INFO - 2018-03-22 21:44:50 --> Helper loaded: url_helper
INFO - 2018-03-22 21:44:50 --> Helper loaded: form_helper
INFO - 2018-03-22 21:44:50 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:44:50 --> Form Validation Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Controller Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:44:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:44:50 --> Final output sent to browser
DEBUG - 2018-03-22 21:44:50 --> Total execution time: 0.1362
INFO - 2018-03-22 21:44:50 --> Config Class Initialized
INFO - 2018-03-22 21:44:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:44:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:44:50 --> Utf8 Class Initialized
INFO - 2018-03-22 21:44:50 --> URI Class Initialized
INFO - 2018-03-22 21:44:50 --> Router Class Initialized
INFO - 2018-03-22 21:44:50 --> Output Class Initialized
INFO - 2018-03-22 21:44:50 --> Security Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:44:50 --> Input Class Initialized
INFO - 2018-03-22 21:44:50 --> Language Class Initialized
INFO - 2018-03-22 21:44:50 --> Loader Class Initialized
INFO - 2018-03-22 21:44:50 --> Helper loaded: url_helper
INFO - 2018-03-22 21:44:50 --> Helper loaded: form_helper
INFO - 2018-03-22 21:44:50 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:44:50 --> Form Validation Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Controller Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
INFO - 2018-03-22 21:44:50 --> Model Class Initialized
DEBUG - 2018-03-22 21:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:44:58 --> Config Class Initialized
INFO - 2018-03-22 21:44:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:44:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:44:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:44:58 --> URI Class Initialized
INFO - 2018-03-22 21:44:58 --> Router Class Initialized
INFO - 2018-03-22 21:44:58 --> Output Class Initialized
INFO - 2018-03-22 21:44:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:44:58 --> Input Class Initialized
INFO - 2018-03-22 21:44:58 --> Language Class Initialized
INFO - 2018-03-22 21:44:58 --> Loader Class Initialized
INFO - 2018-03-22 21:44:58 --> Helper loaded: url_helper
INFO - 2018-03-22 21:44:58 --> Helper loaded: form_helper
INFO - 2018-03-22 21:44:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:44:58 --> Form Validation Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
INFO - 2018-03-22 21:44:58 --> Controller Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
INFO - 2018-03-22 21:44:58 --> Model Class Initialized
DEBUG - 2018-03-22 21:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:10 --> Config Class Initialized
INFO - 2018-03-22 21:45:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:10 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:10 --> URI Class Initialized
INFO - 2018-03-22 21:45:10 --> Router Class Initialized
INFO - 2018-03-22 21:45:10 --> Output Class Initialized
INFO - 2018-03-22 21:45:10 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:10 --> Input Class Initialized
INFO - 2018-03-22 21:45:10 --> Language Class Initialized
INFO - 2018-03-22 21:45:10 --> Loader Class Initialized
INFO - 2018-03-22 21:45:10 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:10 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:10 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:10 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
INFO - 2018-03-22 21:45:10 --> Controller Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
INFO - 2018-03-22 21:45:10 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:45:10 --> Final output sent to browser
DEBUG - 2018-03-22 21:45:10 --> Total execution time: 0.4234
INFO - 2018-03-22 21:45:11 --> Config Class Initialized
INFO - 2018-03-22 21:45:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:11 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:11 --> URI Class Initialized
INFO - 2018-03-22 21:45:11 --> Router Class Initialized
INFO - 2018-03-22 21:45:11 --> Output Class Initialized
INFO - 2018-03-22 21:45:11 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:11 --> Input Class Initialized
INFO - 2018-03-22 21:45:11 --> Language Class Initialized
INFO - 2018-03-22 21:45:11 --> Loader Class Initialized
INFO - 2018-03-22 21:45:11 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:11 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:11 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
INFO - 2018-03-22 21:45:11 --> Controller Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
INFO - 2018-03-22 21:45:11 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:16 --> Config Class Initialized
INFO - 2018-03-22 21:45:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:16 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:16 --> URI Class Initialized
INFO - 2018-03-22 21:45:16 --> Router Class Initialized
INFO - 2018-03-22 21:45:16 --> Output Class Initialized
INFO - 2018-03-22 21:45:16 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:16 --> Input Class Initialized
INFO - 2018-03-22 21:45:16 --> Language Class Initialized
INFO - 2018-03-22 21:45:16 --> Loader Class Initialized
INFO - 2018-03-22 21:45:16 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:16 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:16 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
INFO - 2018-03-22 21:45:16 --> Controller Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
INFO - 2018-03-22 21:45:16 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:23 --> Config Class Initialized
INFO - 2018-03-22 21:45:23 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:23 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:23 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:23 --> URI Class Initialized
INFO - 2018-03-22 21:45:23 --> Router Class Initialized
INFO - 2018-03-22 21:45:23 --> Output Class Initialized
INFO - 2018-03-22 21:45:23 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:23 --> Input Class Initialized
INFO - 2018-03-22 21:45:23 --> Language Class Initialized
INFO - 2018-03-22 21:45:23 --> Loader Class Initialized
INFO - 2018-03-22 21:45:23 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:23 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:23 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:23 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
INFO - 2018-03-22 21:45:23 --> Controller Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
INFO - 2018-03-22 21:45:23 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:45:24 --> Final output sent to browser
DEBUG - 2018-03-22 21:45:24 --> Total execution time: 0.5452
INFO - 2018-03-22 21:45:24 --> Config Class Initialized
INFO - 2018-03-22 21:45:24 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:24 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:24 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:24 --> URI Class Initialized
INFO - 2018-03-22 21:45:24 --> Router Class Initialized
INFO - 2018-03-22 21:45:24 --> Output Class Initialized
INFO - 2018-03-22 21:45:24 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:24 --> Input Class Initialized
INFO - 2018-03-22 21:45:24 --> Language Class Initialized
INFO - 2018-03-22 21:45:24 --> Loader Class Initialized
INFO - 2018-03-22 21:45:24 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:24 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:24 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:24 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
INFO - 2018-03-22 21:45:24 --> Controller Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
INFO - 2018-03-22 21:45:24 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:45:27 --> Config Class Initialized
INFO - 2018-03-22 21:45:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:45:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:45:27 --> Utf8 Class Initialized
INFO - 2018-03-22 21:45:27 --> URI Class Initialized
INFO - 2018-03-22 21:45:27 --> Router Class Initialized
INFO - 2018-03-22 21:45:27 --> Output Class Initialized
INFO - 2018-03-22 21:45:27 --> Security Class Initialized
DEBUG - 2018-03-22 21:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:45:27 --> Input Class Initialized
INFO - 2018-03-22 21:45:27 --> Language Class Initialized
INFO - 2018-03-22 21:45:27 --> Loader Class Initialized
INFO - 2018-03-22 21:45:27 --> Helper loaded: url_helper
INFO - 2018-03-22 21:45:27 --> Helper loaded: form_helper
INFO - 2018-03-22 21:45:27 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:45:27 --> Form Validation Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
INFO - 2018-03-22 21:45:27 --> Controller Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
INFO - 2018-03-22 21:45:27 --> Model Class Initialized
DEBUG - 2018-03-22 21:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:13 --> Config Class Initialized
INFO - 2018-03-22 21:46:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:13 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:13 --> URI Class Initialized
INFO - 2018-03-22 21:46:13 --> Router Class Initialized
INFO - 2018-03-22 21:46:13 --> Output Class Initialized
INFO - 2018-03-22 21:46:13 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:13 --> Input Class Initialized
INFO - 2018-03-22 21:46:13 --> Language Class Initialized
INFO - 2018-03-22 21:46:13 --> Loader Class Initialized
INFO - 2018-03-22 21:46:13 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:13 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:13 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:13 --> Model Class Initialized
INFO - 2018-03-22 21:46:13 --> Controller Class Initialized
INFO - 2018-03-22 21:46:13 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:13 --> Config Class Initialized
INFO - 2018-03-22 21:46:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:13 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:13 --> URI Class Initialized
INFO - 2018-03-22 21:46:13 --> Router Class Initialized
INFO - 2018-03-22 21:46:13 --> Output Class Initialized
INFO - 2018-03-22 21:46:13 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:13 --> Input Class Initialized
INFO - 2018-03-22 21:46:13 --> Language Class Initialized
INFO - 2018-03-22 21:46:13 --> Loader Class Initialized
INFO - 2018-03-22 21:46:13 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:13 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:14 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:14 --> Model Class Initialized
INFO - 2018-03-22 21:46:14 --> Controller Class Initialized
INFO - 2018-03-22 21:46:14 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:14 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:14 --> Total execution time: 0.0622
INFO - 2018-03-22 21:46:14 --> Config Class Initialized
INFO - 2018-03-22 21:46:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:14 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:14 --> URI Class Initialized
INFO - 2018-03-22 21:46:14 --> Router Class Initialized
INFO - 2018-03-22 21:46:14 --> Output Class Initialized
INFO - 2018-03-22 21:46:14 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:14 --> Input Class Initialized
INFO - 2018-03-22 21:46:14 --> Language Class Initialized
INFO - 2018-03-22 21:46:14 --> Loader Class Initialized
INFO - 2018-03-22 21:46:14 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:14 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:14 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:14 --> Model Class Initialized
INFO - 2018-03-22 21:46:14 --> Controller Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 21:46:15 --> Config Class Initialized
INFO - 2018-03-22 21:46:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:15 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:15 --> URI Class Initialized
DEBUG - 2018-03-22 21:46:15 --> No URI present. Default controller set.
INFO - 2018-03-22 21:46:15 --> Router Class Initialized
INFO - 2018-03-22 21:46:15 --> Output Class Initialized
INFO - 2018-03-22 21:46:15 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:15 --> Input Class Initialized
INFO - 2018-03-22 21:46:15 --> Language Class Initialized
INFO - 2018-03-22 21:46:15 --> Loader Class Initialized
INFO - 2018-03-22 21:46:15 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:15 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:15 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Controller Class Initialized
INFO - 2018-03-22 21:46:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:15 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:15 --> Total execution time: 0.0854
INFO - 2018-03-22 21:46:15 --> Config Class Initialized
INFO - 2018-03-22 21:46:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:15 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:15 --> URI Class Initialized
INFO - 2018-03-22 21:46:15 --> Router Class Initialized
INFO - 2018-03-22 21:46:15 --> Output Class Initialized
INFO - 2018-03-22 21:46:15 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:15 --> Input Class Initialized
INFO - 2018-03-22 21:46:15 --> Language Class Initialized
INFO - 2018-03-22 21:46:15 --> Loader Class Initialized
INFO - 2018-03-22 21:46:15 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:15 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:15 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Controller Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
INFO - 2018-03-22 21:46:15 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:16 --> Config Class Initialized
INFO - 2018-03-22 21:46:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:16 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:16 --> URI Class Initialized
INFO - 2018-03-22 21:46:16 --> Router Class Initialized
INFO - 2018-03-22 21:46:16 --> Output Class Initialized
INFO - 2018-03-22 21:46:16 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:16 --> Input Class Initialized
INFO - 2018-03-22 21:46:16 --> Language Class Initialized
INFO - 2018-03-22 21:46:16 --> Loader Class Initialized
INFO - 2018-03-22 21:46:16 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:16 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:16 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:16 --> Model Class Initialized
INFO - 2018-03-22 21:46:16 --> Controller Class Initialized
INFO - 2018-03-22 21:46:16 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:16 --> Config Class Initialized
INFO - 2018-03-22 21:46:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:16 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:16 --> URI Class Initialized
INFO - 2018-03-22 21:46:16 --> Router Class Initialized
INFO - 2018-03-22 21:46:16 --> Output Class Initialized
INFO - 2018-03-22 21:46:16 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:16 --> Input Class Initialized
INFO - 2018-03-22 21:46:16 --> Language Class Initialized
INFO - 2018-03-22 21:46:16 --> Loader Class Initialized
INFO - 2018-03-22 21:46:16 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:16 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:16 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:16 --> Model Class Initialized
INFO - 2018-03-22 21:46:16 --> Controller Class Initialized
INFO - 2018-03-22 21:46:16 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:16 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:16 --> Total execution time: 0.0664
INFO - 2018-03-22 21:46:19 --> Config Class Initialized
INFO - 2018-03-22 21:46:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:19 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:19 --> URI Class Initialized
INFO - 2018-03-22 21:46:19 --> Router Class Initialized
INFO - 2018-03-22 21:46:19 --> Output Class Initialized
INFO - 2018-03-22 21:46:19 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:19 --> Input Class Initialized
INFO - 2018-03-22 21:46:19 --> Language Class Initialized
INFO - 2018-03-22 21:46:19 --> Loader Class Initialized
INFO - 2018-03-22 21:46:19 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:19 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:19 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Controller Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 21:46:19 --> Config Class Initialized
INFO - 2018-03-22 21:46:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:19 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:19 --> URI Class Initialized
DEBUG - 2018-03-22 21:46:19 --> No URI present. Default controller set.
INFO - 2018-03-22 21:46:19 --> Router Class Initialized
INFO - 2018-03-22 21:46:19 --> Output Class Initialized
INFO - 2018-03-22 21:46:19 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:19 --> Input Class Initialized
INFO - 2018-03-22 21:46:19 --> Language Class Initialized
INFO - 2018-03-22 21:46:19 --> Loader Class Initialized
INFO - 2018-03-22 21:46:19 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:19 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:19 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Controller Class Initialized
INFO - 2018-03-22 21:46:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:19 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:19 --> Total execution time: 0.0727
INFO - 2018-03-22 21:46:19 --> Config Class Initialized
INFO - 2018-03-22 21:46:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:19 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:19 --> URI Class Initialized
INFO - 2018-03-22 21:46:19 --> Router Class Initialized
INFO - 2018-03-22 21:46:19 --> Output Class Initialized
INFO - 2018-03-22 21:46:19 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:19 --> Input Class Initialized
INFO - 2018-03-22 21:46:19 --> Language Class Initialized
INFO - 2018-03-22 21:46:19 --> Loader Class Initialized
INFO - 2018-03-22 21:46:19 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:19 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:19 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Controller Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
INFO - 2018-03-22 21:46:19 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:20 --> Config Class Initialized
INFO - 2018-03-22 21:46:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:20 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:20 --> URI Class Initialized
INFO - 2018-03-22 21:46:20 --> Router Class Initialized
INFO - 2018-03-22 21:46:20 --> Output Class Initialized
INFO - 2018-03-22 21:46:20 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:20 --> Input Class Initialized
INFO - 2018-03-22 21:46:20 --> Language Class Initialized
INFO - 2018-03-22 21:46:20 --> Loader Class Initialized
INFO - 2018-03-22 21:46:20 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:20 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:20 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:20 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
INFO - 2018-03-22 21:46:20 --> Controller Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
INFO - 2018-03-22 21:46:20 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:21 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:21 --> Total execution time: 0.1279
INFO - 2018-03-22 21:46:21 --> Config Class Initialized
INFO - 2018-03-22 21:46:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:21 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:21 --> URI Class Initialized
INFO - 2018-03-22 21:46:21 --> Router Class Initialized
INFO - 2018-03-22 21:46:21 --> Output Class Initialized
INFO - 2018-03-22 21:46:21 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:21 --> Input Class Initialized
INFO - 2018-03-22 21:46:21 --> Language Class Initialized
INFO - 2018-03-22 21:46:21 --> Loader Class Initialized
INFO - 2018-03-22 21:46:21 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:21 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:21 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
INFO - 2018-03-22 21:46:21 --> Controller Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
INFO - 2018-03-22 21:46:21 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:25 --> Config Class Initialized
INFO - 2018-03-22 21:46:25 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:25 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:25 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:25 --> URI Class Initialized
INFO - 2018-03-22 21:46:25 --> Router Class Initialized
INFO - 2018-03-22 21:46:25 --> Output Class Initialized
INFO - 2018-03-22 21:46:25 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:25 --> Input Class Initialized
INFO - 2018-03-22 21:46:25 --> Language Class Initialized
INFO - 2018-03-22 21:46:25 --> Loader Class Initialized
INFO - 2018-03-22 21:46:25 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:25 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:25 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:25 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:25 --> Model Class Initialized
INFO - 2018-03-22 21:46:25 --> Controller Class Initialized
INFO - 2018-03-22 21:46:25 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:25 --> Config Class Initialized
INFO - 2018-03-22 21:46:25 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:25 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:25 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:25 --> URI Class Initialized
INFO - 2018-03-22 21:46:25 --> Router Class Initialized
INFO - 2018-03-22 21:46:25 --> Output Class Initialized
INFO - 2018-03-22 21:46:25 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:25 --> Input Class Initialized
INFO - 2018-03-22 21:46:25 --> Language Class Initialized
INFO - 2018-03-22 21:46:25 --> Loader Class Initialized
INFO - 2018-03-22 21:46:25 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:25 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:25 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:25 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:25 --> Model Class Initialized
INFO - 2018-03-22 21:46:25 --> Controller Class Initialized
INFO - 2018-03-22 21:46:25 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:25 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:25 --> Total execution time: 0.0814
INFO - 2018-03-22 21:46:30 --> Config Class Initialized
INFO - 2018-03-22 21:46:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:30 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:30 --> URI Class Initialized
INFO - 2018-03-22 21:46:30 --> Router Class Initialized
INFO - 2018-03-22 21:46:30 --> Output Class Initialized
INFO - 2018-03-22 21:46:30 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:30 --> Input Class Initialized
INFO - 2018-03-22 21:46:30 --> Language Class Initialized
INFO - 2018-03-22 21:46:30 --> Loader Class Initialized
INFO - 2018-03-22 21:46:30 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:30 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:30 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Controller Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 21:46:30 --> Config Class Initialized
INFO - 2018-03-22 21:46:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:30 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:30 --> URI Class Initialized
DEBUG - 2018-03-22 21:46:30 --> No URI present. Default controller set.
INFO - 2018-03-22 21:46:30 --> Router Class Initialized
INFO - 2018-03-22 21:46:30 --> Output Class Initialized
INFO - 2018-03-22 21:46:30 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:30 --> Input Class Initialized
INFO - 2018-03-22 21:46:30 --> Language Class Initialized
INFO - 2018-03-22 21:46:30 --> Loader Class Initialized
INFO - 2018-03-22 21:46:30 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:30 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:30 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Controller Class Initialized
INFO - 2018-03-22 21:46:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:30 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:30 --> Total execution time: 0.0722
INFO - 2018-03-22 21:46:30 --> Config Class Initialized
INFO - 2018-03-22 21:46:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:30 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:30 --> URI Class Initialized
INFO - 2018-03-22 21:46:30 --> Router Class Initialized
INFO - 2018-03-22 21:46:30 --> Output Class Initialized
INFO - 2018-03-22 21:46:30 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:30 --> Input Class Initialized
INFO - 2018-03-22 21:46:30 --> Language Class Initialized
INFO - 2018-03-22 21:46:30 --> Loader Class Initialized
INFO - 2018-03-22 21:46:30 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:30 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:30 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Controller Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
INFO - 2018-03-22 21:46:30 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:32 --> Config Class Initialized
INFO - 2018-03-22 21:46:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:32 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:32 --> URI Class Initialized
INFO - 2018-03-22 21:46:32 --> Router Class Initialized
INFO - 2018-03-22 21:46:32 --> Output Class Initialized
INFO - 2018-03-22 21:46:32 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:32 --> Input Class Initialized
INFO - 2018-03-22 21:46:32 --> Language Class Initialized
INFO - 2018-03-22 21:46:32 --> Loader Class Initialized
INFO - 2018-03-22 21:46:32 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:32 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:32 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Controller Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:46:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:46:32 --> Final output sent to browser
DEBUG - 2018-03-22 21:46:32 --> Total execution time: 0.1369
INFO - 2018-03-22 21:46:32 --> Config Class Initialized
INFO - 2018-03-22 21:46:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:46:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:46:32 --> Utf8 Class Initialized
INFO - 2018-03-22 21:46:32 --> URI Class Initialized
INFO - 2018-03-22 21:46:32 --> Router Class Initialized
INFO - 2018-03-22 21:46:32 --> Output Class Initialized
INFO - 2018-03-22 21:46:32 --> Security Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:46:32 --> Input Class Initialized
INFO - 2018-03-22 21:46:32 --> Language Class Initialized
INFO - 2018-03-22 21:46:32 --> Loader Class Initialized
INFO - 2018-03-22 21:46:32 --> Helper loaded: url_helper
INFO - 2018-03-22 21:46:32 --> Helper loaded: form_helper
INFO - 2018-03-22 21:46:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:46:32 --> Form Validation Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Controller Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
INFO - 2018-03-22 21:46:32 --> Model Class Initialized
DEBUG - 2018-03-22 21:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:48:54 --> Config Class Initialized
INFO - 2018-03-22 21:48:54 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:48:54 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:48:54 --> Utf8 Class Initialized
INFO - 2018-03-22 21:48:54 --> URI Class Initialized
INFO - 2018-03-22 21:48:54 --> Router Class Initialized
INFO - 2018-03-22 21:48:54 --> Output Class Initialized
INFO - 2018-03-22 21:48:54 --> Security Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:48:54 --> Input Class Initialized
INFO - 2018-03-22 21:48:54 --> Language Class Initialized
INFO - 2018-03-22 21:48:54 --> Loader Class Initialized
INFO - 2018-03-22 21:48:54 --> Helper loaded: url_helper
INFO - 2018-03-22 21:48:54 --> Helper loaded: form_helper
INFO - 2018-03-22 21:48:54 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:48:54 --> Form Validation Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Controller Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:48:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:48:54 --> Final output sent to browser
DEBUG - 2018-03-22 21:48:54 --> Total execution time: 0.1616
INFO - 2018-03-22 21:48:54 --> Config Class Initialized
INFO - 2018-03-22 21:48:54 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:48:54 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:48:54 --> Utf8 Class Initialized
INFO - 2018-03-22 21:48:54 --> URI Class Initialized
INFO - 2018-03-22 21:48:54 --> Router Class Initialized
INFO - 2018-03-22 21:48:54 --> Output Class Initialized
INFO - 2018-03-22 21:48:54 --> Security Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:48:54 --> Input Class Initialized
INFO - 2018-03-22 21:48:54 --> Language Class Initialized
INFO - 2018-03-22 21:48:54 --> Loader Class Initialized
INFO - 2018-03-22 21:48:54 --> Helper loaded: url_helper
INFO - 2018-03-22 21:48:54 --> Helper loaded: form_helper
INFO - 2018-03-22 21:48:54 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:48:54 --> Form Validation Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Controller Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
INFO - 2018-03-22 21:48:54 --> Model Class Initialized
DEBUG - 2018-03-22 21:48:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:49:55 --> Config Class Initialized
INFO - 2018-03-22 21:49:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:49:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:49:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:49:55 --> URI Class Initialized
INFO - 2018-03-22 21:49:55 --> Router Class Initialized
INFO - 2018-03-22 21:49:55 --> Output Class Initialized
INFO - 2018-03-22 21:49:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:49:55 --> Input Class Initialized
INFO - 2018-03-22 21:49:55 --> Language Class Initialized
INFO - 2018-03-22 21:49:55 --> Loader Class Initialized
INFO - 2018-03-22 21:49:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:49:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:49:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:49:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Controller Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:49:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:49:55 --> Final output sent to browser
DEBUG - 2018-03-22 21:49:55 --> Total execution time: 0.1575
INFO - 2018-03-22 21:49:55 --> Config Class Initialized
INFO - 2018-03-22 21:49:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:49:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:49:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:49:55 --> URI Class Initialized
INFO - 2018-03-22 21:49:55 --> Router Class Initialized
INFO - 2018-03-22 21:49:55 --> Output Class Initialized
INFO - 2018-03-22 21:49:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:49:55 --> Input Class Initialized
INFO - 2018-03-22 21:49:55 --> Language Class Initialized
INFO - 2018-03-22 21:49:55 --> Loader Class Initialized
INFO - 2018-03-22 21:49:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:49:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:49:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:49:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Controller Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
INFO - 2018-03-22 21:49:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:02 --> Config Class Initialized
INFO - 2018-03-22 21:50:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:02 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:02 --> URI Class Initialized
INFO - 2018-03-22 21:50:02 --> Router Class Initialized
INFO - 2018-03-22 21:50:02 --> Output Class Initialized
INFO - 2018-03-22 21:50:02 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:02 --> Input Class Initialized
INFO - 2018-03-22 21:50:02 --> Language Class Initialized
INFO - 2018-03-22 21:50:02 --> Loader Class Initialized
INFO - 2018-03-22 21:50:02 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:02 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:02 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Controller Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:50:02 --> Final output sent to browser
DEBUG - 2018-03-22 21:50:02 --> Total execution time: 0.1142
INFO - 2018-03-22 21:50:02 --> Config Class Initialized
INFO - 2018-03-22 21:50:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:02 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:02 --> URI Class Initialized
INFO - 2018-03-22 21:50:02 --> Router Class Initialized
INFO - 2018-03-22 21:50:02 --> Output Class Initialized
INFO - 2018-03-22 21:50:02 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:02 --> Input Class Initialized
INFO - 2018-03-22 21:50:02 --> Language Class Initialized
INFO - 2018-03-22 21:50:02 --> Loader Class Initialized
INFO - 2018-03-22 21:50:02 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:02 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:02 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Controller Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
INFO - 2018-03-22 21:50:02 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:04 --> Config Class Initialized
INFO - 2018-03-22 21:50:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:04 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:04 --> URI Class Initialized
INFO - 2018-03-22 21:50:04 --> Router Class Initialized
INFO - 2018-03-22 21:50:04 --> Output Class Initialized
INFO - 2018-03-22 21:50:04 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:04 --> Input Class Initialized
INFO - 2018-03-22 21:50:04 --> Language Class Initialized
INFO - 2018-03-22 21:50:04 --> Loader Class Initialized
INFO - 2018-03-22 21:50:04 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:04 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:04 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:04 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Controller Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:50:04 --> Final output sent to browser
DEBUG - 2018-03-22 21:50:04 --> Total execution time: 0.1453
INFO - 2018-03-22 21:50:04 --> Config Class Initialized
INFO - 2018-03-22 21:50:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:04 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:04 --> URI Class Initialized
INFO - 2018-03-22 21:50:04 --> Router Class Initialized
INFO - 2018-03-22 21:50:04 --> Output Class Initialized
INFO - 2018-03-22 21:50:04 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:04 --> Input Class Initialized
INFO - 2018-03-22 21:50:04 --> Language Class Initialized
INFO - 2018-03-22 21:50:04 --> Loader Class Initialized
INFO - 2018-03-22 21:50:04 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:04 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:04 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:04 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Controller Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
INFO - 2018-03-22 21:50:04 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:14 --> Config Class Initialized
INFO - 2018-03-22 21:50:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:14 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:14 --> URI Class Initialized
INFO - 2018-03-22 21:50:14 --> Router Class Initialized
INFO - 2018-03-22 21:50:14 --> Output Class Initialized
INFO - 2018-03-22 21:50:14 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:14 --> Input Class Initialized
INFO - 2018-03-22 21:50:14 --> Language Class Initialized
INFO - 2018-03-22 21:50:14 --> Loader Class Initialized
INFO - 2018-03-22 21:50:14 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:14 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:14 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
INFO - 2018-03-22 21:50:14 --> Controller Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
INFO - 2018-03-22 21:50:14 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:50:15 --> Final output sent to browser
DEBUG - 2018-03-22 21:50:15 --> Total execution time: 0.5286
INFO - 2018-03-22 21:50:15 --> Config Class Initialized
INFO - 2018-03-22 21:50:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:15 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:15 --> URI Class Initialized
INFO - 2018-03-22 21:50:15 --> Router Class Initialized
INFO - 2018-03-22 21:50:15 --> Output Class Initialized
INFO - 2018-03-22 21:50:15 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:15 --> Input Class Initialized
INFO - 2018-03-22 21:50:15 --> Language Class Initialized
INFO - 2018-03-22 21:50:15 --> Loader Class Initialized
INFO - 2018-03-22 21:50:15 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:15 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:15 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
INFO - 2018-03-22 21:50:15 --> Controller Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
INFO - 2018-03-22 21:50:15 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:19 --> Config Class Initialized
INFO - 2018-03-22 21:50:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:19 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:19 --> URI Class Initialized
INFO - 2018-03-22 21:50:19 --> Router Class Initialized
INFO - 2018-03-22 21:50:19 --> Output Class Initialized
INFO - 2018-03-22 21:50:19 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:19 --> Input Class Initialized
INFO - 2018-03-22 21:50:19 --> Language Class Initialized
INFO - 2018-03-22 21:50:19 --> Loader Class Initialized
INFO - 2018-03-22 21:50:19 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:19 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:20 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:20 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
INFO - 2018-03-22 21:50:20 --> Controller Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
INFO - 2018-03-22 21:50:20 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:34 --> Config Class Initialized
INFO - 2018-03-22 21:50:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:34 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:34 --> URI Class Initialized
INFO - 2018-03-22 21:50:34 --> Router Class Initialized
INFO - 2018-03-22 21:50:34 --> Output Class Initialized
INFO - 2018-03-22 21:50:34 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:34 --> Input Class Initialized
INFO - 2018-03-22 21:50:34 --> Language Class Initialized
INFO - 2018-03-22 21:50:34 --> Loader Class Initialized
INFO - 2018-03-22 21:50:34 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:34 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:34 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:34 --> Model Class Initialized
INFO - 2018-03-22 21:50:34 --> Controller Class Initialized
INFO - 2018-03-22 21:50:34 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:34 --> Config Class Initialized
INFO - 2018-03-22 21:50:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:34 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:34 --> URI Class Initialized
INFO - 2018-03-22 21:50:34 --> Router Class Initialized
INFO - 2018-03-22 21:50:34 --> Output Class Initialized
INFO - 2018-03-22 21:50:34 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:34 --> Input Class Initialized
INFO - 2018-03-22 21:50:34 --> Language Class Initialized
INFO - 2018-03-22 21:50:34 --> Loader Class Initialized
INFO - 2018-03-22 21:50:34 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:34 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:34 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:34 --> Model Class Initialized
INFO - 2018-03-22 21:50:34 --> Controller Class Initialized
INFO - 2018-03-22 21:50:34 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:50:34 --> Final output sent to browser
DEBUG - 2018-03-22 21:50:34 --> Total execution time: 0.0677
INFO - 2018-03-22 21:50:36 --> Config Class Initialized
INFO - 2018-03-22 21:50:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:36 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:36 --> URI Class Initialized
INFO - 2018-03-22 21:50:36 --> Router Class Initialized
INFO - 2018-03-22 21:50:36 --> Output Class Initialized
INFO - 2018-03-22 21:50:36 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:36 --> Input Class Initialized
INFO - 2018-03-22 21:50:36 --> Language Class Initialized
INFO - 2018-03-22 21:50:36 --> Loader Class Initialized
INFO - 2018-03-22 21:50:36 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:36 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:36 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:36 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:36 --> Model Class Initialized
INFO - 2018-03-22 21:50:36 --> Controller Class Initialized
INFO - 2018-03-22 21:50:36 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:50:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 21:50:37 --> Config Class Initialized
INFO - 2018-03-22 21:50:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:37 --> URI Class Initialized
DEBUG - 2018-03-22 21:50:37 --> No URI present. Default controller set.
INFO - 2018-03-22 21:50:37 --> Router Class Initialized
INFO - 2018-03-22 21:50:37 --> Output Class Initialized
INFO - 2018-03-22 21:50:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:37 --> Input Class Initialized
INFO - 2018-03-22 21:50:37 --> Language Class Initialized
INFO - 2018-03-22 21:50:37 --> Loader Class Initialized
INFO - 2018-03-22 21:50:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Controller Class Initialized
INFO - 2018-03-22 21:50:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:50:37 --> Final output sent to browser
DEBUG - 2018-03-22 21:50:37 --> Total execution time: 0.0904
INFO - 2018-03-22 21:50:37 --> Config Class Initialized
INFO - 2018-03-22 21:50:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:50:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:50:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:50:37 --> URI Class Initialized
INFO - 2018-03-22 21:50:37 --> Router Class Initialized
INFO - 2018-03-22 21:50:37 --> Output Class Initialized
INFO - 2018-03-22 21:50:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:50:37 --> Input Class Initialized
INFO - 2018-03-22 21:50:37 --> Language Class Initialized
INFO - 2018-03-22 21:50:37 --> Loader Class Initialized
INFO - 2018-03-22 21:50:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:50:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:50:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:50:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Controller Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
INFO - 2018-03-22 21:50:37 --> Model Class Initialized
DEBUG - 2018-03-22 21:50:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:01 --> Config Class Initialized
INFO - 2018-03-22 21:51:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:01 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:01 --> URI Class Initialized
INFO - 2018-03-22 21:51:01 --> Router Class Initialized
INFO - 2018-03-22 21:51:01 --> Output Class Initialized
INFO - 2018-03-22 21:51:01 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:01 --> Input Class Initialized
INFO - 2018-03-22 21:51:01 --> Language Class Initialized
INFO - 2018-03-22 21:51:01 --> Loader Class Initialized
INFO - 2018-03-22 21:51:01 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:01 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:01 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Controller Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:51:01 --> Final output sent to browser
DEBUG - 2018-03-22 21:51:01 --> Total execution time: 0.1619
INFO - 2018-03-22 21:51:01 --> Config Class Initialized
INFO - 2018-03-22 21:51:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:01 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:01 --> URI Class Initialized
INFO - 2018-03-22 21:51:01 --> Router Class Initialized
INFO - 2018-03-22 21:51:01 --> Output Class Initialized
INFO - 2018-03-22 21:51:01 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:01 --> Input Class Initialized
INFO - 2018-03-22 21:51:01 --> Language Class Initialized
INFO - 2018-03-22 21:51:01 --> Loader Class Initialized
INFO - 2018-03-22 21:51:01 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:01 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:01 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Controller Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
INFO - 2018-03-22 21:51:01 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:32 --> Config Class Initialized
INFO - 2018-03-22 21:51:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:32 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:32 --> URI Class Initialized
INFO - 2018-03-22 21:51:32 --> Router Class Initialized
INFO - 2018-03-22 21:51:32 --> Output Class Initialized
INFO - 2018-03-22 21:51:32 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:32 --> Input Class Initialized
INFO - 2018-03-22 21:51:32 --> Language Class Initialized
INFO - 2018-03-22 21:51:32 --> Loader Class Initialized
INFO - 2018-03-22 21:51:32 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:32 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:32 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:32 --> Model Class Initialized
INFO - 2018-03-22 21:51:32 --> Controller Class Initialized
INFO - 2018-03-22 21:51:32 --> Model Class Initialized
INFO - 2018-03-22 21:51:32 --> Model Class Initialized
INFO - 2018-03-22 21:51:32 --> Model Class Initialized
INFO - 2018-03-22 21:51:32 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:51:32 --> Final output sent to browser
DEBUG - 2018-03-22 21:51:32 --> Total execution time: 0.3960
INFO - 2018-03-22 21:51:33 --> Config Class Initialized
INFO - 2018-03-22 21:51:33 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:33 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:33 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:33 --> URI Class Initialized
INFO - 2018-03-22 21:51:33 --> Router Class Initialized
INFO - 2018-03-22 21:51:33 --> Output Class Initialized
INFO - 2018-03-22 21:51:33 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:33 --> Input Class Initialized
INFO - 2018-03-22 21:51:33 --> Language Class Initialized
INFO - 2018-03-22 21:51:33 --> Loader Class Initialized
INFO - 2018-03-22 21:51:33 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:33 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:33 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:33 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
INFO - 2018-03-22 21:51:33 --> Controller Class Initialized
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:33 --> Model Class Initialized
INFO - 2018-03-22 21:51:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:51:33 --> Final output sent to browser
DEBUG - 2018-03-22 21:51:33 --> Total execution time: 0.1572
INFO - 2018-03-22 21:51:34 --> Config Class Initialized
INFO - 2018-03-22 21:51:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:34 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:34 --> URI Class Initialized
INFO - 2018-03-22 21:51:34 --> Router Class Initialized
INFO - 2018-03-22 21:51:34 --> Output Class Initialized
INFO - 2018-03-22 21:51:34 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:34 --> Input Class Initialized
INFO - 2018-03-22 21:51:34 --> Language Class Initialized
INFO - 2018-03-22 21:51:34 --> Loader Class Initialized
INFO - 2018-03-22 21:51:34 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:34 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:34 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:34 --> Model Class Initialized
INFO - 2018-03-22 21:51:34 --> Controller Class Initialized
INFO - 2018-03-22 21:51:34 --> Model Class Initialized
INFO - 2018-03-22 21:51:34 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:37 --> Config Class Initialized
INFO - 2018-03-22 21:51:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:37 --> URI Class Initialized
INFO - 2018-03-22 21:51:37 --> Router Class Initialized
INFO - 2018-03-22 21:51:37 --> Output Class Initialized
INFO - 2018-03-22 21:51:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:37 --> Input Class Initialized
INFO - 2018-03-22 21:51:37 --> Language Class Initialized
INFO - 2018-03-22 21:51:37 --> Loader Class Initialized
INFO - 2018-03-22 21:51:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Controller Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:51:37 --> Final output sent to browser
DEBUG - 2018-03-22 21:51:37 --> Total execution time: 0.1477
INFO - 2018-03-22 21:51:37 --> Config Class Initialized
INFO - 2018-03-22 21:51:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:51:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:51:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:51:37 --> URI Class Initialized
INFO - 2018-03-22 21:51:37 --> Router Class Initialized
INFO - 2018-03-22 21:51:37 --> Output Class Initialized
INFO - 2018-03-22 21:51:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:51:37 --> Input Class Initialized
INFO - 2018-03-22 21:51:37 --> Language Class Initialized
INFO - 2018-03-22 21:51:37 --> Loader Class Initialized
INFO - 2018-03-22 21:51:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:51:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:51:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:51:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Controller Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
INFO - 2018-03-22 21:51:37 --> Model Class Initialized
DEBUG - 2018-03-22 21:51:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:37 --> Config Class Initialized
INFO - 2018-03-22 21:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:37 --> URI Class Initialized
INFO - 2018-03-22 21:55:37 --> Router Class Initialized
INFO - 2018-03-22 21:55:37 --> Output Class Initialized
INFO - 2018-03-22 21:55:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:37 --> Input Class Initialized
INFO - 2018-03-22 21:55:37 --> Language Class Initialized
INFO - 2018-03-22 21:55:37 --> Loader Class Initialized
INFO - 2018-03-22 21:55:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Controller Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:55:37 --> Final output sent to browser
DEBUG - 2018-03-22 21:55:37 --> Total execution time: 0.1921
INFO - 2018-03-22 21:55:37 --> Config Class Initialized
INFO - 2018-03-22 21:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:37 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:37 --> URI Class Initialized
INFO - 2018-03-22 21:55:37 --> Router Class Initialized
INFO - 2018-03-22 21:55:37 --> Output Class Initialized
INFO - 2018-03-22 21:55:37 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:37 --> Input Class Initialized
INFO - 2018-03-22 21:55:37 --> Language Class Initialized
INFO - 2018-03-22 21:55:37 --> Loader Class Initialized
INFO - 2018-03-22 21:55:37 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:37 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:37 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Controller Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
INFO - 2018-03-22 21:55:37 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:39 --> Config Class Initialized
INFO - 2018-03-22 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:39 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:39 --> URI Class Initialized
INFO - 2018-03-22 21:55:39 --> Router Class Initialized
INFO - 2018-03-22 21:55:39 --> Output Class Initialized
INFO - 2018-03-22 21:55:39 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:39 --> Input Class Initialized
INFO - 2018-03-22 21:55:39 --> Language Class Initialized
INFO - 2018-03-22 21:55:39 --> Loader Class Initialized
INFO - 2018-03-22 21:55:39 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:39 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:39 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:39 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Controller Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:55:39 --> Final output sent to browser
DEBUG - 2018-03-22 21:55:39 --> Total execution time: 0.2088
INFO - 2018-03-22 21:55:39 --> Config Class Initialized
INFO - 2018-03-22 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:39 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:39 --> URI Class Initialized
INFO - 2018-03-22 21:55:39 --> Router Class Initialized
INFO - 2018-03-22 21:55:39 --> Output Class Initialized
INFO - 2018-03-22 21:55:39 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:39 --> Input Class Initialized
INFO - 2018-03-22 21:55:39 --> Language Class Initialized
INFO - 2018-03-22 21:55:39 --> Loader Class Initialized
INFO - 2018-03-22 21:55:39 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:39 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:39 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:39 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Controller Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
INFO - 2018-03-22 21:55:39 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:53 --> Config Class Initialized
INFO - 2018-03-22 21:55:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:53 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:53 --> URI Class Initialized
INFO - 2018-03-22 21:55:53 --> Router Class Initialized
INFO - 2018-03-22 21:55:53 --> Output Class Initialized
INFO - 2018-03-22 21:55:53 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:53 --> Input Class Initialized
INFO - 2018-03-22 21:55:53 --> Language Class Initialized
INFO - 2018-03-22 21:55:53 --> Loader Class Initialized
INFO - 2018-03-22 21:55:53 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:53 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:53 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Controller Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:55:53 --> Final output sent to browser
DEBUG - 2018-03-22 21:55:53 --> Total execution time: 0.2117
INFO - 2018-03-22 21:55:53 --> Config Class Initialized
INFO - 2018-03-22 21:55:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:53 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:53 --> URI Class Initialized
INFO - 2018-03-22 21:55:53 --> Router Class Initialized
INFO - 2018-03-22 21:55:53 --> Output Class Initialized
INFO - 2018-03-22 21:55:53 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:53 --> Input Class Initialized
INFO - 2018-03-22 21:55:53 --> Language Class Initialized
INFO - 2018-03-22 21:55:53 --> Loader Class Initialized
INFO - 2018-03-22 21:55:53 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:53 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:53 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Controller Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
INFO - 2018-03-22 21:55:53 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:53 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:54 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
INFO - 2018-03-22 21:55:55 --> Config Class Initialized
INFO - 2018-03-22 21:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:55 --> URI Class Initialized
INFO - 2018-03-22 21:55:55 --> Router Class Initialized
INFO - 2018-03-22 21:55:55 --> Output Class Initialized
INFO - 2018-03-22 21:55:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:55 --> Input Class Initialized
INFO - 2018-03-22 21:55:55 --> Language Class Initialized
INFO - 2018-03-22 21:55:55 --> Loader Class Initialized
INFO - 2018-03-22 21:55:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Controller Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:55:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:55:55 --> Final output sent to browser
DEBUG - 2018-03-22 21:55:55 --> Total execution time: 0.2007
INFO - 2018-03-22 21:55:55 --> Config Class Initialized
INFO - 2018-03-22 21:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:55:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:55:55 --> URI Class Initialized
INFO - 2018-03-22 21:55:55 --> Router Class Initialized
INFO - 2018-03-22 21:55:55 --> Output Class Initialized
INFO - 2018-03-22 21:55:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:55:55 --> Input Class Initialized
INFO - 2018-03-22 21:55:55 --> Language Class Initialized
INFO - 2018-03-22 21:55:55 --> Loader Class Initialized
INFO - 2018-03-22 21:55:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:55:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:55:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:55:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Controller Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
INFO - 2018-03-22 21:55:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:55:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:55:55 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
INFO - 2018-03-22 21:56:09 --> Config Class Initialized
INFO - 2018-03-22 21:56:09 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:09 --> Config Class Initialized
INFO - 2018-03-22 21:56:09 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:56:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 21:56:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:09 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:09 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:09 --> Config Class Initialized
INFO - 2018-03-22 21:56:09 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:09 --> URI Class Initialized
INFO - 2018-03-22 21:56:09 --> URI Class Initialized
INFO - 2018-03-22 21:56:09 --> Router Class Initialized
DEBUG - 2018-03-22 21:56:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:09 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:09 --> Router Class Initialized
INFO - 2018-03-22 21:56:09 --> URI Class Initialized
INFO - 2018-03-22 21:56:09 --> Output Class Initialized
INFO - 2018-03-22 21:56:09 --> Output Class Initialized
INFO - 2018-03-22 21:56:09 --> Security Class Initialized
INFO - 2018-03-22 21:56:09 --> Router Class Initialized
INFO - 2018-03-22 21:56:09 --> Security Class Initialized
DEBUG - 2018-03-22 21:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:09 --> Input Class Initialized
DEBUG - 2018-03-22 21:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:09 --> Language Class Initialized
INFO - 2018-03-22 21:56:09 --> Input Class Initialized
INFO - 2018-03-22 21:56:09 --> Output Class Initialized
INFO - 2018-03-22 21:56:09 --> Language Class Initialized
ERROR - 2018-03-22 21:56:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:56:09 --> Security Class Initialized
ERROR - 2018-03-22 21:56:09 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:09 --> Input Class Initialized
INFO - 2018-03-22 21:56:09 --> Language Class Initialized
ERROR - 2018-03-22 21:56:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:56:43 --> Config Class Initialized
INFO - 2018-03-22 21:56:43 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:56:43 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:43 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:43 --> URI Class Initialized
INFO - 2018-03-22 21:56:43 --> Router Class Initialized
INFO - 2018-03-22 21:56:43 --> Output Class Initialized
INFO - 2018-03-22 21:56:43 --> Security Class Initialized
DEBUG - 2018-03-22 21:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:43 --> Input Class Initialized
INFO - 2018-03-22 21:56:43 --> Language Class Initialized
INFO - 2018-03-22 21:56:43 --> Loader Class Initialized
INFO - 2018-03-22 21:56:43 --> Helper loaded: url_helper
INFO - 2018-03-22 21:56:43 --> Helper loaded: form_helper
INFO - 2018-03-22 21:56:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:56:43 --> Form Validation Class Initialized
INFO - 2018-03-22 21:56:43 --> Model Class Initialized
INFO - 2018-03-22 21:56:43 --> Controller Class Initialized
INFO - 2018-03-22 21:56:43 --> Model Class Initialized
INFO - 2018-03-22 21:56:43 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:56:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:56:44 --> Final output sent to browser
DEBUG - 2018-03-22 21:56:44 --> Total execution time: 0.1939
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
ERROR - 2018-03-22 21:56:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:56:44 --> Config Class Initialized
INFO - 2018-03-22 21:56:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:56:44 --> Utf8 Class Initialized
INFO - 2018-03-22 21:56:44 --> URI Class Initialized
INFO - 2018-03-22 21:56:44 --> Router Class Initialized
INFO - 2018-03-22 21:56:44 --> Output Class Initialized
INFO - 2018-03-22 21:56:44 --> Security Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:56:44 --> Input Class Initialized
INFO - 2018-03-22 21:56:44 --> Language Class Initialized
INFO - 2018-03-22 21:56:44 --> Loader Class Initialized
INFO - 2018-03-22 21:56:44 --> Helper loaded: url_helper
INFO - 2018-03-22 21:56:44 --> Helper loaded: form_helper
INFO - 2018-03-22 21:56:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:56:44 --> Form Validation Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Controller Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
INFO - 2018-03-22 21:56:44 --> Model Class Initialized
DEBUG - 2018-03-22 21:56:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
INFO - 2018-03-22 21:57:58 --> Loader Class Initialized
INFO - 2018-03-22 21:57:58 --> Helper loaded: url_helper
INFO - 2018-03-22 21:57:58 --> Helper loaded: form_helper
INFO - 2018-03-22 21:57:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:57:58 --> Form Validation Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Controller Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:57:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:57:58 --> Final output sent to browser
DEBUG - 2018-03-22 21:57:58 --> Total execution time: 0.2122
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
ERROR - 2018-03-22 21:57:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:57:58 --> Config Class Initialized
INFO - 2018-03-22 21:57:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:57:58 --> Utf8 Class Initialized
INFO - 2018-03-22 21:57:58 --> URI Class Initialized
INFO - 2018-03-22 21:57:58 --> Router Class Initialized
INFO - 2018-03-22 21:57:58 --> Output Class Initialized
INFO - 2018-03-22 21:57:58 --> Security Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:57:58 --> Input Class Initialized
INFO - 2018-03-22 21:57:58 --> Language Class Initialized
INFO - 2018-03-22 21:57:58 --> Loader Class Initialized
INFO - 2018-03-22 21:57:58 --> Helper loaded: url_helper
INFO - 2018-03-22 21:57:58 --> Helper loaded: form_helper
INFO - 2018-03-22 21:57:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:57:58 --> Form Validation Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Controller Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
INFO - 2018-03-22 21:57:58 --> Model Class Initialized
DEBUG - 2018-03-22 21:57:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:57:59 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
INFO - 2018-03-22 21:58:55 --> Config Class Initialized
INFO - 2018-03-22 21:58:55 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:58:55 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:55 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:55 --> URI Class Initialized
INFO - 2018-03-22 21:58:55 --> Router Class Initialized
INFO - 2018-03-22 21:58:55 --> Output Class Initialized
INFO - 2018-03-22 21:58:55 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:55 --> Input Class Initialized
INFO - 2018-03-22 21:58:55 --> Language Class Initialized
INFO - 2018-03-22 21:58:55 --> Loader Class Initialized
INFO - 2018-03-22 21:58:55 --> Helper loaded: url_helper
INFO - 2018-03-22 21:58:55 --> Helper loaded: form_helper
INFO - 2018-03-22 21:58:55 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:58:55 --> Form Validation Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
INFO - 2018-03-22 21:58:55 --> Controller Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
INFO - 2018-03-22 21:58:55 --> Model Class Initialized
DEBUG - 2018-03-22 21:58:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 21:58:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 21:58:56 --> Final output sent to browser
DEBUG - 2018-03-22 21:58:56 --> Total execution time: 0.1932
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
ERROR - 2018-03-22 21:58:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 21:58:56 --> Config Class Initialized
INFO - 2018-03-22 21:58:56 --> Hooks Class Initialized
DEBUG - 2018-03-22 21:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-22 21:58:56 --> Utf8 Class Initialized
INFO - 2018-03-22 21:58:56 --> URI Class Initialized
INFO - 2018-03-22 21:58:56 --> Router Class Initialized
INFO - 2018-03-22 21:58:56 --> Output Class Initialized
INFO - 2018-03-22 21:58:56 --> Security Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 21:58:56 --> Input Class Initialized
INFO - 2018-03-22 21:58:56 --> Language Class Initialized
INFO - 2018-03-22 21:58:56 --> Loader Class Initialized
INFO - 2018-03-22 21:58:56 --> Helper loaded: url_helper
INFO - 2018-03-22 21:58:56 --> Helper loaded: form_helper
INFO - 2018-03-22 21:58:56 --> Database Driver Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 21:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 21:58:56 --> Form Validation Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
INFO - 2018-03-22 21:58:56 --> Controller Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
INFO - 2018-03-22 21:58:56 --> Model Class Initialized
DEBUG - 2018-03-22 21:58:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 640
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 641
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 645
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 646
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 649
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 650
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 653
ERROR - 2018-03-22 21:58:56 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 654
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
INFO - 2018-03-22 22:00:10 --> Loader Class Initialized
INFO - 2018-03-22 22:00:10 --> Helper loaded: url_helper
INFO - 2018-03-22 22:00:10 --> Helper loaded: form_helper
INFO - 2018-03-22 22:00:10 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:00:10 --> Form Validation Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
INFO - 2018-03-22 22:00:10 --> Controller Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
INFO - 2018-03-22 22:00:10 --> Model Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:00:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:00:10 --> Final output sent to browser
DEBUG - 2018-03-22 22:00:10 --> Total execution time: 0.3656
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
INFO - 2018-03-22 22:00:10 --> Config Class Initialized
INFO - 2018-03-22 22:00:10 --> Hooks Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
DEBUG - 2018-03-22 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:10 --> URI Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Router Class Initialized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
INFO - 2018-03-22 22:00:10 --> Output Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Security Class Initialized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
DEBUG - 2018-03-22 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:10 --> Input Class Initialized
INFO - 2018-03-22 22:00:10 --> Language Class Initialized
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 22:00:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:00:11 --> Config Class Initialized
INFO - 2018-03-22 22:00:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:00:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:00:11 --> Utf8 Class Initialized
INFO - 2018-03-22 22:00:11 --> URI Class Initialized
INFO - 2018-03-22 22:00:11 --> Router Class Initialized
INFO - 2018-03-22 22:00:11 --> Output Class Initialized
INFO - 2018-03-22 22:00:11 --> Security Class Initialized
DEBUG - 2018-03-22 22:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:00:11 --> Input Class Initialized
INFO - 2018-03-22 22:00:11 --> Language Class Initialized
INFO - 2018-03-22 22:00:11 --> Loader Class Initialized
INFO - 2018-03-22 22:00:11 --> Helper loaded: url_helper
INFO - 2018-03-22 22:00:11 --> Helper loaded: form_helper
INFO - 2018-03-22 22:00:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:00:11 --> Form Validation Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
INFO - 2018-03-22 22:00:11 --> Controller Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
INFO - 2018-03-22 22:00:11 --> Model Class Initialized
DEBUG - 2018-03-22 22:00:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
INFO - 2018-03-22 22:01:31 --> Loader Class Initialized
INFO - 2018-03-22 22:01:31 --> Helper loaded: url_helper
INFO - 2018-03-22 22:01:31 --> Helper loaded: form_helper
INFO - 2018-03-22 22:01:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:01:31 --> Form Validation Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Controller Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:01:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:01:31 --> Final output sent to browser
DEBUG - 2018-03-22 22:01:31 --> Total execution time: 0.2346
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
ERROR - 2018-03-22 22:01:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:01:31 --> Config Class Initialized
INFO - 2018-03-22 22:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:31 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:31 --> URI Class Initialized
INFO - 2018-03-22 22:01:31 --> Router Class Initialized
INFO - 2018-03-22 22:01:31 --> Output Class Initialized
INFO - 2018-03-22 22:01:31 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:31 --> Input Class Initialized
INFO - 2018-03-22 22:01:31 --> Language Class Initialized
INFO - 2018-03-22 22:01:31 --> Loader Class Initialized
INFO - 2018-03-22 22:01:31 --> Helper loaded: url_helper
INFO - 2018-03-22 22:01:31 --> Helper loaded: form_helper
INFO - 2018-03-22 22:01:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:01:31 --> Form Validation Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Controller Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
INFO - 2018-03-22 22:01:31 --> Model Class Initialized
DEBUG - 2018-03-22 22:01:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
INFO - 2018-03-22 22:01:42 --> Loader Class Initialized
INFO - 2018-03-22 22:01:42 --> Helper loaded: url_helper
INFO - 2018-03-22 22:01:42 --> Helper loaded: form_helper
INFO - 2018-03-22 22:01:42 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:01:42 --> Form Validation Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
INFO - 2018-03-22 22:01:42 --> Controller Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
INFO - 2018-03-22 22:01:42 --> Model Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:01:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:01:42 --> Final output sent to browser
DEBUG - 2018-03-22 22:01:42 --> Total execution time: 0.1950
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:01:42 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:42 --> Input Class Initialized
INFO - 2018-03-22 22:01:42 --> Language Class Initialized
ERROR - 2018-03-22 22:01:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 22:01:42 --> Config Class Initialized
INFO - 2018-03-22 22:01:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:01:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:01:42 --> URI Class Initialized
INFO - 2018-03-22 22:01:42 --> Router Class Initialized
INFO - 2018-03-22 22:01:42 --> Output Class Initialized
INFO - 2018-03-22 22:01:43 --> Security Class Initialized
DEBUG - 2018-03-22 22:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:01:43 --> Input Class Initialized
INFO - 2018-03-22 22:01:43 --> Language Class Initialized
INFO - 2018-03-22 22:01:43 --> Loader Class Initialized
INFO - 2018-03-22 22:01:43 --> Helper loaded: url_helper
INFO - 2018-03-22 22:01:43 --> Helper loaded: form_helper
INFO - 2018-03-22 22:01:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:01:43 --> Form Validation Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
INFO - 2018-03-22 22:01:43 --> Controller Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
INFO - 2018-03-22 22:01:43 --> Model Class Initialized
DEBUG - 2018-03-22 22:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:03:19 --> Config Class Initialized
INFO - 2018-03-22 22:03:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:03:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:03:19 --> Utf8 Class Initialized
INFO - 2018-03-22 22:03:19 --> URI Class Initialized
INFO - 2018-03-22 22:03:19 --> Router Class Initialized
INFO - 2018-03-22 22:03:19 --> Output Class Initialized
INFO - 2018-03-22 22:03:19 --> Security Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:03:19 --> Input Class Initialized
INFO - 2018-03-22 22:03:19 --> Language Class Initialized
INFO - 2018-03-22 22:03:19 --> Loader Class Initialized
INFO - 2018-03-22 22:03:19 --> Helper loaded: url_helper
INFO - 2018-03-22 22:03:19 --> Helper loaded: form_helper
INFO - 2018-03-22 22:03:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:03:19 --> Form Validation Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Controller Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:03:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:03:19 --> Final output sent to browser
DEBUG - 2018-03-22 22:03:19 --> Total execution time: 0.2397
INFO - 2018-03-22 22:03:19 --> Config Class Initialized
INFO - 2018-03-22 22:03:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:03:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:03:19 --> Utf8 Class Initialized
INFO - 2018-03-22 22:03:19 --> URI Class Initialized
INFO - 2018-03-22 22:03:19 --> Router Class Initialized
INFO - 2018-03-22 22:03:19 --> Output Class Initialized
INFO - 2018-03-22 22:03:19 --> Security Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:03:19 --> Input Class Initialized
INFO - 2018-03-22 22:03:19 --> Language Class Initialized
INFO - 2018-03-22 22:03:19 --> Loader Class Initialized
INFO - 2018-03-22 22:03:19 --> Helper loaded: url_helper
INFO - 2018-03-22 22:03:19 --> Helper loaded: form_helper
INFO - 2018-03-22 22:03:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:03:19 --> Form Validation Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Controller Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
INFO - 2018-03-22 22:03:19 --> Model Class Initialized
DEBUG - 2018-03-22 22:03:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:03:58 --> Config Class Initialized
INFO - 2018-03-22 22:03:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:03:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:03:58 --> Utf8 Class Initialized
INFO - 2018-03-22 22:03:58 --> URI Class Initialized
INFO - 2018-03-22 22:03:58 --> Router Class Initialized
INFO - 2018-03-22 22:03:58 --> Output Class Initialized
INFO - 2018-03-22 22:03:58 --> Security Class Initialized
DEBUG - 2018-03-22 22:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:03:58 --> Input Class Initialized
INFO - 2018-03-22 22:03:58 --> Language Class Initialized
INFO - 2018-03-22 22:03:58 --> Loader Class Initialized
INFO - 2018-03-22 22:03:58 --> Helper loaded: url_helper
INFO - 2018-03-22 22:03:58 --> Helper loaded: form_helper
INFO - 2018-03-22 22:03:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:03:58 --> Form Validation Class Initialized
INFO - 2018-03-22 22:03:58 --> Model Class Initialized
INFO - 2018-03-22 22:03:58 --> Controller Class Initialized
INFO - 2018-03-22 22:03:58 --> Model Class Initialized
INFO - 2018-03-22 22:03:58 --> Model Class Initialized
INFO - 2018-03-22 22:03:58 --> Model Class Initialized
INFO - 2018-03-22 22:03:58 --> Model Class Initialized
DEBUG - 2018-03-22 22:03:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:03:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:03:58 --> Final output sent to browser
DEBUG - 2018-03-22 22:03:58 --> Total execution time: 0.1519
INFO - 2018-03-22 22:03:59 --> Config Class Initialized
INFO - 2018-03-22 22:03:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:03:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:03:59 --> Utf8 Class Initialized
INFO - 2018-03-22 22:03:59 --> URI Class Initialized
INFO - 2018-03-22 22:03:59 --> Router Class Initialized
INFO - 2018-03-22 22:03:59 --> Output Class Initialized
INFO - 2018-03-22 22:03:59 --> Security Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:03:59 --> Input Class Initialized
INFO - 2018-03-22 22:03:59 --> Language Class Initialized
INFO - 2018-03-22 22:03:59 --> Loader Class Initialized
INFO - 2018-03-22 22:03:59 --> Helper loaded: url_helper
INFO - 2018-03-22 22:03:59 --> Helper loaded: form_helper
INFO - 2018-03-22 22:03:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:03:59 --> Form Validation Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Controller Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:03:59 --> Final output sent to browser
DEBUG - 2018-03-22 22:03:59 --> Total execution time: 0.1525
INFO - 2018-03-22 22:03:59 --> Config Class Initialized
INFO - 2018-03-22 22:03:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:03:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:03:59 --> Utf8 Class Initialized
INFO - 2018-03-22 22:03:59 --> URI Class Initialized
INFO - 2018-03-22 22:03:59 --> Router Class Initialized
INFO - 2018-03-22 22:03:59 --> Output Class Initialized
INFO - 2018-03-22 22:03:59 --> Security Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:03:59 --> Input Class Initialized
INFO - 2018-03-22 22:03:59 --> Language Class Initialized
INFO - 2018-03-22 22:03:59 --> Loader Class Initialized
INFO - 2018-03-22 22:03:59 --> Helper loaded: url_helper
INFO - 2018-03-22 22:03:59 --> Helper loaded: form_helper
INFO - 2018-03-22 22:03:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:03:59 --> Form Validation Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Controller Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
INFO - 2018-03-22 22:03:59 --> Model Class Initialized
DEBUG - 2018-03-22 22:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:02 --> Config Class Initialized
INFO - 2018-03-22 22:04:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:02 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:02 --> URI Class Initialized
INFO - 2018-03-22 22:04:02 --> Router Class Initialized
INFO - 2018-03-22 22:04:02 --> Output Class Initialized
INFO - 2018-03-22 22:04:02 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:02 --> Input Class Initialized
INFO - 2018-03-22 22:04:02 --> Language Class Initialized
INFO - 2018-03-22 22:04:02 --> Loader Class Initialized
INFO - 2018-03-22 22:04:02 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:02 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:02 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Controller Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:04:02 --> Final output sent to browser
DEBUG - 2018-03-22 22:04:02 --> Total execution time: 0.1911
INFO - 2018-03-22 22:04:02 --> Config Class Initialized
INFO - 2018-03-22 22:04:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:02 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:02 --> URI Class Initialized
INFO - 2018-03-22 22:04:02 --> Router Class Initialized
INFO - 2018-03-22 22:04:02 --> Output Class Initialized
INFO - 2018-03-22 22:04:02 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:02 --> Input Class Initialized
INFO - 2018-03-22 22:04:02 --> Language Class Initialized
INFO - 2018-03-22 22:04:02 --> Loader Class Initialized
INFO - 2018-03-22 22:04:02 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:02 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:02 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Controller Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
INFO - 2018-03-22 22:04:02 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:05 --> Config Class Initialized
INFO - 2018-03-22 22:04:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:05 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:05 --> URI Class Initialized
INFO - 2018-03-22 22:04:05 --> Router Class Initialized
INFO - 2018-03-22 22:04:05 --> Output Class Initialized
INFO - 2018-03-22 22:04:05 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:05 --> Input Class Initialized
INFO - 2018-03-22 22:04:05 --> Language Class Initialized
INFO - 2018-03-22 22:04:05 --> Loader Class Initialized
INFO - 2018-03-22 22:04:05 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:05 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:05 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:05 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Controller Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:04:05 --> Final output sent to browser
DEBUG - 2018-03-22 22:04:05 --> Total execution time: 0.1239
INFO - 2018-03-22 22:04:05 --> Config Class Initialized
INFO - 2018-03-22 22:04:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:05 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:05 --> URI Class Initialized
INFO - 2018-03-22 22:04:05 --> Router Class Initialized
INFO - 2018-03-22 22:04:05 --> Output Class Initialized
INFO - 2018-03-22 22:04:05 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:05 --> Input Class Initialized
INFO - 2018-03-22 22:04:05 --> Language Class Initialized
INFO - 2018-03-22 22:04:05 --> Loader Class Initialized
INFO - 2018-03-22 22:04:05 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:05 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:05 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:05 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Controller Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
INFO - 2018-03-22 22:04:05 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:06 --> Config Class Initialized
INFO - 2018-03-22 22:04:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:06 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:06 --> URI Class Initialized
INFO - 2018-03-22 22:04:06 --> Router Class Initialized
INFO - 2018-03-22 22:04:06 --> Output Class Initialized
INFO - 2018-03-22 22:04:06 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:06 --> Input Class Initialized
INFO - 2018-03-22 22:04:06 --> Language Class Initialized
INFO - 2018-03-22 22:04:06 --> Loader Class Initialized
INFO - 2018-03-22 22:04:06 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:06 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:06 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Controller Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:04:06 --> Final output sent to browser
DEBUG - 2018-03-22 22:04:06 --> Total execution time: 0.1885
INFO - 2018-03-22 22:04:06 --> Config Class Initialized
INFO - 2018-03-22 22:04:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:06 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:06 --> URI Class Initialized
INFO - 2018-03-22 22:04:06 --> Router Class Initialized
INFO - 2018-03-22 22:04:06 --> Output Class Initialized
INFO - 2018-03-22 22:04:06 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:06 --> Input Class Initialized
INFO - 2018-03-22 22:04:06 --> Language Class Initialized
INFO - 2018-03-22 22:04:06 --> Loader Class Initialized
INFO - 2018-03-22 22:04:06 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:06 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:06 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Controller Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
INFO - 2018-03-22 22:04:06 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:09 --> Config Class Initialized
INFO - 2018-03-22 22:04:09 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:09 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:09 --> URI Class Initialized
INFO - 2018-03-22 22:04:09 --> Router Class Initialized
INFO - 2018-03-22 22:04:09 --> Output Class Initialized
INFO - 2018-03-22 22:04:09 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:09 --> Input Class Initialized
INFO - 2018-03-22 22:04:09 --> Language Class Initialized
INFO - 2018-03-22 22:04:09 --> Loader Class Initialized
INFO - 2018-03-22 22:04:09 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:09 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:09 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:09 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Controller Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:04:09 --> Final output sent to browser
DEBUG - 2018-03-22 22:04:09 --> Total execution time: 0.1356
INFO - 2018-03-22 22:04:09 --> Config Class Initialized
INFO - 2018-03-22 22:04:09 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:09 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:09 --> URI Class Initialized
INFO - 2018-03-22 22:04:09 --> Router Class Initialized
INFO - 2018-03-22 22:04:09 --> Output Class Initialized
INFO - 2018-03-22 22:04:09 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:09 --> Input Class Initialized
INFO - 2018-03-22 22:04:09 --> Language Class Initialized
INFO - 2018-03-22 22:04:09 --> Loader Class Initialized
INFO - 2018-03-22 22:04:09 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:09 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:09 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:09 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Controller Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
INFO - 2018-03-22 22:04:09 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:13 --> Config Class Initialized
INFO - 2018-03-22 22:04:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:13 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:13 --> URI Class Initialized
INFO - 2018-03-22 22:04:13 --> Router Class Initialized
INFO - 2018-03-22 22:04:13 --> Output Class Initialized
INFO - 2018-03-22 22:04:13 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:13 --> Input Class Initialized
INFO - 2018-03-22 22:04:13 --> Language Class Initialized
INFO - 2018-03-22 22:04:13 --> Loader Class Initialized
INFO - 2018-03-22 22:04:13 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:13 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:13 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Controller Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:04:13 --> Final output sent to browser
DEBUG - 2018-03-22 22:04:13 --> Total execution time: 0.2826
INFO - 2018-03-22 22:04:13 --> Config Class Initialized
INFO - 2018-03-22 22:04:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:04:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:04:13 --> Utf8 Class Initialized
INFO - 2018-03-22 22:04:13 --> URI Class Initialized
INFO - 2018-03-22 22:04:13 --> Router Class Initialized
INFO - 2018-03-22 22:04:13 --> Output Class Initialized
INFO - 2018-03-22 22:04:13 --> Security Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:04:13 --> Input Class Initialized
INFO - 2018-03-22 22:04:13 --> Language Class Initialized
INFO - 2018-03-22 22:04:13 --> Loader Class Initialized
INFO - 2018-03-22 22:04:13 --> Helper loaded: url_helper
INFO - 2018-03-22 22:04:13 --> Helper loaded: form_helper
INFO - 2018-03-22 22:04:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:04:13 --> Form Validation Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Controller Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
INFO - 2018-03-22 22:04:13 --> Model Class Initialized
DEBUG - 2018-03-22 22:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:09:42 --> Config Class Initialized
INFO - 2018-03-22 22:09:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:09:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:09:42 --> Utf8 Class Initialized
INFO - 2018-03-22 22:09:42 --> URI Class Initialized
INFO - 2018-03-22 22:09:42 --> Router Class Initialized
INFO - 2018-03-22 22:09:42 --> Output Class Initialized
INFO - 2018-03-22 22:09:42 --> Security Class Initialized
DEBUG - 2018-03-22 22:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:09:42 --> Input Class Initialized
INFO - 2018-03-22 22:09:42 --> Language Class Initialized
INFO - 2018-03-22 22:09:42 --> Loader Class Initialized
INFO - 2018-03-22 22:09:42 --> Helper loaded: url_helper
INFO - 2018-03-22 22:09:42 --> Helper loaded: form_helper
INFO - 2018-03-22 22:09:42 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:09:42 --> Form Validation Class Initialized
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
INFO - 2018-03-22 22:09:42 --> Controller Class Initialized
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
DEBUG - 2018-03-22 22:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:09:42 --> Model Class Initialized
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:09:42 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:09:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 351
ERROR - 2018-03-22 22:09:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 354
INFO - 2018-03-22 22:09:43 --> Final output sent to browser
DEBUG - 2018-03-22 22:09:43 --> Total execution time: 1.1235
INFO - 2018-03-22 22:11:01 --> Config Class Initialized
INFO - 2018-03-22 22:11:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:11:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:11:01 --> Utf8 Class Initialized
INFO - 2018-03-22 22:11:01 --> URI Class Initialized
INFO - 2018-03-22 22:11:01 --> Router Class Initialized
INFO - 2018-03-22 22:11:01 --> Output Class Initialized
INFO - 2018-03-22 22:11:01 --> Security Class Initialized
DEBUG - 2018-03-22 22:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:11:01 --> Input Class Initialized
INFO - 2018-03-22 22:11:01 --> Language Class Initialized
INFO - 2018-03-22 22:11:01 --> Loader Class Initialized
INFO - 2018-03-22 22:11:01 --> Helper loaded: url_helper
INFO - 2018-03-22 22:11:01 --> Helper loaded: form_helper
INFO - 2018-03-22 22:11:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:11:01 --> Form Validation Class Initialized
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
INFO - 2018-03-22 22:11:01 --> Controller Class Initialized
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
DEBUG - 2018-03-22 22:11:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:11:01 --> Model Class Initialized
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 305
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 313
ERROR - 2018-03-22 22:11:01 --> Severity: Notice --> Undefined property: stdClass::$cantidad_horas_extras D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 320
ERROR - 2018-03-22 22:11:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 351
ERROR - 2018-03-22 22:11:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 354
INFO - 2018-03-22 22:11:01 --> Final output sent to browser
DEBUG - 2018-03-22 22:11:01 --> Total execution time: 0.4726
INFO - 2018-03-22 22:11:44 --> Config Class Initialized
INFO - 2018-03-22 22:11:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:11:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:11:44 --> Utf8 Class Initialized
INFO - 2018-03-22 22:11:44 --> URI Class Initialized
INFO - 2018-03-22 22:11:44 --> Router Class Initialized
INFO - 2018-03-22 22:11:44 --> Output Class Initialized
INFO - 2018-03-22 22:11:44 --> Security Class Initialized
DEBUG - 2018-03-22 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:11:44 --> Input Class Initialized
INFO - 2018-03-22 22:11:44 --> Language Class Initialized
INFO - 2018-03-22 22:11:44 --> Loader Class Initialized
INFO - 2018-03-22 22:11:44 --> Helper loaded: url_helper
INFO - 2018-03-22 22:11:44 --> Helper loaded: form_helper
INFO - 2018-03-22 22:11:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:11:44 --> Form Validation Class Initialized
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
INFO - 2018-03-22 22:11:44 --> Controller Class Initialized
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
DEBUG - 2018-03-22 22:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:11:44 --> Model Class Initialized
INFO - 2018-03-22 22:12:13 --> Config Class Initialized
INFO - 2018-03-22 22:12:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:12:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:12:13 --> Utf8 Class Initialized
INFO - 2018-03-22 22:12:13 --> URI Class Initialized
INFO - 2018-03-22 22:12:13 --> Router Class Initialized
INFO - 2018-03-22 22:12:13 --> Output Class Initialized
INFO - 2018-03-22 22:12:13 --> Security Class Initialized
DEBUG - 2018-03-22 22:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:12:13 --> Input Class Initialized
INFO - 2018-03-22 22:12:13 --> Language Class Initialized
INFO - 2018-03-22 22:12:13 --> Loader Class Initialized
INFO - 2018-03-22 22:12:13 --> Helper loaded: url_helper
INFO - 2018-03-22 22:12:13 --> Helper loaded: form_helper
INFO - 2018-03-22 22:12:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:12:13 --> Form Validation Class Initialized
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
INFO - 2018-03-22 22:12:13 --> Controller Class Initialized
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
DEBUG - 2018-03-22 22:12:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:12:13 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Config Class Initialized
INFO - 2018-03-22 22:12:45 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:12:45 --> Utf8 Class Initialized
INFO - 2018-03-22 22:12:45 --> URI Class Initialized
INFO - 2018-03-22 22:12:45 --> Router Class Initialized
INFO - 2018-03-22 22:12:45 --> Output Class Initialized
INFO - 2018-03-22 22:12:45 --> Security Class Initialized
DEBUG - 2018-03-22 22:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:12:45 --> Input Class Initialized
INFO - 2018-03-22 22:12:45 --> Language Class Initialized
INFO - 2018-03-22 22:12:45 --> Loader Class Initialized
INFO - 2018-03-22 22:12:45 --> Helper loaded: url_helper
INFO - 2018-03-22 22:12:45 --> Helper loaded: form_helper
INFO - 2018-03-22 22:12:45 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:12:45 --> Form Validation Class Initialized
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Controller Class Initialized
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
DEBUG - 2018-03-22 22:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:12:45 --> Model Class Initialized
INFO - 2018-03-22 22:12:45 --> Final output sent to browser
DEBUG - 2018-03-22 22:12:45 --> Total execution time: 0.3663
INFO - 2018-03-22 22:13:41 --> Config Class Initialized
INFO - 2018-03-22 22:13:41 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:13:41 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:13:41 --> Utf8 Class Initialized
INFO - 2018-03-22 22:13:41 --> URI Class Initialized
INFO - 2018-03-22 22:13:41 --> Router Class Initialized
INFO - 2018-03-22 22:13:41 --> Output Class Initialized
INFO - 2018-03-22 22:13:41 --> Security Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:13:41 --> Input Class Initialized
INFO - 2018-03-22 22:13:41 --> Language Class Initialized
INFO - 2018-03-22 22:13:41 --> Loader Class Initialized
INFO - 2018-03-22 22:13:41 --> Helper loaded: url_helper
INFO - 2018-03-22 22:13:41 --> Helper loaded: form_helper
INFO - 2018-03-22 22:13:41 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:13:41 --> Form Validation Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Controller Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:13:41 --> Final output sent to browser
DEBUG - 2018-03-22 22:13:41 --> Total execution time: 0.2615
INFO - 2018-03-22 22:13:41 --> Config Class Initialized
INFO - 2018-03-22 22:13:41 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:13:41 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:13:41 --> Utf8 Class Initialized
INFO - 2018-03-22 22:13:41 --> URI Class Initialized
INFO - 2018-03-22 22:13:41 --> Router Class Initialized
INFO - 2018-03-22 22:13:41 --> Output Class Initialized
INFO - 2018-03-22 22:13:41 --> Security Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:13:41 --> Input Class Initialized
INFO - 2018-03-22 22:13:41 --> Language Class Initialized
INFO - 2018-03-22 22:13:41 --> Loader Class Initialized
INFO - 2018-03-22 22:13:41 --> Helper loaded: url_helper
INFO - 2018-03-22 22:13:41 --> Helper loaded: form_helper
INFO - 2018-03-22 22:13:41 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:13:41 --> Form Validation Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Controller Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
INFO - 2018-03-22 22:13:41 --> Model Class Initialized
DEBUG - 2018-03-22 22:13:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:13:44 --> Config Class Initialized
INFO - 2018-03-22 22:13:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:13:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:13:44 --> Utf8 Class Initialized
INFO - 2018-03-22 22:13:44 --> URI Class Initialized
INFO - 2018-03-22 22:13:44 --> Router Class Initialized
INFO - 2018-03-22 22:13:44 --> Output Class Initialized
INFO - 2018-03-22 22:13:44 --> Security Class Initialized
DEBUG - 2018-03-22 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:13:44 --> Input Class Initialized
INFO - 2018-03-22 22:13:44 --> Language Class Initialized
INFO - 2018-03-22 22:13:44 --> Loader Class Initialized
INFO - 2018-03-22 22:13:44 --> Helper loaded: url_helper
INFO - 2018-03-22 22:13:44 --> Helper loaded: form_helper
INFO - 2018-03-22 22:13:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:13:44 --> Form Validation Class Initialized
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
INFO - 2018-03-22 22:13:44 --> Controller Class Initialized
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
DEBUG - 2018-03-22 22:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:13:44 --> Model Class Initialized
INFO - 2018-03-22 22:13:44 --> Final output sent to browser
DEBUG - 2018-03-22 22:13:44 --> Total execution time: 0.5716
INFO - 2018-03-22 22:14:15 --> Config Class Initialized
INFO - 2018-03-22 22:14:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:14:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:14:15 --> Utf8 Class Initialized
INFO - 2018-03-22 22:14:15 --> URI Class Initialized
INFO - 2018-03-22 22:14:15 --> Router Class Initialized
INFO - 2018-03-22 22:14:15 --> Output Class Initialized
INFO - 2018-03-22 22:14:15 --> Security Class Initialized
DEBUG - 2018-03-22 22:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:14:15 --> Input Class Initialized
INFO - 2018-03-22 22:14:15 --> Language Class Initialized
INFO - 2018-03-22 22:14:15 --> Loader Class Initialized
INFO - 2018-03-22 22:14:15 --> Helper loaded: url_helper
INFO - 2018-03-22 22:14:15 --> Helper loaded: form_helper
INFO - 2018-03-22 22:14:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:14:15 --> Form Validation Class Initialized
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
INFO - 2018-03-22 22:14:15 --> Controller Class Initialized
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
DEBUG - 2018-03-22 22:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:14:15 --> Model Class Initialized
INFO - 2018-03-22 22:14:16 --> Final output sent to browser
DEBUG - 2018-03-22 22:14:16 --> Total execution time: 0.5094
INFO - 2018-03-22 22:16:16 --> Config Class Initialized
INFO - 2018-03-22 22:16:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:16:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:16:16 --> Utf8 Class Initialized
INFO - 2018-03-22 22:16:16 --> URI Class Initialized
INFO - 2018-03-22 22:16:16 --> Router Class Initialized
INFO - 2018-03-22 22:16:16 --> Output Class Initialized
INFO - 2018-03-22 22:16:16 --> Security Class Initialized
DEBUG - 2018-03-22 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:16:16 --> Input Class Initialized
INFO - 2018-03-22 22:16:16 --> Language Class Initialized
INFO - 2018-03-22 22:16:16 --> Loader Class Initialized
INFO - 2018-03-22 22:16:16 --> Helper loaded: url_helper
INFO - 2018-03-22 22:16:16 --> Helper loaded: form_helper
INFO - 2018-03-22 22:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:16:17 --> Form Validation Class Initialized
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
INFO - 2018-03-22 22:16:17 --> Controller Class Initialized
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
DEBUG - 2018-03-22 22:16:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:16:17 --> Model Class Initialized
INFO - 2018-03-22 22:16:17 --> Final output sent to browser
DEBUG - 2018-03-22 22:16:17 --> Total execution time: 0.4341
INFO - 2018-03-22 22:20:41 --> Config Class Initialized
INFO - 2018-03-22 22:20:41 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:20:41 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:20:41 --> Utf8 Class Initialized
INFO - 2018-03-22 22:20:41 --> URI Class Initialized
INFO - 2018-03-22 22:20:41 --> Router Class Initialized
INFO - 2018-03-22 22:20:41 --> Output Class Initialized
INFO - 2018-03-22 22:20:41 --> Security Class Initialized
DEBUG - 2018-03-22 22:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:20:41 --> Input Class Initialized
INFO - 2018-03-22 22:20:41 --> Language Class Initialized
INFO - 2018-03-22 22:20:41 --> Loader Class Initialized
INFO - 2018-03-22 22:20:41 --> Helper loaded: url_helper
INFO - 2018-03-22 22:20:41 --> Helper loaded: form_helper
INFO - 2018-03-22 22:20:41 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:20:41 --> Form Validation Class Initialized
INFO - 2018-03-22 22:20:41 --> Model Class Initialized
INFO - 2018-03-22 22:20:41 --> Controller Class Initialized
INFO - 2018-03-22 22:20:41 --> Model Class Initialized
INFO - 2018-03-22 22:20:41 --> Model Class Initialized
INFO - 2018-03-22 22:20:41 --> Model Class Initialized
INFO - 2018-03-22 22:20:41 --> Model Class Initialized
DEBUG - 2018-03-22 22:20:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:20:42 --> Model Class Initialized
INFO - 2018-03-22 22:20:42 --> Final output sent to browser
DEBUG - 2018-03-22 22:20:42 --> Total execution time: 0.5086
INFO - 2018-03-22 22:21:09 --> Config Class Initialized
INFO - 2018-03-22 22:21:09 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:21:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:21:09 --> Utf8 Class Initialized
INFO - 2018-03-22 22:21:09 --> URI Class Initialized
INFO - 2018-03-22 22:21:09 --> Router Class Initialized
INFO - 2018-03-22 22:21:09 --> Output Class Initialized
INFO - 2018-03-22 22:21:09 --> Security Class Initialized
DEBUG - 2018-03-22 22:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:21:09 --> Input Class Initialized
INFO - 2018-03-22 22:21:09 --> Language Class Initialized
INFO - 2018-03-22 22:21:09 --> Loader Class Initialized
INFO - 2018-03-22 22:21:09 --> Helper loaded: url_helper
INFO - 2018-03-22 22:21:09 --> Helper loaded: form_helper
INFO - 2018-03-22 22:21:09 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:21:09 --> Form Validation Class Initialized
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
INFO - 2018-03-22 22:21:09 --> Controller Class Initialized
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
DEBUG - 2018-03-22 22:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:21:09 --> Model Class Initialized
INFO - 2018-03-22 22:21:09 --> Final output sent to browser
DEBUG - 2018-03-22 22:21:09 --> Total execution time: 0.5314
INFO - 2018-03-22 22:21:37 --> Config Class Initialized
INFO - 2018-03-22 22:21:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:21:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:21:37 --> Utf8 Class Initialized
INFO - 2018-03-22 22:21:37 --> URI Class Initialized
INFO - 2018-03-22 22:21:37 --> Router Class Initialized
INFO - 2018-03-22 22:21:37 --> Output Class Initialized
INFO - 2018-03-22 22:21:37 --> Security Class Initialized
DEBUG - 2018-03-22 22:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:21:37 --> Input Class Initialized
INFO - 2018-03-22 22:21:37 --> Language Class Initialized
INFO - 2018-03-22 22:21:37 --> Loader Class Initialized
INFO - 2018-03-22 22:21:37 --> Helper loaded: url_helper
INFO - 2018-03-22 22:21:37 --> Helper loaded: form_helper
INFO - 2018-03-22 22:21:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:21:37 --> Form Validation Class Initialized
INFO - 2018-03-22 22:21:37 --> Model Class Initialized
INFO - 2018-03-22 22:21:37 --> Controller Class Initialized
INFO - 2018-03-22 22:21:37 --> Model Class Initialized
INFO - 2018-03-22 22:21:37 --> Model Class Initialized
INFO - 2018-03-22 22:21:37 --> Model Class Initialized
INFO - 2018-03-22 22:21:37 --> Model Class Initialized
DEBUG - 2018-03-22 22:21:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:21:40 --> Config Class Initialized
INFO - 2018-03-22 22:21:40 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:21:40 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:21:40 --> Utf8 Class Initialized
INFO - 2018-03-22 22:21:40 --> URI Class Initialized
INFO - 2018-03-22 22:21:40 --> Router Class Initialized
INFO - 2018-03-22 22:21:40 --> Output Class Initialized
INFO - 2018-03-22 22:21:40 --> Security Class Initialized
DEBUG - 2018-03-22 22:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:21:40 --> Input Class Initialized
INFO - 2018-03-22 22:21:40 --> Language Class Initialized
INFO - 2018-03-22 22:21:40 --> Loader Class Initialized
INFO - 2018-03-22 22:21:40 --> Helper loaded: url_helper
INFO - 2018-03-22 22:21:40 --> Helper loaded: form_helper
INFO - 2018-03-22 22:21:40 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:21:40 --> Form Validation Class Initialized
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
INFO - 2018-03-22 22:21:40 --> Controller Class Initialized
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
DEBUG - 2018-03-22 22:21:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:21:40 --> Model Class Initialized
INFO - 2018-03-22 22:21:40 --> Final output sent to browser
DEBUG - 2018-03-22 22:21:40 --> Total execution time: 0.3189
INFO - 2018-03-22 22:22:02 --> Config Class Initialized
INFO - 2018-03-22 22:22:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:22:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:22:02 --> Utf8 Class Initialized
INFO - 2018-03-22 22:22:02 --> URI Class Initialized
INFO - 2018-03-22 22:22:02 --> Router Class Initialized
INFO - 2018-03-22 22:22:02 --> Output Class Initialized
INFO - 2018-03-22 22:22:02 --> Security Class Initialized
DEBUG - 2018-03-22 22:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:22:02 --> Input Class Initialized
INFO - 2018-03-22 22:22:02 --> Language Class Initialized
INFO - 2018-03-22 22:22:02 --> Loader Class Initialized
INFO - 2018-03-22 22:22:02 --> Helper loaded: url_helper
INFO - 2018-03-22 22:22:02 --> Helper loaded: form_helper
INFO - 2018-03-22 22:22:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:22:02 --> Form Validation Class Initialized
INFO - 2018-03-22 22:22:02 --> Model Class Initialized
INFO - 2018-03-22 22:22:02 --> Controller Class Initialized
INFO - 2018-03-22 22:22:02 --> Model Class Initialized
INFO - 2018-03-22 22:22:02 --> Model Class Initialized
INFO - 2018-03-22 22:22:02 --> Model Class Initialized
INFO - 2018-03-22 22:22:02 --> Model Class Initialized
DEBUG - 2018-03-22 22:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:22:11 --> Config Class Initialized
INFO - 2018-03-22 22:22:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:22:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:22:11 --> Utf8 Class Initialized
INFO - 2018-03-22 22:22:11 --> URI Class Initialized
INFO - 2018-03-22 22:22:11 --> Router Class Initialized
INFO - 2018-03-22 22:22:11 --> Output Class Initialized
INFO - 2018-03-22 22:22:11 --> Security Class Initialized
DEBUG - 2018-03-22 22:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:22:11 --> Input Class Initialized
INFO - 2018-03-22 22:22:11 --> Language Class Initialized
INFO - 2018-03-22 22:22:11 --> Loader Class Initialized
INFO - 2018-03-22 22:22:11 --> Helper loaded: url_helper
INFO - 2018-03-22 22:22:11 --> Helper loaded: form_helper
INFO - 2018-03-22 22:22:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:22:11 --> Form Validation Class Initialized
INFO - 2018-03-22 22:22:11 --> Model Class Initialized
INFO - 2018-03-22 22:22:11 --> Controller Class Initialized
INFO - 2018-03-22 22:22:11 --> Model Class Initialized
INFO - 2018-03-22 22:22:11 --> Model Class Initialized
INFO - 2018-03-22 22:22:11 --> Model Class Initialized
INFO - 2018-03-22 22:22:11 --> Model Class Initialized
DEBUG - 2018-03-22 22:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:22:13 --> Config Class Initialized
INFO - 2018-03-22 22:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:22:13 --> Utf8 Class Initialized
INFO - 2018-03-22 22:22:13 --> URI Class Initialized
INFO - 2018-03-22 22:22:13 --> Router Class Initialized
INFO - 2018-03-22 22:22:13 --> Output Class Initialized
INFO - 2018-03-22 22:22:13 --> Security Class Initialized
DEBUG - 2018-03-22 22:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:22:13 --> Input Class Initialized
INFO - 2018-03-22 22:22:13 --> Language Class Initialized
INFO - 2018-03-22 22:22:13 --> Loader Class Initialized
INFO - 2018-03-22 22:22:13 --> Helper loaded: url_helper
INFO - 2018-03-22 22:22:13 --> Helper loaded: form_helper
INFO - 2018-03-22 22:22:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:22:13 --> Form Validation Class Initialized
INFO - 2018-03-22 22:22:13 --> Model Class Initialized
INFO - 2018-03-22 22:22:13 --> Controller Class Initialized
INFO - 2018-03-22 22:22:13 --> Model Class Initialized
INFO - 2018-03-22 22:22:13 --> Model Class Initialized
INFO - 2018-03-22 22:22:13 --> Model Class Initialized
INFO - 2018-03-22 22:22:13 --> Model Class Initialized
DEBUG - 2018-03-22 22:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:22:14 --> Model Class Initialized
INFO - 2018-03-22 22:22:14 --> Final output sent to browser
DEBUG - 2018-03-22 22:22:14 --> Total execution time: 0.3303
INFO - 2018-03-22 22:24:03 --> Config Class Initialized
INFO - 2018-03-22 22:24:03 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:24:03 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:24:03 --> Utf8 Class Initialized
INFO - 2018-03-22 22:24:03 --> URI Class Initialized
INFO - 2018-03-22 22:24:03 --> Router Class Initialized
INFO - 2018-03-22 22:24:03 --> Output Class Initialized
INFO - 2018-03-22 22:24:03 --> Security Class Initialized
DEBUG - 2018-03-22 22:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:24:03 --> Input Class Initialized
INFO - 2018-03-22 22:24:03 --> Language Class Initialized
INFO - 2018-03-22 22:24:03 --> Loader Class Initialized
INFO - 2018-03-22 22:24:03 --> Helper loaded: url_helper
INFO - 2018-03-22 22:24:03 --> Helper loaded: form_helper
INFO - 2018-03-22 22:24:03 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:24:03 --> Form Validation Class Initialized
INFO - 2018-03-22 22:24:03 --> Model Class Initialized
INFO - 2018-03-22 22:24:03 --> Controller Class Initialized
INFO - 2018-03-22 22:24:03 --> Model Class Initialized
INFO - 2018-03-22 22:24:03 --> Model Class Initialized
INFO - 2018-03-22 22:24:03 --> Model Class Initialized
INFO - 2018-03-22 22:24:03 --> Model Class Initialized
DEBUG - 2018-03-22 22:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:24:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:24:03 --> Final output sent to browser
DEBUG - 2018-03-22 22:24:03 --> Total execution time: 0.2222
INFO - 2018-03-22 22:31:49 --> Config Class Initialized
INFO - 2018-03-22 22:31:49 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:31:49 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:31:49 --> Utf8 Class Initialized
INFO - 2018-03-22 22:31:49 --> URI Class Initialized
INFO - 2018-03-22 22:31:49 --> Router Class Initialized
INFO - 2018-03-22 22:31:49 --> Output Class Initialized
INFO - 2018-03-22 22:31:49 --> Security Class Initialized
DEBUG - 2018-03-22 22:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:31:49 --> Input Class Initialized
INFO - 2018-03-22 22:31:49 --> Language Class Initialized
INFO - 2018-03-22 22:31:49 --> Loader Class Initialized
INFO - 2018-03-22 22:31:49 --> Helper loaded: url_helper
INFO - 2018-03-22 22:31:49 --> Helper loaded: form_helper
INFO - 2018-03-22 22:31:49 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:31:49 --> Form Validation Class Initialized
INFO - 2018-03-22 22:31:49 --> Model Class Initialized
INFO - 2018-03-22 22:31:49 --> Controller Class Initialized
INFO - 2018-03-22 22:31:49 --> Model Class Initialized
INFO - 2018-03-22 22:31:49 --> Model Class Initialized
INFO - 2018-03-22 22:31:49 --> Model Class Initialized
INFO - 2018-03-22 22:31:49 --> Model Class Initialized
DEBUG - 2018-03-22 22:31:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:31:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:31:49 --> Final output sent to browser
DEBUG - 2018-03-22 22:31:49 --> Total execution time: 0.2542
INFO - 2018-03-22 22:33:12 --> Config Class Initialized
INFO - 2018-03-22 22:33:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:33:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:33:12 --> Utf8 Class Initialized
INFO - 2018-03-22 22:33:12 --> URI Class Initialized
INFO - 2018-03-22 22:33:12 --> Router Class Initialized
INFO - 2018-03-22 22:33:12 --> Output Class Initialized
INFO - 2018-03-22 22:33:12 --> Security Class Initialized
DEBUG - 2018-03-22 22:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:33:12 --> Input Class Initialized
INFO - 2018-03-22 22:33:12 --> Language Class Initialized
INFO - 2018-03-22 22:33:12 --> Loader Class Initialized
INFO - 2018-03-22 22:33:12 --> Helper loaded: url_helper
INFO - 2018-03-22 22:33:12 --> Helper loaded: form_helper
INFO - 2018-03-22 22:33:12 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:33:12 --> Form Validation Class Initialized
INFO - 2018-03-22 22:33:12 --> Model Class Initialized
INFO - 2018-03-22 22:33:12 --> Controller Class Initialized
INFO - 2018-03-22 22:33:12 --> Model Class Initialized
INFO - 2018-03-22 22:33:12 --> Model Class Initialized
INFO - 2018-03-22 22:33:12 --> Model Class Initialized
INFO - 2018-03-22 22:33:12 --> Model Class Initialized
DEBUG - 2018-03-22 22:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:33:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:33:12 --> Final output sent to browser
DEBUG - 2018-03-22 22:33:12 --> Total execution time: 0.3235
INFO - 2018-03-22 22:51:36 --> Config Class Initialized
INFO - 2018-03-22 22:51:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:51:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:51:37 --> Utf8 Class Initialized
INFO - 2018-03-22 22:51:37 --> URI Class Initialized
INFO - 2018-03-22 22:51:37 --> Router Class Initialized
INFO - 2018-03-22 22:51:37 --> Output Class Initialized
INFO - 2018-03-22 22:51:37 --> Security Class Initialized
DEBUG - 2018-03-22 22:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:51:37 --> Input Class Initialized
INFO - 2018-03-22 22:51:37 --> Language Class Initialized
INFO - 2018-03-22 22:51:37 --> Loader Class Initialized
INFO - 2018-03-22 22:51:37 --> Helper loaded: url_helper
INFO - 2018-03-22 22:51:37 --> Helper loaded: form_helper
INFO - 2018-03-22 22:51:37 --> Database Driver Class Initialized
ERROR - 2018-03-22 22:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No se puede establecer una conexi�n ya que el equipo de destino deneg� expresamente dicha conexi�n.
 D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-03-22 22:51:39 --> Unable to connect to the database
INFO - 2018-03-22 22:51:40 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-22 22:53:24 --> Config Class Initialized
INFO - 2018-03-22 22:53:24 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:53:24 --> Utf8 Class Initialized
INFO - 2018-03-22 22:53:24 --> URI Class Initialized
INFO - 2018-03-22 22:53:24 --> Router Class Initialized
INFO - 2018-03-22 22:53:24 --> Output Class Initialized
INFO - 2018-03-22 22:53:24 --> Security Class Initialized
DEBUG - 2018-03-22 22:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:53:24 --> Input Class Initialized
INFO - 2018-03-22 22:53:24 --> Language Class Initialized
INFO - 2018-03-22 22:53:24 --> Loader Class Initialized
INFO - 2018-03-22 22:53:24 --> Helper loaded: url_helper
INFO - 2018-03-22 22:53:24 --> Helper loaded: form_helper
INFO - 2018-03-22 22:53:24 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:53:24 --> Form Validation Class Initialized
INFO - 2018-03-22 22:53:24 --> Model Class Initialized
INFO - 2018-03-22 22:53:24 --> Controller Class Initialized
INFO - 2018-03-22 22:53:24 --> Model Class Initialized
INFO - 2018-03-22 22:53:24 --> Model Class Initialized
INFO - 2018-03-22 22:53:24 --> Model Class Initialized
INFO - 2018-03-22 22:53:24 --> Model Class Initialized
DEBUG - 2018-03-22 22:53:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 22:53:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:53:25 --> Final output sent to browser
DEBUG - 2018-03-22 22:53:25 --> Total execution time: 0.5993
INFO - 2018-03-22 22:57:26 --> Config Class Initialized
INFO - 2018-03-22 22:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:57:26 --> Utf8 Class Initialized
INFO - 2018-03-22 22:57:26 --> URI Class Initialized
INFO - 2018-03-22 22:57:26 --> Router Class Initialized
INFO - 2018-03-22 22:57:26 --> Output Class Initialized
INFO - 2018-03-22 22:57:26 --> Security Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:57:26 --> Input Class Initialized
INFO - 2018-03-22 22:57:26 --> Language Class Initialized
INFO - 2018-03-22 22:57:26 --> Loader Class Initialized
INFO - 2018-03-22 22:57:26 --> Helper loaded: url_helper
INFO - 2018-03-22 22:57:26 --> Helper loaded: form_helper
INFO - 2018-03-22 22:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:57:26 --> Form Validation Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Controller Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 22:57:26 --> Severity: Notice --> Undefined variable: puestos D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyecto.php 64
ERROR - 2018-03-22 22:57:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyecto.php 64
INFO - 2018-03-22 22:57:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 22:57:26 --> Final output sent to browser
DEBUG - 2018-03-22 22:57:26 --> Total execution time: 0.0717
INFO - 2018-03-22 22:57:26 --> Config Class Initialized
INFO - 2018-03-22 22:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 22:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 22:57:26 --> Utf8 Class Initialized
INFO - 2018-03-22 22:57:26 --> URI Class Initialized
INFO - 2018-03-22 22:57:26 --> Router Class Initialized
INFO - 2018-03-22 22:57:26 --> Output Class Initialized
INFO - 2018-03-22 22:57:26 --> Security Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 22:57:26 --> Input Class Initialized
INFO - 2018-03-22 22:57:26 --> Language Class Initialized
INFO - 2018-03-22 22:57:26 --> Loader Class Initialized
INFO - 2018-03-22 22:57:26 --> Helper loaded: url_helper
INFO - 2018-03-22 22:57:26 --> Helper loaded: form_helper
INFO - 2018-03-22 22:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 22:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 22:57:26 --> Form Validation Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Controller Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
INFO - 2018-03-22 22:57:26 --> Model Class Initialized
DEBUG - 2018-03-22 22:57:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:16 --> Config Class Initialized
INFO - 2018-03-22 23:00:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:16 --> URI Class Initialized
INFO - 2018-03-22 23:00:16 --> Router Class Initialized
INFO - 2018-03-22 23:00:16 --> Output Class Initialized
INFO - 2018-03-22 23:00:16 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:16 --> Input Class Initialized
INFO - 2018-03-22 23:00:16 --> Language Class Initialized
INFO - 2018-03-22 23:00:16 --> Loader Class Initialized
INFO - 2018-03-22 23:00:16 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:16 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:16 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Controller Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:00:16 --> Final output sent to browser
DEBUG - 2018-03-22 23:00:16 --> Total execution time: 0.0958
INFO - 2018-03-22 23:00:16 --> Config Class Initialized
INFO - 2018-03-22 23:00:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:16 --> URI Class Initialized
INFO - 2018-03-22 23:00:16 --> Router Class Initialized
INFO - 2018-03-22 23:00:16 --> Output Class Initialized
INFO - 2018-03-22 23:00:16 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:16 --> Input Class Initialized
INFO - 2018-03-22 23:00:16 --> Language Class Initialized
INFO - 2018-03-22 23:00:16 --> Loader Class Initialized
INFO - 2018-03-22 23:00:16 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:16 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:16 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Controller Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
INFO - 2018-03-22 23:00:16 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:38 --> Config Class Initialized
INFO - 2018-03-22 23:00:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:38 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:38 --> URI Class Initialized
INFO - 2018-03-22 23:00:38 --> Router Class Initialized
INFO - 2018-03-22 23:00:38 --> Output Class Initialized
INFO - 2018-03-22 23:00:38 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:38 --> Input Class Initialized
INFO - 2018-03-22 23:00:38 --> Language Class Initialized
INFO - 2018-03-22 23:00:38 --> Loader Class Initialized
INFO - 2018-03-22 23:00:38 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:38 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:38 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:38 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
INFO - 2018-03-22 23:00:38 --> Controller Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
INFO - 2018-03-22 23:00:38 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:43 --> Config Class Initialized
INFO - 2018-03-22 23:00:43 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:43 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:43 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:43 --> URI Class Initialized
INFO - 2018-03-22 23:00:43 --> Router Class Initialized
INFO - 2018-03-22 23:00:43 --> Output Class Initialized
INFO - 2018-03-22 23:00:43 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:43 --> Input Class Initialized
INFO - 2018-03-22 23:00:43 --> Language Class Initialized
INFO - 2018-03-22 23:00:43 --> Loader Class Initialized
INFO - 2018-03-22 23:00:43 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:43 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:43 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
INFO - 2018-03-22 23:00:43 --> Controller Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
INFO - 2018-03-22 23:00:43 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:46 --> Config Class Initialized
INFO - 2018-03-22 23:00:46 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:46 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:46 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:46 --> URI Class Initialized
INFO - 2018-03-22 23:00:46 --> Router Class Initialized
INFO - 2018-03-22 23:00:46 --> Output Class Initialized
INFO - 2018-03-22 23:00:46 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:46 --> Input Class Initialized
INFO - 2018-03-22 23:00:46 --> Language Class Initialized
INFO - 2018-03-22 23:00:46 --> Loader Class Initialized
INFO - 2018-03-22 23:00:46 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:46 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:46 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:46 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
INFO - 2018-03-22 23:00:46 --> Controller Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
INFO - 2018-03-22 23:00:46 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:00:49 --> Config Class Initialized
INFO - 2018-03-22 23:00:49 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:00:49 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:00:49 --> Utf8 Class Initialized
INFO - 2018-03-22 23:00:49 --> URI Class Initialized
INFO - 2018-03-22 23:00:49 --> Router Class Initialized
INFO - 2018-03-22 23:00:49 --> Output Class Initialized
INFO - 2018-03-22 23:00:49 --> Security Class Initialized
DEBUG - 2018-03-22 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:00:49 --> Input Class Initialized
INFO - 2018-03-22 23:00:49 --> Language Class Initialized
INFO - 2018-03-22 23:00:49 --> Loader Class Initialized
INFO - 2018-03-22 23:00:49 --> Helper loaded: url_helper
INFO - 2018-03-22 23:00:49 --> Helper loaded: form_helper
INFO - 2018-03-22 23:00:49 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:00:49 --> Form Validation Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
INFO - 2018-03-22 23:00:49 --> Controller Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
INFO - 2018-03-22 23:00:49 --> Model Class Initialized
DEBUG - 2018-03-22 23:00:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:03 --> Config Class Initialized
INFO - 2018-03-22 23:01:03 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:03 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:03 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:03 --> URI Class Initialized
INFO - 2018-03-22 23:01:03 --> Router Class Initialized
INFO - 2018-03-22 23:01:03 --> Output Class Initialized
INFO - 2018-03-22 23:01:03 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:03 --> Input Class Initialized
INFO - 2018-03-22 23:01:03 --> Language Class Initialized
INFO - 2018-03-22 23:01:03 --> Loader Class Initialized
INFO - 2018-03-22 23:01:03 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:03 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:03 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:03 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
INFO - 2018-03-22 23:01:03 --> Controller Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
INFO - 2018-03-22 23:01:03 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:06 --> Config Class Initialized
INFO - 2018-03-22 23:01:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:06 --> URI Class Initialized
INFO - 2018-03-22 23:01:06 --> Router Class Initialized
INFO - 2018-03-22 23:01:06 --> Output Class Initialized
INFO - 2018-03-22 23:01:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:06 --> Input Class Initialized
INFO - 2018-03-22 23:01:06 --> Language Class Initialized
INFO - 2018-03-22 23:01:06 --> Loader Class Initialized
INFO - 2018-03-22 23:01:06 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:06 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:06 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
INFO - 2018-03-22 23:01:06 --> Controller Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
INFO - 2018-03-22 23:01:06 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:08 --> Config Class Initialized
INFO - 2018-03-22 23:01:08 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:08 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:08 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:08 --> URI Class Initialized
INFO - 2018-03-22 23:01:08 --> Router Class Initialized
INFO - 2018-03-22 23:01:08 --> Output Class Initialized
INFO - 2018-03-22 23:01:08 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:08 --> Input Class Initialized
INFO - 2018-03-22 23:01:08 --> Language Class Initialized
INFO - 2018-03-22 23:01:08 --> Loader Class Initialized
INFO - 2018-03-22 23:01:08 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:08 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:08 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:08 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
INFO - 2018-03-22 23:01:08 --> Controller Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
INFO - 2018-03-22 23:01:08 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:12 --> Config Class Initialized
INFO - 2018-03-22 23:01:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:12 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:12 --> URI Class Initialized
INFO - 2018-03-22 23:01:12 --> Router Class Initialized
INFO - 2018-03-22 23:01:12 --> Output Class Initialized
INFO - 2018-03-22 23:01:12 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:12 --> Input Class Initialized
INFO - 2018-03-22 23:01:12 --> Language Class Initialized
INFO - 2018-03-22 23:01:12 --> Loader Class Initialized
INFO - 2018-03-22 23:01:12 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:12 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:12 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:12 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
INFO - 2018-03-22 23:01:12 --> Controller Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
INFO - 2018-03-22 23:01:12 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:16 --> Config Class Initialized
INFO - 2018-03-22 23:01:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:16 --> URI Class Initialized
INFO - 2018-03-22 23:01:16 --> Router Class Initialized
INFO - 2018-03-22 23:01:16 --> Output Class Initialized
INFO - 2018-03-22 23:01:16 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:16 --> Input Class Initialized
INFO - 2018-03-22 23:01:16 --> Language Class Initialized
INFO - 2018-03-22 23:01:16 --> Loader Class Initialized
INFO - 2018-03-22 23:01:16 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:16 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:16 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
INFO - 2018-03-22 23:01:16 --> Controller Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
INFO - 2018-03-22 23:01:16 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:16 --> Final output sent to browser
DEBUG - 2018-03-22 23:01:16 --> Total execution time: 0.0568
INFO - 2018-03-22 23:01:17 --> Config Class Initialized
INFO - 2018-03-22 23:01:17 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:17 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:17 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:17 --> URI Class Initialized
INFO - 2018-03-22 23:01:17 --> Router Class Initialized
INFO - 2018-03-22 23:01:17 --> Output Class Initialized
INFO - 2018-03-22 23:01:17 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:17 --> Input Class Initialized
INFO - 2018-03-22 23:01:17 --> Language Class Initialized
INFO - 2018-03-22 23:01:17 --> Loader Class Initialized
INFO - 2018-03-22 23:01:17 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:17 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:17 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:17 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
INFO - 2018-03-22 23:01:17 --> Controller Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
INFO - 2018-03-22 23:01:17 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:18 --> Config Class Initialized
INFO - 2018-03-22 23:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:18 --> URI Class Initialized
INFO - 2018-03-22 23:01:18 --> Router Class Initialized
INFO - 2018-03-22 23:01:18 --> Output Class Initialized
INFO - 2018-03-22 23:01:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:18 --> Input Class Initialized
INFO - 2018-03-22 23:01:18 --> Language Class Initialized
INFO - 2018-03-22 23:01:18 --> Loader Class Initialized
INFO - 2018-03-22 23:01:18 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:18 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:19 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
INFO - 2018-03-22 23:01:19 --> Controller Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
INFO - 2018-03-22 23:01:19 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:21 --> Config Class Initialized
INFO - 2018-03-22 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:21 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:21 --> URI Class Initialized
INFO - 2018-03-22 23:01:21 --> Router Class Initialized
INFO - 2018-03-22 23:01:21 --> Output Class Initialized
INFO - 2018-03-22 23:01:21 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:21 --> Input Class Initialized
INFO - 2018-03-22 23:01:21 --> Language Class Initialized
INFO - 2018-03-22 23:01:21 --> Loader Class Initialized
INFO - 2018-03-22 23:01:21 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:21 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:21 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Controller Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:21 --> Config Class Initialized
INFO - 2018-03-22 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:21 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:21 --> URI Class Initialized
INFO - 2018-03-22 23:01:21 --> Router Class Initialized
INFO - 2018-03-22 23:01:21 --> Output Class Initialized
INFO - 2018-03-22 23:01:21 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:21 --> Input Class Initialized
INFO - 2018-03-22 23:01:21 --> Language Class Initialized
INFO - 2018-03-22 23:01:21 --> Loader Class Initialized
INFO - 2018-03-22 23:01:21 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:21 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:21 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Controller Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
INFO - 2018-03-22 23:01:21 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:01:22 --> Config Class Initialized
INFO - 2018-03-22 23:01:22 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:01:22 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:01:22 --> Utf8 Class Initialized
INFO - 2018-03-22 23:01:22 --> URI Class Initialized
INFO - 2018-03-22 23:01:22 --> Router Class Initialized
INFO - 2018-03-22 23:01:22 --> Output Class Initialized
INFO - 2018-03-22 23:01:22 --> Security Class Initialized
DEBUG - 2018-03-22 23:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:01:22 --> Input Class Initialized
INFO - 2018-03-22 23:01:22 --> Language Class Initialized
INFO - 2018-03-22 23:01:22 --> Loader Class Initialized
INFO - 2018-03-22 23:01:22 --> Helper loaded: url_helper
INFO - 2018-03-22 23:01:22 --> Helper loaded: form_helper
INFO - 2018-03-22 23:01:22 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:01:22 --> Form Validation Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
INFO - 2018-03-22 23:01:22 --> Controller Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
INFO - 2018-03-22 23:01:22 --> Model Class Initialized
DEBUG - 2018-03-22 23:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:02:28 --> Config Class Initialized
INFO - 2018-03-22 23:02:28 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:02:28 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:02:28 --> Utf8 Class Initialized
INFO - 2018-03-22 23:02:28 --> URI Class Initialized
INFO - 2018-03-22 23:02:28 --> Router Class Initialized
INFO - 2018-03-22 23:02:28 --> Output Class Initialized
INFO - 2018-03-22 23:02:28 --> Security Class Initialized
DEBUG - 2018-03-22 23:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:02:28 --> Input Class Initialized
INFO - 2018-03-22 23:02:28 --> Language Class Initialized
INFO - 2018-03-22 23:02:28 --> Loader Class Initialized
INFO - 2018-03-22 23:02:28 --> Helper loaded: url_helper
INFO - 2018-03-22 23:02:28 --> Helper loaded: form_helper
INFO - 2018-03-22 23:02:28 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:02:28 --> Form Validation Class Initialized
INFO - 2018-03-22 23:02:28 --> Model Class Initialized
INFO - 2018-03-22 23:02:28 --> Controller Class Initialized
INFO - 2018-03-22 23:02:28 --> Model Class Initialized
INFO - 2018-03-22 23:02:28 --> Model Class Initialized
INFO - 2018-03-22 23:02:28 --> Model Class Initialized
INFO - 2018-03-22 23:02:28 --> Model Class Initialized
DEBUG - 2018-03-22 23:02:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:02:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:02:28 --> Final output sent to browser
DEBUG - 2018-03-22 23:02:28 --> Total execution time: 0.1103
INFO - 2018-03-22 23:02:29 --> Config Class Initialized
INFO - 2018-03-22 23:02:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:02:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:02:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:02:29 --> URI Class Initialized
INFO - 2018-03-22 23:02:29 --> Router Class Initialized
INFO - 2018-03-22 23:02:29 --> Output Class Initialized
INFO - 2018-03-22 23:02:29 --> Security Class Initialized
DEBUG - 2018-03-22 23:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:02:29 --> Input Class Initialized
INFO - 2018-03-22 23:02:29 --> Language Class Initialized
INFO - 2018-03-22 23:02:29 --> Loader Class Initialized
INFO - 2018-03-22 23:02:29 --> Helper loaded: url_helper
INFO - 2018-03-22 23:02:30 --> Helper loaded: form_helper
INFO - 2018-03-22 23:02:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:02:30 --> Form Validation Class Initialized
INFO - 2018-03-22 23:02:30 --> Model Class Initialized
INFO - 2018-03-22 23:02:30 --> Controller Class Initialized
INFO - 2018-03-22 23:02:30 --> Model Class Initialized
INFO - 2018-03-22 23:02:30 --> Model Class Initialized
INFO - 2018-03-22 23:02:30 --> Model Class Initialized
INFO - 2018-03-22 23:02:30 --> Model Class Initialized
DEBUG - 2018-03-22 23:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:02:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:02:30 --> Final output sent to browser
DEBUG - 2018-03-22 23:02:30 --> Total execution time: 0.1117
INFO - 2018-03-22 23:02:31 --> Config Class Initialized
INFO - 2018-03-22 23:02:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:02:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:02:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:02:31 --> URI Class Initialized
INFO - 2018-03-22 23:02:31 --> Router Class Initialized
INFO - 2018-03-22 23:02:31 --> Output Class Initialized
INFO - 2018-03-22 23:02:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:02:31 --> Input Class Initialized
INFO - 2018-03-22 23:02:31 --> Language Class Initialized
INFO - 2018-03-22 23:02:31 --> Loader Class Initialized
INFO - 2018-03-22 23:02:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:02:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:02:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:02:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Controller Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:02:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:02:31 --> Final output sent to browser
DEBUG - 2018-03-22 23:02:31 --> Total execution time: 0.0980
INFO - 2018-03-22 23:02:31 --> Config Class Initialized
INFO - 2018-03-22 23:02:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:02:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:02:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:02:31 --> URI Class Initialized
INFO - 2018-03-22 23:02:31 --> Router Class Initialized
INFO - 2018-03-22 23:02:31 --> Output Class Initialized
INFO - 2018-03-22 23:02:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:02:31 --> Input Class Initialized
INFO - 2018-03-22 23:02:31 --> Language Class Initialized
INFO - 2018-03-22 23:02:31 --> Loader Class Initialized
INFO - 2018-03-22 23:02:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:02:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:02:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:02:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Controller Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
INFO - 2018-03-22 23:02:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:03:06 --> Config Class Initialized
INFO - 2018-03-22 23:03:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:03:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:03:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:03:06 --> URI Class Initialized
INFO - 2018-03-22 23:03:06 --> Router Class Initialized
INFO - 2018-03-22 23:03:06 --> Output Class Initialized
INFO - 2018-03-22 23:03:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:03:06 --> Input Class Initialized
INFO - 2018-03-22 23:03:06 --> Language Class Initialized
INFO - 2018-03-22 23:03:06 --> Loader Class Initialized
INFO - 2018-03-22 23:03:06 --> Helper loaded: url_helper
INFO - 2018-03-22 23:03:06 --> Helper loaded: form_helper
INFO - 2018-03-22 23:03:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:03:06 --> Form Validation Class Initialized
INFO - 2018-03-22 23:03:06 --> Model Class Initialized
INFO - 2018-03-22 23:03:06 --> Controller Class Initialized
INFO - 2018-03-22 23:03:06 --> Model Class Initialized
INFO - 2018-03-22 23:03:06 --> Model Class Initialized
INFO - 2018-03-22 23:03:06 --> Model Class Initialized
INFO - 2018-03-22 23:03:06 --> Model Class Initialized
DEBUG - 2018-03-22 23:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:03:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:03:06 --> Final output sent to browser
DEBUG - 2018-03-22 23:03:06 --> Total execution time: 0.0955
INFO - 2018-03-22 23:03:07 --> Config Class Initialized
INFO - 2018-03-22 23:03:07 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:03:07 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:03:07 --> Utf8 Class Initialized
INFO - 2018-03-22 23:03:07 --> URI Class Initialized
INFO - 2018-03-22 23:03:07 --> Router Class Initialized
INFO - 2018-03-22 23:03:07 --> Output Class Initialized
INFO - 2018-03-22 23:03:07 --> Security Class Initialized
DEBUG - 2018-03-22 23:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:03:07 --> Input Class Initialized
INFO - 2018-03-22 23:03:07 --> Language Class Initialized
INFO - 2018-03-22 23:03:07 --> Loader Class Initialized
INFO - 2018-03-22 23:03:07 --> Helper loaded: url_helper
INFO - 2018-03-22 23:03:07 --> Helper loaded: form_helper
INFO - 2018-03-22 23:03:07 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:03:07 --> Form Validation Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
INFO - 2018-03-22 23:03:07 --> Controller Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
INFO - 2018-03-22 23:03:07 --> Model Class Initialized
DEBUG - 2018-03-22 23:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:03:30 --> Config Class Initialized
INFO - 2018-03-22 23:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:03:30 --> Utf8 Class Initialized
INFO - 2018-03-22 23:03:30 --> URI Class Initialized
INFO - 2018-03-22 23:03:30 --> Router Class Initialized
INFO - 2018-03-22 23:03:30 --> Output Class Initialized
INFO - 2018-03-22 23:03:30 --> Security Class Initialized
DEBUG - 2018-03-22 23:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:03:30 --> Input Class Initialized
INFO - 2018-03-22 23:03:30 --> Language Class Initialized
INFO - 2018-03-22 23:03:30 --> Loader Class Initialized
INFO - 2018-03-22 23:03:30 --> Helper loaded: url_helper
INFO - 2018-03-22 23:03:30 --> Helper loaded: form_helper
INFO - 2018-03-22 23:03:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:03:30 --> Form Validation Class Initialized
INFO - 2018-03-22 23:03:30 --> Model Class Initialized
INFO - 2018-03-22 23:03:30 --> Controller Class Initialized
INFO - 2018-03-22 23:03:30 --> Model Class Initialized
INFO - 2018-03-22 23:03:30 --> Model Class Initialized
INFO - 2018-03-22 23:03:30 --> Model Class Initialized
INFO - 2018-03-22 23:03:30 --> Model Class Initialized
DEBUG - 2018-03-22 23:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:03:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:03:30 --> Final output sent to browser
DEBUG - 2018-03-22 23:03:30 --> Total execution time: 0.1293
INFO - 2018-03-22 23:03:31 --> Config Class Initialized
INFO - 2018-03-22 23:03:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:03:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:03:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:03:31 --> URI Class Initialized
INFO - 2018-03-22 23:03:31 --> Router Class Initialized
INFO - 2018-03-22 23:03:31 --> Output Class Initialized
INFO - 2018-03-22 23:03:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:03:31 --> Input Class Initialized
INFO - 2018-03-22 23:03:31 --> Language Class Initialized
INFO - 2018-03-22 23:03:31 --> Loader Class Initialized
INFO - 2018-03-22 23:03:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:03:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:03:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:03:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
INFO - 2018-03-22 23:03:31 --> Controller Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
INFO - 2018-03-22 23:03:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:03:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:04:12 --> Config Class Initialized
INFO - 2018-03-22 23:04:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:04:12 --> Utf8 Class Initialized
INFO - 2018-03-22 23:04:12 --> URI Class Initialized
INFO - 2018-03-22 23:04:12 --> Router Class Initialized
INFO - 2018-03-22 23:04:12 --> Output Class Initialized
INFO - 2018-03-22 23:04:12 --> Security Class Initialized
DEBUG - 2018-03-22 23:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:04:12 --> Input Class Initialized
INFO - 2018-03-22 23:04:12 --> Language Class Initialized
INFO - 2018-03-22 23:04:12 --> Loader Class Initialized
INFO - 2018-03-22 23:04:12 --> Helper loaded: url_helper
INFO - 2018-03-22 23:04:12 --> Helper loaded: form_helper
INFO - 2018-03-22 23:04:12 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:04:12 --> Form Validation Class Initialized
INFO - 2018-03-22 23:04:12 --> Model Class Initialized
INFO - 2018-03-22 23:04:12 --> Controller Class Initialized
INFO - 2018-03-22 23:04:12 --> Model Class Initialized
INFO - 2018-03-22 23:04:12 --> Model Class Initialized
INFO - 2018-03-22 23:04:12 --> Model Class Initialized
INFO - 2018-03-22 23:04:12 --> Model Class Initialized
DEBUG - 2018-03-22 23:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:04:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:04:12 --> Final output sent to browser
DEBUG - 2018-03-22 23:04:12 --> Total execution time: 0.0943
INFO - 2018-03-22 23:04:13 --> Config Class Initialized
INFO - 2018-03-22 23:04:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:04:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:04:13 --> Utf8 Class Initialized
INFO - 2018-03-22 23:04:13 --> URI Class Initialized
INFO - 2018-03-22 23:04:13 --> Router Class Initialized
INFO - 2018-03-22 23:04:13 --> Output Class Initialized
INFO - 2018-03-22 23:04:13 --> Security Class Initialized
DEBUG - 2018-03-22 23:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:04:13 --> Input Class Initialized
INFO - 2018-03-22 23:04:13 --> Language Class Initialized
INFO - 2018-03-22 23:04:13 --> Loader Class Initialized
INFO - 2018-03-22 23:04:13 --> Helper loaded: url_helper
INFO - 2018-03-22 23:04:13 --> Helper loaded: form_helper
INFO - 2018-03-22 23:04:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:04:13 --> Form Validation Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
INFO - 2018-03-22 23:04:13 --> Controller Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
INFO - 2018-03-22 23:04:13 --> Model Class Initialized
DEBUG - 2018-03-22 23:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:04:43 --> Config Class Initialized
INFO - 2018-03-22 23:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:04:43 --> Utf8 Class Initialized
INFO - 2018-03-22 23:04:43 --> URI Class Initialized
INFO - 2018-03-22 23:04:43 --> Router Class Initialized
INFO - 2018-03-22 23:04:43 --> Output Class Initialized
INFO - 2018-03-22 23:04:43 --> Security Class Initialized
DEBUG - 2018-03-22 23:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:04:43 --> Input Class Initialized
INFO - 2018-03-22 23:04:43 --> Language Class Initialized
INFO - 2018-03-22 23:04:43 --> Loader Class Initialized
INFO - 2018-03-22 23:04:43 --> Helper loaded: url_helper
INFO - 2018-03-22 23:04:43 --> Helper loaded: form_helper
INFO - 2018-03-22 23:04:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:04:43 --> Form Validation Class Initialized
INFO - 2018-03-22 23:04:43 --> Model Class Initialized
INFO - 2018-03-22 23:04:43 --> Controller Class Initialized
INFO - 2018-03-22 23:04:43 --> Model Class Initialized
INFO - 2018-03-22 23:04:43 --> Model Class Initialized
INFO - 2018-03-22 23:04:43 --> Model Class Initialized
INFO - 2018-03-22 23:04:43 --> Model Class Initialized
DEBUG - 2018-03-22 23:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:04:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:04:43 --> Final output sent to browser
DEBUG - 2018-03-22 23:04:43 --> Total execution time: 0.1002
INFO - 2018-03-22 23:04:44 --> Config Class Initialized
INFO - 2018-03-22 23:04:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:04:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:04:44 --> Utf8 Class Initialized
INFO - 2018-03-22 23:04:44 --> URI Class Initialized
INFO - 2018-03-22 23:04:44 --> Router Class Initialized
INFO - 2018-03-22 23:04:44 --> Output Class Initialized
INFO - 2018-03-22 23:04:44 --> Security Class Initialized
DEBUG - 2018-03-22 23:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:04:44 --> Input Class Initialized
INFO - 2018-03-22 23:04:44 --> Language Class Initialized
INFO - 2018-03-22 23:04:44 --> Loader Class Initialized
INFO - 2018-03-22 23:04:44 --> Helper loaded: url_helper
INFO - 2018-03-22 23:04:44 --> Helper loaded: form_helper
INFO - 2018-03-22 23:04:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:04:44 --> Form Validation Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
INFO - 2018-03-22 23:04:44 --> Controller Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
INFO - 2018-03-22 23:04:44 --> Model Class Initialized
DEBUG - 2018-03-22 23:04:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:04:47 --> Config Class Initialized
INFO - 2018-03-22 23:04:47 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:04:47 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:04:47 --> Utf8 Class Initialized
INFO - 2018-03-22 23:04:47 --> URI Class Initialized
INFO - 2018-03-22 23:04:47 --> Router Class Initialized
INFO - 2018-03-22 23:04:47 --> Output Class Initialized
INFO - 2018-03-22 23:04:47 --> Security Class Initialized
DEBUG - 2018-03-22 23:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:04:47 --> Input Class Initialized
INFO - 2018-03-22 23:04:47 --> Language Class Initialized
ERROR - 2018-03-22 23:04:47 --> 404 Page Not Found: Proyectos/horas-por-proyecto
INFO - 2018-03-22 23:05:14 --> Config Class Initialized
INFO - 2018-03-22 23:05:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:14 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:14 --> URI Class Initialized
INFO - 2018-03-22 23:05:14 --> Router Class Initialized
INFO - 2018-03-22 23:05:14 --> Output Class Initialized
INFO - 2018-03-22 23:05:14 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:14 --> Input Class Initialized
INFO - 2018-03-22 23:05:14 --> Language Class Initialized
INFO - 2018-03-22 23:05:14 --> Loader Class Initialized
INFO - 2018-03-22 23:05:14 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:14 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:14 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Controller Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:05:14 --> Final output sent to browser
DEBUG - 2018-03-22 23:05:14 --> Total execution time: 0.0574
INFO - 2018-03-22 23:05:14 --> Config Class Initialized
INFO - 2018-03-22 23:05:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:14 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:14 --> URI Class Initialized
INFO - 2018-03-22 23:05:14 --> Router Class Initialized
INFO - 2018-03-22 23:05:14 --> Output Class Initialized
INFO - 2018-03-22 23:05:14 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:14 --> Input Class Initialized
INFO - 2018-03-22 23:05:14 --> Language Class Initialized
INFO - 2018-03-22 23:05:14 --> Loader Class Initialized
INFO - 2018-03-22 23:05:14 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:14 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:14 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Controller Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
INFO - 2018-03-22 23:05:14 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:31 --> Config Class Initialized
INFO - 2018-03-22 23:05:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:31 --> URI Class Initialized
INFO - 2018-03-22 23:05:31 --> Router Class Initialized
INFO - 2018-03-22 23:05:31 --> Output Class Initialized
INFO - 2018-03-22 23:05:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:31 --> Input Class Initialized
INFO - 2018-03-22 23:05:31 --> Language Class Initialized
INFO - 2018-03-22 23:05:31 --> Loader Class Initialized
INFO - 2018-03-22 23:05:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Controller Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:05:31 --> Final output sent to browser
DEBUG - 2018-03-22 23:05:31 --> Total execution time: 0.0967
INFO - 2018-03-22 23:05:31 --> Config Class Initialized
INFO - 2018-03-22 23:05:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:31 --> URI Class Initialized
INFO - 2018-03-22 23:05:31 --> Router Class Initialized
INFO - 2018-03-22 23:05:31 --> Output Class Initialized
INFO - 2018-03-22 23:05:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:31 --> Input Class Initialized
INFO - 2018-03-22 23:05:31 --> Language Class Initialized
INFO - 2018-03-22 23:05:31 --> Loader Class Initialized
INFO - 2018-03-22 23:05:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Controller Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
INFO - 2018-03-22 23:05:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:32 --> Config Class Initialized
INFO - 2018-03-22 23:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:32 --> URI Class Initialized
INFO - 2018-03-22 23:05:32 --> Router Class Initialized
INFO - 2018-03-22 23:05:32 --> Output Class Initialized
INFO - 2018-03-22 23:05:32 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:32 --> Input Class Initialized
INFO - 2018-03-22 23:05:32 --> Language Class Initialized
INFO - 2018-03-22 23:05:32 --> Loader Class Initialized
INFO - 2018-03-22 23:05:32 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:32 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:32 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:32 --> Model Class Initialized
INFO - 2018-03-22 23:05:32 --> Controller Class Initialized
INFO - 2018-03-22 23:05:32 --> Model Class Initialized
INFO - 2018-03-22 23:05:32 --> Model Class Initialized
INFO - 2018-03-22 23:05:32 --> Model Class Initialized
INFO - 2018-03-22 23:05:32 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:05:32 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:05:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:05:32 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
ERROR - 2018-03-22 23:05:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
INFO - 2018-03-22 23:05:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:05:32 --> Final output sent to browser
DEBUG - 2018-03-22 23:05:32 --> Total execution time: 0.3910
INFO - 2018-03-22 23:05:46 --> Config Class Initialized
INFO - 2018-03-22 23:05:46 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:46 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:46 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:46 --> URI Class Initialized
INFO - 2018-03-22 23:05:46 --> Router Class Initialized
INFO - 2018-03-22 23:05:46 --> Output Class Initialized
INFO - 2018-03-22 23:05:46 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:46 --> Input Class Initialized
INFO - 2018-03-22 23:05:46 --> Language Class Initialized
INFO - 2018-03-22 23:05:46 --> Loader Class Initialized
INFO - 2018-03-22 23:05:46 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:46 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:46 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:46 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Controller Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:05:46 --> Final output sent to browser
DEBUG - 2018-03-22 23:05:46 --> Total execution time: 0.0552
INFO - 2018-03-22 23:05:46 --> Config Class Initialized
INFO - 2018-03-22 23:05:46 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:46 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:46 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:46 --> URI Class Initialized
INFO - 2018-03-22 23:05:46 --> Router Class Initialized
INFO - 2018-03-22 23:05:46 --> Output Class Initialized
INFO - 2018-03-22 23:05:46 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:46 --> Input Class Initialized
INFO - 2018-03-22 23:05:46 --> Language Class Initialized
INFO - 2018-03-22 23:05:46 --> Loader Class Initialized
INFO - 2018-03-22 23:05:46 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:46 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:46 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:46 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Controller Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
INFO - 2018-03-22 23:05:46 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:05:59 --> Config Class Initialized
INFO - 2018-03-22 23:05:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:05:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:05:59 --> Utf8 Class Initialized
INFO - 2018-03-22 23:05:59 --> URI Class Initialized
INFO - 2018-03-22 23:05:59 --> Router Class Initialized
INFO - 2018-03-22 23:05:59 --> Output Class Initialized
INFO - 2018-03-22 23:05:59 --> Security Class Initialized
DEBUG - 2018-03-22 23:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:05:59 --> Input Class Initialized
INFO - 2018-03-22 23:05:59 --> Language Class Initialized
INFO - 2018-03-22 23:05:59 --> Loader Class Initialized
INFO - 2018-03-22 23:05:59 --> Helper loaded: url_helper
INFO - 2018-03-22 23:05:59 --> Helper loaded: form_helper
INFO - 2018-03-22 23:05:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:05:59 --> Form Validation Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
INFO - 2018-03-22 23:05:59 --> Controller Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
INFO - 2018-03-22 23:05:59 --> Model Class Initialized
DEBUG - 2018-03-22 23:05:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:00 --> Config Class Initialized
INFO - 2018-03-22 23:06:00 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:00 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:00 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:00 --> URI Class Initialized
INFO - 2018-03-22 23:06:00 --> Router Class Initialized
INFO - 2018-03-22 23:06:00 --> Output Class Initialized
INFO - 2018-03-22 23:06:00 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:00 --> Input Class Initialized
INFO - 2018-03-22 23:06:00 --> Language Class Initialized
INFO - 2018-03-22 23:06:00 --> Loader Class Initialized
INFO - 2018-03-22 23:06:00 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:00 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:00 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:00 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
INFO - 2018-03-22 23:06:00 --> Controller Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
INFO - 2018-03-22 23:06:00 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:06 --> Config Class Initialized
INFO - 2018-03-22 23:06:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:06 --> URI Class Initialized
INFO - 2018-03-22 23:06:06 --> Router Class Initialized
INFO - 2018-03-22 23:06:06 --> Output Class Initialized
INFO - 2018-03-22 23:06:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:06 --> Input Class Initialized
INFO - 2018-03-22 23:06:06 --> Language Class Initialized
INFO - 2018-03-22 23:06:06 --> Loader Class Initialized
INFO - 2018-03-22 23:06:06 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:06 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:06 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
INFO - 2018-03-22 23:06:06 --> Controller Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
INFO - 2018-03-22 23:06:06 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:14 --> Config Class Initialized
INFO - 2018-03-22 23:06:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:14 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:14 --> URI Class Initialized
INFO - 2018-03-22 23:06:14 --> Router Class Initialized
INFO - 2018-03-22 23:06:14 --> Output Class Initialized
INFO - 2018-03-22 23:06:14 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:14 --> Input Class Initialized
INFO - 2018-03-22 23:06:14 --> Language Class Initialized
INFO - 2018-03-22 23:06:14 --> Loader Class Initialized
INFO - 2018-03-22 23:06:14 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:14 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:14 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
INFO - 2018-03-22 23:06:14 --> Controller Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
INFO - 2018-03-22 23:06:14 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:18 --> Config Class Initialized
INFO - 2018-03-22 23:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:18 --> URI Class Initialized
INFO - 2018-03-22 23:06:18 --> Router Class Initialized
INFO - 2018-03-22 23:06:18 --> Output Class Initialized
INFO - 2018-03-22 23:06:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:18 --> Input Class Initialized
INFO - 2018-03-22 23:06:18 --> Language Class Initialized
INFO - 2018-03-22 23:06:18 --> Loader Class Initialized
INFO - 2018-03-22 23:06:18 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:18 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:18 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
INFO - 2018-03-22 23:06:18 --> Controller Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
INFO - 2018-03-22 23:06:18 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:21 --> Config Class Initialized
INFO - 2018-03-22 23:06:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:21 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:21 --> URI Class Initialized
INFO - 2018-03-22 23:06:21 --> Router Class Initialized
INFO - 2018-03-22 23:06:21 --> Output Class Initialized
INFO - 2018-03-22 23:06:21 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:21 --> Input Class Initialized
INFO - 2018-03-22 23:06:21 --> Language Class Initialized
INFO - 2018-03-22 23:06:21 --> Loader Class Initialized
INFO - 2018-03-22 23:06:21 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:21 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:21 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
INFO - 2018-03-22 23:06:21 --> Controller Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
INFO - 2018-03-22 23:06:21 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:24 --> Config Class Initialized
INFO - 2018-03-22 23:06:24 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:24 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:24 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:24 --> URI Class Initialized
INFO - 2018-03-22 23:06:24 --> Router Class Initialized
INFO - 2018-03-22 23:06:24 --> Output Class Initialized
INFO - 2018-03-22 23:06:24 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:24 --> Input Class Initialized
INFO - 2018-03-22 23:06:24 --> Language Class Initialized
INFO - 2018-03-22 23:06:24 --> Loader Class Initialized
INFO - 2018-03-22 23:06:24 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:24 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:24 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:24 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
INFO - 2018-03-22 23:06:24 --> Controller Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
INFO - 2018-03-22 23:06:24 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:26 --> Config Class Initialized
INFO - 2018-03-22 23:06:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:26 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:26 --> URI Class Initialized
INFO - 2018-03-22 23:06:26 --> Router Class Initialized
INFO - 2018-03-22 23:06:26 --> Output Class Initialized
INFO - 2018-03-22 23:06:26 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:26 --> Input Class Initialized
INFO - 2018-03-22 23:06:26 --> Language Class Initialized
INFO - 2018-03-22 23:06:26 --> Loader Class Initialized
INFO - 2018-03-22 23:06:26 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:26 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:26 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:26 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
INFO - 2018-03-22 23:06:26 --> Controller Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
INFO - 2018-03-22 23:06:26 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:28 --> Config Class Initialized
INFO - 2018-03-22 23:06:28 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:28 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:28 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:28 --> URI Class Initialized
INFO - 2018-03-22 23:06:28 --> Router Class Initialized
INFO - 2018-03-22 23:06:28 --> Output Class Initialized
INFO - 2018-03-22 23:06:28 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:28 --> Input Class Initialized
INFO - 2018-03-22 23:06:28 --> Language Class Initialized
INFO - 2018-03-22 23:06:28 --> Loader Class Initialized
INFO - 2018-03-22 23:06:28 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:28 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:28 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:28 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
INFO - 2018-03-22 23:06:28 --> Controller Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
INFO - 2018-03-22 23:06:28 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:29 --> Config Class Initialized
INFO - 2018-03-22 23:06:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:29 --> URI Class Initialized
INFO - 2018-03-22 23:06:29 --> Router Class Initialized
INFO - 2018-03-22 23:06:29 --> Output Class Initialized
INFO - 2018-03-22 23:06:29 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:29 --> Input Class Initialized
INFO - 2018-03-22 23:06:29 --> Language Class Initialized
INFO - 2018-03-22 23:06:29 --> Loader Class Initialized
INFO - 2018-03-22 23:06:29 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:29 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:29 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Controller Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:29 --> Config Class Initialized
INFO - 2018-03-22 23:06:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:29 --> URI Class Initialized
INFO - 2018-03-22 23:06:29 --> Router Class Initialized
INFO - 2018-03-22 23:06:29 --> Output Class Initialized
INFO - 2018-03-22 23:06:29 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:29 --> Input Class Initialized
INFO - 2018-03-22 23:06:29 --> Language Class Initialized
INFO - 2018-03-22 23:06:29 --> Loader Class Initialized
INFO - 2018-03-22 23:06:29 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:29 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:29 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Controller Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
INFO - 2018-03-22 23:06:29 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:30 --> Config Class Initialized
INFO - 2018-03-22 23:06:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:30 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:30 --> URI Class Initialized
INFO - 2018-03-22 23:06:30 --> Router Class Initialized
INFO - 2018-03-22 23:06:30 --> Output Class Initialized
INFO - 2018-03-22 23:06:30 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:30 --> Input Class Initialized
INFO - 2018-03-22 23:06:30 --> Language Class Initialized
INFO - 2018-03-22 23:06:30 --> Loader Class Initialized
INFO - 2018-03-22 23:06:30 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:30 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:30 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
INFO - 2018-03-22 23:06:30 --> Controller Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
INFO - 2018-03-22 23:06:30 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:31 --> Config Class Initialized
INFO - 2018-03-22 23:06:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:31 --> URI Class Initialized
INFO - 2018-03-22 23:06:31 --> Router Class Initialized
INFO - 2018-03-22 23:06:31 --> Output Class Initialized
INFO - 2018-03-22 23:06:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:31 --> Input Class Initialized
INFO - 2018-03-22 23:06:31 --> Language Class Initialized
INFO - 2018-03-22 23:06:31 --> Loader Class Initialized
INFO - 2018-03-22 23:06:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
INFO - 2018-03-22 23:06:31 --> Controller Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
INFO - 2018-03-22 23:06:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:32 --> Config Class Initialized
INFO - 2018-03-22 23:06:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:32 --> URI Class Initialized
INFO - 2018-03-22 23:06:32 --> Router Class Initialized
INFO - 2018-03-22 23:06:32 --> Output Class Initialized
INFO - 2018-03-22 23:06:32 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:32 --> Input Class Initialized
INFO - 2018-03-22 23:06:32 --> Language Class Initialized
INFO - 2018-03-22 23:06:32 --> Loader Class Initialized
INFO - 2018-03-22 23:06:32 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:32 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:32 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
INFO - 2018-03-22 23:06:32 --> Controller Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
INFO - 2018-03-22 23:06:32 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:33 --> Config Class Initialized
INFO - 2018-03-22 23:06:33 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:33 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:33 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:33 --> URI Class Initialized
INFO - 2018-03-22 23:06:33 --> Router Class Initialized
INFO - 2018-03-22 23:06:33 --> Output Class Initialized
INFO - 2018-03-22 23:06:33 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:33 --> Input Class Initialized
INFO - 2018-03-22 23:06:33 --> Language Class Initialized
INFO - 2018-03-22 23:06:33 --> Loader Class Initialized
INFO - 2018-03-22 23:06:33 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:33 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:33 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:33 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
INFO - 2018-03-22 23:06:33 --> Controller Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
INFO - 2018-03-22 23:06:33 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:34 --> Config Class Initialized
INFO - 2018-03-22 23:06:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:34 --> URI Class Initialized
INFO - 2018-03-22 23:06:34 --> Router Class Initialized
INFO - 2018-03-22 23:06:34 --> Output Class Initialized
INFO - 2018-03-22 23:06:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:34 --> Input Class Initialized
INFO - 2018-03-22 23:06:34 --> Language Class Initialized
INFO - 2018-03-22 23:06:34 --> Loader Class Initialized
INFO - 2018-03-22 23:06:34 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:34 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:34 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Controller Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:34 --> Config Class Initialized
INFO - 2018-03-22 23:06:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:34 --> URI Class Initialized
INFO - 2018-03-22 23:06:34 --> Router Class Initialized
INFO - 2018-03-22 23:06:34 --> Output Class Initialized
INFO - 2018-03-22 23:06:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:34 --> Input Class Initialized
INFO - 2018-03-22 23:06:34 --> Language Class Initialized
INFO - 2018-03-22 23:06:34 --> Loader Class Initialized
INFO - 2018-03-22 23:06:34 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:34 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:34 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Controller Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
INFO - 2018-03-22 23:06:34 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:35 --> Config Class Initialized
INFO - 2018-03-22 23:06:35 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:35 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:35 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:35 --> URI Class Initialized
INFO - 2018-03-22 23:06:35 --> Router Class Initialized
INFO - 2018-03-22 23:06:35 --> Output Class Initialized
INFO - 2018-03-22 23:06:35 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:35 --> Input Class Initialized
INFO - 2018-03-22 23:06:35 --> Language Class Initialized
INFO - 2018-03-22 23:06:35 --> Loader Class Initialized
INFO - 2018-03-22 23:06:35 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:35 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:35 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:35 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
INFO - 2018-03-22 23:06:35 --> Controller Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
INFO - 2018-03-22 23:06:35 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:37 --> Config Class Initialized
INFO - 2018-03-22 23:06:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:37 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:37 --> URI Class Initialized
INFO - 2018-03-22 23:06:37 --> Router Class Initialized
INFO - 2018-03-22 23:06:37 --> Output Class Initialized
INFO - 2018-03-22 23:06:37 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:37 --> Input Class Initialized
INFO - 2018-03-22 23:06:37 --> Language Class Initialized
INFO - 2018-03-22 23:06:37 --> Loader Class Initialized
INFO - 2018-03-22 23:06:37 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:37 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:37 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
INFO - 2018-03-22 23:06:37 --> Controller Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
INFO - 2018-03-22 23:06:37 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:39 --> Config Class Initialized
INFO - 2018-03-22 23:06:39 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:39 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:39 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:39 --> URI Class Initialized
INFO - 2018-03-22 23:06:39 --> Router Class Initialized
INFO - 2018-03-22 23:06:39 --> Output Class Initialized
INFO - 2018-03-22 23:06:39 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:39 --> Input Class Initialized
INFO - 2018-03-22 23:06:39 --> Language Class Initialized
INFO - 2018-03-22 23:06:39 --> Loader Class Initialized
INFO - 2018-03-22 23:06:39 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:39 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:39 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:39 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
INFO - 2018-03-22 23:06:39 --> Controller Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
INFO - 2018-03-22 23:06:39 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:40 --> Config Class Initialized
INFO - 2018-03-22 23:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:40 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:40 --> URI Class Initialized
INFO - 2018-03-22 23:06:40 --> Router Class Initialized
INFO - 2018-03-22 23:06:40 --> Output Class Initialized
INFO - 2018-03-22 23:06:40 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:40 --> Input Class Initialized
INFO - 2018-03-22 23:06:40 --> Language Class Initialized
INFO - 2018-03-22 23:06:40 --> Loader Class Initialized
INFO - 2018-03-22 23:06:40 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:40 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:40 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:40 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
INFO - 2018-03-22 23:06:40 --> Controller Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
INFO - 2018-03-22 23:06:40 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:44 --> Config Class Initialized
INFO - 2018-03-22 23:06:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:44 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:44 --> URI Class Initialized
INFO - 2018-03-22 23:06:44 --> Router Class Initialized
INFO - 2018-03-22 23:06:44 --> Output Class Initialized
INFO - 2018-03-22 23:06:44 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:44 --> Input Class Initialized
INFO - 2018-03-22 23:06:44 --> Language Class Initialized
INFO - 2018-03-22 23:06:44 --> Loader Class Initialized
INFO - 2018-03-22 23:06:44 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:44 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:44 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
INFO - 2018-03-22 23:06:44 --> Controller Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
INFO - 2018-03-22 23:06:44 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:46 --> Config Class Initialized
INFO - 2018-03-22 23:06:46 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:46 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:46 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:46 --> URI Class Initialized
INFO - 2018-03-22 23:06:46 --> Router Class Initialized
INFO - 2018-03-22 23:06:46 --> Output Class Initialized
INFO - 2018-03-22 23:06:46 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:46 --> Input Class Initialized
INFO - 2018-03-22 23:06:46 --> Language Class Initialized
INFO - 2018-03-22 23:06:46 --> Loader Class Initialized
INFO - 2018-03-22 23:06:46 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:46 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:46 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:46 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
INFO - 2018-03-22 23:06:46 --> Controller Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
INFO - 2018-03-22 23:06:46 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:06:48 --> Config Class Initialized
INFO - 2018-03-22 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:06:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:06:48 --> URI Class Initialized
INFO - 2018-03-22 23:06:48 --> Router Class Initialized
INFO - 2018-03-22 23:06:48 --> Output Class Initialized
INFO - 2018-03-22 23:06:48 --> Security Class Initialized
DEBUG - 2018-03-22 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:06:48 --> Input Class Initialized
INFO - 2018-03-22 23:06:48 --> Language Class Initialized
INFO - 2018-03-22 23:06:48 --> Loader Class Initialized
INFO - 2018-03-22 23:06:48 --> Helper loaded: url_helper
INFO - 2018-03-22 23:06:48 --> Helper loaded: form_helper
INFO - 2018-03-22 23:06:48 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:06:48 --> Form Validation Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
INFO - 2018-03-22 23:06:48 --> Controller Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
INFO - 2018-03-22 23:06:48 --> Model Class Initialized
DEBUG - 2018-03-22 23:06:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:07:02 --> Config Class Initialized
INFO - 2018-03-22 23:07:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:07:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:07:02 --> Utf8 Class Initialized
INFO - 2018-03-22 23:07:02 --> URI Class Initialized
INFO - 2018-03-22 23:07:02 --> Router Class Initialized
INFO - 2018-03-22 23:07:02 --> Output Class Initialized
INFO - 2018-03-22 23:07:02 --> Security Class Initialized
DEBUG - 2018-03-22 23:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:07:02 --> Input Class Initialized
INFO - 2018-03-22 23:07:02 --> Language Class Initialized
INFO - 2018-03-22 23:07:02 --> Loader Class Initialized
INFO - 2018-03-22 23:07:02 --> Helper loaded: url_helper
INFO - 2018-03-22 23:07:02 --> Helper loaded: form_helper
INFO - 2018-03-22 23:07:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:07:02 --> Form Validation Class Initialized
INFO - 2018-03-22 23:07:02 --> Model Class Initialized
INFO - 2018-03-22 23:07:02 --> Controller Class Initialized
INFO - 2018-03-22 23:07:02 --> Model Class Initialized
INFO - 2018-03-22 23:07:02 --> Model Class Initialized
INFO - 2018-03-22 23:07:02 --> Model Class Initialized
INFO - 2018-03-22 23:07:02 --> Model Class Initialized
DEBUG - 2018-03-22 23:07:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:07:02 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:07:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:07:02 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
ERROR - 2018-03-22 23:07:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
INFO - 2018-03-22 23:07:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:07:02 --> Final output sent to browser
DEBUG - 2018-03-22 23:07:02 --> Total execution time: 0.0759
INFO - 2018-03-22 23:07:18 --> Config Class Initialized
INFO - 2018-03-22 23:07:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:07:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:07:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:07:18 --> URI Class Initialized
INFO - 2018-03-22 23:07:18 --> Router Class Initialized
INFO - 2018-03-22 23:07:18 --> Output Class Initialized
INFO - 2018-03-22 23:07:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:07:18 --> Input Class Initialized
INFO - 2018-03-22 23:07:18 --> Language Class Initialized
INFO - 2018-03-22 23:07:18 --> Loader Class Initialized
INFO - 2018-03-22 23:07:18 --> Helper loaded: url_helper
INFO - 2018-03-22 23:07:18 --> Helper loaded: form_helper
INFO - 2018-03-22 23:07:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:07:18 --> Form Validation Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Controller Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:07:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:07:18 --> Final output sent to browser
DEBUG - 2018-03-22 23:07:18 --> Total execution time: 0.0936
INFO - 2018-03-22 23:07:18 --> Config Class Initialized
INFO - 2018-03-22 23:07:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:07:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:07:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:07:18 --> URI Class Initialized
INFO - 2018-03-22 23:07:18 --> Router Class Initialized
INFO - 2018-03-22 23:07:18 --> Output Class Initialized
INFO - 2018-03-22 23:07:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:07:18 --> Input Class Initialized
INFO - 2018-03-22 23:07:18 --> Language Class Initialized
INFO - 2018-03-22 23:07:18 --> Loader Class Initialized
INFO - 2018-03-22 23:07:18 --> Helper loaded: url_helper
INFO - 2018-03-22 23:07:18 --> Helper loaded: form_helper
INFO - 2018-03-22 23:07:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:07:18 --> Form Validation Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Controller Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
INFO - 2018-03-22 23:07:18 --> Model Class Initialized
DEBUG - 2018-03-22 23:07:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:07:19 --> Config Class Initialized
INFO - 2018-03-22 23:07:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:07:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:07:19 --> Utf8 Class Initialized
INFO - 2018-03-22 23:07:19 --> URI Class Initialized
INFO - 2018-03-22 23:07:19 --> Router Class Initialized
INFO - 2018-03-22 23:07:19 --> Output Class Initialized
INFO - 2018-03-22 23:07:19 --> Security Class Initialized
DEBUG - 2018-03-22 23:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:07:19 --> Input Class Initialized
INFO - 2018-03-22 23:07:19 --> Language Class Initialized
INFO - 2018-03-22 23:07:19 --> Loader Class Initialized
INFO - 2018-03-22 23:07:19 --> Helper loaded: url_helper
INFO - 2018-03-22 23:07:19 --> Helper loaded: form_helper
INFO - 2018-03-22 23:07:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:07:19 --> Form Validation Class Initialized
INFO - 2018-03-22 23:07:19 --> Model Class Initialized
INFO - 2018-03-22 23:07:19 --> Controller Class Initialized
INFO - 2018-03-22 23:07:19 --> Model Class Initialized
INFO - 2018-03-22 23:07:19 --> Model Class Initialized
INFO - 2018-03-22 23:07:19 --> Model Class Initialized
INFO - 2018-03-22 23:07:19 --> Model Class Initialized
DEBUG - 2018-03-22 23:07:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:07:19 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:07:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:07:19 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
ERROR - 2018-03-22 23:07:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 68
INFO - 2018-03-22 23:07:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:07:19 --> Final output sent to browser
DEBUG - 2018-03-22 23:07:19 --> Total execution time: 0.0916
INFO - 2018-03-22 23:08:29 --> Config Class Initialized
INFO - 2018-03-22 23:08:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:08:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:08:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:08:29 --> URI Class Initialized
INFO - 2018-03-22 23:08:29 --> Router Class Initialized
INFO - 2018-03-22 23:08:29 --> Output Class Initialized
INFO - 2018-03-22 23:08:29 --> Security Class Initialized
DEBUG - 2018-03-22 23:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:08:29 --> Input Class Initialized
INFO - 2018-03-22 23:08:29 --> Language Class Initialized
INFO - 2018-03-22 23:08:29 --> Loader Class Initialized
INFO - 2018-03-22 23:08:29 --> Helper loaded: url_helper
INFO - 2018-03-22 23:08:29 --> Helper loaded: form_helper
INFO - 2018-03-22 23:08:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:08:29 --> Form Validation Class Initialized
INFO - 2018-03-22 23:08:29 --> Model Class Initialized
INFO - 2018-03-22 23:08:29 --> Controller Class Initialized
INFO - 2018-03-22 23:08:29 --> Model Class Initialized
INFO - 2018-03-22 23:08:29 --> Model Class Initialized
INFO - 2018-03-22 23:08:29 --> Model Class Initialized
INFO - 2018-03-22 23:08:29 --> Model Class Initialized
DEBUG - 2018-03-22 23:08:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:08:29 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:08:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:08:29 --> Final output sent to browser
DEBUG - 2018-03-22 23:08:29 --> Total execution time: 0.1317
INFO - 2018-03-22 23:08:31 --> Config Class Initialized
INFO - 2018-03-22 23:08:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:08:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:08:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:08:31 --> URI Class Initialized
INFO - 2018-03-22 23:08:31 --> Router Class Initialized
INFO - 2018-03-22 23:08:31 --> Output Class Initialized
INFO - 2018-03-22 23:08:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:08:31 --> Input Class Initialized
INFO - 2018-03-22 23:08:31 --> Language Class Initialized
INFO - 2018-03-22 23:08:31 --> Loader Class Initialized
INFO - 2018-03-22 23:08:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:08:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:08:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:08:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:08:31 --> Model Class Initialized
INFO - 2018-03-22 23:08:31 --> Controller Class Initialized
INFO - 2018-03-22 23:08:31 --> Model Class Initialized
INFO - 2018-03-22 23:08:31 --> Model Class Initialized
INFO - 2018-03-22 23:08:31 --> Model Class Initialized
INFO - 2018-03-22 23:08:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:08:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:08:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:08:31 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:08:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:08:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:08:31 --> Final output sent to browser
DEBUG - 2018-03-22 23:08:31 --> Total execution time: 0.1151
INFO - 2018-03-22 23:09:05 --> Config Class Initialized
INFO - 2018-03-22 23:09:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:09:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:09:05 --> Utf8 Class Initialized
INFO - 2018-03-22 23:09:05 --> URI Class Initialized
INFO - 2018-03-22 23:09:05 --> Router Class Initialized
INFO - 2018-03-22 23:09:05 --> Output Class Initialized
INFO - 2018-03-22 23:09:05 --> Security Class Initialized
DEBUG - 2018-03-22 23:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:09:05 --> Input Class Initialized
INFO - 2018-03-22 23:09:05 --> Language Class Initialized
INFO - 2018-03-22 23:09:05 --> Loader Class Initialized
INFO - 2018-03-22 23:09:05 --> Helper loaded: url_helper
INFO - 2018-03-22 23:09:05 --> Helper loaded: form_helper
INFO - 2018-03-22 23:09:05 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:09:05 --> Form Validation Class Initialized
INFO - 2018-03-22 23:09:05 --> Model Class Initialized
INFO - 2018-03-22 23:09:05 --> Controller Class Initialized
INFO - 2018-03-22 23:09:05 --> Model Class Initialized
INFO - 2018-03-22 23:09:05 --> Model Class Initialized
INFO - 2018-03-22 23:09:05 --> Model Class Initialized
INFO - 2018-03-22 23:09:05 --> Model Class Initialized
DEBUG - 2018-03-22 23:09:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:09:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:09:05 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:09:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:09:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:09:05 --> Final output sent to browser
DEBUG - 2018-03-22 23:09:05 --> Total execution time: 0.0980
INFO - 2018-03-22 23:09:07 --> Config Class Initialized
INFO - 2018-03-22 23:09:07 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:09:07 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:09:07 --> Utf8 Class Initialized
INFO - 2018-03-22 23:09:07 --> URI Class Initialized
INFO - 2018-03-22 23:09:07 --> Router Class Initialized
INFO - 2018-03-22 23:09:07 --> Output Class Initialized
INFO - 2018-03-22 23:09:07 --> Security Class Initialized
DEBUG - 2018-03-22 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:09:07 --> Input Class Initialized
INFO - 2018-03-22 23:09:07 --> Language Class Initialized
INFO - 2018-03-22 23:09:07 --> Loader Class Initialized
INFO - 2018-03-22 23:09:07 --> Helper loaded: url_helper
INFO - 2018-03-22 23:09:07 --> Helper loaded: form_helper
INFO - 2018-03-22 23:09:07 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:09:07 --> Form Validation Class Initialized
INFO - 2018-03-22 23:09:07 --> Model Class Initialized
INFO - 2018-03-22 23:09:07 --> Controller Class Initialized
INFO - 2018-03-22 23:09:07 --> Model Class Initialized
INFO - 2018-03-22 23:09:07 --> Model Class Initialized
INFO - 2018-03-22 23:09:07 --> Model Class Initialized
INFO - 2018-03-22 23:09:07 --> Model Class Initialized
DEBUG - 2018-03-22 23:09:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:09:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:09:07 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:09:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:09:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:09:07 --> Final output sent to browser
DEBUG - 2018-03-22 23:09:07 --> Total execution time: 0.1033
INFO - 2018-03-22 23:09:23 --> Config Class Initialized
INFO - 2018-03-22 23:09:23 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:09:23 --> Utf8 Class Initialized
INFO - 2018-03-22 23:09:23 --> URI Class Initialized
INFO - 2018-03-22 23:09:23 --> Router Class Initialized
INFO - 2018-03-22 23:09:23 --> Output Class Initialized
INFO - 2018-03-22 23:09:23 --> Security Class Initialized
DEBUG - 2018-03-22 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:09:23 --> Input Class Initialized
INFO - 2018-03-22 23:09:23 --> Language Class Initialized
INFO - 2018-03-22 23:09:23 --> Loader Class Initialized
INFO - 2018-03-22 23:09:23 --> Helper loaded: url_helper
INFO - 2018-03-22 23:09:23 --> Helper loaded: form_helper
INFO - 2018-03-22 23:09:23 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:09:23 --> Form Validation Class Initialized
INFO - 2018-03-22 23:09:23 --> Model Class Initialized
INFO - 2018-03-22 23:09:23 --> Controller Class Initialized
INFO - 2018-03-22 23:09:23 --> Model Class Initialized
INFO - 2018-03-22 23:09:23 --> Model Class Initialized
INFO - 2018-03-22 23:09:23 --> Model Class Initialized
INFO - 2018-03-22 23:09:23 --> Model Class Initialized
DEBUG - 2018-03-22 23:09:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:09:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:09:23 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:09:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:09:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:09:23 --> Final output sent to browser
DEBUG - 2018-03-22 23:09:23 --> Total execution time: 0.0885
INFO - 2018-03-22 23:12:10 --> Config Class Initialized
INFO - 2018-03-22 23:12:10 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:12:10 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:12:10 --> Utf8 Class Initialized
INFO - 2018-03-22 23:12:10 --> URI Class Initialized
INFO - 2018-03-22 23:12:10 --> Router Class Initialized
INFO - 2018-03-22 23:12:10 --> Output Class Initialized
INFO - 2018-03-22 23:12:10 --> Security Class Initialized
DEBUG - 2018-03-22 23:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:12:10 --> Input Class Initialized
INFO - 2018-03-22 23:12:10 --> Language Class Initialized
INFO - 2018-03-22 23:12:10 --> Loader Class Initialized
INFO - 2018-03-22 23:12:10 --> Helper loaded: url_helper
INFO - 2018-03-22 23:12:10 --> Helper loaded: form_helper
INFO - 2018-03-22 23:12:10 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:12:10 --> Form Validation Class Initialized
INFO - 2018-03-22 23:12:10 --> Model Class Initialized
INFO - 2018-03-22 23:12:10 --> Controller Class Initialized
INFO - 2018-03-22 23:12:10 --> Model Class Initialized
INFO - 2018-03-22 23:12:10 --> Model Class Initialized
INFO - 2018-03-22 23:12:10 --> Model Class Initialized
INFO - 2018-03-22 23:12:10 --> Model Class Initialized
DEBUG - 2018-03-22 23:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:12:26 --> Config Class Initialized
INFO - 2018-03-22 23:12:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:12:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:12:26 --> Utf8 Class Initialized
INFO - 2018-03-22 23:12:26 --> URI Class Initialized
INFO - 2018-03-22 23:12:26 --> Router Class Initialized
INFO - 2018-03-22 23:12:26 --> Output Class Initialized
INFO - 2018-03-22 23:12:26 --> Security Class Initialized
DEBUG - 2018-03-22 23:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:12:26 --> Input Class Initialized
INFO - 2018-03-22 23:12:26 --> Language Class Initialized
INFO - 2018-03-22 23:12:26 --> Loader Class Initialized
INFO - 2018-03-22 23:12:26 --> Helper loaded: url_helper
INFO - 2018-03-22 23:12:26 --> Helper loaded: form_helper
INFO - 2018-03-22 23:12:26 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:12:26 --> Form Validation Class Initialized
INFO - 2018-03-22 23:12:26 --> Model Class Initialized
INFO - 2018-03-22 23:12:26 --> Controller Class Initialized
INFO - 2018-03-22 23:12:26 --> Model Class Initialized
INFO - 2018-03-22 23:12:26 --> Model Class Initialized
INFO - 2018-03-22 23:12:26 --> Model Class Initialized
INFO - 2018-03-22 23:12:26 --> Model Class Initialized
DEBUG - 2018-03-22 23:12:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:15:53 --> Config Class Initialized
INFO - 2018-03-22 23:15:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:15:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:15:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:15:53 --> URI Class Initialized
INFO - 2018-03-22 23:15:53 --> Router Class Initialized
INFO - 2018-03-22 23:15:53 --> Output Class Initialized
INFO - 2018-03-22 23:15:53 --> Security Class Initialized
DEBUG - 2018-03-22 23:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:15:53 --> Input Class Initialized
INFO - 2018-03-22 23:15:53 --> Language Class Initialized
INFO - 2018-03-22 23:15:53 --> Loader Class Initialized
INFO - 2018-03-22 23:15:53 --> Helper loaded: url_helper
INFO - 2018-03-22 23:15:53 --> Helper loaded: form_helper
INFO - 2018-03-22 23:15:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:15:53 --> Form Validation Class Initialized
INFO - 2018-03-22 23:15:53 --> Model Class Initialized
INFO - 2018-03-22 23:15:53 --> Controller Class Initialized
INFO - 2018-03-22 23:15:53 --> Model Class Initialized
INFO - 2018-03-22 23:15:53 --> Model Class Initialized
INFO - 2018-03-22 23:15:53 --> Model Class Initialized
INFO - 2018-03-22 23:15:53 --> Model Class Initialized
DEBUG - 2018-03-22 23:15:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:15:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:15:53 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:15:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:15:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:15:53 --> Final output sent to browser
DEBUG - 2018-03-22 23:15:53 --> Total execution time: 0.0709
INFO - 2018-03-22 23:16:19 --> Config Class Initialized
INFO - 2018-03-22 23:16:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:16:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:16:19 --> Utf8 Class Initialized
INFO - 2018-03-22 23:16:19 --> URI Class Initialized
INFO - 2018-03-22 23:16:19 --> Router Class Initialized
INFO - 2018-03-22 23:16:19 --> Output Class Initialized
INFO - 2018-03-22 23:16:19 --> Security Class Initialized
DEBUG - 2018-03-22 23:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:16:19 --> Input Class Initialized
INFO - 2018-03-22 23:16:19 --> Language Class Initialized
INFO - 2018-03-22 23:16:19 --> Loader Class Initialized
INFO - 2018-03-22 23:16:19 --> Helper loaded: url_helper
INFO - 2018-03-22 23:16:19 --> Helper loaded: form_helper
INFO - 2018-03-22 23:16:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:16:19 --> Form Validation Class Initialized
INFO - 2018-03-22 23:16:19 --> Model Class Initialized
INFO - 2018-03-22 23:16:19 --> Controller Class Initialized
INFO - 2018-03-22 23:16:19 --> Model Class Initialized
INFO - 2018-03-22 23:16:19 --> Model Class Initialized
INFO - 2018-03-22 23:16:19 --> Model Class Initialized
INFO - 2018-03-22 23:16:19 --> Model Class Initialized
DEBUG - 2018-03-22 23:16:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:16:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:16:19 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:16:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:16:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:16:19 --> Final output sent to browser
DEBUG - 2018-03-22 23:16:19 --> Total execution time: 0.1563
INFO - 2018-03-22 23:16:34 --> Config Class Initialized
INFO - 2018-03-22 23:16:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:16:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:16:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:16:34 --> URI Class Initialized
INFO - 2018-03-22 23:16:34 --> Router Class Initialized
INFO - 2018-03-22 23:16:34 --> Output Class Initialized
INFO - 2018-03-22 23:16:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:16:34 --> Input Class Initialized
INFO - 2018-03-22 23:16:34 --> Language Class Initialized
INFO - 2018-03-22 23:16:34 --> Loader Class Initialized
INFO - 2018-03-22 23:16:34 --> Helper loaded: url_helper
INFO - 2018-03-22 23:16:34 --> Helper loaded: form_helper
INFO - 2018-03-22 23:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:16:34 --> Form Validation Class Initialized
INFO - 2018-03-22 23:16:34 --> Model Class Initialized
INFO - 2018-03-22 23:16:34 --> Controller Class Initialized
INFO - 2018-03-22 23:16:34 --> Model Class Initialized
INFO - 2018-03-22 23:16:34 --> Model Class Initialized
INFO - 2018-03-22 23:16:34 --> Model Class Initialized
INFO - 2018-03-22 23:16:34 --> Model Class Initialized
DEBUG - 2018-03-22 23:16:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 20
ERROR - 2018-03-22 23:16:34 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:16:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:16:34 --> Final output sent to browser
DEBUG - 2018-03-22 23:16:34 --> Total execution time: 0.1206
INFO - 2018-03-22 23:16:54 --> Config Class Initialized
INFO - 2018-03-22 23:16:54 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:16:54 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:16:54 --> Utf8 Class Initialized
INFO - 2018-03-22 23:16:54 --> URI Class Initialized
INFO - 2018-03-22 23:16:54 --> Router Class Initialized
INFO - 2018-03-22 23:16:54 --> Output Class Initialized
INFO - 2018-03-22 23:16:54 --> Security Class Initialized
DEBUG - 2018-03-22 23:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:16:54 --> Input Class Initialized
INFO - 2018-03-22 23:16:54 --> Language Class Initialized
INFO - 2018-03-22 23:16:54 --> Loader Class Initialized
INFO - 2018-03-22 23:16:54 --> Helper loaded: url_helper
INFO - 2018-03-22 23:16:54 --> Helper loaded: form_helper
INFO - 2018-03-22 23:16:54 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:16:54 --> Form Validation Class Initialized
INFO - 2018-03-22 23:16:54 --> Model Class Initialized
INFO - 2018-03-22 23:16:54 --> Controller Class Initialized
INFO - 2018-03-22 23:16:54 --> Model Class Initialized
INFO - 2018-03-22 23:16:54 --> Model Class Initialized
INFO - 2018-03-22 23:16:54 --> Model Class Initialized
INFO - 2018-03-22 23:16:54 --> Model Class Initialized
DEBUG - 2018-03-22 23:16:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:16:54 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 15
INFO - 2018-03-22 23:16:59 --> Config Class Initialized
INFO - 2018-03-22 23:16:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:16:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:16:59 --> Utf8 Class Initialized
INFO - 2018-03-22 23:16:59 --> URI Class Initialized
INFO - 2018-03-22 23:16:59 --> Router Class Initialized
INFO - 2018-03-22 23:16:59 --> Output Class Initialized
INFO - 2018-03-22 23:16:59 --> Security Class Initialized
DEBUG - 2018-03-22 23:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:16:59 --> Input Class Initialized
INFO - 2018-03-22 23:16:59 --> Language Class Initialized
INFO - 2018-03-22 23:16:59 --> Loader Class Initialized
INFO - 2018-03-22 23:16:59 --> Helper loaded: url_helper
INFO - 2018-03-22 23:16:59 --> Helper loaded: form_helper
INFO - 2018-03-22 23:16:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:16:59 --> Form Validation Class Initialized
INFO - 2018-03-22 23:16:59 --> Model Class Initialized
INFO - 2018-03-22 23:16:59 --> Controller Class Initialized
INFO - 2018-03-22 23:16:59 --> Model Class Initialized
INFO - 2018-03-22 23:16:59 --> Model Class Initialized
INFO - 2018-03-22 23:16:59 --> Model Class Initialized
INFO - 2018-03-22 23:16:59 --> Model Class Initialized
DEBUG - 2018-03-22 23:16:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:16:59 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:16:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:16:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:16:59 --> Final output sent to browser
DEBUG - 2018-03-22 23:16:59 --> Total execution time: 0.1780
INFO - 2018-03-22 23:17:35 --> Config Class Initialized
INFO - 2018-03-22 23:17:35 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:17:35 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:17:35 --> Utf8 Class Initialized
INFO - 2018-03-22 23:17:35 --> URI Class Initialized
INFO - 2018-03-22 23:17:35 --> Router Class Initialized
INFO - 2018-03-22 23:17:35 --> Output Class Initialized
INFO - 2018-03-22 23:17:35 --> Security Class Initialized
DEBUG - 2018-03-22 23:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:17:35 --> Input Class Initialized
INFO - 2018-03-22 23:17:35 --> Language Class Initialized
INFO - 2018-03-22 23:17:35 --> Loader Class Initialized
INFO - 2018-03-22 23:17:35 --> Helper loaded: url_helper
INFO - 2018-03-22 23:17:35 --> Helper loaded: form_helper
INFO - 2018-03-22 23:17:35 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:17:35 --> Form Validation Class Initialized
INFO - 2018-03-22 23:17:35 --> Model Class Initialized
INFO - 2018-03-22 23:17:35 --> Controller Class Initialized
INFO - 2018-03-22 23:17:35 --> Model Class Initialized
INFO - 2018-03-22 23:17:35 --> Model Class Initialized
INFO - 2018-03-22 23:17:35 --> Model Class Initialized
INFO - 2018-03-22 23:17:35 --> Model Class Initialized
DEBUG - 2018-03-22 23:17:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:17:35 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:17:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:17:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:17:35 --> Final output sent to browser
DEBUG - 2018-03-22 23:17:35 --> Total execution time: 0.1159
INFO - 2018-03-22 23:17:36 --> Config Class Initialized
INFO - 2018-03-22 23:17:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:17:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:17:36 --> Utf8 Class Initialized
INFO - 2018-03-22 23:17:36 --> URI Class Initialized
INFO - 2018-03-22 23:17:36 --> Router Class Initialized
INFO - 2018-03-22 23:17:36 --> Output Class Initialized
INFO - 2018-03-22 23:17:36 --> Security Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:17:36 --> Input Class Initialized
INFO - 2018-03-22 23:17:36 --> Language Class Initialized
INFO - 2018-03-22 23:17:36 --> Loader Class Initialized
INFO - 2018-03-22 23:17:36 --> Helper loaded: url_helper
INFO - 2018-03-22 23:17:36 --> Helper loaded: form_helper
INFO - 2018-03-22 23:17:36 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:17:36 --> Form Validation Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Controller Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:17:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:17:36 --> Final output sent to browser
DEBUG - 2018-03-22 23:17:36 --> Total execution time: 0.0577
INFO - 2018-03-22 23:17:36 --> Config Class Initialized
INFO - 2018-03-22 23:17:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:17:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:17:36 --> Utf8 Class Initialized
INFO - 2018-03-22 23:17:36 --> URI Class Initialized
INFO - 2018-03-22 23:17:36 --> Router Class Initialized
INFO - 2018-03-22 23:17:36 --> Output Class Initialized
INFO - 2018-03-22 23:17:36 --> Security Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:17:36 --> Input Class Initialized
INFO - 2018-03-22 23:17:36 --> Language Class Initialized
INFO - 2018-03-22 23:17:36 --> Loader Class Initialized
INFO - 2018-03-22 23:17:36 --> Helper loaded: url_helper
INFO - 2018-03-22 23:17:36 --> Helper loaded: form_helper
INFO - 2018-03-22 23:17:36 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:17:36 --> Form Validation Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Controller Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
INFO - 2018-03-22 23:17:36 --> Model Class Initialized
DEBUG - 2018-03-22 23:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:17:38 --> Config Class Initialized
INFO - 2018-03-22 23:17:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:17:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:17:38 --> Utf8 Class Initialized
INFO - 2018-03-22 23:17:38 --> URI Class Initialized
INFO - 2018-03-22 23:17:38 --> Router Class Initialized
INFO - 2018-03-22 23:17:38 --> Output Class Initialized
INFO - 2018-03-22 23:17:38 --> Security Class Initialized
DEBUG - 2018-03-22 23:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:17:38 --> Input Class Initialized
INFO - 2018-03-22 23:17:38 --> Language Class Initialized
INFO - 2018-03-22 23:17:38 --> Loader Class Initialized
INFO - 2018-03-22 23:17:38 --> Helper loaded: url_helper
INFO - 2018-03-22 23:17:38 --> Helper loaded: form_helper
INFO - 2018-03-22 23:17:38 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:17:38 --> Form Validation Class Initialized
INFO - 2018-03-22 23:17:38 --> Model Class Initialized
INFO - 2018-03-22 23:17:38 --> Controller Class Initialized
INFO - 2018-03-22 23:17:38 --> Model Class Initialized
INFO - 2018-03-22 23:17:38 --> Model Class Initialized
INFO - 2018-03-22 23:17:38 --> Model Class Initialized
INFO - 2018-03-22 23:17:38 --> Model Class Initialized
DEBUG - 2018-03-22 23:17:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:17:38 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:17:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:17:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:17:38 --> Final output sent to browser
DEBUG - 2018-03-22 23:17:38 --> Total execution time: 0.0653
INFO - 2018-03-22 23:17:51 --> Config Class Initialized
INFO - 2018-03-22 23:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:17:51 --> Utf8 Class Initialized
INFO - 2018-03-22 23:17:51 --> URI Class Initialized
INFO - 2018-03-22 23:17:51 --> Router Class Initialized
INFO - 2018-03-22 23:17:51 --> Output Class Initialized
INFO - 2018-03-22 23:17:51 --> Security Class Initialized
DEBUG - 2018-03-22 23:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:17:51 --> Input Class Initialized
INFO - 2018-03-22 23:17:51 --> Language Class Initialized
INFO - 2018-03-22 23:17:51 --> Loader Class Initialized
INFO - 2018-03-22 23:17:51 --> Helper loaded: url_helper
INFO - 2018-03-22 23:17:51 --> Helper loaded: form_helper
INFO - 2018-03-22 23:17:51 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:17:51 --> Form Validation Class Initialized
INFO - 2018-03-22 23:17:51 --> Model Class Initialized
INFO - 2018-03-22 23:17:51 --> Controller Class Initialized
INFO - 2018-03-22 23:17:51 --> Model Class Initialized
INFO - 2018-03-22 23:17:51 --> Model Class Initialized
INFO - 2018-03-22 23:17:51 --> Model Class Initialized
INFO - 2018-03-22 23:17:51 --> Model Class Initialized
DEBUG - 2018-03-22 23:17:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:17:51 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:17:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:17:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:17:51 --> Final output sent to browser
DEBUG - 2018-03-22 23:17:51 --> Total execution time: 0.1020
INFO - 2018-03-22 23:18:06 --> Config Class Initialized
INFO - 2018-03-22 23:18:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:06 --> URI Class Initialized
INFO - 2018-03-22 23:18:06 --> Router Class Initialized
INFO - 2018-03-22 23:18:06 --> Output Class Initialized
INFO - 2018-03-22 23:18:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:06 --> Input Class Initialized
INFO - 2018-03-22 23:18:06 --> Language Class Initialized
INFO - 2018-03-22 23:18:06 --> Loader Class Initialized
INFO - 2018-03-22 23:18:06 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:06 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:06 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:06 --> Model Class Initialized
INFO - 2018-03-22 23:18:06 --> Controller Class Initialized
INFO - 2018-03-22 23:18:06 --> Model Class Initialized
INFO - 2018-03-22 23:18:06 --> Model Class Initialized
INFO - 2018-03-22 23:18:06 --> Model Class Initialized
INFO - 2018-03-22 23:18:06 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:18:06 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:18:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:18:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:06 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:06 --> Total execution time: 0.1646
INFO - 2018-03-22 23:18:29 --> Config Class Initialized
INFO - 2018-03-22 23:18:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:29 --> URI Class Initialized
INFO - 2018-03-22 23:18:29 --> Router Class Initialized
INFO - 2018-03-22 23:18:29 --> Output Class Initialized
INFO - 2018-03-22 23:18:29 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:29 --> Input Class Initialized
INFO - 2018-03-22 23:18:29 --> Language Class Initialized
INFO - 2018-03-22 23:18:29 --> Loader Class Initialized
INFO - 2018-03-22 23:18:29 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:29 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:29 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:29 --> Model Class Initialized
INFO - 2018-03-22 23:18:29 --> Controller Class Initialized
INFO - 2018-03-22 23:18:29 --> Model Class Initialized
INFO - 2018-03-22 23:18:29 --> Model Class Initialized
INFO - 2018-03-22 23:18:29 --> Model Class Initialized
INFO - 2018-03-22 23:18:29 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:18:29 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:18:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:18:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:29 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:29 --> Total execution time: 0.0666
INFO - 2018-03-22 23:18:32 --> Config Class Initialized
INFO - 2018-03-22 23:18:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:32 --> URI Class Initialized
INFO - 2018-03-22 23:18:32 --> Router Class Initialized
INFO - 2018-03-22 23:18:32 --> Output Class Initialized
INFO - 2018-03-22 23:18:32 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:32 --> Input Class Initialized
INFO - 2018-03-22 23:18:32 --> Language Class Initialized
INFO - 2018-03-22 23:18:32 --> Loader Class Initialized
INFO - 2018-03-22 23:18:32 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:32 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:32 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:32 --> Model Class Initialized
INFO - 2018-03-22 23:18:32 --> Controller Class Initialized
INFO - 2018-03-22 23:18:32 --> Model Class Initialized
INFO - 2018-03-22 23:18:32 --> Model Class Initialized
INFO - 2018-03-22 23:18:32 --> Model Class Initialized
INFO - 2018-03-22 23:18:32 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:32 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:32 --> Total execution time: 0.0693
INFO - 2018-03-22 23:18:33 --> Config Class Initialized
INFO - 2018-03-22 23:18:33 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:33 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:33 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:33 --> URI Class Initialized
INFO - 2018-03-22 23:18:33 --> Router Class Initialized
INFO - 2018-03-22 23:18:33 --> Output Class Initialized
INFO - 2018-03-22 23:18:33 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:33 --> Input Class Initialized
INFO - 2018-03-22 23:18:33 --> Language Class Initialized
INFO - 2018-03-22 23:18:33 --> Loader Class Initialized
INFO - 2018-03-22 23:18:33 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:33 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:33 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:33 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
INFO - 2018-03-22 23:18:33 --> Controller Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
INFO - 2018-03-22 23:18:33 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:35 --> Config Class Initialized
INFO - 2018-03-22 23:18:35 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:35 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:35 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:35 --> URI Class Initialized
INFO - 2018-03-22 23:18:35 --> Router Class Initialized
INFO - 2018-03-22 23:18:35 --> Output Class Initialized
INFO - 2018-03-22 23:18:35 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:35 --> Input Class Initialized
INFO - 2018-03-22 23:18:35 --> Language Class Initialized
INFO - 2018-03-22 23:18:35 --> Loader Class Initialized
INFO - 2018-03-22 23:18:35 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:35 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:35 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:35 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:35 --> Model Class Initialized
INFO - 2018-03-22 23:18:35 --> Controller Class Initialized
INFO - 2018-03-22 23:18:35 --> Model Class Initialized
INFO - 2018-03-22 23:18:35 --> Model Class Initialized
INFO - 2018-03-22 23:18:35 --> Model Class Initialized
INFO - 2018-03-22 23:18:35 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:35 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:35 --> Total execution time: 0.0697
INFO - 2018-03-22 23:18:36 --> Config Class Initialized
INFO - 2018-03-22 23:18:36 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:36 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:36 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:36 --> URI Class Initialized
INFO - 2018-03-22 23:18:36 --> Router Class Initialized
INFO - 2018-03-22 23:18:36 --> Output Class Initialized
INFO - 2018-03-22 23:18:36 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:36 --> Input Class Initialized
INFO - 2018-03-22 23:18:36 --> Language Class Initialized
INFO - 2018-03-22 23:18:36 --> Loader Class Initialized
INFO - 2018-03-22 23:18:36 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:36 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:36 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:36 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
INFO - 2018-03-22 23:18:36 --> Controller Class Initialized
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:36 --> Model Class Initialized
INFO - 2018-03-22 23:18:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:36 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:36 --> Total execution time: 0.0755
INFO - 2018-03-22 23:18:37 --> Config Class Initialized
INFO - 2018-03-22 23:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:37 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:37 --> URI Class Initialized
INFO - 2018-03-22 23:18:37 --> Router Class Initialized
INFO - 2018-03-22 23:18:37 --> Output Class Initialized
INFO - 2018-03-22 23:18:37 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:37 --> Input Class Initialized
INFO - 2018-03-22 23:18:37 --> Language Class Initialized
INFO - 2018-03-22 23:18:37 --> Loader Class Initialized
INFO - 2018-03-22 23:18:37 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:37 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:37 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:37 --> Model Class Initialized
INFO - 2018-03-22 23:18:37 --> Controller Class Initialized
INFO - 2018-03-22 23:18:37 --> Model Class Initialized
INFO - 2018-03-22 23:18:37 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:41 --> Config Class Initialized
INFO - 2018-03-22 23:18:41 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:41 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:41 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:41 --> URI Class Initialized
INFO - 2018-03-22 23:18:41 --> Router Class Initialized
INFO - 2018-03-22 23:18:41 --> Output Class Initialized
INFO - 2018-03-22 23:18:41 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:41 --> Input Class Initialized
INFO - 2018-03-22 23:18:41 --> Language Class Initialized
INFO - 2018-03-22 23:18:41 --> Loader Class Initialized
INFO - 2018-03-22 23:18:41 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:41 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:41 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:41 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Controller Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:41 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:41 --> Total execution time: 0.1252
INFO - 2018-03-22 23:18:41 --> Config Class Initialized
INFO - 2018-03-22 23:18:41 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:41 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:41 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:41 --> URI Class Initialized
INFO - 2018-03-22 23:18:41 --> Router Class Initialized
INFO - 2018-03-22 23:18:41 --> Output Class Initialized
INFO - 2018-03-22 23:18:41 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:41 --> Input Class Initialized
INFO - 2018-03-22 23:18:41 --> Language Class Initialized
INFO - 2018-03-22 23:18:41 --> Loader Class Initialized
INFO - 2018-03-22 23:18:41 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:41 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:41 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:41 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Controller Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
INFO - 2018-03-22 23:18:41 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:42 --> Config Class Initialized
INFO - 2018-03-22 23:18:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:42 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:42 --> URI Class Initialized
INFO - 2018-03-22 23:18:42 --> Router Class Initialized
INFO - 2018-03-22 23:18:42 --> Output Class Initialized
INFO - 2018-03-22 23:18:42 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:42 --> Input Class Initialized
INFO - 2018-03-22 23:18:42 --> Language Class Initialized
INFO - 2018-03-22 23:18:42 --> Loader Class Initialized
INFO - 2018-03-22 23:18:42 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:42 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:42 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:42 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Controller Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:42 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:42 --> Total execution time: 0.0787
INFO - 2018-03-22 23:18:42 --> Config Class Initialized
INFO - 2018-03-22 23:18:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:42 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:42 --> URI Class Initialized
INFO - 2018-03-22 23:18:42 --> Router Class Initialized
INFO - 2018-03-22 23:18:42 --> Output Class Initialized
INFO - 2018-03-22 23:18:42 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:42 --> Input Class Initialized
INFO - 2018-03-22 23:18:42 --> Language Class Initialized
INFO - 2018-03-22 23:18:42 --> Loader Class Initialized
INFO - 2018-03-22 23:18:42 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:42 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:42 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:42 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Controller Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
INFO - 2018-03-22 23:18:42 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:44 --> Config Class Initialized
INFO - 2018-03-22 23:18:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:44 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:44 --> URI Class Initialized
INFO - 2018-03-22 23:18:44 --> Router Class Initialized
INFO - 2018-03-22 23:18:44 --> Output Class Initialized
INFO - 2018-03-22 23:18:44 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:44 --> Input Class Initialized
INFO - 2018-03-22 23:18:44 --> Language Class Initialized
INFO - 2018-03-22 23:18:44 --> Loader Class Initialized
INFO - 2018-03-22 23:18:44 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:44 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:44 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Controller Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:44 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:44 --> Total execution time: 0.1479
INFO - 2018-03-22 23:18:44 --> Config Class Initialized
INFO - 2018-03-22 23:18:44 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:44 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:44 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:44 --> URI Class Initialized
INFO - 2018-03-22 23:18:44 --> Router Class Initialized
INFO - 2018-03-22 23:18:44 --> Output Class Initialized
INFO - 2018-03-22 23:18:44 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:44 --> Input Class Initialized
INFO - 2018-03-22 23:18:44 --> Language Class Initialized
INFO - 2018-03-22 23:18:44 --> Loader Class Initialized
INFO - 2018-03-22 23:18:44 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:44 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:44 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:44 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Controller Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
INFO - 2018-03-22 23:18:44 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:57 --> Config Class Initialized
INFO - 2018-03-22 23:18:57 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:57 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:57 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:57 --> URI Class Initialized
INFO - 2018-03-22 23:18:57 --> Router Class Initialized
INFO - 2018-03-22 23:18:57 --> Output Class Initialized
INFO - 2018-03-22 23:18:57 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:57 --> Input Class Initialized
INFO - 2018-03-22 23:18:57 --> Language Class Initialized
INFO - 2018-03-22 23:18:57 --> Loader Class Initialized
INFO - 2018-03-22 23:18:57 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:57 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:57 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:57 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
INFO - 2018-03-22 23:18:57 --> Controller Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:57 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:57 --> Total execution time: 0.1109
INFO - 2018-03-22 23:18:57 --> Config Class Initialized
INFO - 2018-03-22 23:18:57 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:57 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:57 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:57 --> URI Class Initialized
INFO - 2018-03-22 23:18:57 --> Router Class Initialized
INFO - 2018-03-22 23:18:57 --> Output Class Initialized
INFO - 2018-03-22 23:18:57 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:57 --> Input Class Initialized
INFO - 2018-03-22 23:18:57 --> Language Class Initialized
INFO - 2018-03-22 23:18:57 --> Loader Class Initialized
INFO - 2018-03-22 23:18:57 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:57 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:57 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:57 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
INFO - 2018-03-22 23:18:57 --> Controller Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
INFO - 2018-03-22 23:18:57 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:59 --> Config Class Initialized
INFO - 2018-03-22 23:18:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:59 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:59 --> URI Class Initialized
INFO - 2018-03-22 23:18:59 --> Router Class Initialized
INFO - 2018-03-22 23:18:59 --> Output Class Initialized
INFO - 2018-03-22 23:18:59 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:59 --> Input Class Initialized
INFO - 2018-03-22 23:18:59 --> Language Class Initialized
INFO - 2018-03-22 23:18:59 --> Loader Class Initialized
INFO - 2018-03-22 23:18:59 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:59 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:59 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
INFO - 2018-03-22 23:18:59 --> Controller Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:18:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:18:59 --> Final output sent to browser
DEBUG - 2018-03-22 23:18:59 --> Total execution time: 0.0980
INFO - 2018-03-22 23:18:59 --> Config Class Initialized
INFO - 2018-03-22 23:18:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:18:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:18:59 --> Utf8 Class Initialized
INFO - 2018-03-22 23:18:59 --> URI Class Initialized
INFO - 2018-03-22 23:18:59 --> Router Class Initialized
INFO - 2018-03-22 23:18:59 --> Output Class Initialized
INFO - 2018-03-22 23:18:59 --> Security Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:18:59 --> Input Class Initialized
INFO - 2018-03-22 23:18:59 --> Language Class Initialized
INFO - 2018-03-22 23:18:59 --> Loader Class Initialized
INFO - 2018-03-22 23:18:59 --> Helper loaded: url_helper
INFO - 2018-03-22 23:18:59 --> Helper loaded: form_helper
INFO - 2018-03-22 23:18:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:18:59 --> Form Validation Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
INFO - 2018-03-22 23:18:59 --> Controller Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
INFO - 2018-03-22 23:18:59 --> Model Class Initialized
DEBUG - 2018-03-22 23:18:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:19:00 --> Config Class Initialized
INFO - 2018-03-22 23:19:00 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:19:00 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:19:00 --> Utf8 Class Initialized
INFO - 2018-03-22 23:19:00 --> URI Class Initialized
INFO - 2018-03-22 23:19:00 --> Router Class Initialized
INFO - 2018-03-22 23:19:00 --> Output Class Initialized
INFO - 2018-03-22 23:19:00 --> Security Class Initialized
DEBUG - 2018-03-22 23:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:19:00 --> Input Class Initialized
INFO - 2018-03-22 23:19:00 --> Language Class Initialized
INFO - 2018-03-22 23:19:00 --> Loader Class Initialized
INFO - 2018-03-22 23:19:00 --> Helper loaded: url_helper
INFO - 2018-03-22 23:19:00 --> Helper loaded: form_helper
INFO - 2018-03-22 23:19:00 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:19:00 --> Form Validation Class Initialized
INFO - 2018-03-22 23:19:00 --> Model Class Initialized
INFO - 2018-03-22 23:19:00 --> Controller Class Initialized
INFO - 2018-03-22 23:19:00 --> Model Class Initialized
INFO - 2018-03-22 23:19:00 --> Model Class Initialized
INFO - 2018-03-22 23:19:00 --> Model Class Initialized
INFO - 2018-03-22 23:19:00 --> Model Class Initialized
DEBUG - 2018-03-22 23:19:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:19:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:19:00 --> Final output sent to browser
DEBUG - 2018-03-22 23:19:00 --> Total execution time: 0.0833
INFO - 2018-03-22 23:19:01 --> Config Class Initialized
INFO - 2018-03-22 23:19:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:19:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:19:01 --> Utf8 Class Initialized
INFO - 2018-03-22 23:19:01 --> URI Class Initialized
INFO - 2018-03-22 23:19:01 --> Router Class Initialized
INFO - 2018-03-22 23:19:01 --> Output Class Initialized
INFO - 2018-03-22 23:19:01 --> Security Class Initialized
DEBUG - 2018-03-22 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:19:01 --> Input Class Initialized
INFO - 2018-03-22 23:19:01 --> Language Class Initialized
INFO - 2018-03-22 23:19:01 --> Loader Class Initialized
INFO - 2018-03-22 23:19:01 --> Helper loaded: url_helper
INFO - 2018-03-22 23:19:01 --> Helper loaded: form_helper
INFO - 2018-03-22 23:19:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:19:01 --> Form Validation Class Initialized
INFO - 2018-03-22 23:19:01 --> Model Class Initialized
INFO - 2018-03-22 23:19:01 --> Controller Class Initialized
INFO - 2018-03-22 23:19:01 --> Model Class Initialized
INFO - 2018-03-22 23:19:01 --> Model Class Initialized
INFO - 2018-03-22 23:19:01 --> Model Class Initialized
INFO - 2018-03-22 23:19:01 --> Model Class Initialized
DEBUG - 2018-03-22 23:19:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:19:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:19:01 --> Final output sent to browser
DEBUG - 2018-03-22 23:19:01 --> Total execution time: 0.0929
INFO - 2018-03-22 23:19:02 --> Config Class Initialized
INFO - 2018-03-22 23:19:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:19:02 --> Utf8 Class Initialized
INFO - 2018-03-22 23:19:02 --> URI Class Initialized
INFO - 2018-03-22 23:19:02 --> Router Class Initialized
INFO - 2018-03-22 23:19:02 --> Output Class Initialized
INFO - 2018-03-22 23:19:02 --> Security Class Initialized
DEBUG - 2018-03-22 23:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:19:02 --> Input Class Initialized
INFO - 2018-03-22 23:19:02 --> Language Class Initialized
INFO - 2018-03-22 23:19:02 --> Loader Class Initialized
INFO - 2018-03-22 23:19:02 --> Helper loaded: url_helper
INFO - 2018-03-22 23:19:02 --> Helper loaded: form_helper
INFO - 2018-03-22 23:19:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:19:02 --> Form Validation Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
INFO - 2018-03-22 23:19:02 --> Controller Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
INFO - 2018-03-22 23:19:02 --> Model Class Initialized
DEBUG - 2018-03-22 23:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:19:03 --> Config Class Initialized
INFO - 2018-03-22 23:19:03 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:19:03 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:19:03 --> Utf8 Class Initialized
INFO - 2018-03-22 23:19:03 --> URI Class Initialized
INFO - 2018-03-22 23:19:03 --> Router Class Initialized
INFO - 2018-03-22 23:19:03 --> Output Class Initialized
INFO - 2018-03-22 23:19:03 --> Security Class Initialized
DEBUG - 2018-03-22 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:19:03 --> Input Class Initialized
INFO - 2018-03-22 23:19:03 --> Language Class Initialized
INFO - 2018-03-22 23:19:03 --> Loader Class Initialized
INFO - 2018-03-22 23:19:03 --> Helper loaded: url_helper
INFO - 2018-03-22 23:19:03 --> Helper loaded: form_helper
INFO - 2018-03-22 23:19:03 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:19:03 --> Form Validation Class Initialized
INFO - 2018-03-22 23:19:03 --> Model Class Initialized
INFO - 2018-03-22 23:19:03 --> Controller Class Initialized
INFO - 2018-03-22 23:19:03 --> Model Class Initialized
INFO - 2018-03-22 23:19:03 --> Model Class Initialized
INFO - 2018-03-22 23:19:03 --> Model Class Initialized
INFO - 2018-03-22 23:19:03 --> Model Class Initialized
DEBUG - 2018-03-22 23:19:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:19:03 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
ERROR - 2018-03-22 23:19:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteHorasPorProyectoDetalle.php 63
INFO - 2018-03-22 23:19:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:19:03 --> Final output sent to browser
DEBUG - 2018-03-22 23:19:03 --> Total execution time: 0.0759
INFO - 2018-03-22 23:25:58 --> Config Class Initialized
INFO - 2018-03-22 23:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:25:58 --> Utf8 Class Initialized
INFO - 2018-03-22 23:25:58 --> URI Class Initialized
INFO - 2018-03-22 23:25:58 --> Router Class Initialized
INFO - 2018-03-22 23:25:58 --> Output Class Initialized
INFO - 2018-03-22 23:25:58 --> Security Class Initialized
DEBUG - 2018-03-22 23:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:25:58 --> Input Class Initialized
INFO - 2018-03-22 23:25:58 --> Language Class Initialized
INFO - 2018-03-22 23:25:58 --> Loader Class Initialized
INFO - 2018-03-22 23:25:58 --> Helper loaded: url_helper
INFO - 2018-03-22 23:25:58 --> Helper loaded: form_helper
INFO - 2018-03-22 23:25:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:25:58 --> Form Validation Class Initialized
INFO - 2018-03-22 23:25:58 --> Model Class Initialized
INFO - 2018-03-22 23:25:58 --> Controller Class Initialized
INFO - 2018-03-22 23:25:58 --> Model Class Initialized
INFO - 2018-03-22 23:25:58 --> Model Class Initialized
INFO - 2018-03-22 23:25:58 --> Model Class Initialized
INFO - 2018-03-22 23:25:58 --> Model Class Initialized
DEBUG - 2018-03-22 23:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:25:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:25:58 --> Final output sent to browser
DEBUG - 2018-03-22 23:25:58 --> Total execution time: 0.1129
INFO - 2018-03-22 23:25:58 --> Config Class Initialized
INFO - 2018-03-22 23:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:25:59 --> Utf8 Class Initialized
INFO - 2018-03-22 23:25:59 --> URI Class Initialized
INFO - 2018-03-22 23:25:59 --> Router Class Initialized
INFO - 2018-03-22 23:25:59 --> Output Class Initialized
INFO - 2018-03-22 23:25:59 --> Security Class Initialized
DEBUG - 2018-03-22 23:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:25:59 --> Input Class Initialized
INFO - 2018-03-22 23:25:59 --> Language Class Initialized
INFO - 2018-03-22 23:25:59 --> Loader Class Initialized
INFO - 2018-03-22 23:25:59 --> Helper loaded: url_helper
INFO - 2018-03-22 23:25:59 --> Helper loaded: form_helper
INFO - 2018-03-22 23:25:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:25:59 --> Form Validation Class Initialized
INFO - 2018-03-22 23:25:59 --> Model Class Initialized
INFO - 2018-03-22 23:25:59 --> Controller Class Initialized
INFO - 2018-03-22 23:25:59 --> Model Class Initialized
INFO - 2018-03-22 23:25:59 --> Model Class Initialized
INFO - 2018-03-22 23:25:59 --> Model Class Initialized
INFO - 2018-03-22 23:25:59 --> Model Class Initialized
DEBUG - 2018-03-22 23:25:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:25:59 --> Severity: Error --> Call to undefined method M_Proyecto::consultaHorasLaboradasProyecto() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 177
INFO - 2018-03-22 23:26:42 --> Config Class Initialized
INFO - 2018-03-22 23:26:42 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:26:42 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:26:42 --> Utf8 Class Initialized
INFO - 2018-03-22 23:26:43 --> URI Class Initialized
INFO - 2018-03-22 23:26:43 --> Router Class Initialized
INFO - 2018-03-22 23:26:43 --> Output Class Initialized
INFO - 2018-03-22 23:26:43 --> Security Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:26:43 --> Input Class Initialized
INFO - 2018-03-22 23:26:43 --> Language Class Initialized
INFO - 2018-03-22 23:26:43 --> Loader Class Initialized
INFO - 2018-03-22 23:26:43 --> Helper loaded: url_helper
INFO - 2018-03-22 23:26:43 --> Helper loaded: form_helper
INFO - 2018-03-22 23:26:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:26:43 --> Form Validation Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Controller Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:26:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:26:43 --> Final output sent to browser
DEBUG - 2018-03-22 23:26:43 --> Total execution time: 0.1147
INFO - 2018-03-22 23:26:43 --> Config Class Initialized
INFO - 2018-03-22 23:26:43 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:26:43 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:26:43 --> Utf8 Class Initialized
INFO - 2018-03-22 23:26:43 --> URI Class Initialized
INFO - 2018-03-22 23:26:43 --> Router Class Initialized
INFO - 2018-03-22 23:26:43 --> Output Class Initialized
INFO - 2018-03-22 23:26:43 --> Security Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:26:43 --> Input Class Initialized
INFO - 2018-03-22 23:26:43 --> Language Class Initialized
INFO - 2018-03-22 23:26:43 --> Loader Class Initialized
INFO - 2018-03-22 23:26:43 --> Helper loaded: url_helper
INFO - 2018-03-22 23:26:43 --> Helper loaded: form_helper
INFO - 2018-03-22 23:26:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:26:43 --> Form Validation Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Controller Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
INFO - 2018-03-22 23:26:43 --> Model Class Initialized
DEBUG - 2018-03-22 23:26:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:26:43 --> Severity: Error --> Call to undefined method M_Proyecto::consultaHorasLaboradasProyecto() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 177
INFO - 2018-03-22 23:36:27 --> Config Class Initialized
INFO - 2018-03-22 23:36:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:27 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:27 --> URI Class Initialized
INFO - 2018-03-22 23:36:27 --> Router Class Initialized
INFO - 2018-03-22 23:36:27 --> Output Class Initialized
INFO - 2018-03-22 23:36:27 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:27 --> Input Class Initialized
INFO - 2018-03-22 23:36:27 --> Language Class Initialized
INFO - 2018-03-22 23:36:27 --> Loader Class Initialized
INFO - 2018-03-22 23:36:27 --> Helper loaded: url_helper
INFO - 2018-03-22 23:36:27 --> Helper loaded: form_helper
INFO - 2018-03-22 23:36:27 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:36:27 --> Form Validation Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Controller Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:36:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:36:27 --> Final output sent to browser
DEBUG - 2018-03-22 23:36:27 --> Total execution time: 0.1148
INFO - 2018-03-22 23:36:27 --> Config Class Initialized
INFO - 2018-03-22 23:36:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:27 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:27 --> URI Class Initialized
INFO - 2018-03-22 23:36:27 --> Router Class Initialized
INFO - 2018-03-22 23:36:27 --> Output Class Initialized
INFO - 2018-03-22 23:36:27 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:27 --> Input Class Initialized
INFO - 2018-03-22 23:36:27 --> Language Class Initialized
INFO - 2018-03-22 23:36:27 --> Loader Class Initialized
INFO - 2018-03-22 23:36:27 --> Helper loaded: url_helper
INFO - 2018-03-22 23:36:27 --> Helper loaded: form_helper
INFO - 2018-03-22 23:36:27 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:36:27 --> Form Validation Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Controller Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
INFO - 2018-03-22 23:36:27 --> Model Class Initialized
DEBUG - 2018-03-22 23:36:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:36:27 --> Query error: Unknown column 'proyecto_gasto_monto.estado_costo' in 'on clause' - Invalid query: SELECT *
FROM `proyecto_gasto_mano_obra`
JOIN `proyecto_gasto` ON `proyecto_gasto`.`proyecto_gasto_id` = `proyecto_gasto_mano_obra`.`proyecto_gasto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_costo` = 1
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto_mano_obra`.`estado_registro` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-03-22 23:36:27 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-22 23:36:29 --> Config Class Initialized
INFO - 2018-03-22 23:36:29 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:29 --> Config Class Initialized
INFO - 2018-03-22 23:36:29 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:29 --> Config Class Initialized
INFO - 2018-03-22 23:36:29 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:29 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:29 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:29 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:29 --> URI Class Initialized
INFO - 2018-03-22 23:36:29 --> URI Class Initialized
INFO - 2018-03-22 23:36:29 --> Config Class Initialized
INFO - 2018-03-22 23:36:29 --> URI Class Initialized
INFO - 2018-03-22 23:36:29 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:29 --> Router Class Initialized
INFO - 2018-03-22 23:36:29 --> Output Class Initialized
DEBUG - 2018-03-22 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:29 --> Security Class Initialized
INFO - 2018-03-22 23:36:29 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:29 --> Input Class Initialized
INFO - 2018-03-22 23:36:29 --> URI Class Initialized
INFO - 2018-03-22 23:36:29 --> Language Class Initialized
INFO - 2018-03-22 23:36:29 --> Router Class Initialized
ERROR - 2018-03-22 23:36:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:36:29 --> Router Class Initialized
INFO - 2018-03-22 23:36:29 --> Output Class Initialized
INFO - 2018-03-22 23:36:29 --> Security Class Initialized
INFO - 2018-03-22 23:36:29 --> Output Class Initialized
INFO - 2018-03-22 23:36:30 --> Router Class Initialized
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
INFO - 2018-03-22 23:36:30 --> Output Class Initialized
INFO - 2018-03-22 23:36:30 --> Security Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:36:30 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
INFO - 2018-03-22 23:36:30 --> Config Class Initialized
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
INFO - 2018-03-22 23:36:30 --> Config Class Initialized
INFO - 2018-03-22 23:36:30 --> Hooks Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 23:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:30 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:30 --> URI Class Initialized
DEBUG - 2018-03-22 23:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:30 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:30 --> Config Class Initialized
INFO - 2018-03-22 23:36:30 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:30 --> URI Class Initialized
INFO - 2018-03-22 23:36:30 --> Router Class Initialized
DEBUG - 2018-03-22 23:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:30 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:30 --> Output Class Initialized
INFO - 2018-03-22 23:36:30 --> Router Class Initialized
INFO - 2018-03-22 23:36:30 --> URI Class Initialized
INFO - 2018-03-22 23:36:30 --> Security Class Initialized
INFO - 2018-03-22 23:36:30 --> Output Class Initialized
INFO - 2018-03-22 23:36:30 --> Router Class Initialized
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
INFO - 2018-03-22 23:36:30 --> Security Class Initialized
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
INFO - 2018-03-22 23:36:30 --> Output Class Initialized
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
INFO - 2018-03-22 23:36:30 --> Security Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:30 --> Input Class Initialized
INFO - 2018-03-22 23:36:30 --> Language Class Initialized
ERROR - 2018-03-22 23:36:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:36:31 --> Config Class Initialized
INFO - 2018-03-22 23:36:31 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:31 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:31 --> URI Class Initialized
INFO - 2018-03-22 23:36:31 --> Router Class Initialized
INFO - 2018-03-22 23:36:31 --> Output Class Initialized
INFO - 2018-03-22 23:36:31 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:31 --> Input Class Initialized
INFO - 2018-03-22 23:36:31 --> Language Class Initialized
INFO - 2018-03-22 23:36:31 --> Loader Class Initialized
INFO - 2018-03-22 23:36:31 --> Helper loaded: url_helper
INFO - 2018-03-22 23:36:31 --> Helper loaded: form_helper
INFO - 2018-03-22 23:36:31 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:36:31 --> Form Validation Class Initialized
INFO - 2018-03-22 23:36:31 --> Model Class Initialized
INFO - 2018-03-22 23:36:31 --> Controller Class Initialized
INFO - 2018-03-22 23:36:31 --> Model Class Initialized
INFO - 2018-03-22 23:36:31 --> Model Class Initialized
INFO - 2018-03-22 23:36:31 --> Model Class Initialized
INFO - 2018-03-22 23:36:31 --> Model Class Initialized
DEBUG - 2018-03-22 23:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:36:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:36:31 --> Final output sent to browser
DEBUG - 2018-03-22 23:36:31 --> Total execution time: 0.1035
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:36:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:36:32 --> Config Class Initialized
INFO - 2018-03-22 23:36:32 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:36:32 --> Utf8 Class Initialized
INFO - 2018-03-22 23:36:32 --> URI Class Initialized
INFO - 2018-03-22 23:36:32 --> Router Class Initialized
INFO - 2018-03-22 23:36:32 --> Output Class Initialized
INFO - 2018-03-22 23:36:32 --> Security Class Initialized
DEBUG - 2018-03-22 23:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:36:32 --> Input Class Initialized
INFO - 2018-03-22 23:36:32 --> Language Class Initialized
INFO - 2018-03-22 23:36:32 --> Loader Class Initialized
INFO - 2018-03-22 23:36:32 --> Helper loaded: url_helper
INFO - 2018-03-22 23:36:32 --> Helper loaded: form_helper
INFO - 2018-03-22 23:36:32 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:36:32 --> Form Validation Class Initialized
INFO - 2018-03-22 23:36:32 --> Model Class Initialized
INFO - 2018-03-22 23:36:32 --> Controller Class Initialized
INFO - 2018-03-22 23:36:32 --> Model Class Initialized
INFO - 2018-03-22 23:36:32 --> Model Class Initialized
INFO - 2018-03-22 23:36:32 --> Model Class Initialized
INFO - 2018-03-22 23:36:32 --> Model Class Initialized
DEBUG - 2018-03-22 23:36:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:36:32 --> Query error: Unknown column 'proyecto_gasto_monto.estado_costo' in 'on clause' - Invalid query: SELECT *
FROM `proyecto_gasto_mano_obra`
JOIN `proyecto_gasto` ON `proyecto_gasto`.`proyecto_gasto_id` = `proyecto_gasto_mano_obra`.`proyecto_gasto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_costo` = 1
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto_mano_obra`.`estado_registro` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-03-22 23:36:32 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-22 23:37:15 --> Config Class Initialized
INFO - 2018-03-22 23:37:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:37:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:15 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:15 --> URI Class Initialized
INFO - 2018-03-22 23:37:15 --> Router Class Initialized
INFO - 2018-03-22 23:37:15 --> Output Class Initialized
INFO - 2018-03-22 23:37:15 --> Security Class Initialized
DEBUG - 2018-03-22 23:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:15 --> Input Class Initialized
INFO - 2018-03-22 23:37:15 --> Language Class Initialized
INFO - 2018-03-22 23:37:15 --> Loader Class Initialized
INFO - 2018-03-22 23:37:15 --> Helper loaded: url_helper
INFO - 2018-03-22 23:37:15 --> Helper loaded: form_helper
INFO - 2018-03-22 23:37:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:37:16 --> Form Validation Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Controller Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:37:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:37:16 --> Final output sent to browser
DEBUG - 2018-03-22 23:37:16 --> Total execution time: 0.0812
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
ERROR - 2018-03-22 23:37:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:37:16 --> Config Class Initialized
INFO - 2018-03-22 23:37:16 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2018-03-22 23:37:16 --> URI Class Initialized
INFO - 2018-03-22 23:37:16 --> Router Class Initialized
INFO - 2018-03-22 23:37:16 --> Output Class Initialized
INFO - 2018-03-22 23:37:16 --> Security Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:37:16 --> Input Class Initialized
INFO - 2018-03-22 23:37:16 --> Language Class Initialized
INFO - 2018-03-22 23:37:16 --> Loader Class Initialized
INFO - 2018-03-22 23:37:16 --> Helper loaded: url_helper
INFO - 2018-03-22 23:37:16 --> Helper loaded: form_helper
INFO - 2018-03-22 23:37:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:37:16 --> Form Validation Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Controller Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
INFO - 2018-03-22 23:37:16 --> Model Class Initialized
DEBUG - 2018-03-22 23:37:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:46:01 --> Config Class Initialized
INFO - 2018-03-22 23:46:01 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:01 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:01 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:01 --> URI Class Initialized
INFO - 2018-03-22 23:46:01 --> Router Class Initialized
INFO - 2018-03-22 23:46:01 --> Output Class Initialized
INFO - 2018-03-22 23:46:01 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:01 --> Input Class Initialized
INFO - 2018-03-22 23:46:01 --> Language Class Initialized
INFO - 2018-03-22 23:46:01 --> Loader Class Initialized
INFO - 2018-03-22 23:46:01 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:01 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:01 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:01 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:01 --> Model Class Initialized
INFO - 2018-03-22 23:46:01 --> Controller Class Initialized
INFO - 2018-03-22 23:46:01 --> Model Class Initialized
INFO - 2018-03-22 23:46:01 --> Model Class Initialized
INFO - 2018-03-22 23:46:01 --> Model Class Initialized
INFO - 2018-03-22 23:46:01 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:46:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:46:01 --> Final output sent to browser
DEBUG - 2018-03-22 23:46:01 --> Total execution time: 0.0933
INFO - 2018-03-22 23:46:02 --> Config Class Initialized
INFO - 2018-03-22 23:46:02 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:02 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:02 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:02 --> URI Class Initialized
INFO - 2018-03-22 23:46:02 --> Router Class Initialized
INFO - 2018-03-22 23:46:02 --> Output Class Initialized
INFO - 2018-03-22 23:46:02 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:02 --> Input Class Initialized
INFO - 2018-03-22 23:46:02 --> Language Class Initialized
INFO - 2018-03-22 23:46:02 --> Loader Class Initialized
INFO - 2018-03-22 23:46:02 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:02 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:02 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:02 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:02 --> Model Class Initialized
INFO - 2018-03-22 23:46:02 --> Controller Class Initialized
INFO - 2018-03-22 23:46:02 --> Model Class Initialized
INFO - 2018-03-22 23:46:02 --> Model Class Initialized
INFO - 2018-03-22 23:46:02 --> Model Class Initialized
INFO - 2018-03-22 23:46:02 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:46:02 --> Query error: Unknown column 'proyecto_gasto_monto.cantidad_horas' in 'field list' - Invalid query: SELECT `proyecto_gasto`.`fecha_gasto`, SUM(`proyecto_gasto_monto`.`cantidad_horas`) AS `total_horas`, SUM(`proyecto_gasto_monto`.`cantidad_horas_extra`) AS `total_horas_extra`, SUM(`proyecto_gasto_monto`.`proyecto_gasto_monto`) AS `total_costo`
FROM `proyecto_gasto_mano_obra`
JOIN `proyecto_gasto` ON `proyecto_gasto`.`proyecto_gasto_id` = `proyecto_gasto_mano_obra`.`proyecto_gasto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto_mano_obra`.`estado_registro` = 1
GROUP BY `proyecto_gasto`.`proyecto_id`
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-03-22 23:46:02 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Config Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
INFO - 2018-03-22 23:46:04 --> URI Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> Router Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
INFO - 2018-03-22 23:46:04 --> Output Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
INFO - 2018-03-22 23:46:04 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
DEBUG - 2018-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:46:04 --> Input Class Initialized
INFO - 2018-03-22 23:46:04 --> Language Class Initialized
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:46:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:46:05 --> Config Class Initialized
INFO - 2018-03-22 23:46:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:05 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:05 --> URI Class Initialized
INFO - 2018-03-22 23:46:05 --> Router Class Initialized
INFO - 2018-03-22 23:46:05 --> Output Class Initialized
INFO - 2018-03-22 23:46:05 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:05 --> Input Class Initialized
INFO - 2018-03-22 23:46:05 --> Language Class Initialized
INFO - 2018-03-22 23:46:05 --> Loader Class Initialized
INFO - 2018-03-22 23:46:05 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:05 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:05 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:05 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:05 --> Model Class Initialized
INFO - 2018-03-22 23:46:05 --> Controller Class Initialized
INFO - 2018-03-22 23:46:05 --> Model Class Initialized
INFO - 2018-03-22 23:46:05 --> Model Class Initialized
INFO - 2018-03-22 23:46:05 --> Model Class Initialized
INFO - 2018-03-22 23:46:05 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:46:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:46:05 --> Final output sent to browser
DEBUG - 2018-03-22 23:46:05 --> Total execution time: 0.0686
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
ERROR - 2018-03-22 23:46:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:46:06 --> Config Class Initialized
INFO - 2018-03-22 23:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:06 --> URI Class Initialized
INFO - 2018-03-22 23:46:06 --> Router Class Initialized
INFO - 2018-03-22 23:46:06 --> Output Class Initialized
INFO - 2018-03-22 23:46:06 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:06 --> Input Class Initialized
INFO - 2018-03-22 23:46:06 --> Language Class Initialized
INFO - 2018-03-22 23:46:06 --> Loader Class Initialized
INFO - 2018-03-22 23:46:06 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:06 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:06 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:06 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:06 --> Model Class Initialized
INFO - 2018-03-22 23:46:06 --> Controller Class Initialized
INFO - 2018-03-22 23:46:06 --> Model Class Initialized
INFO - 2018-03-22 23:46:06 --> Model Class Initialized
INFO - 2018-03-22 23:46:06 --> Model Class Initialized
INFO - 2018-03-22 23:46:06 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:46:06 --> Query error: Unknown column 'proyecto_gasto_monto.cantidad_horas' in 'field list' - Invalid query: SELECT `proyecto_gasto`.`fecha_gasto`, SUM(`proyecto_gasto_monto`.`cantidad_horas`) AS `total_horas`, SUM(`proyecto_gasto_monto`.`cantidad_horas_extra`) AS `total_horas_extra`, SUM(`proyecto_gasto_monto`.`proyecto_gasto_monto`) AS `total_costo`
FROM `proyecto_gasto_mano_obra`
JOIN `proyecto_gasto` ON `proyecto_gasto`.`proyecto_gasto_id` = `proyecto_gasto_mano_obra`.`proyecto_gasto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto_mano_obra`.`estado_registro` = 1
GROUP BY `proyecto_gasto`.`proyecto_id`
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-03-22 23:46:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
INFO - 2018-03-22 23:46:53 --> Loader Class Initialized
INFO - 2018-03-22 23:46:53 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:53 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:53 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Controller Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:46:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:46:53 --> Final output sent to browser
DEBUG - 2018-03-22 23:46:53 --> Total execution time: 0.0825
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:46:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:46:53 --> Config Class Initialized
INFO - 2018-03-22 23:46:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:46:53 --> Utf8 Class Initialized
INFO - 2018-03-22 23:46:53 --> URI Class Initialized
INFO - 2018-03-22 23:46:53 --> Router Class Initialized
INFO - 2018-03-22 23:46:53 --> Output Class Initialized
INFO - 2018-03-22 23:46:53 --> Security Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:46:53 --> Input Class Initialized
INFO - 2018-03-22 23:46:53 --> Language Class Initialized
INFO - 2018-03-22 23:46:53 --> Loader Class Initialized
INFO - 2018-03-22 23:46:53 --> Helper loaded: url_helper
INFO - 2018-03-22 23:46:53 --> Helper loaded: form_helper
INFO - 2018-03-22 23:46:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:46:53 --> Form Validation Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Controller Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
INFO - 2018-03-22 23:46:53 --> Model Class Initialized
DEBUG - 2018-03-22 23:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Loader Class Initialized
INFO - 2018-03-22 23:47:11 --> Helper loaded: url_helper
INFO - 2018-03-22 23:47:11 --> Helper loaded: form_helper
INFO - 2018-03-22 23:47:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:47:11 --> Form Validation Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Controller Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:47:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:47:11 --> Final output sent to browser
DEBUG - 2018-03-22 23:47:11 --> Total execution time: 0.1495
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:47:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:47:11 --> Config Class Initialized
INFO - 2018-03-22 23:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-22 23:47:11 --> URI Class Initialized
INFO - 2018-03-22 23:47:11 --> Router Class Initialized
INFO - 2018-03-22 23:47:11 --> Output Class Initialized
INFO - 2018-03-22 23:47:11 --> Security Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:47:11 --> Input Class Initialized
INFO - 2018-03-22 23:47:11 --> Language Class Initialized
INFO - 2018-03-22 23:47:11 --> Loader Class Initialized
INFO - 2018-03-22 23:47:11 --> Helper loaded: url_helper
INFO - 2018-03-22 23:47:11 --> Helper loaded: form_helper
INFO - 2018-03-22 23:47:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:47:11 --> Form Validation Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Controller Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
INFO - 2018-03-22 23:47:11 --> Model Class Initialized
DEBUG - 2018-03-22 23:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:50:17 --> Config Class Initialized
INFO - 2018-03-22 23:50:17 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:50:17 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:17 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:17 --> URI Class Initialized
INFO - 2018-03-22 23:50:17 --> Router Class Initialized
INFO - 2018-03-22 23:50:17 --> Output Class Initialized
INFO - 2018-03-22 23:50:17 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:17 --> Input Class Initialized
INFO - 2018-03-22 23:50:17 --> Language Class Initialized
INFO - 2018-03-22 23:50:17 --> Loader Class Initialized
INFO - 2018-03-22 23:50:17 --> Helper loaded: url_helper
INFO - 2018-03-22 23:50:17 --> Helper loaded: form_helper
INFO - 2018-03-22 23:50:17 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:50:17 --> Form Validation Class Initialized
INFO - 2018-03-22 23:50:17 --> Model Class Initialized
INFO - 2018-03-22 23:50:17 --> Controller Class Initialized
INFO - 2018-03-22 23:50:17 --> Model Class Initialized
INFO - 2018-03-22 23:50:17 --> Model Class Initialized
INFO - 2018-03-22 23:50:17 --> Model Class Initialized
INFO - 2018-03-22 23:50:17 --> Model Class Initialized
DEBUG - 2018-03-22 23:50:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:50:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:50:17 --> Final output sent to browser
DEBUG - 2018-03-22 23:50:17 --> Total execution time: 0.1053
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
ERROR - 2018-03-22 23:50:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:50:18 --> Config Class Initialized
INFO - 2018-03-22 23:50:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:50:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:50:18 --> Utf8 Class Initialized
INFO - 2018-03-22 23:50:18 --> URI Class Initialized
INFO - 2018-03-22 23:50:18 --> Router Class Initialized
INFO - 2018-03-22 23:50:18 --> Output Class Initialized
INFO - 2018-03-22 23:50:18 --> Security Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:50:18 --> Input Class Initialized
INFO - 2018-03-22 23:50:18 --> Language Class Initialized
INFO - 2018-03-22 23:50:18 --> Loader Class Initialized
INFO - 2018-03-22 23:50:18 --> Helper loaded: url_helper
INFO - 2018-03-22 23:50:18 --> Helper loaded: form_helper
INFO - 2018-03-22 23:50:18 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:50:18 --> Form Validation Class Initialized
INFO - 2018-03-22 23:50:18 --> Model Class Initialized
INFO - 2018-03-22 23:50:18 --> Controller Class Initialized
INFO - 2018-03-22 23:50:18 --> Model Class Initialized
INFO - 2018-03-22 23:50:18 --> Model Class Initialized
INFO - 2018-03-22 23:50:18 --> Model Class Initialized
INFO - 2018-03-22 23:50:18 --> Model Class Initialized
DEBUG - 2018-03-22 23:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Loader Class Initialized
INFO - 2018-03-22 23:54:34 --> Helper loaded: url_helper
INFO - 2018-03-22 23:54:34 --> Helper loaded: form_helper
INFO - 2018-03-22 23:54:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:54:34 --> Form Validation Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Controller Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:54:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:54:34 --> Final output sent to browser
DEBUG - 2018-03-22 23:54:34 --> Total execution time: 0.1210
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
ERROR - 2018-03-22 23:54:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:54:34 --> Config Class Initialized
INFO - 2018-03-22 23:54:34 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:54:34 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:54:34 --> Utf8 Class Initialized
INFO - 2018-03-22 23:54:34 --> URI Class Initialized
INFO - 2018-03-22 23:54:34 --> Router Class Initialized
INFO - 2018-03-22 23:54:34 --> Output Class Initialized
INFO - 2018-03-22 23:54:34 --> Security Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:54:34 --> Input Class Initialized
INFO - 2018-03-22 23:54:34 --> Language Class Initialized
INFO - 2018-03-22 23:54:34 --> Loader Class Initialized
INFO - 2018-03-22 23:54:34 --> Helper loaded: url_helper
INFO - 2018-03-22 23:54:34 --> Helper loaded: form_helper
INFO - 2018-03-22 23:54:34 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:54:34 --> Form Validation Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Controller Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
INFO - 2018-03-22 23:54:34 --> Model Class Initialized
DEBUG - 2018-03-22 23:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:59:47 --> Config Class Initialized
INFO - 2018-03-22 23:59:47 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:59:47 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:47 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:47 --> URI Class Initialized
INFO - 2018-03-22 23:59:47 --> Router Class Initialized
INFO - 2018-03-22 23:59:47 --> Output Class Initialized
INFO - 2018-03-22 23:59:47 --> Security Class Initialized
DEBUG - 2018-03-22 23:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:47 --> Input Class Initialized
INFO - 2018-03-22 23:59:47 --> Language Class Initialized
INFO - 2018-03-22 23:59:47 --> Loader Class Initialized
INFO - 2018-03-22 23:59:47 --> Helper loaded: url_helper
INFO - 2018-03-22 23:59:47 --> Helper loaded: form_helper
INFO - 2018-03-22 23:59:47 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:59:47 --> Form Validation Class Initialized
INFO - 2018-03-22 23:59:47 --> Model Class Initialized
INFO - 2018-03-22 23:59:47 --> Controller Class Initialized
INFO - 2018-03-22 23:59:47 --> Model Class Initialized
INFO - 2018-03-22 23:59:47 --> Model Class Initialized
INFO - 2018-03-22 23:59:47 --> Model Class Initialized
INFO - 2018-03-22 23:59:47 --> Model Class Initialized
DEBUG - 2018-03-22 23:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-22 23:59:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-22 23:59:47 --> Final output sent to browser
DEBUG - 2018-03-22 23:59:47 --> Total execution time: 0.1477
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-22 23:59:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-22 23:59:48 --> Config Class Initialized
INFO - 2018-03-22 23:59:48 --> Hooks Class Initialized
DEBUG - 2018-03-22 23:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-22 23:59:48 --> Utf8 Class Initialized
INFO - 2018-03-22 23:59:48 --> URI Class Initialized
INFO - 2018-03-22 23:59:48 --> Router Class Initialized
INFO - 2018-03-22 23:59:48 --> Output Class Initialized
INFO - 2018-03-22 23:59:48 --> Security Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 23:59:48 --> Input Class Initialized
INFO - 2018-03-22 23:59:48 --> Language Class Initialized
INFO - 2018-03-22 23:59:48 --> Loader Class Initialized
INFO - 2018-03-22 23:59:48 --> Helper loaded: url_helper
INFO - 2018-03-22 23:59:48 --> Helper loaded: form_helper
INFO - 2018-03-22 23:59:48 --> Database Driver Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 23:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 23:59:48 --> Form Validation Class Initialized
INFO - 2018-03-22 23:59:48 --> Model Class Initialized
INFO - 2018-03-22 23:59:48 --> Controller Class Initialized
INFO - 2018-03-22 23:59:48 --> Model Class Initialized
INFO - 2018-03-22 23:59:48 --> Model Class Initialized
INFO - 2018-03-22 23:59:48 --> Model Class Initialized
INFO - 2018-03-22 23:59:48 --> Model Class Initialized
DEBUG - 2018-03-22 23:59:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-22 23:59:48 --> Query error: Not unique table/alias: 'proyecto_gasto' - Invalid query: SELECT `proyecto_gasto`.`fecha_gasto`, SUM(`proyecto_gasto_mano_obra`.`cantidad_horas`) AS `total_horas`, SUM(`proyecto_gasto_mano_obra`.`cantidad_horas_extra`) AS `total_horas_extra`, SUM(`proyecto_gasto_monto`.`proyecto_gasto_monto`) AS `total_costo`
FROM `proyecto_gasto`
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
JOIN `proyecto_gasto` ON `proyecto_gasto`.`proyecto_gasto_id` = `proyecto_gasto_mano_obra`.`proyecto_gasto_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto_mano_obra`.`estado_registro` = 1
AND `proyecto_gasto_monto`.`estado_registro` = 1
GROUP BY `proyecto_gasto`.`proyecto_gasto_id`
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-03-22 23:59:48 --> Language file loaded: language/english/db_lang.php
