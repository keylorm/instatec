<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-13 22:18:48 --> Config Class Initialized
INFO - 2018-03-13 22:18:48 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:18:48 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:18:48 --> Utf8 Class Initialized
INFO - 2018-03-13 22:18:48 --> URI Class Initialized
INFO - 2018-03-13 22:18:48 --> Router Class Initialized
INFO - 2018-03-13 22:18:48 --> Output Class Initialized
INFO - 2018-03-13 22:18:48 --> Security Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:18:48 --> Input Class Initialized
INFO - 2018-03-13 22:18:48 --> Language Class Initialized
INFO - 2018-03-13 22:18:48 --> Loader Class Initialized
INFO - 2018-03-13 22:18:48 --> Helper loaded: url_helper
INFO - 2018-03-13 22:18:48 --> Helper loaded: form_helper
INFO - 2018-03-13 22:18:48 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:18:48 --> Form Validation Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Controller Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:18:48 --> Config Class Initialized
INFO - 2018-03-13 22:18:48 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:18:48 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:18:48 --> Utf8 Class Initialized
INFO - 2018-03-13 22:18:48 --> URI Class Initialized
INFO - 2018-03-13 22:18:48 --> Router Class Initialized
INFO - 2018-03-13 22:18:48 --> Output Class Initialized
INFO - 2018-03-13 22:18:48 --> Security Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:18:48 --> Input Class Initialized
INFO - 2018-03-13 22:18:48 --> Language Class Initialized
INFO - 2018-03-13 22:18:48 --> Loader Class Initialized
INFO - 2018-03-13 22:18:48 --> Helper loaded: url_helper
INFO - 2018-03-13 22:18:48 --> Helper loaded: form_helper
INFO - 2018-03-13 22:18:48 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:18:48 --> Form Validation Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
INFO - 2018-03-13 22:18:48 --> Controller Class Initialized
INFO - 2018-03-13 22:18:48 --> Model Class Initialized
DEBUG - 2018-03-13 22:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:18:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:18:48 --> Final output sent to browser
DEBUG - 2018-03-13 22:18:48 --> Total execution time: 0.0403
INFO - 2018-03-13 22:18:50 --> Config Class Initialized
INFO - 2018-03-13 22:18:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:18:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:18:50 --> Utf8 Class Initialized
INFO - 2018-03-13 22:18:50 --> URI Class Initialized
INFO - 2018-03-13 22:18:50 --> Router Class Initialized
INFO - 2018-03-13 22:18:50 --> Output Class Initialized
INFO - 2018-03-13 22:18:50 --> Security Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:18:50 --> Input Class Initialized
INFO - 2018-03-13 22:18:50 --> Language Class Initialized
INFO - 2018-03-13 22:18:50 --> Loader Class Initialized
INFO - 2018-03-13 22:18:50 --> Helper loaded: url_helper
INFO - 2018-03-13 22:18:50 --> Helper loaded: form_helper
INFO - 2018-03-13 22:18:50 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:18:50 --> Form Validation Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Controller Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:18:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-13 22:18:50 --> Config Class Initialized
INFO - 2018-03-13 22:18:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:18:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:18:50 --> Utf8 Class Initialized
INFO - 2018-03-13 22:18:50 --> URI Class Initialized
DEBUG - 2018-03-13 22:18:50 --> No URI present. Default controller set.
INFO - 2018-03-13 22:18:50 --> Router Class Initialized
INFO - 2018-03-13 22:18:50 --> Output Class Initialized
INFO - 2018-03-13 22:18:50 --> Security Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:18:50 --> Input Class Initialized
INFO - 2018-03-13 22:18:50 --> Language Class Initialized
INFO - 2018-03-13 22:18:50 --> Loader Class Initialized
INFO - 2018-03-13 22:18:50 --> Helper loaded: url_helper
INFO - 2018-03-13 22:18:50 --> Helper loaded: form_helper
INFO - 2018-03-13 22:18:50 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:18:50 --> Form Validation Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Controller Class Initialized
INFO - 2018-03-13 22:18:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:18:50 --> Final output sent to browser
DEBUG - 2018-03-13 22:18:50 --> Total execution time: 0.0736
INFO - 2018-03-13 22:18:50 --> Config Class Initialized
INFO - 2018-03-13 22:18:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:18:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:18:50 --> Utf8 Class Initialized
INFO - 2018-03-13 22:18:50 --> URI Class Initialized
INFO - 2018-03-13 22:18:50 --> Router Class Initialized
INFO - 2018-03-13 22:18:50 --> Output Class Initialized
INFO - 2018-03-13 22:18:50 --> Security Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:18:50 --> Input Class Initialized
INFO - 2018-03-13 22:18:50 --> Language Class Initialized
INFO - 2018-03-13 22:18:50 --> Loader Class Initialized
INFO - 2018-03-13 22:18:50 --> Helper loaded: url_helper
INFO - 2018-03-13 22:18:50 --> Helper loaded: form_helper
INFO - 2018-03-13 22:18:50 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:18:50 --> Form Validation Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Controller Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
INFO - 2018-03-13 22:18:50 --> Model Class Initialized
DEBUG - 2018-03-13 22:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:19:38 --> Config Class Initialized
INFO - 2018-03-13 22:19:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:19:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:19:38 --> Utf8 Class Initialized
INFO - 2018-03-13 22:19:38 --> URI Class Initialized
INFO - 2018-03-13 22:19:38 --> Router Class Initialized
INFO - 2018-03-13 22:19:38 --> Output Class Initialized
INFO - 2018-03-13 22:19:38 --> Security Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:19:38 --> Input Class Initialized
INFO - 2018-03-13 22:19:38 --> Language Class Initialized
INFO - 2018-03-13 22:19:38 --> Loader Class Initialized
INFO - 2018-03-13 22:19:38 --> Helper loaded: url_helper
INFO - 2018-03-13 22:19:38 --> Helper loaded: form_helper
INFO - 2018-03-13 22:19:38 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:19:38 --> Form Validation Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Controller Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:19:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:19:38 --> Final output sent to browser
DEBUG - 2018-03-13 22:19:38 --> Total execution time: 0.0640
INFO - 2018-03-13 22:19:38 --> Config Class Initialized
INFO - 2018-03-13 22:19:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:19:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:19:38 --> Utf8 Class Initialized
INFO - 2018-03-13 22:19:38 --> URI Class Initialized
INFO - 2018-03-13 22:19:38 --> Router Class Initialized
INFO - 2018-03-13 22:19:38 --> Output Class Initialized
INFO - 2018-03-13 22:19:38 --> Security Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:19:38 --> Input Class Initialized
INFO - 2018-03-13 22:19:38 --> Language Class Initialized
INFO - 2018-03-13 22:19:38 --> Loader Class Initialized
INFO - 2018-03-13 22:19:38 --> Helper loaded: url_helper
INFO - 2018-03-13 22:19:38 --> Helper loaded: form_helper
INFO - 2018-03-13 22:19:38 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:19:38 --> Form Validation Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Controller Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
INFO - 2018-03-13 22:19:38 --> Model Class Initialized
DEBUG - 2018-03-13 22:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:19:39 --> Config Class Initialized
INFO - 2018-03-13 22:19:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:19:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:19:39 --> Utf8 Class Initialized
INFO - 2018-03-13 22:19:39 --> URI Class Initialized
INFO - 2018-03-13 22:19:39 --> Router Class Initialized
INFO - 2018-03-13 22:19:39 --> Output Class Initialized
INFO - 2018-03-13 22:19:39 --> Security Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:19:39 --> Input Class Initialized
INFO - 2018-03-13 22:19:39 --> Language Class Initialized
INFO - 2018-03-13 22:19:39 --> Loader Class Initialized
INFO - 2018-03-13 22:19:39 --> Helper loaded: url_helper
INFO - 2018-03-13 22:19:39 --> Helper loaded: form_helper
INFO - 2018-03-13 22:19:39 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:19:39 --> Form Validation Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Controller Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:19:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:19:39 --> Final output sent to browser
DEBUG - 2018-03-13 22:19:39 --> Total execution time: 0.0633
INFO - 2018-03-13 22:19:39 --> Config Class Initialized
INFO - 2018-03-13 22:19:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:19:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:19:39 --> Utf8 Class Initialized
INFO - 2018-03-13 22:19:39 --> URI Class Initialized
INFO - 2018-03-13 22:19:39 --> Router Class Initialized
INFO - 2018-03-13 22:19:39 --> Output Class Initialized
INFO - 2018-03-13 22:19:39 --> Security Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:19:39 --> Input Class Initialized
INFO - 2018-03-13 22:19:39 --> Language Class Initialized
INFO - 2018-03-13 22:19:39 --> Loader Class Initialized
INFO - 2018-03-13 22:19:39 --> Helper loaded: url_helper
INFO - 2018-03-13 22:19:39 --> Helper loaded: form_helper
INFO - 2018-03-13 22:19:39 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:19:39 --> Form Validation Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Controller Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
INFO - 2018-03-13 22:19:39 --> Model Class Initialized
DEBUG - 2018-03-13 22:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:26 --> Config Class Initialized
INFO - 2018-03-13 22:23:26 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:26 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:26 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:26 --> URI Class Initialized
INFO - 2018-03-13 22:23:26 --> Router Class Initialized
INFO - 2018-03-13 22:23:26 --> Output Class Initialized
INFO - 2018-03-13 22:23:26 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:26 --> Input Class Initialized
INFO - 2018-03-13 22:23:26 --> Language Class Initialized
INFO - 2018-03-13 22:23:26 --> Loader Class Initialized
INFO - 2018-03-13 22:23:26 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:26 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:26 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:26 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Controller Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:26 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:26 --> Total execution time: 0.0564
INFO - 2018-03-13 22:23:26 --> Config Class Initialized
INFO - 2018-03-13 22:23:26 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:26 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:26 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:26 --> URI Class Initialized
INFO - 2018-03-13 22:23:26 --> Router Class Initialized
INFO - 2018-03-13 22:23:26 --> Output Class Initialized
INFO - 2018-03-13 22:23:26 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:26 --> Input Class Initialized
INFO - 2018-03-13 22:23:26 --> Language Class Initialized
INFO - 2018-03-13 22:23:26 --> Loader Class Initialized
INFO - 2018-03-13 22:23:26 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:26 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:26 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:26 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Controller Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
INFO - 2018-03-13 22:23:26 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:35 --> Config Class Initialized
INFO - 2018-03-13 22:23:35 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:35 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:35 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:35 --> URI Class Initialized
INFO - 2018-03-13 22:23:35 --> Router Class Initialized
INFO - 2018-03-13 22:23:35 --> Output Class Initialized
INFO - 2018-03-13 22:23:35 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:35 --> Input Class Initialized
INFO - 2018-03-13 22:23:35 --> Language Class Initialized
INFO - 2018-03-13 22:23:35 --> Loader Class Initialized
INFO - 2018-03-13 22:23:35 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:35 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:35 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:35 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Controller Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:35 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:35 --> Total execution time: 0.0507
INFO - 2018-03-13 22:23:35 --> Config Class Initialized
INFO - 2018-03-13 22:23:35 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:35 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:35 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:35 --> URI Class Initialized
INFO - 2018-03-13 22:23:35 --> Router Class Initialized
INFO - 2018-03-13 22:23:35 --> Output Class Initialized
INFO - 2018-03-13 22:23:35 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:35 --> Input Class Initialized
INFO - 2018-03-13 22:23:35 --> Language Class Initialized
INFO - 2018-03-13 22:23:35 --> Loader Class Initialized
INFO - 2018-03-13 22:23:35 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:35 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:35 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:35 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Controller Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
INFO - 2018-03-13 22:23:35 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:38 --> Config Class Initialized
INFO - 2018-03-13 22:23:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:38 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:38 --> URI Class Initialized
INFO - 2018-03-13 22:23:38 --> Router Class Initialized
INFO - 2018-03-13 22:23:38 --> Output Class Initialized
INFO - 2018-03-13 22:23:38 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:38 --> Input Class Initialized
INFO - 2018-03-13 22:23:38 --> Language Class Initialized
INFO - 2018-03-13 22:23:38 --> Loader Class Initialized
INFO - 2018-03-13 22:23:38 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:38 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:38 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:38 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Controller Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:38 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:38 --> Total execution time: 0.0740
INFO - 2018-03-13 22:23:38 --> Config Class Initialized
INFO - 2018-03-13 22:23:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:38 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:38 --> URI Class Initialized
INFO - 2018-03-13 22:23:38 --> Router Class Initialized
INFO - 2018-03-13 22:23:38 --> Output Class Initialized
INFO - 2018-03-13 22:23:38 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:38 --> Input Class Initialized
INFO - 2018-03-13 22:23:38 --> Language Class Initialized
INFO - 2018-03-13 22:23:38 --> Loader Class Initialized
INFO - 2018-03-13 22:23:38 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:38 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:38 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:38 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Controller Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
INFO - 2018-03-13 22:23:38 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:42 --> Config Class Initialized
INFO - 2018-03-13 22:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:42 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:42 --> URI Class Initialized
INFO - 2018-03-13 22:23:42 --> Router Class Initialized
INFO - 2018-03-13 22:23:42 --> Output Class Initialized
INFO - 2018-03-13 22:23:42 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:42 --> Input Class Initialized
INFO - 2018-03-13 22:23:42 --> Language Class Initialized
INFO - 2018-03-13 22:23:42 --> Loader Class Initialized
INFO - 2018-03-13 22:23:42 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:42 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:42 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:42 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Controller Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:42 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:42 --> Total execution time: 0.0763
INFO - 2018-03-13 22:23:42 --> Config Class Initialized
INFO - 2018-03-13 22:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:42 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:42 --> URI Class Initialized
INFO - 2018-03-13 22:23:42 --> Router Class Initialized
INFO - 2018-03-13 22:23:42 --> Output Class Initialized
INFO - 2018-03-13 22:23:42 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:42 --> Input Class Initialized
INFO - 2018-03-13 22:23:42 --> Language Class Initialized
INFO - 2018-03-13 22:23:42 --> Loader Class Initialized
INFO - 2018-03-13 22:23:42 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:42 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:42 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:42 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Controller Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
INFO - 2018-03-13 22:23:42 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:49 --> Config Class Initialized
INFO - 2018-03-13 22:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:49 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:49 --> URI Class Initialized
INFO - 2018-03-13 22:23:49 --> Router Class Initialized
INFO - 2018-03-13 22:23:49 --> Output Class Initialized
INFO - 2018-03-13 22:23:49 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:49 --> Input Class Initialized
INFO - 2018-03-13 22:23:49 --> Language Class Initialized
INFO - 2018-03-13 22:23:49 --> Loader Class Initialized
INFO - 2018-03-13 22:23:49 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:49 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:49 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
INFO - 2018-03-13 22:23:49 --> Controller Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
INFO - 2018-03-13 22:23:49 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:50 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:50 --> Total execution time: 0.2680
INFO - 2018-03-13 22:23:50 --> Config Class Initialized
INFO - 2018-03-13 22:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:50 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:50 --> URI Class Initialized
INFO - 2018-03-13 22:23:50 --> Router Class Initialized
INFO - 2018-03-13 22:23:50 --> Output Class Initialized
INFO - 2018-03-13 22:23:50 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:50 --> Input Class Initialized
INFO - 2018-03-13 22:23:50 --> Language Class Initialized
INFO - 2018-03-13 22:23:50 --> Loader Class Initialized
INFO - 2018-03-13 22:23:50 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:50 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:50 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:50 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
INFO - 2018-03-13 22:23:50 --> Controller Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
INFO - 2018-03-13 22:23:50 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:52 --> Config Class Initialized
INFO - 2018-03-13 22:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:52 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:52 --> URI Class Initialized
INFO - 2018-03-13 22:23:52 --> Router Class Initialized
INFO - 2018-03-13 22:23:52 --> Output Class Initialized
INFO - 2018-03-13 22:23:52 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:52 --> Input Class Initialized
INFO - 2018-03-13 22:23:52 --> Language Class Initialized
INFO - 2018-03-13 22:23:52 --> Loader Class Initialized
INFO - 2018-03-13 22:23:52 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:52 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:52 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Controller Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:52 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:52 --> Total execution time: 0.0765
INFO - 2018-03-13 22:23:52 --> Config Class Initialized
INFO - 2018-03-13 22:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:52 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:52 --> URI Class Initialized
INFO - 2018-03-13 22:23:52 --> Router Class Initialized
INFO - 2018-03-13 22:23:52 --> Output Class Initialized
INFO - 2018-03-13 22:23:52 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:52 --> Input Class Initialized
INFO - 2018-03-13 22:23:52 --> Language Class Initialized
INFO - 2018-03-13 22:23:52 --> Loader Class Initialized
INFO - 2018-03-13 22:23:52 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:52 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:52 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Controller Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
INFO - 2018-03-13 22:23:52 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:55 --> Config Class Initialized
INFO - 2018-03-13 22:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:55 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:55 --> URI Class Initialized
INFO - 2018-03-13 22:23:55 --> Router Class Initialized
INFO - 2018-03-13 22:23:55 --> Output Class Initialized
INFO - 2018-03-13 22:23:55 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:55 --> Input Class Initialized
INFO - 2018-03-13 22:23:55 --> Language Class Initialized
INFO - 2018-03-13 22:23:55 --> Loader Class Initialized
INFO - 2018-03-13 22:23:55 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:55 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:55 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:55 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Controller Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:23:55 --> Final output sent to browser
DEBUG - 2018-03-13 22:23:55 --> Total execution time: 0.0790
INFO - 2018-03-13 22:23:55 --> Config Class Initialized
INFO - 2018-03-13 22:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:55 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:55 --> URI Class Initialized
INFO - 2018-03-13 22:23:55 --> Router Class Initialized
INFO - 2018-03-13 22:23:55 --> Output Class Initialized
INFO - 2018-03-13 22:23:55 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:55 --> Input Class Initialized
INFO - 2018-03-13 22:23:55 --> Language Class Initialized
INFO - 2018-03-13 22:23:55 --> Loader Class Initialized
INFO - 2018-03-13 22:23:55 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:55 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:55 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:55 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Controller Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
INFO - 2018-03-13 22:23:55 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:23:59 --> Config Class Initialized
INFO - 2018-03-13 22:23:59 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:23:59 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:23:59 --> Utf8 Class Initialized
INFO - 2018-03-13 22:23:59 --> URI Class Initialized
INFO - 2018-03-13 22:23:59 --> Router Class Initialized
INFO - 2018-03-13 22:23:59 --> Output Class Initialized
INFO - 2018-03-13 22:23:59 --> Security Class Initialized
DEBUG - 2018-03-13 22:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:23:59 --> Input Class Initialized
INFO - 2018-03-13 22:23:59 --> Language Class Initialized
INFO - 2018-03-13 22:23:59 --> Loader Class Initialized
INFO - 2018-03-13 22:23:59 --> Helper loaded: url_helper
INFO - 2018-03-13 22:23:59 --> Helper loaded: form_helper
INFO - 2018-03-13 22:23:59 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:23:59 --> Form Validation Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
INFO - 2018-03-13 22:23:59 --> Controller Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
INFO - 2018-03-13 22:23:59 --> Model Class Initialized
DEBUG - 2018-03-13 22:23:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:08 --> Config Class Initialized
INFO - 2018-03-13 22:24:08 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:08 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:08 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:08 --> URI Class Initialized
INFO - 2018-03-13 22:24:08 --> Router Class Initialized
INFO - 2018-03-13 22:24:08 --> Output Class Initialized
INFO - 2018-03-13 22:24:08 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:08 --> Input Class Initialized
INFO - 2018-03-13 22:24:08 --> Language Class Initialized
INFO - 2018-03-13 22:24:08 --> Loader Class Initialized
INFO - 2018-03-13 22:24:08 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:08 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:08 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:08 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
INFO - 2018-03-13 22:24:08 --> Controller Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
INFO - 2018-03-13 22:24:08 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:24:09 --> Final output sent to browser
DEBUG - 2018-03-13 22:24:09 --> Total execution time: 0.2286
INFO - 2018-03-13 22:24:09 --> Config Class Initialized
INFO - 2018-03-13 22:24:09 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:09 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:09 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:09 --> URI Class Initialized
INFO - 2018-03-13 22:24:09 --> Router Class Initialized
INFO - 2018-03-13 22:24:09 --> Output Class Initialized
INFO - 2018-03-13 22:24:09 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:09 --> Input Class Initialized
INFO - 2018-03-13 22:24:09 --> Language Class Initialized
INFO - 2018-03-13 22:24:09 --> Loader Class Initialized
INFO - 2018-03-13 22:24:09 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:09 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:09 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:09 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
INFO - 2018-03-13 22:24:09 --> Controller Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
INFO - 2018-03-13 22:24:09 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:14 --> Config Class Initialized
INFO - 2018-03-13 22:24:14 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:14 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:14 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:14 --> URI Class Initialized
INFO - 2018-03-13 22:24:14 --> Router Class Initialized
INFO - 2018-03-13 22:24:14 --> Output Class Initialized
INFO - 2018-03-13 22:24:14 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:14 --> Input Class Initialized
INFO - 2018-03-13 22:24:14 --> Language Class Initialized
INFO - 2018-03-13 22:24:14 --> Loader Class Initialized
INFO - 2018-03-13 22:24:14 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:14 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:14 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:14 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
INFO - 2018-03-13 22:24:14 --> Controller Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
INFO - 2018-03-13 22:24:14 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:18 --> Config Class Initialized
INFO - 2018-03-13 22:24:18 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:18 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:18 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:18 --> URI Class Initialized
INFO - 2018-03-13 22:24:18 --> Router Class Initialized
INFO - 2018-03-13 22:24:18 --> Output Class Initialized
INFO - 2018-03-13 22:24:18 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:18 --> Input Class Initialized
INFO - 2018-03-13 22:24:18 --> Language Class Initialized
INFO - 2018-03-13 22:24:18 --> Loader Class Initialized
INFO - 2018-03-13 22:24:18 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:18 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:18 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:18 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
INFO - 2018-03-13 22:24:18 --> Controller Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
INFO - 2018-03-13 22:24:18 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:20 --> Config Class Initialized
INFO - 2018-03-13 22:24:20 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:20 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:20 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:20 --> URI Class Initialized
INFO - 2018-03-13 22:24:20 --> Router Class Initialized
INFO - 2018-03-13 22:24:20 --> Output Class Initialized
INFO - 2018-03-13 22:24:20 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:20 --> Input Class Initialized
INFO - 2018-03-13 22:24:20 --> Language Class Initialized
INFO - 2018-03-13 22:24:20 --> Loader Class Initialized
INFO - 2018-03-13 22:24:20 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:20 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:20 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:20 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Controller Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:24:20 --> Final output sent to browser
DEBUG - 2018-03-13 22:24:20 --> Total execution time: 0.0700
INFO - 2018-03-13 22:24:20 --> Config Class Initialized
INFO - 2018-03-13 22:24:20 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:20 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:20 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:20 --> URI Class Initialized
INFO - 2018-03-13 22:24:20 --> Router Class Initialized
INFO - 2018-03-13 22:24:20 --> Output Class Initialized
INFO - 2018-03-13 22:24:20 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:20 --> Input Class Initialized
INFO - 2018-03-13 22:24:20 --> Language Class Initialized
INFO - 2018-03-13 22:24:20 --> Loader Class Initialized
INFO - 2018-03-13 22:24:20 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:20 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:20 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:20 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Controller Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
INFO - 2018-03-13 22:24:20 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:21 --> Config Class Initialized
INFO - 2018-03-13 22:24:21 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:21 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:21 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:21 --> URI Class Initialized
INFO - 2018-03-13 22:24:21 --> Router Class Initialized
INFO - 2018-03-13 22:24:21 --> Output Class Initialized
INFO - 2018-03-13 22:24:21 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:21 --> Input Class Initialized
INFO - 2018-03-13 22:24:21 --> Language Class Initialized
INFO - 2018-03-13 22:24:21 --> Loader Class Initialized
INFO - 2018-03-13 22:24:21 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:21 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:21 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:21 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Controller Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:24:21 --> Final output sent to browser
DEBUG - 2018-03-13 22:24:21 --> Total execution time: 0.0591
INFO - 2018-03-13 22:24:21 --> Config Class Initialized
INFO - 2018-03-13 22:24:21 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:21 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:21 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:21 --> URI Class Initialized
INFO - 2018-03-13 22:24:21 --> Router Class Initialized
INFO - 2018-03-13 22:24:21 --> Output Class Initialized
INFO - 2018-03-13 22:24:21 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:21 --> Input Class Initialized
INFO - 2018-03-13 22:24:21 --> Language Class Initialized
INFO - 2018-03-13 22:24:21 --> Loader Class Initialized
INFO - 2018-03-13 22:24:21 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:21 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:21 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:21 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Controller Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
INFO - 2018-03-13 22:24:21 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:41 --> Config Class Initialized
INFO - 2018-03-13 22:24:41 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:41 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:41 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:41 --> URI Class Initialized
INFO - 2018-03-13 22:24:41 --> Router Class Initialized
INFO - 2018-03-13 22:24:41 --> Output Class Initialized
INFO - 2018-03-13 22:24:41 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:41 --> Input Class Initialized
INFO - 2018-03-13 22:24:41 --> Language Class Initialized
INFO - 2018-03-13 22:24:41 --> Loader Class Initialized
INFO - 2018-03-13 22:24:41 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:41 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:41 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:41 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Controller Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:24:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:24:41 --> Final output sent to browser
DEBUG - 2018-03-13 22:24:41 --> Total execution time: 0.0829
INFO - 2018-03-13 22:24:41 --> Config Class Initialized
INFO - 2018-03-13 22:24:41 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:24:41 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:24:41 --> Utf8 Class Initialized
INFO - 2018-03-13 22:24:41 --> URI Class Initialized
INFO - 2018-03-13 22:24:41 --> Router Class Initialized
INFO - 2018-03-13 22:24:41 --> Output Class Initialized
INFO - 2018-03-13 22:24:41 --> Security Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:24:41 --> Input Class Initialized
INFO - 2018-03-13 22:24:41 --> Language Class Initialized
INFO - 2018-03-13 22:24:41 --> Loader Class Initialized
INFO - 2018-03-13 22:24:41 --> Helper loaded: url_helper
INFO - 2018-03-13 22:24:41 --> Helper loaded: form_helper
INFO - 2018-03-13 22:24:41 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:24:41 --> Form Validation Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Controller Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
INFO - 2018-03-13 22:24:41 --> Model Class Initialized
DEBUG - 2018-03-13 22:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:29:47 --> Config Class Initialized
INFO - 2018-03-13 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:29:47 --> Utf8 Class Initialized
INFO - 2018-03-13 22:29:47 --> URI Class Initialized
INFO - 2018-03-13 22:29:47 --> Router Class Initialized
INFO - 2018-03-13 22:29:47 --> Output Class Initialized
INFO - 2018-03-13 22:29:47 --> Security Class Initialized
DEBUG - 2018-03-13 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:29:47 --> Input Class Initialized
INFO - 2018-03-13 22:29:47 --> Language Class Initialized
INFO - 2018-03-13 22:29:47 --> Loader Class Initialized
INFO - 2018-03-13 22:29:47 --> Helper loaded: url_helper
INFO - 2018-03-13 22:29:47 --> Helper loaded: form_helper
INFO - 2018-03-13 22:29:47 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:29:47 --> Form Validation Class Initialized
INFO - 2018-03-13 22:29:47 --> Model Class Initialized
INFO - 2018-03-13 22:29:47 --> Controller Class Initialized
INFO - 2018-03-13 22:29:47 --> Model Class Initialized
INFO - 2018-03-13 22:29:47 --> Model Class Initialized
INFO - 2018-03-13 22:29:47 --> Model Class Initialized
INFO - 2018-03-13 22:29:47 --> Model Class Initialized
DEBUG - 2018-03-13 22:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:29:48 --> Final output sent to browser
DEBUG - 2018-03-13 22:29:48 --> Total execution time: 1.0945
INFO - 2018-03-13 22:32:20 --> Config Class Initialized
INFO - 2018-03-13 22:32:20 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:32:20 --> Utf8 Class Initialized
INFO - 2018-03-13 22:32:20 --> URI Class Initialized
INFO - 2018-03-13 22:32:20 --> Router Class Initialized
INFO - 2018-03-13 22:32:20 --> Output Class Initialized
INFO - 2018-03-13 22:32:20 --> Security Class Initialized
DEBUG - 2018-03-13 22:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:32:20 --> Input Class Initialized
INFO - 2018-03-13 22:32:20 --> Language Class Initialized
INFO - 2018-03-13 22:32:20 --> Loader Class Initialized
INFO - 2018-03-13 22:32:20 --> Helper loaded: url_helper
INFO - 2018-03-13 22:32:20 --> Helper loaded: form_helper
INFO - 2018-03-13 22:32:20 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:32:20 --> Form Validation Class Initialized
INFO - 2018-03-13 22:32:20 --> Model Class Initialized
INFO - 2018-03-13 22:32:20 --> Controller Class Initialized
INFO - 2018-03-13 22:32:20 --> Model Class Initialized
INFO - 2018-03-13 22:32:20 --> Model Class Initialized
INFO - 2018-03-13 22:32:20 --> Model Class Initialized
INFO - 2018-03-13 22:32:20 --> Model Class Initialized
DEBUG - 2018-03-13 22:32:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:32:20 --> Final output sent to browser
DEBUG - 2018-03-13 22:32:20 --> Total execution time: 0.1347
INFO - 2018-03-13 22:32:41 --> Config Class Initialized
INFO - 2018-03-13 22:32:41 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:32:41 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:32:41 --> Utf8 Class Initialized
INFO - 2018-03-13 22:32:41 --> URI Class Initialized
INFO - 2018-03-13 22:32:41 --> Router Class Initialized
INFO - 2018-03-13 22:32:41 --> Output Class Initialized
INFO - 2018-03-13 22:32:41 --> Security Class Initialized
DEBUG - 2018-03-13 22:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:32:41 --> Input Class Initialized
INFO - 2018-03-13 22:32:41 --> Language Class Initialized
INFO - 2018-03-13 22:32:41 --> Loader Class Initialized
INFO - 2018-03-13 22:32:41 --> Helper loaded: url_helper
INFO - 2018-03-13 22:32:41 --> Helper loaded: form_helper
INFO - 2018-03-13 22:32:41 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:32:41 --> Form Validation Class Initialized
INFO - 2018-03-13 22:32:41 --> Model Class Initialized
INFO - 2018-03-13 22:32:41 --> Controller Class Initialized
INFO - 2018-03-13 22:32:41 --> Model Class Initialized
INFO - 2018-03-13 22:32:41 --> Model Class Initialized
INFO - 2018-03-13 22:32:41 --> Model Class Initialized
INFO - 2018-03-13 22:32:41 --> Model Class Initialized
DEBUG - 2018-03-13 22:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:32:41 --> Final output sent to browser
DEBUG - 2018-03-13 22:32:41 --> Total execution time: 0.1406
INFO - 2018-03-13 22:36:57 --> Config Class Initialized
INFO - 2018-03-13 22:36:57 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:36:57 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:36:57 --> Utf8 Class Initialized
INFO - 2018-03-13 22:36:57 --> URI Class Initialized
INFO - 2018-03-13 22:36:57 --> Router Class Initialized
INFO - 2018-03-13 22:36:57 --> Output Class Initialized
INFO - 2018-03-13 22:36:57 --> Security Class Initialized
DEBUG - 2018-03-13 22:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:36:57 --> Input Class Initialized
INFO - 2018-03-13 22:36:57 --> Language Class Initialized
INFO - 2018-03-13 22:36:57 --> Loader Class Initialized
INFO - 2018-03-13 22:36:57 --> Helper loaded: url_helper
INFO - 2018-03-13 22:36:57 --> Helper loaded: form_helper
INFO - 2018-03-13 22:36:57 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:36:57 --> Form Validation Class Initialized
INFO - 2018-03-13 22:36:57 --> Model Class Initialized
INFO - 2018-03-13 22:36:57 --> Controller Class Initialized
INFO - 2018-03-13 22:36:57 --> Model Class Initialized
INFO - 2018-03-13 22:36:57 --> Model Class Initialized
INFO - 2018-03-13 22:36:57 --> Model Class Initialized
INFO - 2018-03-13 22:36:57 --> Model Class Initialized
DEBUG - 2018-03-13 22:36:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:36:57 --> Final output sent to browser
DEBUG - 2018-03-13 22:36:57 --> Total execution time: 0.1536
INFO - 2018-03-13 22:37:54 --> Config Class Initialized
INFO - 2018-03-13 22:37:54 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:37:54 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:37:54 --> Utf8 Class Initialized
INFO - 2018-03-13 22:37:54 --> URI Class Initialized
INFO - 2018-03-13 22:37:54 --> Router Class Initialized
INFO - 2018-03-13 22:37:54 --> Output Class Initialized
INFO - 2018-03-13 22:37:54 --> Security Class Initialized
DEBUG - 2018-03-13 22:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:37:54 --> Input Class Initialized
INFO - 2018-03-13 22:37:54 --> Language Class Initialized
INFO - 2018-03-13 22:37:54 --> Loader Class Initialized
INFO - 2018-03-13 22:37:54 --> Helper loaded: url_helper
INFO - 2018-03-13 22:37:54 --> Helper loaded: form_helper
INFO - 2018-03-13 22:37:54 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:37:54 --> Form Validation Class Initialized
INFO - 2018-03-13 22:37:54 --> Model Class Initialized
INFO - 2018-03-13 22:37:54 --> Controller Class Initialized
INFO - 2018-03-13 22:37:54 --> Model Class Initialized
INFO - 2018-03-13 22:37:54 --> Model Class Initialized
INFO - 2018-03-13 22:37:54 --> Model Class Initialized
INFO - 2018-03-13 22:37:54 --> Model Class Initialized
DEBUG - 2018-03-13 22:37:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:37:54 --> Final output sent to browser
DEBUG - 2018-03-13 22:37:54 --> Total execution time: 0.1491
INFO - 2018-03-13 22:38:57 --> Config Class Initialized
INFO - 2018-03-13 22:38:57 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:38:57 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:38:57 --> Utf8 Class Initialized
INFO - 2018-03-13 22:38:57 --> URI Class Initialized
INFO - 2018-03-13 22:38:57 --> Router Class Initialized
INFO - 2018-03-13 22:38:57 --> Output Class Initialized
INFO - 2018-03-13 22:38:57 --> Security Class Initialized
DEBUG - 2018-03-13 22:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:38:57 --> Input Class Initialized
INFO - 2018-03-13 22:38:57 --> Language Class Initialized
INFO - 2018-03-13 22:38:57 --> Loader Class Initialized
INFO - 2018-03-13 22:38:57 --> Helper loaded: url_helper
INFO - 2018-03-13 22:38:57 --> Helper loaded: form_helper
INFO - 2018-03-13 22:38:57 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:38:57 --> Form Validation Class Initialized
INFO - 2018-03-13 22:38:57 --> Model Class Initialized
INFO - 2018-03-13 22:38:57 --> Controller Class Initialized
INFO - 2018-03-13 22:38:57 --> Model Class Initialized
INFO - 2018-03-13 22:38:57 --> Model Class Initialized
INFO - 2018-03-13 22:38:57 --> Model Class Initialized
INFO - 2018-03-13 22:38:57 --> Model Class Initialized
DEBUG - 2018-03-13 22:38:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:38:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:38:57 --> Final output sent to browser
DEBUG - 2018-03-13 22:38:57 --> Total execution time: 0.3509
INFO - 2018-03-13 22:57:34 --> Config Class Initialized
INFO - 2018-03-13 22:57:34 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:57:34 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:57:34 --> Utf8 Class Initialized
INFO - 2018-03-13 22:57:34 --> URI Class Initialized
INFO - 2018-03-13 22:57:34 --> Router Class Initialized
INFO - 2018-03-13 22:57:34 --> Output Class Initialized
INFO - 2018-03-13 22:57:34 --> Security Class Initialized
DEBUG - 2018-03-13 22:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:57:34 --> Input Class Initialized
INFO - 2018-03-13 22:57:34 --> Language Class Initialized
INFO - 2018-03-13 22:57:34 --> Loader Class Initialized
INFO - 2018-03-13 22:57:34 --> Helper loaded: url_helper
INFO - 2018-03-13 22:57:34 --> Helper loaded: form_helper
INFO - 2018-03-13 22:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-13 22:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 22:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 22:57:34 --> Form Validation Class Initialized
INFO - 2018-03-13 22:57:34 --> Model Class Initialized
INFO - 2018-03-13 22:57:34 --> Controller Class Initialized
INFO - 2018-03-13 22:57:34 --> Model Class Initialized
INFO - 2018-03-13 22:57:34 --> Model Class Initialized
INFO - 2018-03-13 22:57:34 --> Model Class Initialized
INFO - 2018-03-13 22:57:34 --> Model Class Initialized
DEBUG - 2018-03-13 22:57:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-13 22:57:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-13 22:57:34 --> Final output sent to browser
DEBUG - 2018-03-13 22:57:34 --> Total execution time: 0.0594
INFO - 2018-03-13 22:57:35 --> Config Class Initialized
INFO - 2018-03-13 22:57:35 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:57:35 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:57:35 --> Utf8 Class Initialized
INFO - 2018-03-13 22:57:35 --> URI Class Initialized
INFO - 2018-03-13 22:57:35 --> Router Class Initialized
INFO - 2018-03-13 22:57:35 --> Output Class Initialized
INFO - 2018-03-13 22:57:35 --> Security Class Initialized
DEBUG - 2018-03-13 22:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:57:35 --> Input Class Initialized
INFO - 2018-03-13 22:57:35 --> Language Class Initialized
ERROR - 2018-03-13 22:57:35 --> 404 Page Not Found: Reportes/horas-por-trabajador
INFO - 2018-03-13 22:57:37 --> Config Class Initialized
INFO - 2018-03-13 22:57:37 --> Hooks Class Initialized
DEBUG - 2018-03-13 22:57:37 --> UTF-8 Support Enabled
INFO - 2018-03-13 22:57:37 --> Utf8 Class Initialized
INFO - 2018-03-13 22:57:37 --> URI Class Initialized
INFO - 2018-03-13 22:57:37 --> Router Class Initialized
INFO - 2018-03-13 22:57:37 --> Output Class Initialized
INFO - 2018-03-13 22:57:37 --> Security Class Initialized
DEBUG - 2018-03-13 22:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 22:57:37 --> Input Class Initialized
INFO - 2018-03-13 22:57:37 --> Language Class Initialized
ERROR - 2018-03-13 22:57:37 --> 404 Page Not Found: Reportes/horas-por-trabajador
