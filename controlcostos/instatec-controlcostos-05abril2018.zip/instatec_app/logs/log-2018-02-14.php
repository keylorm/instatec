<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-14 23:43:59 --> Config Class Initialized
INFO - 2018-02-14 23:43:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:43:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:43:59 --> Utf8 Class Initialized
INFO - 2018-02-14 23:43:59 --> URI Class Initialized
INFO - 2018-02-14 23:43:59 --> Router Class Initialized
INFO - 2018-02-14 23:43:59 --> Output Class Initialized
INFO - 2018-02-14 23:43:59 --> Security Class Initialized
DEBUG - 2018-02-14 23:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:43:59 --> Input Class Initialized
INFO - 2018-02-14 23:43:59 --> Language Class Initialized
INFO - 2018-02-14 23:43:59 --> Loader Class Initialized
INFO - 2018-02-14 23:43:59 --> Helper loaded: url_helper
INFO - 2018-02-14 23:43:59 --> Helper loaded: form_helper
INFO - 2018-02-14 23:43:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:43:59 --> Form Validation Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
INFO - 2018-02-14 23:43:59 --> Controller Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
INFO - 2018-02-14 23:43:59 --> Model Class Initialized
DEBUG - 2018-02-14 23:43:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:43:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:43:59 --> Final output sent to browser
DEBUG - 2018-02-14 23:43:59 --> Total execution time: 0.1000
INFO - 2018-02-14 23:44:00 --> Config Class Initialized
INFO - 2018-02-14 23:44:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:44:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:44:00 --> Utf8 Class Initialized
INFO - 2018-02-14 23:44:00 --> URI Class Initialized
INFO - 2018-02-14 23:44:00 --> Router Class Initialized
INFO - 2018-02-14 23:44:00 --> Output Class Initialized
INFO - 2018-02-14 23:44:00 --> Security Class Initialized
DEBUG - 2018-02-14 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:44:00 --> Input Class Initialized
INFO - 2018-02-14 23:44:00 --> Language Class Initialized
INFO - 2018-02-14 23:44:00 --> Loader Class Initialized
INFO - 2018-02-14 23:44:00 --> Helper loaded: url_helper
INFO - 2018-02-14 23:44:00 --> Helper loaded: form_helper
INFO - 2018-02-14 23:44:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:44:00 --> Form Validation Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
INFO - 2018-02-14 23:44:00 --> Controller Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
INFO - 2018-02-14 23:44:00 --> Model Class Initialized
DEBUG - 2018-02-14 23:44:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:44:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:44:00 --> Final output sent to browser
DEBUG - 2018-02-14 23:44:00 --> Total execution time: 0.0681
INFO - 2018-02-14 23:44:01 --> Config Class Initialized
INFO - 2018-02-14 23:44:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:44:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:44:01 --> Utf8 Class Initialized
INFO - 2018-02-14 23:44:01 --> URI Class Initialized
INFO - 2018-02-14 23:44:01 --> Router Class Initialized
INFO - 2018-02-14 23:44:01 --> Output Class Initialized
INFO - 2018-02-14 23:44:01 --> Security Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:44:01 --> Input Class Initialized
INFO - 2018-02-14 23:44:01 --> Language Class Initialized
INFO - 2018-02-14 23:44:01 --> Loader Class Initialized
INFO - 2018-02-14 23:44:01 --> Helper loaded: url_helper
INFO - 2018-02-14 23:44:01 --> Helper loaded: form_helper
INFO - 2018-02-14 23:44:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:44:01 --> Form Validation Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Controller Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:44:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:44:01 --> Final output sent to browser
DEBUG - 2018-02-14 23:44:01 --> Total execution time: 0.0567
INFO - 2018-02-14 23:44:01 --> Config Class Initialized
INFO - 2018-02-14 23:44:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:44:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:44:01 --> Utf8 Class Initialized
INFO - 2018-02-14 23:44:01 --> URI Class Initialized
INFO - 2018-02-14 23:44:01 --> Router Class Initialized
INFO - 2018-02-14 23:44:01 --> Output Class Initialized
INFO - 2018-02-14 23:44:01 --> Security Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:44:01 --> Input Class Initialized
INFO - 2018-02-14 23:44:01 --> Language Class Initialized
INFO - 2018-02-14 23:44:01 --> Loader Class Initialized
INFO - 2018-02-14 23:44:01 --> Helper loaded: url_helper
INFO - 2018-02-14 23:44:01 --> Helper loaded: form_helper
INFO - 2018-02-14 23:44:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:44:01 --> Form Validation Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Controller Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
INFO - 2018-02-14 23:44:01 --> Model Class Initialized
DEBUG - 2018-02-14 23:44:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:44:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:44:01 --> Final output sent to browser
DEBUG - 2018-02-14 23:44:01 --> Total execution time: 0.0623
INFO - 2018-02-14 23:55:41 --> Config Class Initialized
INFO - 2018-02-14 23:55:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:41 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:41 --> URI Class Initialized
INFO - 2018-02-14 23:55:41 --> Router Class Initialized
INFO - 2018-02-14 23:55:41 --> Output Class Initialized
INFO - 2018-02-14 23:55:41 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:41 --> Input Class Initialized
INFO - 2018-02-14 23:55:41 --> Language Class Initialized
INFO - 2018-02-14 23:55:41 --> Loader Class Initialized
INFO - 2018-02-14 23:55:41 --> Helper loaded: url_helper
INFO - 2018-02-14 23:55:41 --> Helper loaded: form_helper
INFO - 2018-02-14 23:55:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:55:41 --> Form Validation Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
INFO - 2018-02-14 23:55:41 --> Controller Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
INFO - 2018-02-14 23:55:41 --> Model Class Initialized
DEBUG - 2018-02-14 23:55:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:55:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:55:41 --> Final output sent to browser
DEBUG - 2018-02-14 23:55:41 --> Total execution time: 0.1394
INFO - 2018-02-14 23:55:43 --> Config Class Initialized
INFO - 2018-02-14 23:55:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:43 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:43 --> URI Class Initialized
INFO - 2018-02-14 23:55:43 --> Router Class Initialized
INFO - 2018-02-14 23:55:43 --> Output Class Initialized
INFO - 2018-02-14 23:55:43 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:43 --> Input Class Initialized
INFO - 2018-02-14 23:55:43 --> Language Class Initialized
INFO - 2018-02-14 23:55:43 --> Loader Class Initialized
INFO - 2018-02-14 23:55:43 --> Helper loaded: url_helper
INFO - 2018-02-14 23:55:43 --> Helper loaded: form_helper
INFO - 2018-02-14 23:55:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:55:43 --> Form Validation Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
INFO - 2018-02-14 23:55:43 --> Controller Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
INFO - 2018-02-14 23:55:43 --> Model Class Initialized
DEBUG - 2018-02-14 23:55:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:55:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:55:44 --> Final output sent to browser
DEBUG - 2018-02-14 23:55:44 --> Total execution time: 0.0672
INFO - 2018-02-14 23:55:44 --> Config Class Initialized
INFO - 2018-02-14 23:55:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:44 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:44 --> URI Class Initialized
INFO - 2018-02-14 23:55:44 --> Router Class Initialized
INFO - 2018-02-14 23:55:44 --> Output Class Initialized
INFO - 2018-02-14 23:55:44 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:44 --> Input Class Initialized
INFO - 2018-02-14 23:55:44 --> Language Class Initialized
INFO - 2018-02-14 23:55:44 --> Loader Class Initialized
INFO - 2018-02-14 23:55:44 --> Helper loaded: url_helper
INFO - 2018-02-14 23:55:44 --> Helper loaded: form_helper
INFO - 2018-02-14 23:55:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:55:44 --> Form Validation Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
INFO - 2018-02-14 23:55:44 --> Controller Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
INFO - 2018-02-14 23:55:44 --> Model Class Initialized
DEBUG - 2018-02-14 23:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:55:46 --> Config Class Initialized
INFO - 2018-02-14 23:55:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:46 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:46 --> URI Class Initialized
INFO - 2018-02-14 23:55:46 --> Router Class Initialized
INFO - 2018-02-14 23:55:46 --> Output Class Initialized
INFO - 2018-02-14 23:55:46 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:46 --> Input Class Initialized
INFO - 2018-02-14 23:55:46 --> Language Class Initialized
INFO - 2018-02-14 23:55:46 --> Loader Class Initialized
INFO - 2018-02-14 23:55:46 --> Helper loaded: url_helper
INFO - 2018-02-14 23:55:46 --> Helper loaded: form_helper
INFO - 2018-02-14 23:55:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:55:46 --> Form Validation Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Controller Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:55:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:55:46 --> Final output sent to browser
DEBUG - 2018-02-14 23:55:46 --> Total execution time: 0.0792
INFO - 2018-02-14 23:55:46 --> Config Class Initialized
INFO - 2018-02-14 23:55:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:46 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:46 --> URI Class Initialized
INFO - 2018-02-14 23:55:46 --> Router Class Initialized
INFO - 2018-02-14 23:55:46 --> Output Class Initialized
INFO - 2018-02-14 23:55:46 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:46 --> Input Class Initialized
INFO - 2018-02-14 23:55:46 --> Language Class Initialized
INFO - 2018-02-14 23:55:46 --> Loader Class Initialized
INFO - 2018-02-14 23:55:46 --> Helper loaded: url_helper
INFO - 2018-02-14 23:55:46 --> Helper loaded: form_helper
INFO - 2018-02-14 23:55:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:55:46 --> Form Validation Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Controller Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
INFO - 2018-02-14 23:55:46 --> Model Class Initialized
DEBUG - 2018-02-14 23:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:55:55 --> Config Class Initialized
INFO - 2018-02-14 23:55:55 --> Hooks Class Initialized
INFO - 2018-02-14 23:55:55 --> Config Class Initialized
INFO - 2018-02-14 23:55:55 --> Hooks Class Initialized
INFO - 2018-02-14 23:55:55 --> Config Class Initialized
INFO - 2018-02-14 23:55:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:55 --> Utf8 Class Initialized
DEBUG - 2018-02-14 23:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:55 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:55 --> URI Class Initialized
DEBUG - 2018-02-14 23:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:55:55 --> Utf8 Class Initialized
INFO - 2018-02-14 23:55:55 --> URI Class Initialized
INFO - 2018-02-14 23:55:55 --> URI Class Initialized
INFO - 2018-02-14 23:55:55 --> Router Class Initialized
INFO - 2018-02-14 23:55:55 --> Router Class Initialized
INFO - 2018-02-14 23:55:55 --> Router Class Initialized
INFO - 2018-02-14 23:55:55 --> Output Class Initialized
INFO - 2018-02-14 23:55:55 --> Output Class Initialized
INFO - 2018-02-14 23:55:55 --> Output Class Initialized
INFO - 2018-02-14 23:55:55 --> Security Class Initialized
INFO - 2018-02-14 23:55:55 --> Security Class Initialized
INFO - 2018-02-14 23:55:55 --> Security Class Initialized
DEBUG - 2018-02-14 23:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:55 --> Input Class Initialized
DEBUG - 2018-02-14 23:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-14 23:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:55:55 --> Input Class Initialized
INFO - 2018-02-14 23:55:55 --> Language Class Initialized
INFO - 2018-02-14 23:55:55 --> Input Class Initialized
INFO - 2018-02-14 23:55:55 --> Language Class Initialized
INFO - 2018-02-14 23:55:55 --> Language Class Initialized
ERROR - 2018-02-14 23:55:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-14 23:55:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-14 23:55:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Loader Class Initialized
INFO - 2018-02-14 23:56:07 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:07 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:07 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
INFO - 2018-02-14 23:56:07 --> Controller Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
INFO - 2018-02-14 23:56:07 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:07 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:07 --> Total execution time: 0.0498
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
ERROR - 2018-02-14 23:56:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-14 23:56:07 --> Config Class Initialized
INFO - 2018-02-14 23:56:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:07 --> URI Class Initialized
INFO - 2018-02-14 23:56:07 --> Router Class Initialized
INFO - 2018-02-14 23:56:07 --> Output Class Initialized
INFO - 2018-02-14 23:56:07 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:07 --> Input Class Initialized
INFO - 2018-02-14 23:56:07 --> Language Class Initialized
INFO - 2018-02-14 23:56:07 --> Loader Class Initialized
INFO - 2018-02-14 23:56:07 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:07 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:08 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
INFO - 2018-02-14 23:56:08 --> Controller Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
INFO - 2018-02-14 23:56:08 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:24 --> Config Class Initialized
INFO - 2018-02-14 23:56:24 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:24 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:24 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:24 --> URI Class Initialized
INFO - 2018-02-14 23:56:24 --> Router Class Initialized
INFO - 2018-02-14 23:56:24 --> Output Class Initialized
INFO - 2018-02-14 23:56:24 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:24 --> Input Class Initialized
INFO - 2018-02-14 23:56:24 --> Language Class Initialized
INFO - 2018-02-14 23:56:24 --> Loader Class Initialized
INFO - 2018-02-14 23:56:24 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:24 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:24 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:25 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Controller Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:25 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:25 --> Total execution time: 0.0698
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-14 23:56:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-14 23:56:25 --> Config Class Initialized
INFO - 2018-02-14 23:56:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:25 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:25 --> URI Class Initialized
INFO - 2018-02-14 23:56:25 --> Router Class Initialized
INFO - 2018-02-14 23:56:25 --> Output Class Initialized
INFO - 2018-02-14 23:56:25 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:25 --> Input Class Initialized
INFO - 2018-02-14 23:56:25 --> Language Class Initialized
INFO - 2018-02-14 23:56:25 --> Loader Class Initialized
INFO - 2018-02-14 23:56:25 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:25 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:25 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:25 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Controller Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
INFO - 2018-02-14 23:56:25 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:33 --> Config Class Initialized
INFO - 2018-02-14 23:56:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:33 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:33 --> URI Class Initialized
INFO - 2018-02-14 23:56:33 --> Router Class Initialized
INFO - 2018-02-14 23:56:33 --> Output Class Initialized
INFO - 2018-02-14 23:56:33 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:33 --> Input Class Initialized
INFO - 2018-02-14 23:56:33 --> Language Class Initialized
INFO - 2018-02-14 23:56:33 --> Loader Class Initialized
INFO - 2018-02-14 23:56:33 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:33 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:33 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Controller Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:33 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:33 --> Total execution time: 0.1439
INFO - 2018-02-14 23:56:33 --> Config Class Initialized
INFO - 2018-02-14 23:56:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:33 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:33 --> URI Class Initialized
INFO - 2018-02-14 23:56:33 --> Router Class Initialized
INFO - 2018-02-14 23:56:33 --> Output Class Initialized
INFO - 2018-02-14 23:56:33 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:33 --> Input Class Initialized
INFO - 2018-02-14 23:56:33 --> Language Class Initialized
INFO - 2018-02-14 23:56:33 --> Loader Class Initialized
INFO - 2018-02-14 23:56:33 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:33 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:33 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Controller Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
INFO - 2018-02-14 23:56:33 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:36 --> Config Class Initialized
INFO - 2018-02-14 23:56:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:36 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:36 --> URI Class Initialized
INFO - 2018-02-14 23:56:36 --> Router Class Initialized
INFO - 2018-02-14 23:56:36 --> Output Class Initialized
INFO - 2018-02-14 23:56:36 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:36 --> Input Class Initialized
INFO - 2018-02-14 23:56:36 --> Language Class Initialized
INFO - 2018-02-14 23:56:36 --> Loader Class Initialized
INFO - 2018-02-14 23:56:36 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:36 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:36 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Controller Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:36 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:36 --> Total execution time: 0.0453
INFO - 2018-02-14 23:56:36 --> Config Class Initialized
INFO - 2018-02-14 23:56:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:36 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:36 --> URI Class Initialized
INFO - 2018-02-14 23:56:36 --> Router Class Initialized
INFO - 2018-02-14 23:56:36 --> Output Class Initialized
INFO - 2018-02-14 23:56:36 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:36 --> Input Class Initialized
INFO - 2018-02-14 23:56:36 --> Language Class Initialized
INFO - 2018-02-14 23:56:36 --> Loader Class Initialized
INFO - 2018-02-14 23:56:36 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:36 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:36 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Controller Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
INFO - 2018-02-14 23:56:36 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:37 --> Config Class Initialized
INFO - 2018-02-14 23:56:37 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:37 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:37 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:37 --> URI Class Initialized
INFO - 2018-02-14 23:56:37 --> Router Class Initialized
INFO - 2018-02-14 23:56:37 --> Output Class Initialized
INFO - 2018-02-14 23:56:37 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:37 --> Input Class Initialized
INFO - 2018-02-14 23:56:37 --> Language Class Initialized
INFO - 2018-02-14 23:56:37 --> Loader Class Initialized
INFO - 2018-02-14 23:56:37 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:37 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:37 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:37 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
INFO - 2018-02-14 23:56:37 --> Controller Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
INFO - 2018-02-14 23:56:37 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:37 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:37 --> Total execution time: 0.0588
INFO - 2018-02-14 23:56:38 --> Config Class Initialized
INFO - 2018-02-14 23:56:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:38 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:38 --> URI Class Initialized
INFO - 2018-02-14 23:56:38 --> Router Class Initialized
INFO - 2018-02-14 23:56:38 --> Output Class Initialized
INFO - 2018-02-14 23:56:38 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:38 --> Input Class Initialized
INFO - 2018-02-14 23:56:38 --> Language Class Initialized
INFO - 2018-02-14 23:56:38 --> Loader Class Initialized
INFO - 2018-02-14 23:56:38 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:38 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:38 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
INFO - 2018-02-14 23:56:38 --> Controller Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
INFO - 2018-02-14 23:56:38 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:41 --> Config Class Initialized
INFO - 2018-02-14 23:56:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:41 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:41 --> URI Class Initialized
INFO - 2018-02-14 23:56:41 --> Router Class Initialized
INFO - 2018-02-14 23:56:41 --> Output Class Initialized
INFO - 2018-02-14 23:56:41 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:41 --> Input Class Initialized
INFO - 2018-02-14 23:56:41 --> Language Class Initialized
INFO - 2018-02-14 23:56:41 --> Loader Class Initialized
INFO - 2018-02-14 23:56:41 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:41 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:41 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Controller Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:41 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:41 --> Total execution time: 0.0602
INFO - 2018-02-14 23:56:41 --> Config Class Initialized
INFO - 2018-02-14 23:56:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:41 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:41 --> URI Class Initialized
INFO - 2018-02-14 23:56:41 --> Router Class Initialized
INFO - 2018-02-14 23:56:41 --> Output Class Initialized
INFO - 2018-02-14 23:56:41 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:41 --> Input Class Initialized
INFO - 2018-02-14 23:56:41 --> Language Class Initialized
INFO - 2018-02-14 23:56:41 --> Loader Class Initialized
INFO - 2018-02-14 23:56:41 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:41 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:41 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Controller Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
INFO - 2018-02-14 23:56:41 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:42 --> Config Class Initialized
INFO - 2018-02-14 23:56:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:42 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:42 --> URI Class Initialized
INFO - 2018-02-14 23:56:42 --> Router Class Initialized
INFO - 2018-02-14 23:56:42 --> Output Class Initialized
INFO - 2018-02-14 23:56:42 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:42 --> Input Class Initialized
INFO - 2018-02-14 23:56:42 --> Language Class Initialized
INFO - 2018-02-14 23:56:42 --> Loader Class Initialized
INFO - 2018-02-14 23:56:42 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:42 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:42 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
INFO - 2018-02-14 23:56:42 --> Controller Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
INFO - 2018-02-14 23:56:42 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:42 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:42 --> Total execution time: 0.0667
INFO - 2018-02-14 23:56:43 --> Config Class Initialized
INFO - 2018-02-14 23:56:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:43 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:43 --> URI Class Initialized
INFO - 2018-02-14 23:56:43 --> Router Class Initialized
INFO - 2018-02-14 23:56:43 --> Output Class Initialized
INFO - 2018-02-14 23:56:43 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:43 --> Input Class Initialized
INFO - 2018-02-14 23:56:43 --> Language Class Initialized
INFO - 2018-02-14 23:56:43 --> Loader Class Initialized
INFO - 2018-02-14 23:56:43 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:43 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:43 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
INFO - 2018-02-14 23:56:43 --> Controller Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
INFO - 2018-02-14 23:56:43 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:48 --> Config Class Initialized
INFO - 2018-02-14 23:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:48 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:48 --> URI Class Initialized
INFO - 2018-02-14 23:56:48 --> Router Class Initialized
INFO - 2018-02-14 23:56:48 --> Output Class Initialized
INFO - 2018-02-14 23:56:48 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:48 --> Input Class Initialized
INFO - 2018-02-14 23:56:48 --> Language Class Initialized
INFO - 2018-02-14 23:56:48 --> Loader Class Initialized
INFO - 2018-02-14 23:56:48 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:48 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:48 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Controller Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:48 --> Config Class Initialized
INFO - 2018-02-14 23:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:48 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:48 --> URI Class Initialized
INFO - 2018-02-14 23:56:48 --> Router Class Initialized
INFO - 2018-02-14 23:56:48 --> Output Class Initialized
INFO - 2018-02-14 23:56:48 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:48 --> Input Class Initialized
INFO - 2018-02-14 23:56:48 --> Language Class Initialized
INFO - 2018-02-14 23:56:48 --> Loader Class Initialized
INFO - 2018-02-14 23:56:48 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:48 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:48 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Controller Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
INFO - 2018-02-14 23:56:48 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:57 --> Config Class Initialized
INFO - 2018-02-14 23:56:57 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:57 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:57 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:57 --> URI Class Initialized
INFO - 2018-02-14 23:56:57 --> Router Class Initialized
INFO - 2018-02-14 23:56:57 --> Output Class Initialized
INFO - 2018-02-14 23:56:57 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:57 --> Input Class Initialized
INFO - 2018-02-14 23:56:57 --> Language Class Initialized
INFO - 2018-02-14 23:56:57 --> Loader Class Initialized
INFO - 2018-02-14 23:56:57 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:57 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:57 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:57 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Controller Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:56:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:56:57 --> Final output sent to browser
DEBUG - 2018-02-14 23:56:57 --> Total execution time: 0.0641
INFO - 2018-02-14 23:56:57 --> Config Class Initialized
INFO - 2018-02-14 23:56:57 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:56:57 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:56:57 --> Utf8 Class Initialized
INFO - 2018-02-14 23:56:57 --> URI Class Initialized
INFO - 2018-02-14 23:56:57 --> Router Class Initialized
INFO - 2018-02-14 23:56:57 --> Output Class Initialized
INFO - 2018-02-14 23:56:57 --> Security Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:56:57 --> Input Class Initialized
INFO - 2018-02-14 23:56:57 --> Language Class Initialized
INFO - 2018-02-14 23:56:57 --> Loader Class Initialized
INFO - 2018-02-14 23:56:57 --> Helper loaded: url_helper
INFO - 2018-02-14 23:56:57 --> Helper loaded: form_helper
INFO - 2018-02-14 23:56:57 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:56:57 --> Form Validation Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Controller Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
INFO - 2018-02-14 23:56:57 --> Model Class Initialized
DEBUG - 2018-02-14 23:56:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:01 --> Config Class Initialized
INFO - 2018-02-14 23:57:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:01 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:01 --> URI Class Initialized
INFO - 2018-02-14 23:57:01 --> Router Class Initialized
INFO - 2018-02-14 23:57:01 --> Output Class Initialized
INFO - 2018-02-14 23:57:01 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:01 --> Input Class Initialized
INFO - 2018-02-14 23:57:01 --> Language Class Initialized
INFO - 2018-02-14 23:57:01 --> Loader Class Initialized
INFO - 2018-02-14 23:57:01 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:01 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:01 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Controller Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:57:01 --> Final output sent to browser
DEBUG - 2018-02-14 23:57:01 --> Total execution time: 0.0695
INFO - 2018-02-14 23:57:01 --> Config Class Initialized
INFO - 2018-02-14 23:57:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:01 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:01 --> URI Class Initialized
INFO - 2018-02-14 23:57:01 --> Router Class Initialized
INFO - 2018-02-14 23:57:01 --> Output Class Initialized
INFO - 2018-02-14 23:57:01 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:01 --> Input Class Initialized
INFO - 2018-02-14 23:57:01 --> Language Class Initialized
INFO - 2018-02-14 23:57:01 --> Loader Class Initialized
INFO - 2018-02-14 23:57:01 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:01 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:01 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Controller Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
INFO - 2018-02-14 23:57:01 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:04 --> Config Class Initialized
INFO - 2018-02-14 23:57:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:04 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:04 --> URI Class Initialized
INFO - 2018-02-14 23:57:04 --> Router Class Initialized
INFO - 2018-02-14 23:57:04 --> Output Class Initialized
INFO - 2018-02-14 23:57:04 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:04 --> Input Class Initialized
INFO - 2018-02-14 23:57:04 --> Language Class Initialized
INFO - 2018-02-14 23:57:04 --> Loader Class Initialized
INFO - 2018-02-14 23:57:04 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:04 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:04 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Controller Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:57:04 --> Final output sent to browser
DEBUG - 2018-02-14 23:57:04 --> Total execution time: 0.0550
INFO - 2018-02-14 23:57:04 --> Config Class Initialized
INFO - 2018-02-14 23:57:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:04 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:04 --> URI Class Initialized
INFO - 2018-02-14 23:57:04 --> Router Class Initialized
INFO - 2018-02-14 23:57:04 --> Output Class Initialized
INFO - 2018-02-14 23:57:04 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:04 --> Input Class Initialized
INFO - 2018-02-14 23:57:04 --> Language Class Initialized
INFO - 2018-02-14 23:57:04 --> Loader Class Initialized
INFO - 2018-02-14 23:57:04 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:04 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:04 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Controller Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
INFO - 2018-02-14 23:57:04 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:05 --> Config Class Initialized
INFO - 2018-02-14 23:57:05 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:05 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:05 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:05 --> URI Class Initialized
INFO - 2018-02-14 23:57:05 --> Router Class Initialized
INFO - 2018-02-14 23:57:05 --> Output Class Initialized
INFO - 2018-02-14 23:57:05 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:05 --> Input Class Initialized
INFO - 2018-02-14 23:57:05 --> Language Class Initialized
INFO - 2018-02-14 23:57:05 --> Loader Class Initialized
INFO - 2018-02-14 23:57:05 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:05 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:05 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:05 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
INFO - 2018-02-14 23:57:05 --> Controller Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
INFO - 2018-02-14 23:57:05 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:57:05 --> Final output sent to browser
DEBUG - 2018-02-14 23:57:05 --> Total execution time: 0.0609
INFO - 2018-02-14 23:57:06 --> Config Class Initialized
INFO - 2018-02-14 23:57:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:06 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:06 --> URI Class Initialized
INFO - 2018-02-14 23:57:06 --> Router Class Initialized
INFO - 2018-02-14 23:57:06 --> Output Class Initialized
INFO - 2018-02-14 23:57:06 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:06 --> Input Class Initialized
INFO - 2018-02-14 23:57:06 --> Language Class Initialized
INFO - 2018-02-14 23:57:06 --> Loader Class Initialized
INFO - 2018-02-14 23:57:06 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:06 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:06 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
INFO - 2018-02-14 23:57:06 --> Controller Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
INFO - 2018-02-14 23:57:06 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:07 --> Config Class Initialized
INFO - 2018-02-14 23:57:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:57:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:57:07 --> Utf8 Class Initialized
INFO - 2018-02-14 23:57:07 --> URI Class Initialized
INFO - 2018-02-14 23:57:07 --> Router Class Initialized
INFO - 2018-02-14 23:57:07 --> Output Class Initialized
INFO - 2018-02-14 23:57:07 --> Security Class Initialized
DEBUG - 2018-02-14 23:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:57:07 --> Input Class Initialized
INFO - 2018-02-14 23:57:07 --> Language Class Initialized
INFO - 2018-02-14 23:57:07 --> Loader Class Initialized
INFO - 2018-02-14 23:57:07 --> Helper loaded: url_helper
INFO - 2018-02-14 23:57:07 --> Helper loaded: form_helper
INFO - 2018-02-14 23:57:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:57:07 --> Form Validation Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
INFO - 2018-02-14 23:57:07 --> Controller Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
INFO - 2018-02-14 23:57:07 --> Model Class Initialized
DEBUG - 2018-02-14 23:57:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:57:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:57:07 --> Final output sent to browser
DEBUG - 2018-02-14 23:57:07 --> Total execution time: 0.0678
INFO - 2018-02-14 23:59:37 --> Config Class Initialized
INFO - 2018-02-14 23:59:37 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:37 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:37 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:37 --> URI Class Initialized
INFO - 2018-02-14 23:59:37 --> Router Class Initialized
INFO - 2018-02-14 23:59:37 --> Output Class Initialized
INFO - 2018-02-14 23:59:37 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:37 --> Input Class Initialized
INFO - 2018-02-14 23:59:37 --> Language Class Initialized
INFO - 2018-02-14 23:59:37 --> Loader Class Initialized
INFO - 2018-02-14 23:59:37 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:37 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:37 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:37 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
INFO - 2018-02-14 23:59:37 --> Controller Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
INFO - 2018-02-14 23:59:37 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:59:37 --> Final output sent to browser
DEBUG - 2018-02-14 23:59:37 --> Total execution time: 0.0950
INFO - 2018-02-14 23:59:38 --> Config Class Initialized
INFO - 2018-02-14 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:38 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:38 --> URI Class Initialized
INFO - 2018-02-14 23:59:38 --> Router Class Initialized
INFO - 2018-02-14 23:59:38 --> Output Class Initialized
INFO - 2018-02-14 23:59:38 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:38 --> Input Class Initialized
INFO - 2018-02-14 23:59:38 --> Language Class Initialized
INFO - 2018-02-14 23:59:38 --> Loader Class Initialized
INFO - 2018-02-14 23:59:38 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:38 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:38 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
INFO - 2018-02-14 23:59:38 --> Controller Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
INFO - 2018-02-14 23:59:38 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:40 --> Config Class Initialized
INFO - 2018-02-14 23:59:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:40 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:40 --> URI Class Initialized
INFO - 2018-02-14 23:59:40 --> Router Class Initialized
INFO - 2018-02-14 23:59:40 --> Output Class Initialized
INFO - 2018-02-14 23:59:40 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:40 --> Input Class Initialized
INFO - 2018-02-14 23:59:40 --> Language Class Initialized
INFO - 2018-02-14 23:59:40 --> Loader Class Initialized
INFO - 2018-02-14 23:59:40 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:40 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:40 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Controller Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:59:40 --> Final output sent to browser
DEBUG - 2018-02-14 23:59:40 --> Total execution time: 0.0963
INFO - 2018-02-14 23:59:40 --> Config Class Initialized
INFO - 2018-02-14 23:59:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:40 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:40 --> URI Class Initialized
INFO - 2018-02-14 23:59:40 --> Router Class Initialized
INFO - 2018-02-14 23:59:40 --> Output Class Initialized
INFO - 2018-02-14 23:59:40 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:40 --> Input Class Initialized
INFO - 2018-02-14 23:59:40 --> Language Class Initialized
INFO - 2018-02-14 23:59:40 --> Loader Class Initialized
INFO - 2018-02-14 23:59:40 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:40 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:40 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Controller Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
INFO - 2018-02-14 23:59:40 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:44 --> Config Class Initialized
INFO - 2018-02-14 23:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:44 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:44 --> URI Class Initialized
INFO - 2018-02-14 23:59:44 --> Router Class Initialized
INFO - 2018-02-14 23:59:44 --> Output Class Initialized
INFO - 2018-02-14 23:59:44 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:44 --> Input Class Initialized
INFO - 2018-02-14 23:59:44 --> Language Class Initialized
INFO - 2018-02-14 23:59:44 --> Loader Class Initialized
INFO - 2018-02-14 23:59:44 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:44 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:44 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Controller Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:59:44 --> Final output sent to browser
DEBUG - 2018-02-14 23:59:44 --> Total execution time: 0.0615
INFO - 2018-02-14 23:59:44 --> Config Class Initialized
INFO - 2018-02-14 23:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:44 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:44 --> URI Class Initialized
INFO - 2018-02-14 23:59:44 --> Router Class Initialized
INFO - 2018-02-14 23:59:44 --> Output Class Initialized
INFO - 2018-02-14 23:59:44 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:44 --> Input Class Initialized
INFO - 2018-02-14 23:59:44 --> Language Class Initialized
INFO - 2018-02-14 23:59:44 --> Loader Class Initialized
INFO - 2018-02-14 23:59:44 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:44 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:44 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Controller Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
INFO - 2018-02-14 23:59:44 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:45 --> Config Class Initialized
INFO - 2018-02-14 23:59:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:45 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:45 --> URI Class Initialized
INFO - 2018-02-14 23:59:45 --> Router Class Initialized
INFO - 2018-02-14 23:59:45 --> Output Class Initialized
INFO - 2018-02-14 23:59:45 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:45 --> Input Class Initialized
INFO - 2018-02-14 23:59:45 --> Language Class Initialized
INFO - 2018-02-14 23:59:45 --> Loader Class Initialized
INFO - 2018-02-14 23:59:45 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:45 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:45 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Controller Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 23:59:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-14 23:59:45 --> Final output sent to browser
DEBUG - 2018-02-14 23:59:45 --> Total execution time: 0.0572
INFO - 2018-02-14 23:59:45 --> Config Class Initialized
INFO - 2018-02-14 23:59:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 23:59:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 23:59:45 --> Utf8 Class Initialized
INFO - 2018-02-14 23:59:45 --> URI Class Initialized
INFO - 2018-02-14 23:59:45 --> Router Class Initialized
INFO - 2018-02-14 23:59:45 --> Output Class Initialized
INFO - 2018-02-14 23:59:45 --> Security Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 23:59:45 --> Input Class Initialized
INFO - 2018-02-14 23:59:45 --> Language Class Initialized
INFO - 2018-02-14 23:59:45 --> Loader Class Initialized
INFO - 2018-02-14 23:59:45 --> Helper loaded: url_helper
INFO - 2018-02-14 23:59:45 --> Helper loaded: form_helper
INFO - 2018-02-14 23:59:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 23:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 23:59:45 --> Form Validation Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Controller Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
INFO - 2018-02-14 23:59:45 --> Model Class Initialized
DEBUG - 2018-02-14 23:59:45 --> Form_validation class already loaded. Second attempt ignored.
