<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-01 00:02:28 --> Config Class Initialized
INFO - 2018-04-01 00:02:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:28 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:28 --> URI Class Initialized
INFO - 2018-04-01 00:02:28 --> Router Class Initialized
INFO - 2018-04-01 00:02:28 --> Output Class Initialized
INFO - 2018-04-01 00:02:28 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:28 --> Input Class Initialized
INFO - 2018-04-01 00:02:28 --> Language Class Initialized
INFO - 2018-04-01 00:02:28 --> Loader Class Initialized
INFO - 2018-04-01 00:02:28 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:28 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:28 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:28 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:28 --> Model Class Initialized
INFO - 2018-04-01 00:02:28 --> Controller Class Initialized
INFO - 2018-04-01 00:02:28 --> Model Class Initialized
INFO - 2018-04-01 00:02:28 --> Model Class Initialized
INFO - 2018-04-01 00:02:28 --> Model Class Initialized
INFO - 2018-04-01 00:02:28 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 00:02:28 --> Final output sent to browser
DEBUG - 2018-04-01 00:02:28 --> Total execution time: 0.0775
INFO - 2018-04-01 00:02:30 --> Config Class Initialized
INFO - 2018-04-01 00:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:30 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:30 --> URI Class Initialized
INFO - 2018-04-01 00:02:30 --> Router Class Initialized
INFO - 2018-04-01 00:02:30 --> Output Class Initialized
INFO - 2018-04-01 00:02:30 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:30 --> Input Class Initialized
INFO - 2018-04-01 00:02:30 --> Language Class Initialized
INFO - 2018-04-01 00:02:30 --> Loader Class Initialized
INFO - 2018-04-01 00:02:30 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:30 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:30 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Controller Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 00:02:30 --> Final output sent to browser
DEBUG - 2018-04-01 00:02:30 --> Total execution time: 0.0729
INFO - 2018-04-01 00:02:30 --> Config Class Initialized
INFO - 2018-04-01 00:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:30 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:30 --> URI Class Initialized
INFO - 2018-04-01 00:02:30 --> Router Class Initialized
INFO - 2018-04-01 00:02:30 --> Output Class Initialized
INFO - 2018-04-01 00:02:30 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:30 --> Input Class Initialized
INFO - 2018-04-01 00:02:30 --> Language Class Initialized
INFO - 2018-04-01 00:02:30 --> Loader Class Initialized
INFO - 2018-04-01 00:02:30 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:30 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:30 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Controller Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
INFO - 2018-04-01 00:02:30 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:33 --> Config Class Initialized
INFO - 2018-04-01 00:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:33 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:33 --> URI Class Initialized
INFO - 2018-04-01 00:02:33 --> Router Class Initialized
INFO - 2018-04-01 00:02:33 --> Output Class Initialized
INFO - 2018-04-01 00:02:33 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:33 --> Input Class Initialized
INFO - 2018-04-01 00:02:33 --> Language Class Initialized
INFO - 2018-04-01 00:02:33 --> Loader Class Initialized
INFO - 2018-04-01 00:02:33 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:33 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:33 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:33 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Controller Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 00:02:33 --> Final output sent to browser
DEBUG - 2018-04-01 00:02:33 --> Total execution time: 0.0986
INFO - 2018-04-01 00:02:33 --> Config Class Initialized
INFO - 2018-04-01 00:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:33 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:33 --> URI Class Initialized
INFO - 2018-04-01 00:02:33 --> Router Class Initialized
INFO - 2018-04-01 00:02:33 --> Output Class Initialized
INFO - 2018-04-01 00:02:33 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:33 --> Input Class Initialized
INFO - 2018-04-01 00:02:33 --> Language Class Initialized
INFO - 2018-04-01 00:02:33 --> Loader Class Initialized
INFO - 2018-04-01 00:02:33 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:33 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:33 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:33 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Controller Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
INFO - 2018-04-01 00:02:33 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:36 --> Config Class Initialized
INFO - 2018-04-01 00:02:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:36 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:36 --> URI Class Initialized
INFO - 2018-04-01 00:02:36 --> Router Class Initialized
INFO - 2018-04-01 00:02:36 --> Output Class Initialized
INFO - 2018-04-01 00:02:36 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:36 --> Input Class Initialized
INFO - 2018-04-01 00:02:36 --> Language Class Initialized
INFO - 2018-04-01 00:02:36 --> Loader Class Initialized
INFO - 2018-04-01 00:02:36 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:36 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:36 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Controller Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 00:02:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 00:02:36 --> Final output sent to browser
DEBUG - 2018-04-01 00:02:36 --> Total execution time: 0.0715
INFO - 2018-04-01 00:02:36 --> Config Class Initialized
INFO - 2018-04-01 00:02:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 00:02:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 00:02:36 --> Utf8 Class Initialized
INFO - 2018-04-01 00:02:36 --> URI Class Initialized
INFO - 2018-04-01 00:02:36 --> Router Class Initialized
INFO - 2018-04-01 00:02:36 --> Output Class Initialized
INFO - 2018-04-01 00:02:36 --> Security Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 00:02:36 --> Input Class Initialized
INFO - 2018-04-01 00:02:36 --> Language Class Initialized
INFO - 2018-04-01 00:02:36 --> Loader Class Initialized
INFO - 2018-04-01 00:02:36 --> Helper loaded: url_helper
INFO - 2018-04-01 00:02:36 --> Helper loaded: form_helper
INFO - 2018-04-01 00:02:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 00:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 00:02:36 --> Form Validation Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Controller Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
INFO - 2018-04-01 00:02:36 --> Model Class Initialized
DEBUG - 2018-04-01 00:02:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:46 --> Config Class Initialized
INFO - 2018-04-01 17:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:46 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:46 --> URI Class Initialized
INFO - 2018-04-01 17:14:46 --> Router Class Initialized
INFO - 2018-04-01 17:14:46 --> Output Class Initialized
INFO - 2018-04-01 17:14:46 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:46 --> Input Class Initialized
INFO - 2018-04-01 17:14:46 --> Language Class Initialized
INFO - 2018-04-01 17:14:46 --> Loader Class Initialized
INFO - 2018-04-01 17:14:46 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:46 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:46 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:46 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
INFO - 2018-04-01 17:14:46 --> Controller Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:46 --> Config Class Initialized
INFO - 2018-04-01 17:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:46 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:46 --> URI Class Initialized
INFO - 2018-04-01 17:14:46 --> Router Class Initialized
INFO - 2018-04-01 17:14:46 --> Output Class Initialized
INFO - 2018-04-01 17:14:46 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:46 --> Input Class Initialized
INFO - 2018-04-01 17:14:46 --> Language Class Initialized
INFO - 2018-04-01 17:14:46 --> Loader Class Initialized
INFO - 2018-04-01 17:14:46 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:46 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:46 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:46 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
INFO - 2018-04-01 17:14:46 --> Controller Class Initialized
INFO - 2018-04-01 17:14:46 --> Model Class Initialized
DEBUG - 2018-04-01 17:14:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:14:46 --> Final output sent to browser
DEBUG - 2018-04-01 17:14:46 --> Total execution time: 0.0401
INFO - 2018-04-01 17:14:48 --> Config Class Initialized
INFO - 2018-04-01 17:14:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:48 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:48 --> URI Class Initialized
INFO - 2018-04-01 17:14:48 --> Router Class Initialized
INFO - 2018-04-01 17:14:48 --> Output Class Initialized
INFO - 2018-04-01 17:14:48 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:48 --> Input Class Initialized
INFO - 2018-04-01 17:14:48 --> Language Class Initialized
INFO - 2018-04-01 17:14:48 --> Loader Class Initialized
INFO - 2018-04-01 17:14:48 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:48 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:48 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Controller Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-01 17:14:48 --> Config Class Initialized
INFO - 2018-04-01 17:14:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:48 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:48 --> URI Class Initialized
DEBUG - 2018-04-01 17:14:48 --> No URI present. Default controller set.
INFO - 2018-04-01 17:14:48 --> Router Class Initialized
INFO - 2018-04-01 17:14:48 --> Output Class Initialized
INFO - 2018-04-01 17:14:48 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:48 --> Input Class Initialized
INFO - 2018-04-01 17:14:48 --> Language Class Initialized
INFO - 2018-04-01 17:14:48 --> Loader Class Initialized
INFO - 2018-04-01 17:14:48 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:48 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:48 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Controller Class Initialized
INFO - 2018-04-01 17:14:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:14:48 --> Final output sent to browser
DEBUG - 2018-04-01 17:14:48 --> Total execution time: 0.0375
INFO - 2018-04-01 17:14:48 --> Config Class Initialized
INFO - 2018-04-01 17:14:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:48 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:48 --> URI Class Initialized
INFO - 2018-04-01 17:14:48 --> Router Class Initialized
INFO - 2018-04-01 17:14:48 --> Output Class Initialized
INFO - 2018-04-01 17:14:48 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:48 --> Input Class Initialized
INFO - 2018-04-01 17:14:48 --> Language Class Initialized
INFO - 2018-04-01 17:14:48 --> Loader Class Initialized
INFO - 2018-04-01 17:14:48 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:48 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:48 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Controller Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
INFO - 2018-04-01 17:14:48 --> Model Class Initialized
DEBUG - 2018-04-01 17:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:49 --> Config Class Initialized
INFO - 2018-04-01 17:14:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:14:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:14:49 --> Utf8 Class Initialized
INFO - 2018-04-01 17:14:49 --> URI Class Initialized
INFO - 2018-04-01 17:14:49 --> Router Class Initialized
INFO - 2018-04-01 17:14:49 --> Output Class Initialized
INFO - 2018-04-01 17:14:49 --> Security Class Initialized
DEBUG - 2018-04-01 17:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:14:49 --> Input Class Initialized
INFO - 2018-04-01 17:14:49 --> Language Class Initialized
INFO - 2018-04-01 17:14:50 --> Loader Class Initialized
INFO - 2018-04-01 17:14:50 --> Helper loaded: url_helper
INFO - 2018-04-01 17:14:50 --> Helper loaded: form_helper
INFO - 2018-04-01 17:14:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:14:50 --> Form Validation Class Initialized
INFO - 2018-04-01 17:14:50 --> Model Class Initialized
INFO - 2018-04-01 17:14:50 --> Controller Class Initialized
INFO - 2018-04-01 17:14:50 --> Model Class Initialized
INFO - 2018-04-01 17:14:50 --> Model Class Initialized
INFO - 2018-04-01 17:14:50 --> Model Class Initialized
INFO - 2018-04-01 17:14:50 --> Model Class Initialized
DEBUG - 2018-04-01 17:14:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:14:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:14:50 --> Final output sent to browser
DEBUG - 2018-04-01 17:14:50 --> Total execution time: 0.0523
INFO - 2018-04-01 17:17:25 --> Config Class Initialized
INFO - 2018-04-01 17:17:25 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:17:25 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:17:25 --> Utf8 Class Initialized
INFO - 2018-04-01 17:17:25 --> URI Class Initialized
INFO - 2018-04-01 17:17:25 --> Router Class Initialized
INFO - 2018-04-01 17:17:25 --> Output Class Initialized
INFO - 2018-04-01 17:17:25 --> Security Class Initialized
DEBUG - 2018-04-01 17:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:17:25 --> Input Class Initialized
INFO - 2018-04-01 17:17:25 --> Language Class Initialized
INFO - 2018-04-01 17:17:25 --> Loader Class Initialized
INFO - 2018-04-01 17:17:25 --> Helper loaded: url_helper
INFO - 2018-04-01 17:17:25 --> Helper loaded: form_helper
INFO - 2018-04-01 17:17:25 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:17:25 --> Form Validation Class Initialized
INFO - 2018-04-01 17:17:25 --> Model Class Initialized
INFO - 2018-04-01 17:17:25 --> Controller Class Initialized
INFO - 2018-04-01 17:17:25 --> Model Class Initialized
INFO - 2018-04-01 17:17:25 --> Model Class Initialized
INFO - 2018-04-01 17:17:25 --> Model Class Initialized
INFO - 2018-04-01 17:17:25 --> Model Class Initialized
DEBUG - 2018-04-01 17:17:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:17:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:17:25 --> Final output sent to browser
DEBUG - 2018-04-01 17:17:25 --> Total execution time: 0.0582
INFO - 2018-04-01 17:17:29 --> Config Class Initialized
INFO - 2018-04-01 17:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:17:29 --> Utf8 Class Initialized
INFO - 2018-04-01 17:17:29 --> URI Class Initialized
INFO - 2018-04-01 17:17:29 --> Router Class Initialized
INFO - 2018-04-01 17:17:29 --> Output Class Initialized
INFO - 2018-04-01 17:17:29 --> Security Class Initialized
DEBUG - 2018-04-01 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:17:29 --> Input Class Initialized
INFO - 2018-04-01 17:17:29 --> Language Class Initialized
INFO - 2018-04-01 17:17:29 --> Loader Class Initialized
INFO - 2018-04-01 17:17:29 --> Helper loaded: url_helper
INFO - 2018-04-01 17:17:29 --> Helper loaded: form_helper
INFO - 2018-04-01 17:17:29 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:17:29 --> Form Validation Class Initialized
INFO - 2018-04-01 17:17:29 --> Model Class Initialized
INFO - 2018-04-01 17:17:29 --> Controller Class Initialized
INFO - 2018-04-01 17:17:29 --> Model Class Initialized
INFO - 2018-04-01 17:17:29 --> Model Class Initialized
INFO - 2018-04-01 17:17:29 --> Model Class Initialized
INFO - 2018-04-01 17:17:29 --> Model Class Initialized
DEBUG - 2018-04-01 17:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:17:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:17:29 --> Final output sent to browser
DEBUG - 2018-04-01 17:17:29 --> Total execution time: 0.0615
INFO - 2018-04-01 17:17:30 --> Config Class Initialized
INFO - 2018-04-01 17:17:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:17:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:17:30 --> Utf8 Class Initialized
INFO - 2018-04-01 17:17:30 --> URI Class Initialized
INFO - 2018-04-01 17:17:30 --> Router Class Initialized
INFO - 2018-04-01 17:17:30 --> Output Class Initialized
INFO - 2018-04-01 17:17:30 --> Security Class Initialized
DEBUG - 2018-04-01 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:17:30 --> Input Class Initialized
INFO - 2018-04-01 17:17:30 --> Language Class Initialized
INFO - 2018-04-01 17:17:30 --> Loader Class Initialized
INFO - 2018-04-01 17:17:30 --> Helper loaded: url_helper
INFO - 2018-04-01 17:17:30 --> Helper loaded: form_helper
INFO - 2018-04-01 17:17:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:17:30 --> Form Validation Class Initialized
INFO - 2018-04-01 17:17:30 --> Model Class Initialized
INFO - 2018-04-01 17:17:30 --> Controller Class Initialized
INFO - 2018-04-01 17:17:30 --> Model Class Initialized
INFO - 2018-04-01 17:17:30 --> Model Class Initialized
INFO - 2018-04-01 17:17:30 --> Model Class Initialized
INFO - 2018-04-01 17:17:30 --> Model Class Initialized
DEBUG - 2018-04-01 17:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:17:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:17:30 --> Final output sent to browser
DEBUG - 2018-04-01 17:17:30 --> Total execution time: 0.0671
INFO - 2018-04-01 17:17:31 --> Config Class Initialized
INFO - 2018-04-01 17:17:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:17:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:17:31 --> Utf8 Class Initialized
INFO - 2018-04-01 17:17:31 --> URI Class Initialized
INFO - 2018-04-01 17:17:31 --> Router Class Initialized
INFO - 2018-04-01 17:17:31 --> Output Class Initialized
INFO - 2018-04-01 17:17:31 --> Security Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:17:31 --> Input Class Initialized
INFO - 2018-04-01 17:17:31 --> Language Class Initialized
INFO - 2018-04-01 17:17:31 --> Loader Class Initialized
INFO - 2018-04-01 17:17:31 --> Helper loaded: url_helper
INFO - 2018-04-01 17:17:31 --> Helper loaded: form_helper
INFO - 2018-04-01 17:17:31 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:17:31 --> Form Validation Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Controller Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:17:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:17:31 --> Final output sent to browser
DEBUG - 2018-04-01 17:17:31 --> Total execution time: 0.0658
INFO - 2018-04-01 17:17:31 --> Config Class Initialized
INFO - 2018-04-01 17:17:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:17:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:17:31 --> Utf8 Class Initialized
INFO - 2018-04-01 17:17:31 --> URI Class Initialized
INFO - 2018-04-01 17:17:31 --> Router Class Initialized
INFO - 2018-04-01 17:17:31 --> Output Class Initialized
INFO - 2018-04-01 17:17:31 --> Security Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:17:31 --> Input Class Initialized
INFO - 2018-04-01 17:17:31 --> Language Class Initialized
INFO - 2018-04-01 17:17:31 --> Loader Class Initialized
INFO - 2018-04-01 17:17:31 --> Helper loaded: url_helper
INFO - 2018-04-01 17:17:31 --> Helper loaded: form_helper
INFO - 2018-04-01 17:17:31 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:17:31 --> Form Validation Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Controller Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
INFO - 2018-04-01 17:17:31 --> Model Class Initialized
DEBUG - 2018-04-01 17:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:17:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:17:31 --> Final output sent to browser
DEBUG - 2018-04-01 17:17:31 --> Total execution time: 0.0648
INFO - 2018-04-01 17:28:06 --> Config Class Initialized
INFO - 2018-04-01 17:28:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:28:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:28:06 --> Utf8 Class Initialized
INFO - 2018-04-01 17:28:06 --> URI Class Initialized
INFO - 2018-04-01 17:28:06 --> Router Class Initialized
INFO - 2018-04-01 17:28:06 --> Output Class Initialized
INFO - 2018-04-01 17:28:06 --> Security Class Initialized
DEBUG - 2018-04-01 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:28:06 --> Input Class Initialized
INFO - 2018-04-01 17:28:06 --> Language Class Initialized
INFO - 2018-04-01 17:28:06 --> Loader Class Initialized
INFO - 2018-04-01 17:28:06 --> Helper loaded: url_helper
INFO - 2018-04-01 17:28:06 --> Helper loaded: form_helper
INFO - 2018-04-01 17:28:06 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:28:07 --> Form Validation Class Initialized
INFO - 2018-04-01 17:28:07 --> Model Class Initialized
INFO - 2018-04-01 17:28:07 --> Controller Class Initialized
INFO - 2018-04-01 17:28:07 --> Model Class Initialized
INFO - 2018-04-01 17:28:07 --> Model Class Initialized
INFO - 2018-04-01 17:28:07 --> Model Class Initialized
INFO - 2018-04-01 17:28:07 --> Model Class Initialized
DEBUG - 2018-04-01 17:28:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:28:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:28:07 --> Final output sent to browser
DEBUG - 2018-04-01 17:28:07 --> Total execution time: 0.0691
INFO - 2018-04-01 17:28:40 --> Config Class Initialized
INFO - 2018-04-01 17:28:40 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:28:40 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:28:40 --> Utf8 Class Initialized
INFO - 2018-04-01 17:28:40 --> URI Class Initialized
INFO - 2018-04-01 17:28:40 --> Router Class Initialized
INFO - 2018-04-01 17:28:40 --> Output Class Initialized
INFO - 2018-04-01 17:28:40 --> Security Class Initialized
DEBUG - 2018-04-01 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:28:40 --> Input Class Initialized
INFO - 2018-04-01 17:28:40 --> Language Class Initialized
INFO - 2018-04-01 17:28:40 --> Loader Class Initialized
INFO - 2018-04-01 17:28:40 --> Helper loaded: url_helper
INFO - 2018-04-01 17:28:40 --> Helper loaded: form_helper
INFO - 2018-04-01 17:28:40 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:28:40 --> Form Validation Class Initialized
INFO - 2018-04-01 17:28:40 --> Model Class Initialized
INFO - 2018-04-01 17:28:40 --> Controller Class Initialized
INFO - 2018-04-01 17:28:40 --> Model Class Initialized
INFO - 2018-04-01 17:28:40 --> Model Class Initialized
INFO - 2018-04-01 17:28:40 --> Model Class Initialized
INFO - 2018-04-01 17:28:40 --> Model Class Initialized
DEBUG - 2018-04-01 17:28:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:28:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:28:40 --> Final output sent to browser
DEBUG - 2018-04-01 17:28:40 --> Total execution time: 0.0572
INFO - 2018-04-01 17:28:50 --> Config Class Initialized
INFO - 2018-04-01 17:28:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:28:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:28:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:28:50 --> URI Class Initialized
INFO - 2018-04-01 17:28:50 --> Router Class Initialized
INFO - 2018-04-01 17:28:50 --> Output Class Initialized
INFO - 2018-04-01 17:28:50 --> Security Class Initialized
DEBUG - 2018-04-01 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:28:50 --> Input Class Initialized
INFO - 2018-04-01 17:28:50 --> Language Class Initialized
INFO - 2018-04-01 17:28:50 --> Loader Class Initialized
INFO - 2018-04-01 17:28:50 --> Helper loaded: url_helper
INFO - 2018-04-01 17:28:50 --> Helper loaded: form_helper
INFO - 2018-04-01 17:28:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:28:50 --> Form Validation Class Initialized
INFO - 2018-04-01 17:28:50 --> Model Class Initialized
INFO - 2018-04-01 17:28:50 --> Controller Class Initialized
INFO - 2018-04-01 17:28:50 --> Model Class Initialized
INFO - 2018-04-01 17:28:50 --> Model Class Initialized
INFO - 2018-04-01 17:28:50 --> Model Class Initialized
INFO - 2018-04-01 17:28:50 --> Model Class Initialized
DEBUG - 2018-04-01 17:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:28:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:28:50 --> Final output sent to browser
DEBUG - 2018-04-01 17:28:50 --> Total execution time: 0.0558
INFO - 2018-04-01 17:32:13 --> Config Class Initialized
INFO - 2018-04-01 17:32:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:13 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:13 --> URI Class Initialized
INFO - 2018-04-01 17:32:13 --> Router Class Initialized
INFO - 2018-04-01 17:32:13 --> Output Class Initialized
INFO - 2018-04-01 17:32:13 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:13 --> Input Class Initialized
INFO - 2018-04-01 17:32:13 --> Language Class Initialized
INFO - 2018-04-01 17:32:13 --> Loader Class Initialized
INFO - 2018-04-01 17:32:13 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:13 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:13 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Controller Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:32:13 --> Final output sent to browser
DEBUG - 2018-04-01 17:32:13 --> Total execution time: 0.3395
INFO - 2018-04-01 17:32:13 --> Config Class Initialized
INFO - 2018-04-01 17:32:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:13 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:13 --> URI Class Initialized
INFO - 2018-04-01 17:32:13 --> Router Class Initialized
INFO - 2018-04-01 17:32:13 --> Output Class Initialized
INFO - 2018-04-01 17:32:13 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:13 --> Input Class Initialized
INFO - 2018-04-01 17:32:13 --> Language Class Initialized
INFO - 2018-04-01 17:32:13 --> Loader Class Initialized
INFO - 2018-04-01 17:32:13 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:13 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:13 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Controller Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
INFO - 2018-04-01 17:32:13 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:15 --> Config Class Initialized
INFO - 2018-04-01 17:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:15 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:15 --> URI Class Initialized
INFO - 2018-04-01 17:32:15 --> Router Class Initialized
INFO - 2018-04-01 17:32:15 --> Output Class Initialized
INFO - 2018-04-01 17:32:15 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:15 --> Input Class Initialized
INFO - 2018-04-01 17:32:15 --> Language Class Initialized
INFO - 2018-04-01 17:32:15 --> Loader Class Initialized
INFO - 2018-04-01 17:32:15 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:15 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:15 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:15 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Controller Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:32:15 --> Final output sent to browser
DEBUG - 2018-04-01 17:32:15 --> Total execution time: 0.1168
INFO - 2018-04-01 17:32:15 --> Config Class Initialized
INFO - 2018-04-01 17:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:15 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:15 --> URI Class Initialized
INFO - 2018-04-01 17:32:15 --> Router Class Initialized
INFO - 2018-04-01 17:32:15 --> Output Class Initialized
INFO - 2018-04-01 17:32:15 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:15 --> Input Class Initialized
INFO - 2018-04-01 17:32:15 --> Language Class Initialized
INFO - 2018-04-01 17:32:15 --> Loader Class Initialized
INFO - 2018-04-01 17:32:15 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:15 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:15 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:15 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Controller Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
INFO - 2018-04-01 17:32:15 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:29 --> Config Class Initialized
INFO - 2018-04-01 17:32:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:29 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:29 --> URI Class Initialized
INFO - 2018-04-01 17:32:29 --> Router Class Initialized
INFO - 2018-04-01 17:32:29 --> Output Class Initialized
INFO - 2018-04-01 17:32:29 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:29 --> Input Class Initialized
INFO - 2018-04-01 17:32:29 --> Language Class Initialized
INFO - 2018-04-01 17:32:29 --> Loader Class Initialized
INFO - 2018-04-01 17:32:29 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:29 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:29 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:29 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:29 --> Model Class Initialized
INFO - 2018-04-01 17:32:29 --> Controller Class Initialized
INFO - 2018-04-01 17:32:29 --> Model Class Initialized
INFO - 2018-04-01 17:32:29 --> Model Class Initialized
INFO - 2018-04-01 17:32:29 --> Model Class Initialized
INFO - 2018-04-01 17:32:29 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:39 --> Config Class Initialized
INFO - 2018-04-01 17:32:39 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:39 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:39 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:39 --> URI Class Initialized
INFO - 2018-04-01 17:32:39 --> Router Class Initialized
INFO - 2018-04-01 17:32:39 --> Output Class Initialized
INFO - 2018-04-01 17:32:39 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:39 --> Input Class Initialized
INFO - 2018-04-01 17:32:39 --> Language Class Initialized
INFO - 2018-04-01 17:32:39 --> Loader Class Initialized
INFO - 2018-04-01 17:32:39 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:39 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:39 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:39 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:39 --> Model Class Initialized
INFO - 2018-04-01 17:32:39 --> Controller Class Initialized
INFO - 2018-04-01 17:32:39 --> Model Class Initialized
INFO - 2018-04-01 17:32:39 --> Model Class Initialized
INFO - 2018-04-01 17:32:39 --> Model Class Initialized
INFO - 2018-04-01 17:32:39 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:32:39 --> Final output sent to browser
DEBUG - 2018-04-01 17:32:39 --> Total execution time: 0.0561
INFO - 2018-04-01 17:32:42 --> Config Class Initialized
INFO - 2018-04-01 17:32:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:42 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:42 --> URI Class Initialized
INFO - 2018-04-01 17:32:42 --> Router Class Initialized
INFO - 2018-04-01 17:32:42 --> Output Class Initialized
INFO - 2018-04-01 17:32:42 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:42 --> Input Class Initialized
INFO - 2018-04-01 17:32:42 --> Language Class Initialized
INFO - 2018-04-01 17:32:42 --> Loader Class Initialized
INFO - 2018-04-01 17:32:42 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:42 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:42 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Controller Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:32:42 --> Final output sent to browser
DEBUG - 2018-04-01 17:32:42 --> Total execution time: 0.0941
INFO - 2018-04-01 17:32:42 --> Config Class Initialized
INFO - 2018-04-01 17:32:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:32:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:32:42 --> Utf8 Class Initialized
INFO - 2018-04-01 17:32:42 --> URI Class Initialized
INFO - 2018-04-01 17:32:42 --> Router Class Initialized
INFO - 2018-04-01 17:32:42 --> Output Class Initialized
INFO - 2018-04-01 17:32:42 --> Security Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:32:42 --> Input Class Initialized
INFO - 2018-04-01 17:32:42 --> Language Class Initialized
INFO - 2018-04-01 17:32:42 --> Loader Class Initialized
INFO - 2018-04-01 17:32:42 --> Helper loaded: url_helper
INFO - 2018-04-01 17:32:42 --> Helper loaded: form_helper
INFO - 2018-04-01 17:32:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:32:42 --> Form Validation Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Controller Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
INFO - 2018-04-01 17:32:42 --> Model Class Initialized
DEBUG - 2018-04-01 17:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:01 --> Config Class Initialized
INFO - 2018-04-01 17:33:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:01 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:01 --> URI Class Initialized
INFO - 2018-04-01 17:33:01 --> Router Class Initialized
INFO - 2018-04-01 17:33:01 --> Output Class Initialized
INFO - 2018-04-01 17:33:01 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:01 --> Input Class Initialized
INFO - 2018-04-01 17:33:01 --> Language Class Initialized
INFO - 2018-04-01 17:33:01 --> Loader Class Initialized
INFO - 2018-04-01 17:33:01 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:01 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:01 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:01 --> Model Class Initialized
INFO - 2018-04-01 17:33:01 --> Controller Class Initialized
INFO - 2018-04-01 17:33:01 --> Model Class Initialized
INFO - 2018-04-01 17:33:01 --> Model Class Initialized
INFO - 2018-04-01 17:33:01 --> Model Class Initialized
INFO - 2018-04-01 17:33:01 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:33:01 --> Final output sent to browser
DEBUG - 2018-04-01 17:33:01 --> Total execution time: 0.0571
INFO - 2018-04-01 17:33:03 --> Config Class Initialized
INFO - 2018-04-01 17:33:03 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:03 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:03 --> URI Class Initialized
INFO - 2018-04-01 17:33:03 --> Router Class Initialized
INFO - 2018-04-01 17:33:03 --> Output Class Initialized
INFO - 2018-04-01 17:33:03 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:03 --> Input Class Initialized
INFO - 2018-04-01 17:33:03 --> Language Class Initialized
INFO - 2018-04-01 17:33:03 --> Loader Class Initialized
INFO - 2018-04-01 17:33:03 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:03 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:03 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:03 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Controller Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:33:03 --> Final output sent to browser
DEBUG - 2018-04-01 17:33:03 --> Total execution time: 0.0554
INFO - 2018-04-01 17:33:03 --> Config Class Initialized
INFO - 2018-04-01 17:33:03 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:03 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:03 --> URI Class Initialized
INFO - 2018-04-01 17:33:03 --> Router Class Initialized
INFO - 2018-04-01 17:33:03 --> Output Class Initialized
INFO - 2018-04-01 17:33:03 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:03 --> Input Class Initialized
INFO - 2018-04-01 17:33:03 --> Language Class Initialized
INFO - 2018-04-01 17:33:03 --> Loader Class Initialized
INFO - 2018-04-01 17:33:03 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:03 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:03 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:03 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Controller Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
INFO - 2018-04-01 17:33:03 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:10 --> Config Class Initialized
INFO - 2018-04-01 17:33:10 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:10 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:10 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:10 --> URI Class Initialized
INFO - 2018-04-01 17:33:10 --> Router Class Initialized
INFO - 2018-04-01 17:33:10 --> Output Class Initialized
INFO - 2018-04-01 17:33:10 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:10 --> Input Class Initialized
INFO - 2018-04-01 17:33:10 --> Language Class Initialized
INFO - 2018-04-01 17:33:10 --> Loader Class Initialized
INFO - 2018-04-01 17:33:10 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:10 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:10 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:10 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:10 --> Model Class Initialized
INFO - 2018-04-01 17:33:10 --> Controller Class Initialized
INFO - 2018-04-01 17:33:10 --> Model Class Initialized
INFO - 2018-04-01 17:33:10 --> Model Class Initialized
INFO - 2018-04-01 17:33:10 --> Model Class Initialized
INFO - 2018-04-01 17:33:10 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:33:10 --> Final output sent to browser
DEBUG - 2018-04-01 17:33:10 --> Total execution time: 0.0563
INFO - 2018-04-01 17:33:12 --> Config Class Initialized
INFO - 2018-04-01 17:33:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:12 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:12 --> URI Class Initialized
INFO - 2018-04-01 17:33:12 --> Router Class Initialized
INFO - 2018-04-01 17:33:12 --> Output Class Initialized
INFO - 2018-04-01 17:33:12 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:12 --> Input Class Initialized
INFO - 2018-04-01 17:33:12 --> Language Class Initialized
INFO - 2018-04-01 17:33:12 --> Loader Class Initialized
INFO - 2018-04-01 17:33:12 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:12 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:12 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Controller Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:33:12 --> Final output sent to browser
DEBUG - 2018-04-01 17:33:12 --> Total execution time: 0.0687
INFO - 2018-04-01 17:33:12 --> Config Class Initialized
INFO - 2018-04-01 17:33:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:33:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:33:12 --> Utf8 Class Initialized
INFO - 2018-04-01 17:33:12 --> URI Class Initialized
INFO - 2018-04-01 17:33:12 --> Router Class Initialized
INFO - 2018-04-01 17:33:12 --> Output Class Initialized
INFO - 2018-04-01 17:33:12 --> Security Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:33:12 --> Input Class Initialized
INFO - 2018-04-01 17:33:12 --> Language Class Initialized
INFO - 2018-04-01 17:33:12 --> Loader Class Initialized
INFO - 2018-04-01 17:33:12 --> Helper loaded: url_helper
INFO - 2018-04-01 17:33:12 --> Helper loaded: form_helper
INFO - 2018-04-01 17:33:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:33:12 --> Form Validation Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Controller Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
INFO - 2018-04-01 17:33:12 --> Model Class Initialized
DEBUG - 2018-04-01 17:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:34:56 --> Config Class Initialized
INFO - 2018-04-01 17:34:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:34:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:34:56 --> Utf8 Class Initialized
INFO - 2018-04-01 17:34:56 --> URI Class Initialized
INFO - 2018-04-01 17:34:56 --> Router Class Initialized
INFO - 2018-04-01 17:34:56 --> Output Class Initialized
INFO - 2018-04-01 17:34:56 --> Security Class Initialized
DEBUG - 2018-04-01 17:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:34:56 --> Input Class Initialized
INFO - 2018-04-01 17:34:56 --> Language Class Initialized
INFO - 2018-04-01 17:34:56 --> Loader Class Initialized
INFO - 2018-04-01 17:34:56 --> Helper loaded: url_helper
INFO - 2018-04-01 17:34:56 --> Helper loaded: form_helper
INFO - 2018-04-01 17:34:56 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:34:56 --> Form Validation Class Initialized
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
INFO - 2018-04-01 17:34:56 --> Controller Class Initialized
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
DEBUG - 2018-04-01 17:34:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:34:56 --> Model Class Initialized
INFO - 2018-04-01 17:34:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:34:56 --> Final output sent to browser
DEBUG - 2018-04-01 17:34:56 --> Total execution time: 0.0565
INFO - 2018-04-01 17:34:57 --> Config Class Initialized
INFO - 2018-04-01 17:34:57 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:34:57 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:34:57 --> Utf8 Class Initialized
INFO - 2018-04-01 17:34:57 --> URI Class Initialized
INFO - 2018-04-01 17:34:57 --> Router Class Initialized
INFO - 2018-04-01 17:34:57 --> Output Class Initialized
INFO - 2018-04-01 17:34:57 --> Security Class Initialized
DEBUG - 2018-04-01 17:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:34:57 --> Input Class Initialized
INFO - 2018-04-01 17:34:57 --> Language Class Initialized
INFO - 2018-04-01 17:34:57 --> Loader Class Initialized
INFO - 2018-04-01 17:34:57 --> Helper loaded: url_helper
INFO - 2018-04-01 17:34:57 --> Helper loaded: form_helper
INFO - 2018-04-01 17:34:57 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:34:57 --> Form Validation Class Initialized
INFO - 2018-04-01 17:34:57 --> Model Class Initialized
INFO - 2018-04-01 17:34:57 --> Controller Class Initialized
INFO - 2018-04-01 17:34:57 --> Model Class Initialized
INFO - 2018-04-01 17:34:57 --> Model Class Initialized
DEBUG - 2018-04-01 17:34:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:01 --> Config Class Initialized
INFO - 2018-04-01 17:35:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:01 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:01 --> URI Class Initialized
INFO - 2018-04-01 17:35:01 --> Router Class Initialized
INFO - 2018-04-01 17:35:01 --> Output Class Initialized
INFO - 2018-04-01 17:35:01 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:01 --> Input Class Initialized
INFO - 2018-04-01 17:35:01 --> Language Class Initialized
INFO - 2018-04-01 17:35:01 --> Loader Class Initialized
INFO - 2018-04-01 17:35:01 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:01 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:01 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Controller Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:01 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:01 --> Total execution time: 0.0620
INFO - 2018-04-01 17:35:01 --> Config Class Initialized
INFO - 2018-04-01 17:35:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:01 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:01 --> URI Class Initialized
INFO - 2018-04-01 17:35:01 --> Router Class Initialized
INFO - 2018-04-01 17:35:01 --> Output Class Initialized
INFO - 2018-04-01 17:35:01 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:01 --> Input Class Initialized
INFO - 2018-04-01 17:35:01 --> Language Class Initialized
INFO - 2018-04-01 17:35:01 --> Loader Class Initialized
INFO - 2018-04-01 17:35:01 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:01 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:01 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Controller Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
INFO - 2018-04-01 17:35:01 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:06 --> Config Class Initialized
INFO - 2018-04-01 17:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:06 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:06 --> URI Class Initialized
INFO - 2018-04-01 17:35:06 --> Router Class Initialized
INFO - 2018-04-01 17:35:06 --> Output Class Initialized
INFO - 2018-04-01 17:35:06 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:06 --> Input Class Initialized
INFO - 2018-04-01 17:35:06 --> Language Class Initialized
INFO - 2018-04-01 17:35:06 --> Loader Class Initialized
INFO - 2018-04-01 17:35:06 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:06 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:06 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:06 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Controller Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:06 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:06 --> Total execution time: 0.0571
INFO - 2018-04-01 17:35:06 --> Config Class Initialized
INFO - 2018-04-01 17:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:06 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:06 --> URI Class Initialized
INFO - 2018-04-01 17:35:06 --> Router Class Initialized
INFO - 2018-04-01 17:35:06 --> Output Class Initialized
INFO - 2018-04-01 17:35:06 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:06 --> Input Class Initialized
INFO - 2018-04-01 17:35:06 --> Language Class Initialized
INFO - 2018-04-01 17:35:06 --> Loader Class Initialized
INFO - 2018-04-01 17:35:06 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:06 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:06 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:06 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Controller Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
INFO - 2018-04-01 17:35:06 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:08 --> Config Class Initialized
INFO - 2018-04-01 17:35:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:08 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:08 --> URI Class Initialized
INFO - 2018-04-01 17:35:08 --> Router Class Initialized
INFO - 2018-04-01 17:35:08 --> Output Class Initialized
INFO - 2018-04-01 17:35:08 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:08 --> Input Class Initialized
INFO - 2018-04-01 17:35:08 --> Language Class Initialized
INFO - 2018-04-01 17:35:08 --> Loader Class Initialized
INFO - 2018-04-01 17:35:08 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:08 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:08 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:08 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Controller Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:08 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:08 --> Total execution time: 0.0586
INFO - 2018-04-01 17:35:08 --> Config Class Initialized
INFO - 2018-04-01 17:35:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:08 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:08 --> URI Class Initialized
INFO - 2018-04-01 17:35:08 --> Router Class Initialized
INFO - 2018-04-01 17:35:08 --> Output Class Initialized
INFO - 2018-04-01 17:35:08 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:08 --> Input Class Initialized
INFO - 2018-04-01 17:35:08 --> Language Class Initialized
INFO - 2018-04-01 17:35:08 --> Loader Class Initialized
INFO - 2018-04-01 17:35:08 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:08 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:08 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:08 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Controller Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
INFO - 2018-04-01 17:35:08 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:23 --> Config Class Initialized
INFO - 2018-04-01 17:35:23 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:23 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:23 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:23 --> URI Class Initialized
INFO - 2018-04-01 17:35:23 --> Router Class Initialized
INFO - 2018-04-01 17:35:23 --> Output Class Initialized
INFO - 2018-04-01 17:35:23 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:23 --> Input Class Initialized
INFO - 2018-04-01 17:35:23 --> Language Class Initialized
INFO - 2018-04-01 17:35:23 --> Loader Class Initialized
INFO - 2018-04-01 17:35:23 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:23 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:23 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:23 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
INFO - 2018-04-01 17:35:23 --> Controller Class Initialized
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:23 --> Model Class Initialized
INFO - 2018-04-01 17:35:23 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:23 --> Total execution time: 0.2443
INFO - 2018-04-01 17:35:42 --> Config Class Initialized
INFO - 2018-04-01 17:35:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:42 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:42 --> URI Class Initialized
INFO - 2018-04-01 17:35:42 --> Router Class Initialized
INFO - 2018-04-01 17:35:42 --> Output Class Initialized
INFO - 2018-04-01 17:35:42 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:42 --> Input Class Initialized
INFO - 2018-04-01 17:35:42 --> Language Class Initialized
INFO - 2018-04-01 17:35:42 --> Loader Class Initialized
INFO - 2018-04-01 17:35:42 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:42 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:42 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:42 --> Model Class Initialized
INFO - 2018-04-01 17:35:42 --> Controller Class Initialized
INFO - 2018-04-01 17:35:42 --> Model Class Initialized
INFO - 2018-04-01 17:35:42 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:43 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:43 --> Total execution time: 0.0953
INFO - 2018-04-01 17:35:43 --> Config Class Initialized
INFO - 2018-04-01 17:35:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:43 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:43 --> URI Class Initialized
INFO - 2018-04-01 17:35:43 --> Router Class Initialized
INFO - 2018-04-01 17:35:43 --> Output Class Initialized
INFO - 2018-04-01 17:35:43 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:43 --> Input Class Initialized
INFO - 2018-04-01 17:35:43 --> Language Class Initialized
INFO - 2018-04-01 17:35:43 --> Loader Class Initialized
INFO - 2018-04-01 17:35:43 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:43 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:43 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:43 --> Model Class Initialized
INFO - 2018-04-01 17:35:43 --> Controller Class Initialized
INFO - 2018-04-01 17:35:43 --> Model Class Initialized
INFO - 2018-04-01 17:35:43 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:43 --> Config Class Initialized
INFO - 2018-04-01 17:35:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:43 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:43 --> URI Class Initialized
INFO - 2018-04-01 17:35:43 --> Router Class Initialized
INFO - 2018-04-01 17:35:43 --> Output Class Initialized
INFO - 2018-04-01 17:35:43 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:43 --> Input Class Initialized
INFO - 2018-04-01 17:35:43 --> Language Class Initialized
INFO - 2018-04-01 17:35:44 --> Loader Class Initialized
INFO - 2018-04-01 17:35:44 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:44 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:44 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:44 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:44 --> Model Class Initialized
INFO - 2018-04-01 17:35:44 --> Controller Class Initialized
INFO - 2018-04-01 17:35:44 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:44 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:44 --> Total execution time: 0.1148
INFO - 2018-04-01 17:35:44 --> Config Class Initialized
INFO - 2018-04-01 17:35:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:44 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:44 --> URI Class Initialized
INFO - 2018-04-01 17:35:44 --> Router Class Initialized
INFO - 2018-04-01 17:35:44 --> Output Class Initialized
INFO - 2018-04-01 17:35:44 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:44 --> Input Class Initialized
INFO - 2018-04-01 17:35:44 --> Language Class Initialized
INFO - 2018-04-01 17:35:44 --> Loader Class Initialized
INFO - 2018-04-01 17:35:44 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:44 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:44 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:44 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:44 --> Model Class Initialized
INFO - 2018-04-01 17:35:44 --> Controller Class Initialized
INFO - 2018-04-01 17:35:44 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:45 --> Config Class Initialized
INFO - 2018-04-01 17:35:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:35:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:35:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:35:45 --> URI Class Initialized
INFO - 2018-04-01 17:35:45 --> Router Class Initialized
INFO - 2018-04-01 17:35:45 --> Output Class Initialized
INFO - 2018-04-01 17:35:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:35:45 --> Input Class Initialized
INFO - 2018-04-01 17:35:45 --> Language Class Initialized
INFO - 2018-04-01 17:35:45 --> Loader Class Initialized
INFO - 2018-04-01 17:35:45 --> Helper loaded: url_helper
INFO - 2018-04-01 17:35:45 --> Helper loaded: form_helper
INFO - 2018-04-01 17:35:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:35:45 --> Form Validation Class Initialized
INFO - 2018-04-01 17:35:45 --> Model Class Initialized
INFO - 2018-04-01 17:35:45 --> Controller Class Initialized
INFO - 2018-04-01 17:35:45 --> Model Class Initialized
INFO - 2018-04-01 17:35:45 --> Model Class Initialized
INFO - 2018-04-01 17:35:45 --> Model Class Initialized
INFO - 2018-04-01 17:35:45 --> Model Class Initialized
DEBUG - 2018-04-01 17:35:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:35:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:35:45 --> Final output sent to browser
DEBUG - 2018-04-01 17:35:45 --> Total execution time: 0.0672
INFO - 2018-04-01 17:36:13 --> Config Class Initialized
INFO - 2018-04-01 17:36:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:13 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:13 --> URI Class Initialized
INFO - 2018-04-01 17:36:13 --> Router Class Initialized
INFO - 2018-04-01 17:36:13 --> Output Class Initialized
INFO - 2018-04-01 17:36:13 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:13 --> Input Class Initialized
INFO - 2018-04-01 17:36:13 --> Language Class Initialized
ERROR - 2018-04-01 17:36:13 --> 404 Page Not Found: Reporte/reporteGastosMaterialesPorProyecto
INFO - 2018-04-01 17:36:22 --> Config Class Initialized
INFO - 2018-04-01 17:36:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:22 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:22 --> URI Class Initialized
INFO - 2018-04-01 17:36:22 --> Router Class Initialized
INFO - 2018-04-01 17:36:22 --> Output Class Initialized
INFO - 2018-04-01 17:36:22 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:22 --> Input Class Initialized
INFO - 2018-04-01 17:36:22 --> Language Class Initialized
INFO - 2018-04-01 17:36:22 --> Loader Class Initialized
INFO - 2018-04-01 17:36:22 --> Helper loaded: url_helper
INFO - 2018-04-01 17:36:22 --> Helper loaded: form_helper
INFO - 2018-04-01 17:36:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:36:22 --> Form Validation Class Initialized
INFO - 2018-04-01 17:36:22 --> Model Class Initialized
INFO - 2018-04-01 17:36:22 --> Controller Class Initialized
INFO - 2018-04-01 17:36:22 --> Model Class Initialized
INFO - 2018-04-01 17:36:22 --> Model Class Initialized
INFO - 2018-04-01 17:36:22 --> Model Class Initialized
INFO - 2018-04-01 17:36:22 --> Model Class Initialized
DEBUG - 2018-04-01 17:36:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:36:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:36:22 --> Final output sent to browser
DEBUG - 2018-04-01 17:36:22 --> Total execution time: 0.0562
INFO - 2018-04-01 17:36:28 --> Config Class Initialized
INFO - 2018-04-01 17:36:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:28 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:28 --> URI Class Initialized
INFO - 2018-04-01 17:36:28 --> Router Class Initialized
INFO - 2018-04-01 17:36:28 --> Output Class Initialized
INFO - 2018-04-01 17:36:28 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:28 --> Input Class Initialized
INFO - 2018-04-01 17:36:28 --> Language Class Initialized
INFO - 2018-04-01 17:36:28 --> Loader Class Initialized
INFO - 2018-04-01 17:36:28 --> Helper loaded: url_helper
INFO - 2018-04-01 17:36:28 --> Helper loaded: form_helper
INFO - 2018-04-01 17:36:28 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:36:28 --> Form Validation Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Controller Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:36:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:36:28 --> Final output sent to browser
DEBUG - 2018-04-01 17:36:28 --> Total execution time: 0.0559
INFO - 2018-04-01 17:36:28 --> Config Class Initialized
INFO - 2018-04-01 17:36:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:28 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:28 --> URI Class Initialized
INFO - 2018-04-01 17:36:28 --> Router Class Initialized
INFO - 2018-04-01 17:36:28 --> Output Class Initialized
INFO - 2018-04-01 17:36:28 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:28 --> Input Class Initialized
INFO - 2018-04-01 17:36:28 --> Language Class Initialized
INFO - 2018-04-01 17:36:28 --> Loader Class Initialized
INFO - 2018-04-01 17:36:28 --> Helper loaded: url_helper
INFO - 2018-04-01 17:36:28 --> Helper loaded: form_helper
INFO - 2018-04-01 17:36:28 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:36:28 --> Form Validation Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Controller Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
INFO - 2018-04-01 17:36:28 --> Model Class Initialized
DEBUG - 2018-04-01 17:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:36:30 --> Config Class Initialized
INFO - 2018-04-01 17:36:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:30 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:30 --> URI Class Initialized
INFO - 2018-04-01 17:36:30 --> Router Class Initialized
INFO - 2018-04-01 17:36:30 --> Output Class Initialized
INFO - 2018-04-01 17:36:30 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:30 --> Input Class Initialized
INFO - 2018-04-01 17:36:30 --> Language Class Initialized
INFO - 2018-04-01 17:36:30 --> Loader Class Initialized
INFO - 2018-04-01 17:36:30 --> Helper loaded: url_helper
INFO - 2018-04-01 17:36:30 --> Helper loaded: form_helper
INFO - 2018-04-01 17:36:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:36:30 --> Form Validation Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Controller Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:36:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:36:30 --> Final output sent to browser
DEBUG - 2018-04-01 17:36:30 --> Total execution time: 0.0604
INFO - 2018-04-01 17:36:30 --> Config Class Initialized
INFO - 2018-04-01 17:36:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:36:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:36:30 --> Utf8 Class Initialized
INFO - 2018-04-01 17:36:30 --> URI Class Initialized
INFO - 2018-04-01 17:36:30 --> Router Class Initialized
INFO - 2018-04-01 17:36:30 --> Output Class Initialized
INFO - 2018-04-01 17:36:30 --> Security Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:36:30 --> Input Class Initialized
INFO - 2018-04-01 17:36:30 --> Language Class Initialized
INFO - 2018-04-01 17:36:30 --> Loader Class Initialized
INFO - 2018-04-01 17:36:30 --> Helper loaded: url_helper
INFO - 2018-04-01 17:36:30 --> Helper loaded: form_helper
INFO - 2018-04-01 17:36:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:36:30 --> Form Validation Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Controller Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
INFO - 2018-04-01 17:36:30 --> Model Class Initialized
DEBUG - 2018-04-01 17:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:42:48 --> Config Class Initialized
INFO - 2018-04-01 17:42:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:48 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:48 --> URI Class Initialized
INFO - 2018-04-01 17:42:48 --> Router Class Initialized
INFO - 2018-04-01 17:42:48 --> Output Class Initialized
INFO - 2018-04-01 17:42:48 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:48 --> Input Class Initialized
INFO - 2018-04-01 17:42:48 --> Language Class Initialized
INFO - 2018-04-01 17:42:48 --> Loader Class Initialized
INFO - 2018-04-01 17:42:48 --> Helper loaded: url_helper
INFO - 2018-04-01 17:42:48 --> Helper loaded: form_helper
INFO - 2018-04-01 17:42:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:42:48 --> Form Validation Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Controller Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:42:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:42:48 --> Final output sent to browser
DEBUG - 2018-04-01 17:42:48 --> Total execution time: 0.0688
INFO - 2018-04-01 17:42:48 --> Config Class Initialized
INFO - 2018-04-01 17:42:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:48 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:48 --> URI Class Initialized
INFO - 2018-04-01 17:42:48 --> Router Class Initialized
INFO - 2018-04-01 17:42:48 --> Output Class Initialized
INFO - 2018-04-01 17:42:48 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:48 --> Input Class Initialized
INFO - 2018-04-01 17:42:48 --> Language Class Initialized
INFO - 2018-04-01 17:42:48 --> Loader Class Initialized
INFO - 2018-04-01 17:42:48 --> Helper loaded: url_helper
INFO - 2018-04-01 17:42:48 --> Helper loaded: form_helper
INFO - 2018-04-01 17:42:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:42:48 --> Form Validation Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Controller Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
INFO - 2018-04-01 17:42:48 --> Model Class Initialized
DEBUG - 2018-04-01 17:42:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> Config Class Initialized
INFO - 2018-04-01 17:42:50 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
DEBUG - 2018-04-01 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:50 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
INFO - 2018-04-01 17:42:50 --> URI Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
INFO - 2018-04-01 17:42:50 --> Router Class Initialized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Output Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
INFO - 2018-04-01 17:42:50 --> Security Class Initialized
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
DEBUG - 2018-04-01 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:50 --> Input Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
INFO - 2018-04-01 17:42:50 --> Language Class Initialized
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:42:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
INFO - 2018-04-01 17:42:52 --> Loader Class Initialized
INFO - 2018-04-01 17:42:52 --> Helper loaded: url_helper
INFO - 2018-04-01 17:42:52 --> Helper loaded: form_helper
INFO - 2018-04-01 17:42:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:42:52 --> Form Validation Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Controller Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:42:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:42:52 --> Final output sent to browser
DEBUG - 2018-04-01 17:42:52 --> Total execution time: 0.0726
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:42:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:42:52 --> Config Class Initialized
INFO - 2018-04-01 17:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:42:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:42:52 --> URI Class Initialized
INFO - 2018-04-01 17:42:52 --> Router Class Initialized
INFO - 2018-04-01 17:42:52 --> Output Class Initialized
INFO - 2018-04-01 17:42:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:42:52 --> Input Class Initialized
INFO - 2018-04-01 17:42:52 --> Language Class Initialized
INFO - 2018-04-01 17:42:52 --> Loader Class Initialized
INFO - 2018-04-01 17:42:52 --> Helper loaded: url_helper
INFO - 2018-04-01 17:42:52 --> Helper loaded: form_helper
INFO - 2018-04-01 17:42:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:42:52 --> Form Validation Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Controller Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
INFO - 2018-04-01 17:42:52 --> Model Class Initialized
DEBUG - 2018-04-01 17:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
INFO - 2018-04-01 17:48:02 --> Loader Class Initialized
INFO - 2018-04-01 17:48:02 --> Helper loaded: url_helper
INFO - 2018-04-01 17:48:02 --> Helper loaded: form_helper
INFO - 2018-04-01 17:48:02 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:48:02 --> Form Validation Class Initialized
INFO - 2018-04-01 17:48:02 --> Model Class Initialized
INFO - 2018-04-01 17:48:02 --> Controller Class Initialized
INFO - 2018-04-01 17:48:02 --> Model Class Initialized
INFO - 2018-04-01 17:48:02 --> Model Class Initialized
INFO - 2018-04-01 17:48:02 --> Model Class Initialized
INFO - 2018-04-01 17:48:02 --> Model Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:48:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:48:02 --> Final output sent to browser
DEBUG - 2018-04-01 17:48:02 --> Total execution time: 0.0779
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:48:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:48:02 --> Config Class Initialized
INFO - 2018-04-01 17:48:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:02 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:02 --> URI Class Initialized
INFO - 2018-04-01 17:48:02 --> Router Class Initialized
INFO - 2018-04-01 17:48:02 --> Output Class Initialized
INFO - 2018-04-01 17:48:02 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:02 --> Input Class Initialized
INFO - 2018-04-01 17:48:02 --> Language Class Initialized
INFO - 2018-04-01 17:48:03 --> Loader Class Initialized
INFO - 2018-04-01 17:48:03 --> Helper loaded: url_helper
INFO - 2018-04-01 17:48:03 --> Helper loaded: form_helper
INFO - 2018-04-01 17:48:03 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:48:03 --> Form Validation Class Initialized
INFO - 2018-04-01 17:48:03 --> Model Class Initialized
INFO - 2018-04-01 17:48:03 --> Controller Class Initialized
INFO - 2018-04-01 17:48:03 --> Model Class Initialized
INFO - 2018-04-01 17:48:03 --> Model Class Initialized
INFO - 2018-04-01 17:48:03 --> Model Class Initialized
INFO - 2018-04-01 17:48:03 --> Model Class Initialized
DEBUG - 2018-04-01 17:48:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
INFO - 2018-04-01 17:48:45 --> Loader Class Initialized
INFO - 2018-04-01 17:48:45 --> Helper loaded: url_helper
INFO - 2018-04-01 17:48:45 --> Helper loaded: form_helper
INFO - 2018-04-01 17:48:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:48:45 --> Form Validation Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Controller Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:48:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:48:45 --> Final output sent to browser
DEBUG - 2018-04-01 17:48:45 --> Total execution time: 0.0753
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:48:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:48:45 --> Config Class Initialized
INFO - 2018-04-01 17:48:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:48:45 --> Utf8 Class Initialized
INFO - 2018-04-01 17:48:45 --> URI Class Initialized
INFO - 2018-04-01 17:48:45 --> Router Class Initialized
INFO - 2018-04-01 17:48:45 --> Output Class Initialized
INFO - 2018-04-01 17:48:45 --> Security Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:48:45 --> Input Class Initialized
INFO - 2018-04-01 17:48:45 --> Language Class Initialized
INFO - 2018-04-01 17:48:45 --> Loader Class Initialized
INFO - 2018-04-01 17:48:45 --> Helper loaded: url_helper
INFO - 2018-04-01 17:48:45 --> Helper loaded: form_helper
INFO - 2018-04-01 17:48:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:48:45 --> Form Validation Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Controller Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
INFO - 2018-04-01 17:48:45 --> Model Class Initialized
DEBUG - 2018-04-01 17:48:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:52:51 --> Config Class Initialized
INFO - 2018-04-01 17:52:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:52:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:51 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:51 --> URI Class Initialized
INFO - 2018-04-01 17:52:51 --> Router Class Initialized
INFO - 2018-04-01 17:52:51 --> Output Class Initialized
INFO - 2018-04-01 17:52:51 --> Security Class Initialized
DEBUG - 2018-04-01 17:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:51 --> Input Class Initialized
INFO - 2018-04-01 17:52:51 --> Language Class Initialized
INFO - 2018-04-01 17:52:51 --> Loader Class Initialized
INFO - 2018-04-01 17:52:51 --> Helper loaded: url_helper
INFO - 2018-04-01 17:52:51 --> Helper loaded: form_helper
INFO - 2018-04-01 17:52:51 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:52:51 --> Form Validation Class Initialized
INFO - 2018-04-01 17:52:51 --> Model Class Initialized
INFO - 2018-04-01 17:52:51 --> Controller Class Initialized
INFO - 2018-04-01 17:52:51 --> Model Class Initialized
INFO - 2018-04-01 17:52:51 --> Model Class Initialized
INFO - 2018-04-01 17:52:51 --> Model Class Initialized
INFO - 2018-04-01 17:52:51 --> Model Class Initialized
DEBUG - 2018-04-01 17:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:52:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:52:51 --> Final output sent to browser
DEBUG - 2018-04-01 17:52:51 --> Total execution time: 0.0735
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:52:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:52:52 --> Config Class Initialized
INFO - 2018-04-01 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-01 17:52:52 --> URI Class Initialized
INFO - 2018-04-01 17:52:52 --> Router Class Initialized
INFO - 2018-04-01 17:52:52 --> Output Class Initialized
INFO - 2018-04-01 17:52:52 --> Security Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:52:52 --> Input Class Initialized
INFO - 2018-04-01 17:52:52 --> Language Class Initialized
INFO - 2018-04-01 17:52:52 --> Loader Class Initialized
INFO - 2018-04-01 17:52:52 --> Helper loaded: url_helper
INFO - 2018-04-01 17:52:52 --> Helper loaded: form_helper
INFO - 2018-04-01 17:52:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:52:52 --> Form Validation Class Initialized
INFO - 2018-04-01 17:52:52 --> Model Class Initialized
INFO - 2018-04-01 17:52:52 --> Controller Class Initialized
INFO - 2018-04-01 17:52:52 --> Model Class Initialized
INFO - 2018-04-01 17:52:52 --> Model Class Initialized
INFO - 2018-04-01 17:52:52 --> Model Class Initialized
INFO - 2018-04-01 17:52:52 --> Model Class Initialized
DEBUG - 2018-04-01 17:52:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> Loader Class Initialized
INFO - 2018-04-01 17:54:00 --> Helper loaded: url_helper
INFO - 2018-04-01 17:54:00 --> Helper loaded: form_helper
INFO - 2018-04-01 17:54:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:54:00 --> Form Validation Class Initialized
INFO - 2018-04-01 17:54:00 --> Model Class Initialized
INFO - 2018-04-01 17:54:00 --> Controller Class Initialized
INFO - 2018-04-01 17:54:00 --> Model Class Initialized
INFO - 2018-04-01 17:54:00 --> Model Class Initialized
INFO - 2018-04-01 17:54:00 --> Model Class Initialized
INFO - 2018-04-01 17:54:00 --> Model Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:54:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:54:00 --> Final output sent to browser
DEBUG - 2018-04-01 17:54:00 --> Total execution time: 0.0752
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
ERROR - 2018-04-01 17:54:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:54:00 --> Config Class Initialized
INFO - 2018-04-01 17:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:00 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:00 --> URI Class Initialized
INFO - 2018-04-01 17:54:00 --> Router Class Initialized
INFO - 2018-04-01 17:54:00 --> Output Class Initialized
INFO - 2018-04-01 17:54:00 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:00 --> Input Class Initialized
INFO - 2018-04-01 17:54:00 --> Language Class Initialized
INFO - 2018-04-01 17:54:00 --> Loader Class Initialized
INFO - 2018-04-01 17:54:00 --> Helper loaded: url_helper
INFO - 2018-04-01 17:54:00 --> Helper loaded: form_helper
INFO - 2018-04-01 17:54:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:54:01 --> Form Validation Class Initialized
INFO - 2018-04-01 17:54:01 --> Model Class Initialized
INFO - 2018-04-01 17:54:01 --> Controller Class Initialized
INFO - 2018-04-01 17:54:01 --> Model Class Initialized
INFO - 2018-04-01 17:54:01 --> Model Class Initialized
INFO - 2018-04-01 17:54:01 --> Model Class Initialized
INFO - 2018-04-01 17:54:01 --> Model Class Initialized
DEBUG - 2018-04-01 17:54:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Loader Class Initialized
INFO - 2018-04-01 17:54:14 --> Helper loaded: url_helper
INFO - 2018-04-01 17:54:14 --> Helper loaded: form_helper
INFO - 2018-04-01 17:54:14 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:54:14 --> Form Validation Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Controller Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:54:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 17:54:14 --> Final output sent to browser
DEBUG - 2018-04-01 17:54:14 --> Total execution time: 0.0763
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 17:54:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 17:54:14 --> Config Class Initialized
INFO - 2018-04-01 17:54:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:14 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:14 --> URI Class Initialized
INFO - 2018-04-01 17:54:14 --> Router Class Initialized
INFO - 2018-04-01 17:54:14 --> Output Class Initialized
INFO - 2018-04-01 17:54:14 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:14 --> Input Class Initialized
INFO - 2018-04-01 17:54:14 --> Language Class Initialized
INFO - 2018-04-01 17:54:14 --> Loader Class Initialized
INFO - 2018-04-01 17:54:14 --> Helper loaded: url_helper
INFO - 2018-04-01 17:54:14 --> Helper loaded: form_helper
INFO - 2018-04-01 17:54:14 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:54:14 --> Form Validation Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Controller Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
INFO - 2018-04-01 17:54:14 --> Model Class Initialized
DEBUG - 2018-04-01 17:54:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:54:27 --> Config Class Initialized
INFO - 2018-04-01 17:54:27 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:54:27 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:54:27 --> Utf8 Class Initialized
INFO - 2018-04-01 17:54:27 --> URI Class Initialized
INFO - 2018-04-01 17:54:27 --> Router Class Initialized
INFO - 2018-04-01 17:54:27 --> Output Class Initialized
INFO - 2018-04-01 17:54:27 --> Security Class Initialized
DEBUG - 2018-04-01 17:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:54:27 --> Input Class Initialized
INFO - 2018-04-01 17:54:27 --> Language Class Initialized
INFO - 2018-04-01 17:54:27 --> Loader Class Initialized
INFO - 2018-04-01 17:54:27 --> Helper loaded: url_helper
INFO - 2018-04-01 17:54:27 --> Helper loaded: form_helper
INFO - 2018-04-01 17:54:27 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:54:27 --> Form Validation Class Initialized
INFO - 2018-04-01 17:54:27 --> Model Class Initialized
INFO - 2018-04-01 17:54:27 --> Controller Class Initialized
INFO - 2018-04-01 17:54:27 --> Model Class Initialized
INFO - 2018-04-01 17:54:27 --> Model Class Initialized
INFO - 2018-04-01 17:54:27 --> Model Class Initialized
INFO - 2018-04-01 17:54:27 --> Model Class Initialized
DEBUG - 2018-04-01 17:54:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:58:40 --> Config Class Initialized
INFO - 2018-04-01 17:58:40 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:58:40 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:58:40 --> Utf8 Class Initialized
INFO - 2018-04-01 17:58:40 --> URI Class Initialized
INFO - 2018-04-01 17:58:40 --> Router Class Initialized
INFO - 2018-04-01 17:58:40 --> Output Class Initialized
INFO - 2018-04-01 17:58:40 --> Security Class Initialized
DEBUG - 2018-04-01 17:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:58:40 --> Input Class Initialized
INFO - 2018-04-01 17:58:40 --> Language Class Initialized
INFO - 2018-04-01 17:58:40 --> Loader Class Initialized
INFO - 2018-04-01 17:58:40 --> Helper loaded: url_helper
INFO - 2018-04-01 17:58:40 --> Helper loaded: form_helper
INFO - 2018-04-01 17:58:40 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:58:40 --> Form Validation Class Initialized
INFO - 2018-04-01 17:58:40 --> Model Class Initialized
INFO - 2018-04-01 17:58:40 --> Controller Class Initialized
INFO - 2018-04-01 17:58:40 --> Model Class Initialized
INFO - 2018-04-01 17:58:40 --> Model Class Initialized
INFO - 2018-04-01 17:58:40 --> Model Class Initialized
INFO - 2018-04-01 17:58:40 --> Model Class Initialized
DEBUG - 2018-04-01 17:58:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:58:44 --> Config Class Initialized
INFO - 2018-04-01 17:58:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:58:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:58:44 --> Utf8 Class Initialized
INFO - 2018-04-01 17:58:44 --> URI Class Initialized
INFO - 2018-04-01 17:58:44 --> Router Class Initialized
INFO - 2018-04-01 17:58:44 --> Output Class Initialized
INFO - 2018-04-01 17:58:44 --> Security Class Initialized
DEBUG - 2018-04-01 17:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:58:44 --> Input Class Initialized
INFO - 2018-04-01 17:58:44 --> Language Class Initialized
INFO - 2018-04-01 17:58:45 --> Loader Class Initialized
INFO - 2018-04-01 17:58:45 --> Helper loaded: url_helper
INFO - 2018-04-01 17:58:45 --> Helper loaded: form_helper
INFO - 2018-04-01 17:58:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:58:45 --> Form Validation Class Initialized
INFO - 2018-04-01 17:58:45 --> Model Class Initialized
INFO - 2018-04-01 17:58:45 --> Controller Class Initialized
INFO - 2018-04-01 17:58:45 --> Model Class Initialized
INFO - 2018-04-01 17:58:45 --> Model Class Initialized
INFO - 2018-04-01 17:58:45 --> Model Class Initialized
INFO - 2018-04-01 17:58:45 --> Model Class Initialized
DEBUG - 2018-04-01 17:58:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:19 --> Config Class Initialized
INFO - 2018-04-01 17:59:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:19 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:19 --> URI Class Initialized
INFO - 2018-04-01 17:59:19 --> Router Class Initialized
INFO - 2018-04-01 17:59:19 --> Output Class Initialized
INFO - 2018-04-01 17:59:19 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:19 --> Input Class Initialized
INFO - 2018-04-01 17:59:19 --> Language Class Initialized
INFO - 2018-04-01 17:59:19 --> Loader Class Initialized
INFO - 2018-04-01 17:59:19 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:19 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:19 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:19 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:19 --> Model Class Initialized
INFO - 2018-04-01 17:59:19 --> Controller Class Initialized
INFO - 2018-04-01 17:59:19 --> Model Class Initialized
INFO - 2018-04-01 17:59:19 --> Model Class Initialized
INFO - 2018-04-01 17:59:19 --> Model Class Initialized
INFO - 2018-04-01 17:59:19 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:25 --> Config Class Initialized
INFO - 2018-04-01 17:59:25 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:25 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:25 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:25 --> URI Class Initialized
INFO - 2018-04-01 17:59:25 --> Router Class Initialized
INFO - 2018-04-01 17:59:25 --> Output Class Initialized
INFO - 2018-04-01 17:59:25 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:25 --> Input Class Initialized
INFO - 2018-04-01 17:59:25 --> Language Class Initialized
INFO - 2018-04-01 17:59:25 --> Loader Class Initialized
INFO - 2018-04-01 17:59:25 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:25 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:25 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:25 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:25 --> Model Class Initialized
INFO - 2018-04-01 17:59:25 --> Controller Class Initialized
INFO - 2018-04-01 17:59:25 --> Model Class Initialized
INFO - 2018-04-01 17:59:25 --> Model Class Initialized
INFO - 2018-04-01 17:59:25 --> Model Class Initialized
INFO - 2018-04-01 17:59:25 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:32 --> Config Class Initialized
INFO - 2018-04-01 17:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:32 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:32 --> URI Class Initialized
INFO - 2018-04-01 17:59:32 --> Router Class Initialized
INFO - 2018-04-01 17:59:32 --> Output Class Initialized
INFO - 2018-04-01 17:59:32 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:32 --> Input Class Initialized
INFO - 2018-04-01 17:59:32 --> Language Class Initialized
INFO - 2018-04-01 17:59:32 --> Loader Class Initialized
INFO - 2018-04-01 17:59:32 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:32 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:32 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:32 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:32 --> Model Class Initialized
INFO - 2018-04-01 17:59:32 --> Controller Class Initialized
INFO - 2018-04-01 17:59:32 --> Model Class Initialized
INFO - 2018-04-01 17:59:32 --> Model Class Initialized
INFO - 2018-04-01 17:59:32 --> Model Class Initialized
INFO - 2018-04-01 17:59:32 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:36 --> Config Class Initialized
INFO - 2018-04-01 17:59:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:36 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:36 --> URI Class Initialized
INFO - 2018-04-01 17:59:36 --> Router Class Initialized
INFO - 2018-04-01 17:59:36 --> Output Class Initialized
INFO - 2018-04-01 17:59:36 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:36 --> Input Class Initialized
INFO - 2018-04-01 17:59:36 --> Language Class Initialized
INFO - 2018-04-01 17:59:36 --> Loader Class Initialized
INFO - 2018-04-01 17:59:36 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:36 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:36 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:36 --> Model Class Initialized
INFO - 2018-04-01 17:59:36 --> Controller Class Initialized
INFO - 2018-04-01 17:59:36 --> Model Class Initialized
INFO - 2018-04-01 17:59:36 --> Model Class Initialized
INFO - 2018-04-01 17:59:36 --> Model Class Initialized
INFO - 2018-04-01 17:59:36 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:40 --> Config Class Initialized
INFO - 2018-04-01 17:59:40 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:40 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:40 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:40 --> URI Class Initialized
INFO - 2018-04-01 17:59:40 --> Router Class Initialized
INFO - 2018-04-01 17:59:40 --> Output Class Initialized
INFO - 2018-04-01 17:59:40 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:40 --> Input Class Initialized
INFO - 2018-04-01 17:59:40 --> Language Class Initialized
INFO - 2018-04-01 17:59:40 --> Loader Class Initialized
INFO - 2018-04-01 17:59:40 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:40 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:40 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:40 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:40 --> Model Class Initialized
INFO - 2018-04-01 17:59:40 --> Controller Class Initialized
INFO - 2018-04-01 17:59:40 --> Model Class Initialized
INFO - 2018-04-01 17:59:40 --> Model Class Initialized
INFO - 2018-04-01 17:59:40 --> Model Class Initialized
INFO - 2018-04-01 17:59:40 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 17:59:42 --> Config Class Initialized
INFO - 2018-04-01 17:59:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 17:59:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 17:59:42 --> Utf8 Class Initialized
INFO - 2018-04-01 17:59:42 --> URI Class Initialized
INFO - 2018-04-01 17:59:42 --> Router Class Initialized
INFO - 2018-04-01 17:59:42 --> Output Class Initialized
INFO - 2018-04-01 17:59:42 --> Security Class Initialized
DEBUG - 2018-04-01 17:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 17:59:42 --> Input Class Initialized
INFO - 2018-04-01 17:59:42 --> Language Class Initialized
INFO - 2018-04-01 17:59:42 --> Loader Class Initialized
INFO - 2018-04-01 17:59:42 --> Helper loaded: url_helper
INFO - 2018-04-01 17:59:42 --> Helper loaded: form_helper
INFO - 2018-04-01 17:59:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 17:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 17:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 17:59:42 --> Form Validation Class Initialized
INFO - 2018-04-01 17:59:42 --> Model Class Initialized
INFO - 2018-04-01 17:59:42 --> Controller Class Initialized
INFO - 2018-04-01 17:59:42 --> Model Class Initialized
INFO - 2018-04-01 17:59:42 --> Model Class Initialized
INFO - 2018-04-01 17:59:42 --> Model Class Initialized
INFO - 2018-04-01 17:59:43 --> Model Class Initialized
DEBUG - 2018-04-01 17:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:08:43 --> Config Class Initialized
INFO - 2018-04-01 18:08:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:08:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:08:43 --> Utf8 Class Initialized
INFO - 2018-04-01 18:08:43 --> URI Class Initialized
INFO - 2018-04-01 18:08:43 --> Router Class Initialized
INFO - 2018-04-01 18:08:43 --> Output Class Initialized
INFO - 2018-04-01 18:08:43 --> Security Class Initialized
DEBUG - 2018-04-01 18:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:08:43 --> Input Class Initialized
INFO - 2018-04-01 18:08:43 --> Language Class Initialized
INFO - 2018-04-01 18:08:43 --> Loader Class Initialized
INFO - 2018-04-01 18:08:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:08:43 --> Helper loaded: form_helper
INFO - 2018-04-01 18:08:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:08:43 --> Form Validation Class Initialized
INFO - 2018-04-01 18:08:43 --> Model Class Initialized
INFO - 2018-04-01 18:08:43 --> Controller Class Initialized
INFO - 2018-04-01 18:08:43 --> Model Class Initialized
INFO - 2018-04-01 18:08:43 --> Model Class Initialized
INFO - 2018-04-01 18:08:43 --> Model Class Initialized
INFO - 2018-04-01 18:08:43 --> Model Class Initialized
DEBUG - 2018-04-01 18:08:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:08:44 --> Config Class Initialized
INFO - 2018-04-01 18:08:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:08:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:08:44 --> Utf8 Class Initialized
INFO - 2018-04-01 18:08:44 --> URI Class Initialized
INFO - 2018-04-01 18:08:44 --> Router Class Initialized
INFO - 2018-04-01 18:08:44 --> Output Class Initialized
INFO - 2018-04-01 18:08:44 --> Security Class Initialized
DEBUG - 2018-04-01 18:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:08:44 --> Input Class Initialized
INFO - 2018-04-01 18:08:44 --> Language Class Initialized
INFO - 2018-04-01 18:08:44 --> Loader Class Initialized
INFO - 2018-04-01 18:08:44 --> Helper loaded: url_helper
INFO - 2018-04-01 18:08:44 --> Helper loaded: form_helper
INFO - 2018-04-01 18:08:44 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:08:44 --> Form Validation Class Initialized
INFO - 2018-04-01 18:08:44 --> Model Class Initialized
INFO - 2018-04-01 18:08:44 --> Controller Class Initialized
INFO - 2018-04-01 18:08:44 --> Model Class Initialized
INFO - 2018-04-01 18:08:44 --> Model Class Initialized
INFO - 2018-04-01 18:08:44 --> Model Class Initialized
INFO - 2018-04-01 18:08:44 --> Model Class Initialized
DEBUG - 2018-04-01 18:08:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:08:44 --> Final output sent to browser
DEBUG - 2018-04-01 18:08:44 --> Total execution time: 0.1609
INFO - 2018-04-01 18:14:16 --> Config Class Initialized
INFO - 2018-04-01 18:14:16 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:14:16 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:14:16 --> Utf8 Class Initialized
INFO - 2018-04-01 18:14:16 --> URI Class Initialized
INFO - 2018-04-01 18:14:16 --> Router Class Initialized
INFO - 2018-04-01 18:14:16 --> Output Class Initialized
INFO - 2018-04-01 18:14:16 --> Security Class Initialized
DEBUG - 2018-04-01 18:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:14:16 --> Input Class Initialized
INFO - 2018-04-01 18:14:16 --> Language Class Initialized
INFO - 2018-04-01 18:14:16 --> Loader Class Initialized
INFO - 2018-04-01 18:14:16 --> Helper loaded: url_helper
INFO - 2018-04-01 18:14:16 --> Helper loaded: form_helper
INFO - 2018-04-01 18:14:16 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:14:16 --> Form Validation Class Initialized
INFO - 2018-04-01 18:14:16 --> Model Class Initialized
INFO - 2018-04-01 18:14:16 --> Controller Class Initialized
INFO - 2018-04-01 18:14:16 --> Model Class Initialized
INFO - 2018-04-01 18:14:16 --> Model Class Initialized
INFO - 2018-04-01 18:14:16 --> Model Class Initialized
INFO - 2018-04-01 18:14:16 --> Model Class Initialized
DEBUG - 2018-04-01 18:14:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:14:18 --> Config Class Initialized
INFO - 2018-04-01 18:14:18 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:14:18 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:14:18 --> Utf8 Class Initialized
INFO - 2018-04-01 18:14:18 --> URI Class Initialized
INFO - 2018-04-01 18:14:18 --> Router Class Initialized
INFO - 2018-04-01 18:14:18 --> Output Class Initialized
INFO - 2018-04-01 18:14:18 --> Security Class Initialized
DEBUG - 2018-04-01 18:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:14:18 --> Input Class Initialized
INFO - 2018-04-01 18:14:18 --> Language Class Initialized
INFO - 2018-04-01 18:14:18 --> Loader Class Initialized
INFO - 2018-04-01 18:14:18 --> Helper loaded: url_helper
INFO - 2018-04-01 18:14:18 --> Helper loaded: form_helper
INFO - 2018-04-01 18:14:18 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:14:18 --> Form Validation Class Initialized
INFO - 2018-04-01 18:14:18 --> Model Class Initialized
INFO - 2018-04-01 18:14:18 --> Controller Class Initialized
INFO - 2018-04-01 18:14:18 --> Model Class Initialized
INFO - 2018-04-01 18:14:18 --> Model Class Initialized
INFO - 2018-04-01 18:14:18 --> Model Class Initialized
INFO - 2018-04-01 18:14:18 --> Model Class Initialized
DEBUG - 2018-04-01 18:14:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 697
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 698
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 703
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 703
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 703
ERROR - 2018-04-01 18:14:18 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 723
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 723
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 723
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 741
ERROR - 2018-04-01 18:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 744
INFO - 2018-04-01 18:14:18 --> Final output sent to browser
DEBUG - 2018-04-01 18:14:18 --> Total execution time: 0.3640
INFO - 2018-04-01 18:15:43 --> Config Class Initialized
INFO - 2018-04-01 18:15:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:15:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:15:43 --> Utf8 Class Initialized
INFO - 2018-04-01 18:15:43 --> URI Class Initialized
INFO - 2018-04-01 18:15:43 --> Router Class Initialized
INFO - 2018-04-01 18:15:43 --> Output Class Initialized
INFO - 2018-04-01 18:15:43 --> Security Class Initialized
DEBUG - 2018-04-01 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:15:43 --> Input Class Initialized
INFO - 2018-04-01 18:15:43 --> Language Class Initialized
INFO - 2018-04-01 18:15:43 --> Loader Class Initialized
INFO - 2018-04-01 18:15:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:15:43 --> Helper loaded: form_helper
INFO - 2018-04-01 18:15:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:15:43 --> Form Validation Class Initialized
INFO - 2018-04-01 18:15:43 --> Model Class Initialized
INFO - 2018-04-01 18:15:43 --> Controller Class Initialized
INFO - 2018-04-01 18:15:43 --> Model Class Initialized
INFO - 2018-04-01 18:15:43 --> Model Class Initialized
INFO - 2018-04-01 18:15:43 --> Model Class Initialized
INFO - 2018-04-01 18:15:43 --> Model Class Initialized
DEBUG - 2018-04-01 18:15:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 18:15:43 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:43 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:43 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:43 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
ERROR - 2018-04-01 18:15:43 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
ERROR - 2018-04-01 18:15:43 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
INFO - 2018-04-01 18:15:43 --> Final output sent to browser
DEBUG - 2018-04-01 18:15:43 --> Total execution time: 0.3106
INFO - 2018-04-01 18:15:55 --> Config Class Initialized
INFO - 2018-04-01 18:15:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:15:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:15:55 --> Utf8 Class Initialized
INFO - 2018-04-01 18:15:55 --> URI Class Initialized
INFO - 2018-04-01 18:15:55 --> Router Class Initialized
INFO - 2018-04-01 18:15:55 --> Output Class Initialized
INFO - 2018-04-01 18:15:55 --> Security Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:15:55 --> Input Class Initialized
INFO - 2018-04-01 18:15:55 --> Language Class Initialized
INFO - 2018-04-01 18:15:55 --> Loader Class Initialized
INFO - 2018-04-01 18:15:55 --> Helper loaded: url_helper
INFO - 2018-04-01 18:15:55 --> Helper loaded: form_helper
INFO - 2018-04-01 18:15:55 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:15:55 --> Form Validation Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Controller Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:15:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:15:55 --> Final output sent to browser
DEBUG - 2018-04-01 18:15:55 --> Total execution time: 0.0701
INFO - 2018-04-01 18:15:55 --> Config Class Initialized
INFO - 2018-04-01 18:15:55 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:15:55 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:15:55 --> Utf8 Class Initialized
INFO - 2018-04-01 18:15:55 --> URI Class Initialized
INFO - 2018-04-01 18:15:55 --> Router Class Initialized
INFO - 2018-04-01 18:15:55 --> Output Class Initialized
INFO - 2018-04-01 18:15:55 --> Security Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:15:55 --> Input Class Initialized
INFO - 2018-04-01 18:15:55 --> Language Class Initialized
INFO - 2018-04-01 18:15:55 --> Loader Class Initialized
INFO - 2018-04-01 18:15:55 --> Helper loaded: url_helper
INFO - 2018-04-01 18:15:55 --> Helper loaded: form_helper
INFO - 2018-04-01 18:15:55 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:15:55 --> Form Validation Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Controller Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
INFO - 2018-04-01 18:15:55 --> Model Class Initialized
DEBUG - 2018-04-01 18:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:15:58 --> Config Class Initialized
INFO - 2018-04-01 18:15:58 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:15:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:15:58 --> Utf8 Class Initialized
INFO - 2018-04-01 18:15:58 --> URI Class Initialized
INFO - 2018-04-01 18:15:58 --> Router Class Initialized
INFO - 2018-04-01 18:15:58 --> Output Class Initialized
INFO - 2018-04-01 18:15:58 --> Security Class Initialized
DEBUG - 2018-04-01 18:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:15:58 --> Input Class Initialized
INFO - 2018-04-01 18:15:58 --> Language Class Initialized
INFO - 2018-04-01 18:15:58 --> Loader Class Initialized
INFO - 2018-04-01 18:15:58 --> Helper loaded: url_helper
INFO - 2018-04-01 18:15:58 --> Helper loaded: form_helper
INFO - 2018-04-01 18:15:58 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:15:58 --> Form Validation Class Initialized
INFO - 2018-04-01 18:15:58 --> Model Class Initialized
INFO - 2018-04-01 18:15:58 --> Controller Class Initialized
INFO - 2018-04-01 18:15:58 --> Model Class Initialized
INFO - 2018-04-01 18:15:58 --> Model Class Initialized
INFO - 2018-04-01 18:15:58 --> Model Class Initialized
INFO - 2018-04-01 18:15:58 --> Model Class Initialized
DEBUG - 2018-04-01 18:15:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 18:15:58 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:58 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:58 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 707
ERROR - 2018-04-01 18:15:58 --> Severity: Notice --> Use of undefined constant post_data - assumed 'post_data' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
ERROR - 2018-04-01 18:15:58 --> Severity: Warning --> Illegal string offset 'filtros' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
ERROR - 2018-04-01 18:15:58 --> Severity: Warning --> Illegal string offset 'group_by' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 727
INFO - 2018-04-01 18:15:58 --> Final output sent to browser
DEBUG - 2018-04-01 18:15:58 --> Total execution time: 0.3030
INFO - 2018-04-01 18:17:11 --> Config Class Initialized
INFO - 2018-04-01 18:17:11 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:17:11 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:17:11 --> Utf8 Class Initialized
INFO - 2018-04-01 18:17:11 --> URI Class Initialized
INFO - 2018-04-01 18:17:11 --> Router Class Initialized
INFO - 2018-04-01 18:17:11 --> Output Class Initialized
INFO - 2018-04-01 18:17:11 --> Security Class Initialized
DEBUG - 2018-04-01 18:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:17:11 --> Input Class Initialized
INFO - 2018-04-01 18:17:11 --> Language Class Initialized
INFO - 2018-04-01 18:17:11 --> Loader Class Initialized
INFO - 2018-04-01 18:17:11 --> Helper loaded: url_helper
INFO - 2018-04-01 18:17:11 --> Helper loaded: form_helper
INFO - 2018-04-01 18:17:11 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:17:11 --> Form Validation Class Initialized
INFO - 2018-04-01 18:17:11 --> Model Class Initialized
INFO - 2018-04-01 18:17:11 --> Controller Class Initialized
INFO - 2018-04-01 18:17:11 --> Model Class Initialized
INFO - 2018-04-01 18:17:11 --> Model Class Initialized
INFO - 2018-04-01 18:17:11 --> Model Class Initialized
INFO - 2018-04-01 18:17:11 --> Model Class Initialized
DEBUG - 2018-04-01 18:17:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:17:11 --> Final output sent to browser
DEBUG - 2018-04-01 18:17:11 --> Total execution time: 0.3091
INFO - 2018-04-01 18:17:26 --> Config Class Initialized
INFO - 2018-04-01 18:17:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:17:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:17:26 --> Utf8 Class Initialized
INFO - 2018-04-01 18:17:26 --> URI Class Initialized
INFO - 2018-04-01 18:17:26 --> Router Class Initialized
INFO - 2018-04-01 18:17:26 --> Output Class Initialized
INFO - 2018-04-01 18:17:26 --> Security Class Initialized
DEBUG - 2018-04-01 18:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:17:26 --> Input Class Initialized
INFO - 2018-04-01 18:17:26 --> Language Class Initialized
INFO - 2018-04-01 18:17:26 --> Loader Class Initialized
INFO - 2018-04-01 18:17:26 --> Helper loaded: url_helper
INFO - 2018-04-01 18:17:26 --> Helper loaded: form_helper
INFO - 2018-04-01 18:17:26 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:17:26 --> Form Validation Class Initialized
INFO - 2018-04-01 18:17:26 --> Model Class Initialized
INFO - 2018-04-01 18:17:26 --> Controller Class Initialized
INFO - 2018-04-01 18:17:26 --> Model Class Initialized
INFO - 2018-04-01 18:17:26 --> Model Class Initialized
INFO - 2018-04-01 18:17:26 --> Model Class Initialized
INFO - 2018-04-01 18:17:26 --> Model Class Initialized
DEBUG - 2018-04-01 18:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:17:28 --> Config Class Initialized
INFO - 2018-04-01 18:17:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:17:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:17:28 --> Utf8 Class Initialized
INFO - 2018-04-01 18:17:28 --> URI Class Initialized
INFO - 2018-04-01 18:17:28 --> Router Class Initialized
INFO - 2018-04-01 18:17:28 --> Output Class Initialized
INFO - 2018-04-01 18:17:28 --> Security Class Initialized
DEBUG - 2018-04-01 18:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:17:28 --> Input Class Initialized
INFO - 2018-04-01 18:17:28 --> Language Class Initialized
INFO - 2018-04-01 18:17:28 --> Loader Class Initialized
INFO - 2018-04-01 18:17:28 --> Helper loaded: url_helper
INFO - 2018-04-01 18:17:28 --> Helper loaded: form_helper
INFO - 2018-04-01 18:17:28 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:17:28 --> Form Validation Class Initialized
INFO - 2018-04-01 18:17:28 --> Model Class Initialized
INFO - 2018-04-01 18:17:28 --> Controller Class Initialized
INFO - 2018-04-01 18:17:28 --> Model Class Initialized
INFO - 2018-04-01 18:17:28 --> Model Class Initialized
INFO - 2018-04-01 18:17:28 --> Model Class Initialized
INFO - 2018-04-01 18:17:28 --> Model Class Initialized
DEBUG - 2018-04-01 18:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:17:28 --> Final output sent to browser
DEBUG - 2018-04-01 18:17:28 --> Total execution time: 0.1954
INFO - 2018-04-01 18:17:31 --> Config Class Initialized
INFO - 2018-04-01 18:17:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:17:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:17:31 --> Utf8 Class Initialized
INFO - 2018-04-01 18:17:31 --> URI Class Initialized
INFO - 2018-04-01 18:17:31 --> Router Class Initialized
INFO - 2018-04-01 18:17:31 --> Output Class Initialized
INFO - 2018-04-01 18:17:31 --> Security Class Initialized
DEBUG - 2018-04-01 18:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:17:31 --> Input Class Initialized
INFO - 2018-04-01 18:17:31 --> Language Class Initialized
INFO - 2018-04-01 18:17:31 --> Loader Class Initialized
INFO - 2018-04-01 18:17:31 --> Helper loaded: url_helper
INFO - 2018-04-01 18:17:31 --> Helper loaded: form_helper
INFO - 2018-04-01 18:17:31 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:17:31 --> Form Validation Class Initialized
INFO - 2018-04-01 18:17:31 --> Model Class Initialized
INFO - 2018-04-01 18:17:31 --> Controller Class Initialized
INFO - 2018-04-01 18:17:31 --> Model Class Initialized
INFO - 2018-04-01 18:17:31 --> Model Class Initialized
INFO - 2018-04-01 18:17:31 --> Model Class Initialized
INFO - 2018-04-01 18:17:31 --> Model Class Initialized
DEBUG - 2018-04-01 18:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:17:32 --> Config Class Initialized
INFO - 2018-04-01 18:17:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:17:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:17:32 --> Utf8 Class Initialized
INFO - 2018-04-01 18:17:32 --> URI Class Initialized
INFO - 2018-04-01 18:17:32 --> Router Class Initialized
INFO - 2018-04-01 18:17:32 --> Output Class Initialized
INFO - 2018-04-01 18:17:32 --> Security Class Initialized
DEBUG - 2018-04-01 18:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:17:32 --> Input Class Initialized
INFO - 2018-04-01 18:17:32 --> Language Class Initialized
INFO - 2018-04-01 18:17:32 --> Loader Class Initialized
INFO - 2018-04-01 18:17:32 --> Helper loaded: url_helper
INFO - 2018-04-01 18:17:32 --> Helper loaded: form_helper
INFO - 2018-04-01 18:17:32 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:17:32 --> Form Validation Class Initialized
INFO - 2018-04-01 18:17:32 --> Model Class Initialized
INFO - 2018-04-01 18:17:32 --> Controller Class Initialized
INFO - 2018-04-01 18:17:32 --> Model Class Initialized
INFO - 2018-04-01 18:17:32 --> Model Class Initialized
INFO - 2018-04-01 18:17:32 --> Model Class Initialized
INFO - 2018-04-01 18:17:32 --> Model Class Initialized
DEBUG - 2018-04-01 18:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:17:33 --> Final output sent to browser
DEBUG - 2018-04-01 18:17:33 --> Total execution time: 0.1714
INFO - 2018-04-01 18:20:09 --> Config Class Initialized
INFO - 2018-04-01 18:20:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:20:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:20:09 --> Utf8 Class Initialized
INFO - 2018-04-01 18:20:09 --> URI Class Initialized
INFO - 2018-04-01 18:20:09 --> Router Class Initialized
INFO - 2018-04-01 18:20:09 --> Output Class Initialized
INFO - 2018-04-01 18:20:09 --> Security Class Initialized
DEBUG - 2018-04-01 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:20:09 --> Input Class Initialized
INFO - 2018-04-01 18:20:09 --> Language Class Initialized
INFO - 2018-04-01 18:20:09 --> Loader Class Initialized
INFO - 2018-04-01 18:20:09 --> Helper loaded: url_helper
INFO - 2018-04-01 18:20:09 --> Helper loaded: form_helper
INFO - 2018-04-01 18:20:09 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:20:09 --> Form Validation Class Initialized
INFO - 2018-04-01 18:20:09 --> Model Class Initialized
INFO - 2018-04-01 18:20:09 --> Controller Class Initialized
INFO - 2018-04-01 18:20:09 --> Model Class Initialized
INFO - 2018-04-01 18:20:09 --> Model Class Initialized
INFO - 2018-04-01 18:20:09 --> Model Class Initialized
INFO - 2018-04-01 18:20:09 --> Model Class Initialized
DEBUG - 2018-04-01 18:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:20:11 --> Config Class Initialized
INFO - 2018-04-01 18:20:11 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:20:11 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:20:11 --> Utf8 Class Initialized
INFO - 2018-04-01 18:20:11 --> URI Class Initialized
INFO - 2018-04-01 18:20:11 --> Router Class Initialized
INFO - 2018-04-01 18:20:11 --> Output Class Initialized
INFO - 2018-04-01 18:20:11 --> Security Class Initialized
DEBUG - 2018-04-01 18:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:20:11 --> Input Class Initialized
INFO - 2018-04-01 18:20:11 --> Language Class Initialized
INFO - 2018-04-01 18:20:11 --> Loader Class Initialized
INFO - 2018-04-01 18:20:11 --> Helper loaded: url_helper
INFO - 2018-04-01 18:20:11 --> Helper loaded: form_helper
INFO - 2018-04-01 18:20:11 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:20:11 --> Form Validation Class Initialized
INFO - 2018-04-01 18:20:11 --> Model Class Initialized
INFO - 2018-04-01 18:20:11 --> Controller Class Initialized
INFO - 2018-04-01 18:20:11 --> Model Class Initialized
INFO - 2018-04-01 18:20:11 --> Model Class Initialized
INFO - 2018-04-01 18:20:11 --> Model Class Initialized
INFO - 2018-04-01 18:20:11 --> Model Class Initialized
DEBUG - 2018-04-01 18:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:20:11 --> Final output sent to browser
DEBUG - 2018-04-01 18:20:11 --> Total execution time: 0.3076
INFO - 2018-04-01 18:20:35 --> Config Class Initialized
INFO - 2018-04-01 18:20:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:20:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:20:35 --> Utf8 Class Initialized
INFO - 2018-04-01 18:20:35 --> URI Class Initialized
INFO - 2018-04-01 18:20:35 --> Router Class Initialized
INFO - 2018-04-01 18:20:35 --> Output Class Initialized
INFO - 2018-04-01 18:20:35 --> Security Class Initialized
DEBUG - 2018-04-01 18:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:20:35 --> Input Class Initialized
INFO - 2018-04-01 18:20:35 --> Language Class Initialized
INFO - 2018-04-01 18:20:35 --> Loader Class Initialized
INFO - 2018-04-01 18:20:35 --> Helper loaded: url_helper
INFO - 2018-04-01 18:20:35 --> Helper loaded: form_helper
INFO - 2018-04-01 18:20:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:20:35 --> Form Validation Class Initialized
INFO - 2018-04-01 18:20:35 --> Model Class Initialized
INFO - 2018-04-01 18:20:35 --> Controller Class Initialized
INFO - 2018-04-01 18:20:35 --> Model Class Initialized
INFO - 2018-04-01 18:20:35 --> Model Class Initialized
INFO - 2018-04-01 18:20:35 --> Model Class Initialized
INFO - 2018-04-01 18:20:35 --> Model Class Initialized
DEBUG - 2018-04-01 18:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:20:36 --> Config Class Initialized
INFO - 2018-04-01 18:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:20:36 --> Utf8 Class Initialized
INFO - 2018-04-01 18:20:36 --> URI Class Initialized
INFO - 2018-04-01 18:20:36 --> Router Class Initialized
INFO - 2018-04-01 18:20:36 --> Output Class Initialized
INFO - 2018-04-01 18:20:36 --> Security Class Initialized
DEBUG - 2018-04-01 18:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:20:36 --> Input Class Initialized
INFO - 2018-04-01 18:20:36 --> Language Class Initialized
INFO - 2018-04-01 18:20:36 --> Loader Class Initialized
INFO - 2018-04-01 18:20:36 --> Helper loaded: url_helper
INFO - 2018-04-01 18:20:36 --> Helper loaded: form_helper
INFO - 2018-04-01 18:20:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:20:36 --> Form Validation Class Initialized
INFO - 2018-04-01 18:20:36 --> Model Class Initialized
INFO - 2018-04-01 18:20:36 --> Controller Class Initialized
INFO - 2018-04-01 18:20:36 --> Model Class Initialized
INFO - 2018-04-01 18:20:36 --> Model Class Initialized
INFO - 2018-04-01 18:20:36 --> Model Class Initialized
INFO - 2018-04-01 18:20:36 --> Model Class Initialized
DEBUG - 2018-04-01 18:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:20:36 --> Final output sent to browser
DEBUG - 2018-04-01 18:20:36 --> Total execution time: 0.1918
INFO - 2018-04-01 18:21:00 --> Config Class Initialized
INFO - 2018-04-01 18:21:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:00 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:00 --> URI Class Initialized
INFO - 2018-04-01 18:21:00 --> Router Class Initialized
INFO - 2018-04-01 18:21:00 --> Output Class Initialized
INFO - 2018-04-01 18:21:00 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:00 --> Input Class Initialized
INFO - 2018-04-01 18:21:00 --> Language Class Initialized
INFO - 2018-04-01 18:21:00 --> Loader Class Initialized
INFO - 2018-04-01 18:21:00 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:00 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:00 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:00 --> Model Class Initialized
INFO - 2018-04-01 18:21:00 --> Controller Class Initialized
INFO - 2018-04-01 18:21:00 --> Model Class Initialized
INFO - 2018-04-01 18:21:00 --> Model Class Initialized
INFO - 2018-04-01 18:21:00 --> Model Class Initialized
INFO - 2018-04-01 18:21:00 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:02 --> Config Class Initialized
INFO - 2018-04-01 18:21:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:02 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:02 --> URI Class Initialized
INFO - 2018-04-01 18:21:02 --> Router Class Initialized
INFO - 2018-04-01 18:21:02 --> Output Class Initialized
INFO - 2018-04-01 18:21:02 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:02 --> Input Class Initialized
INFO - 2018-04-01 18:21:02 --> Language Class Initialized
INFO - 2018-04-01 18:21:02 --> Loader Class Initialized
INFO - 2018-04-01 18:21:02 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:02 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:02 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:02 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:02 --> Model Class Initialized
INFO - 2018-04-01 18:21:02 --> Controller Class Initialized
INFO - 2018-04-01 18:21:02 --> Model Class Initialized
INFO - 2018-04-01 18:21:02 --> Model Class Initialized
INFO - 2018-04-01 18:21:02 --> Model Class Initialized
INFO - 2018-04-01 18:21:02 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:02 --> Final output sent to browser
DEBUG - 2018-04-01 18:21:02 --> Total execution time: 0.1664
INFO - 2018-04-01 18:21:12 --> Config Class Initialized
INFO - 2018-04-01 18:21:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:12 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:12 --> URI Class Initialized
INFO - 2018-04-01 18:21:12 --> Router Class Initialized
INFO - 2018-04-01 18:21:12 --> Output Class Initialized
INFO - 2018-04-01 18:21:12 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:12 --> Input Class Initialized
INFO - 2018-04-01 18:21:12 --> Language Class Initialized
INFO - 2018-04-01 18:21:12 --> Loader Class Initialized
INFO - 2018-04-01 18:21:12 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:12 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:12 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:12 --> Model Class Initialized
INFO - 2018-04-01 18:21:12 --> Controller Class Initialized
INFO - 2018-04-01 18:21:12 --> Model Class Initialized
INFO - 2018-04-01 18:21:12 --> Model Class Initialized
INFO - 2018-04-01 18:21:12 --> Model Class Initialized
INFO - 2018-04-01 18:21:12 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:22 --> Config Class Initialized
INFO - 2018-04-01 18:21:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:22 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:22 --> URI Class Initialized
INFO - 2018-04-01 18:21:22 --> Router Class Initialized
INFO - 2018-04-01 18:21:22 --> Output Class Initialized
INFO - 2018-04-01 18:21:22 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:22 --> Input Class Initialized
INFO - 2018-04-01 18:21:22 --> Language Class Initialized
INFO - 2018-04-01 18:21:22 --> Loader Class Initialized
INFO - 2018-04-01 18:21:22 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:22 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:22 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:22 --> Model Class Initialized
INFO - 2018-04-01 18:21:22 --> Controller Class Initialized
INFO - 2018-04-01 18:21:22 --> Model Class Initialized
INFO - 2018-04-01 18:21:22 --> Model Class Initialized
INFO - 2018-04-01 18:21:22 --> Model Class Initialized
INFO - 2018-04-01 18:21:22 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:25 --> Config Class Initialized
INFO - 2018-04-01 18:21:25 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:25 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:25 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:25 --> URI Class Initialized
INFO - 2018-04-01 18:21:25 --> Router Class Initialized
INFO - 2018-04-01 18:21:25 --> Output Class Initialized
INFO - 2018-04-01 18:21:25 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:25 --> Input Class Initialized
INFO - 2018-04-01 18:21:25 --> Language Class Initialized
INFO - 2018-04-01 18:21:25 --> Loader Class Initialized
INFO - 2018-04-01 18:21:25 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:25 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:25 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:25 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:25 --> Model Class Initialized
INFO - 2018-04-01 18:21:25 --> Controller Class Initialized
INFO - 2018-04-01 18:21:25 --> Model Class Initialized
INFO - 2018-04-01 18:21:25 --> Model Class Initialized
INFO - 2018-04-01 18:21:25 --> Model Class Initialized
INFO - 2018-04-01 18:21:25 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:25 --> Final output sent to browser
DEBUG - 2018-04-01 18:21:25 --> Total execution time: 0.1724
INFO - 2018-04-01 18:21:34 --> Config Class Initialized
INFO - 2018-04-01 18:21:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:34 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:34 --> URI Class Initialized
INFO - 2018-04-01 18:21:34 --> Router Class Initialized
INFO - 2018-04-01 18:21:34 --> Output Class Initialized
INFO - 2018-04-01 18:21:34 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:34 --> Input Class Initialized
INFO - 2018-04-01 18:21:34 --> Language Class Initialized
INFO - 2018-04-01 18:21:34 --> Loader Class Initialized
INFO - 2018-04-01 18:21:34 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:34 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:34 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:34 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:34 --> Model Class Initialized
INFO - 2018-04-01 18:21:34 --> Controller Class Initialized
INFO - 2018-04-01 18:21:34 --> Model Class Initialized
INFO - 2018-04-01 18:21:34 --> Model Class Initialized
INFO - 2018-04-01 18:21:34 --> Model Class Initialized
INFO - 2018-04-01 18:21:34 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:36 --> Config Class Initialized
INFO - 2018-04-01 18:21:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:21:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:21:36 --> Utf8 Class Initialized
INFO - 2018-04-01 18:21:36 --> URI Class Initialized
INFO - 2018-04-01 18:21:36 --> Router Class Initialized
INFO - 2018-04-01 18:21:36 --> Output Class Initialized
INFO - 2018-04-01 18:21:36 --> Security Class Initialized
DEBUG - 2018-04-01 18:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:21:36 --> Input Class Initialized
INFO - 2018-04-01 18:21:36 --> Language Class Initialized
INFO - 2018-04-01 18:21:36 --> Loader Class Initialized
INFO - 2018-04-01 18:21:36 --> Helper loaded: url_helper
INFO - 2018-04-01 18:21:36 --> Helper loaded: form_helper
INFO - 2018-04-01 18:21:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:21:36 --> Form Validation Class Initialized
INFO - 2018-04-01 18:21:36 --> Model Class Initialized
INFO - 2018-04-01 18:21:36 --> Controller Class Initialized
INFO - 2018-04-01 18:21:36 --> Model Class Initialized
INFO - 2018-04-01 18:21:36 --> Model Class Initialized
INFO - 2018-04-01 18:21:36 --> Model Class Initialized
INFO - 2018-04-01 18:21:36 --> Model Class Initialized
DEBUG - 2018-04-01 18:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:21:37 --> Final output sent to browser
DEBUG - 2018-04-01 18:21:37 --> Total execution time: 0.2967
INFO - 2018-04-01 18:24:35 --> Config Class Initialized
INFO - 2018-04-01 18:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:24:35 --> Utf8 Class Initialized
INFO - 2018-04-01 18:24:35 --> URI Class Initialized
INFO - 2018-04-01 18:24:35 --> Router Class Initialized
INFO - 2018-04-01 18:24:35 --> Output Class Initialized
INFO - 2018-04-01 18:24:35 --> Security Class Initialized
DEBUG - 2018-04-01 18:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:24:35 --> Input Class Initialized
INFO - 2018-04-01 18:24:35 --> Language Class Initialized
INFO - 2018-04-01 18:24:35 --> Loader Class Initialized
INFO - 2018-04-01 18:24:35 --> Helper loaded: url_helper
INFO - 2018-04-01 18:24:35 --> Helper loaded: form_helper
INFO - 2018-04-01 18:24:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:24:35 --> Form Validation Class Initialized
INFO - 2018-04-01 18:24:35 --> Model Class Initialized
INFO - 2018-04-01 18:24:35 --> Controller Class Initialized
INFO - 2018-04-01 18:24:35 --> Model Class Initialized
INFO - 2018-04-01 18:24:35 --> Model Class Initialized
INFO - 2018-04-01 18:24:35 --> Model Class Initialized
INFO - 2018-04-01 18:24:35 --> Model Class Initialized
DEBUG - 2018-04-01 18:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:24:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:24:35 --> Final output sent to browser
DEBUG - 2018-04-01 18:24:35 --> Total execution time: 0.0678
INFO - 2018-04-01 18:24:42 --> Config Class Initialized
INFO - 2018-04-01 18:24:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:24:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:24:42 --> Utf8 Class Initialized
INFO - 2018-04-01 18:24:42 --> URI Class Initialized
INFO - 2018-04-01 18:24:42 --> Router Class Initialized
INFO - 2018-04-01 18:24:42 --> Output Class Initialized
INFO - 2018-04-01 18:24:42 --> Security Class Initialized
DEBUG - 2018-04-01 18:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:24:42 --> Input Class Initialized
INFO - 2018-04-01 18:24:42 --> Language Class Initialized
ERROR - 2018-04-01 18:24:42 --> 404 Page Not Found: Reporte/reporteGastosMaterialesPorProyecto
INFO - 2018-04-01 18:33:43 --> Config Class Initialized
INFO - 2018-04-01 18:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 18:33:43 --> URI Class Initialized
INFO - 2018-04-01 18:33:43 --> Router Class Initialized
INFO - 2018-04-01 18:33:43 --> Output Class Initialized
INFO - 2018-04-01 18:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:33:43 --> Input Class Initialized
INFO - 2018-04-01 18:33:43 --> Language Class Initialized
INFO - 2018-04-01 18:33:43 --> Loader Class Initialized
INFO - 2018-04-01 18:33:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:33:43 --> Helper loaded: form_helper
INFO - 2018-04-01 18:33:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:33:43 --> Form Validation Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Controller Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:33:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:33:43 --> Final output sent to browser
DEBUG - 2018-04-01 18:33:43 --> Total execution time: 0.3344
INFO - 2018-04-01 18:33:43 --> Config Class Initialized
INFO - 2018-04-01 18:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 18:33:43 --> URI Class Initialized
INFO - 2018-04-01 18:33:43 --> Router Class Initialized
INFO - 2018-04-01 18:33:43 --> Output Class Initialized
INFO - 2018-04-01 18:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:33:43 --> Input Class Initialized
INFO - 2018-04-01 18:33:43 --> Language Class Initialized
INFO - 2018-04-01 18:33:43 --> Loader Class Initialized
INFO - 2018-04-01 18:33:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:33:43 --> Helper loaded: form_helper
INFO - 2018-04-01 18:33:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:33:43 --> Form Validation Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Controller Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
INFO - 2018-04-01 18:33:43 --> Model Class Initialized
DEBUG - 2018-04-01 18:33:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:13 --> Config Class Initialized
INFO - 2018-04-01 18:34:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:13 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:13 --> URI Class Initialized
INFO - 2018-04-01 18:34:13 --> Router Class Initialized
INFO - 2018-04-01 18:34:13 --> Output Class Initialized
INFO - 2018-04-01 18:34:13 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:13 --> Input Class Initialized
INFO - 2018-04-01 18:34:13 --> Language Class Initialized
INFO - 2018-04-01 18:34:13 --> Loader Class Initialized
INFO - 2018-04-01 18:34:13 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:13 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:13 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
INFO - 2018-04-01 18:34:13 --> Controller Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
INFO - 2018-04-01 18:34:13 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:17 --> Config Class Initialized
INFO - 2018-04-01 18:34:17 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:17 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:17 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:17 --> URI Class Initialized
INFO - 2018-04-01 18:34:17 --> Router Class Initialized
INFO - 2018-04-01 18:34:17 --> Output Class Initialized
INFO - 2018-04-01 18:34:17 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:17 --> Input Class Initialized
INFO - 2018-04-01 18:34:17 --> Language Class Initialized
INFO - 2018-04-01 18:34:17 --> Loader Class Initialized
INFO - 2018-04-01 18:34:17 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:17 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:17 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:17 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
INFO - 2018-04-01 18:34:17 --> Controller Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
INFO - 2018-04-01 18:34:17 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:20 --> Config Class Initialized
INFO - 2018-04-01 18:34:20 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:20 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:20 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:20 --> URI Class Initialized
INFO - 2018-04-01 18:34:20 --> Router Class Initialized
INFO - 2018-04-01 18:34:20 --> Output Class Initialized
INFO - 2018-04-01 18:34:20 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:20 --> Input Class Initialized
INFO - 2018-04-01 18:34:20 --> Language Class Initialized
INFO - 2018-04-01 18:34:20 --> Loader Class Initialized
INFO - 2018-04-01 18:34:20 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:20 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:20 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:20 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
INFO - 2018-04-01 18:34:20 --> Controller Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
INFO - 2018-04-01 18:34:20 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:21 --> Config Class Initialized
INFO - 2018-04-01 18:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:21 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:21 --> URI Class Initialized
INFO - 2018-04-01 18:34:21 --> Router Class Initialized
INFO - 2018-04-01 18:34:21 --> Output Class Initialized
INFO - 2018-04-01 18:34:21 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:21 --> Input Class Initialized
INFO - 2018-04-01 18:34:21 --> Language Class Initialized
INFO - 2018-04-01 18:34:21 --> Loader Class Initialized
INFO - 2018-04-01 18:34:21 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:21 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:21 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:21 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
INFO - 2018-04-01 18:34:21 --> Controller Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
INFO - 2018-04-01 18:34:21 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:22 --> Config Class Initialized
INFO - 2018-04-01 18:34:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:22 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:22 --> URI Class Initialized
INFO - 2018-04-01 18:34:22 --> Router Class Initialized
INFO - 2018-04-01 18:34:22 --> Output Class Initialized
INFO - 2018-04-01 18:34:22 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:22 --> Input Class Initialized
INFO - 2018-04-01 18:34:22 --> Language Class Initialized
INFO - 2018-04-01 18:34:22 --> Loader Class Initialized
INFO - 2018-04-01 18:34:22 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:22 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:22 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
INFO - 2018-04-01 18:34:22 --> Controller Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
INFO - 2018-04-01 18:34:22 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:23 --> Config Class Initialized
INFO - 2018-04-01 18:34:23 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:23 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:23 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:23 --> URI Class Initialized
INFO - 2018-04-01 18:34:23 --> Router Class Initialized
INFO - 2018-04-01 18:34:23 --> Output Class Initialized
INFO - 2018-04-01 18:34:23 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:23 --> Input Class Initialized
INFO - 2018-04-01 18:34:23 --> Language Class Initialized
INFO - 2018-04-01 18:34:23 --> Loader Class Initialized
INFO - 2018-04-01 18:34:23 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:23 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:23 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:23 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
INFO - 2018-04-01 18:34:23 --> Controller Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
INFO - 2018-04-01 18:34:23 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:24 --> Config Class Initialized
INFO - 2018-04-01 18:34:24 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:24 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:24 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:24 --> URI Class Initialized
INFO - 2018-04-01 18:34:24 --> Router Class Initialized
INFO - 2018-04-01 18:34:24 --> Output Class Initialized
INFO - 2018-04-01 18:34:24 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:24 --> Input Class Initialized
INFO - 2018-04-01 18:34:24 --> Language Class Initialized
INFO - 2018-04-01 18:34:24 --> Loader Class Initialized
INFO - 2018-04-01 18:34:24 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:24 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:24 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:24 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
INFO - 2018-04-01 18:34:24 --> Controller Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
INFO - 2018-04-01 18:34:24 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:29 --> Config Class Initialized
INFO - 2018-04-01 18:34:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:29 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:29 --> URI Class Initialized
INFO - 2018-04-01 18:34:29 --> Router Class Initialized
INFO - 2018-04-01 18:34:29 --> Output Class Initialized
INFO - 2018-04-01 18:34:29 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:29 --> Input Class Initialized
INFO - 2018-04-01 18:34:29 --> Language Class Initialized
INFO - 2018-04-01 18:34:29 --> Loader Class Initialized
INFO - 2018-04-01 18:34:29 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:29 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:29 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:29 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
INFO - 2018-04-01 18:34:29 --> Controller Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
INFO - 2018-04-01 18:34:29 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:30 --> Config Class Initialized
INFO - 2018-04-01 18:34:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:30 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:30 --> URI Class Initialized
INFO - 2018-04-01 18:34:30 --> Router Class Initialized
INFO - 2018-04-01 18:34:30 --> Output Class Initialized
INFO - 2018-04-01 18:34:30 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:30 --> Input Class Initialized
INFO - 2018-04-01 18:34:30 --> Language Class Initialized
INFO - 2018-04-01 18:34:30 --> Loader Class Initialized
INFO - 2018-04-01 18:34:30 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:30 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:30 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
INFO - 2018-04-01 18:34:30 --> Controller Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
INFO - 2018-04-01 18:34:30 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:32 --> Config Class Initialized
INFO - 2018-04-01 18:34:32 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:32 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:32 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:32 --> URI Class Initialized
INFO - 2018-04-01 18:34:32 --> Router Class Initialized
INFO - 2018-04-01 18:34:32 --> Output Class Initialized
INFO - 2018-04-01 18:34:32 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:32 --> Input Class Initialized
INFO - 2018-04-01 18:34:32 --> Language Class Initialized
INFO - 2018-04-01 18:34:32 --> Loader Class Initialized
INFO - 2018-04-01 18:34:32 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:32 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:32 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:32 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
INFO - 2018-04-01 18:34:32 --> Controller Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
INFO - 2018-04-01 18:34:32 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:33 --> Config Class Initialized
INFO - 2018-04-01 18:34:33 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:33 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:33 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:33 --> URI Class Initialized
INFO - 2018-04-01 18:34:33 --> Router Class Initialized
INFO - 2018-04-01 18:34:33 --> Output Class Initialized
INFO - 2018-04-01 18:34:33 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:33 --> Input Class Initialized
INFO - 2018-04-01 18:34:33 --> Language Class Initialized
INFO - 2018-04-01 18:34:33 --> Loader Class Initialized
INFO - 2018-04-01 18:34:33 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:33 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:33 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:33 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
INFO - 2018-04-01 18:34:33 --> Controller Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
INFO - 2018-04-01 18:34:33 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:34 --> Config Class Initialized
INFO - 2018-04-01 18:34:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:34 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:34 --> URI Class Initialized
INFO - 2018-04-01 18:34:34 --> Router Class Initialized
INFO - 2018-04-01 18:34:34 --> Output Class Initialized
INFO - 2018-04-01 18:34:34 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:34 --> Input Class Initialized
INFO - 2018-04-01 18:34:34 --> Language Class Initialized
INFO - 2018-04-01 18:34:34 --> Loader Class Initialized
INFO - 2018-04-01 18:34:34 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:34 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:34 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:34 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
INFO - 2018-04-01 18:34:34 --> Controller Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
INFO - 2018-04-01 18:34:34 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:36 --> Config Class Initialized
INFO - 2018-04-01 18:34:36 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:36 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:36 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:36 --> URI Class Initialized
INFO - 2018-04-01 18:34:36 --> Router Class Initialized
INFO - 2018-04-01 18:34:36 --> Output Class Initialized
INFO - 2018-04-01 18:34:36 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:36 --> Input Class Initialized
INFO - 2018-04-01 18:34:36 --> Language Class Initialized
INFO - 2018-04-01 18:34:36 --> Loader Class Initialized
INFO - 2018-04-01 18:34:36 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:36 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:36 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:36 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
INFO - 2018-04-01 18:34:36 --> Controller Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
INFO - 2018-04-01 18:34:36 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:37 --> Config Class Initialized
INFO - 2018-04-01 18:34:37 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:37 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:37 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:37 --> URI Class Initialized
INFO - 2018-04-01 18:34:37 --> Router Class Initialized
INFO - 2018-04-01 18:34:37 --> Output Class Initialized
INFO - 2018-04-01 18:34:37 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:37 --> Input Class Initialized
INFO - 2018-04-01 18:34:37 --> Language Class Initialized
INFO - 2018-04-01 18:34:37 --> Loader Class Initialized
INFO - 2018-04-01 18:34:37 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:37 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:37 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:37 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
INFO - 2018-04-01 18:34:37 --> Controller Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
INFO - 2018-04-01 18:34:37 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:38 --> Config Class Initialized
INFO - 2018-04-01 18:34:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:38 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:38 --> URI Class Initialized
INFO - 2018-04-01 18:34:38 --> Router Class Initialized
INFO - 2018-04-01 18:34:38 --> Output Class Initialized
INFO - 2018-04-01 18:34:38 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:38 --> Input Class Initialized
INFO - 2018-04-01 18:34:38 --> Language Class Initialized
INFO - 2018-04-01 18:34:38 --> Loader Class Initialized
INFO - 2018-04-01 18:34:38 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:38 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:38 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:38 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
INFO - 2018-04-01 18:34:38 --> Controller Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
INFO - 2018-04-01 18:34:38 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:41 --> Config Class Initialized
INFO - 2018-04-01 18:34:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:41 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:41 --> URI Class Initialized
INFO - 2018-04-01 18:34:41 --> Router Class Initialized
INFO - 2018-04-01 18:34:41 --> Output Class Initialized
INFO - 2018-04-01 18:34:41 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:41 --> Input Class Initialized
INFO - 2018-04-01 18:34:41 --> Language Class Initialized
INFO - 2018-04-01 18:34:41 --> Loader Class Initialized
INFO - 2018-04-01 18:34:41 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:41 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:41 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:41 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
INFO - 2018-04-01 18:34:41 --> Controller Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
INFO - 2018-04-01 18:34:41 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:42 --> Config Class Initialized
INFO - 2018-04-01 18:34:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:42 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:42 --> URI Class Initialized
INFO - 2018-04-01 18:34:42 --> Router Class Initialized
INFO - 2018-04-01 18:34:42 --> Output Class Initialized
INFO - 2018-04-01 18:34:42 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:42 --> Input Class Initialized
INFO - 2018-04-01 18:34:42 --> Language Class Initialized
INFO - 2018-04-01 18:34:42 --> Loader Class Initialized
INFO - 2018-04-01 18:34:42 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:42 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:42 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
INFO - 2018-04-01 18:34:42 --> Controller Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
INFO - 2018-04-01 18:34:42 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:44 --> Config Class Initialized
INFO - 2018-04-01 18:34:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:44 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:44 --> URI Class Initialized
INFO - 2018-04-01 18:34:44 --> Router Class Initialized
INFO - 2018-04-01 18:34:44 --> Output Class Initialized
INFO - 2018-04-01 18:34:44 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:44 --> Input Class Initialized
INFO - 2018-04-01 18:34:44 --> Language Class Initialized
INFO - 2018-04-01 18:34:44 --> Loader Class Initialized
INFO - 2018-04-01 18:34:44 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:44 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:44 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:44 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
INFO - 2018-04-01 18:34:44 --> Controller Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
INFO - 2018-04-01 18:34:44 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:45 --> Config Class Initialized
INFO - 2018-04-01 18:34:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:45 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:45 --> URI Class Initialized
INFO - 2018-04-01 18:34:45 --> Router Class Initialized
INFO - 2018-04-01 18:34:45 --> Output Class Initialized
INFO - 2018-04-01 18:34:45 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:45 --> Input Class Initialized
INFO - 2018-04-01 18:34:45 --> Language Class Initialized
INFO - 2018-04-01 18:34:45 --> Loader Class Initialized
INFO - 2018-04-01 18:34:45 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:45 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:45 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
INFO - 2018-04-01 18:34:45 --> Controller Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
INFO - 2018-04-01 18:34:45 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:46 --> Config Class Initialized
INFO - 2018-04-01 18:34:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:46 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:46 --> URI Class Initialized
INFO - 2018-04-01 18:34:46 --> Router Class Initialized
INFO - 2018-04-01 18:34:46 --> Output Class Initialized
INFO - 2018-04-01 18:34:46 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:46 --> Input Class Initialized
INFO - 2018-04-01 18:34:46 --> Language Class Initialized
INFO - 2018-04-01 18:34:46 --> Loader Class Initialized
INFO - 2018-04-01 18:34:46 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:46 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:46 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:46 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
INFO - 2018-04-01 18:34:46 --> Controller Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
INFO - 2018-04-01 18:34:46 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:49 --> Config Class Initialized
INFO - 2018-04-01 18:34:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:49 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:49 --> URI Class Initialized
INFO - 2018-04-01 18:34:49 --> Router Class Initialized
INFO - 2018-04-01 18:34:49 --> Output Class Initialized
INFO - 2018-04-01 18:34:49 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:49 --> Input Class Initialized
INFO - 2018-04-01 18:34:49 --> Language Class Initialized
INFO - 2018-04-01 18:34:49 --> Loader Class Initialized
INFO - 2018-04-01 18:34:49 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:49 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:49 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:49 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
INFO - 2018-04-01 18:34:49 --> Controller Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
INFO - 2018-04-01 18:34:49 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:50 --> Config Class Initialized
INFO - 2018-04-01 18:34:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:50 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:50 --> URI Class Initialized
INFO - 2018-04-01 18:34:50 --> Router Class Initialized
INFO - 2018-04-01 18:34:50 --> Output Class Initialized
INFO - 2018-04-01 18:34:50 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:50 --> Input Class Initialized
INFO - 2018-04-01 18:34:50 --> Language Class Initialized
INFO - 2018-04-01 18:34:50 --> Loader Class Initialized
INFO - 2018-04-01 18:34:50 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:50 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:50 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
INFO - 2018-04-01 18:34:50 --> Controller Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
INFO - 2018-04-01 18:34:50 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:34:52 --> Config Class Initialized
INFO - 2018-04-01 18:34:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:34:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:34:52 --> Utf8 Class Initialized
INFO - 2018-04-01 18:34:52 --> URI Class Initialized
INFO - 2018-04-01 18:34:52 --> Router Class Initialized
INFO - 2018-04-01 18:34:52 --> Output Class Initialized
INFO - 2018-04-01 18:34:52 --> Security Class Initialized
DEBUG - 2018-04-01 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:34:52 --> Input Class Initialized
INFO - 2018-04-01 18:34:52 --> Language Class Initialized
INFO - 2018-04-01 18:34:52 --> Loader Class Initialized
INFO - 2018-04-01 18:34:52 --> Helper loaded: url_helper
INFO - 2018-04-01 18:34:52 --> Helper loaded: form_helper
INFO - 2018-04-01 18:34:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:34:52 --> Form Validation Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
INFO - 2018-04-01 18:34:52 --> Controller Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
INFO - 2018-04-01 18:34:52 --> Model Class Initialized
DEBUG - 2018-04-01 18:34:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:08 --> Config Class Initialized
INFO - 2018-04-01 18:35:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:08 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:08 --> URI Class Initialized
INFO - 2018-04-01 18:35:08 --> Router Class Initialized
INFO - 2018-04-01 18:35:08 --> Output Class Initialized
INFO - 2018-04-01 18:35:08 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:08 --> Input Class Initialized
INFO - 2018-04-01 18:35:08 --> Language Class Initialized
INFO - 2018-04-01 18:35:08 --> Loader Class Initialized
INFO - 2018-04-01 18:35:09 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:09 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:09 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:09 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
INFO - 2018-04-01 18:35:09 --> Controller Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
INFO - 2018-04-01 18:35:09 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:10 --> Config Class Initialized
INFO - 2018-04-01 18:35:10 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:10 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:10 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:10 --> URI Class Initialized
INFO - 2018-04-01 18:35:10 --> Router Class Initialized
INFO - 2018-04-01 18:35:10 --> Output Class Initialized
INFO - 2018-04-01 18:35:10 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:10 --> Input Class Initialized
INFO - 2018-04-01 18:35:10 --> Language Class Initialized
INFO - 2018-04-01 18:35:10 --> Loader Class Initialized
INFO - 2018-04-01 18:35:10 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:10 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:10 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:10 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
INFO - 2018-04-01 18:35:10 --> Controller Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
INFO - 2018-04-01 18:35:10 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:13 --> Config Class Initialized
INFO - 2018-04-01 18:35:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:13 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:13 --> URI Class Initialized
INFO - 2018-04-01 18:35:13 --> Router Class Initialized
INFO - 2018-04-01 18:35:13 --> Output Class Initialized
INFO - 2018-04-01 18:35:13 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:13 --> Input Class Initialized
INFO - 2018-04-01 18:35:13 --> Language Class Initialized
INFO - 2018-04-01 18:35:13 --> Loader Class Initialized
INFO - 2018-04-01 18:35:13 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:13 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:13 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
INFO - 2018-04-01 18:35:13 --> Controller Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
INFO - 2018-04-01 18:35:13 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:14 --> Config Class Initialized
INFO - 2018-04-01 18:35:14 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:14 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:14 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:14 --> URI Class Initialized
INFO - 2018-04-01 18:35:14 --> Router Class Initialized
INFO - 2018-04-01 18:35:14 --> Output Class Initialized
INFO - 2018-04-01 18:35:14 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:14 --> Input Class Initialized
INFO - 2018-04-01 18:35:14 --> Language Class Initialized
INFO - 2018-04-01 18:35:14 --> Loader Class Initialized
INFO - 2018-04-01 18:35:14 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:14 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:14 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:14 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
INFO - 2018-04-01 18:35:14 --> Controller Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
INFO - 2018-04-01 18:35:14 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:19 --> Config Class Initialized
INFO - 2018-04-01 18:35:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:19 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:19 --> URI Class Initialized
INFO - 2018-04-01 18:35:19 --> Router Class Initialized
INFO - 2018-04-01 18:35:19 --> Output Class Initialized
INFO - 2018-04-01 18:35:19 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:19 --> Input Class Initialized
INFO - 2018-04-01 18:35:19 --> Language Class Initialized
INFO - 2018-04-01 18:35:19 --> Loader Class Initialized
INFO - 2018-04-01 18:35:19 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:19 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:19 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:19 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
INFO - 2018-04-01 18:35:19 --> Controller Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
INFO - 2018-04-01 18:35:19 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:21 --> Config Class Initialized
INFO - 2018-04-01 18:35:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:21 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:21 --> URI Class Initialized
INFO - 2018-04-01 18:35:21 --> Router Class Initialized
INFO - 2018-04-01 18:35:21 --> Output Class Initialized
INFO - 2018-04-01 18:35:21 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:21 --> Input Class Initialized
INFO - 2018-04-01 18:35:21 --> Language Class Initialized
INFO - 2018-04-01 18:35:21 --> Loader Class Initialized
INFO - 2018-04-01 18:35:21 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:21 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:21 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:21 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
INFO - 2018-04-01 18:35:21 --> Controller Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
INFO - 2018-04-01 18:35:21 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:24 --> Config Class Initialized
INFO - 2018-04-01 18:35:24 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:24 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:24 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:24 --> URI Class Initialized
INFO - 2018-04-01 18:35:24 --> Router Class Initialized
INFO - 2018-04-01 18:35:24 --> Output Class Initialized
INFO - 2018-04-01 18:35:24 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:24 --> Input Class Initialized
INFO - 2018-04-01 18:35:24 --> Language Class Initialized
INFO - 2018-04-01 18:35:24 --> Loader Class Initialized
INFO - 2018-04-01 18:35:24 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:24 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:24 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:24 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
INFO - 2018-04-01 18:35:24 --> Controller Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
INFO - 2018-04-01 18:35:24 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:35:26 --> Config Class Initialized
INFO - 2018-04-01 18:35:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:35:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:35:26 --> Utf8 Class Initialized
INFO - 2018-04-01 18:35:26 --> URI Class Initialized
INFO - 2018-04-01 18:35:26 --> Router Class Initialized
INFO - 2018-04-01 18:35:26 --> Output Class Initialized
INFO - 2018-04-01 18:35:26 --> Security Class Initialized
DEBUG - 2018-04-01 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:35:26 --> Input Class Initialized
INFO - 2018-04-01 18:35:26 --> Language Class Initialized
INFO - 2018-04-01 18:35:26 --> Loader Class Initialized
INFO - 2018-04-01 18:35:26 --> Helper loaded: url_helper
INFO - 2018-04-01 18:35:26 --> Helper loaded: form_helper
INFO - 2018-04-01 18:35:26 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:35:26 --> Form Validation Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
INFO - 2018-04-01 18:35:26 --> Controller Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
INFO - 2018-04-01 18:35:26 --> Model Class Initialized
DEBUG - 2018-04-01 18:35:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:13 --> Config Class Initialized
INFO - 2018-04-01 18:41:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:13 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:13 --> URI Class Initialized
INFO - 2018-04-01 18:41:13 --> Router Class Initialized
INFO - 2018-04-01 18:41:13 --> Output Class Initialized
INFO - 2018-04-01 18:41:13 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:13 --> Input Class Initialized
INFO - 2018-04-01 18:41:13 --> Language Class Initialized
INFO - 2018-04-01 18:41:13 --> Loader Class Initialized
INFO - 2018-04-01 18:41:13 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:13 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:13 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Controller Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:41:13 --> Final output sent to browser
DEBUG - 2018-04-01 18:41:13 --> Total execution time: 0.0565
INFO - 2018-04-01 18:41:13 --> Config Class Initialized
INFO - 2018-04-01 18:41:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:13 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:13 --> URI Class Initialized
INFO - 2018-04-01 18:41:13 --> Router Class Initialized
INFO - 2018-04-01 18:41:13 --> Output Class Initialized
INFO - 2018-04-01 18:41:13 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:13 --> Input Class Initialized
INFO - 2018-04-01 18:41:13 --> Language Class Initialized
INFO - 2018-04-01 18:41:13 --> Loader Class Initialized
INFO - 2018-04-01 18:41:13 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:13 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:13 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:13 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Controller Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
INFO - 2018-04-01 18:41:13 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:22 --> Config Class Initialized
INFO - 2018-04-01 18:41:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:22 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:22 --> URI Class Initialized
INFO - 2018-04-01 18:41:22 --> Router Class Initialized
INFO - 2018-04-01 18:41:22 --> Output Class Initialized
INFO - 2018-04-01 18:41:22 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:22 --> Input Class Initialized
INFO - 2018-04-01 18:41:22 --> Language Class Initialized
INFO - 2018-04-01 18:41:22 --> Loader Class Initialized
INFO - 2018-04-01 18:41:22 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:22 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:22 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:22 --> Model Class Initialized
INFO - 2018-04-01 18:41:22 --> Controller Class Initialized
INFO - 2018-04-01 18:41:22 --> Model Class Initialized
INFO - 2018-04-01 18:41:22 --> Model Class Initialized
INFO - 2018-04-01 18:41:22 --> Model Class Initialized
INFO - 2018-04-01 18:41:22 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:41:22 --> Final output sent to browser
DEBUG - 2018-04-01 18:41:22 --> Total execution time: 0.0616
INFO - 2018-04-01 18:41:22 --> Config Class Initialized
INFO - 2018-04-01 18:41:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:22 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:22 --> URI Class Initialized
INFO - 2018-04-01 18:41:22 --> Router Class Initialized
INFO - 2018-04-01 18:41:22 --> Output Class Initialized
INFO - 2018-04-01 18:41:22 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:22 --> Input Class Initialized
INFO - 2018-04-01 18:41:22 --> Language Class Initialized
INFO - 2018-04-01 18:41:22 --> Loader Class Initialized
INFO - 2018-04-01 18:41:22 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:22 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:23 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:23 --> Model Class Initialized
INFO - 2018-04-01 18:41:23 --> Controller Class Initialized
INFO - 2018-04-01 18:41:23 --> Model Class Initialized
INFO - 2018-04-01 18:41:23 --> Model Class Initialized
INFO - 2018-04-01 18:41:23 --> Model Class Initialized
INFO - 2018-04-01 18:41:23 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:56 --> Config Class Initialized
INFO - 2018-04-01 18:41:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:56 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:56 --> URI Class Initialized
INFO - 2018-04-01 18:41:56 --> Router Class Initialized
INFO - 2018-04-01 18:41:56 --> Output Class Initialized
INFO - 2018-04-01 18:41:56 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:56 --> Input Class Initialized
INFO - 2018-04-01 18:41:56 --> Language Class Initialized
INFO - 2018-04-01 18:41:56 --> Loader Class Initialized
INFO - 2018-04-01 18:41:56 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:56 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:56 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:56 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Controller Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:41:56 --> Final output sent to browser
DEBUG - 2018-04-01 18:41:56 --> Total execution time: 0.0712
INFO - 2018-04-01 18:41:56 --> Config Class Initialized
INFO - 2018-04-01 18:41:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:56 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:56 --> URI Class Initialized
INFO - 2018-04-01 18:41:56 --> Router Class Initialized
INFO - 2018-04-01 18:41:56 --> Output Class Initialized
INFO - 2018-04-01 18:41:56 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:56 --> Input Class Initialized
INFO - 2018-04-01 18:41:56 --> Language Class Initialized
INFO - 2018-04-01 18:41:56 --> Loader Class Initialized
INFO - 2018-04-01 18:41:56 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:56 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:56 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:56 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Controller Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
INFO - 2018-04-01 18:41:56 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:59 --> Config Class Initialized
INFO - 2018-04-01 18:41:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:41:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:41:59 --> Utf8 Class Initialized
INFO - 2018-04-01 18:41:59 --> URI Class Initialized
INFO - 2018-04-01 18:41:59 --> Router Class Initialized
INFO - 2018-04-01 18:41:59 --> Output Class Initialized
INFO - 2018-04-01 18:41:59 --> Security Class Initialized
DEBUG - 2018-04-01 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:41:59 --> Input Class Initialized
INFO - 2018-04-01 18:41:59 --> Language Class Initialized
INFO - 2018-04-01 18:41:59 --> Loader Class Initialized
INFO - 2018-04-01 18:41:59 --> Helper loaded: url_helper
INFO - 2018-04-01 18:41:59 --> Helper loaded: form_helper
INFO - 2018-04-01 18:41:59 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:41:59 --> Form Validation Class Initialized
INFO - 2018-04-01 18:41:59 --> Model Class Initialized
INFO - 2018-04-01 18:41:59 --> Controller Class Initialized
INFO - 2018-04-01 18:41:59 --> Model Class Initialized
INFO - 2018-04-01 18:41:59 --> Model Class Initialized
INFO - 2018-04-01 18:41:59 --> Model Class Initialized
INFO - 2018-04-01 18:41:59 --> Model Class Initialized
DEBUG - 2018-04-01 18:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:41:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:41:59 --> Final output sent to browser
DEBUG - 2018-04-01 18:41:59 --> Total execution time: 0.0573
INFO - 2018-04-01 18:42:00 --> Config Class Initialized
INFO - 2018-04-01 18:42:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:42:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:42:00 --> Utf8 Class Initialized
INFO - 2018-04-01 18:42:00 --> URI Class Initialized
INFO - 2018-04-01 18:42:00 --> Router Class Initialized
INFO - 2018-04-01 18:42:00 --> Output Class Initialized
INFO - 2018-04-01 18:42:00 --> Security Class Initialized
DEBUG - 2018-04-01 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:42:00 --> Input Class Initialized
INFO - 2018-04-01 18:42:00 --> Language Class Initialized
INFO - 2018-04-01 18:42:00 --> Loader Class Initialized
INFO - 2018-04-01 18:42:00 --> Helper loaded: url_helper
INFO - 2018-04-01 18:42:00 --> Helper loaded: form_helper
INFO - 2018-04-01 18:42:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:42:00 --> Form Validation Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
INFO - 2018-04-01 18:42:00 --> Controller Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
INFO - 2018-04-01 18:42:00 --> Model Class Initialized
DEBUG - 2018-04-01 18:42:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:42:01 --> Config Class Initialized
INFO - 2018-04-01 18:42:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:42:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:42:01 --> Utf8 Class Initialized
INFO - 2018-04-01 18:42:01 --> URI Class Initialized
INFO - 2018-04-01 18:42:01 --> Router Class Initialized
INFO - 2018-04-01 18:42:01 --> Output Class Initialized
INFO - 2018-04-01 18:42:01 --> Security Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:42:01 --> Input Class Initialized
INFO - 2018-04-01 18:42:01 --> Language Class Initialized
INFO - 2018-04-01 18:42:01 --> Loader Class Initialized
INFO - 2018-04-01 18:42:01 --> Helper loaded: url_helper
INFO - 2018-04-01 18:42:01 --> Helper loaded: form_helper
INFO - 2018-04-01 18:42:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:42:01 --> Form Validation Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Controller Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:42:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:42:01 --> Final output sent to browser
DEBUG - 2018-04-01 18:42:01 --> Total execution time: 0.0614
INFO - 2018-04-01 18:42:01 --> Config Class Initialized
INFO - 2018-04-01 18:42:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:42:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:42:01 --> Utf8 Class Initialized
INFO - 2018-04-01 18:42:01 --> URI Class Initialized
INFO - 2018-04-01 18:42:01 --> Router Class Initialized
INFO - 2018-04-01 18:42:01 --> Output Class Initialized
INFO - 2018-04-01 18:42:01 --> Security Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:42:01 --> Input Class Initialized
INFO - 2018-04-01 18:42:01 --> Language Class Initialized
INFO - 2018-04-01 18:42:01 --> Loader Class Initialized
INFO - 2018-04-01 18:42:01 --> Helper loaded: url_helper
INFO - 2018-04-01 18:42:01 --> Helper loaded: form_helper
INFO - 2018-04-01 18:42:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:42:01 --> Form Validation Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Controller Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
INFO - 2018-04-01 18:42:01 --> Model Class Initialized
DEBUG - 2018-04-01 18:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:42:12 --> Config Class Initialized
INFO - 2018-04-01 18:42:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:42:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:42:12 --> Utf8 Class Initialized
INFO - 2018-04-01 18:42:12 --> URI Class Initialized
INFO - 2018-04-01 18:42:12 --> Router Class Initialized
INFO - 2018-04-01 18:42:12 --> Output Class Initialized
INFO - 2018-04-01 18:42:12 --> Security Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:42:12 --> Input Class Initialized
INFO - 2018-04-01 18:42:12 --> Language Class Initialized
INFO - 2018-04-01 18:42:12 --> Loader Class Initialized
INFO - 2018-04-01 18:42:12 --> Helper loaded: url_helper
INFO - 2018-04-01 18:42:12 --> Helper loaded: form_helper
INFO - 2018-04-01 18:42:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:42:12 --> Form Validation Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Controller Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:42:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:42:12 --> Final output sent to browser
DEBUG - 2018-04-01 18:42:12 --> Total execution time: 0.0601
INFO - 2018-04-01 18:42:12 --> Config Class Initialized
INFO - 2018-04-01 18:42:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:42:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:42:12 --> Utf8 Class Initialized
INFO - 2018-04-01 18:42:12 --> URI Class Initialized
INFO - 2018-04-01 18:42:12 --> Router Class Initialized
INFO - 2018-04-01 18:42:12 --> Output Class Initialized
INFO - 2018-04-01 18:42:12 --> Security Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:42:12 --> Input Class Initialized
INFO - 2018-04-01 18:42:12 --> Language Class Initialized
INFO - 2018-04-01 18:42:12 --> Loader Class Initialized
INFO - 2018-04-01 18:42:12 --> Helper loaded: url_helper
INFO - 2018-04-01 18:42:12 --> Helper loaded: form_helper
INFO - 2018-04-01 18:42:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:42:12 --> Form Validation Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Controller Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
INFO - 2018-04-01 18:42:12 --> Model Class Initialized
DEBUG - 2018-04-01 18:42:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:04 --> Config Class Initialized
INFO - 2018-04-01 18:44:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:04 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:04 --> URI Class Initialized
INFO - 2018-04-01 18:44:04 --> Router Class Initialized
INFO - 2018-04-01 18:44:04 --> Output Class Initialized
INFO - 2018-04-01 18:44:04 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:04 --> Input Class Initialized
INFO - 2018-04-01 18:44:04 --> Language Class Initialized
INFO - 2018-04-01 18:44:04 --> Loader Class Initialized
INFO - 2018-04-01 18:44:04 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:04 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:04 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:04 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Controller Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:44:04 --> Final output sent to browser
DEBUG - 2018-04-01 18:44:04 --> Total execution time: 0.0541
INFO - 2018-04-01 18:44:04 --> Config Class Initialized
INFO - 2018-04-01 18:44:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:04 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:04 --> URI Class Initialized
INFO - 2018-04-01 18:44:04 --> Router Class Initialized
INFO - 2018-04-01 18:44:04 --> Output Class Initialized
INFO - 2018-04-01 18:44:04 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:04 --> Input Class Initialized
INFO - 2018-04-01 18:44:04 --> Language Class Initialized
INFO - 2018-04-01 18:44:04 --> Loader Class Initialized
INFO - 2018-04-01 18:44:04 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:04 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:04 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:04 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Controller Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
INFO - 2018-04-01 18:44:04 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:06 --> Config Class Initialized
INFO - 2018-04-01 18:44:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:06 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:06 --> URI Class Initialized
INFO - 2018-04-01 18:44:06 --> Router Class Initialized
INFO - 2018-04-01 18:44:06 --> Output Class Initialized
INFO - 2018-04-01 18:44:06 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:06 --> Input Class Initialized
INFO - 2018-04-01 18:44:06 --> Language Class Initialized
INFO - 2018-04-01 18:44:06 --> Loader Class Initialized
INFO - 2018-04-01 18:44:06 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:06 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:06 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:06 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
INFO - 2018-04-01 18:44:06 --> Controller Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
INFO - 2018-04-01 18:44:06 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:44:06 --> Final output sent to browser
DEBUG - 2018-04-01 18:44:06 --> Total execution time: 0.0590
INFO - 2018-04-01 18:44:07 --> Config Class Initialized
INFO - 2018-04-01 18:44:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:07 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:07 --> URI Class Initialized
INFO - 2018-04-01 18:44:07 --> Router Class Initialized
INFO - 2018-04-01 18:44:07 --> Output Class Initialized
INFO - 2018-04-01 18:44:07 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:07 --> Input Class Initialized
INFO - 2018-04-01 18:44:07 --> Language Class Initialized
INFO - 2018-04-01 18:44:07 --> Loader Class Initialized
INFO - 2018-04-01 18:44:07 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:07 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:07 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:07 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
INFO - 2018-04-01 18:44:07 --> Controller Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
INFO - 2018-04-01 18:44:07 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:09 --> Config Class Initialized
INFO - 2018-04-01 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:09 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:09 --> URI Class Initialized
INFO - 2018-04-01 18:44:09 --> Router Class Initialized
INFO - 2018-04-01 18:44:09 --> Output Class Initialized
INFO - 2018-04-01 18:44:09 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:09 --> Input Class Initialized
INFO - 2018-04-01 18:44:09 --> Language Class Initialized
INFO - 2018-04-01 18:44:09 --> Loader Class Initialized
INFO - 2018-04-01 18:44:09 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:09 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:09 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Controller Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:44:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:44:09 --> Final output sent to browser
DEBUG - 2018-04-01 18:44:09 --> Total execution time: 0.0619
INFO - 2018-04-01 18:44:09 --> Config Class Initialized
INFO - 2018-04-01 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:44:09 --> Utf8 Class Initialized
INFO - 2018-04-01 18:44:09 --> URI Class Initialized
INFO - 2018-04-01 18:44:09 --> Router Class Initialized
INFO - 2018-04-01 18:44:09 --> Output Class Initialized
INFO - 2018-04-01 18:44:09 --> Security Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:44:09 --> Input Class Initialized
INFO - 2018-04-01 18:44:09 --> Language Class Initialized
INFO - 2018-04-01 18:44:09 --> Loader Class Initialized
INFO - 2018-04-01 18:44:09 --> Helper loaded: url_helper
INFO - 2018-04-01 18:44:09 --> Helper loaded: form_helper
INFO - 2018-04-01 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:44:09 --> Form Validation Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Controller Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
INFO - 2018-04-01 18:44:09 --> Model Class Initialized
DEBUG - 2018-04-01 18:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:31 --> Config Class Initialized
INFO - 2018-04-01 18:53:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:31 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:31 --> URI Class Initialized
INFO - 2018-04-01 18:53:31 --> Router Class Initialized
INFO - 2018-04-01 18:53:31 --> Output Class Initialized
INFO - 2018-04-01 18:53:31 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:31 --> Input Class Initialized
INFO - 2018-04-01 18:53:31 --> Language Class Initialized
INFO - 2018-04-01 18:53:31 --> Loader Class Initialized
INFO - 2018-04-01 18:53:31 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:31 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:31 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:31 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:31 --> Model Class Initialized
INFO - 2018-04-01 18:53:31 --> Controller Class Initialized
INFO - 2018-04-01 18:53:31 --> Model Class Initialized
INFO - 2018-04-01 18:53:31 --> Model Class Initialized
INFO - 2018-04-01 18:53:31 --> Model Class Initialized
INFO - 2018-04-01 18:53:31 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:53:31 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:31 --> Total execution time: 0.0596
INFO - 2018-04-01 18:53:35 --> Config Class Initialized
INFO - 2018-04-01 18:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:35 --> URI Class Initialized
INFO - 2018-04-01 18:53:35 --> Router Class Initialized
INFO - 2018-04-01 18:53:35 --> Output Class Initialized
INFO - 2018-04-01 18:53:35 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:35 --> Input Class Initialized
INFO - 2018-04-01 18:53:35 --> Language Class Initialized
INFO - 2018-04-01 18:53:35 --> Loader Class Initialized
INFO - 2018-04-01 18:53:35 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:35 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:35 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Controller Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:53:35 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:35 --> Total execution time: 0.0731
INFO - 2018-04-01 18:53:35 --> Config Class Initialized
INFO - 2018-04-01 18:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:35 --> URI Class Initialized
INFO - 2018-04-01 18:53:35 --> Router Class Initialized
INFO - 2018-04-01 18:53:35 --> Output Class Initialized
INFO - 2018-04-01 18:53:35 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:35 --> Input Class Initialized
INFO - 2018-04-01 18:53:35 --> Language Class Initialized
INFO - 2018-04-01 18:53:35 --> Loader Class Initialized
INFO - 2018-04-01 18:53:35 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:35 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:35 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Controller Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
INFO - 2018-04-01 18:53:35 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:39 --> Config Class Initialized
INFO - 2018-04-01 18:53:39 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:39 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:39 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:39 --> URI Class Initialized
INFO - 2018-04-01 18:53:39 --> Router Class Initialized
INFO - 2018-04-01 18:53:39 --> Output Class Initialized
INFO - 2018-04-01 18:53:39 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:39 --> Input Class Initialized
INFO - 2018-04-01 18:53:39 --> Language Class Initialized
INFO - 2018-04-01 18:53:39 --> Loader Class Initialized
INFO - 2018-04-01 18:53:39 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:39 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:39 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:39 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:39 --> Model Class Initialized
INFO - 2018-04-01 18:53:39 --> Controller Class Initialized
INFO - 2018-04-01 18:53:39 --> Model Class Initialized
INFO - 2018-04-01 18:53:39 --> Model Class Initialized
INFO - 2018-04-01 18:53:39 --> Model Class Initialized
INFO - 2018-04-01 18:53:39 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:53:39 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:39 --> Total execution time: 0.0675
INFO - 2018-04-01 18:53:41 --> Config Class Initialized
INFO - 2018-04-01 18:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:41 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:41 --> URI Class Initialized
INFO - 2018-04-01 18:53:41 --> Router Class Initialized
INFO - 2018-04-01 18:53:41 --> Output Class Initialized
INFO - 2018-04-01 18:53:41 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:41 --> Input Class Initialized
INFO - 2018-04-01 18:53:41 --> Language Class Initialized
INFO - 2018-04-01 18:53:41 --> Loader Class Initialized
INFO - 2018-04-01 18:53:41 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:41 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:41 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:41 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:41 --> Model Class Initialized
INFO - 2018-04-01 18:53:41 --> Controller Class Initialized
INFO - 2018-04-01 18:53:41 --> Model Class Initialized
INFO - 2018-04-01 18:53:41 --> Model Class Initialized
INFO - 2018-04-01 18:53:41 --> Model Class Initialized
INFO - 2018-04-01 18:53:41 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:53:41 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:41 --> Total execution time: 0.0589
INFO - 2018-04-01 18:53:42 --> Config Class Initialized
INFO - 2018-04-01 18:53:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:42 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:42 --> URI Class Initialized
INFO - 2018-04-01 18:53:42 --> Router Class Initialized
INFO - 2018-04-01 18:53:42 --> Output Class Initialized
INFO - 2018-04-01 18:53:42 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:42 --> Input Class Initialized
INFO - 2018-04-01 18:53:42 --> Language Class Initialized
INFO - 2018-04-01 18:53:42 --> Loader Class Initialized
INFO - 2018-04-01 18:53:42 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:42 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:42 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
INFO - 2018-04-01 18:53:42 --> Controller Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
INFO - 2018-04-01 18:53:42 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:43 --> Config Class Initialized
INFO - 2018-04-01 18:53:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:43 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:43 --> URI Class Initialized
INFO - 2018-04-01 18:53:43 --> Router Class Initialized
INFO - 2018-04-01 18:53:43 --> Output Class Initialized
INFO - 2018-04-01 18:53:43 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:43 --> Input Class Initialized
INFO - 2018-04-01 18:53:43 --> Language Class Initialized
INFO - 2018-04-01 18:53:43 --> Loader Class Initialized
INFO - 2018-04-01 18:53:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:43 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:43 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:43 --> Model Class Initialized
INFO - 2018-04-01 18:53:43 --> Controller Class Initialized
INFO - 2018-04-01 18:53:43 --> Model Class Initialized
INFO - 2018-04-01 18:53:43 --> Model Class Initialized
INFO - 2018-04-01 18:53:43 --> Model Class Initialized
INFO - 2018-04-01 18:53:43 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 18:53:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 18:53:43 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:43 --> Total execution time: 0.0724
INFO - 2018-04-01 18:53:44 --> Config Class Initialized
INFO - 2018-04-01 18:53:44 --> Hooks Class Initialized
DEBUG - 2018-04-01 18:53:44 --> UTF-8 Support Enabled
INFO - 2018-04-01 18:53:44 --> Utf8 Class Initialized
INFO - 2018-04-01 18:53:44 --> URI Class Initialized
INFO - 2018-04-01 18:53:44 --> Router Class Initialized
INFO - 2018-04-01 18:53:44 --> Output Class Initialized
INFO - 2018-04-01 18:53:44 --> Security Class Initialized
DEBUG - 2018-04-01 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 18:53:44 --> Input Class Initialized
INFO - 2018-04-01 18:53:44 --> Language Class Initialized
INFO - 2018-04-01 18:53:44 --> Loader Class Initialized
INFO - 2018-04-01 18:53:44 --> Helper loaded: url_helper
INFO - 2018-04-01 18:53:44 --> Helper loaded: form_helper
INFO - 2018-04-01 18:53:44 --> Database Driver Class Initialized
DEBUG - 2018-04-01 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 18:53:44 --> Form Validation Class Initialized
INFO - 2018-04-01 18:53:44 --> Model Class Initialized
INFO - 2018-04-01 18:53:44 --> Controller Class Initialized
INFO - 2018-04-01 18:53:44 --> Model Class Initialized
INFO - 2018-04-01 18:53:44 --> Model Class Initialized
INFO - 2018-04-01 18:53:44 --> Model Class Initialized
INFO - 2018-04-01 18:53:44 --> Model Class Initialized
DEBUG - 2018-04-01 18:53:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:01:25 --> Config Class Initialized
INFO - 2018-04-01 19:01:25 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:01:25 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:01:25 --> Utf8 Class Initialized
INFO - 2018-04-01 19:01:25 --> URI Class Initialized
INFO - 2018-04-01 19:01:25 --> Router Class Initialized
INFO - 2018-04-01 19:01:25 --> Output Class Initialized
INFO - 2018-04-01 19:01:25 --> Security Class Initialized
DEBUG - 2018-04-01 19:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:01:25 --> Input Class Initialized
INFO - 2018-04-01 19:01:25 --> Language Class Initialized
INFO - 2018-04-01 19:01:25 --> Loader Class Initialized
INFO - 2018-04-01 19:01:25 --> Helper loaded: url_helper
INFO - 2018-04-01 19:01:25 --> Helper loaded: form_helper
INFO - 2018-04-01 19:01:25 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:01:25 --> Form Validation Class Initialized
INFO - 2018-04-01 19:01:25 --> Model Class Initialized
INFO - 2018-04-01 19:01:25 --> Controller Class Initialized
INFO - 2018-04-01 19:01:25 --> Model Class Initialized
INFO - 2018-04-01 19:01:25 --> Model Class Initialized
INFO - 2018-04-01 19:01:25 --> Model Class Initialized
INFO - 2018-04-01 19:01:25 --> Model Class Initialized
DEBUG - 2018-04-01 19:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:01:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:01:25 --> Final output sent to browser
DEBUG - 2018-04-01 19:01:25 --> Total execution time: 0.0621
INFO - 2018-04-01 19:01:26 --> Config Class Initialized
INFO - 2018-04-01 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:01:26 --> Utf8 Class Initialized
INFO - 2018-04-01 19:01:26 --> URI Class Initialized
INFO - 2018-04-01 19:01:26 --> Router Class Initialized
INFO - 2018-04-01 19:01:26 --> Output Class Initialized
INFO - 2018-04-01 19:01:26 --> Security Class Initialized
DEBUG - 2018-04-01 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:01:26 --> Input Class Initialized
INFO - 2018-04-01 19:01:26 --> Language Class Initialized
INFO - 2018-04-01 19:01:26 --> Loader Class Initialized
INFO - 2018-04-01 19:01:26 --> Helper loaded: url_helper
INFO - 2018-04-01 19:01:26 --> Helper loaded: form_helper
INFO - 2018-04-01 19:01:26 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:01:26 --> Form Validation Class Initialized
INFO - 2018-04-01 19:01:26 --> Model Class Initialized
INFO - 2018-04-01 19:01:26 --> Controller Class Initialized
INFO - 2018-04-01 19:01:26 --> Model Class Initialized
INFO - 2018-04-01 19:01:26 --> Model Class Initialized
INFO - 2018-04-01 19:01:26 --> Model Class Initialized
INFO - 2018-04-01 19:01:26 --> Model Class Initialized
DEBUG - 2018-04-01 19:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:21:26 --> Config Class Initialized
INFO - 2018-04-01 19:21:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:26 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:26 --> URI Class Initialized
INFO - 2018-04-01 19:21:26 --> Router Class Initialized
INFO - 2018-04-01 19:21:26 --> Output Class Initialized
INFO - 2018-04-01 19:21:26 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:26 --> Input Class Initialized
INFO - 2018-04-01 19:21:26 --> Language Class Initialized
INFO - 2018-04-01 19:21:26 --> Loader Class Initialized
INFO - 2018-04-01 19:21:26 --> Helper loaded: url_helper
INFO - 2018-04-01 19:21:26 --> Helper loaded: form_helper
INFO - 2018-04-01 19:21:26 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:21:26 --> Form Validation Class Initialized
INFO - 2018-04-01 19:21:26 --> Model Class Initialized
INFO - 2018-04-01 19:21:26 --> Controller Class Initialized
INFO - 2018-04-01 19:21:26 --> Model Class Initialized
INFO - 2018-04-01 19:21:26 --> Model Class Initialized
INFO - 2018-04-01 19:21:26 --> Model Class Initialized
INFO - 2018-04-01 19:21:26 --> Model Class Initialized
DEBUG - 2018-04-01 19:21:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:21:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:21:26 --> Final output sent to browser
DEBUG - 2018-04-01 19:21:26 --> Total execution time: 0.0615
INFO - 2018-04-01 19:21:27 --> Config Class Initialized
INFO - 2018-04-01 19:21:27 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:27 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:27 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:27 --> URI Class Initialized
INFO - 2018-04-01 19:21:27 --> Router Class Initialized
INFO - 2018-04-01 19:21:27 --> Output Class Initialized
INFO - 2018-04-01 19:21:27 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:27 --> Input Class Initialized
INFO - 2018-04-01 19:21:27 --> Language Class Initialized
INFO - 2018-04-01 19:21:27 --> Loader Class Initialized
INFO - 2018-04-01 19:21:27 --> Helper loaded: url_helper
INFO - 2018-04-01 19:21:27 --> Helper loaded: form_helper
INFO - 2018-04-01 19:21:27 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:21:27 --> Form Validation Class Initialized
INFO - 2018-04-01 19:21:27 --> Model Class Initialized
INFO - 2018-04-01 19:21:27 --> Controller Class Initialized
INFO - 2018-04-01 19:21:27 --> Model Class Initialized
INFO - 2018-04-01 19:21:27 --> Model Class Initialized
INFO - 2018-04-01 19:21:27 --> Model Class Initialized
INFO - 2018-04-01 19:21:27 --> Model Class Initialized
DEBUG - 2018-04-01 19:21:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:29 --> Config Class Initialized
INFO - 2018-04-01 19:21:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:29 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:29 --> URI Class Initialized
INFO - 2018-04-01 19:21:29 --> Router Class Initialized
INFO - 2018-04-01 19:21:29 --> Output Class Initialized
INFO - 2018-04-01 19:21:29 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:29 --> Input Class Initialized
INFO - 2018-04-01 19:21:29 --> Language Class Initialized
ERROR - 2018-04-01 19:21:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:30 --> Config Class Initialized
INFO - 2018-04-01 19:21:30 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:30 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:30 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:30 --> URI Class Initialized
INFO - 2018-04-01 19:21:30 --> Router Class Initialized
INFO - 2018-04-01 19:21:30 --> Output Class Initialized
INFO - 2018-04-01 19:21:30 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:30 --> Input Class Initialized
INFO - 2018-04-01 19:21:30 --> Language Class Initialized
INFO - 2018-04-01 19:21:30 --> Loader Class Initialized
INFO - 2018-04-01 19:21:30 --> Helper loaded: url_helper
INFO - 2018-04-01 19:21:30 --> Helper loaded: form_helper
INFO - 2018-04-01 19:21:30 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:21:30 --> Form Validation Class Initialized
INFO - 2018-04-01 19:21:30 --> Model Class Initialized
INFO - 2018-04-01 19:21:30 --> Controller Class Initialized
INFO - 2018-04-01 19:21:30 --> Model Class Initialized
INFO - 2018-04-01 19:21:30 --> Model Class Initialized
INFO - 2018-04-01 19:21:30 --> Model Class Initialized
INFO - 2018-04-01 19:21:30 --> Model Class Initialized
DEBUG - 2018-04-01 19:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:21:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:21:30 --> Final output sent to browser
DEBUG - 2018-04-01 19:21:30 --> Total execution time: 0.0618
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
ERROR - 2018-04-01 19:21:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:21:31 --> Config Class Initialized
INFO - 2018-04-01 19:21:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:21:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:21:31 --> Utf8 Class Initialized
INFO - 2018-04-01 19:21:31 --> URI Class Initialized
INFO - 2018-04-01 19:21:31 --> Router Class Initialized
INFO - 2018-04-01 19:21:31 --> Output Class Initialized
INFO - 2018-04-01 19:21:31 --> Security Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:21:31 --> Input Class Initialized
INFO - 2018-04-01 19:21:31 --> Language Class Initialized
INFO - 2018-04-01 19:21:31 --> Loader Class Initialized
INFO - 2018-04-01 19:21:31 --> Helper loaded: url_helper
INFO - 2018-04-01 19:21:31 --> Helper loaded: form_helper
INFO - 2018-04-01 19:21:31 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:21:31 --> Form Validation Class Initialized
INFO - 2018-04-01 19:21:31 --> Model Class Initialized
INFO - 2018-04-01 19:21:31 --> Controller Class Initialized
INFO - 2018-04-01 19:21:31 --> Model Class Initialized
INFO - 2018-04-01 19:21:31 --> Model Class Initialized
INFO - 2018-04-01 19:21:31 --> Model Class Initialized
INFO - 2018-04-01 19:21:31 --> Model Class Initialized
DEBUG - 2018-04-01 19:21:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Loader Class Initialized
INFO - 2018-04-01 19:25:38 --> Helper loaded: url_helper
INFO - 2018-04-01 19:25:38 --> Helper loaded: form_helper
INFO - 2018-04-01 19:25:38 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:25:38 --> Form Validation Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Controller Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:25:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:25:38 --> Final output sent to browser
DEBUG - 2018-04-01 19:25:38 --> Total execution time: 0.0708
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 19:25:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:25:38 --> Config Class Initialized
INFO - 2018-04-01 19:25:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:25:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:25:38 --> Utf8 Class Initialized
INFO - 2018-04-01 19:25:38 --> URI Class Initialized
INFO - 2018-04-01 19:25:38 --> Router Class Initialized
INFO - 2018-04-01 19:25:38 --> Output Class Initialized
INFO - 2018-04-01 19:25:38 --> Security Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:25:38 --> Input Class Initialized
INFO - 2018-04-01 19:25:38 --> Language Class Initialized
INFO - 2018-04-01 19:25:38 --> Loader Class Initialized
INFO - 2018-04-01 19:25:38 --> Helper loaded: url_helper
INFO - 2018-04-01 19:25:38 --> Helper loaded: form_helper
INFO - 2018-04-01 19:25:38 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:25:38 --> Form Validation Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Controller Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
INFO - 2018-04-01 19:25:38 --> Model Class Initialized
DEBUG - 2018-04-01 19:25:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:51:59 --> Config Class Initialized
INFO - 2018-04-01 19:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:51:59 --> Utf8 Class Initialized
INFO - 2018-04-01 19:51:59 --> URI Class Initialized
INFO - 2018-04-01 19:51:59 --> Router Class Initialized
INFO - 2018-04-01 19:51:59 --> Output Class Initialized
INFO - 2018-04-01 19:51:59 --> Security Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:51:59 --> Input Class Initialized
INFO - 2018-04-01 19:51:59 --> Language Class Initialized
INFO - 2018-04-01 19:51:59 --> Loader Class Initialized
INFO - 2018-04-01 19:51:59 --> Helper loaded: url_helper
INFO - 2018-04-01 19:51:59 --> Helper loaded: form_helper
INFO - 2018-04-01 19:51:59 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:51:59 --> Form Validation Class Initialized
INFO - 2018-04-01 19:51:59 --> Model Class Initialized
INFO - 2018-04-01 19:51:59 --> Controller Class Initialized
INFO - 2018-04-01 19:51:59 --> Model Class Initialized
INFO - 2018-04-01 19:51:59 --> Model Class Initialized
INFO - 2018-04-01 19:51:59 --> Model Class Initialized
INFO - 2018-04-01 19:51:59 --> Model Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:51:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:51:59 --> Final output sent to browser
DEBUG - 2018-04-01 19:51:59 --> Total execution time: 0.0922
INFO - 2018-04-01 19:51:59 --> Config Class Initialized
INFO - 2018-04-01 19:51:59 --> Hooks Class Initialized
INFO - 2018-04-01 19:51:59 --> Config Class Initialized
INFO - 2018-04-01 19:51:59 --> Config Class Initialized
INFO - 2018-04-01 19:51:59 --> Hooks Class Initialized
INFO - 2018-04-01 19:51:59 --> Hooks Class Initialized
INFO - 2018-04-01 19:51:59 --> Config Class Initialized
INFO - 2018-04-01 19:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:51:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:51:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:51:59 --> URI Class Initialized
INFO - 2018-04-01 19:51:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:51:59 --> URI Class Initialized
INFO - 2018-04-01 19:51:59 --> Utf8 Class Initialized
INFO - 2018-04-01 19:51:59 --> URI Class Initialized
INFO - 2018-04-01 19:51:59 --> Router Class Initialized
INFO - 2018-04-01 19:51:59 --> URI Class Initialized
INFO - 2018-04-01 19:51:59 --> Router Class Initialized
INFO - 2018-04-01 19:51:59 --> Router Class Initialized
INFO - 2018-04-01 19:51:59 --> Output Class Initialized
INFO - 2018-04-01 19:51:59 --> Router Class Initialized
INFO - 2018-04-01 19:51:59 --> Output Class Initialized
INFO - 2018-04-01 19:51:59 --> Output Class Initialized
INFO - 2018-04-01 19:51:59 --> Security Class Initialized
INFO - 2018-04-01 19:51:59 --> Security Class Initialized
INFO - 2018-04-01 19:51:59 --> Security Class Initialized
INFO - 2018-04-01 19:51:59 --> Output Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:51:59 --> Input Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:51:59 --> Language Class Initialized
INFO - 2018-04-01 19:51:59 --> Security Class Initialized
INFO - 2018-04-01 19:51:59 --> Input Class Initialized
INFO - 2018-04-01 19:51:59 --> Input Class Initialized
INFO - 2018-04-01 19:51:59 --> Language Class Initialized
INFO - 2018-04-01 19:51:59 --> Language Class Initialized
DEBUG - 2018-04-01 19:51:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 19:51:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:51:59 --> Input Class Initialized
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:52:00 --> Language Class Initialized
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:52:00 --> Config Class Initialized
INFO - 2018-04-01 19:52:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:52:00 --> Config Class Initialized
INFO - 2018-04-01 19:52:00 --> Config Class Initialized
INFO - 2018-04-01 19:52:00 --> Hooks Class Initialized
INFO - 2018-04-01 19:52:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:52:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:52:00 --> URI Class Initialized
DEBUG - 2018-04-01 19:52:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:52:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:52:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:52:00 --> Router Class Initialized
INFO - 2018-04-01 19:52:00 --> URI Class Initialized
INFO - 2018-04-01 19:52:00 --> URI Class Initialized
INFO - 2018-04-01 19:52:00 --> Output Class Initialized
INFO - 2018-04-01 19:52:00 --> Router Class Initialized
INFO - 2018-04-01 19:52:00 --> Router Class Initialized
INFO - 2018-04-01 19:52:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:52:00 --> Output Class Initialized
INFO - 2018-04-01 19:52:00 --> Output Class Initialized
INFO - 2018-04-01 19:52:00 --> Input Class Initialized
INFO - 2018-04-01 19:52:00 --> Language Class Initialized
INFO - 2018-04-01 19:52:00 --> Security Class Initialized
INFO - 2018-04-01 19:52:00 --> Security Class Initialized
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 19:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:52:00 --> Input Class Initialized
INFO - 2018-04-01 19:52:00 --> Input Class Initialized
INFO - 2018-04-01 19:52:00 --> Language Class Initialized
INFO - 2018-04-01 19:52:00 --> Language Class Initialized
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 19:52:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:52:00 --> Config Class Initialized
INFO - 2018-04-01 19:52:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:52:00 --> Utf8 Class Initialized
INFO - 2018-04-01 19:52:00 --> URI Class Initialized
INFO - 2018-04-01 19:52:00 --> Router Class Initialized
INFO - 2018-04-01 19:52:00 --> Output Class Initialized
INFO - 2018-04-01 19:52:00 --> Security Class Initialized
DEBUG - 2018-04-01 19:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:52:00 --> Input Class Initialized
INFO - 2018-04-01 19:52:00 --> Language Class Initialized
INFO - 2018-04-01 19:52:00 --> Loader Class Initialized
INFO - 2018-04-01 19:52:00 --> Helper loaded: url_helper
INFO - 2018-04-01 19:52:00 --> Helper loaded: form_helper
INFO - 2018-04-01 19:52:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:52:00 --> Form Validation Class Initialized
INFO - 2018-04-01 19:52:00 --> Model Class Initialized
INFO - 2018-04-01 19:52:00 --> Controller Class Initialized
INFO - 2018-04-01 19:52:00 --> Model Class Initialized
INFO - 2018-04-01 19:52:00 --> Model Class Initialized
INFO - 2018-04-01 19:52:00 --> Model Class Initialized
INFO - 2018-04-01 19:52:00 --> Model Class Initialized
DEBUG - 2018-04-01 19:52:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 19:52:00 --> Query error: Unknown column 'proyecto.valor_compra' in 'field list' - Invalid query: SELECT `proyecto`.`valor_compra`, `proveedor`.`proveedor_id`, `proveedor`.`nombre_proveedor`, `proyecto_gasto`.`fecha_gasto`, `proyecto_gasto_monto`.`proyecto_gasto_monto`, `proyecto_gasto_monto`.`moneda_id`
FROM `proyecto_gasto`
JOIN `proyecto` ON `proyecto`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto`.`proyecto_gasto_tipo_id` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-04-01 19:52:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Loader Class Initialized
INFO - 2018-04-01 19:53:19 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:19 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:19 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:19 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Controller Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:53:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:53:19 --> Final output sent to browser
DEBUG - 2018-04-01 19:53:19 --> Total execution time: 0.0726
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
ERROR - 2018-04-01 19:53:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:53:19 --> Config Class Initialized
INFO - 2018-04-01 19:53:19 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:19 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:19 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:19 --> URI Class Initialized
INFO - 2018-04-01 19:53:19 --> Router Class Initialized
INFO - 2018-04-01 19:53:19 --> Output Class Initialized
INFO - 2018-04-01 19:53:19 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:19 --> Input Class Initialized
INFO - 2018-04-01 19:53:19 --> Language Class Initialized
INFO - 2018-04-01 19:53:19 --> Loader Class Initialized
INFO - 2018-04-01 19:53:19 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:19 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:19 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:19 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Controller Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
INFO - 2018-04-01 19:53:19 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 19:53:19 --> Severity: Notice --> Undefined property: Reporte::$proyecto_tipo_cambio D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-04-01 19:53:19 --> Severity: Notice --> Undefined property: Reporte::$proyecto_tipo_cambio D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-04-01 19:53:19 --> Severity: Notice --> Undefined property: Reporte::$proyecto_tipo_cambio D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-04-01 19:53:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `proveedor`.`proveedor_id`, `proveedor`.`nombre_proveedor`, `proyecto_gasto`.`f' at line 1 - Invalid query: SELECT .`valor_compra`, `proveedor`.`proveedor_id`, `proveedor`.`nombre_proveedor`, `proyecto_gasto`.`fecha_gasto`, `proyecto_gasto_monto`.`proyecto_gasto_monto`, `proyecto_gasto_monto`.`moneda_id`
FROM `proyecto_gasto`
JOIN  ON .`proyecto_id` = `proyecto_gasto`.`proyecto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = 1
AND `proyecto_gasto`.`proyecto_gasto_tipo_id` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-04-01 19:53:19 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-01 19:53:34 --> Config Class Initialized
INFO - 2018-04-01 19:53:34 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:34 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:34 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:34 --> URI Class Initialized
INFO - 2018-04-01 19:53:34 --> Router Class Initialized
INFO - 2018-04-01 19:53:34 --> Output Class Initialized
INFO - 2018-04-01 19:53:34 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:34 --> Input Class Initialized
INFO - 2018-04-01 19:53:34 --> Language Class Initialized
INFO - 2018-04-01 19:53:34 --> Loader Class Initialized
INFO - 2018-04-01 19:53:34 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:34 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:34 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:34 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:34 --> Model Class Initialized
INFO - 2018-04-01 19:53:34 --> Controller Class Initialized
INFO - 2018-04-01 19:53:34 --> Model Class Initialized
INFO - 2018-04-01 19:53:34 --> Model Class Initialized
INFO - 2018-04-01 19:53:34 --> Model Class Initialized
INFO - 2018-04-01 19:53:34 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:53:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:53:34 --> Final output sent to browser
DEBUG - 2018-04-01 19:53:34 --> Total execution time: 0.1182
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
ERROR - 2018-04-01 19:53:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:53:35 --> Config Class Initialized
INFO - 2018-04-01 19:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:35 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:35 --> URI Class Initialized
INFO - 2018-04-01 19:53:35 --> Router Class Initialized
INFO - 2018-04-01 19:53:35 --> Output Class Initialized
INFO - 2018-04-01 19:53:35 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:35 --> Input Class Initialized
INFO - 2018-04-01 19:53:35 --> Language Class Initialized
INFO - 2018-04-01 19:53:35 --> Loader Class Initialized
INFO - 2018-04-01 19:53:35 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:35 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:35 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:35 --> Model Class Initialized
INFO - 2018-04-01 19:53:35 --> Controller Class Initialized
INFO - 2018-04-01 19:53:35 --> Model Class Initialized
INFO - 2018-04-01 19:53:35 --> Model Class Initialized
INFO - 2018-04-01 19:53:35 --> Model Class Initialized
INFO - 2018-04-01 19:53:35 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:53:50 --> Config Class Initialized
INFO - 2018-04-01 19:53:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:50 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:50 --> URI Class Initialized
INFO - 2018-04-01 19:53:50 --> Router Class Initialized
INFO - 2018-04-01 19:53:50 --> Output Class Initialized
INFO - 2018-04-01 19:53:50 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:50 --> Input Class Initialized
INFO - 2018-04-01 19:53:50 --> Language Class Initialized
INFO - 2018-04-01 19:53:50 --> Loader Class Initialized
INFO - 2018-04-01 19:53:50 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:50 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:50 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
INFO - 2018-04-01 19:53:50 --> Controller Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
INFO - 2018-04-01 19:53:50 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:53:59 --> Config Class Initialized
INFO - 2018-04-01 19:53:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:53:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:53:59 --> Utf8 Class Initialized
INFO - 2018-04-01 19:53:59 --> URI Class Initialized
INFO - 2018-04-01 19:53:59 --> Router Class Initialized
INFO - 2018-04-01 19:53:59 --> Output Class Initialized
INFO - 2018-04-01 19:53:59 --> Security Class Initialized
DEBUG - 2018-04-01 19:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:53:59 --> Input Class Initialized
INFO - 2018-04-01 19:53:59 --> Language Class Initialized
INFO - 2018-04-01 19:53:59 --> Loader Class Initialized
INFO - 2018-04-01 19:53:59 --> Helper loaded: url_helper
INFO - 2018-04-01 19:53:59 --> Helper loaded: form_helper
INFO - 2018-04-01 19:53:59 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:53:59 --> Form Validation Class Initialized
INFO - 2018-04-01 19:53:59 --> Model Class Initialized
INFO - 2018-04-01 19:53:59 --> Controller Class Initialized
INFO - 2018-04-01 19:53:59 --> Model Class Initialized
INFO - 2018-04-01 19:53:59 --> Model Class Initialized
INFO - 2018-04-01 19:53:59 --> Model Class Initialized
INFO - 2018-04-01 19:53:59 --> Model Class Initialized
DEBUG - 2018-04-01 19:53:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
INFO - 2018-04-01 19:54:42 --> Loader Class Initialized
INFO - 2018-04-01 19:54:42 --> Helper loaded: url_helper
INFO - 2018-04-01 19:54:42 --> Helper loaded: form_helper
INFO - 2018-04-01 19:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:54:42 --> Form Validation Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Controller Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:54:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 19:54:42 --> Final output sent to browser
DEBUG - 2018-04-01 19:54:42 --> Total execution time: 0.0901
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 19:54:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:54:42 --> Config Class Initialized
INFO - 2018-04-01 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:42 --> URI Class Initialized
INFO - 2018-04-01 19:54:42 --> Router Class Initialized
INFO - 2018-04-01 19:54:42 --> Output Class Initialized
INFO - 2018-04-01 19:54:42 --> Security Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:42 --> Input Class Initialized
INFO - 2018-04-01 19:54:42 --> Language Class Initialized
INFO - 2018-04-01 19:54:42 --> Loader Class Initialized
INFO - 2018-04-01 19:54:42 --> Helper loaded: url_helper
INFO - 2018-04-01 19:54:42 --> Helper loaded: form_helper
INFO - 2018-04-01 19:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:54:42 --> Form Validation Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Controller Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
INFO - 2018-04-01 19:54:42 --> Model Class Initialized
DEBUG - 2018-04-01 19:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:54:46 --> Config Class Initialized
INFO - 2018-04-01 19:54:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:46 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:46 --> URI Class Initialized
INFO - 2018-04-01 19:54:46 --> Router Class Initialized
INFO - 2018-04-01 19:54:46 --> Output Class Initialized
INFO - 2018-04-01 19:54:46 --> Security Class Initialized
DEBUG - 2018-04-01 19:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:46 --> Input Class Initialized
INFO - 2018-04-01 19:54:46 --> Language Class Initialized
INFO - 2018-04-01 19:54:46 --> Loader Class Initialized
INFO - 2018-04-01 19:54:46 --> Helper loaded: url_helper
INFO - 2018-04-01 19:54:46 --> Helper loaded: form_helper
INFO - 2018-04-01 19:54:46 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:54:46 --> Form Validation Class Initialized
INFO - 2018-04-01 19:54:46 --> Model Class Initialized
INFO - 2018-04-01 19:54:46 --> Controller Class Initialized
INFO - 2018-04-01 19:54:46 --> Model Class Initialized
INFO - 2018-04-01 19:54:46 --> Model Class Initialized
INFO - 2018-04-01 19:54:46 --> Model Class Initialized
INFO - 2018-04-01 19:54:46 --> Model Class Initialized
DEBUG - 2018-04-01 19:54:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:54:51 --> Config Class Initialized
INFO - 2018-04-01 19:54:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:54:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:54:51 --> Utf8 Class Initialized
INFO - 2018-04-01 19:54:51 --> URI Class Initialized
INFO - 2018-04-01 19:54:51 --> Router Class Initialized
INFO - 2018-04-01 19:54:51 --> Output Class Initialized
INFO - 2018-04-01 19:54:51 --> Security Class Initialized
DEBUG - 2018-04-01 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:54:51 --> Input Class Initialized
INFO - 2018-04-01 19:54:51 --> Language Class Initialized
INFO - 2018-04-01 19:54:51 --> Loader Class Initialized
INFO - 2018-04-01 19:54:51 --> Helper loaded: url_helper
INFO - 2018-04-01 19:54:51 --> Helper loaded: form_helper
INFO - 2018-04-01 19:54:51 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:54:51 --> Form Validation Class Initialized
INFO - 2018-04-01 19:54:51 --> Model Class Initialized
INFO - 2018-04-01 19:54:51 --> Controller Class Initialized
INFO - 2018-04-01 19:54:51 --> Model Class Initialized
INFO - 2018-04-01 19:54:51 --> Model Class Initialized
INFO - 2018-04-01 19:54:51 --> Model Class Initialized
INFO - 2018-04-01 19:54:51 --> Model Class Initialized
DEBUG - 2018-04-01 19:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:55:02 --> Config Class Initialized
INFO - 2018-04-01 19:55:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:02 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:02 --> URI Class Initialized
INFO - 2018-04-01 19:55:02 --> Router Class Initialized
INFO - 2018-04-01 19:55:02 --> Output Class Initialized
INFO - 2018-04-01 19:55:02 --> Security Class Initialized
DEBUG - 2018-04-01 19:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:02 --> Input Class Initialized
INFO - 2018-04-01 19:55:02 --> Language Class Initialized
INFO - 2018-04-01 19:55:02 --> Loader Class Initialized
INFO - 2018-04-01 19:55:02 --> Helper loaded: url_helper
INFO - 2018-04-01 19:55:02 --> Helper loaded: form_helper
INFO - 2018-04-01 19:55:02 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:55:02 --> Form Validation Class Initialized
INFO - 2018-04-01 19:55:02 --> Model Class Initialized
INFO - 2018-04-01 19:55:02 --> Controller Class Initialized
INFO - 2018-04-01 19:55:02 --> Model Class Initialized
INFO - 2018-04-01 19:55:02 --> Model Class Initialized
INFO - 2018-04-01 19:55:02 --> Model Class Initialized
INFO - 2018-04-01 19:55:02 --> Model Class Initialized
DEBUG - 2018-04-01 19:55:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:55:07 --> Config Class Initialized
INFO - 2018-04-01 19:55:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:07 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:07 --> URI Class Initialized
INFO - 2018-04-01 19:55:07 --> Router Class Initialized
INFO - 2018-04-01 19:55:07 --> Output Class Initialized
INFO - 2018-04-01 19:55:07 --> Security Class Initialized
DEBUG - 2018-04-01 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:07 --> Input Class Initialized
INFO - 2018-04-01 19:55:07 --> Language Class Initialized
INFO - 2018-04-01 19:55:07 --> Loader Class Initialized
INFO - 2018-04-01 19:55:07 --> Helper loaded: url_helper
INFO - 2018-04-01 19:55:07 --> Helper loaded: form_helper
INFO - 2018-04-01 19:55:07 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:55:07 --> Form Validation Class Initialized
INFO - 2018-04-01 19:55:07 --> Model Class Initialized
INFO - 2018-04-01 19:55:07 --> Controller Class Initialized
INFO - 2018-04-01 19:55:07 --> Model Class Initialized
INFO - 2018-04-01 19:55:07 --> Model Class Initialized
INFO - 2018-04-01 19:55:07 --> Model Class Initialized
INFO - 2018-04-01 19:55:07 --> Model Class Initialized
DEBUG - 2018-04-01 19:55:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:55:12 --> Config Class Initialized
INFO - 2018-04-01 19:55:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:12 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:12 --> URI Class Initialized
INFO - 2018-04-01 19:55:12 --> Router Class Initialized
INFO - 2018-04-01 19:55:12 --> Output Class Initialized
INFO - 2018-04-01 19:55:12 --> Security Class Initialized
DEBUG - 2018-04-01 19:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:12 --> Input Class Initialized
INFO - 2018-04-01 19:55:12 --> Language Class Initialized
INFO - 2018-04-01 19:55:12 --> Loader Class Initialized
INFO - 2018-04-01 19:55:12 --> Helper loaded: url_helper
INFO - 2018-04-01 19:55:12 --> Helper loaded: form_helper
INFO - 2018-04-01 19:55:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:55:12 --> Form Validation Class Initialized
INFO - 2018-04-01 19:55:12 --> Model Class Initialized
INFO - 2018-04-01 19:55:12 --> Controller Class Initialized
INFO - 2018-04-01 19:55:12 --> Model Class Initialized
INFO - 2018-04-01 19:55:12 --> Model Class Initialized
INFO - 2018-04-01 19:55:12 --> Model Class Initialized
INFO - 2018-04-01 19:55:12 --> Model Class Initialized
DEBUG - 2018-04-01 19:55:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> Config Class Initialized
INFO - 2018-04-01 19:55:15 --> Hooks Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
DEBUG - 2018-04-01 19:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
INFO - 2018-04-01 19:55:15 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:15 --> URI Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
INFO - 2018-04-01 19:55:15 --> Router Class Initialized
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Output Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
INFO - 2018-04-01 19:55:15 --> Security Class Initialized
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
DEBUG - 2018-04-01 19:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:15 --> Input Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
INFO - 2018-04-01 19:55:15 --> Language Class Initialized
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 19:55:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 19:55:21 --> Config Class Initialized
INFO - 2018-04-01 19:55:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 19:55:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 19:55:21 --> Utf8 Class Initialized
INFO - 2018-04-01 19:55:21 --> URI Class Initialized
INFO - 2018-04-01 19:55:21 --> Router Class Initialized
INFO - 2018-04-01 19:55:21 --> Output Class Initialized
INFO - 2018-04-01 19:55:21 --> Security Class Initialized
DEBUG - 2018-04-01 19:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 19:55:21 --> Input Class Initialized
INFO - 2018-04-01 19:55:21 --> Language Class Initialized
INFO - 2018-04-01 19:55:21 --> Loader Class Initialized
INFO - 2018-04-01 19:55:21 --> Helper loaded: url_helper
INFO - 2018-04-01 19:55:21 --> Helper loaded: form_helper
INFO - 2018-04-01 19:55:21 --> Database Driver Class Initialized
DEBUG - 2018-04-01 19:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 19:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 19:55:21 --> Form Validation Class Initialized
INFO - 2018-04-01 19:55:21 --> Model Class Initialized
INFO - 2018-04-01 19:55:21 --> Controller Class Initialized
INFO - 2018-04-01 19:55:21 --> Model Class Initialized
INFO - 2018-04-01 19:55:21 --> Model Class Initialized
INFO - 2018-04-01 19:55:21 --> Model Class Initialized
INFO - 2018-04-01 19:55:21 --> Model Class Initialized
DEBUG - 2018-04-01 19:55:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
INFO - 2018-04-01 23:33:41 --> Loader Class Initialized
INFO - 2018-04-01 23:33:41 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:41 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:41 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:41 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
INFO - 2018-04-01 23:33:41 --> Controller Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
INFO - 2018-04-01 23:33:41 --> Loader Class Initialized
INFO - 2018-04-01 23:33:41 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:41 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:41 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:41 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
INFO - 2018-04-01 23:33:41 --> Controller Class Initialized
INFO - 2018-04-01 23:33:41 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:33:41 --> Final output sent to browser
DEBUG - 2018-04-01 23:33:41 --> Total execution time: 0.0461
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Config Class Initialized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:41 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> URI Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Router Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Output Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
INFO - 2018-04-01 23:33:41 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Input Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
INFO - 2018-04-01 23:33:41 --> Language Class Initialized
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:33:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:42 --> Config Class Initialized
INFO - 2018-04-01 23:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:42 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:42 --> URI Class Initialized
INFO - 2018-04-01 23:33:42 --> Router Class Initialized
INFO - 2018-04-01 23:33:42 --> Output Class Initialized
INFO - 2018-04-01 23:33:42 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:42 --> Input Class Initialized
INFO - 2018-04-01 23:33:42 --> Language Class Initialized
INFO - 2018-04-01 23:33:42 --> Loader Class Initialized
INFO - 2018-04-01 23:33:42 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:42 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:42 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:42 --> Model Class Initialized
INFO - 2018-04-01 23:33:42 --> Controller Class Initialized
INFO - 2018-04-01 23:33:42 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-01 23:33:42 --> Config Class Initialized
INFO - 2018-04-01 23:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:42 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:42 --> URI Class Initialized
DEBUG - 2018-04-01 23:33:42 --> No URI present. Default controller set.
INFO - 2018-04-01 23:33:42 --> Router Class Initialized
INFO - 2018-04-01 23:33:42 --> Output Class Initialized
INFO - 2018-04-01 23:33:42 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:42 --> Input Class Initialized
INFO - 2018-04-01 23:33:42 --> Language Class Initialized
INFO - 2018-04-01 23:33:42 --> Loader Class Initialized
INFO - 2018-04-01 23:33:42 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:42 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:42 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:42 --> Model Class Initialized
INFO - 2018-04-01 23:33:42 --> Controller Class Initialized
INFO - 2018-04-01 23:33:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:33:42 --> Final output sent to browser
DEBUG - 2018-04-01 23:33:42 --> Total execution time: 0.0469
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:33:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:43 --> Config Class Initialized
INFO - 2018-04-01 23:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:43 --> URI Class Initialized
INFO - 2018-04-01 23:33:43 --> Router Class Initialized
INFO - 2018-04-01 23:33:43 --> Output Class Initialized
INFO - 2018-04-01 23:33:43 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:43 --> Input Class Initialized
INFO - 2018-04-01 23:33:43 --> Language Class Initialized
INFO - 2018-04-01 23:33:43 --> Loader Class Initialized
INFO - 2018-04-01 23:33:43 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:43 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:43 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
INFO - 2018-04-01 23:33:43 --> Controller Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
INFO - 2018-04-01 23:33:43 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:45 --> Config Class Initialized
INFO - 2018-04-01 23:33:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:45 --> URI Class Initialized
INFO - 2018-04-01 23:33:45 --> Router Class Initialized
INFO - 2018-04-01 23:33:45 --> Output Class Initialized
INFO - 2018-04-01 23:33:45 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:45 --> Input Class Initialized
INFO - 2018-04-01 23:33:45 --> Language Class Initialized
INFO - 2018-04-01 23:33:45 --> Loader Class Initialized
INFO - 2018-04-01 23:33:45 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:45 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:45 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:45 --> Model Class Initialized
INFO - 2018-04-01 23:33:45 --> Controller Class Initialized
INFO - 2018-04-01 23:33:45 --> Model Class Initialized
INFO - 2018-04-01 23:33:45 --> Model Class Initialized
INFO - 2018-04-01 23:33:45 --> Model Class Initialized
INFO - 2018-04-01 23:33:46 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:33:46 --> Final output sent to browser
DEBUG - 2018-04-01 23:33:46 --> Total execution time: 0.0600
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:46 --> Config Class Initialized
INFO - 2018-04-01 23:33:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:46 --> URI Class Initialized
INFO - 2018-04-01 23:33:46 --> Router Class Initialized
INFO - 2018-04-01 23:33:46 --> Output Class Initialized
INFO - 2018-04-01 23:33:46 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:46 --> Input Class Initialized
INFO - 2018-04-01 23:33:46 --> Language Class Initialized
ERROR - 2018-04-01 23:33:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
INFO - 2018-04-01 23:33:48 --> Loader Class Initialized
INFO - 2018-04-01 23:33:48 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:48 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:48 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Controller Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:33:48 --> Final output sent to browser
DEBUG - 2018-04-01 23:33:48 --> Total execution time: 0.0613
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
ERROR - 2018-04-01 23:33:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:48 --> Config Class Initialized
INFO - 2018-04-01 23:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:48 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:48 --> URI Class Initialized
INFO - 2018-04-01 23:33:48 --> Router Class Initialized
INFO - 2018-04-01 23:33:48 --> Output Class Initialized
INFO - 2018-04-01 23:33:48 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:48 --> Input Class Initialized
INFO - 2018-04-01 23:33:48 --> Language Class Initialized
INFO - 2018-04-01 23:33:48 --> Loader Class Initialized
INFO - 2018-04-01 23:33:48 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:48 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:48 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:48 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Controller Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
INFO - 2018-04-01 23:33:48 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
INFO - 2018-04-01 23:33:49 --> Loader Class Initialized
INFO - 2018-04-01 23:33:49 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:49 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:49 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:49 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:49 --> Model Class Initialized
INFO - 2018-04-01 23:33:49 --> Controller Class Initialized
INFO - 2018-04-01 23:33:49 --> Model Class Initialized
INFO - 2018-04-01 23:33:49 --> Model Class Initialized
INFO - 2018-04-01 23:33:49 --> Model Class Initialized
INFO - 2018-04-01 23:33:49 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:33:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:33:49 --> Final output sent to browser
DEBUG - 2018-04-01 23:33:49 --> Total execution time: 0.0539
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
INFO - 2018-04-01 23:33:49 --> Config Class Initialized
INFO - 2018-04-01 23:33:49 --> Hooks Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> URI Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
INFO - 2018-04-01 23:33:49 --> Router Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
INFO - 2018-04-01 23:33:49 --> Output Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:49 --> Security Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:49 --> Input Class Initialized
INFO - 2018-04-01 23:33:49 --> Language Class Initialized
ERROR - 2018-04-01 23:33:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:33:53 --> Config Class Initialized
INFO - 2018-04-01 23:33:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:33:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:33:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:33:53 --> URI Class Initialized
INFO - 2018-04-01 23:33:53 --> Router Class Initialized
INFO - 2018-04-01 23:33:53 --> Output Class Initialized
INFO - 2018-04-01 23:33:53 --> Security Class Initialized
DEBUG - 2018-04-01 23:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:33:53 --> Input Class Initialized
INFO - 2018-04-01 23:33:53 --> Language Class Initialized
INFO - 2018-04-01 23:33:53 --> Loader Class Initialized
INFO - 2018-04-01 23:33:53 --> Helper loaded: url_helper
INFO - 2018-04-01 23:33:53 --> Helper loaded: form_helper
INFO - 2018-04-01 23:33:53 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:33:53 --> Form Validation Class Initialized
INFO - 2018-04-01 23:33:53 --> Model Class Initialized
INFO - 2018-04-01 23:33:53 --> Controller Class Initialized
INFO - 2018-04-01 23:33:53 --> Model Class Initialized
INFO - 2018-04-01 23:33:53 --> Model Class Initialized
INFO - 2018-04-01 23:33:53 --> Model Class Initialized
INFO - 2018-04-01 23:33:53 --> Model Class Initialized
DEBUG - 2018-04-01 23:33:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:34:00 --> Config Class Initialized
INFO - 2018-04-01 23:34:00 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:34:00 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:34:00 --> Utf8 Class Initialized
INFO - 2018-04-01 23:34:00 --> URI Class Initialized
INFO - 2018-04-01 23:34:00 --> Router Class Initialized
INFO - 2018-04-01 23:34:00 --> Output Class Initialized
INFO - 2018-04-01 23:34:00 --> Security Class Initialized
DEBUG - 2018-04-01 23:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:34:00 --> Input Class Initialized
INFO - 2018-04-01 23:34:00 --> Language Class Initialized
INFO - 2018-04-01 23:34:00 --> Loader Class Initialized
INFO - 2018-04-01 23:34:00 --> Helper loaded: url_helper
INFO - 2018-04-01 23:34:00 --> Helper loaded: form_helper
INFO - 2018-04-01 23:34:00 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:34:00 --> Form Validation Class Initialized
INFO - 2018-04-01 23:34:00 --> Model Class Initialized
INFO - 2018-04-01 23:34:00 --> Controller Class Initialized
INFO - 2018-04-01 23:34:00 --> Model Class Initialized
INFO - 2018-04-01 23:34:00 --> Model Class Initialized
INFO - 2018-04-01 23:34:00 --> Model Class Initialized
INFO - 2018-04-01 23:34:00 --> Model Class Initialized
DEBUG - 2018-04-01 23:34:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:34:03 --> Config Class Initialized
INFO - 2018-04-01 23:34:03 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:34:03 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:34:03 --> Utf8 Class Initialized
INFO - 2018-04-01 23:34:03 --> URI Class Initialized
INFO - 2018-04-01 23:34:03 --> Router Class Initialized
INFO - 2018-04-01 23:34:03 --> Output Class Initialized
INFO - 2018-04-01 23:34:03 --> Security Class Initialized
DEBUG - 2018-04-01 23:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:34:03 --> Input Class Initialized
INFO - 2018-04-01 23:34:03 --> Language Class Initialized
INFO - 2018-04-01 23:34:03 --> Loader Class Initialized
INFO - 2018-04-01 23:34:03 --> Helper loaded: url_helper
INFO - 2018-04-01 23:34:03 --> Helper loaded: form_helper
INFO - 2018-04-01 23:34:03 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:34:03 --> Form Validation Class Initialized
INFO - 2018-04-01 23:34:03 --> Model Class Initialized
INFO - 2018-04-01 23:34:03 --> Controller Class Initialized
INFO - 2018-04-01 23:34:03 --> Model Class Initialized
INFO - 2018-04-01 23:34:03 --> Model Class Initialized
INFO - 2018-04-01 23:34:03 --> Model Class Initialized
INFO - 2018-04-01 23:34:03 --> Model Class Initialized
DEBUG - 2018-04-01 23:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:34:06 --> Config Class Initialized
INFO - 2018-04-01 23:34:06 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:34:06 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:34:06 --> Utf8 Class Initialized
INFO - 2018-04-01 23:34:06 --> URI Class Initialized
INFO - 2018-04-01 23:34:06 --> Router Class Initialized
INFO - 2018-04-01 23:34:06 --> Output Class Initialized
INFO - 2018-04-01 23:34:06 --> Security Class Initialized
DEBUG - 2018-04-01 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:34:06 --> Input Class Initialized
INFO - 2018-04-01 23:34:06 --> Language Class Initialized
INFO - 2018-04-01 23:34:06 --> Loader Class Initialized
INFO - 2018-04-01 23:34:06 --> Helper loaded: url_helper
INFO - 2018-04-01 23:34:06 --> Helper loaded: form_helper
INFO - 2018-04-01 23:34:06 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:34:06 --> Form Validation Class Initialized
INFO - 2018-04-01 23:34:06 --> Model Class Initialized
INFO - 2018-04-01 23:34:06 --> Controller Class Initialized
INFO - 2018-04-01 23:34:06 --> Model Class Initialized
INFO - 2018-04-01 23:34:06 --> Model Class Initialized
INFO - 2018-04-01 23:34:06 --> Model Class Initialized
INFO - 2018-04-01 23:34:06 --> Model Class Initialized
DEBUG - 2018-04-01 23:34:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:34:11 --> Config Class Initialized
INFO - 2018-04-01 23:34:11 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:34:11 --> Utf8 Class Initialized
INFO - 2018-04-01 23:34:11 --> URI Class Initialized
INFO - 2018-04-01 23:34:11 --> Router Class Initialized
INFO - 2018-04-01 23:34:11 --> Output Class Initialized
INFO - 2018-04-01 23:34:11 --> Security Class Initialized
DEBUG - 2018-04-01 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:34:11 --> Input Class Initialized
INFO - 2018-04-01 23:34:11 --> Language Class Initialized
INFO - 2018-04-01 23:34:11 --> Loader Class Initialized
INFO - 2018-04-01 23:34:11 --> Helper loaded: url_helper
INFO - 2018-04-01 23:34:11 --> Helper loaded: form_helper
INFO - 2018-04-01 23:34:11 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:34:11 --> Form Validation Class Initialized
INFO - 2018-04-01 23:34:11 --> Model Class Initialized
INFO - 2018-04-01 23:34:11 --> Controller Class Initialized
INFO - 2018-04-01 23:34:12 --> Model Class Initialized
INFO - 2018-04-01 23:34:12 --> Model Class Initialized
INFO - 2018-04-01 23:34:12 --> Model Class Initialized
INFO - 2018-04-01 23:34:12 --> Model Class Initialized
DEBUG - 2018-04-01 23:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:34:15 --> Config Class Initialized
INFO - 2018-04-01 23:34:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:34:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:34:15 --> Utf8 Class Initialized
INFO - 2018-04-01 23:34:15 --> URI Class Initialized
INFO - 2018-04-01 23:34:15 --> Router Class Initialized
INFO - 2018-04-01 23:34:15 --> Output Class Initialized
INFO - 2018-04-01 23:34:15 --> Security Class Initialized
DEBUG - 2018-04-01 23:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:34:15 --> Input Class Initialized
INFO - 2018-04-01 23:34:15 --> Language Class Initialized
INFO - 2018-04-01 23:34:15 --> Loader Class Initialized
INFO - 2018-04-01 23:34:15 --> Helper loaded: url_helper
INFO - 2018-04-01 23:34:15 --> Helper loaded: form_helper
INFO - 2018-04-01 23:34:15 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:34:15 --> Form Validation Class Initialized
INFO - 2018-04-01 23:34:15 --> Model Class Initialized
INFO - 2018-04-01 23:34:15 --> Controller Class Initialized
INFO - 2018-04-01 23:34:15 --> Model Class Initialized
INFO - 2018-04-01 23:34:15 --> Model Class Initialized
INFO - 2018-04-01 23:34:15 --> Model Class Initialized
INFO - 2018-04-01 23:34:15 --> Model Class Initialized
DEBUG - 2018-04-01 23:34:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
INFO - 2018-04-01 23:39:45 --> Loader Class Initialized
INFO - 2018-04-01 23:39:45 --> Helper loaded: url_helper
INFO - 2018-04-01 23:39:45 --> Helper loaded: form_helper
INFO - 2018-04-01 23:39:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:39:45 --> Form Validation Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Controller Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:39:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:39:45 --> Final output sent to browser
DEBUG - 2018-04-01 23:39:45 --> Total execution time: 0.0650
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
ERROR - 2018-04-01 23:39:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:39:45 --> Config Class Initialized
INFO - 2018-04-01 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:39:45 --> Utf8 Class Initialized
INFO - 2018-04-01 23:39:45 --> URI Class Initialized
INFO - 2018-04-01 23:39:45 --> Router Class Initialized
INFO - 2018-04-01 23:39:45 --> Output Class Initialized
INFO - 2018-04-01 23:39:45 --> Security Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:39:45 --> Input Class Initialized
INFO - 2018-04-01 23:39:45 --> Language Class Initialized
INFO - 2018-04-01 23:39:45 --> Loader Class Initialized
INFO - 2018-04-01 23:39:45 --> Helper loaded: url_helper
INFO - 2018-04-01 23:39:45 --> Helper loaded: form_helper
INFO - 2018-04-01 23:39:45 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:39:45 --> Form Validation Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Controller Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
INFO - 2018-04-01 23:39:45 --> Model Class Initialized
DEBUG - 2018-04-01 23:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:41:11 --> Config Class Initialized
INFO - 2018-04-01 23:41:11 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:41:11 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:11 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:11 --> URI Class Initialized
INFO - 2018-04-01 23:41:11 --> Router Class Initialized
INFO - 2018-04-01 23:41:11 --> Output Class Initialized
INFO - 2018-04-01 23:41:11 --> Security Class Initialized
DEBUG - 2018-04-01 23:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:11 --> Input Class Initialized
INFO - 2018-04-01 23:41:11 --> Language Class Initialized
INFO - 2018-04-01 23:41:11 --> Loader Class Initialized
INFO - 2018-04-01 23:41:11 --> Helper loaded: url_helper
INFO - 2018-04-01 23:41:11 --> Helper loaded: form_helper
INFO - 2018-04-01 23:41:11 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:41:11 --> Form Validation Class Initialized
INFO - 2018-04-01 23:41:11 --> Model Class Initialized
INFO - 2018-04-01 23:41:11 --> Controller Class Initialized
INFO - 2018-04-01 23:41:11 --> Model Class Initialized
INFO - 2018-04-01 23:41:11 --> Model Class Initialized
INFO - 2018-04-01 23:41:11 --> Model Class Initialized
INFO - 2018-04-01 23:41:11 --> Model Class Initialized
DEBUG - 2018-04-01 23:41:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:41:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:41:11 --> Final output sent to browser
DEBUG - 2018-04-01 23:41:11 --> Total execution time: 0.0785
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:41:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:41:12 --> Config Class Initialized
INFO - 2018-04-01 23:41:12 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:41:12 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:41:12 --> Utf8 Class Initialized
INFO - 2018-04-01 23:41:12 --> URI Class Initialized
INFO - 2018-04-01 23:41:12 --> Router Class Initialized
INFO - 2018-04-01 23:41:12 --> Output Class Initialized
INFO - 2018-04-01 23:41:12 --> Security Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:41:12 --> Input Class Initialized
INFO - 2018-04-01 23:41:12 --> Language Class Initialized
INFO - 2018-04-01 23:41:12 --> Loader Class Initialized
INFO - 2018-04-01 23:41:12 --> Helper loaded: url_helper
INFO - 2018-04-01 23:41:12 --> Helper loaded: form_helper
INFO - 2018-04-01 23:41:12 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:41:12 --> Form Validation Class Initialized
INFO - 2018-04-01 23:41:12 --> Model Class Initialized
INFO - 2018-04-01 23:41:12 --> Controller Class Initialized
INFO - 2018-04-01 23:41:12 --> Model Class Initialized
INFO - 2018-04-01 23:41:12 --> Model Class Initialized
INFO - 2018-04-01 23:41:12 --> Model Class Initialized
INFO - 2018-04-01 23:41:12 --> Model Class Initialized
DEBUG - 2018-04-01 23:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:21 --> Loader Class Initialized
INFO - 2018-04-01 23:43:21 --> Helper loaded: url_helper
INFO - 2018-04-01 23:43:21 --> Helper loaded: form_helper
INFO - 2018-04-01 23:43:21 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:43:21 --> Form Validation Class Initialized
INFO - 2018-04-01 23:43:21 --> Model Class Initialized
INFO - 2018-04-01 23:43:21 --> Controller Class Initialized
INFO - 2018-04-01 23:43:21 --> Model Class Initialized
INFO - 2018-04-01 23:43:21 --> Model Class Initialized
INFO - 2018-04-01 23:43:21 --> Model Class Initialized
INFO - 2018-04-01 23:43:21 --> Model Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:43:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:43:21 --> Final output sent to browser
DEBUG - 2018-04-01 23:43:21 --> Total execution time: 0.0632
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
ERROR - 2018-04-01 23:43:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:43:21 --> Config Class Initialized
INFO - 2018-04-01 23:43:21 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:21 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:21 --> URI Class Initialized
INFO - 2018-04-01 23:43:21 --> Router Class Initialized
INFO - 2018-04-01 23:43:21 --> Output Class Initialized
INFO - 2018-04-01 23:43:21 --> Security Class Initialized
DEBUG - 2018-04-01 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:21 --> Input Class Initialized
INFO - 2018-04-01 23:43:21 --> Language Class Initialized
INFO - 2018-04-01 23:43:22 --> Loader Class Initialized
INFO - 2018-04-01 23:43:22 --> Helper loaded: url_helper
INFO - 2018-04-01 23:43:22 --> Helper loaded: form_helper
INFO - 2018-04-01 23:43:22 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:43:22 --> Form Validation Class Initialized
INFO - 2018-04-01 23:43:22 --> Model Class Initialized
INFO - 2018-04-01 23:43:22 --> Controller Class Initialized
INFO - 2018-04-01 23:43:22 --> Model Class Initialized
INFO - 2018-04-01 23:43:22 --> Model Class Initialized
INFO - 2018-04-01 23:43:22 --> Model Class Initialized
INFO - 2018-04-01 23:43:22 --> Model Class Initialized
DEBUG - 2018-04-01 23:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:43:53 --> Config Class Initialized
INFO - 2018-04-01 23:43:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:43:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:43:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:43:53 --> URI Class Initialized
INFO - 2018-04-01 23:43:53 --> Router Class Initialized
INFO - 2018-04-01 23:43:53 --> Output Class Initialized
INFO - 2018-04-01 23:43:53 --> Security Class Initialized
DEBUG - 2018-04-01 23:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:43:53 --> Input Class Initialized
INFO - 2018-04-01 23:43:53 --> Language Class Initialized
INFO - 2018-04-01 23:43:53 --> Loader Class Initialized
INFO - 2018-04-01 23:43:53 --> Helper loaded: url_helper
INFO - 2018-04-01 23:43:53 --> Helper loaded: form_helper
INFO - 2018-04-01 23:43:53 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:43:53 --> Form Validation Class Initialized
INFO - 2018-04-01 23:43:53 --> Model Class Initialized
INFO - 2018-04-01 23:43:53 --> Controller Class Initialized
INFO - 2018-04-01 23:43:53 --> Model Class Initialized
INFO - 2018-04-01 23:43:53 --> Model Class Initialized
INFO - 2018-04-01 23:43:53 --> Model Class Initialized
INFO - 2018-04-01 23:43:53 --> Model Class Initialized
DEBUG - 2018-04-01 23:43:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:45:42 --> Config Class Initialized
INFO - 2018-04-01 23:45:42 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:45:42 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:45:42 --> Utf8 Class Initialized
INFO - 2018-04-01 23:45:42 --> URI Class Initialized
INFO - 2018-04-01 23:45:42 --> Router Class Initialized
INFO - 2018-04-01 23:45:42 --> Output Class Initialized
INFO - 2018-04-01 23:45:42 --> Security Class Initialized
DEBUG - 2018-04-01 23:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:45:42 --> Input Class Initialized
INFO - 2018-04-01 23:45:42 --> Language Class Initialized
INFO - 2018-04-01 23:45:42 --> Loader Class Initialized
INFO - 2018-04-01 23:45:42 --> Helper loaded: url_helper
INFO - 2018-04-01 23:45:42 --> Helper loaded: form_helper
INFO - 2018-04-01 23:45:42 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:45:42 --> Form Validation Class Initialized
INFO - 2018-04-01 23:45:42 --> Model Class Initialized
INFO - 2018-04-01 23:45:42 --> Controller Class Initialized
INFO - 2018-04-01 23:45:42 --> Model Class Initialized
INFO - 2018-04-01 23:45:42 --> Model Class Initialized
INFO - 2018-04-01 23:45:42 --> Model Class Initialized
INFO - 2018-04-01 23:45:42 --> Model Class Initialized
DEBUG - 2018-04-01 23:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:45:47 --> Config Class Initialized
INFO - 2018-04-01 23:45:47 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:45:47 --> Utf8 Class Initialized
INFO - 2018-04-01 23:45:47 --> URI Class Initialized
INFO - 2018-04-01 23:45:47 --> Router Class Initialized
INFO - 2018-04-01 23:45:47 --> Output Class Initialized
INFO - 2018-04-01 23:45:47 --> Security Class Initialized
DEBUG - 2018-04-01 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:45:47 --> Input Class Initialized
INFO - 2018-04-01 23:45:47 --> Language Class Initialized
INFO - 2018-04-01 23:45:47 --> Loader Class Initialized
INFO - 2018-04-01 23:45:47 --> Helper loaded: url_helper
INFO - 2018-04-01 23:45:47 --> Helper loaded: form_helper
INFO - 2018-04-01 23:45:47 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:45:47 --> Form Validation Class Initialized
INFO - 2018-04-01 23:45:47 --> Model Class Initialized
INFO - 2018-04-01 23:45:47 --> Controller Class Initialized
INFO - 2018-04-01 23:45:47 --> Model Class Initialized
INFO - 2018-04-01 23:45:47 --> Model Class Initialized
INFO - 2018-04-01 23:45:47 --> Model Class Initialized
INFO - 2018-04-01 23:45:47 --> Model Class Initialized
DEBUG - 2018-04-01 23:45:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:45:50 --> Config Class Initialized
INFO - 2018-04-01 23:45:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:45:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:45:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:45:50 --> URI Class Initialized
INFO - 2018-04-01 23:45:50 --> Router Class Initialized
INFO - 2018-04-01 23:45:50 --> Output Class Initialized
INFO - 2018-04-01 23:45:50 --> Security Class Initialized
DEBUG - 2018-04-01 23:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:45:50 --> Input Class Initialized
INFO - 2018-04-01 23:45:50 --> Language Class Initialized
INFO - 2018-04-01 23:45:50 --> Loader Class Initialized
INFO - 2018-04-01 23:45:50 --> Helper loaded: url_helper
INFO - 2018-04-01 23:45:50 --> Helper loaded: form_helper
INFO - 2018-04-01 23:45:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:45:50 --> Form Validation Class Initialized
INFO - 2018-04-01 23:45:50 --> Model Class Initialized
INFO - 2018-04-01 23:45:50 --> Controller Class Initialized
INFO - 2018-04-01 23:45:50 --> Model Class Initialized
INFO - 2018-04-01 23:45:50 --> Model Class Initialized
INFO - 2018-04-01 23:45:50 --> Model Class Initialized
INFO - 2018-04-01 23:45:50 --> Model Class Initialized
DEBUG - 2018-04-01 23:45:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
INFO - 2018-04-01 23:46:50 --> Loader Class Initialized
INFO - 2018-04-01 23:46:50 --> Helper loaded: url_helper
INFO - 2018-04-01 23:46:50 --> Helper loaded: form_helper
INFO - 2018-04-01 23:46:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:46:50 --> Form Validation Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Controller Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:46:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:46:50 --> Final output sent to browser
DEBUG - 2018-04-01 23:46:50 --> Total execution time: 0.0764
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
ERROR - 2018-04-01 23:46:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:46:50 --> Config Class Initialized
INFO - 2018-04-01 23:46:50 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:50 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:50 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:50 --> URI Class Initialized
INFO - 2018-04-01 23:46:50 --> Router Class Initialized
INFO - 2018-04-01 23:46:50 --> Output Class Initialized
INFO - 2018-04-01 23:46:50 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:50 --> Input Class Initialized
INFO - 2018-04-01 23:46:50 --> Language Class Initialized
INFO - 2018-04-01 23:46:50 --> Loader Class Initialized
INFO - 2018-04-01 23:46:50 --> Helper loaded: url_helper
INFO - 2018-04-01 23:46:50 --> Helper loaded: form_helper
INFO - 2018-04-01 23:46:50 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:46:50 --> Form Validation Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Controller Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
INFO - 2018-04-01 23:46:50 --> Model Class Initialized
DEBUG - 2018-04-01 23:46:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
INFO - 2018-04-01 23:46:51 --> Loader Class Initialized
INFO - 2018-04-01 23:46:51 --> Helper loaded: url_helper
INFO - 2018-04-01 23:46:51 --> Helper loaded: form_helper
INFO - 2018-04-01 23:46:51 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:46:51 --> Form Validation Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Controller Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:46:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:46:51 --> Final output sent to browser
DEBUG - 2018-04-01 23:46:51 --> Total execution time: 0.0696
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:46:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:46:51 --> Config Class Initialized
INFO - 2018-04-01 23:46:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:51 --> URI Class Initialized
INFO - 2018-04-01 23:46:51 --> Router Class Initialized
INFO - 2018-04-01 23:46:51 --> Output Class Initialized
INFO - 2018-04-01 23:46:51 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:51 --> Input Class Initialized
INFO - 2018-04-01 23:46:51 --> Language Class Initialized
INFO - 2018-04-01 23:46:51 --> Loader Class Initialized
INFO - 2018-04-01 23:46:51 --> Helper loaded: url_helper
INFO - 2018-04-01 23:46:51 --> Helper loaded: form_helper
INFO - 2018-04-01 23:46:51 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:46:51 --> Form Validation Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Controller Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
INFO - 2018-04-01 23:46:51 --> Model Class Initialized
DEBUG - 2018-04-01 23:46:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:46:54 --> Config Class Initialized
INFO - 2018-04-01 23:46:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:46:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:46:54 --> Utf8 Class Initialized
INFO - 2018-04-01 23:46:54 --> URI Class Initialized
INFO - 2018-04-01 23:46:54 --> Router Class Initialized
INFO - 2018-04-01 23:46:54 --> Output Class Initialized
INFO - 2018-04-01 23:46:54 --> Security Class Initialized
DEBUG - 2018-04-01 23:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:46:54 --> Input Class Initialized
INFO - 2018-04-01 23:46:54 --> Language Class Initialized
INFO - 2018-04-01 23:46:54 --> Loader Class Initialized
INFO - 2018-04-01 23:46:54 --> Helper loaded: url_helper
INFO - 2018-04-01 23:46:54 --> Helper loaded: form_helper
INFO - 2018-04-01 23:46:54 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:46:54 --> Form Validation Class Initialized
INFO - 2018-04-01 23:46:54 --> Model Class Initialized
INFO - 2018-04-01 23:46:54 --> Controller Class Initialized
INFO - 2018-04-01 23:46:54 --> Model Class Initialized
INFO - 2018-04-01 23:46:54 --> Model Class Initialized
INFO - 2018-04-01 23:46:54 --> Model Class Initialized
INFO - 2018-04-01 23:46:54 --> Model Class Initialized
DEBUG - 2018-04-01 23:46:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:04 --> Config Class Initialized
INFO - 2018-04-01 23:47:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:04 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:04 --> URI Class Initialized
INFO - 2018-04-01 23:47:04 --> Router Class Initialized
INFO - 2018-04-01 23:47:04 --> Output Class Initialized
INFO - 2018-04-01 23:47:04 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:04 --> Input Class Initialized
INFO - 2018-04-01 23:47:04 --> Language Class Initialized
INFO - 2018-04-01 23:47:04 --> Loader Class Initialized
INFO - 2018-04-01 23:47:04 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:04 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:04 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:04 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
INFO - 2018-04-01 23:47:04 --> Controller Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
INFO - 2018-04-01 23:47:04 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:47:04 --> Final output sent to browser
DEBUG - 2018-04-01 23:47:04 --> Total execution time: 0.0569
INFO - 2018-04-01 23:47:35 --> Config Class Initialized
INFO - 2018-04-01 23:47:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:35 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:35 --> URI Class Initialized
INFO - 2018-04-01 23:47:35 --> Router Class Initialized
INFO - 2018-04-01 23:47:35 --> Output Class Initialized
INFO - 2018-04-01 23:47:35 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:35 --> Input Class Initialized
INFO - 2018-04-01 23:47:35 --> Language Class Initialized
INFO - 2018-04-01 23:47:35 --> Loader Class Initialized
INFO - 2018-04-01 23:47:35 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:35 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:35 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Controller Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:35 --> Config Class Initialized
INFO - 2018-04-01 23:47:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:35 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:35 --> URI Class Initialized
INFO - 2018-04-01 23:47:35 --> Router Class Initialized
INFO - 2018-04-01 23:47:35 --> Output Class Initialized
INFO - 2018-04-01 23:47:35 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:35 --> Input Class Initialized
INFO - 2018-04-01 23:47:35 --> Language Class Initialized
INFO - 2018-04-01 23:47:35 --> Loader Class Initialized
INFO - 2018-04-01 23:47:35 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:35 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:35 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Controller Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:47:35 --> Final output sent to browser
DEBUG - 2018-04-01 23:47:35 --> Total execution time: 0.0529
INFO - 2018-04-01 23:47:35 --> Config Class Initialized
INFO - 2018-04-01 23:47:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:35 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:35 --> URI Class Initialized
INFO - 2018-04-01 23:47:35 --> Router Class Initialized
INFO - 2018-04-01 23:47:35 --> Output Class Initialized
INFO - 2018-04-01 23:47:35 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:35 --> Input Class Initialized
INFO - 2018-04-01 23:47:35 --> Language Class Initialized
INFO - 2018-04-01 23:47:35 --> Loader Class Initialized
INFO - 2018-04-01 23:47:35 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:35 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:35 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:35 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Controller Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
INFO - 2018-04-01 23:47:35 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
INFO - 2018-04-01 23:47:53 --> Loader Class Initialized
INFO - 2018-04-01 23:47:53 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:53 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:53 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:53 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:53 --> Model Class Initialized
INFO - 2018-04-01 23:47:53 --> Controller Class Initialized
INFO - 2018-04-01 23:47:53 --> Model Class Initialized
INFO - 2018-04-01 23:47:53 --> Model Class Initialized
INFO - 2018-04-01 23:47:53 --> Model Class Initialized
INFO - 2018-04-01 23:47:53 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:47:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:47:53 --> Final output sent to browser
DEBUG - 2018-04-01 23:47:53 --> Total execution time: 0.0601
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
INFO - 2018-04-01 23:47:53 --> Config Class Initialized
INFO - 2018-04-01 23:47:53 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:53 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> URI Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Router Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Output Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
INFO - 2018-04-01 23:47:53 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
DEBUG - 2018-04-01 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
INFO - 2018-04-01 23:47:53 --> Input Class Initialized
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:47:53 --> Language Class Initialized
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:47:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:47:54 --> Config Class Initialized
INFO - 2018-04-01 23:47:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:47:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:47:54 --> Utf8 Class Initialized
INFO - 2018-04-01 23:47:54 --> URI Class Initialized
INFO - 2018-04-01 23:47:54 --> Router Class Initialized
INFO - 2018-04-01 23:47:54 --> Output Class Initialized
INFO - 2018-04-01 23:47:54 --> Security Class Initialized
DEBUG - 2018-04-01 23:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:47:54 --> Input Class Initialized
INFO - 2018-04-01 23:47:54 --> Language Class Initialized
INFO - 2018-04-01 23:47:54 --> Loader Class Initialized
INFO - 2018-04-01 23:47:54 --> Helper loaded: url_helper
INFO - 2018-04-01 23:47:54 --> Helper loaded: form_helper
INFO - 2018-04-01 23:47:54 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:47:54 --> Form Validation Class Initialized
INFO - 2018-04-01 23:47:54 --> Model Class Initialized
INFO - 2018-04-01 23:47:54 --> Controller Class Initialized
INFO - 2018-04-01 23:47:54 --> Model Class Initialized
INFO - 2018-04-01 23:47:54 --> Model Class Initialized
INFO - 2018-04-01 23:47:54 --> Model Class Initialized
INFO - 2018-04-01 23:47:54 --> Model Class Initialized
DEBUG - 2018-04-01 23:47:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:48:05 --> Config Class Initialized
INFO - 2018-04-01 23:48:05 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:48:05 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:48:05 --> Utf8 Class Initialized
INFO - 2018-04-01 23:48:05 --> URI Class Initialized
INFO - 2018-04-01 23:48:05 --> Router Class Initialized
INFO - 2018-04-01 23:48:05 --> Output Class Initialized
INFO - 2018-04-01 23:48:05 --> Security Class Initialized
DEBUG - 2018-04-01 23:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:48:05 --> Input Class Initialized
INFO - 2018-04-01 23:48:05 --> Language Class Initialized
INFO - 2018-04-01 23:48:05 --> Loader Class Initialized
INFO - 2018-04-01 23:48:05 --> Helper loaded: url_helper
INFO - 2018-04-01 23:48:05 --> Helper loaded: form_helper
INFO - 2018-04-01 23:48:05 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:48:05 --> Form Validation Class Initialized
INFO - 2018-04-01 23:48:05 --> Model Class Initialized
INFO - 2018-04-01 23:48:05 --> Controller Class Initialized
INFO - 2018-04-01 23:48:05 --> Model Class Initialized
INFO - 2018-04-01 23:48:05 --> Model Class Initialized
INFO - 2018-04-01 23:48:05 --> Model Class Initialized
INFO - 2018-04-01 23:48:05 --> Model Class Initialized
DEBUG - 2018-04-01 23:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:48:10 --> Config Class Initialized
INFO - 2018-04-01 23:48:10 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:48:10 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:48:10 --> Utf8 Class Initialized
INFO - 2018-04-01 23:48:10 --> URI Class Initialized
INFO - 2018-04-01 23:48:10 --> Router Class Initialized
INFO - 2018-04-01 23:48:10 --> Output Class Initialized
INFO - 2018-04-01 23:48:10 --> Security Class Initialized
DEBUG - 2018-04-01 23:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:48:10 --> Input Class Initialized
INFO - 2018-04-01 23:48:10 --> Language Class Initialized
INFO - 2018-04-01 23:48:10 --> Loader Class Initialized
INFO - 2018-04-01 23:48:10 --> Helper loaded: url_helper
INFO - 2018-04-01 23:48:10 --> Helper loaded: form_helper
INFO - 2018-04-01 23:48:10 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:48:10 --> Form Validation Class Initialized
INFO - 2018-04-01 23:48:10 --> Model Class Initialized
INFO - 2018-04-01 23:48:10 --> Controller Class Initialized
INFO - 2018-04-01 23:48:10 --> Model Class Initialized
INFO - 2018-04-01 23:48:10 --> Model Class Initialized
INFO - 2018-04-01 23:48:10 --> Model Class Initialized
INFO - 2018-04-01 23:48:10 --> Model Class Initialized
DEBUG - 2018-04-01 23:48:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:58:51 --> Config Class Initialized
INFO - 2018-04-01 23:58:51 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:58:51 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:51 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:51 --> URI Class Initialized
INFO - 2018-04-01 23:58:51 --> Router Class Initialized
INFO - 2018-04-01 23:58:51 --> Output Class Initialized
INFO - 2018-04-01 23:58:51 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:51 --> Input Class Initialized
INFO - 2018-04-01 23:58:51 --> Language Class Initialized
INFO - 2018-04-01 23:58:51 --> Loader Class Initialized
INFO - 2018-04-01 23:58:51 --> Helper loaded: url_helper
INFO - 2018-04-01 23:58:51 --> Helper loaded: form_helper
INFO - 2018-04-01 23:58:51 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:58:51 --> Form Validation Class Initialized
INFO - 2018-04-01 23:58:51 --> Model Class Initialized
INFO - 2018-04-01 23:58:51 --> Controller Class Initialized
INFO - 2018-04-01 23:58:51 --> Model Class Initialized
INFO - 2018-04-01 23:58:51 --> Model Class Initialized
INFO - 2018-04-01 23:58:51 --> Model Class Initialized
INFO - 2018-04-01 23:58:51 --> Model Class Initialized
DEBUG - 2018-04-01 23:58:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:58:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:58:51 --> Final output sent to browser
DEBUG - 2018-04-01 23:58:51 --> Total execution time: 0.0572
INFO - 2018-04-01 23:58:52 --> Config Class Initialized
INFO - 2018-04-01 23:58:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:58:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:52 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:52 --> URI Class Initialized
INFO - 2018-04-01 23:58:52 --> Router Class Initialized
INFO - 2018-04-01 23:58:52 --> Output Class Initialized
INFO - 2018-04-01 23:58:52 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:52 --> Input Class Initialized
INFO - 2018-04-01 23:58:52 --> Language Class Initialized
INFO - 2018-04-01 23:58:52 --> Loader Class Initialized
INFO - 2018-04-01 23:58:52 --> Helper loaded: url_helper
INFO - 2018-04-01 23:58:52 --> Helper loaded: form_helper
INFO - 2018-04-01 23:58:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:58:52 --> Form Validation Class Initialized
INFO - 2018-04-01 23:58:52 --> Model Class Initialized
INFO - 2018-04-01 23:58:52 --> Controller Class Initialized
INFO - 2018-04-01 23:58:52 --> Model Class Initialized
INFO - 2018-04-01 23:58:52 --> Model Class Initialized
INFO - 2018-04-01 23:58:52 --> Model Class Initialized
INFO - 2018-04-01 23:58:52 --> Model Class Initialized
DEBUG - 2018-04-01 23:58:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 23:58:52 --> Severity: Notice --> Undefined index: proveedor_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 2004
ERROR - 2018-04-01 23:58:52 --> Severity: Notice --> Undefined index: proyecto_gasto_estado_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 2008
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
INFO - 2018-04-01 23:58:59 --> Config Class Initialized
INFO - 2018-04-01 23:58:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
DEBUG - 2018-04-01 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:58:59 --> Utf8 Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> URI Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Router Class Initialized
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
INFO - 2018-04-01 23:58:59 --> Output Class Initialized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Security Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
DEBUG - 2018-04-01 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:58:59 --> Input Class Initialized
INFO - 2018-04-01 23:58:59 --> Language Class Initialized
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:58:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:59:01 --> Config Class Initialized
INFO - 2018-04-01 23:59:01 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:01 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:01 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:01 --> URI Class Initialized
INFO - 2018-04-01 23:59:01 --> Router Class Initialized
INFO - 2018-04-01 23:59:01 --> Output Class Initialized
INFO - 2018-04-01 23:59:01 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:01 --> Input Class Initialized
INFO - 2018-04-01 23:59:01 --> Language Class Initialized
INFO - 2018-04-01 23:59:01 --> Loader Class Initialized
INFO - 2018-04-01 23:59:01 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:01 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:01 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:01 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:01 --> Model Class Initialized
INFO - 2018-04-01 23:59:01 --> Controller Class Initialized
INFO - 2018-04-01 23:59:01 --> Model Class Initialized
INFO - 2018-04-01 23:59:01 --> Model Class Initialized
INFO - 2018-04-01 23:59:01 --> Model Class Initialized
INFO - 2018-04-01 23:59:01 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:59:01 --> Final output sent to browser
DEBUG - 2018-04-01 23:59:01 --> Total execution time: 0.0607
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
ERROR - 2018-04-01 23:59:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:59:02 --> Config Class Initialized
INFO - 2018-04-01 23:59:02 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:02 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:02 --> URI Class Initialized
INFO - 2018-04-01 23:59:02 --> Router Class Initialized
INFO - 2018-04-01 23:59:02 --> Output Class Initialized
INFO - 2018-04-01 23:59:02 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:02 --> Input Class Initialized
INFO - 2018-04-01 23:59:02 --> Language Class Initialized
INFO - 2018-04-01 23:59:02 --> Loader Class Initialized
INFO - 2018-04-01 23:59:02 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:02 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:02 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:02 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:02 --> Model Class Initialized
INFO - 2018-04-01 23:59:02 --> Controller Class Initialized
INFO - 2018-04-01 23:59:02 --> Model Class Initialized
INFO - 2018-04-01 23:59:02 --> Model Class Initialized
INFO - 2018-04-01 23:59:02 --> Model Class Initialized
INFO - 2018-04-01 23:59:02 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-01 23:59:02 --> Severity: Notice --> Undefined index: proveedor_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 2004
ERROR - 2018-04-01 23:59:02 --> Severity: Notice --> Undefined index: proyecto_gasto_estado_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 2008
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
INFO - 2018-04-01 23:59:28 --> Loader Class Initialized
INFO - 2018-04-01 23:59:28 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:28 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:28 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:28 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:28 --> Model Class Initialized
INFO - 2018-04-01 23:59:28 --> Controller Class Initialized
INFO - 2018-04-01 23:59:28 --> Model Class Initialized
INFO - 2018-04-01 23:59:28 --> Model Class Initialized
INFO - 2018-04-01 23:59:28 --> Model Class Initialized
INFO - 2018-04-01 23:59:28 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-01 23:59:28 --> Final output sent to browser
DEBUG - 2018-04-01 23:59:28 --> Total execution time: 0.0727
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:28 --> Config Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
INFO - 2018-04-01 23:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2018-04-01 23:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> URI Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Router Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Output Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
INFO - 2018-04-01 23:59:28 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
DEBUG - 2018-04-01 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:28 --> Input Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
INFO - 2018-04-01 23:59:28 --> Language Class Initialized
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-01 23:59:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-01 23:59:29 --> Config Class Initialized
INFO - 2018-04-01 23:59:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:29 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:29 --> URI Class Initialized
INFO - 2018-04-01 23:59:29 --> Router Class Initialized
INFO - 2018-04-01 23:59:29 --> Output Class Initialized
INFO - 2018-04-01 23:59:29 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:29 --> Input Class Initialized
INFO - 2018-04-01 23:59:29 --> Language Class Initialized
INFO - 2018-04-01 23:59:29 --> Loader Class Initialized
INFO - 2018-04-01 23:59:29 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:29 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:29 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:29 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:29 --> Model Class Initialized
INFO - 2018-04-01 23:59:29 --> Controller Class Initialized
INFO - 2018-04-01 23:59:29 --> Model Class Initialized
INFO - 2018-04-01 23:59:29 --> Model Class Initialized
INFO - 2018-04-01 23:59:29 --> Model Class Initialized
INFO - 2018-04-01 23:59:29 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:40 --> Config Class Initialized
INFO - 2018-04-01 23:59:40 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:40 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:40 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:40 --> URI Class Initialized
INFO - 2018-04-01 23:59:40 --> Router Class Initialized
INFO - 2018-04-01 23:59:40 --> Output Class Initialized
INFO - 2018-04-01 23:59:40 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:40 --> Input Class Initialized
INFO - 2018-04-01 23:59:40 --> Language Class Initialized
INFO - 2018-04-01 23:59:40 --> Loader Class Initialized
INFO - 2018-04-01 23:59:40 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:40 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:40 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:40 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:40 --> Model Class Initialized
INFO - 2018-04-01 23:59:40 --> Controller Class Initialized
INFO - 2018-04-01 23:59:40 --> Model Class Initialized
INFO - 2018-04-01 23:59:40 --> Model Class Initialized
INFO - 2018-04-01 23:59:40 --> Model Class Initialized
INFO - 2018-04-01 23:59:40 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:43 --> Config Class Initialized
INFO - 2018-04-01 23:59:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:43 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:43 --> URI Class Initialized
INFO - 2018-04-01 23:59:43 --> Router Class Initialized
INFO - 2018-04-01 23:59:43 --> Output Class Initialized
INFO - 2018-04-01 23:59:43 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:43 --> Input Class Initialized
INFO - 2018-04-01 23:59:43 --> Language Class Initialized
INFO - 2018-04-01 23:59:43 --> Loader Class Initialized
INFO - 2018-04-01 23:59:43 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:43 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:43 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:43 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:43 --> Model Class Initialized
INFO - 2018-04-01 23:59:43 --> Controller Class Initialized
INFO - 2018-04-01 23:59:43 --> Model Class Initialized
INFO - 2018-04-01 23:59:44 --> Model Class Initialized
INFO - 2018-04-01 23:59:44 --> Model Class Initialized
INFO - 2018-04-01 23:59:44 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:46 --> Config Class Initialized
INFO - 2018-04-01 23:59:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:46 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:46 --> URI Class Initialized
INFO - 2018-04-01 23:59:46 --> Router Class Initialized
INFO - 2018-04-01 23:59:46 --> Output Class Initialized
INFO - 2018-04-01 23:59:46 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:46 --> Input Class Initialized
INFO - 2018-04-01 23:59:46 --> Language Class Initialized
INFO - 2018-04-01 23:59:46 --> Loader Class Initialized
INFO - 2018-04-01 23:59:46 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:46 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:46 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:46 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:46 --> Model Class Initialized
INFO - 2018-04-01 23:59:47 --> Controller Class Initialized
INFO - 2018-04-01 23:59:47 --> Model Class Initialized
INFO - 2018-04-01 23:59:47 --> Model Class Initialized
INFO - 2018-04-01 23:59:47 --> Model Class Initialized
INFO - 2018-04-01 23:59:47 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:49 --> Config Class Initialized
INFO - 2018-04-01 23:59:49 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:49 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:49 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:49 --> URI Class Initialized
INFO - 2018-04-01 23:59:49 --> Router Class Initialized
INFO - 2018-04-01 23:59:49 --> Output Class Initialized
INFO - 2018-04-01 23:59:49 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:49 --> Input Class Initialized
INFO - 2018-04-01 23:59:49 --> Language Class Initialized
INFO - 2018-04-01 23:59:49 --> Loader Class Initialized
INFO - 2018-04-01 23:59:49 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:49 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:49 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:49 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:49 --> Model Class Initialized
INFO - 2018-04-01 23:59:49 --> Controller Class Initialized
INFO - 2018-04-01 23:59:49 --> Model Class Initialized
INFO - 2018-04-01 23:59:49 --> Model Class Initialized
INFO - 2018-04-01 23:59:49 --> Model Class Initialized
INFO - 2018-04-01 23:59:49 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:52 --> Config Class Initialized
INFO - 2018-04-01 23:59:52 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:52 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:52 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:52 --> URI Class Initialized
INFO - 2018-04-01 23:59:52 --> Router Class Initialized
INFO - 2018-04-01 23:59:52 --> Output Class Initialized
INFO - 2018-04-01 23:59:52 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:52 --> Input Class Initialized
INFO - 2018-04-01 23:59:52 --> Language Class Initialized
INFO - 2018-04-01 23:59:52 --> Loader Class Initialized
INFO - 2018-04-01 23:59:52 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:52 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:52 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:52 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:52 --> Model Class Initialized
INFO - 2018-04-01 23:59:52 --> Controller Class Initialized
INFO - 2018-04-01 23:59:52 --> Model Class Initialized
INFO - 2018-04-01 23:59:52 --> Model Class Initialized
INFO - 2018-04-01 23:59:52 --> Model Class Initialized
INFO - 2018-04-01 23:59:52 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:56 --> Config Class Initialized
INFO - 2018-04-01 23:59:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:56 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:56 --> URI Class Initialized
INFO - 2018-04-01 23:59:56 --> Router Class Initialized
INFO - 2018-04-01 23:59:56 --> Output Class Initialized
INFO - 2018-04-01 23:59:56 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:56 --> Input Class Initialized
INFO - 2018-04-01 23:59:56 --> Language Class Initialized
INFO - 2018-04-01 23:59:56 --> Loader Class Initialized
INFO - 2018-04-01 23:59:56 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:56 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:56 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:56 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:56 --> Model Class Initialized
INFO - 2018-04-01 23:59:56 --> Controller Class Initialized
INFO - 2018-04-01 23:59:56 --> Model Class Initialized
INFO - 2018-04-01 23:59:56 --> Model Class Initialized
INFO - 2018-04-01 23:59:56 --> Model Class Initialized
INFO - 2018-04-01 23:59:56 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 23:59:58 --> Config Class Initialized
INFO - 2018-04-01 23:59:58 --> Hooks Class Initialized
DEBUG - 2018-04-01 23:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-01 23:59:58 --> Utf8 Class Initialized
INFO - 2018-04-01 23:59:58 --> URI Class Initialized
INFO - 2018-04-01 23:59:58 --> Router Class Initialized
INFO - 2018-04-01 23:59:58 --> Output Class Initialized
INFO - 2018-04-01 23:59:58 --> Security Class Initialized
DEBUG - 2018-04-01 23:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 23:59:58 --> Input Class Initialized
INFO - 2018-04-01 23:59:58 --> Language Class Initialized
INFO - 2018-04-01 23:59:58 --> Loader Class Initialized
INFO - 2018-04-01 23:59:58 --> Helper loaded: url_helper
INFO - 2018-04-01 23:59:58 --> Helper loaded: form_helper
INFO - 2018-04-01 23:59:58 --> Database Driver Class Initialized
DEBUG - 2018-04-01 23:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-01 23:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 23:59:58 --> Form Validation Class Initialized
INFO - 2018-04-01 23:59:58 --> Model Class Initialized
INFO - 2018-04-01 23:59:58 --> Controller Class Initialized
INFO - 2018-04-01 23:59:58 --> Model Class Initialized
INFO - 2018-04-01 23:59:58 --> Model Class Initialized
INFO - 2018-04-01 23:59:58 --> Model Class Initialized
INFO - 2018-04-01 23:59:58 --> Model Class Initialized
DEBUG - 2018-04-01 23:59:58 --> Form_validation class already loaded. Second attempt ignored.
