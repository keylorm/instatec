<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-31 19:14:22 --> Config Class Initialized
INFO - 2018-03-31 19:14:22 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:22 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:22 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:22 --> URI Class Initialized
INFO - 2018-03-31 19:14:22 --> Router Class Initialized
INFO - 2018-03-31 19:14:22 --> Output Class Initialized
INFO - 2018-03-31 19:14:22 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:22 --> Input Class Initialized
INFO - 2018-03-31 19:14:22 --> Language Class Initialized
INFO - 2018-03-31 19:14:23 --> Loader Class Initialized
INFO - 2018-03-31 19:14:23 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:23 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:23 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
INFO - 2018-03-31 19:14:23 --> Controller Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:23 --> Config Class Initialized
INFO - 2018-03-31 19:14:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:23 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:23 --> URI Class Initialized
INFO - 2018-03-31 19:14:23 --> Router Class Initialized
INFO - 2018-03-31 19:14:23 --> Output Class Initialized
INFO - 2018-03-31 19:14:23 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:23 --> Input Class Initialized
INFO - 2018-03-31 19:14:23 --> Language Class Initialized
INFO - 2018-03-31 19:14:23 --> Loader Class Initialized
INFO - 2018-03-31 19:14:23 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:23 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:23 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
INFO - 2018-03-31 19:14:23 --> Controller Class Initialized
INFO - 2018-03-31 19:14:23 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:14:24 --> Final output sent to browser
DEBUG - 2018-03-31 19:14:24 --> Total execution time: 0.2337
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:24 --> Config Class Initialized
INFO - 2018-03-31 19:14:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:24 --> URI Class Initialized
INFO - 2018-03-31 19:14:24 --> Router Class Initialized
INFO - 2018-03-31 19:14:24 --> Output Class Initialized
INFO - 2018-03-31 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:24 --> Input Class Initialized
INFO - 2018-03-31 19:14:24 --> Language Class Initialized
ERROR - 2018-03-31 19:14:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:29 --> Config Class Initialized
INFO - 2018-03-31 19:14:29 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:29 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:29 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:29 --> URI Class Initialized
INFO - 2018-03-31 19:14:29 --> Router Class Initialized
INFO - 2018-03-31 19:14:29 --> Output Class Initialized
INFO - 2018-03-31 19:14:29 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:29 --> Input Class Initialized
INFO - 2018-03-31 19:14:29 --> Language Class Initialized
INFO - 2018-03-31 19:14:29 --> Loader Class Initialized
INFO - 2018-03-31 19:14:29 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:29 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:29 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:29 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:29 --> Model Class Initialized
INFO - 2018-03-31 19:14:29 --> Controller Class Initialized
INFO - 2018-03-31 19:14:29 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 19:14:29 --> Config Class Initialized
INFO - 2018-03-31 19:14:29 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:29 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:29 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:29 --> URI Class Initialized
DEBUG - 2018-03-31 19:14:29 --> No URI present. Default controller set.
INFO - 2018-03-31 19:14:29 --> Router Class Initialized
INFO - 2018-03-31 19:14:29 --> Output Class Initialized
INFO - 2018-03-31 19:14:29 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:29 --> Input Class Initialized
INFO - 2018-03-31 19:14:29 --> Language Class Initialized
INFO - 2018-03-31 19:14:29 --> Loader Class Initialized
INFO - 2018-03-31 19:14:29 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:29 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:29 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:29 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:29 --> Model Class Initialized
INFO - 2018-03-31 19:14:29 --> Controller Class Initialized
INFO - 2018-03-31 19:14:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:14:29 --> Final output sent to browser
DEBUG - 2018-03-31 19:14:29 --> Total execution time: 0.2060
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:30 --> Loader Class Initialized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> Database Driver Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:30 --> Config Class Initialized
INFO - 2018-03-31 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:30 --> URI Class Initialized
INFO - 2018-03-31 19:14:30 --> Router Class Initialized
INFO - 2018-03-31 19:14:30 --> Output Class Initialized
INFO - 2018-03-31 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:30 --> Input Class Initialized
INFO - 2018-03-31 19:14:30 --> Language Class Initialized
ERROR - 2018-03-31 19:14:30 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:30 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
INFO - 2018-03-31 19:14:30 --> Controller Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
INFO - 2018-03-31 19:14:30 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:44 --> Config Class Initialized
INFO - 2018-03-31 19:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:44 --> URI Class Initialized
INFO - 2018-03-31 19:14:44 --> Router Class Initialized
INFO - 2018-03-31 19:14:44 --> Output Class Initialized
INFO - 2018-03-31 19:14:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:44 --> Input Class Initialized
INFO - 2018-03-31 19:14:44 --> Language Class Initialized
INFO - 2018-03-31 19:14:44 --> Loader Class Initialized
INFO - 2018-03-31 19:14:44 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:44 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:45 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:45 --> Model Class Initialized
INFO - 2018-03-31 19:14:45 --> Controller Class Initialized
INFO - 2018-03-31 19:14:45 --> Model Class Initialized
INFO - 2018-03-31 19:14:45 --> Model Class Initialized
INFO - 2018-03-31 19:14:45 --> Model Class Initialized
INFO - 2018-03-31 19:14:45 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:14:45 --> Final output sent to browser
DEBUG - 2018-03-31 19:14:45 --> Total execution time: 1.1723
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
ERROR - 2018-03-31 19:14:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:48 --> Config Class Initialized
INFO - 2018-03-31 19:14:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:48 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:48 --> URI Class Initialized
INFO - 2018-03-31 19:14:48 --> Router Class Initialized
INFO - 2018-03-31 19:14:48 --> Output Class Initialized
INFO - 2018-03-31 19:14:48 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:48 --> Input Class Initialized
INFO - 2018-03-31 19:14:48 --> Language Class Initialized
INFO - 2018-03-31 19:14:48 --> Loader Class Initialized
INFO - 2018-03-31 19:14:48 --> Helper loaded: url_helper
INFO - 2018-03-31 19:14:48 --> Helper loaded: form_helper
INFO - 2018-03-31 19:14:48 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:14:49 --> Form Validation Class Initialized
INFO - 2018-03-31 19:14:49 --> Model Class Initialized
INFO - 2018-03-31 19:14:49 --> Controller Class Initialized
INFO - 2018-03-31 19:14:49 --> Model Class Initialized
INFO - 2018-03-31 19:14:49 --> Model Class Initialized
INFO - 2018-03-31 19:14:49 --> Model Class Initialized
INFO - 2018-03-31 19:14:49 --> Model Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:14:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:14:49 --> Final output sent to browser
DEBUG - 2018-03-31 19:14:49 --> Total execution time: 0.2606
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> Config Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
INFO - 2018-03-31 19:14:49 --> Hooks Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:14:49 --> URI Class Initialized
INFO - 2018-03-31 19:14:49 --> Router Class Initialized
INFO - 2018-03-31 19:14:49 --> Output Class Initialized
INFO - 2018-03-31 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:14:49 --> Input Class Initialized
INFO - 2018-03-31 19:14:49 --> Language Class Initialized
ERROR - 2018-03-31 19:14:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:16:26 --> Config Class Initialized
INFO - 2018-03-31 19:16:26 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:26 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:26 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:26 --> URI Class Initialized
INFO - 2018-03-31 19:16:26 --> Router Class Initialized
INFO - 2018-03-31 19:16:26 --> Output Class Initialized
INFO - 2018-03-31 19:16:26 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:26 --> Input Class Initialized
INFO - 2018-03-31 19:16:26 --> Language Class Initialized
INFO - 2018-03-31 19:16:26 --> Loader Class Initialized
INFO - 2018-03-31 19:16:26 --> Helper loaded: url_helper
INFO - 2018-03-31 19:16:26 --> Helper loaded: form_helper
INFO - 2018-03-31 19:16:26 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:16:26 --> Form Validation Class Initialized
INFO - 2018-03-31 19:16:26 --> Model Class Initialized
INFO - 2018-03-31 19:16:26 --> Controller Class Initialized
INFO - 2018-03-31 19:16:26 --> Model Class Initialized
INFO - 2018-03-31 19:16:26 --> Model Class Initialized
INFO - 2018-03-31 19:16:26 --> Model Class Initialized
INFO - 2018-03-31 19:16:26 --> Model Class Initialized
DEBUG - 2018-03-31 19:16:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:16:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:16:26 --> Final output sent to browser
DEBUG - 2018-03-31 19:16:26 --> Total execution time: 0.2523
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
ERROR - 2018-03-31 19:16:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:16:27 --> Config Class Initialized
INFO - 2018-03-31 19:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:16:27 --> Utf8 Class Initialized
INFO - 2018-03-31 19:16:27 --> URI Class Initialized
INFO - 2018-03-31 19:16:27 --> Router Class Initialized
INFO - 2018-03-31 19:16:27 --> Output Class Initialized
INFO - 2018-03-31 19:16:27 --> Security Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:16:27 --> Input Class Initialized
INFO - 2018-03-31 19:16:27 --> Language Class Initialized
INFO - 2018-03-31 19:16:27 --> Loader Class Initialized
INFO - 2018-03-31 19:16:27 --> Helper loaded: url_helper
INFO - 2018-03-31 19:16:27 --> Helper loaded: form_helper
INFO - 2018-03-31 19:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:16:27 --> Form Validation Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
INFO - 2018-03-31 19:16:27 --> Controller Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
INFO - 2018-03-31 19:16:27 --> Model Class Initialized
DEBUG - 2018-03-31 19:16:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:25:24 --> Config Class Initialized
INFO - 2018-03-31 19:25:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:25:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:24 --> URI Class Initialized
INFO - 2018-03-31 19:25:24 --> Router Class Initialized
INFO - 2018-03-31 19:25:24 --> Output Class Initialized
INFO - 2018-03-31 19:25:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:24 --> Input Class Initialized
INFO - 2018-03-31 19:25:24 --> Language Class Initialized
INFO - 2018-03-31 19:25:24 --> Loader Class Initialized
INFO - 2018-03-31 19:25:24 --> Helper loaded: url_helper
INFO - 2018-03-31 19:25:24 --> Helper loaded: form_helper
INFO - 2018-03-31 19:25:24 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:25:25 --> Form Validation Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Controller Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:25:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:25:25 --> Final output sent to browser
DEBUG - 2018-03-31 19:25:25 --> Total execution time: 0.2500
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:25:25 --> Config Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
INFO - 2018-03-31 19:25:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
DEBUG - 2018-03-31 19:25:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
INFO - 2018-03-31 19:25:25 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> URI Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
INFO - 2018-03-31 19:25:25 --> Router Class Initialized
ERROR - 2018-03-31 19:25:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:25:25 --> Output Class Initialized
INFO - 2018-03-31 19:25:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:25:25 --> Input Class Initialized
INFO - 2018-03-31 19:25:25 --> Language Class Initialized
INFO - 2018-03-31 19:25:25 --> Loader Class Initialized
INFO - 2018-03-31 19:25:25 --> Helper loaded: url_helper
INFO - 2018-03-31 19:25:25 --> Helper loaded: form_helper
INFO - 2018-03-31 19:25:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:25:25 --> Form Validation Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Controller Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
INFO - 2018-03-31 19:25:25 --> Model Class Initialized
DEBUG - 2018-03-31 19:25:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1867
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1920
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:25:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
INFO - 2018-03-31 19:26:16 --> Config Class Initialized
INFO - 2018-03-31 19:26:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:16 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:16 --> URI Class Initialized
INFO - 2018-03-31 19:26:16 --> Router Class Initialized
INFO - 2018-03-31 19:26:16 --> Output Class Initialized
INFO - 2018-03-31 19:26:16 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:16 --> Input Class Initialized
INFO - 2018-03-31 19:26:16 --> Language Class Initialized
INFO - 2018-03-31 19:26:16 --> Loader Class Initialized
INFO - 2018-03-31 19:26:16 --> Helper loaded: url_helper
INFO - 2018-03-31 19:26:16 --> Helper loaded: form_helper
INFO - 2018-03-31 19:26:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:26:16 --> Form Validation Class Initialized
INFO - 2018-03-31 19:26:16 --> Model Class Initialized
INFO - 2018-03-31 19:26:16 --> Controller Class Initialized
INFO - 2018-03-31 19:26:16 --> Model Class Initialized
INFO - 2018-03-31 19:26:16 --> Model Class Initialized
INFO - 2018-03-31 19:26:16 --> Model Class Initialized
INFO - 2018-03-31 19:26:16 --> Model Class Initialized
DEBUG - 2018-03-31 19:26:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:26:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:26:16 --> Final output sent to browser
DEBUG - 2018-03-31 19:26:16 --> Total execution time: 0.2391
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Config Class Initialized
INFO - 2018-03-31 19:26:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Loader Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
DEBUG - 2018-03-31 19:26:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:26:17 --> Helper loaded: url_helper
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:26:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:26:17 --> URI Class Initialized
INFO - 2018-03-31 19:26:17 --> Helper loaded: form_helper
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Router Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:26:17 --> Output Class Initialized
INFO - 2018-03-31 19:26:17 --> Database Driver Class Initialized
INFO - 2018-03-31 19:26:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:26:17 --> Input Class Initialized
INFO - 2018-03-31 19:26:17 --> Language Class Initialized
ERROR - 2018-03-31 19:26:17 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:26:17 --> Form Validation Class Initialized
INFO - 2018-03-31 19:26:17 --> Model Class Initialized
INFO - 2018-03-31 19:26:17 --> Controller Class Initialized
INFO - 2018-03-31 19:26:17 --> Model Class Initialized
INFO - 2018-03-31 19:26:17 --> Model Class Initialized
INFO - 2018-03-31 19:26:17 --> Model Class Initialized
INFO - 2018-03-31 19:26:17 --> Model Class Initialized
DEBUG - 2018-03-31 19:26:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:17 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:26:18 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
INFO - 2018-03-31 19:28:13 --> Config Class Initialized
INFO - 2018-03-31 19:28:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:28:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:13 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:13 --> URI Class Initialized
INFO - 2018-03-31 19:28:13 --> Router Class Initialized
INFO - 2018-03-31 19:28:13 --> Output Class Initialized
INFO - 2018-03-31 19:28:13 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:13 --> Input Class Initialized
INFO - 2018-03-31 19:28:13 --> Language Class Initialized
INFO - 2018-03-31 19:28:13 --> Loader Class Initialized
INFO - 2018-03-31 19:28:13 --> Helper loaded: url_helper
INFO - 2018-03-31 19:28:13 --> Helper loaded: form_helper
INFO - 2018-03-31 19:28:13 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:28:13 --> Form Validation Class Initialized
INFO - 2018-03-31 19:28:13 --> Model Class Initialized
INFO - 2018-03-31 19:28:13 --> Controller Class Initialized
INFO - 2018-03-31 19:28:13 --> Model Class Initialized
INFO - 2018-03-31 19:28:13 --> Model Class Initialized
INFO - 2018-03-31 19:28:13 --> Model Class Initialized
INFO - 2018-03-31 19:28:13 --> Model Class Initialized
DEBUG - 2018-03-31 19:28:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:28:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:28:13 --> Final output sent to browser
DEBUG - 2018-03-31 19:28:13 --> Total execution time: 0.2729
INFO - 2018-03-31 19:28:13 --> Config Class Initialized
INFO - 2018-03-31 19:28:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:28:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:13 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:13 --> URI Class Initialized
INFO - 2018-03-31 19:28:13 --> Router Class Initialized
INFO - 2018-03-31 19:28:13 --> Output Class Initialized
INFO - 2018-03-31 19:28:13 --> Config Class Initialized
INFO - 2018-03-31 19:28:13 --> Hooks Class Initialized
INFO - 2018-03-31 19:28:13 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:13 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
INFO - 2018-03-31 19:28:14 --> Loader Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Config Class Initialized
INFO - 2018-03-31 19:28:14 --> Hooks Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
INFO - 2018-03-31 19:28:14 --> Helper loaded: url_helper
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:28:14 --> Helper loaded: form_helper
DEBUG - 2018-03-31 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:28:14 --> URI Class Initialized
INFO - 2018-03-31 19:28:14 --> Router Class Initialized
INFO - 2018-03-31 19:28:14 --> Output Class Initialized
INFO - 2018-03-31 19:28:14 --> Database Driver Class Initialized
INFO - 2018-03-31 19:28:14 --> Security Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:28:14 --> Input Class Initialized
INFO - 2018-03-31 19:28:14 --> Language Class Initialized
ERROR - 2018-03-31 19:28:14 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:28:14 --> Form Validation Class Initialized
INFO - 2018-03-31 19:28:14 --> Model Class Initialized
INFO - 2018-03-31 19:28:14 --> Controller Class Initialized
INFO - 2018-03-31 19:28:14 --> Model Class Initialized
INFO - 2018-03-31 19:28:14 --> Model Class Initialized
INFO - 2018-03-31 19:28:14 --> Model Class Initialized
INFO - 2018-03-31 19:28:14 --> Model Class Initialized
DEBUG - 2018-03-31 19:28:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:14 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:15 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:15 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:15 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:15 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:15 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:15 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:15 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:15 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
ERROR - 2018-03-31 19:28:15 --> Severity: Notice --> Undefined property: stdClass::$valor_venta D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1894
ERROR - 2018-03-31 19:28:15 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1895
INFO - 2018-03-31 19:29:09 --> Config Class Initialized
INFO - 2018-03-31 19:29:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:09 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:09 --> URI Class Initialized
INFO - 2018-03-31 19:29:09 --> Router Class Initialized
INFO - 2018-03-31 19:29:09 --> Output Class Initialized
INFO - 2018-03-31 19:29:09 --> Security Class Initialized
DEBUG - 2018-03-31 19:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:09 --> Input Class Initialized
INFO - 2018-03-31 19:29:09 --> Language Class Initialized
INFO - 2018-03-31 19:29:09 --> Loader Class Initialized
INFO - 2018-03-31 19:29:09 --> Helper loaded: url_helper
INFO - 2018-03-31 19:29:09 --> Helper loaded: form_helper
INFO - 2018-03-31 19:29:09 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:29:09 --> Form Validation Class Initialized
INFO - 2018-03-31 19:29:09 --> Model Class Initialized
INFO - 2018-03-31 19:29:09 --> Controller Class Initialized
INFO - 2018-03-31 19:29:09 --> Model Class Initialized
INFO - 2018-03-31 19:29:09 --> Model Class Initialized
INFO - 2018-03-31 19:29:09 --> Model Class Initialized
INFO - 2018-03-31 19:29:09 --> Model Class Initialized
DEBUG - 2018-03-31 19:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:29:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:29:10 --> Final output sent to browser
DEBUG - 2018-03-31 19:29:10 --> Total execution time: 0.2476
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
INFO - 2018-03-31 19:29:10 --> Loader Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:29:10 --> Helper loaded: url_helper
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> Helper loaded: form_helper
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Config Class Initialized
INFO - 2018-03-31 19:29:10 --> Hooks Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
DEBUG - 2018-03-31 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:29:10 --> Utf8 Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> URI Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
INFO - 2018-03-31 19:29:10 --> Database Driver Class Initialized
INFO - 2018-03-31 19:29:10 --> Router Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Output Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
INFO - 2018-03-31 19:29:10 --> Security Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:29:10 --> Input Class Initialized
INFO - 2018-03-31 19:29:10 --> Language Class Initialized
ERROR - 2018-03-31 19:29:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:29:10 --> Form Validation Class Initialized
INFO - 2018-03-31 19:29:10 --> Model Class Initialized
INFO - 2018-03-31 19:29:10 --> Controller Class Initialized
INFO - 2018-03-31 19:29:10 --> Model Class Initialized
INFO - 2018-03-31 19:29:10 --> Model Class Initialized
INFO - 2018-03-31 19:29:10 --> Model Class Initialized
INFO - 2018-03-31 19:29:10 --> Model Class Initialized
DEBUG - 2018-03-31 19:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:33:44 --> Config Class Initialized
INFO - 2018-03-31 19:33:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:44 --> URI Class Initialized
INFO - 2018-03-31 19:33:44 --> Router Class Initialized
INFO - 2018-03-31 19:33:44 --> Output Class Initialized
INFO - 2018-03-31 19:33:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:44 --> Input Class Initialized
INFO - 2018-03-31 19:33:44 --> Language Class Initialized
INFO - 2018-03-31 19:33:44 --> Loader Class Initialized
INFO - 2018-03-31 19:33:44 --> Helper loaded: url_helper
INFO - 2018-03-31 19:33:44 --> Helper loaded: form_helper
INFO - 2018-03-31 19:33:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:33:44 --> Form Validation Class Initialized
INFO - 2018-03-31 19:33:44 --> Model Class Initialized
INFO - 2018-03-31 19:33:44 --> Controller Class Initialized
INFO - 2018-03-31 19:33:44 --> Model Class Initialized
INFO - 2018-03-31 19:33:44 --> Model Class Initialized
INFO - 2018-03-31 19:33:44 --> Model Class Initialized
INFO - 2018-03-31 19:33:44 --> Model Class Initialized
DEBUG - 2018-03-31 19:33:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:33:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:33:44 --> Final output sent to browser
DEBUG - 2018-03-31 19:33:44 --> Total execution time: 0.2652
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Config Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
DEBUG - 2018-03-31 19:33:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> URI Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Router Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Output Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
INFO - 2018-03-31 19:33:45 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:45 --> Input Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
INFO - 2018-03-31 19:33:45 --> Language Class Initialized
ERROR - 2018-03-31 19:33:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:33:45 --> Loader Class Initialized
INFO - 2018-03-31 19:33:45 --> Helper loaded: url_helper
INFO - 2018-03-31 19:33:45 --> Helper loaded: form_helper
INFO - 2018-03-31 19:33:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:33:45 --> Form Validation Class Initialized
INFO - 2018-03-31 19:33:45 --> Model Class Initialized
INFO - 2018-03-31 19:33:45 --> Controller Class Initialized
INFO - 2018-03-31 19:33:45 --> Model Class Initialized
INFO - 2018-03-31 19:33:45 --> Model Class Initialized
INFO - 2018-03-31 19:33:45 --> Model Class Initialized
INFO - 2018-03-31 19:33:45 --> Model Class Initialized
DEBUG - 2018-03-31 19:33:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
INFO - 2018-03-31 19:33:57 --> Loader Class Initialized
INFO - 2018-03-31 19:33:57 --> Helper loaded: url_helper
INFO - 2018-03-31 19:33:57 --> Helper loaded: form_helper
INFO - 2018-03-31 19:33:57 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:33:57 --> Form Validation Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Controller Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:33:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:33:57 --> Final output sent to browser
DEBUG - 2018-03-31 19:33:57 --> Total execution time: 0.2413
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Loader Class Initialized
INFO - 2018-03-31 19:33:57 --> Config Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
INFO - 2018-03-31 19:33:57 --> Hooks Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Helper loaded: url_helper
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Utf8 Class Initialized
INFO - 2018-03-31 19:33:57 --> Helper loaded: form_helper
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
INFO - 2018-03-31 19:33:57 --> URI Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:33:57 --> Router Class Initialized
INFO - 2018-03-31 19:33:57 --> Output Class Initialized
INFO - 2018-03-31 19:33:57 --> Database Driver Class Initialized
INFO - 2018-03-31 19:33:57 --> Security Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:33:57 --> Input Class Initialized
INFO - 2018-03-31 19:33:57 --> Language Class Initialized
ERROR - 2018-03-31 19:33:57 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:33:57 --> Form Validation Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Controller Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
INFO - 2018-03-31 19:33:57 --> Model Class Initialized
DEBUG - 2018-03-31 19:33:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:34:49 --> Config Class Initialized
INFO - 2018-03-31 19:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:34:49 --> Utf8 Class Initialized
INFO - 2018-03-31 19:34:49 --> URI Class Initialized
INFO - 2018-03-31 19:34:49 --> Router Class Initialized
INFO - 2018-03-31 19:34:49 --> Output Class Initialized
INFO - 2018-03-31 19:34:49 --> Security Class Initialized
DEBUG - 2018-03-31 19:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:34:49 --> Input Class Initialized
INFO - 2018-03-31 19:34:49 --> Language Class Initialized
INFO - 2018-03-31 19:34:49 --> Loader Class Initialized
INFO - 2018-03-31 19:34:49 --> Helper loaded: url_helper
INFO - 2018-03-31 19:34:49 --> Helper loaded: form_helper
INFO - 2018-03-31 19:34:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:34:49 --> Form Validation Class Initialized
INFO - 2018-03-31 19:34:49 --> Model Class Initialized
INFO - 2018-03-31 19:34:49 --> Controller Class Initialized
INFO - 2018-03-31 19:34:49 --> Model Class Initialized
INFO - 2018-03-31 19:34:49 --> Model Class Initialized
INFO - 2018-03-31 19:34:49 --> Model Class Initialized
INFO - 2018-03-31 19:34:49 --> Model Class Initialized
DEBUG - 2018-03-31 19:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:34:59 --> Config Class Initialized
INFO - 2018-03-31 19:34:59 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:34:59 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:34:59 --> Utf8 Class Initialized
INFO - 2018-03-31 19:34:59 --> URI Class Initialized
INFO - 2018-03-31 19:34:59 --> Router Class Initialized
INFO - 2018-03-31 19:34:59 --> Output Class Initialized
INFO - 2018-03-31 19:34:59 --> Security Class Initialized
DEBUG - 2018-03-31 19:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:34:59 --> Input Class Initialized
INFO - 2018-03-31 19:34:59 --> Language Class Initialized
INFO - 2018-03-31 19:34:59 --> Loader Class Initialized
INFO - 2018-03-31 19:34:59 --> Helper loaded: url_helper
INFO - 2018-03-31 19:34:59 --> Helper loaded: form_helper
INFO - 2018-03-31 19:34:59 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:34:59 --> Form Validation Class Initialized
INFO - 2018-03-31 19:34:59 --> Model Class Initialized
INFO - 2018-03-31 19:34:59 --> Controller Class Initialized
INFO - 2018-03-31 19:34:59 --> Model Class Initialized
INFO - 2018-03-31 19:34:59 --> Model Class Initialized
INFO - 2018-03-31 19:34:59 --> Model Class Initialized
INFO - 2018-03-31 19:34:59 --> Model Class Initialized
DEBUG - 2018-03-31 19:34:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:36:43 --> Config Class Initialized
INFO - 2018-03-31 19:36:43 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:43 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:43 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:43 --> URI Class Initialized
INFO - 2018-03-31 19:36:43 --> Router Class Initialized
INFO - 2018-03-31 19:36:43 --> Output Class Initialized
INFO - 2018-03-31 19:36:43 --> Security Class Initialized
DEBUG - 2018-03-31 19:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:43 --> Input Class Initialized
INFO - 2018-03-31 19:36:43 --> Language Class Initialized
INFO - 2018-03-31 19:36:43 --> Loader Class Initialized
INFO - 2018-03-31 19:36:43 --> Helper loaded: url_helper
INFO - 2018-03-31 19:36:43 --> Helper loaded: form_helper
INFO - 2018-03-31 19:36:43 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:36:43 --> Form Validation Class Initialized
INFO - 2018-03-31 19:36:43 --> Model Class Initialized
INFO - 2018-03-31 19:36:43 --> Controller Class Initialized
INFO - 2018-03-31 19:36:43 --> Model Class Initialized
INFO - 2018-03-31 19:36:43 --> Model Class Initialized
INFO - 2018-03-31 19:36:43 --> Model Class Initialized
INFO - 2018-03-31 19:36:43 --> Model Class Initialized
DEBUG - 2018-03-31 19:36:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:36:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:36:43 --> Final output sent to browser
DEBUG - 2018-03-31 19:36:43 --> Total execution time: 0.2734
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Loader Class Initialized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
INFO - 2018-03-31 19:36:44 --> Helper loaded: url_helper
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:36:44 --> Helper loaded: form_helper
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Config Class Initialized
INFO - 2018-03-31 19:36:44 --> Hooks Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
INFO - 2018-03-31 19:36:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
DEBUG - 2018-03-31 19:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:36:44 --> Utf8 Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:36:44 --> URI Class Initialized
INFO - 2018-03-31 19:36:44 --> Router Class Initialized
INFO - 2018-03-31 19:36:44 --> Output Class Initialized
INFO - 2018-03-31 19:36:44 --> Security Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:36:44 --> Input Class Initialized
INFO - 2018-03-31 19:36:44 --> Language Class Initialized
ERROR - 2018-03-31 19:36:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:36:44 --> Form Validation Class Initialized
INFO - 2018-03-31 19:36:44 --> Model Class Initialized
INFO - 2018-03-31 19:36:44 --> Controller Class Initialized
INFO - 2018-03-31 19:36:44 --> Model Class Initialized
INFO - 2018-03-31 19:36:44 --> Model Class Initialized
INFO - 2018-03-31 19:36:44 --> Model Class Initialized
INFO - 2018-03-31 19:36:44 --> Model Class Initialized
DEBUG - 2018-03-31 19:36:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:37:37 --> Config Class Initialized
INFO - 2018-03-31 19:37:37 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:37 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:37 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:37 --> URI Class Initialized
INFO - 2018-03-31 19:37:37 --> Router Class Initialized
INFO - 2018-03-31 19:37:37 --> Output Class Initialized
INFO - 2018-03-31 19:37:37 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:37 --> Input Class Initialized
INFO - 2018-03-31 19:37:37 --> Language Class Initialized
INFO - 2018-03-31 19:37:37 --> Loader Class Initialized
INFO - 2018-03-31 19:37:37 --> Helper loaded: url_helper
INFO - 2018-03-31 19:37:37 --> Helper loaded: form_helper
INFO - 2018-03-31 19:37:37 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:37:37 --> Form Validation Class Initialized
INFO - 2018-03-31 19:37:37 --> Model Class Initialized
INFO - 2018-03-31 19:37:37 --> Controller Class Initialized
INFO - 2018-03-31 19:37:37 --> Model Class Initialized
INFO - 2018-03-31 19:37:37 --> Model Class Initialized
INFO - 2018-03-31 19:37:37 --> Model Class Initialized
INFO - 2018-03-31 19:37:37 --> Model Class Initialized
DEBUG - 2018-03-31 19:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:37:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:37:38 --> Final output sent to browser
DEBUG - 2018-03-31 19:37:38 --> Total execution time: 0.2492
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Loader Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Helper loaded: url_helper
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
INFO - 2018-03-31 19:37:38 --> Helper loaded: form_helper
INFO - 2018-03-31 19:37:38 --> Config Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
INFO - 2018-03-31 19:37:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
DEBUG - 2018-03-31 19:37:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:37:38 --> Utf8 Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:37:38 --> URI Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Database Driver Class Initialized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
INFO - 2018-03-31 19:37:38 --> Router Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:37:38 --> Output Class Initialized
INFO - 2018-03-31 19:37:38 --> Security Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:37:38 --> Input Class Initialized
INFO - 2018-03-31 19:37:38 --> Language Class Initialized
ERROR - 2018-03-31 19:37:38 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:37:38 --> Form Validation Class Initialized
INFO - 2018-03-31 19:37:38 --> Model Class Initialized
INFO - 2018-03-31 19:37:38 --> Controller Class Initialized
INFO - 2018-03-31 19:37:38 --> Model Class Initialized
INFO - 2018-03-31 19:37:38 --> Model Class Initialized
INFO - 2018-03-31 19:37:38 --> Model Class Initialized
INFO - 2018-03-31 19:37:38 --> Model Class Initialized
DEBUG - 2018-03-31 19:37:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:38:41 --> Config Class Initialized
INFO - 2018-03-31 19:38:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:38:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:38:41 --> Utf8 Class Initialized
INFO - 2018-03-31 19:38:41 --> URI Class Initialized
INFO - 2018-03-31 19:38:41 --> Router Class Initialized
INFO - 2018-03-31 19:38:41 --> Output Class Initialized
INFO - 2018-03-31 19:38:41 --> Security Class Initialized
DEBUG - 2018-03-31 19:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:38:41 --> Input Class Initialized
INFO - 2018-03-31 19:38:41 --> Language Class Initialized
INFO - 2018-03-31 19:38:41 --> Loader Class Initialized
INFO - 2018-03-31 19:38:41 --> Helper loaded: url_helper
INFO - 2018-03-31 19:38:41 --> Helper loaded: form_helper
INFO - 2018-03-31 19:38:41 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:38:42 --> Form Validation Class Initialized
INFO - 2018-03-31 19:38:42 --> Model Class Initialized
INFO - 2018-03-31 19:38:42 --> Controller Class Initialized
INFO - 2018-03-31 19:38:42 --> Model Class Initialized
INFO - 2018-03-31 19:38:42 --> Model Class Initialized
INFO - 2018-03-31 19:38:42 --> Model Class Initialized
INFO - 2018-03-31 19:38:42 --> Model Class Initialized
DEBUG - 2018-03-31 19:38:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 19:38:42 --> Severity: Notice --> Undefined index: fecha_entrega_estimada D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1869
INFO - 2018-03-31 19:38:59 --> Config Class Initialized
INFO - 2018-03-31 19:38:59 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:38:59 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:38:59 --> Utf8 Class Initialized
INFO - 2018-03-31 19:38:59 --> URI Class Initialized
INFO - 2018-03-31 19:38:59 --> Router Class Initialized
INFO - 2018-03-31 19:38:59 --> Output Class Initialized
INFO - 2018-03-31 19:38:59 --> Security Class Initialized
DEBUG - 2018-03-31 19:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:38:59 --> Input Class Initialized
INFO - 2018-03-31 19:38:59 --> Language Class Initialized
INFO - 2018-03-31 19:38:59 --> Loader Class Initialized
INFO - 2018-03-31 19:38:59 --> Helper loaded: url_helper
INFO - 2018-03-31 19:38:59 --> Helper loaded: form_helper
INFO - 2018-03-31 19:38:59 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:38:59 --> Form Validation Class Initialized
INFO - 2018-03-31 19:38:59 --> Model Class Initialized
INFO - 2018-03-31 19:38:59 --> Controller Class Initialized
INFO - 2018-03-31 19:38:59 --> Model Class Initialized
INFO - 2018-03-31 19:38:59 --> Model Class Initialized
INFO - 2018-03-31 19:38:59 --> Model Class Initialized
INFO - 2018-03-31 19:38:59 --> Model Class Initialized
DEBUG - 2018-03-31 19:38:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:39:21 --> Config Class Initialized
INFO - 2018-03-31 19:39:21 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:39:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:39:21 --> Utf8 Class Initialized
INFO - 2018-03-31 19:39:21 --> URI Class Initialized
INFO - 2018-03-31 19:39:21 --> Router Class Initialized
INFO - 2018-03-31 19:39:21 --> Output Class Initialized
INFO - 2018-03-31 19:39:21 --> Security Class Initialized
DEBUG - 2018-03-31 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:39:21 --> Input Class Initialized
INFO - 2018-03-31 19:39:21 --> Language Class Initialized
INFO - 2018-03-31 19:39:21 --> Loader Class Initialized
INFO - 2018-03-31 19:39:21 --> Helper loaded: url_helper
INFO - 2018-03-31 19:39:21 --> Helper loaded: form_helper
INFO - 2018-03-31 19:39:21 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:39:21 --> Form Validation Class Initialized
INFO - 2018-03-31 19:39:21 --> Model Class Initialized
INFO - 2018-03-31 19:39:21 --> Controller Class Initialized
INFO - 2018-03-31 19:39:21 --> Model Class Initialized
INFO - 2018-03-31 19:39:21 --> Model Class Initialized
INFO - 2018-03-31 19:39:21 --> Model Class Initialized
INFO - 2018-03-31 19:39:21 --> Model Class Initialized
DEBUG - 2018-03-31 19:39:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 19:39:22 --> Severity: Notice --> Undefined index: fecha_entrega_estimada D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1869
INFO - 2018-03-31 19:40:05 --> Config Class Initialized
INFO - 2018-03-31 19:40:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:05 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:05 --> URI Class Initialized
INFO - 2018-03-31 19:40:05 --> Router Class Initialized
INFO - 2018-03-31 19:40:05 --> Output Class Initialized
INFO - 2018-03-31 19:40:05 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:05 --> Input Class Initialized
INFO - 2018-03-31 19:40:05 --> Language Class Initialized
INFO - 2018-03-31 19:40:05 --> Loader Class Initialized
INFO - 2018-03-31 19:40:05 --> Helper loaded: url_helper
INFO - 2018-03-31 19:40:05 --> Helper loaded: form_helper
INFO - 2018-03-31 19:40:05 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:40:05 --> Form Validation Class Initialized
INFO - 2018-03-31 19:40:05 --> Model Class Initialized
INFO - 2018-03-31 19:40:05 --> Controller Class Initialized
INFO - 2018-03-31 19:40:05 --> Model Class Initialized
INFO - 2018-03-31 19:40:05 --> Model Class Initialized
INFO - 2018-03-31 19:40:05 --> Model Class Initialized
INFO - 2018-03-31 19:40:05 --> Model Class Initialized
DEBUG - 2018-03-31 19:40:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
INFO - 2018-03-31 19:40:25 --> Loader Class Initialized
INFO - 2018-03-31 19:40:25 --> Helper loaded: url_helper
INFO - 2018-03-31 19:40:25 --> Helper loaded: form_helper
INFO - 2018-03-31 19:40:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:40:25 --> Form Validation Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Controller Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:40:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:40:25 --> Final output sent to browser
DEBUG - 2018-03-31 19:40:25 --> Total execution time: 0.2363
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
INFO - 2018-03-31 19:40:25 --> Config Class Initialized
INFO - 2018-03-31 19:40:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:25 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:25 --> URI Class Initialized
INFO - 2018-03-31 19:40:25 --> Loader Class Initialized
INFO - 2018-03-31 19:40:25 --> Router Class Initialized
INFO - 2018-03-31 19:40:25 --> Helper loaded: url_helper
INFO - 2018-03-31 19:40:25 --> Output Class Initialized
INFO - 2018-03-31 19:40:25 --> Security Class Initialized
INFO - 2018-03-31 19:40:25 --> Helper loaded: form_helper
DEBUG - 2018-03-31 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:25 --> Input Class Initialized
INFO - 2018-03-31 19:40:25 --> Language Class Initialized
ERROR - 2018-03-31 19:40:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:40:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:40:25 --> Form Validation Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Controller Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
INFO - 2018-03-31 19:40:25 --> Model Class Initialized
DEBUG - 2018-03-31 19:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:40:41 --> Config Class Initialized
INFO - 2018-03-31 19:40:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:41 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:41 --> URI Class Initialized
INFO - 2018-03-31 19:40:41 --> Router Class Initialized
INFO - 2018-03-31 19:40:41 --> Output Class Initialized
INFO - 2018-03-31 19:40:41 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:41 --> Input Class Initialized
INFO - 2018-03-31 19:40:41 --> Language Class Initialized
INFO - 2018-03-31 19:40:41 --> Loader Class Initialized
INFO - 2018-03-31 19:40:41 --> Helper loaded: url_helper
INFO - 2018-03-31 19:40:41 --> Helper loaded: form_helper
INFO - 2018-03-31 19:40:41 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:40:41 --> Form Validation Class Initialized
INFO - 2018-03-31 19:40:41 --> Model Class Initialized
INFO - 2018-03-31 19:40:41 --> Controller Class Initialized
INFO - 2018-03-31 19:40:41 --> Model Class Initialized
INFO - 2018-03-31 19:40:41 --> Model Class Initialized
INFO - 2018-03-31 19:40:41 --> Model Class Initialized
INFO - 2018-03-31 19:40:41 --> Model Class Initialized
DEBUG - 2018-03-31 19:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:40:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:40:42 --> Final output sent to browser
DEBUG - 2018-03-31 19:40:42 --> Total execution time: 0.2568
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
INFO - 2018-03-31 19:40:42 --> Loader Class Initialized
INFO - 2018-03-31 19:40:42 --> Helper loaded: url_helper
INFO - 2018-03-31 19:40:42 --> Helper loaded: form_helper
INFO - 2018-03-31 19:40:42 --> Database Driver Class Initialized
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 19:40:42 --> Config Class Initialized
INFO - 2018-03-31 19:40:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:40:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:40:42 --> Utf8 Class Initialized
INFO - 2018-03-31 19:40:42 --> URI Class Initialized
INFO - 2018-03-31 19:40:42 --> Router Class Initialized
INFO - 2018-03-31 19:40:42 --> Output Class Initialized
INFO - 2018-03-31 19:40:42 --> Security Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:40:42 --> Input Class Initialized
INFO - 2018-03-31 19:40:42 --> Language Class Initialized
ERROR - 2018-03-31 19:40:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 19:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:40:42 --> Form Validation Class Initialized
INFO - 2018-03-31 19:40:42 --> Model Class Initialized
INFO - 2018-03-31 19:40:42 --> Controller Class Initialized
INFO - 2018-03-31 19:40:42 --> Model Class Initialized
INFO - 2018-03-31 19:40:42 --> Model Class Initialized
INFO - 2018-03-31 19:40:42 --> Model Class Initialized
INFO - 2018-03-31 19:40:42 --> Model Class Initialized
DEBUG - 2018-03-31 19:40:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:13 --> Config Class Initialized
INFO - 2018-03-31 19:42:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:13 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:13 --> URI Class Initialized
INFO - 2018-03-31 19:42:13 --> Router Class Initialized
INFO - 2018-03-31 19:42:13 --> Output Class Initialized
INFO - 2018-03-31 19:42:13 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:13 --> Input Class Initialized
INFO - 2018-03-31 19:42:13 --> Language Class Initialized
INFO - 2018-03-31 19:42:13 --> Loader Class Initialized
INFO - 2018-03-31 19:42:13 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:13 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:13 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:13 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:13 --> Model Class Initialized
INFO - 2018-03-31 19:42:13 --> Controller Class Initialized
INFO - 2018-03-31 19:42:13 --> Model Class Initialized
INFO - 2018-03-31 19:42:13 --> Model Class Initialized
INFO - 2018-03-31 19:42:13 --> Model Class Initialized
INFO - 2018-03-31 19:42:13 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:17 --> Config Class Initialized
INFO - 2018-03-31 19:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:17 --> URI Class Initialized
INFO - 2018-03-31 19:42:17 --> Router Class Initialized
INFO - 2018-03-31 19:42:17 --> Output Class Initialized
INFO - 2018-03-31 19:42:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:17 --> Input Class Initialized
INFO - 2018-03-31 19:42:17 --> Language Class Initialized
INFO - 2018-03-31 19:42:17 --> Loader Class Initialized
INFO - 2018-03-31 19:42:17 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:17 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:17 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:17 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:17 --> Model Class Initialized
INFO - 2018-03-31 19:42:17 --> Controller Class Initialized
INFO - 2018-03-31 19:42:17 --> Model Class Initialized
INFO - 2018-03-31 19:42:17 --> Model Class Initialized
INFO - 2018-03-31 19:42:17 --> Model Class Initialized
INFO - 2018-03-31 19:42:17 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:22 --> Config Class Initialized
INFO - 2018-03-31 19:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:22 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:22 --> URI Class Initialized
INFO - 2018-03-31 19:42:22 --> Router Class Initialized
INFO - 2018-03-31 19:42:22 --> Output Class Initialized
INFO - 2018-03-31 19:42:22 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:22 --> Input Class Initialized
INFO - 2018-03-31 19:42:22 --> Language Class Initialized
INFO - 2018-03-31 19:42:22 --> Loader Class Initialized
INFO - 2018-03-31 19:42:22 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:22 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:22 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:22 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
INFO - 2018-03-31 19:42:22 --> Controller Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
INFO - 2018-03-31 19:42:22 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:23 --> Final output sent to browser
DEBUG - 2018-03-31 19:42:23 --> Total execution time: 0.2962
INFO - 2018-03-31 19:42:23 --> Config Class Initialized
INFO - 2018-03-31 19:42:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:23 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:23 --> URI Class Initialized
INFO - 2018-03-31 19:42:23 --> Router Class Initialized
INFO - 2018-03-31 19:42:23 --> Output Class Initialized
INFO - 2018-03-31 19:42:23 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:23 --> Input Class Initialized
INFO - 2018-03-31 19:42:23 --> Language Class Initialized
INFO - 2018-03-31 19:42:23 --> Loader Class Initialized
INFO - 2018-03-31 19:42:23 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:23 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:23 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
INFO - 2018-03-31 19:42:23 --> Controller Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
INFO - 2018-03-31 19:42:23 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:24 --> Config Class Initialized
INFO - 2018-03-31 19:42:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:24 --> URI Class Initialized
INFO - 2018-03-31 19:42:24 --> Router Class Initialized
INFO - 2018-03-31 19:42:24 --> Output Class Initialized
INFO - 2018-03-31 19:42:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:24 --> Input Class Initialized
INFO - 2018-03-31 19:42:24 --> Language Class Initialized
INFO - 2018-03-31 19:42:24 --> Loader Class Initialized
INFO - 2018-03-31 19:42:24 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:24 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:24 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:24 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:24 --> Model Class Initialized
INFO - 2018-03-31 19:42:24 --> Controller Class Initialized
INFO - 2018-03-31 19:42:24 --> Model Class Initialized
INFO - 2018-03-31 19:42:24 --> Model Class Initialized
INFO - 2018-03-31 19:42:24 --> Model Class Initialized
INFO - 2018-03-31 19:42:24 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:28 --> Config Class Initialized
INFO - 2018-03-31 19:42:28 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:28 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:28 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:28 --> URI Class Initialized
INFO - 2018-03-31 19:42:28 --> Router Class Initialized
INFO - 2018-03-31 19:42:28 --> Output Class Initialized
INFO - 2018-03-31 19:42:28 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:28 --> Input Class Initialized
INFO - 2018-03-31 19:42:28 --> Language Class Initialized
INFO - 2018-03-31 19:42:28 --> Loader Class Initialized
INFO - 2018-03-31 19:42:28 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:28 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:28 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:28 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
INFO - 2018-03-31 19:42:28 --> Controller Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
INFO - 2018-03-31 19:42:28 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:30 --> Config Class Initialized
INFO - 2018-03-31 19:42:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:30 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:30 --> URI Class Initialized
INFO - 2018-03-31 19:42:30 --> Router Class Initialized
INFO - 2018-03-31 19:42:30 --> Output Class Initialized
INFO - 2018-03-31 19:42:30 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:30 --> Input Class Initialized
INFO - 2018-03-31 19:42:30 --> Language Class Initialized
INFO - 2018-03-31 19:42:30 --> Loader Class Initialized
INFO - 2018-03-31 19:42:31 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:31 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:31 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:31 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
INFO - 2018-03-31 19:42:31 --> Controller Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
INFO - 2018-03-31 19:42:31 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:42:32 --> Config Class Initialized
INFO - 2018-03-31 19:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:42:32 --> Utf8 Class Initialized
INFO - 2018-03-31 19:42:32 --> URI Class Initialized
INFO - 2018-03-31 19:42:32 --> Router Class Initialized
INFO - 2018-03-31 19:42:32 --> Output Class Initialized
INFO - 2018-03-31 19:42:32 --> Security Class Initialized
DEBUG - 2018-03-31 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:42:32 --> Input Class Initialized
INFO - 2018-03-31 19:42:32 --> Language Class Initialized
INFO - 2018-03-31 19:42:32 --> Loader Class Initialized
INFO - 2018-03-31 19:42:32 --> Helper loaded: url_helper
INFO - 2018-03-31 19:42:32 --> Helper loaded: form_helper
INFO - 2018-03-31 19:42:32 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:42:32 --> Form Validation Class Initialized
INFO - 2018-03-31 19:42:32 --> Model Class Initialized
INFO - 2018-03-31 19:42:32 --> Controller Class Initialized
INFO - 2018-03-31 19:42:32 --> Model Class Initialized
INFO - 2018-03-31 19:42:32 --> Model Class Initialized
INFO - 2018-03-31 19:42:32 --> Model Class Initialized
INFO - 2018-03-31 19:42:32 --> Model Class Initialized
DEBUG - 2018-03-31 19:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:44:14 --> Config Class Initialized
INFO - 2018-03-31 19:44:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:44:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:44:14 --> Utf8 Class Initialized
INFO - 2018-03-31 19:44:14 --> URI Class Initialized
INFO - 2018-03-31 19:44:14 --> Router Class Initialized
INFO - 2018-03-31 19:44:14 --> Output Class Initialized
INFO - 2018-03-31 19:44:14 --> Security Class Initialized
DEBUG - 2018-03-31 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:44:14 --> Input Class Initialized
INFO - 2018-03-31 19:44:14 --> Language Class Initialized
INFO - 2018-03-31 19:44:14 --> Loader Class Initialized
INFO - 2018-03-31 19:44:14 --> Helper loaded: url_helper
INFO - 2018-03-31 19:44:14 --> Helper loaded: form_helper
INFO - 2018-03-31 19:44:14 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:44:14 --> Form Validation Class Initialized
INFO - 2018-03-31 19:44:14 --> Model Class Initialized
INFO - 2018-03-31 19:44:14 --> Controller Class Initialized
INFO - 2018-03-31 19:44:14 --> Model Class Initialized
INFO - 2018-03-31 19:44:14 --> Model Class Initialized
INFO - 2018-03-31 19:44:14 --> Model Class Initialized
INFO - 2018-03-31 19:44:14 --> Model Class Initialized
DEBUG - 2018-03-31 19:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:44:17 --> Config Class Initialized
INFO - 2018-03-31 19:44:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:44:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:44:17 --> Utf8 Class Initialized
INFO - 2018-03-31 19:44:17 --> URI Class Initialized
INFO - 2018-03-31 19:44:17 --> Router Class Initialized
INFO - 2018-03-31 19:44:17 --> Output Class Initialized
INFO - 2018-03-31 19:44:17 --> Security Class Initialized
DEBUG - 2018-03-31 19:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:44:17 --> Input Class Initialized
INFO - 2018-03-31 19:44:17 --> Language Class Initialized
INFO - 2018-03-31 19:44:17 --> Loader Class Initialized
INFO - 2018-03-31 19:44:17 --> Helper loaded: url_helper
INFO - 2018-03-31 19:44:17 --> Helper loaded: form_helper
INFO - 2018-03-31 19:44:17 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:44:17 --> Form Validation Class Initialized
INFO - 2018-03-31 19:44:17 --> Model Class Initialized
INFO - 2018-03-31 19:44:17 --> Controller Class Initialized
INFO - 2018-03-31 19:44:17 --> Model Class Initialized
INFO - 2018-03-31 19:44:17 --> Model Class Initialized
INFO - 2018-03-31 19:44:17 --> Model Class Initialized
INFO - 2018-03-31 19:44:17 --> Model Class Initialized
DEBUG - 2018-03-31 19:44:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:44:20 --> Config Class Initialized
INFO - 2018-03-31 19:44:20 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:44:20 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:44:20 --> Utf8 Class Initialized
INFO - 2018-03-31 19:44:20 --> URI Class Initialized
INFO - 2018-03-31 19:44:20 --> Router Class Initialized
INFO - 2018-03-31 19:44:20 --> Output Class Initialized
INFO - 2018-03-31 19:44:20 --> Security Class Initialized
DEBUG - 2018-03-31 19:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:44:20 --> Input Class Initialized
INFO - 2018-03-31 19:44:20 --> Language Class Initialized
INFO - 2018-03-31 19:44:20 --> Loader Class Initialized
INFO - 2018-03-31 19:44:20 --> Helper loaded: url_helper
INFO - 2018-03-31 19:44:20 --> Helper loaded: form_helper
INFO - 2018-03-31 19:44:20 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:44:20 --> Form Validation Class Initialized
INFO - 2018-03-31 19:44:20 --> Model Class Initialized
INFO - 2018-03-31 19:44:20 --> Controller Class Initialized
INFO - 2018-03-31 19:44:20 --> Model Class Initialized
INFO - 2018-03-31 19:44:20 --> Model Class Initialized
INFO - 2018-03-31 19:44:20 --> Model Class Initialized
INFO - 2018-03-31 19:44:20 --> Model Class Initialized
DEBUG - 2018-03-31 19:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:51:15 --> Config Class Initialized
INFO - 2018-03-31 19:51:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:51:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:51:15 --> Utf8 Class Initialized
INFO - 2018-03-31 19:51:15 --> URI Class Initialized
INFO - 2018-03-31 19:51:15 --> Router Class Initialized
INFO - 2018-03-31 19:51:15 --> Output Class Initialized
INFO - 2018-03-31 19:51:15 --> Security Class Initialized
DEBUG - 2018-03-31 19:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:51:15 --> Input Class Initialized
INFO - 2018-03-31 19:51:15 --> Language Class Initialized
INFO - 2018-03-31 19:51:15 --> Loader Class Initialized
INFO - 2018-03-31 19:51:15 --> Helper loaded: url_helper
INFO - 2018-03-31 19:51:15 --> Helper loaded: form_helper
INFO - 2018-03-31 19:51:15 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:51:15 --> Form Validation Class Initialized
INFO - 2018-03-31 19:51:15 --> Model Class Initialized
INFO - 2018-03-31 19:51:15 --> Controller Class Initialized
INFO - 2018-03-31 19:51:15 --> Model Class Initialized
INFO - 2018-03-31 19:51:15 --> Model Class Initialized
INFO - 2018-03-31 19:51:15 --> Model Class Initialized
INFO - 2018-03-31 19:51:15 --> Model Class Initialized
DEBUG - 2018-03-31 19:51:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:51:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:51:15 --> Final output sent to browser
DEBUG - 2018-03-31 19:51:15 --> Total execution time: 0.2387
INFO - 2018-03-31 19:51:15 --> Config Class Initialized
INFO - 2018-03-31 19:51:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:51:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:51:15 --> Utf8 Class Initialized
INFO - 2018-03-31 19:51:15 --> URI Class Initialized
INFO - 2018-03-31 19:51:15 --> Router Class Initialized
INFO - 2018-03-31 19:51:15 --> Output Class Initialized
INFO - 2018-03-31 19:51:15 --> Security Class Initialized
DEBUG - 2018-03-31 19:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:51:15 --> Input Class Initialized
INFO - 2018-03-31 19:51:15 --> Language Class Initialized
INFO - 2018-03-31 19:51:15 --> Loader Class Initialized
INFO - 2018-03-31 19:51:15 --> Helper loaded: url_helper
INFO - 2018-03-31 19:51:15 --> Helper loaded: form_helper
INFO - 2018-03-31 19:51:15 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:51:16 --> Form Validation Class Initialized
INFO - 2018-03-31 19:51:16 --> Model Class Initialized
INFO - 2018-03-31 19:51:16 --> Controller Class Initialized
INFO - 2018-03-31 19:51:16 --> Model Class Initialized
INFO - 2018-03-31 19:51:16 --> Model Class Initialized
INFO - 2018-03-31 19:51:16 --> Model Class Initialized
INFO - 2018-03-31 19:51:16 --> Model Class Initialized
DEBUG - 2018-03-31 19:51:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:58:36 --> Config Class Initialized
INFO - 2018-03-31 19:58:36 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:58:36 --> Utf8 Class Initialized
INFO - 2018-03-31 19:58:36 --> URI Class Initialized
INFO - 2018-03-31 19:58:36 --> Router Class Initialized
INFO - 2018-03-31 19:58:36 --> Output Class Initialized
INFO - 2018-03-31 19:58:36 --> Security Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:58:36 --> Input Class Initialized
INFO - 2018-03-31 19:58:36 --> Language Class Initialized
INFO - 2018-03-31 19:58:36 --> Loader Class Initialized
INFO - 2018-03-31 19:58:36 --> Helper loaded: url_helper
INFO - 2018-03-31 19:58:36 --> Helper loaded: form_helper
INFO - 2018-03-31 19:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:58:36 --> Form Validation Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Controller Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:58:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:58:36 --> Final output sent to browser
DEBUG - 2018-03-31 19:58:36 --> Total execution time: 0.2232
INFO - 2018-03-31 19:58:36 --> Config Class Initialized
INFO - 2018-03-31 19:58:36 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:58:36 --> Utf8 Class Initialized
INFO - 2018-03-31 19:58:36 --> URI Class Initialized
INFO - 2018-03-31 19:58:36 --> Router Class Initialized
INFO - 2018-03-31 19:58:36 --> Output Class Initialized
INFO - 2018-03-31 19:58:36 --> Security Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:58:36 --> Input Class Initialized
INFO - 2018-03-31 19:58:36 --> Language Class Initialized
INFO - 2018-03-31 19:58:36 --> Loader Class Initialized
INFO - 2018-03-31 19:58:36 --> Helper loaded: url_helper
INFO - 2018-03-31 19:58:36 --> Helper loaded: form_helper
INFO - 2018-03-31 19:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:58:36 --> Form Validation Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Controller Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
INFO - 2018-03-31 19:58:36 --> Model Class Initialized
DEBUG - 2018-03-31 19:58:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:59:23 --> Config Class Initialized
INFO - 2018-03-31 19:59:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:59:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:59:23 --> Utf8 Class Initialized
INFO - 2018-03-31 19:59:23 --> URI Class Initialized
INFO - 2018-03-31 19:59:23 --> Router Class Initialized
INFO - 2018-03-31 19:59:23 --> Output Class Initialized
INFO - 2018-03-31 19:59:23 --> Security Class Initialized
DEBUG - 2018-03-31 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:59:23 --> Input Class Initialized
INFO - 2018-03-31 19:59:23 --> Language Class Initialized
INFO - 2018-03-31 19:59:23 --> Loader Class Initialized
INFO - 2018-03-31 19:59:23 --> Helper loaded: url_helper
INFO - 2018-03-31 19:59:23 --> Helper loaded: form_helper
INFO - 2018-03-31 19:59:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:59:23 --> Form Validation Class Initialized
INFO - 2018-03-31 19:59:23 --> Model Class Initialized
INFO - 2018-03-31 19:59:23 --> Controller Class Initialized
INFO - 2018-03-31 19:59:23 --> Model Class Initialized
INFO - 2018-03-31 19:59:23 --> Model Class Initialized
INFO - 2018-03-31 19:59:23 --> Model Class Initialized
INFO - 2018-03-31 19:59:23 --> Model Class Initialized
DEBUG - 2018-03-31 19:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 19:59:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 19:59:23 --> Final output sent to browser
DEBUG - 2018-03-31 19:59:23 --> Total execution time: 0.2405
INFO - 2018-03-31 19:59:24 --> Config Class Initialized
INFO - 2018-03-31 19:59:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 19:59:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 19:59:24 --> Utf8 Class Initialized
INFO - 2018-03-31 19:59:24 --> URI Class Initialized
INFO - 2018-03-31 19:59:24 --> Router Class Initialized
INFO - 2018-03-31 19:59:24 --> Output Class Initialized
INFO - 2018-03-31 19:59:24 --> Security Class Initialized
DEBUG - 2018-03-31 19:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 19:59:24 --> Input Class Initialized
INFO - 2018-03-31 19:59:24 --> Language Class Initialized
INFO - 2018-03-31 19:59:24 --> Loader Class Initialized
INFO - 2018-03-31 19:59:24 --> Helper loaded: url_helper
INFO - 2018-03-31 19:59:24 --> Helper loaded: form_helper
INFO - 2018-03-31 19:59:24 --> Database Driver Class Initialized
DEBUG - 2018-03-31 19:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 19:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 19:59:24 --> Form Validation Class Initialized
INFO - 2018-03-31 19:59:24 --> Model Class Initialized
INFO - 2018-03-31 19:59:24 --> Controller Class Initialized
INFO - 2018-03-31 19:59:24 --> Model Class Initialized
INFO - 2018-03-31 19:59:24 --> Model Class Initialized
INFO - 2018-03-31 19:59:24 --> Model Class Initialized
INFO - 2018-03-31 19:59:24 --> Model Class Initialized
DEBUG - 2018-03-31 19:59:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:00:22 --> Config Class Initialized
INFO - 2018-03-31 20:00:22 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:00:22 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:00:22 --> Utf8 Class Initialized
INFO - 2018-03-31 20:00:22 --> URI Class Initialized
INFO - 2018-03-31 20:00:22 --> Router Class Initialized
INFO - 2018-03-31 20:00:22 --> Output Class Initialized
INFO - 2018-03-31 20:00:22 --> Security Class Initialized
DEBUG - 2018-03-31 20:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:00:22 --> Input Class Initialized
INFO - 2018-03-31 20:00:22 --> Language Class Initialized
INFO - 2018-03-31 20:00:22 --> Loader Class Initialized
INFO - 2018-03-31 20:00:22 --> Helper loaded: url_helper
INFO - 2018-03-31 20:00:22 --> Helper loaded: form_helper
INFO - 2018-03-31 20:00:22 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:00:22 --> Form Validation Class Initialized
INFO - 2018-03-31 20:00:22 --> Model Class Initialized
INFO - 2018-03-31 20:00:22 --> Controller Class Initialized
INFO - 2018-03-31 20:00:22 --> Model Class Initialized
INFO - 2018-03-31 20:00:22 --> Model Class Initialized
INFO - 2018-03-31 20:00:22 --> Model Class Initialized
INFO - 2018-03-31 20:00:22 --> Model Class Initialized
DEBUG - 2018-03-31 20:00:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:00:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:00:23 --> Final output sent to browser
DEBUG - 2018-03-31 20:00:23 --> Total execution time: 0.2363
INFO - 2018-03-31 20:00:23 --> Config Class Initialized
INFO - 2018-03-31 20:00:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:00:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:00:23 --> Utf8 Class Initialized
INFO - 2018-03-31 20:00:23 --> URI Class Initialized
INFO - 2018-03-31 20:00:23 --> Router Class Initialized
INFO - 2018-03-31 20:00:23 --> Output Class Initialized
INFO - 2018-03-31 20:00:23 --> Security Class Initialized
DEBUG - 2018-03-31 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:00:23 --> Input Class Initialized
INFO - 2018-03-31 20:00:23 --> Language Class Initialized
INFO - 2018-03-31 20:00:23 --> Loader Class Initialized
INFO - 2018-03-31 20:00:23 --> Helper loaded: url_helper
INFO - 2018-03-31 20:00:23 --> Helper loaded: form_helper
INFO - 2018-03-31 20:00:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:00:23 --> Form Validation Class Initialized
INFO - 2018-03-31 20:00:23 --> Model Class Initialized
INFO - 2018-03-31 20:00:23 --> Controller Class Initialized
INFO - 2018-03-31 20:00:23 --> Model Class Initialized
INFO - 2018-03-31 20:00:23 --> Model Class Initialized
INFO - 2018-03-31 20:00:23 --> Model Class Initialized
INFO - 2018-03-31 20:00:23 --> Model Class Initialized
DEBUG - 2018-03-31 20:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:00:34 --> Config Class Initialized
INFO - 2018-03-31 20:00:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:00:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:00:34 --> Utf8 Class Initialized
INFO - 2018-03-31 20:00:34 --> URI Class Initialized
INFO - 2018-03-31 20:00:34 --> Router Class Initialized
INFO - 2018-03-31 20:00:34 --> Output Class Initialized
INFO - 2018-03-31 20:00:34 --> Security Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:00:34 --> Input Class Initialized
INFO - 2018-03-31 20:00:34 --> Language Class Initialized
INFO - 2018-03-31 20:00:34 --> Loader Class Initialized
INFO - 2018-03-31 20:00:34 --> Helper loaded: url_helper
INFO - 2018-03-31 20:00:34 --> Helper loaded: form_helper
INFO - 2018-03-31 20:00:34 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:00:34 --> Form Validation Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Controller Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:00:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:00:34 --> Final output sent to browser
DEBUG - 2018-03-31 20:00:34 --> Total execution time: 0.2319
INFO - 2018-03-31 20:00:34 --> Config Class Initialized
INFO - 2018-03-31 20:00:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:00:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:00:34 --> Utf8 Class Initialized
INFO - 2018-03-31 20:00:34 --> URI Class Initialized
INFO - 2018-03-31 20:00:34 --> Router Class Initialized
INFO - 2018-03-31 20:00:34 --> Output Class Initialized
INFO - 2018-03-31 20:00:34 --> Security Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:00:34 --> Input Class Initialized
INFO - 2018-03-31 20:00:34 --> Language Class Initialized
INFO - 2018-03-31 20:00:34 --> Loader Class Initialized
INFO - 2018-03-31 20:00:34 --> Helper loaded: url_helper
INFO - 2018-03-31 20:00:34 --> Helper loaded: form_helper
INFO - 2018-03-31 20:00:34 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:00:34 --> Form Validation Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Controller Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:00:34 --> Model Class Initialized
DEBUG - 2018-03-31 20:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> Config Class Initialized
INFO - 2018-03-31 20:01:21 --> Hooks Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:01:21 --> Utf8 Class Initialized
INFO - 2018-03-31 20:01:21 --> URI Class Initialized
INFO - 2018-03-31 20:01:21 --> Router Class Initialized
INFO - 2018-03-31 20:01:21 --> Output Class Initialized
INFO - 2018-03-31 20:01:21 --> Security Class Initialized
DEBUG - 2018-03-31 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:01:21 --> Input Class Initialized
INFO - 2018-03-31 20:01:21 --> Language Class Initialized
ERROR - 2018-03-31 20:01:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:02:11 --> Config Class Initialized
INFO - 2018-03-31 20:02:11 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:11 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:11 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:11 --> URI Class Initialized
INFO - 2018-03-31 20:02:11 --> Router Class Initialized
INFO - 2018-03-31 20:02:11 --> Output Class Initialized
INFO - 2018-03-31 20:02:11 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:11 --> Input Class Initialized
INFO - 2018-03-31 20:02:11 --> Language Class Initialized
INFO - 2018-03-31 20:02:11 --> Loader Class Initialized
INFO - 2018-03-31 20:02:11 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:11 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:11 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:11 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:11 --> Model Class Initialized
INFO - 2018-03-31 20:02:11 --> Controller Class Initialized
INFO - 2018-03-31 20:02:11 --> Model Class Initialized
INFO - 2018-03-31 20:02:11 --> Model Class Initialized
INFO - 2018-03-31 20:02:11 --> Model Class Initialized
INFO - 2018-03-31 20:02:11 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:02:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:02:12 --> Final output sent to browser
DEBUG - 2018-03-31 20:02:12 --> Total execution time: 0.3236
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Loader Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
INFO - 2018-03-31 20:02:12 --> Config Class Initialized
INFO - 2018-03-31 20:02:12 --> Hooks Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:02:12 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
DEBUG - 2018-03-31 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
INFO - 2018-03-31 20:02:12 --> URI Class Initialized
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
INFO - 2018-03-31 20:02:12 --> Router Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Database Driver Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
INFO - 2018-03-31 20:02:12 --> Output Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:02:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:12 --> Input Class Initialized
INFO - 2018-03-31 20:02:12 --> Language Class Initialized
ERROR - 2018-03-31 20:02:12 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 20:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:12 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:12 --> Model Class Initialized
INFO - 2018-03-31 20:02:12 --> Controller Class Initialized
INFO - 2018-03-31 20:02:12 --> Model Class Initialized
INFO - 2018-03-31 20:02:12 --> Model Class Initialized
INFO - 2018-03-31 20:02:12 --> Model Class Initialized
INFO - 2018-03-31 20:02:12 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:02:49 --> Config Class Initialized
INFO - 2018-03-31 20:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:49 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:49 --> URI Class Initialized
INFO - 2018-03-31 20:02:49 --> Router Class Initialized
INFO - 2018-03-31 20:02:49 --> Output Class Initialized
INFO - 2018-03-31 20:02:49 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:49 --> Input Class Initialized
INFO - 2018-03-31 20:02:49 --> Language Class Initialized
INFO - 2018-03-31 20:02:49 --> Loader Class Initialized
INFO - 2018-03-31 20:02:49 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:49 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:49 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Controller Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:02:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:02:49 --> Final output sent to browser
DEBUG - 2018-03-31 20:02:49 --> Total execution time: 0.3952
INFO - 2018-03-31 20:02:49 --> Config Class Initialized
INFO - 2018-03-31 20:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:49 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:49 --> URI Class Initialized
INFO - 2018-03-31 20:02:49 --> Router Class Initialized
INFO - 2018-03-31 20:02:49 --> Output Class Initialized
INFO - 2018-03-31 20:02:49 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:49 --> Input Class Initialized
INFO - 2018-03-31 20:02:49 --> Language Class Initialized
INFO - 2018-03-31 20:02:49 --> Loader Class Initialized
INFO - 2018-03-31 20:02:49 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:49 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:49 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Controller Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
INFO - 2018-03-31 20:02:49 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:02:53 --> Config Class Initialized
INFO - 2018-03-31 20:02:53 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:53 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:53 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:53 --> URI Class Initialized
INFO - 2018-03-31 20:02:53 --> Router Class Initialized
INFO - 2018-03-31 20:02:53 --> Output Class Initialized
INFO - 2018-03-31 20:02:53 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:53 --> Input Class Initialized
INFO - 2018-03-31 20:02:53 --> Language Class Initialized
INFO - 2018-03-31 20:02:53 --> Loader Class Initialized
INFO - 2018-03-31 20:02:53 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:53 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:53 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:53 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
INFO - 2018-03-31 20:02:53 --> Controller Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
INFO - 2018-03-31 20:02:53 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:02:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:02:54 --> Final output sent to browser
DEBUG - 2018-03-31 20:02:54 --> Total execution time: 0.5459
INFO - 2018-03-31 20:02:54 --> Config Class Initialized
INFO - 2018-03-31 20:02:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:02:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:02:54 --> Utf8 Class Initialized
INFO - 2018-03-31 20:02:54 --> URI Class Initialized
INFO - 2018-03-31 20:02:54 --> Router Class Initialized
INFO - 2018-03-31 20:02:54 --> Output Class Initialized
INFO - 2018-03-31 20:02:54 --> Security Class Initialized
DEBUG - 2018-03-31 20:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:02:54 --> Input Class Initialized
INFO - 2018-03-31 20:02:54 --> Language Class Initialized
INFO - 2018-03-31 20:02:54 --> Loader Class Initialized
INFO - 2018-03-31 20:02:54 --> Helper loaded: url_helper
INFO - 2018-03-31 20:02:54 --> Helper loaded: form_helper
INFO - 2018-03-31 20:02:54 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:02:54 --> Form Validation Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
INFO - 2018-03-31 20:02:54 --> Controller Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
INFO - 2018-03-31 20:02:54 --> Model Class Initialized
DEBUG - 2018-03-31 20:02:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:05:42 --> Config Class Initialized
INFO - 2018-03-31 20:05:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:05:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:05:42 --> Utf8 Class Initialized
INFO - 2018-03-31 20:05:42 --> URI Class Initialized
INFO - 2018-03-31 20:05:42 --> Router Class Initialized
INFO - 2018-03-31 20:05:42 --> Output Class Initialized
INFO - 2018-03-31 20:05:42 --> Security Class Initialized
DEBUG - 2018-03-31 20:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:05:42 --> Input Class Initialized
INFO - 2018-03-31 20:05:42 --> Language Class Initialized
INFO - 2018-03-31 20:05:42 --> Loader Class Initialized
INFO - 2018-03-31 20:05:42 --> Helper loaded: url_helper
INFO - 2018-03-31 20:05:42 --> Helper loaded: form_helper
INFO - 2018-03-31 20:05:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:05:42 --> Form Validation Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
INFO - 2018-03-31 20:05:42 --> Controller Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
INFO - 2018-03-31 20:05:42 --> Model Class Initialized
DEBUG - 2018-03-31 20:05:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:05:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:05:42 --> Final output sent to browser
DEBUG - 2018-03-31 20:05:42 --> Total execution time: 0.3745
INFO - 2018-03-31 20:05:42 --> Config Class Initialized
INFO - 2018-03-31 20:05:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:05:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:05:42 --> Utf8 Class Initialized
INFO - 2018-03-31 20:05:42 --> URI Class Initialized
INFO - 2018-03-31 20:05:42 --> Router Class Initialized
INFO - 2018-03-31 20:05:42 --> Output Class Initialized
INFO - 2018-03-31 20:05:42 --> Security Class Initialized
DEBUG - 2018-03-31 20:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:05:42 --> Input Class Initialized
INFO - 2018-03-31 20:05:42 --> Language Class Initialized
INFO - 2018-03-31 20:05:42 --> Loader Class Initialized
INFO - 2018-03-31 20:05:42 --> Helper loaded: url_helper
INFO - 2018-03-31 20:05:42 --> Helper loaded: form_helper
INFO - 2018-03-31 20:05:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:05:43 --> Form Validation Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
INFO - 2018-03-31 20:05:43 --> Controller Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
INFO - 2018-03-31 20:05:43 --> Model Class Initialized
DEBUG - 2018-03-31 20:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:06:55 --> Config Class Initialized
INFO - 2018-03-31 20:06:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:06:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:06:55 --> Utf8 Class Initialized
INFO - 2018-03-31 20:06:55 --> URI Class Initialized
INFO - 2018-03-31 20:06:55 --> Router Class Initialized
INFO - 2018-03-31 20:06:55 --> Output Class Initialized
INFO - 2018-03-31 20:06:55 --> Security Class Initialized
DEBUG - 2018-03-31 20:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:06:55 --> Input Class Initialized
INFO - 2018-03-31 20:06:55 --> Language Class Initialized
INFO - 2018-03-31 20:06:55 --> Loader Class Initialized
INFO - 2018-03-31 20:06:55 --> Helper loaded: url_helper
INFO - 2018-03-31 20:06:55 --> Helper loaded: form_helper
INFO - 2018-03-31 20:06:55 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:06:55 --> Form Validation Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
INFO - 2018-03-31 20:06:55 --> Controller Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
INFO - 2018-03-31 20:06:55 --> Model Class Initialized
DEBUG - 2018-03-31 20:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:06:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:06:55 --> Final output sent to browser
DEBUG - 2018-03-31 20:06:55 --> Total execution time: 0.4419
INFO - 2018-03-31 20:06:55 --> Config Class Initialized
INFO - 2018-03-31 20:06:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:06:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:06:55 --> Utf8 Class Initialized
INFO - 2018-03-31 20:06:55 --> URI Class Initialized
INFO - 2018-03-31 20:06:55 --> Router Class Initialized
INFO - 2018-03-31 20:06:55 --> Output Class Initialized
INFO - 2018-03-31 20:06:55 --> Security Class Initialized
DEBUG - 2018-03-31 20:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:06:55 --> Input Class Initialized
INFO - 2018-03-31 20:06:55 --> Language Class Initialized
INFO - 2018-03-31 20:06:55 --> Loader Class Initialized
INFO - 2018-03-31 20:06:55 --> Helper loaded: url_helper
INFO - 2018-03-31 20:06:56 --> Helper loaded: form_helper
INFO - 2018-03-31 20:06:56 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:06:56 --> Form Validation Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
INFO - 2018-03-31 20:06:56 --> Controller Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
INFO - 2018-03-31 20:06:56 --> Model Class Initialized
DEBUG - 2018-03-31 20:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:07:04 --> Config Class Initialized
INFO - 2018-03-31 20:07:04 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:07:04 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:07:04 --> Utf8 Class Initialized
INFO - 2018-03-31 20:07:04 --> URI Class Initialized
INFO - 2018-03-31 20:07:04 --> Router Class Initialized
INFO - 2018-03-31 20:07:05 --> Output Class Initialized
INFO - 2018-03-31 20:07:05 --> Security Class Initialized
DEBUG - 2018-03-31 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:07:05 --> Input Class Initialized
INFO - 2018-03-31 20:07:05 --> Language Class Initialized
INFO - 2018-03-31 20:07:05 --> Loader Class Initialized
INFO - 2018-03-31 20:07:05 --> Helper loaded: url_helper
INFO - 2018-03-31 20:07:05 --> Helper loaded: form_helper
INFO - 2018-03-31 20:07:05 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:07:05 --> Form Validation Class Initialized
INFO - 2018-03-31 20:07:05 --> Model Class Initialized
INFO - 2018-03-31 20:07:05 --> Controller Class Initialized
INFO - 2018-03-31 20:07:05 --> Model Class Initialized
INFO - 2018-03-31 20:07:05 --> Model Class Initialized
INFO - 2018-03-31 20:07:05 --> Model Class Initialized
INFO - 2018-03-31 20:07:05 --> Model Class Initialized
DEBUG - 2018-03-31 20:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:07:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:07:05 --> Final output sent to browser
DEBUG - 2018-03-31 20:07:05 --> Total execution time: 0.2388
INFO - 2018-03-31 20:07:07 --> Config Class Initialized
INFO - 2018-03-31 20:07:07 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:07:07 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:07:07 --> Utf8 Class Initialized
INFO - 2018-03-31 20:07:07 --> URI Class Initialized
INFO - 2018-03-31 20:07:07 --> Router Class Initialized
INFO - 2018-03-31 20:07:07 --> Output Class Initialized
INFO - 2018-03-31 20:07:07 --> Security Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:07:07 --> Input Class Initialized
INFO - 2018-03-31 20:07:07 --> Language Class Initialized
INFO - 2018-03-31 20:07:07 --> Loader Class Initialized
INFO - 2018-03-31 20:07:07 --> Helper loaded: url_helper
INFO - 2018-03-31 20:07:07 --> Helper loaded: form_helper
INFO - 2018-03-31 20:07:07 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:07:07 --> Form Validation Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Controller Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:07:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:07:07 --> Final output sent to browser
DEBUG - 2018-03-31 20:07:07 --> Total execution time: 0.2339
INFO - 2018-03-31 20:07:07 --> Config Class Initialized
INFO - 2018-03-31 20:07:07 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:07:07 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:07:07 --> Utf8 Class Initialized
INFO - 2018-03-31 20:07:07 --> URI Class Initialized
INFO - 2018-03-31 20:07:07 --> Router Class Initialized
INFO - 2018-03-31 20:07:07 --> Output Class Initialized
INFO - 2018-03-31 20:07:07 --> Security Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:07:07 --> Input Class Initialized
INFO - 2018-03-31 20:07:07 --> Language Class Initialized
INFO - 2018-03-31 20:07:07 --> Loader Class Initialized
INFO - 2018-03-31 20:07:07 --> Helper loaded: url_helper
INFO - 2018-03-31 20:07:07 --> Helper loaded: form_helper
INFO - 2018-03-31 20:07:07 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:07:07 --> Form Validation Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Controller Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
INFO - 2018-03-31 20:07:07 --> Model Class Initialized
DEBUG - 2018-03-31 20:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:07:33 --> Config Class Initialized
INFO - 2018-03-31 20:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:07:33 --> Utf8 Class Initialized
INFO - 2018-03-31 20:07:33 --> URI Class Initialized
INFO - 2018-03-31 20:07:33 --> Router Class Initialized
INFO - 2018-03-31 20:07:33 --> Output Class Initialized
INFO - 2018-03-31 20:07:33 --> Security Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:07:33 --> Input Class Initialized
INFO - 2018-03-31 20:07:33 --> Language Class Initialized
INFO - 2018-03-31 20:07:33 --> Loader Class Initialized
INFO - 2018-03-31 20:07:33 --> Helper loaded: url_helper
INFO - 2018-03-31 20:07:33 --> Helper loaded: form_helper
INFO - 2018-03-31 20:07:33 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:07:33 --> Form Validation Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Controller Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:07:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:07:33 --> Final output sent to browser
DEBUG - 2018-03-31 20:07:33 --> Total execution time: 0.2616
INFO - 2018-03-31 20:07:33 --> Config Class Initialized
INFO - 2018-03-31 20:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:07:33 --> Utf8 Class Initialized
INFO - 2018-03-31 20:07:33 --> URI Class Initialized
INFO - 2018-03-31 20:07:33 --> Router Class Initialized
INFO - 2018-03-31 20:07:33 --> Output Class Initialized
INFO - 2018-03-31 20:07:33 --> Security Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:07:33 --> Input Class Initialized
INFO - 2018-03-31 20:07:33 --> Language Class Initialized
INFO - 2018-03-31 20:07:33 --> Loader Class Initialized
INFO - 2018-03-31 20:07:33 --> Helper loaded: url_helper
INFO - 2018-03-31 20:07:33 --> Helper loaded: form_helper
INFO - 2018-03-31 20:07:33 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:07:33 --> Form Validation Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Controller Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
INFO - 2018-03-31 20:07:33 --> Model Class Initialized
DEBUG - 2018-03-31 20:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:09:02 --> Config Class Initialized
INFO - 2018-03-31 20:09:02 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:02 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:02 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:02 --> URI Class Initialized
INFO - 2018-03-31 20:09:02 --> Router Class Initialized
INFO - 2018-03-31 20:09:02 --> Output Class Initialized
INFO - 2018-03-31 20:09:02 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:02 --> Input Class Initialized
INFO - 2018-03-31 20:09:02 --> Language Class Initialized
INFO - 2018-03-31 20:09:02 --> Loader Class Initialized
INFO - 2018-03-31 20:09:02 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:02 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:02 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:02 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:02 --> Model Class Initialized
INFO - 2018-03-31 20:09:02 --> Controller Class Initialized
INFO - 2018-03-31 20:09:02 --> Model Class Initialized
INFO - 2018-03-31 20:09:02 --> Model Class Initialized
INFO - 2018-03-31 20:09:02 --> Model Class Initialized
INFO - 2018-03-31 20:09:02 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:09:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:09:02 --> Final output sent to browser
DEBUG - 2018-03-31 20:09:02 --> Total execution time: 0.2254
INFO - 2018-03-31 20:09:03 --> Config Class Initialized
INFO - 2018-03-31 20:09:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:03 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:03 --> URI Class Initialized
INFO - 2018-03-31 20:09:03 --> Router Class Initialized
INFO - 2018-03-31 20:09:03 --> Output Class Initialized
INFO - 2018-03-31 20:09:03 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:03 --> Input Class Initialized
INFO - 2018-03-31 20:09:03 --> Language Class Initialized
INFO - 2018-03-31 20:09:03 --> Loader Class Initialized
INFO - 2018-03-31 20:09:03 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:03 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:03 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:03 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:03 --> Model Class Initialized
INFO - 2018-03-31 20:09:03 --> Controller Class Initialized
INFO - 2018-03-31 20:09:03 --> Model Class Initialized
INFO - 2018-03-31 20:09:03 --> Model Class Initialized
INFO - 2018-03-31 20:09:03 --> Model Class Initialized
INFO - 2018-03-31 20:09:03 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 20:09:03 --> Severity: Notice --> Undefined property: Reporte::$tproyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-31 20:09:03 --> Severity: Notice --> Undefined property: Reporte::$tproyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-31 20:09:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ASC, .`fecha_inicio` ASC' at line 9 - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
ORDER BY .`proyecto_estado_id` ASC, .`fecha_inicio` ASC
INFO - 2018-03-31 20:09:03 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 20:09:05 --> Config Class Initialized
INFO - 2018-03-31 20:09:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:05 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:05 --> URI Class Initialized
INFO - 2018-03-31 20:09:05 --> Router Class Initialized
INFO - 2018-03-31 20:09:05 --> Output Class Initialized
INFO - 2018-03-31 20:09:05 --> Config Class Initialized
INFO - 2018-03-31 20:09:05 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:05 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:05 --> Input Class Initialized
DEBUG - 2018-03-31 20:09:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:05 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:05 --> Language Class Initialized
INFO - 2018-03-31 20:09:05 --> URI Class Initialized
ERROR - 2018-03-31 20:09:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:05 --> Router Class Initialized
INFO - 2018-03-31 20:09:05 --> Output Class Initialized
INFO - 2018-03-31 20:09:05 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:05 --> Input Class Initialized
INFO - 2018-03-31 20:09:05 --> Language Class Initialized
ERROR - 2018-03-31 20:09:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:06 --> Config Class Initialized
INFO - 2018-03-31 20:09:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:06 --> URI Class Initialized
INFO - 2018-03-31 20:09:06 --> Router Class Initialized
INFO - 2018-03-31 20:09:06 --> Config Class Initialized
INFO - 2018-03-31 20:09:06 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:06 --> Output Class Initialized
DEBUG - 2018-03-31 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:06 --> Security Class Initialized
INFO - 2018-03-31 20:09:06 --> URI Class Initialized
DEBUG - 2018-03-31 20:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:06 --> Input Class Initialized
INFO - 2018-03-31 20:09:06 --> Config Class Initialized
INFO - 2018-03-31 20:09:06 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:06 --> Language Class Initialized
INFO - 2018-03-31 20:09:06 --> Router Class Initialized
ERROR - 2018-03-31 20:09:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:06 --> Output Class Initialized
DEBUG - 2018-03-31 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:06 --> Security Class Initialized
INFO - 2018-03-31 20:09:06 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:06 --> URI Class Initialized
INFO - 2018-03-31 20:09:06 --> Input Class Initialized
INFO - 2018-03-31 20:09:06 --> Config Class Initialized
INFO - 2018-03-31 20:09:06 --> Language Class Initialized
INFO - 2018-03-31 20:09:06 --> Hooks Class Initialized
ERROR - 2018-03-31 20:09:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:06 --> Router Class Initialized
DEBUG - 2018-03-31 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:06 --> Config Class Initialized
INFO - 2018-03-31 20:09:06 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:06 --> Output Class Initialized
INFO - 2018-03-31 20:09:06 --> URI Class Initialized
INFO - 2018-03-31 20:09:06 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-31 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:06 --> Input Class Initialized
INFO - 2018-03-31 20:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:06 --> Router Class Initialized
INFO - 2018-03-31 20:09:06 --> Language Class Initialized
INFO - 2018-03-31 20:09:06 --> URI Class Initialized
INFO - 2018-03-31 20:09:06 --> Output Class Initialized
ERROR - 2018-03-31 20:09:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:06 --> Security Class Initialized
INFO - 2018-03-31 20:09:06 --> Router Class Initialized
DEBUG - 2018-03-31 20:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:06 --> Input Class Initialized
INFO - 2018-03-31 20:09:06 --> Language Class Initialized
INFO - 2018-03-31 20:09:06 --> Output Class Initialized
ERROR - 2018-03-31 20:09:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:06 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:06 --> Input Class Initialized
INFO - 2018-03-31 20:09:06 --> Language Class Initialized
ERROR - 2018-03-31 20:09:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:08 --> Config Class Initialized
INFO - 2018-03-31 20:09:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:08 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:08 --> URI Class Initialized
INFO - 2018-03-31 20:09:08 --> Router Class Initialized
INFO - 2018-03-31 20:09:08 --> Output Class Initialized
INFO - 2018-03-31 20:09:08 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:08 --> Input Class Initialized
INFO - 2018-03-31 20:09:08 --> Language Class Initialized
INFO - 2018-03-31 20:09:08 --> Loader Class Initialized
INFO - 2018-03-31 20:09:08 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:08 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:08 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:08 --> Model Class Initialized
INFO - 2018-03-31 20:09:08 --> Controller Class Initialized
INFO - 2018-03-31 20:09:08 --> Model Class Initialized
INFO - 2018-03-31 20:09:08 --> Model Class Initialized
INFO - 2018-03-31 20:09:08 --> Model Class Initialized
INFO - 2018-03-31 20:09:08 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:09:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:09:09 --> Final output sent to browser
DEBUG - 2018-03-31 20:09:09 --> Total execution time: 0.2567
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
INFO - 2018-03-31 20:09:09 --> Config Class Initialized
INFO - 2018-03-31 20:09:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
DEBUG - 2018-03-31 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:09 --> Utf8 Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
INFO - 2018-03-31 20:09:09 --> URI Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Router Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Output Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
INFO - 2018-03-31 20:09:09 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:09 --> Input Class Initialized
INFO - 2018-03-31 20:09:09 --> Language Class Initialized
ERROR - 2018-03-31 20:09:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:09 --> Loader Class Initialized
INFO - 2018-03-31 20:09:09 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:09 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:09 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:09 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:09 --> Model Class Initialized
INFO - 2018-03-31 20:09:09 --> Controller Class Initialized
INFO - 2018-03-31 20:09:09 --> Model Class Initialized
INFO - 2018-03-31 20:09:09 --> Model Class Initialized
INFO - 2018-03-31 20:09:09 --> Model Class Initialized
INFO - 2018-03-31 20:09:09 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 20:09:09 --> Severity: Notice --> Undefined property: Reporte::$tproyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-31 20:09:09 --> Severity: Notice --> Undefined property: Reporte::$tproyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-31 20:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ASC, .`fecha_inicio` ASC' at line 9 - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
ORDER BY .`proyecto_estado_id` ASC, .`fecha_inicio` ASC
INFO - 2018-03-31 20:09:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Loader Class Initialized
INFO - 2018-03-31 20:09:25 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:25 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:25 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:25 --> Model Class Initialized
INFO - 2018-03-31 20:09:25 --> Controller Class Initialized
INFO - 2018-03-31 20:09:25 --> Model Class Initialized
INFO - 2018-03-31 20:09:25 --> Model Class Initialized
INFO - 2018-03-31 20:09:25 --> Model Class Initialized
INFO - 2018-03-31 20:09:25 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:09:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:09:25 --> Final output sent to browser
DEBUG - 2018-03-31 20:09:25 --> Total execution time: 0.2313
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Loader Class Initialized
INFO - 2018-03-31 20:09:25 --> Helper loaded: url_helper
INFO - 2018-03-31 20:09:25 --> Helper loaded: form_helper
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
INFO - 2018-03-31 20:09:25 --> Database Driver Class Initialized
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:25 --> Config Class Initialized
INFO - 2018-03-31 20:09:25 --> Hooks Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
DEBUG - 2018-03-31 20:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
INFO - 2018-03-31 20:09:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:09:25 --> URI Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-31 20:09:25 --> Router Class Initialized
INFO - 2018-03-31 20:09:25 --> Output Class Initialized
INFO - 2018-03-31 20:09:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:09:25 --> Input Class Initialized
INFO - 2018-03-31 20:09:25 --> Language Class Initialized
ERROR - 2018-03-31 20:09:25 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-31 20:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:09:26 --> Form Validation Class Initialized
INFO - 2018-03-31 20:09:26 --> Model Class Initialized
INFO - 2018-03-31 20:09:26 --> Controller Class Initialized
INFO - 2018-03-31 20:09:26 --> Model Class Initialized
INFO - 2018-03-31 20:09:26 --> Model Class Initialized
INFO - 2018-03-31 20:09:26 --> Model Class Initialized
INFO - 2018-03-31 20:09:26 --> Model Class Initialized
DEBUG - 2018-03-31 20:09:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:10:34 --> Config Class Initialized
INFO - 2018-03-31 20:10:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:10:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:10:34 --> Utf8 Class Initialized
INFO - 2018-03-31 20:10:34 --> URI Class Initialized
INFO - 2018-03-31 20:10:34 --> Router Class Initialized
INFO - 2018-03-31 20:10:34 --> Output Class Initialized
INFO - 2018-03-31 20:10:34 --> Security Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:10:34 --> Input Class Initialized
INFO - 2018-03-31 20:10:34 --> Language Class Initialized
INFO - 2018-03-31 20:10:34 --> Loader Class Initialized
INFO - 2018-03-31 20:10:34 --> Helper loaded: url_helper
INFO - 2018-03-31 20:10:34 --> Helper loaded: form_helper
INFO - 2018-03-31 20:10:34 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:10:34 --> Form Validation Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Controller Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:10:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:10:34 --> Final output sent to browser
DEBUG - 2018-03-31 20:10:34 --> Total execution time: 0.2890
INFO - 2018-03-31 20:10:34 --> Config Class Initialized
INFO - 2018-03-31 20:10:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:10:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:10:34 --> Utf8 Class Initialized
INFO - 2018-03-31 20:10:34 --> URI Class Initialized
INFO - 2018-03-31 20:10:34 --> Router Class Initialized
INFO - 2018-03-31 20:10:34 --> Output Class Initialized
INFO - 2018-03-31 20:10:34 --> Security Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:10:34 --> Input Class Initialized
INFO - 2018-03-31 20:10:34 --> Language Class Initialized
INFO - 2018-03-31 20:10:34 --> Loader Class Initialized
INFO - 2018-03-31 20:10:34 --> Helper loaded: url_helper
INFO - 2018-03-31 20:10:34 --> Helper loaded: form_helper
INFO - 2018-03-31 20:10:34 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:10:34 --> Form Validation Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Controller Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
INFO - 2018-03-31 20:10:34 --> Model Class Initialized
DEBUG - 2018-03-31 20:10:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:10:40 --> Config Class Initialized
INFO - 2018-03-31 20:10:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:10:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:10:40 --> Utf8 Class Initialized
INFO - 2018-03-31 20:10:40 --> URI Class Initialized
INFO - 2018-03-31 20:10:40 --> Router Class Initialized
INFO - 2018-03-31 20:10:40 --> Output Class Initialized
INFO - 2018-03-31 20:10:40 --> Security Class Initialized
DEBUG - 2018-03-31 20:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:10:40 --> Input Class Initialized
INFO - 2018-03-31 20:10:40 --> Language Class Initialized
INFO - 2018-03-31 20:10:40 --> Loader Class Initialized
INFO - 2018-03-31 20:10:40 --> Helper loaded: url_helper
INFO - 2018-03-31 20:10:40 --> Helper loaded: form_helper
INFO - 2018-03-31 20:10:40 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:10:40 --> Form Validation Class Initialized
INFO - 2018-03-31 20:10:40 --> Model Class Initialized
INFO - 2018-03-31 20:10:40 --> Controller Class Initialized
INFO - 2018-03-31 20:10:40 --> Model Class Initialized
INFO - 2018-03-31 20:10:40 --> Model Class Initialized
INFO - 2018-03-31 20:10:40 --> Model Class Initialized
INFO - 2018-03-31 20:10:40 --> Model Class Initialized
DEBUG - 2018-03-31 20:10:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:10:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:10:40 --> Final output sent to browser
DEBUG - 2018-03-31 20:10:40 --> Total execution time: 0.2192
INFO - 2018-03-31 20:10:41 --> Config Class Initialized
INFO - 2018-03-31 20:10:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:10:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:10:41 --> Utf8 Class Initialized
INFO - 2018-03-31 20:10:41 --> URI Class Initialized
INFO - 2018-03-31 20:10:41 --> Router Class Initialized
INFO - 2018-03-31 20:10:41 --> Output Class Initialized
INFO - 2018-03-31 20:10:41 --> Security Class Initialized
DEBUG - 2018-03-31 20:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:10:41 --> Input Class Initialized
INFO - 2018-03-31 20:10:41 --> Language Class Initialized
INFO - 2018-03-31 20:10:41 --> Loader Class Initialized
INFO - 2018-03-31 20:10:41 --> Helper loaded: url_helper
INFO - 2018-03-31 20:10:41 --> Helper loaded: form_helper
INFO - 2018-03-31 20:10:41 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:10:41 --> Form Validation Class Initialized
INFO - 2018-03-31 20:10:41 --> Model Class Initialized
INFO - 2018-03-31 20:10:41 --> Controller Class Initialized
INFO - 2018-03-31 20:10:41 --> Model Class Initialized
INFO - 2018-03-31 20:10:41 --> Model Class Initialized
INFO - 2018-03-31 20:10:41 --> Model Class Initialized
INFO - 2018-03-31 20:10:41 --> Model Class Initialized
DEBUG - 2018-03-31 20:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:10:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:10:41 --> Final output sent to browser
DEBUG - 2018-03-31 20:10:41 --> Total execution time: 0.2409
INFO - 2018-03-31 20:10:41 --> Config Class Initialized
INFO - 2018-03-31 20:10:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:10:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:10:41 --> Utf8 Class Initialized
INFO - 2018-03-31 20:10:41 --> URI Class Initialized
INFO - 2018-03-31 20:10:41 --> Router Class Initialized
INFO - 2018-03-31 20:10:41 --> Output Class Initialized
INFO - 2018-03-31 20:10:41 --> Security Class Initialized
DEBUG - 2018-03-31 20:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:10:41 --> Input Class Initialized
INFO - 2018-03-31 20:10:41 --> Language Class Initialized
INFO - 2018-03-31 20:10:41 --> Loader Class Initialized
INFO - 2018-03-31 20:10:41 --> Helper loaded: url_helper
INFO - 2018-03-31 20:10:41 --> Helper loaded: form_helper
INFO - 2018-03-31 20:10:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:10:42 --> Form Validation Class Initialized
INFO - 2018-03-31 20:10:42 --> Model Class Initialized
INFO - 2018-03-31 20:10:42 --> Controller Class Initialized
INFO - 2018-03-31 20:10:42 --> Model Class Initialized
INFO - 2018-03-31 20:10:42 --> Model Class Initialized
INFO - 2018-03-31 20:10:42 --> Model Class Initialized
INFO - 2018-03-31 20:10:42 --> Model Class Initialized
DEBUG - 2018-03-31 20:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:32 --> Config Class Initialized
INFO - 2018-03-31 20:13:32 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:32 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:32 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:32 --> URI Class Initialized
INFO - 2018-03-31 20:13:32 --> Router Class Initialized
INFO - 2018-03-31 20:13:32 --> Output Class Initialized
INFO - 2018-03-31 20:13:32 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:32 --> Input Class Initialized
INFO - 2018-03-31 20:13:32 --> Language Class Initialized
INFO - 2018-03-31 20:13:32 --> Loader Class Initialized
INFO - 2018-03-31 20:13:32 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:32 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:32 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:32 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:32 --> Model Class Initialized
INFO - 2018-03-31 20:13:32 --> Controller Class Initialized
INFO - 2018-03-31 20:13:32 --> Model Class Initialized
INFO - 2018-03-31 20:13:32 --> Model Class Initialized
INFO - 2018-03-31 20:13:32 --> Model Class Initialized
INFO - 2018-03-31 20:13:32 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:13:32 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:32 --> Total execution time: 0.2174
INFO - 2018-03-31 20:13:33 --> Config Class Initialized
INFO - 2018-03-31 20:13:33 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:33 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:33 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:33 --> URI Class Initialized
INFO - 2018-03-31 20:13:33 --> Router Class Initialized
INFO - 2018-03-31 20:13:33 --> Output Class Initialized
INFO - 2018-03-31 20:13:33 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:33 --> Input Class Initialized
INFO - 2018-03-31 20:13:33 --> Language Class Initialized
INFO - 2018-03-31 20:13:33 --> Loader Class Initialized
INFO - 2018-03-31 20:13:33 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:33 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:33 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:33 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:33 --> Model Class Initialized
INFO - 2018-03-31 20:13:33 --> Controller Class Initialized
INFO - 2018-03-31 20:13:33 --> Model Class Initialized
INFO - 2018-03-31 20:13:33 --> Model Class Initialized
INFO - 2018-03-31 20:13:33 --> Model Class Initialized
INFO - 2018-03-31 20:13:33 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:35 --> Config Class Initialized
INFO - 2018-03-31 20:13:35 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:35 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:35 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:35 --> URI Class Initialized
INFO - 2018-03-31 20:13:35 --> Router Class Initialized
INFO - 2018-03-31 20:13:35 --> Output Class Initialized
INFO - 2018-03-31 20:13:35 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:35 --> Input Class Initialized
INFO - 2018-03-31 20:13:35 --> Language Class Initialized
INFO - 2018-03-31 20:13:35 --> Loader Class Initialized
INFO - 2018-03-31 20:13:35 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:35 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:35 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:35 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Controller Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:13:35 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:35 --> Total execution time: 0.2176
INFO - 2018-03-31 20:13:35 --> Config Class Initialized
INFO - 2018-03-31 20:13:35 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:35 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:35 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:35 --> URI Class Initialized
INFO - 2018-03-31 20:13:35 --> Router Class Initialized
INFO - 2018-03-31 20:13:35 --> Output Class Initialized
INFO - 2018-03-31 20:13:35 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:35 --> Input Class Initialized
INFO - 2018-03-31 20:13:35 --> Language Class Initialized
INFO - 2018-03-31 20:13:35 --> Loader Class Initialized
INFO - 2018-03-31 20:13:35 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:35 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:35 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:35 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Controller Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
INFO - 2018-03-31 20:13:35 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:54 --> Config Class Initialized
INFO - 2018-03-31 20:13:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:54 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:54 --> URI Class Initialized
INFO - 2018-03-31 20:13:54 --> Router Class Initialized
INFO - 2018-03-31 20:13:54 --> Output Class Initialized
INFO - 2018-03-31 20:13:54 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:54 --> Input Class Initialized
INFO - 2018-03-31 20:13:54 --> Language Class Initialized
INFO - 2018-03-31 20:13:54 --> Loader Class Initialized
INFO - 2018-03-31 20:13:54 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:54 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:54 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:54 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:54 --> Model Class Initialized
INFO - 2018-03-31 20:13:54 --> Controller Class Initialized
INFO - 2018-03-31 20:13:54 --> Model Class Initialized
INFO - 2018-03-31 20:13:54 --> Model Class Initialized
INFO - 2018-03-31 20:13:54 --> Model Class Initialized
INFO - 2018-03-31 20:13:54 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:13:55 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:55 --> Total execution time: 0.1987
INFO - 2018-03-31 20:13:55 --> Config Class Initialized
INFO - 2018-03-31 20:13:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:55 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:55 --> URI Class Initialized
INFO - 2018-03-31 20:13:55 --> Router Class Initialized
INFO - 2018-03-31 20:13:55 --> Output Class Initialized
INFO - 2018-03-31 20:13:55 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:55 --> Input Class Initialized
INFO - 2018-03-31 20:13:55 --> Language Class Initialized
INFO - 2018-03-31 20:13:55 --> Loader Class Initialized
INFO - 2018-03-31 20:13:55 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:55 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:55 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:55 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:55 --> Model Class Initialized
INFO - 2018-03-31 20:13:55 --> Controller Class Initialized
INFO - 2018-03-31 20:13:55 --> Model Class Initialized
INFO - 2018-03-31 20:13:55 --> Model Class Initialized
INFO - 2018-03-31 20:13:55 --> Model Class Initialized
INFO - 2018-03-31 20:13:55 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:57 --> Config Class Initialized
INFO - 2018-03-31 20:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:57 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:57 --> URI Class Initialized
INFO - 2018-03-31 20:13:57 --> Router Class Initialized
INFO - 2018-03-31 20:13:57 --> Output Class Initialized
INFO - 2018-03-31 20:13:57 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:57 --> Input Class Initialized
INFO - 2018-03-31 20:13:57 --> Language Class Initialized
INFO - 2018-03-31 20:13:57 --> Loader Class Initialized
INFO - 2018-03-31 20:13:57 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:57 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:57 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:57 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Controller Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:13:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:13:57 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:57 --> Total execution time: 0.2063
INFO - 2018-03-31 20:13:57 --> Config Class Initialized
INFO - 2018-03-31 20:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:13:57 --> Utf8 Class Initialized
INFO - 2018-03-31 20:13:57 --> URI Class Initialized
INFO - 2018-03-31 20:13:57 --> Router Class Initialized
INFO - 2018-03-31 20:13:57 --> Output Class Initialized
INFO - 2018-03-31 20:13:57 --> Security Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:13:57 --> Input Class Initialized
INFO - 2018-03-31 20:13:57 --> Language Class Initialized
INFO - 2018-03-31 20:13:57 --> Loader Class Initialized
INFO - 2018-03-31 20:13:57 --> Helper loaded: url_helper
INFO - 2018-03-31 20:13:57 --> Helper loaded: form_helper
INFO - 2018-03-31 20:13:57 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:13:57 --> Form Validation Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Controller Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
INFO - 2018-03-31 20:13:57 --> Model Class Initialized
DEBUG - 2018-03-31 20:13:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:14:15 --> Config Class Initialized
INFO - 2018-03-31 20:14:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:14:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:14:15 --> Utf8 Class Initialized
INFO - 2018-03-31 20:14:15 --> URI Class Initialized
INFO - 2018-03-31 20:14:15 --> Router Class Initialized
INFO - 2018-03-31 20:14:15 --> Output Class Initialized
INFO - 2018-03-31 20:14:15 --> Security Class Initialized
DEBUG - 2018-03-31 20:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:14:15 --> Input Class Initialized
INFO - 2018-03-31 20:14:15 --> Language Class Initialized
INFO - 2018-03-31 20:14:15 --> Loader Class Initialized
INFO - 2018-03-31 20:14:15 --> Helper loaded: url_helper
INFO - 2018-03-31 20:14:15 --> Helper loaded: form_helper
INFO - 2018-03-31 20:14:15 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:14:15 --> Form Validation Class Initialized
INFO - 2018-03-31 20:14:15 --> Model Class Initialized
INFO - 2018-03-31 20:14:15 --> Controller Class Initialized
INFO - 2018-03-31 20:14:15 --> Model Class Initialized
INFO - 2018-03-31 20:14:15 --> Model Class Initialized
INFO - 2018-03-31 20:14:15 --> Model Class Initialized
INFO - 2018-03-31 20:14:15 --> Model Class Initialized
DEBUG - 2018-03-31 20:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:14:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:14:15 --> Final output sent to browser
DEBUG - 2018-03-31 20:14:15 --> Total execution time: 0.2396
INFO - 2018-03-31 20:14:15 --> Config Class Initialized
INFO - 2018-03-31 20:14:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:14:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:14:15 --> Utf8 Class Initialized
INFO - 2018-03-31 20:14:15 --> URI Class Initialized
INFO - 2018-03-31 20:14:15 --> Router Class Initialized
INFO - 2018-03-31 20:14:15 --> Output Class Initialized
INFO - 2018-03-31 20:14:15 --> Security Class Initialized
DEBUG - 2018-03-31 20:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:14:15 --> Input Class Initialized
INFO - 2018-03-31 20:14:15 --> Language Class Initialized
INFO - 2018-03-31 20:14:15 --> Loader Class Initialized
INFO - 2018-03-31 20:14:15 --> Helper loaded: url_helper
INFO - 2018-03-31 20:14:15 --> Helper loaded: form_helper
INFO - 2018-03-31 20:14:15 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:14:16 --> Form Validation Class Initialized
INFO - 2018-03-31 20:14:16 --> Model Class Initialized
INFO - 2018-03-31 20:14:16 --> Controller Class Initialized
INFO - 2018-03-31 20:14:16 --> Model Class Initialized
INFO - 2018-03-31 20:14:16 --> Model Class Initialized
INFO - 2018-03-31 20:14:16 --> Model Class Initialized
INFO - 2018-03-31 20:14:16 --> Model Class Initialized
DEBUG - 2018-03-31 20:14:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:15:25 --> Config Class Initialized
INFO - 2018-03-31 20:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:15:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:15:25 --> URI Class Initialized
INFO - 2018-03-31 20:15:25 --> Router Class Initialized
INFO - 2018-03-31 20:15:25 --> Output Class Initialized
INFO - 2018-03-31 20:15:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:15:25 --> Input Class Initialized
INFO - 2018-03-31 20:15:25 --> Language Class Initialized
INFO - 2018-03-31 20:15:25 --> Loader Class Initialized
INFO - 2018-03-31 20:15:25 --> Helper loaded: url_helper
INFO - 2018-03-31 20:15:25 --> Helper loaded: form_helper
INFO - 2018-03-31 20:15:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:15:25 --> Form Validation Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Controller Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:15:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:15:25 --> Final output sent to browser
DEBUG - 2018-03-31 20:15:25 --> Total execution time: 0.2567
INFO - 2018-03-31 20:15:25 --> Config Class Initialized
INFO - 2018-03-31 20:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:15:25 --> Utf8 Class Initialized
INFO - 2018-03-31 20:15:25 --> URI Class Initialized
INFO - 2018-03-31 20:15:25 --> Router Class Initialized
INFO - 2018-03-31 20:15:25 --> Output Class Initialized
INFO - 2018-03-31 20:15:25 --> Security Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:15:25 --> Input Class Initialized
INFO - 2018-03-31 20:15:25 --> Language Class Initialized
INFO - 2018-03-31 20:15:25 --> Loader Class Initialized
INFO - 2018-03-31 20:15:25 --> Helper loaded: url_helper
INFO - 2018-03-31 20:15:25 --> Helper loaded: form_helper
INFO - 2018-03-31 20:15:25 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:15:25 --> Form Validation Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Controller Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
INFO - 2018-03-31 20:15:25 --> Model Class Initialized
DEBUG - 2018-03-31 20:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:16 --> Config Class Initialized
INFO - 2018-03-31 20:16:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:16 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:16 --> URI Class Initialized
INFO - 2018-03-31 20:16:16 --> Router Class Initialized
INFO - 2018-03-31 20:16:16 --> Output Class Initialized
INFO - 2018-03-31 20:16:16 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:16 --> Input Class Initialized
INFO - 2018-03-31 20:16:16 --> Language Class Initialized
INFO - 2018-03-31 20:16:16 --> Loader Class Initialized
INFO - 2018-03-31 20:16:16 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:16 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:17 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Controller Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:16:17 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:17 --> Total execution time: 0.2329
INFO - 2018-03-31 20:16:17 --> Config Class Initialized
INFO - 2018-03-31 20:16:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:17 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:17 --> URI Class Initialized
INFO - 2018-03-31 20:16:17 --> Router Class Initialized
INFO - 2018-03-31 20:16:17 --> Output Class Initialized
INFO - 2018-03-31 20:16:17 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:17 --> Input Class Initialized
INFO - 2018-03-31 20:16:17 --> Language Class Initialized
INFO - 2018-03-31 20:16:17 --> Loader Class Initialized
INFO - 2018-03-31 20:16:17 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:17 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:17 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:17 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Controller Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
INFO - 2018-03-31 20:16:17 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:18 --> Config Class Initialized
INFO - 2018-03-31 20:16:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:18 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:18 --> URI Class Initialized
INFO - 2018-03-31 20:16:18 --> Router Class Initialized
INFO - 2018-03-31 20:16:18 --> Output Class Initialized
INFO - 2018-03-31 20:16:18 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:18 --> Input Class Initialized
INFO - 2018-03-31 20:16:18 --> Language Class Initialized
INFO - 2018-03-31 20:16:18 --> Loader Class Initialized
INFO - 2018-03-31 20:16:18 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:18 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:18 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:18 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
INFO - 2018-03-31 20:16:18 --> Controller Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
INFO - 2018-03-31 20:16:18 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:16:18 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:18 --> Total execution time: 0.3450
INFO - 2018-03-31 20:16:19 --> Config Class Initialized
INFO - 2018-03-31 20:16:19 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:19 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:19 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:19 --> URI Class Initialized
INFO - 2018-03-31 20:16:19 --> Router Class Initialized
INFO - 2018-03-31 20:16:19 --> Output Class Initialized
INFO - 2018-03-31 20:16:19 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:19 --> Input Class Initialized
INFO - 2018-03-31 20:16:19 --> Language Class Initialized
INFO - 2018-03-31 20:16:19 --> Loader Class Initialized
INFO - 2018-03-31 20:16:19 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:19 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:19 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:19 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
INFO - 2018-03-31 20:16:19 --> Controller Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
INFO - 2018-03-31 20:16:19 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:42 --> Config Class Initialized
INFO - 2018-03-31 20:16:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:42 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:42 --> URI Class Initialized
INFO - 2018-03-31 20:16:42 --> Router Class Initialized
INFO - 2018-03-31 20:16:42 --> Output Class Initialized
INFO - 2018-03-31 20:16:42 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:42 --> Input Class Initialized
INFO - 2018-03-31 20:16:42 --> Language Class Initialized
INFO - 2018-03-31 20:16:42 --> Loader Class Initialized
INFO - 2018-03-31 20:16:42 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:42 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:42 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Controller Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:16:42 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:42 --> Total execution time: 0.4251
INFO - 2018-03-31 20:16:42 --> Config Class Initialized
INFO - 2018-03-31 20:16:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:42 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:42 --> URI Class Initialized
INFO - 2018-03-31 20:16:42 --> Router Class Initialized
INFO - 2018-03-31 20:16:42 --> Output Class Initialized
INFO - 2018-03-31 20:16:42 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:42 --> Input Class Initialized
INFO - 2018-03-31 20:16:42 --> Language Class Initialized
INFO - 2018-03-31 20:16:42 --> Loader Class Initialized
INFO - 2018-03-31 20:16:42 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:42 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:42 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Controller Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:42 --> Model Class Initialized
INFO - 2018-03-31 20:16:43 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:46 --> Config Class Initialized
INFO - 2018-03-31 20:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:46 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:46 --> URI Class Initialized
INFO - 2018-03-31 20:16:46 --> Router Class Initialized
INFO - 2018-03-31 20:16:46 --> Output Class Initialized
INFO - 2018-03-31 20:16:46 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:46 --> Input Class Initialized
INFO - 2018-03-31 20:16:46 --> Language Class Initialized
INFO - 2018-03-31 20:16:46 --> Loader Class Initialized
INFO - 2018-03-31 20:16:46 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:46 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:46 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:46 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Controller Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:16:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:16:46 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:46 --> Total execution time: 0.2338
INFO - 2018-03-31 20:16:46 --> Config Class Initialized
INFO - 2018-03-31 20:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:16:46 --> Utf8 Class Initialized
INFO - 2018-03-31 20:16:46 --> URI Class Initialized
INFO - 2018-03-31 20:16:46 --> Router Class Initialized
INFO - 2018-03-31 20:16:46 --> Output Class Initialized
INFO - 2018-03-31 20:16:46 --> Security Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:16:46 --> Input Class Initialized
INFO - 2018-03-31 20:16:46 --> Language Class Initialized
INFO - 2018-03-31 20:16:46 --> Loader Class Initialized
INFO - 2018-03-31 20:16:46 --> Helper loaded: url_helper
INFO - 2018-03-31 20:16:46 --> Helper loaded: form_helper
INFO - 2018-03-31 20:16:46 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:16:46 --> Form Validation Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Controller Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
INFO - 2018-03-31 20:16:46 --> Model Class Initialized
DEBUG - 2018-03-31 20:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:30 --> Config Class Initialized
INFO - 2018-03-31 20:17:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:30 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:30 --> URI Class Initialized
INFO - 2018-03-31 20:17:30 --> Router Class Initialized
INFO - 2018-03-31 20:17:30 --> Output Class Initialized
INFO - 2018-03-31 20:17:30 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:30 --> Input Class Initialized
INFO - 2018-03-31 20:17:30 --> Language Class Initialized
INFO - 2018-03-31 20:17:30 --> Loader Class Initialized
INFO - 2018-03-31 20:17:30 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:30 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:30 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:30 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:30 --> Model Class Initialized
INFO - 2018-03-31 20:17:30 --> Controller Class Initialized
INFO - 2018-03-31 20:17:30 --> Model Class Initialized
INFO - 2018-03-31 20:17:30 --> Model Class Initialized
INFO - 2018-03-31 20:17:30 --> Model Class Initialized
INFO - 2018-03-31 20:17:30 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:17:30 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:30 --> Total execution time: 0.2849
INFO - 2018-03-31 20:17:31 --> Config Class Initialized
INFO - 2018-03-31 20:17:31 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:31 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:31 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:31 --> URI Class Initialized
INFO - 2018-03-31 20:17:31 --> Router Class Initialized
INFO - 2018-03-31 20:17:31 --> Output Class Initialized
INFO - 2018-03-31 20:17:31 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:31 --> Input Class Initialized
INFO - 2018-03-31 20:17:31 --> Language Class Initialized
INFO - 2018-03-31 20:17:31 --> Loader Class Initialized
INFO - 2018-03-31 20:17:31 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:31 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:31 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:31 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:31 --> Model Class Initialized
INFO - 2018-03-31 20:17:31 --> Controller Class Initialized
INFO - 2018-03-31 20:17:31 --> Model Class Initialized
INFO - 2018-03-31 20:17:31 --> Model Class Initialized
INFO - 2018-03-31 20:17:31 --> Model Class Initialized
INFO - 2018-03-31 20:17:31 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:44 --> Config Class Initialized
INFO - 2018-03-31 20:17:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:44 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:44 --> URI Class Initialized
INFO - 2018-03-31 20:17:44 --> Router Class Initialized
INFO - 2018-03-31 20:17:44 --> Output Class Initialized
INFO - 2018-03-31 20:17:44 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:44 --> Input Class Initialized
INFO - 2018-03-31 20:17:44 --> Language Class Initialized
INFO - 2018-03-31 20:17:44 --> Loader Class Initialized
INFO - 2018-03-31 20:17:44 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:44 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:45 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Controller Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:17:45 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:45 --> Total execution time: 0.3571
INFO - 2018-03-31 20:17:45 --> Config Class Initialized
INFO - 2018-03-31 20:17:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:45 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:45 --> URI Class Initialized
INFO - 2018-03-31 20:17:45 --> Router Class Initialized
INFO - 2018-03-31 20:17:45 --> Output Class Initialized
INFO - 2018-03-31 20:17:45 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:45 --> Input Class Initialized
INFO - 2018-03-31 20:17:45 --> Language Class Initialized
INFO - 2018-03-31 20:17:45 --> Loader Class Initialized
INFO - 2018-03-31 20:17:45 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:45 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:45 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Controller Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
INFO - 2018-03-31 20:17:45 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:52 --> Config Class Initialized
INFO - 2018-03-31 20:17:52 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:52 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:52 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:52 --> URI Class Initialized
INFO - 2018-03-31 20:17:52 --> Router Class Initialized
INFO - 2018-03-31 20:17:52 --> Output Class Initialized
INFO - 2018-03-31 20:17:52 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:52 --> Input Class Initialized
INFO - 2018-03-31 20:17:52 --> Language Class Initialized
INFO - 2018-03-31 20:17:52 --> Loader Class Initialized
INFO - 2018-03-31 20:17:52 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:52 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:52 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:52 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Controller Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:17:52 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:52 --> Total execution time: 0.2879
INFO - 2018-03-31 20:17:52 --> Config Class Initialized
INFO - 2018-03-31 20:17:52 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:52 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:52 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:52 --> URI Class Initialized
INFO - 2018-03-31 20:17:52 --> Router Class Initialized
INFO - 2018-03-31 20:17:52 --> Output Class Initialized
INFO - 2018-03-31 20:17:52 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:52 --> Input Class Initialized
INFO - 2018-03-31 20:17:52 --> Language Class Initialized
INFO - 2018-03-31 20:17:52 --> Loader Class Initialized
INFO - 2018-03-31 20:17:52 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:52 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:52 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:52 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Controller Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
INFO - 2018-03-31 20:17:52 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:56 --> Config Class Initialized
INFO - 2018-03-31 20:17:56 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:56 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:56 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:56 --> URI Class Initialized
INFO - 2018-03-31 20:17:56 --> Router Class Initialized
INFO - 2018-03-31 20:17:56 --> Output Class Initialized
INFO - 2018-03-31 20:17:56 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:56 --> Input Class Initialized
INFO - 2018-03-31 20:17:56 --> Language Class Initialized
INFO - 2018-03-31 20:17:56 --> Loader Class Initialized
INFO - 2018-03-31 20:17:56 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:56 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:56 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:56 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Controller Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:17:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:17:56 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:56 --> Total execution time: 0.3665
INFO - 2018-03-31 20:17:56 --> Config Class Initialized
INFO - 2018-03-31 20:17:56 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:17:56 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:17:56 --> Utf8 Class Initialized
INFO - 2018-03-31 20:17:56 --> URI Class Initialized
INFO - 2018-03-31 20:17:56 --> Router Class Initialized
INFO - 2018-03-31 20:17:56 --> Output Class Initialized
INFO - 2018-03-31 20:17:56 --> Security Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:17:56 --> Input Class Initialized
INFO - 2018-03-31 20:17:56 --> Language Class Initialized
INFO - 2018-03-31 20:17:56 --> Loader Class Initialized
INFO - 2018-03-31 20:17:56 --> Helper loaded: url_helper
INFO - 2018-03-31 20:17:56 --> Helper loaded: form_helper
INFO - 2018-03-31 20:17:56 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:17:56 --> Form Validation Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Controller Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
INFO - 2018-03-31 20:17:56 --> Model Class Initialized
DEBUG - 2018-03-31 20:17:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:02 --> Config Class Initialized
INFO - 2018-03-31 20:18:02 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:02 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:02 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:02 --> URI Class Initialized
INFO - 2018-03-31 20:18:02 --> Router Class Initialized
INFO - 2018-03-31 20:18:02 --> Output Class Initialized
INFO - 2018-03-31 20:18:02 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:02 --> Input Class Initialized
INFO - 2018-03-31 20:18:02 --> Language Class Initialized
INFO - 2018-03-31 20:18:02 --> Loader Class Initialized
INFO - 2018-03-31 20:18:02 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:02 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:02 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:02 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Controller Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:18:02 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:02 --> Total execution time: 0.2510
INFO - 2018-03-31 20:18:02 --> Config Class Initialized
INFO - 2018-03-31 20:18:02 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:02 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:02 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:02 --> URI Class Initialized
INFO - 2018-03-31 20:18:02 --> Router Class Initialized
INFO - 2018-03-31 20:18:02 --> Output Class Initialized
INFO - 2018-03-31 20:18:02 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:02 --> Input Class Initialized
INFO - 2018-03-31 20:18:02 --> Language Class Initialized
INFO - 2018-03-31 20:18:02 --> Loader Class Initialized
INFO - 2018-03-31 20:18:02 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:02 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:02 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:02 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Controller Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
INFO - 2018-03-31 20:18:02 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:05 --> Config Class Initialized
INFO - 2018-03-31 20:18:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:05 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:05 --> URI Class Initialized
INFO - 2018-03-31 20:18:05 --> Router Class Initialized
INFO - 2018-03-31 20:18:05 --> Output Class Initialized
INFO - 2018-03-31 20:18:05 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:05 --> Input Class Initialized
INFO - 2018-03-31 20:18:05 --> Language Class Initialized
INFO - 2018-03-31 20:18:05 --> Loader Class Initialized
INFO - 2018-03-31 20:18:05 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:05 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:05 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:05 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
INFO - 2018-03-31 20:18:05 --> Controller Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
INFO - 2018-03-31 20:18:05 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:18:05 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:05 --> Total execution time: 0.3401
INFO - 2018-03-31 20:18:06 --> Config Class Initialized
INFO - 2018-03-31 20:18:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:06 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:06 --> URI Class Initialized
INFO - 2018-03-31 20:18:06 --> Router Class Initialized
INFO - 2018-03-31 20:18:06 --> Output Class Initialized
INFO - 2018-03-31 20:18:06 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:06 --> Input Class Initialized
INFO - 2018-03-31 20:18:06 --> Language Class Initialized
INFO - 2018-03-31 20:18:06 --> Loader Class Initialized
INFO - 2018-03-31 20:18:06 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:06 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:06 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:06 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> Controller Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:08 --> Config Class Initialized
INFO - 2018-03-31 20:18:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:08 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:08 --> URI Class Initialized
INFO - 2018-03-31 20:18:08 --> Router Class Initialized
INFO - 2018-03-31 20:18:08 --> Output Class Initialized
INFO - 2018-03-31 20:18:08 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:08 --> Input Class Initialized
INFO - 2018-03-31 20:18:08 --> Language Class Initialized
INFO - 2018-03-31 20:18:08 --> Loader Class Initialized
INFO - 2018-03-31 20:18:08 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:08 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:08 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Controller Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:18:08 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:08 --> Total execution time: 0.2616
INFO - 2018-03-31 20:18:08 --> Config Class Initialized
INFO - 2018-03-31 20:18:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:08 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:08 --> URI Class Initialized
INFO - 2018-03-31 20:18:08 --> Router Class Initialized
INFO - 2018-03-31 20:18:08 --> Output Class Initialized
INFO - 2018-03-31 20:18:08 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:08 --> Input Class Initialized
INFO - 2018-03-31 20:18:08 --> Language Class Initialized
INFO - 2018-03-31 20:18:08 --> Loader Class Initialized
INFO - 2018-03-31 20:18:08 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:08 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:08 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Controller Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
INFO - 2018-03-31 20:18:08 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:11 --> Config Class Initialized
INFO - 2018-03-31 20:18:11 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:11 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:11 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:11 --> URI Class Initialized
INFO - 2018-03-31 20:18:11 --> Router Class Initialized
INFO - 2018-03-31 20:18:11 --> Output Class Initialized
INFO - 2018-03-31 20:18:11 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:11 --> Input Class Initialized
INFO - 2018-03-31 20:18:11 --> Language Class Initialized
INFO - 2018-03-31 20:18:11 --> Loader Class Initialized
INFO - 2018-03-31 20:18:11 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:11 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:11 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:11 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
INFO - 2018-03-31 20:18:11 --> Controller Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
INFO - 2018-03-31 20:18:11 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:18:12 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:12 --> Total execution time: 0.3431
INFO - 2018-03-31 20:18:12 --> Config Class Initialized
INFO - 2018-03-31 20:18:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:12 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:12 --> URI Class Initialized
INFO - 2018-03-31 20:18:12 --> Router Class Initialized
INFO - 2018-03-31 20:18:12 --> Output Class Initialized
INFO - 2018-03-31 20:18:12 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:12 --> Input Class Initialized
INFO - 2018-03-31 20:18:12 --> Language Class Initialized
INFO - 2018-03-31 20:18:12 --> Loader Class Initialized
INFO - 2018-03-31 20:18:12 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:12 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:12 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:12 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
INFO - 2018-03-31 20:18:12 --> Controller Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
INFO - 2018-03-31 20:18:12 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:16 --> Config Class Initialized
INFO - 2018-03-31 20:18:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:16 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:16 --> URI Class Initialized
INFO - 2018-03-31 20:18:16 --> Router Class Initialized
INFO - 2018-03-31 20:18:16 --> Output Class Initialized
INFO - 2018-03-31 20:18:16 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:16 --> Input Class Initialized
INFO - 2018-03-31 20:18:16 --> Language Class Initialized
INFO - 2018-03-31 20:18:16 --> Loader Class Initialized
INFO - 2018-03-31 20:18:16 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:16 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:16 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:16 --> Model Class Initialized
INFO - 2018-03-31 20:18:16 --> Controller Class Initialized
INFO - 2018-03-31 20:18:16 --> Model Class Initialized
INFO - 2018-03-31 20:18:16 --> Model Class Initialized
INFO - 2018-03-31 20:18:16 --> Model Class Initialized
INFO - 2018-03-31 20:18:16 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:18:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:18:17 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:17 --> Total execution time: 0.2391
INFO - 2018-03-31 20:18:17 --> Config Class Initialized
INFO - 2018-03-31 20:18:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:18:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:18:17 --> Utf8 Class Initialized
INFO - 2018-03-31 20:18:17 --> URI Class Initialized
INFO - 2018-03-31 20:18:17 --> Router Class Initialized
INFO - 2018-03-31 20:18:17 --> Output Class Initialized
INFO - 2018-03-31 20:18:17 --> Security Class Initialized
DEBUG - 2018-03-31 20:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:18:17 --> Input Class Initialized
INFO - 2018-03-31 20:18:17 --> Language Class Initialized
INFO - 2018-03-31 20:18:17 --> Loader Class Initialized
INFO - 2018-03-31 20:18:17 --> Helper loaded: url_helper
INFO - 2018-03-31 20:18:17 --> Helper loaded: form_helper
INFO - 2018-03-31 20:18:17 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:18:17 --> Form Validation Class Initialized
INFO - 2018-03-31 20:18:17 --> Model Class Initialized
INFO - 2018-03-31 20:18:17 --> Controller Class Initialized
INFO - 2018-03-31 20:18:17 --> Model Class Initialized
INFO - 2018-03-31 20:18:17 --> Model Class Initialized
INFO - 2018-03-31 20:18:17 --> Model Class Initialized
INFO - 2018-03-31 20:18:17 --> Model Class Initialized
DEBUG - 2018-03-31 20:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:19:16 --> Config Class Initialized
INFO - 2018-03-31 20:19:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:19:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:19:16 --> Utf8 Class Initialized
INFO - 2018-03-31 20:19:16 --> URI Class Initialized
INFO - 2018-03-31 20:19:16 --> Router Class Initialized
INFO - 2018-03-31 20:19:16 --> Output Class Initialized
INFO - 2018-03-31 20:19:16 --> Security Class Initialized
DEBUG - 2018-03-31 20:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:19:16 --> Input Class Initialized
INFO - 2018-03-31 20:19:16 --> Language Class Initialized
INFO - 2018-03-31 20:19:16 --> Loader Class Initialized
INFO - 2018-03-31 20:19:16 --> Helper loaded: url_helper
INFO - 2018-03-31 20:19:16 --> Helper loaded: form_helper
INFO - 2018-03-31 20:19:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:19:16 --> Form Validation Class Initialized
INFO - 2018-03-31 20:19:16 --> Model Class Initialized
INFO - 2018-03-31 20:19:16 --> Controller Class Initialized
INFO - 2018-03-31 20:19:16 --> Model Class Initialized
INFO - 2018-03-31 20:19:16 --> Model Class Initialized
INFO - 2018-03-31 20:19:16 --> Model Class Initialized
INFO - 2018-03-31 20:19:16 --> Model Class Initialized
DEBUG - 2018-03-31 20:19:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:19:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:19:16 --> Final output sent to browser
DEBUG - 2018-03-31 20:19:16 --> Total execution time: 0.2132
INFO - 2018-03-31 20:19:16 --> Config Class Initialized
INFO - 2018-03-31 20:19:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:19:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:19:16 --> Utf8 Class Initialized
INFO - 2018-03-31 20:19:16 --> URI Class Initialized
INFO - 2018-03-31 20:19:16 --> Router Class Initialized
INFO - 2018-03-31 20:19:16 --> Output Class Initialized
INFO - 2018-03-31 20:19:16 --> Security Class Initialized
DEBUG - 2018-03-31 20:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:19:16 --> Input Class Initialized
INFO - 2018-03-31 20:19:16 --> Language Class Initialized
INFO - 2018-03-31 20:19:16 --> Loader Class Initialized
INFO - 2018-03-31 20:19:16 --> Helper loaded: url_helper
INFO - 2018-03-31 20:19:16 --> Helper loaded: form_helper
INFO - 2018-03-31 20:19:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:19:17 --> Form Validation Class Initialized
INFO - 2018-03-31 20:19:17 --> Model Class Initialized
INFO - 2018-03-31 20:19:17 --> Controller Class Initialized
INFO - 2018-03-31 20:19:17 --> Model Class Initialized
INFO - 2018-03-31 20:19:17 --> Model Class Initialized
INFO - 2018-03-31 20:19:17 --> Model Class Initialized
INFO - 2018-03-31 20:19:17 --> Model Class Initialized
DEBUG - 2018-03-31 20:19:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:19:40 --> Config Class Initialized
INFO - 2018-03-31 20:19:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:19:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:19:40 --> Utf8 Class Initialized
INFO - 2018-03-31 20:19:40 --> URI Class Initialized
INFO - 2018-03-31 20:19:40 --> Router Class Initialized
INFO - 2018-03-31 20:19:40 --> Output Class Initialized
INFO - 2018-03-31 20:19:40 --> Security Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:19:40 --> Input Class Initialized
INFO - 2018-03-31 20:19:40 --> Language Class Initialized
INFO - 2018-03-31 20:19:40 --> Loader Class Initialized
INFO - 2018-03-31 20:19:40 --> Helper loaded: url_helper
INFO - 2018-03-31 20:19:40 --> Helper loaded: form_helper
INFO - 2018-03-31 20:19:40 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:19:40 --> Form Validation Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Controller Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:19:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:19:40 --> Final output sent to browser
DEBUG - 2018-03-31 20:19:40 --> Total execution time: 0.2198
INFO - 2018-03-31 20:19:40 --> Config Class Initialized
INFO - 2018-03-31 20:19:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:19:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:19:40 --> Utf8 Class Initialized
INFO - 2018-03-31 20:19:40 --> URI Class Initialized
INFO - 2018-03-31 20:19:40 --> Router Class Initialized
INFO - 2018-03-31 20:19:40 --> Output Class Initialized
INFO - 2018-03-31 20:19:40 --> Security Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:19:40 --> Input Class Initialized
INFO - 2018-03-31 20:19:40 --> Language Class Initialized
INFO - 2018-03-31 20:19:40 --> Loader Class Initialized
INFO - 2018-03-31 20:19:40 --> Helper loaded: url_helper
INFO - 2018-03-31 20:19:40 --> Helper loaded: form_helper
INFO - 2018-03-31 20:19:40 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:19:40 --> Form Validation Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Controller Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
INFO - 2018-03-31 20:19:40 --> Model Class Initialized
DEBUG - 2018-03-31 20:19:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:20:08 --> Config Class Initialized
INFO - 2018-03-31 20:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:20:08 --> Utf8 Class Initialized
INFO - 2018-03-31 20:20:08 --> URI Class Initialized
INFO - 2018-03-31 20:20:08 --> Router Class Initialized
INFO - 2018-03-31 20:20:08 --> Output Class Initialized
INFO - 2018-03-31 20:20:08 --> Security Class Initialized
DEBUG - 2018-03-31 20:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:20:08 --> Input Class Initialized
INFO - 2018-03-31 20:20:08 --> Language Class Initialized
INFO - 2018-03-31 20:20:08 --> Loader Class Initialized
INFO - 2018-03-31 20:20:08 --> Helper loaded: url_helper
INFO - 2018-03-31 20:20:08 --> Helper loaded: form_helper
INFO - 2018-03-31 20:20:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:20:08 --> Form Validation Class Initialized
INFO - 2018-03-31 20:20:08 --> Model Class Initialized
INFO - 2018-03-31 20:20:08 --> Controller Class Initialized
INFO - 2018-03-31 20:20:08 --> Model Class Initialized
INFO - 2018-03-31 20:20:08 --> Model Class Initialized
INFO - 2018-03-31 20:20:08 --> Model Class Initialized
INFO - 2018-03-31 20:20:08 --> Model Class Initialized
DEBUG - 2018-03-31 20:20:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:20:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:20:08 --> Final output sent to browser
DEBUG - 2018-03-31 20:20:08 --> Total execution time: 0.1988
INFO - 2018-03-31 20:20:08 --> Config Class Initialized
INFO - 2018-03-31 20:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:20:08 --> Utf8 Class Initialized
INFO - 2018-03-31 20:20:08 --> URI Class Initialized
INFO - 2018-03-31 20:20:08 --> Router Class Initialized
INFO - 2018-03-31 20:20:08 --> Output Class Initialized
INFO - 2018-03-31 20:20:08 --> Security Class Initialized
DEBUG - 2018-03-31 20:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:20:08 --> Input Class Initialized
INFO - 2018-03-31 20:20:08 --> Language Class Initialized
INFO - 2018-03-31 20:20:08 --> Loader Class Initialized
INFO - 2018-03-31 20:20:08 --> Helper loaded: url_helper
INFO - 2018-03-31 20:20:08 --> Helper loaded: form_helper
INFO - 2018-03-31 20:20:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:20:09 --> Form Validation Class Initialized
INFO - 2018-03-31 20:20:09 --> Model Class Initialized
INFO - 2018-03-31 20:20:09 --> Controller Class Initialized
INFO - 2018-03-31 20:20:09 --> Model Class Initialized
INFO - 2018-03-31 20:20:09 --> Model Class Initialized
INFO - 2018-03-31 20:20:09 --> Model Class Initialized
INFO - 2018-03-31 20:20:09 --> Model Class Initialized
DEBUG - 2018-03-31 20:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:21:18 --> Config Class Initialized
INFO - 2018-03-31 20:21:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:21:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:21:18 --> Utf8 Class Initialized
INFO - 2018-03-31 20:21:18 --> URI Class Initialized
INFO - 2018-03-31 20:21:18 --> Router Class Initialized
INFO - 2018-03-31 20:21:18 --> Output Class Initialized
INFO - 2018-03-31 20:21:18 --> Security Class Initialized
DEBUG - 2018-03-31 20:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:21:18 --> Input Class Initialized
INFO - 2018-03-31 20:21:18 --> Language Class Initialized
INFO - 2018-03-31 20:21:18 --> Loader Class Initialized
INFO - 2018-03-31 20:21:18 --> Helper loaded: url_helper
INFO - 2018-03-31 20:21:18 --> Helper loaded: form_helper
INFO - 2018-03-31 20:21:18 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:21:18 --> Form Validation Class Initialized
INFO - 2018-03-31 20:21:18 --> Model Class Initialized
INFO - 2018-03-31 20:21:18 --> Controller Class Initialized
INFO - 2018-03-31 20:21:18 --> Model Class Initialized
INFO - 2018-03-31 20:21:18 --> Model Class Initialized
INFO - 2018-03-31 20:21:18 --> Model Class Initialized
INFO - 2018-03-31 20:21:18 --> Model Class Initialized
DEBUG - 2018-03-31 20:21:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 20:21:18 --> Severity: Notice --> Undefined variable: colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteProyectosGeneral.php 161
ERROR - 2018-03-31 20:21:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\reporte\reporteProyectosGeneral.php 161
INFO - 2018-03-31 20:21:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:21:18 --> Final output sent to browser
DEBUG - 2018-03-31 20:21:18 --> Total execution time: 0.2245
INFO - 2018-03-31 20:21:19 --> Config Class Initialized
INFO - 2018-03-31 20:21:19 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:21:19 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:21:19 --> Utf8 Class Initialized
INFO - 2018-03-31 20:21:19 --> URI Class Initialized
INFO - 2018-03-31 20:21:19 --> Router Class Initialized
INFO - 2018-03-31 20:21:19 --> Output Class Initialized
INFO - 2018-03-31 20:21:19 --> Security Class Initialized
DEBUG - 2018-03-31 20:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:21:19 --> Input Class Initialized
INFO - 2018-03-31 20:21:19 --> Language Class Initialized
INFO - 2018-03-31 20:21:19 --> Loader Class Initialized
INFO - 2018-03-31 20:21:19 --> Helper loaded: url_helper
INFO - 2018-03-31 20:21:19 --> Helper loaded: form_helper
INFO - 2018-03-31 20:21:19 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:21:19 --> Form Validation Class Initialized
INFO - 2018-03-31 20:21:19 --> Model Class Initialized
INFO - 2018-03-31 20:21:19 --> Controller Class Initialized
INFO - 2018-03-31 20:21:19 --> Model Class Initialized
INFO - 2018-03-31 20:21:19 --> Model Class Initialized
INFO - 2018-03-31 20:21:19 --> Model Class Initialized
INFO - 2018-03-31 20:21:19 --> Model Class Initialized
DEBUG - 2018-03-31 20:21:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:21:31 --> Config Class Initialized
INFO - 2018-03-31 20:21:31 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:21:31 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:21:31 --> Utf8 Class Initialized
INFO - 2018-03-31 20:21:31 --> URI Class Initialized
INFO - 2018-03-31 20:21:31 --> Router Class Initialized
INFO - 2018-03-31 20:21:31 --> Output Class Initialized
INFO - 2018-03-31 20:21:31 --> Security Class Initialized
DEBUG - 2018-03-31 20:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:21:31 --> Input Class Initialized
INFO - 2018-03-31 20:21:31 --> Language Class Initialized
INFO - 2018-03-31 20:21:31 --> Loader Class Initialized
INFO - 2018-03-31 20:21:31 --> Helper loaded: url_helper
INFO - 2018-03-31 20:21:31 --> Helper loaded: form_helper
INFO - 2018-03-31 20:21:31 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:21:31 --> Form Validation Class Initialized
INFO - 2018-03-31 20:21:31 --> Model Class Initialized
INFO - 2018-03-31 20:21:31 --> Controller Class Initialized
INFO - 2018-03-31 20:21:31 --> Model Class Initialized
INFO - 2018-03-31 20:21:31 --> Model Class Initialized
INFO - 2018-03-31 20:21:31 --> Model Class Initialized
INFO - 2018-03-31 20:21:31 --> Model Class Initialized
DEBUG - 2018-03-31 20:21:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:21:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:21:32 --> Final output sent to browser
DEBUG - 2018-03-31 20:21:32 --> Total execution time: 0.2165
INFO - 2018-03-31 20:21:32 --> Config Class Initialized
INFO - 2018-03-31 20:21:32 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:21:32 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:21:32 --> Utf8 Class Initialized
INFO - 2018-03-31 20:21:32 --> URI Class Initialized
INFO - 2018-03-31 20:21:32 --> Router Class Initialized
INFO - 2018-03-31 20:21:32 --> Output Class Initialized
INFO - 2018-03-31 20:21:32 --> Security Class Initialized
DEBUG - 2018-03-31 20:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:21:32 --> Input Class Initialized
INFO - 2018-03-31 20:21:32 --> Language Class Initialized
INFO - 2018-03-31 20:21:32 --> Loader Class Initialized
INFO - 2018-03-31 20:21:32 --> Helper loaded: url_helper
INFO - 2018-03-31 20:21:32 --> Helper loaded: form_helper
INFO - 2018-03-31 20:21:32 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:21:32 --> Form Validation Class Initialized
INFO - 2018-03-31 20:21:32 --> Model Class Initialized
INFO - 2018-03-31 20:21:32 --> Controller Class Initialized
INFO - 2018-03-31 20:21:32 --> Model Class Initialized
INFO - 2018-03-31 20:21:32 --> Model Class Initialized
INFO - 2018-03-31 20:21:32 --> Model Class Initialized
INFO - 2018-03-31 20:21:32 --> Model Class Initialized
DEBUG - 2018-03-31 20:21:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:03 --> Config Class Initialized
INFO - 2018-03-31 20:22:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:03 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:03 --> URI Class Initialized
INFO - 2018-03-31 20:22:03 --> Router Class Initialized
INFO - 2018-03-31 20:22:03 --> Output Class Initialized
INFO - 2018-03-31 20:22:03 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:03 --> Input Class Initialized
INFO - 2018-03-31 20:22:03 --> Language Class Initialized
INFO - 2018-03-31 20:22:03 --> Loader Class Initialized
INFO - 2018-03-31 20:22:03 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:03 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:03 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:03 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:03 --> Model Class Initialized
INFO - 2018-03-31 20:22:03 --> Controller Class Initialized
INFO - 2018-03-31 20:22:03 --> Model Class Initialized
INFO - 2018-03-31 20:22:03 --> Model Class Initialized
INFO - 2018-03-31 20:22:03 --> Model Class Initialized
INFO - 2018-03-31 20:22:03 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:22:03 --> Final output sent to browser
DEBUG - 2018-03-31 20:22:03 --> Total execution time: 0.2316
INFO - 2018-03-31 20:22:04 --> Config Class Initialized
INFO - 2018-03-31 20:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:04 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:04 --> URI Class Initialized
INFO - 2018-03-31 20:22:04 --> Router Class Initialized
INFO - 2018-03-31 20:22:04 --> Output Class Initialized
INFO - 2018-03-31 20:22:04 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:04 --> Input Class Initialized
INFO - 2018-03-31 20:22:04 --> Language Class Initialized
INFO - 2018-03-31 20:22:04 --> Loader Class Initialized
INFO - 2018-03-31 20:22:04 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:04 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:04 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:04 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:04 --> Model Class Initialized
INFO - 2018-03-31 20:22:04 --> Controller Class Initialized
INFO - 2018-03-31 20:22:04 --> Model Class Initialized
INFO - 2018-03-31 20:22:04 --> Model Class Initialized
INFO - 2018-03-31 20:22:04 --> Model Class Initialized
INFO - 2018-03-31 20:22:04 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:14 --> Config Class Initialized
INFO - 2018-03-31 20:22:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:14 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:14 --> URI Class Initialized
INFO - 2018-03-31 20:22:14 --> Router Class Initialized
INFO - 2018-03-31 20:22:14 --> Output Class Initialized
INFO - 2018-03-31 20:22:14 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:14 --> Input Class Initialized
INFO - 2018-03-31 20:22:14 --> Language Class Initialized
INFO - 2018-03-31 20:22:14 --> Loader Class Initialized
INFO - 2018-03-31 20:22:14 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:14 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:14 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:14 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:14 --> Model Class Initialized
INFO - 2018-03-31 20:22:14 --> Controller Class Initialized
INFO - 2018-03-31 20:22:14 --> Model Class Initialized
INFO - 2018-03-31 20:22:14 --> Model Class Initialized
INFO - 2018-03-31 20:22:14 --> Model Class Initialized
INFO - 2018-03-31 20:22:14 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:22:14 --> Final output sent to browser
DEBUG - 2018-03-31 20:22:14 --> Total execution time: 0.2091
INFO - 2018-03-31 20:22:14 --> Config Class Initialized
INFO - 2018-03-31 20:22:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:14 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:14 --> URI Class Initialized
INFO - 2018-03-31 20:22:14 --> Router Class Initialized
INFO - 2018-03-31 20:22:14 --> Output Class Initialized
INFO - 2018-03-31 20:22:14 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:15 --> Input Class Initialized
INFO - 2018-03-31 20:22:15 --> Language Class Initialized
INFO - 2018-03-31 20:22:15 --> Loader Class Initialized
INFO - 2018-03-31 20:22:15 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:15 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:15 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:15 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:15 --> Model Class Initialized
INFO - 2018-03-31 20:22:15 --> Controller Class Initialized
INFO - 2018-03-31 20:22:15 --> Model Class Initialized
INFO - 2018-03-31 20:22:15 --> Model Class Initialized
INFO - 2018-03-31 20:22:15 --> Model Class Initialized
INFO - 2018-03-31 20:22:15 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:45 --> Config Class Initialized
INFO - 2018-03-31 20:22:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:45 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:45 --> URI Class Initialized
INFO - 2018-03-31 20:22:45 --> Router Class Initialized
INFO - 2018-03-31 20:22:45 --> Output Class Initialized
INFO - 2018-03-31 20:22:45 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:45 --> Input Class Initialized
INFO - 2018-03-31 20:22:45 --> Language Class Initialized
INFO - 2018-03-31 20:22:45 --> Loader Class Initialized
INFO - 2018-03-31 20:22:45 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:45 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:45 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Controller Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 20:22:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 20:22:45 --> Final output sent to browser
DEBUG - 2018-03-31 20:22:45 --> Total execution time: 0.2023
INFO - 2018-03-31 20:22:45 --> Config Class Initialized
INFO - 2018-03-31 20:22:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 20:22:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 20:22:45 --> Utf8 Class Initialized
INFO - 2018-03-31 20:22:45 --> URI Class Initialized
INFO - 2018-03-31 20:22:45 --> Router Class Initialized
INFO - 2018-03-31 20:22:45 --> Output Class Initialized
INFO - 2018-03-31 20:22:45 --> Security Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 20:22:45 --> Input Class Initialized
INFO - 2018-03-31 20:22:45 --> Language Class Initialized
INFO - 2018-03-31 20:22:45 --> Loader Class Initialized
INFO - 2018-03-31 20:22:45 --> Helper loaded: url_helper
INFO - 2018-03-31 20:22:45 --> Helper loaded: form_helper
INFO - 2018-03-31 20:22:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 20:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 20:22:45 --> Form Validation Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Controller Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
INFO - 2018-03-31 20:22:45 --> Model Class Initialized
DEBUG - 2018-03-31 20:22:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:43 --> Config Class Initialized
INFO - 2018-03-31 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:43 --> URI Class Initialized
INFO - 2018-03-31 23:34:43 --> Router Class Initialized
INFO - 2018-03-31 23:34:43 --> Output Class Initialized
INFO - 2018-03-31 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:43 --> Input Class Initialized
INFO - 2018-03-31 23:34:43 --> Language Class Initialized
INFO - 2018-03-31 23:34:43 --> Loader Class Initialized
INFO - 2018-03-31 23:34:43 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:43 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:43 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:43 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:43 --> Model Class Initialized
INFO - 2018-03-31 23:34:43 --> Controller Class Initialized
INFO - 2018-03-31 23:34:43 --> Model Class Initialized
INFO - 2018-03-31 23:34:43 --> Model Class Initialized
INFO - 2018-03-31 23:34:43 --> Model Class Initialized
INFO - 2018-03-31 23:34:43 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:43 --> Config Class Initialized
INFO - 2018-03-31 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:43 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:43 --> URI Class Initialized
INFO - 2018-03-31 23:34:43 --> Router Class Initialized
INFO - 2018-03-31 23:34:43 --> Output Class Initialized
INFO - 2018-03-31 23:34:43 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:43 --> Input Class Initialized
INFO - 2018-03-31 23:34:43 --> Language Class Initialized
INFO - 2018-03-31 23:34:43 --> Loader Class Initialized
INFO - 2018-03-31 23:34:43 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:43 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:43 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:44 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:44 --> Model Class Initialized
INFO - 2018-03-31 23:34:44 --> Controller Class Initialized
INFO - 2018-03-31 23:34:44 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:34:44 --> Final output sent to browser
DEBUG - 2018-03-31 23:34:44 --> Total execution time: 0.0553
INFO - 2018-03-31 23:34:45 --> Config Class Initialized
INFO - 2018-03-31 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:45 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:45 --> URI Class Initialized
INFO - 2018-03-31 23:34:45 --> Router Class Initialized
INFO - 2018-03-31 23:34:45 --> Output Class Initialized
INFO - 2018-03-31 23:34:45 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:45 --> Input Class Initialized
INFO - 2018-03-31 23:34:45 --> Language Class Initialized
INFO - 2018-03-31 23:34:45 --> Loader Class Initialized
INFO - 2018-03-31 23:34:45 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:45 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:45 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:45 --> Model Class Initialized
INFO - 2018-03-31 23:34:45 --> Controller Class Initialized
INFO - 2018-03-31 23:34:45 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 23:34:46 --> Config Class Initialized
INFO - 2018-03-31 23:34:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:46 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:46 --> URI Class Initialized
DEBUG - 2018-03-31 23:34:46 --> No URI present. Default controller set.
INFO - 2018-03-31 23:34:46 --> Router Class Initialized
INFO - 2018-03-31 23:34:46 --> Output Class Initialized
INFO - 2018-03-31 23:34:46 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:46 --> Input Class Initialized
INFO - 2018-03-31 23:34:46 --> Language Class Initialized
INFO - 2018-03-31 23:34:46 --> Loader Class Initialized
INFO - 2018-03-31 23:34:46 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:46 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:46 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:46 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Controller Class Initialized
INFO - 2018-03-31 23:34:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:34:46 --> Final output sent to browser
DEBUG - 2018-03-31 23:34:46 --> Total execution time: 0.1050
INFO - 2018-03-31 23:34:46 --> Config Class Initialized
INFO - 2018-03-31 23:34:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:46 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:46 --> URI Class Initialized
INFO - 2018-03-31 23:34:46 --> Router Class Initialized
INFO - 2018-03-31 23:34:46 --> Output Class Initialized
INFO - 2018-03-31 23:34:46 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:46 --> Input Class Initialized
INFO - 2018-03-31 23:34:46 --> Language Class Initialized
INFO - 2018-03-31 23:34:46 --> Loader Class Initialized
INFO - 2018-03-31 23:34:46 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:46 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:46 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:46 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Controller Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
INFO - 2018-03-31 23:34:46 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:48 --> Config Class Initialized
INFO - 2018-03-31 23:34:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:48 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:48 --> URI Class Initialized
INFO - 2018-03-31 23:34:48 --> Router Class Initialized
INFO - 2018-03-31 23:34:48 --> Output Class Initialized
INFO - 2018-03-31 23:34:48 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:48 --> Input Class Initialized
INFO - 2018-03-31 23:34:48 --> Language Class Initialized
INFO - 2018-03-31 23:34:48 --> Loader Class Initialized
INFO - 2018-03-31 23:34:48 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:48 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:48 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:48 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:48 --> Model Class Initialized
INFO - 2018-03-31 23:34:48 --> Controller Class Initialized
INFO - 2018-03-31 23:34:48 --> Model Class Initialized
INFO - 2018-03-31 23:34:48 --> Model Class Initialized
INFO - 2018-03-31 23:34:48 --> Model Class Initialized
INFO - 2018-03-31 23:34:48 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:34:48 --> Final output sent to browser
DEBUG - 2018-03-31 23:34:48 --> Total execution time: 0.1033
INFO - 2018-03-31 23:34:49 --> Config Class Initialized
INFO - 2018-03-31 23:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:49 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:49 --> URI Class Initialized
INFO - 2018-03-31 23:34:49 --> Router Class Initialized
INFO - 2018-03-31 23:34:49 --> Output Class Initialized
INFO - 2018-03-31 23:34:49 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:49 --> Input Class Initialized
INFO - 2018-03-31 23:34:49 --> Language Class Initialized
INFO - 2018-03-31 23:34:49 --> Loader Class Initialized
INFO - 2018-03-31 23:34:49 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:49 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:49 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Controller Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:34:49 --> Final output sent to browser
DEBUG - 2018-03-31 23:34:49 --> Total execution time: 0.0966
INFO - 2018-03-31 23:34:49 --> Config Class Initialized
INFO - 2018-03-31 23:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:49 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:49 --> URI Class Initialized
INFO - 2018-03-31 23:34:49 --> Router Class Initialized
INFO - 2018-03-31 23:34:49 --> Output Class Initialized
INFO - 2018-03-31 23:34:49 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:49 --> Input Class Initialized
INFO - 2018-03-31 23:34:49 --> Language Class Initialized
INFO - 2018-03-31 23:34:49 --> Loader Class Initialized
INFO - 2018-03-31 23:34:49 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:49 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:49 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Controller Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
INFO - 2018-03-31 23:34:49 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:56 --> Config Class Initialized
INFO - 2018-03-31 23:34:56 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:34:56 --> Utf8 Class Initialized
INFO - 2018-03-31 23:34:56 --> URI Class Initialized
INFO - 2018-03-31 23:34:56 --> Router Class Initialized
INFO - 2018-03-31 23:34:56 --> Output Class Initialized
INFO - 2018-03-31 23:34:56 --> Security Class Initialized
DEBUG - 2018-03-31 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:34:56 --> Input Class Initialized
INFO - 2018-03-31 23:34:56 --> Language Class Initialized
INFO - 2018-03-31 23:34:56 --> Loader Class Initialized
INFO - 2018-03-31 23:34:56 --> Helper loaded: url_helper
INFO - 2018-03-31 23:34:56 --> Helper loaded: form_helper
INFO - 2018-03-31 23:34:56 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:34:56 --> Form Validation Class Initialized
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
INFO - 2018-03-31 23:34:56 --> Controller Class Initialized
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
DEBUG - 2018-03-31 23:34:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:34:56 --> Model Class Initialized
ERROR - 2018-03-31 23:34:56 --> Severity: Notice --> Undefined index: colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 278
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 292
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 292
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 298
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 304
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 310
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 316
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 322
ERROR - 2018-03-31 23:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 366
ERROR - 2018-03-31 23:34:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 422
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 425
ERROR - 2018-03-31 23:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 425
ERROR - 2018-03-31 23:34:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 425
INFO - 2018-03-31 23:34:57 --> Final output sent to browser
DEBUG - 2018-03-31 23:34:57 --> Total execution time: 1.1626
INFO - 2018-03-31 23:36:01 --> Config Class Initialized
INFO - 2018-03-31 23:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:36:01 --> Utf8 Class Initialized
INFO - 2018-03-31 23:36:01 --> URI Class Initialized
INFO - 2018-03-31 23:36:01 --> Router Class Initialized
INFO - 2018-03-31 23:36:01 --> Output Class Initialized
INFO - 2018-03-31 23:36:01 --> Security Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:36:01 --> Input Class Initialized
INFO - 2018-03-31 23:36:01 --> Language Class Initialized
INFO - 2018-03-31 23:36:01 --> Loader Class Initialized
INFO - 2018-03-31 23:36:01 --> Helper loaded: url_helper
INFO - 2018-03-31 23:36:01 --> Helper loaded: form_helper
INFO - 2018-03-31 23:36:01 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:36:01 --> Form Validation Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Controller Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:36:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:36:01 --> Final output sent to browser
DEBUG - 2018-03-31 23:36:01 --> Total execution time: 0.0958
INFO - 2018-03-31 23:36:01 --> Config Class Initialized
INFO - 2018-03-31 23:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:36:01 --> Utf8 Class Initialized
INFO - 2018-03-31 23:36:01 --> URI Class Initialized
INFO - 2018-03-31 23:36:01 --> Router Class Initialized
INFO - 2018-03-31 23:36:01 --> Output Class Initialized
INFO - 2018-03-31 23:36:01 --> Security Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:36:01 --> Input Class Initialized
INFO - 2018-03-31 23:36:01 --> Language Class Initialized
INFO - 2018-03-31 23:36:01 --> Loader Class Initialized
INFO - 2018-03-31 23:36:01 --> Helper loaded: url_helper
INFO - 2018-03-31 23:36:01 --> Helper loaded: form_helper
INFO - 2018-03-31 23:36:01 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:36:01 --> Form Validation Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Controller Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
INFO - 2018-03-31 23:36:01 --> Model Class Initialized
DEBUG - 2018-03-31 23:36:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:36:06 --> Config Class Initialized
INFO - 2018-03-31 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:36:06 --> Utf8 Class Initialized
INFO - 2018-03-31 23:36:06 --> URI Class Initialized
INFO - 2018-03-31 23:36:06 --> Router Class Initialized
INFO - 2018-03-31 23:36:06 --> Output Class Initialized
INFO - 2018-03-31 23:36:06 --> Security Class Initialized
DEBUG - 2018-03-31 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:36:06 --> Input Class Initialized
INFO - 2018-03-31 23:36:06 --> Language Class Initialized
INFO - 2018-03-31 23:36:06 --> Loader Class Initialized
INFO - 2018-03-31 23:36:06 --> Helper loaded: url_helper
INFO - 2018-03-31 23:36:06 --> Helper loaded: form_helper
INFO - 2018-03-31 23:36:06 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:36:06 --> Form Validation Class Initialized
INFO - 2018-03-31 23:36:06 --> Model Class Initialized
INFO - 2018-03-31 23:36:06 --> Controller Class Initialized
INFO - 2018-03-31 23:36:06 --> Model Class Initialized
INFO - 2018-03-31 23:36:06 --> Model Class Initialized
INFO - 2018-03-31 23:36:06 --> Model Class Initialized
INFO - 2018-03-31 23:36:06 --> Model Class Initialized
DEBUG - 2018-03-31 23:36:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:36:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
ERROR - 2018-03-31 23:36:06 --> Severity: Notice --> Undefined index: from D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1759
ERROR - 2018-03-31 23:36:06 --> Query error: Unknown column 'proyecto.fecha_incio' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
WHERE `proyecto`.`fecha_incio` = `Array`
ORDER BY `proyecto`.`proyecto_estado_id` ASC, `proyecto`.`fecha_inicio` ASC
INFO - 2018-03-31 23:36:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 23:38:24 --> Config Class Initialized
INFO - 2018-03-31 23:38:24 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:38:24 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:38:24 --> Utf8 Class Initialized
INFO - 2018-03-31 23:38:24 --> URI Class Initialized
INFO - 2018-03-31 23:38:24 --> Router Class Initialized
INFO - 2018-03-31 23:38:24 --> Output Class Initialized
INFO - 2018-03-31 23:38:24 --> Security Class Initialized
DEBUG - 2018-03-31 23:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:38:24 --> Input Class Initialized
INFO - 2018-03-31 23:38:24 --> Language Class Initialized
INFO - 2018-03-31 23:38:24 --> Loader Class Initialized
INFO - 2018-03-31 23:38:24 --> Helper loaded: url_helper
INFO - 2018-03-31 23:38:24 --> Helper loaded: form_helper
INFO - 2018-03-31 23:38:24 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:38:24 --> Form Validation Class Initialized
INFO - 2018-03-31 23:38:24 --> Model Class Initialized
INFO - 2018-03-31 23:38:24 --> Controller Class Initialized
INFO - 2018-03-31 23:38:24 --> Model Class Initialized
INFO - 2018-03-31 23:38:24 --> Model Class Initialized
INFO - 2018-03-31 23:38:24 --> Model Class Initialized
INFO - 2018-03-31 23:38:24 --> Model Class Initialized
DEBUG - 2018-03-31 23:38:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:39:12 --> Config Class Initialized
INFO - 2018-03-31 23:39:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:39:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:39:12 --> Utf8 Class Initialized
INFO - 2018-03-31 23:39:12 --> URI Class Initialized
INFO - 2018-03-31 23:39:12 --> Router Class Initialized
INFO - 2018-03-31 23:39:12 --> Output Class Initialized
INFO - 2018-03-31 23:39:12 --> Security Class Initialized
DEBUG - 2018-03-31 23:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:39:12 --> Input Class Initialized
INFO - 2018-03-31 23:39:12 --> Language Class Initialized
INFO - 2018-03-31 23:39:12 --> Loader Class Initialized
INFO - 2018-03-31 23:39:12 --> Helper loaded: url_helper
INFO - 2018-03-31 23:39:12 --> Helper loaded: form_helper
INFO - 2018-03-31 23:39:12 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:39:12 --> Form Validation Class Initialized
INFO - 2018-03-31 23:39:12 --> Model Class Initialized
INFO - 2018-03-31 23:39:12 --> Controller Class Initialized
INFO - 2018-03-31 23:39:12 --> Model Class Initialized
INFO - 2018-03-31 23:39:12 --> Model Class Initialized
INFO - 2018-03-31 23:39:12 --> Model Class Initialized
INFO - 2018-03-31 23:39:12 --> Model Class Initialized
DEBUG - 2018-03-31 23:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:39:58 --> Config Class Initialized
INFO - 2018-03-31 23:39:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:39:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:39:58 --> Utf8 Class Initialized
INFO - 2018-03-31 23:39:58 --> URI Class Initialized
INFO - 2018-03-31 23:39:58 --> Router Class Initialized
INFO - 2018-03-31 23:39:58 --> Output Class Initialized
INFO - 2018-03-31 23:39:58 --> Security Class Initialized
DEBUG - 2018-03-31 23:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:39:58 --> Input Class Initialized
INFO - 2018-03-31 23:39:58 --> Language Class Initialized
INFO - 2018-03-31 23:39:58 --> Loader Class Initialized
INFO - 2018-03-31 23:39:58 --> Helper loaded: url_helper
INFO - 2018-03-31 23:39:58 --> Helper loaded: form_helper
INFO - 2018-03-31 23:39:58 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:39:58 --> Form Validation Class Initialized
INFO - 2018-03-31 23:39:58 --> Model Class Initialized
INFO - 2018-03-31 23:39:58 --> Controller Class Initialized
INFO - 2018-03-31 23:39:58 --> Model Class Initialized
INFO - 2018-03-31 23:39:58 --> Model Class Initialized
INFO - 2018-03-31 23:39:58 --> Model Class Initialized
INFO - 2018-03-31 23:39:58 --> Model Class Initialized
DEBUG - 2018-03-31 23:39:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:39:58 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
ERROR - 2018-03-31 23:39:58 --> Severity: Notice --> Undefined index: from D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1760
ERROR - 2018-03-31 23:39:58 --> Query error: Unknown column 'proyecto.fecha_incio' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
WHERE `proyecto`.`fecha_incio` = `Array`
ORDER BY `proyecto`.`proyecto_estado_id` ASC, `proyecto`.`fecha_inicio` ASC
INFO - 2018-03-31 23:39:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 23:41:55 --> Config Class Initialized
INFO - 2018-03-31 23:41:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:41:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:41:55 --> Utf8 Class Initialized
INFO - 2018-03-31 23:41:55 --> URI Class Initialized
INFO - 2018-03-31 23:41:55 --> Router Class Initialized
INFO - 2018-03-31 23:41:55 --> Output Class Initialized
INFO - 2018-03-31 23:41:55 --> Security Class Initialized
DEBUG - 2018-03-31 23:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:41:55 --> Input Class Initialized
INFO - 2018-03-31 23:41:55 --> Language Class Initialized
INFO - 2018-03-31 23:41:55 --> Loader Class Initialized
INFO - 2018-03-31 23:41:55 --> Helper loaded: url_helper
INFO - 2018-03-31 23:41:55 --> Helper loaded: form_helper
INFO - 2018-03-31 23:41:56 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:41:56 --> Form Validation Class Initialized
INFO - 2018-03-31 23:41:56 --> Model Class Initialized
INFO - 2018-03-31 23:41:56 --> Controller Class Initialized
INFO - 2018-03-31 23:41:56 --> Model Class Initialized
INFO - 2018-03-31 23:41:56 --> Model Class Initialized
INFO - 2018-03-31 23:41:56 --> Model Class Initialized
INFO - 2018-03-31 23:41:56 --> Model Class Initialized
DEBUG - 2018-03-31 23:41:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:41:56 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
ERROR - 2018-03-31 23:41:56 --> Severity: Notice --> Undefined index: from D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1760
ERROR - 2018-03-31 23:41:56 --> Query error: Unknown column 'proyecto.fecha_incio' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
WHERE `proyecto`.`fecha_incio` = `Array`
ORDER BY `proyecto`.`proyecto_estado_id` ASC, `proyecto`.`fecha_inicio` ASC
INFO - 2018-03-31 23:41:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 23:42:01 --> Config Class Initialized
INFO - 2018-03-31 23:42:01 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:01 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:01 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:01 --> URI Class Initialized
INFO - 2018-03-31 23:42:01 --> Router Class Initialized
INFO - 2018-03-31 23:42:01 --> Output Class Initialized
INFO - 2018-03-31 23:42:01 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:01 --> Input Class Initialized
INFO - 2018-03-31 23:42:01 --> Language Class Initialized
INFO - 2018-03-31 23:42:01 --> Loader Class Initialized
INFO - 2018-03-31 23:42:01 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:01 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:01 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:01 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:01 --> Model Class Initialized
INFO - 2018-03-31 23:42:01 --> Controller Class Initialized
INFO - 2018-03-31 23:42:01 --> Model Class Initialized
INFO - 2018-03-31 23:42:01 --> Model Class Initialized
INFO - 2018-03-31 23:42:01 --> Model Class Initialized
INFO - 2018-03-31 23:42:01 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:42:01 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
ERROR - 2018-03-31 23:42:01 --> Severity: Notice --> Undefined index: from D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1760
ERROR - 2018-03-31 23:42:02 --> Query error: Unknown column 'proyecto.fecha_incio' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
WHERE `proyecto`.`fecha_incio` = `Array`
ORDER BY `proyecto`.`proyecto_estado_id` ASC, `proyecto`.`fecha_inicio` ASC
INFO - 2018-03-31 23:42:02 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 23:42:03 --> Config Class Initialized
INFO - 2018-03-31 23:42:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:03 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:03 --> URI Class Initialized
INFO - 2018-03-31 23:42:03 --> Router Class Initialized
INFO - 2018-03-31 23:42:03 --> Output Class Initialized
INFO - 2018-03-31 23:42:03 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:03 --> Input Class Initialized
INFO - 2018-03-31 23:42:03 --> Language Class Initialized
INFO - 2018-03-31 23:42:03 --> Loader Class Initialized
INFO - 2018-03-31 23:42:03 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:03 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:03 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:03 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:03 --> Model Class Initialized
INFO - 2018-03-31 23:42:03 --> Controller Class Initialized
INFO - 2018-03-31 23:42:03 --> Model Class Initialized
INFO - 2018-03-31 23:42:03 --> Model Class Initialized
INFO - 2018-03-31 23:42:03 --> Model Class Initialized
INFO - 2018-03-31 23:42:03 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:42:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 683
ERROR - 2018-03-31 23:42:03 --> Severity: Notice --> Undefined index: from D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1760
ERROR - 2018-03-31 23:42:03 --> Query error: Unknown column 'proyecto.fecha_incio' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto`.`proyecto_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
WHERE `proyecto`.`fecha_incio` = `Array`
ORDER BY `proyecto`.`proyecto_estado_id` ASC, `proyecto`.`fecha_inicio` ASC
INFO - 2018-03-31 23:42:03 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-31 23:42:05 --> Config Class Initialized
INFO - 2018-03-31 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:05 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:05 --> URI Class Initialized
INFO - 2018-03-31 23:42:05 --> Router Class Initialized
INFO - 2018-03-31 23:42:05 --> Output Class Initialized
INFO - 2018-03-31 23:42:05 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:05 --> Input Class Initialized
INFO - 2018-03-31 23:42:05 --> Language Class Initialized
INFO - 2018-03-31 23:42:05 --> Loader Class Initialized
INFO - 2018-03-31 23:42:05 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:05 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:05 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Controller Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:42:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-31 23:42:05 --> Final output sent to browser
DEBUG - 2018-03-31 23:42:05 --> Total execution time: 0.1024
INFO - 2018-03-31 23:42:05 --> Config Class Initialized
INFO - 2018-03-31 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:05 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:05 --> URI Class Initialized
INFO - 2018-03-31 23:42:05 --> Router Class Initialized
INFO - 2018-03-31 23:42:05 --> Output Class Initialized
INFO - 2018-03-31 23:42:05 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:05 --> Input Class Initialized
INFO - 2018-03-31 23:42:05 --> Language Class Initialized
INFO - 2018-03-31 23:42:05 --> Loader Class Initialized
INFO - 2018-03-31 23:42:05 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:05 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:05 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Controller Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
INFO - 2018-03-31 23:42:05 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:42:07 --> Config Class Initialized
INFO - 2018-03-31 23:42:07 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:07 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:07 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:07 --> URI Class Initialized
INFO - 2018-03-31 23:42:07 --> Router Class Initialized
INFO - 2018-03-31 23:42:07 --> Output Class Initialized
INFO - 2018-03-31 23:42:07 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:07 --> Input Class Initialized
INFO - 2018-03-31 23:42:07 --> Language Class Initialized
INFO - 2018-03-31 23:42:07 --> Loader Class Initialized
INFO - 2018-03-31 23:42:07 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:07 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:07 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:07 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:07 --> Model Class Initialized
INFO - 2018-03-31 23:42:07 --> Controller Class Initialized
INFO - 2018-03-31 23:42:07 --> Model Class Initialized
INFO - 2018-03-31 23:42:07 --> Model Class Initialized
INFO - 2018-03-31 23:42:07 --> Model Class Initialized
INFO - 2018-03-31 23:42:07 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:42:07 --> Severity: 4096 --> Argument 1 passed to PhpOffice\PhpSpreadsheet\Style\Color::applyFromArray() must be of the type array, string given, called in D:\xampp\htdocs\instateccr\controlcostos\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\Style\Font.php on line 192 and defined D:\xampp\htdocs\instateccr\controlcostos\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\Style\Color.php 99
INFO - 2018-03-31 23:42:07 --> Final output sent to browser
DEBUG - 2018-03-31 23:42:07 --> Total execution time: 0.3231
INFO - 2018-03-31 23:42:20 --> Config Class Initialized
INFO - 2018-03-31 23:42:20 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:42:20 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:42:20 --> Utf8 Class Initialized
INFO - 2018-03-31 23:42:20 --> URI Class Initialized
INFO - 2018-03-31 23:42:20 --> Router Class Initialized
INFO - 2018-03-31 23:42:20 --> Output Class Initialized
INFO - 2018-03-31 23:42:20 --> Security Class Initialized
DEBUG - 2018-03-31 23:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:42:20 --> Input Class Initialized
INFO - 2018-03-31 23:42:20 --> Language Class Initialized
INFO - 2018-03-31 23:42:20 --> Loader Class Initialized
INFO - 2018-03-31 23:42:20 --> Helper loaded: url_helper
INFO - 2018-03-31 23:42:20 --> Helper loaded: form_helper
INFO - 2018-03-31 23:42:20 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:42:20 --> Form Validation Class Initialized
INFO - 2018-03-31 23:42:20 --> Model Class Initialized
INFO - 2018-03-31 23:42:20 --> Controller Class Initialized
INFO - 2018-03-31 23:42:20 --> Model Class Initialized
INFO - 2018-03-31 23:42:20 --> Model Class Initialized
INFO - 2018-03-31 23:42:20 --> Model Class Initialized
INFO - 2018-03-31 23:42:20 --> Model Class Initialized
DEBUG - 2018-03-31 23:42:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-31 23:42:20 --> Severity: 4096 --> Argument 1 passed to PhpOffice\PhpSpreadsheet\Style\Color::applyFromArray() must be of the type array, string given, called in D:\xampp\htdocs\instateccr\controlcostos\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\Style\Font.php on line 192 and defined D:\xampp\htdocs\instateccr\controlcostos\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\Style\Color.php 99
INFO - 2018-03-31 23:42:20 --> Final output sent to browser
DEBUG - 2018-03-31 23:42:20 --> Total execution time: 0.3285
INFO - 2018-03-31 23:45:44 --> Config Class Initialized
INFO - 2018-03-31 23:45:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:45:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:45:44 --> Utf8 Class Initialized
INFO - 2018-03-31 23:45:44 --> URI Class Initialized
INFO - 2018-03-31 23:45:44 --> Router Class Initialized
INFO - 2018-03-31 23:45:44 --> Output Class Initialized
INFO - 2018-03-31 23:45:44 --> Security Class Initialized
DEBUG - 2018-03-31 23:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:45:44 --> Input Class Initialized
INFO - 2018-03-31 23:45:44 --> Language Class Initialized
INFO - 2018-03-31 23:45:44 --> Loader Class Initialized
INFO - 2018-03-31 23:45:44 --> Helper loaded: url_helper
INFO - 2018-03-31 23:45:44 --> Helper loaded: form_helper
INFO - 2018-03-31 23:45:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:45:44 --> Form Validation Class Initialized
INFO - 2018-03-31 23:45:44 --> Model Class Initialized
INFO - 2018-03-31 23:45:44 --> Controller Class Initialized
INFO - 2018-03-31 23:45:45 --> Model Class Initialized
INFO - 2018-03-31 23:45:45 --> Model Class Initialized
INFO - 2018-03-31 23:45:45 --> Model Class Initialized
INFO - 2018-03-31 23:45:45 --> Model Class Initialized
DEBUG - 2018-03-31 23:45:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:45:45 --> Final output sent to browser
DEBUG - 2018-03-31 23:45:45 --> Total execution time: 0.2856
INFO - 2018-03-31 23:47:11 --> Config Class Initialized
INFO - 2018-03-31 23:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:11 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:11 --> URI Class Initialized
INFO - 2018-03-31 23:47:11 --> Router Class Initialized
INFO - 2018-03-31 23:47:11 --> Output Class Initialized
INFO - 2018-03-31 23:47:11 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:11 --> Input Class Initialized
INFO - 2018-03-31 23:47:11 --> Language Class Initialized
INFO - 2018-03-31 23:47:11 --> Loader Class Initialized
INFO - 2018-03-31 23:47:11 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:11 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:11 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:11 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:11 --> Model Class Initialized
INFO - 2018-03-31 23:47:11 --> Controller Class Initialized
INFO - 2018-03-31 23:47:11 --> Model Class Initialized
INFO - 2018-03-31 23:47:11 --> Model Class Initialized
INFO - 2018-03-31 23:47:11 --> Model Class Initialized
INFO - 2018-03-31 23:47:11 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:12 --> Final output sent to browser
DEBUG - 2018-03-31 23:47:12 --> Total execution time: 0.3026
INFO - 2018-03-31 23:47:27 --> Config Class Initialized
INFO - 2018-03-31 23:47:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:27 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:27 --> URI Class Initialized
INFO - 2018-03-31 23:47:27 --> Router Class Initialized
INFO - 2018-03-31 23:47:27 --> Output Class Initialized
INFO - 2018-03-31 23:47:27 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:27 --> Input Class Initialized
INFO - 2018-03-31 23:47:27 --> Language Class Initialized
INFO - 2018-03-31 23:47:27 --> Loader Class Initialized
INFO - 2018-03-31 23:47:27 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:27 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:27 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:27 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:27 --> Model Class Initialized
INFO - 2018-03-31 23:47:27 --> Controller Class Initialized
INFO - 2018-03-31 23:47:27 --> Model Class Initialized
INFO - 2018-03-31 23:47:27 --> Model Class Initialized
INFO - 2018-03-31 23:47:27 --> Model Class Initialized
INFO - 2018-03-31 23:47:27 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:29 --> Config Class Initialized
INFO - 2018-03-31 23:47:29 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:29 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:29 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:29 --> URI Class Initialized
INFO - 2018-03-31 23:47:29 --> Router Class Initialized
INFO - 2018-03-31 23:47:29 --> Output Class Initialized
INFO - 2018-03-31 23:47:29 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:29 --> Input Class Initialized
INFO - 2018-03-31 23:47:29 --> Language Class Initialized
INFO - 2018-03-31 23:47:29 --> Loader Class Initialized
INFO - 2018-03-31 23:47:29 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:29 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:29 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:29 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:29 --> Model Class Initialized
INFO - 2018-03-31 23:47:29 --> Controller Class Initialized
INFO - 2018-03-31 23:47:29 --> Model Class Initialized
INFO - 2018-03-31 23:47:29 --> Model Class Initialized
INFO - 2018-03-31 23:47:29 --> Model Class Initialized
INFO - 2018-03-31 23:47:29 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:30 --> Config Class Initialized
INFO - 2018-03-31 23:47:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:30 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:30 --> URI Class Initialized
INFO - 2018-03-31 23:47:30 --> Final output sent to browser
DEBUG - 2018-03-31 23:47:30 --> Total execution time: 0.1850
INFO - 2018-03-31 23:47:30 --> Router Class Initialized
INFO - 2018-03-31 23:47:30 --> Output Class Initialized
INFO - 2018-03-31 23:47:30 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:30 --> Input Class Initialized
INFO - 2018-03-31 23:47:30 --> Language Class Initialized
INFO - 2018-03-31 23:47:30 --> Loader Class Initialized
INFO - 2018-03-31 23:47:30 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:30 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:30 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:30 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:30 --> Model Class Initialized
INFO - 2018-03-31 23:47:30 --> Controller Class Initialized
INFO - 2018-03-31 23:47:30 --> Model Class Initialized
INFO - 2018-03-31 23:47:30 --> Model Class Initialized
INFO - 2018-03-31 23:47:30 --> Model Class Initialized
INFO - 2018-03-31 23:47:30 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:30 --> Final output sent to browser
DEBUG - 2018-03-31 23:47:30 --> Total execution time: 0.1791
INFO - 2018-03-31 23:47:45 --> Config Class Initialized
INFO - 2018-03-31 23:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:45 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:45 --> URI Class Initialized
INFO - 2018-03-31 23:47:45 --> Router Class Initialized
INFO - 2018-03-31 23:47:45 --> Output Class Initialized
INFO - 2018-03-31 23:47:45 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:45 --> Input Class Initialized
INFO - 2018-03-31 23:47:45 --> Language Class Initialized
INFO - 2018-03-31 23:47:45 --> Loader Class Initialized
INFO - 2018-03-31 23:47:45 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:45 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:45 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:45 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:45 --> Model Class Initialized
INFO - 2018-03-31 23:47:45 --> Controller Class Initialized
INFO - 2018-03-31 23:47:45 --> Model Class Initialized
INFO - 2018-03-31 23:47:45 --> Model Class Initialized
INFO - 2018-03-31 23:47:45 --> Model Class Initialized
INFO - 2018-03-31 23:47:45 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:49 --> Config Class Initialized
INFO - 2018-03-31 23:47:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:49 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:49 --> URI Class Initialized
INFO - 2018-03-31 23:47:49 --> Router Class Initialized
INFO - 2018-03-31 23:47:49 --> Output Class Initialized
INFO - 2018-03-31 23:47:49 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:49 --> Input Class Initialized
INFO - 2018-03-31 23:47:49 --> Language Class Initialized
INFO - 2018-03-31 23:47:49 --> Loader Class Initialized
INFO - 2018-03-31 23:47:49 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:49 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:49 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:49 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
INFO - 2018-03-31 23:47:49 --> Controller Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
INFO - 2018-03-31 23:47:49 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:50 --> Config Class Initialized
INFO - 2018-03-31 23:47:50 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:50 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:50 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:50 --> URI Class Initialized
INFO - 2018-03-31 23:47:50 --> Router Class Initialized
INFO - 2018-03-31 23:47:50 --> Output Class Initialized
INFO - 2018-03-31 23:47:50 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:50 --> Input Class Initialized
INFO - 2018-03-31 23:47:50 --> Language Class Initialized
INFO - 2018-03-31 23:47:50 --> Loader Class Initialized
INFO - 2018-03-31 23:47:50 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:50 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:50 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:50 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
INFO - 2018-03-31 23:47:50 --> Controller Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
INFO - 2018-03-31 23:47:50 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:52 --> Config Class Initialized
INFO - 2018-03-31 23:47:52 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:52 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:52 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:52 --> URI Class Initialized
INFO - 2018-03-31 23:47:52 --> Router Class Initialized
INFO - 2018-03-31 23:47:52 --> Output Class Initialized
INFO - 2018-03-31 23:47:52 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:52 --> Input Class Initialized
INFO - 2018-03-31 23:47:52 --> Language Class Initialized
INFO - 2018-03-31 23:47:52 --> Loader Class Initialized
INFO - 2018-03-31 23:47:52 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:52 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:52 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:52 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:52 --> Model Class Initialized
INFO - 2018-03-31 23:47:52 --> Controller Class Initialized
INFO - 2018-03-31 23:47:52 --> Model Class Initialized
INFO - 2018-03-31 23:47:52 --> Model Class Initialized
INFO - 2018-03-31 23:47:52 --> Model Class Initialized
INFO - 2018-03-31 23:47:52 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:55 --> Config Class Initialized
INFO - 2018-03-31 23:47:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:47:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:47:55 --> Utf8 Class Initialized
INFO - 2018-03-31 23:47:55 --> URI Class Initialized
INFO - 2018-03-31 23:47:55 --> Router Class Initialized
INFO - 2018-03-31 23:47:55 --> Output Class Initialized
INFO - 2018-03-31 23:47:55 --> Security Class Initialized
DEBUG - 2018-03-31 23:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:47:55 --> Input Class Initialized
INFO - 2018-03-31 23:47:55 --> Language Class Initialized
INFO - 2018-03-31 23:47:55 --> Loader Class Initialized
INFO - 2018-03-31 23:47:55 --> Helper loaded: url_helper
INFO - 2018-03-31 23:47:55 --> Helper loaded: form_helper
INFO - 2018-03-31 23:47:55 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:47:55 --> Form Validation Class Initialized
INFO - 2018-03-31 23:47:55 --> Model Class Initialized
INFO - 2018-03-31 23:47:55 --> Controller Class Initialized
INFO - 2018-03-31 23:47:55 --> Model Class Initialized
INFO - 2018-03-31 23:47:55 --> Model Class Initialized
INFO - 2018-03-31 23:47:55 --> Model Class Initialized
INFO - 2018-03-31 23:47:55 --> Model Class Initialized
DEBUG - 2018-03-31 23:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:47:55 --> Final output sent to browser
DEBUG - 2018-03-31 23:47:55 --> Total execution time: 0.2160
INFO - 2018-03-31 23:50:32 --> Config Class Initialized
INFO - 2018-03-31 23:50:32 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:50:32 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:50:32 --> Utf8 Class Initialized
INFO - 2018-03-31 23:50:32 --> URI Class Initialized
INFO - 2018-03-31 23:50:32 --> Router Class Initialized
INFO - 2018-03-31 23:50:32 --> Output Class Initialized
INFO - 2018-03-31 23:50:32 --> Security Class Initialized
DEBUG - 2018-03-31 23:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:50:32 --> Input Class Initialized
INFO - 2018-03-31 23:50:32 --> Language Class Initialized
INFO - 2018-03-31 23:50:32 --> Loader Class Initialized
INFO - 2018-03-31 23:50:32 --> Helper loaded: url_helper
INFO - 2018-03-31 23:50:32 --> Helper loaded: form_helper
INFO - 2018-03-31 23:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:50:32 --> Form Validation Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
INFO - 2018-03-31 23:50:32 --> Controller Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
INFO - 2018-03-31 23:50:32 --> Model Class Initialized
DEBUG - 2018-03-31 23:50:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:50:44 --> Config Class Initialized
INFO - 2018-03-31 23:50:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:50:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:50:44 --> Utf8 Class Initialized
INFO - 2018-03-31 23:50:44 --> URI Class Initialized
INFO - 2018-03-31 23:50:44 --> Router Class Initialized
INFO - 2018-03-31 23:50:44 --> Output Class Initialized
INFO - 2018-03-31 23:50:44 --> Security Class Initialized
DEBUG - 2018-03-31 23:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:50:44 --> Input Class Initialized
INFO - 2018-03-31 23:50:44 --> Language Class Initialized
INFO - 2018-03-31 23:50:44 --> Loader Class Initialized
INFO - 2018-03-31 23:50:44 --> Helper loaded: url_helper
INFO - 2018-03-31 23:50:44 --> Helper loaded: form_helper
INFO - 2018-03-31 23:50:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:50:44 --> Form Validation Class Initialized
INFO - 2018-03-31 23:50:44 --> Model Class Initialized
INFO - 2018-03-31 23:50:44 --> Controller Class Initialized
INFO - 2018-03-31 23:50:44 --> Model Class Initialized
INFO - 2018-03-31 23:50:44 --> Model Class Initialized
INFO - 2018-03-31 23:50:44 --> Model Class Initialized
INFO - 2018-03-31 23:50:44 --> Model Class Initialized
DEBUG - 2018-03-31 23:50:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:50:46 --> Config Class Initialized
INFO - 2018-03-31 23:50:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:50:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:50:46 --> Utf8 Class Initialized
INFO - 2018-03-31 23:50:46 --> URI Class Initialized
INFO - 2018-03-31 23:50:46 --> Router Class Initialized
INFO - 2018-03-31 23:50:46 --> Output Class Initialized
INFO - 2018-03-31 23:50:46 --> Security Class Initialized
DEBUG - 2018-03-31 23:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:50:46 --> Input Class Initialized
INFO - 2018-03-31 23:50:46 --> Language Class Initialized
INFO - 2018-03-31 23:50:46 --> Loader Class Initialized
INFO - 2018-03-31 23:50:46 --> Helper loaded: url_helper
INFO - 2018-03-31 23:50:46 --> Helper loaded: form_helper
INFO - 2018-03-31 23:50:46 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:50:46 --> Form Validation Class Initialized
INFO - 2018-03-31 23:50:46 --> Model Class Initialized
INFO - 2018-03-31 23:50:46 --> Controller Class Initialized
INFO - 2018-03-31 23:50:46 --> Model Class Initialized
INFO - 2018-03-31 23:50:46 --> Model Class Initialized
INFO - 2018-03-31 23:50:46 --> Model Class Initialized
INFO - 2018-03-31 23:50:46 --> Model Class Initialized
DEBUG - 2018-03-31 23:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:50:47 --> Final output sent to browser
DEBUG - 2018-03-31 23:50:47 --> Total execution time: 0.2237
INFO - 2018-03-31 23:51:13 --> Config Class Initialized
INFO - 2018-03-31 23:51:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:51:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:51:13 --> Utf8 Class Initialized
INFO - 2018-03-31 23:51:13 --> URI Class Initialized
INFO - 2018-03-31 23:51:13 --> Router Class Initialized
INFO - 2018-03-31 23:51:13 --> Output Class Initialized
INFO - 2018-03-31 23:51:13 --> Security Class Initialized
DEBUG - 2018-03-31 23:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:51:13 --> Input Class Initialized
INFO - 2018-03-31 23:51:13 --> Language Class Initialized
INFO - 2018-03-31 23:51:13 --> Loader Class Initialized
INFO - 2018-03-31 23:51:13 --> Helper loaded: url_helper
INFO - 2018-03-31 23:51:13 --> Helper loaded: form_helper
INFO - 2018-03-31 23:51:13 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:51:13 --> Form Validation Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
INFO - 2018-03-31 23:51:13 --> Controller Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
INFO - 2018-03-31 23:51:13 --> Model Class Initialized
DEBUG - 2018-03-31 23:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:51:14 --> Config Class Initialized
INFO - 2018-03-31 23:51:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:51:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:51:14 --> Utf8 Class Initialized
INFO - 2018-03-31 23:51:14 --> URI Class Initialized
INFO - 2018-03-31 23:51:14 --> Router Class Initialized
INFO - 2018-03-31 23:51:14 --> Output Class Initialized
INFO - 2018-03-31 23:51:14 --> Security Class Initialized
DEBUG - 2018-03-31 23:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:51:14 --> Input Class Initialized
INFO - 2018-03-31 23:51:14 --> Language Class Initialized
INFO - 2018-03-31 23:51:14 --> Loader Class Initialized
INFO - 2018-03-31 23:51:14 --> Helper loaded: url_helper
INFO - 2018-03-31 23:51:14 --> Helper loaded: form_helper
INFO - 2018-03-31 23:51:14 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:51:14 --> Form Validation Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
INFO - 2018-03-31 23:51:14 --> Controller Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
INFO - 2018-03-31 23:51:14 --> Model Class Initialized
DEBUG - 2018-03-31 23:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:51:16 --> Config Class Initialized
INFO - 2018-03-31 23:51:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:51:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:51:16 --> Utf8 Class Initialized
INFO - 2018-03-31 23:51:16 --> URI Class Initialized
INFO - 2018-03-31 23:51:16 --> Router Class Initialized
INFO - 2018-03-31 23:51:16 --> Output Class Initialized
INFO - 2018-03-31 23:51:16 --> Security Class Initialized
DEBUG - 2018-03-31 23:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:51:16 --> Input Class Initialized
INFO - 2018-03-31 23:51:16 --> Language Class Initialized
INFO - 2018-03-31 23:51:16 --> Loader Class Initialized
INFO - 2018-03-31 23:51:16 --> Helper loaded: url_helper
INFO - 2018-03-31 23:51:16 --> Helper loaded: form_helper
INFO - 2018-03-31 23:51:16 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:51:16 --> Form Validation Class Initialized
INFO - 2018-03-31 23:51:16 --> Model Class Initialized
INFO - 2018-03-31 23:51:16 --> Controller Class Initialized
INFO - 2018-03-31 23:51:16 --> Model Class Initialized
INFO - 2018-03-31 23:51:16 --> Model Class Initialized
INFO - 2018-03-31 23:51:16 --> Model Class Initialized
INFO - 2018-03-31 23:51:16 --> Model Class Initialized
DEBUG - 2018-03-31 23:51:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:51:18 --> Config Class Initialized
INFO - 2018-03-31 23:51:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:51:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:51:18 --> Utf8 Class Initialized
INFO - 2018-03-31 23:51:18 --> URI Class Initialized
INFO - 2018-03-31 23:51:18 --> Router Class Initialized
INFO - 2018-03-31 23:51:18 --> Output Class Initialized
INFO - 2018-03-31 23:51:18 --> Security Class Initialized
DEBUG - 2018-03-31 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:51:18 --> Input Class Initialized
INFO - 2018-03-31 23:51:18 --> Language Class Initialized
INFO - 2018-03-31 23:51:18 --> Loader Class Initialized
INFO - 2018-03-31 23:51:18 --> Helper loaded: url_helper
INFO - 2018-03-31 23:51:18 --> Helper loaded: form_helper
INFO - 2018-03-31 23:51:18 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:51:18 --> Form Validation Class Initialized
INFO - 2018-03-31 23:51:18 --> Model Class Initialized
INFO - 2018-03-31 23:51:18 --> Controller Class Initialized
INFO - 2018-03-31 23:51:18 --> Model Class Initialized
INFO - 2018-03-31 23:51:18 --> Model Class Initialized
INFO - 2018-03-31 23:51:18 --> Model Class Initialized
INFO - 2018-03-31 23:51:18 --> Model Class Initialized
DEBUG - 2018-03-31 23:51:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:51:19 --> Final output sent to browser
DEBUG - 2018-03-31 23:51:19 --> Total execution time: 0.1814
INFO - 2018-03-31 23:53:40 --> Config Class Initialized
INFO - 2018-03-31 23:53:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:53:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:53:40 --> Utf8 Class Initialized
INFO - 2018-03-31 23:53:40 --> URI Class Initialized
INFO - 2018-03-31 23:53:40 --> Router Class Initialized
INFO - 2018-03-31 23:53:40 --> Output Class Initialized
INFO - 2018-03-31 23:53:40 --> Security Class Initialized
DEBUG - 2018-03-31 23:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:53:40 --> Input Class Initialized
INFO - 2018-03-31 23:53:40 --> Language Class Initialized
INFO - 2018-03-31 23:53:40 --> Loader Class Initialized
INFO - 2018-03-31 23:53:40 --> Helper loaded: url_helper
INFO - 2018-03-31 23:53:40 --> Helper loaded: form_helper
INFO - 2018-03-31 23:53:40 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:53:40 --> Form Validation Class Initialized
INFO - 2018-03-31 23:53:40 --> Model Class Initialized
INFO - 2018-03-31 23:53:40 --> Controller Class Initialized
INFO - 2018-03-31 23:53:40 --> Model Class Initialized
INFO - 2018-03-31 23:53:40 --> Model Class Initialized
INFO - 2018-03-31 23:53:40 --> Model Class Initialized
INFO - 2018-03-31 23:53:40 --> Model Class Initialized
DEBUG - 2018-03-31 23:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:53:41 --> Final output sent to browser
DEBUG - 2018-03-31 23:53:41 --> Total execution time: 0.5413
INFO - 2018-03-31 23:55:47 --> Config Class Initialized
INFO - 2018-03-31 23:55:47 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:55:47 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:55:47 --> Utf8 Class Initialized
INFO - 2018-03-31 23:55:47 --> URI Class Initialized
INFO - 2018-03-31 23:55:47 --> Router Class Initialized
INFO - 2018-03-31 23:55:47 --> Output Class Initialized
INFO - 2018-03-31 23:55:47 --> Security Class Initialized
DEBUG - 2018-03-31 23:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:55:47 --> Input Class Initialized
INFO - 2018-03-31 23:55:47 --> Language Class Initialized
INFO - 2018-03-31 23:55:47 --> Loader Class Initialized
INFO - 2018-03-31 23:55:47 --> Helper loaded: url_helper
INFO - 2018-03-31 23:55:47 --> Helper loaded: form_helper
INFO - 2018-03-31 23:55:47 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:55:47 --> Form Validation Class Initialized
INFO - 2018-03-31 23:55:47 --> Model Class Initialized
INFO - 2018-03-31 23:55:47 --> Controller Class Initialized
INFO - 2018-03-31 23:55:47 --> Model Class Initialized
INFO - 2018-03-31 23:55:47 --> Model Class Initialized
INFO - 2018-03-31 23:55:47 --> Model Class Initialized
INFO - 2018-03-31 23:55:47 --> Model Class Initialized
DEBUG - 2018-03-31 23:55:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:55:48 --> Final output sent to browser
DEBUG - 2018-03-31 23:55:48 --> Total execution time: 0.1737
INFO - 2018-03-31 23:56:58 --> Config Class Initialized
INFO - 2018-03-31 23:56:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:56:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:56:58 --> Utf8 Class Initialized
INFO - 2018-03-31 23:56:58 --> URI Class Initialized
INFO - 2018-03-31 23:56:58 --> Router Class Initialized
INFO - 2018-03-31 23:56:58 --> Output Class Initialized
INFO - 2018-03-31 23:56:58 --> Security Class Initialized
DEBUG - 2018-03-31 23:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:56:58 --> Input Class Initialized
INFO - 2018-03-31 23:56:58 --> Language Class Initialized
INFO - 2018-03-31 23:56:58 --> Loader Class Initialized
INFO - 2018-03-31 23:56:58 --> Helper loaded: url_helper
INFO - 2018-03-31 23:56:58 --> Helper loaded: form_helper
INFO - 2018-03-31 23:56:58 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:56:58 --> Form Validation Class Initialized
INFO - 2018-03-31 23:56:58 --> Model Class Initialized
INFO - 2018-03-31 23:56:58 --> Controller Class Initialized
INFO - 2018-03-31 23:56:58 --> Model Class Initialized
INFO - 2018-03-31 23:56:58 --> Model Class Initialized
INFO - 2018-03-31 23:56:58 --> Model Class Initialized
INFO - 2018-03-31 23:56:58 --> Model Class Initialized
DEBUG - 2018-03-31 23:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:56:58 --> Final output sent to browser
DEBUG - 2018-03-31 23:56:58 --> Total execution time: 0.1868
INFO - 2018-03-31 23:57:34 --> Config Class Initialized
INFO - 2018-03-31 23:57:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:57:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:57:34 --> Utf8 Class Initialized
INFO - 2018-03-31 23:57:34 --> URI Class Initialized
INFO - 2018-03-31 23:57:34 --> Router Class Initialized
INFO - 2018-03-31 23:57:34 --> Output Class Initialized
INFO - 2018-03-31 23:57:34 --> Security Class Initialized
DEBUG - 2018-03-31 23:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:57:34 --> Input Class Initialized
INFO - 2018-03-31 23:57:34 --> Language Class Initialized
INFO - 2018-03-31 23:57:34 --> Loader Class Initialized
INFO - 2018-03-31 23:57:34 --> Helper loaded: url_helper
INFO - 2018-03-31 23:57:34 --> Helper loaded: form_helper
INFO - 2018-03-31 23:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:57:34 --> Form Validation Class Initialized
INFO - 2018-03-31 23:57:34 --> Model Class Initialized
INFO - 2018-03-31 23:57:34 --> Controller Class Initialized
INFO - 2018-03-31 23:57:34 --> Model Class Initialized
INFO - 2018-03-31 23:57:34 --> Model Class Initialized
INFO - 2018-03-31 23:57:34 --> Model Class Initialized
INFO - 2018-03-31 23:57:34 --> Model Class Initialized
DEBUG - 2018-03-31 23:57:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:57:34 --> Final output sent to browser
DEBUG - 2018-03-31 23:57:34 --> Total execution time: 0.2337
INFO - 2018-03-31 23:57:53 --> Config Class Initialized
INFO - 2018-03-31 23:57:53 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:57:53 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:57:53 --> Utf8 Class Initialized
INFO - 2018-03-31 23:57:53 --> URI Class Initialized
INFO - 2018-03-31 23:57:53 --> Router Class Initialized
INFO - 2018-03-31 23:57:53 --> Output Class Initialized
INFO - 2018-03-31 23:57:53 --> Security Class Initialized
DEBUG - 2018-03-31 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:57:53 --> Input Class Initialized
INFO - 2018-03-31 23:57:53 --> Language Class Initialized
INFO - 2018-03-31 23:57:53 --> Loader Class Initialized
INFO - 2018-03-31 23:57:53 --> Helper loaded: url_helper
INFO - 2018-03-31 23:57:53 --> Helper loaded: form_helper
INFO - 2018-03-31 23:57:53 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:57:53 --> Form Validation Class Initialized
INFO - 2018-03-31 23:57:53 --> Model Class Initialized
INFO - 2018-03-31 23:57:53 --> Controller Class Initialized
INFO - 2018-03-31 23:57:53 --> Model Class Initialized
INFO - 2018-03-31 23:57:53 --> Model Class Initialized
INFO - 2018-03-31 23:57:53 --> Model Class Initialized
INFO - 2018-03-31 23:57:53 --> Model Class Initialized
DEBUG - 2018-03-31 23:57:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:57:54 --> Final output sent to browser
DEBUG - 2018-03-31 23:57:54 --> Total execution time: 0.1615
INFO - 2018-03-31 23:58:06 --> Config Class Initialized
INFO - 2018-03-31 23:58:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:58:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:58:06 --> Utf8 Class Initialized
INFO - 2018-03-31 23:58:06 --> URI Class Initialized
INFO - 2018-03-31 23:58:06 --> Router Class Initialized
INFO - 2018-03-31 23:58:06 --> Output Class Initialized
INFO - 2018-03-31 23:58:06 --> Security Class Initialized
DEBUG - 2018-03-31 23:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:58:06 --> Input Class Initialized
INFO - 2018-03-31 23:58:06 --> Language Class Initialized
INFO - 2018-03-31 23:58:06 --> Loader Class Initialized
INFO - 2018-03-31 23:58:06 --> Helper loaded: url_helper
INFO - 2018-03-31 23:58:06 --> Helper loaded: form_helper
INFO - 2018-03-31 23:58:06 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:58:06 --> Form Validation Class Initialized
INFO - 2018-03-31 23:58:06 --> Model Class Initialized
INFO - 2018-03-31 23:58:06 --> Controller Class Initialized
INFO - 2018-03-31 23:58:06 --> Model Class Initialized
INFO - 2018-03-31 23:58:06 --> Model Class Initialized
INFO - 2018-03-31 23:58:06 --> Model Class Initialized
INFO - 2018-03-31 23:58:06 --> Model Class Initialized
DEBUG - 2018-03-31 23:58:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:58:08 --> Config Class Initialized
INFO - 2018-03-31 23:58:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:58:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:58:08 --> Utf8 Class Initialized
INFO - 2018-03-31 23:58:08 --> URI Class Initialized
INFO - 2018-03-31 23:58:08 --> Router Class Initialized
INFO - 2018-03-31 23:58:08 --> Output Class Initialized
INFO - 2018-03-31 23:58:08 --> Security Class Initialized
DEBUG - 2018-03-31 23:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:58:08 --> Input Class Initialized
INFO - 2018-03-31 23:58:08 --> Language Class Initialized
INFO - 2018-03-31 23:58:08 --> Loader Class Initialized
INFO - 2018-03-31 23:58:08 --> Helper loaded: url_helper
INFO - 2018-03-31 23:58:08 --> Helper loaded: form_helper
INFO - 2018-03-31 23:58:08 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:58:08 --> Form Validation Class Initialized
INFO - 2018-03-31 23:58:08 --> Model Class Initialized
INFO - 2018-03-31 23:58:08 --> Controller Class Initialized
INFO - 2018-03-31 23:58:08 --> Model Class Initialized
INFO - 2018-03-31 23:58:08 --> Model Class Initialized
INFO - 2018-03-31 23:58:08 --> Model Class Initialized
INFO - 2018-03-31 23:58:08 --> Model Class Initialized
DEBUG - 2018-03-31 23:58:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:58:08 --> Final output sent to browser
DEBUG - 2018-03-31 23:58:08 --> Total execution time: 0.3628
INFO - 2018-03-31 23:58:50 --> Config Class Initialized
INFO - 2018-03-31 23:58:50 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:58:50 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:58:50 --> Utf8 Class Initialized
INFO - 2018-03-31 23:58:50 --> URI Class Initialized
INFO - 2018-03-31 23:58:50 --> Router Class Initialized
INFO - 2018-03-31 23:58:50 --> Output Class Initialized
INFO - 2018-03-31 23:58:50 --> Security Class Initialized
DEBUG - 2018-03-31 23:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:58:50 --> Input Class Initialized
INFO - 2018-03-31 23:58:50 --> Language Class Initialized
INFO - 2018-03-31 23:58:50 --> Loader Class Initialized
INFO - 2018-03-31 23:58:50 --> Helper loaded: url_helper
INFO - 2018-03-31 23:58:50 --> Helper loaded: form_helper
INFO - 2018-03-31 23:58:50 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:58:50 --> Form Validation Class Initialized
INFO - 2018-03-31 23:58:50 --> Model Class Initialized
INFO - 2018-03-31 23:58:50 --> Controller Class Initialized
INFO - 2018-03-31 23:58:50 --> Model Class Initialized
INFO - 2018-03-31 23:58:50 --> Model Class Initialized
INFO - 2018-03-31 23:58:50 --> Model Class Initialized
INFO - 2018-03-31 23:58:50 --> Model Class Initialized
DEBUG - 2018-03-31 23:58:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:58:51 --> Final output sent to browser
DEBUG - 2018-03-31 23:58:51 --> Total execution time: 0.6528
INFO - 2018-03-31 23:59:42 --> Config Class Initialized
INFO - 2018-03-31 23:59:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 23:59:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 23:59:42 --> Utf8 Class Initialized
INFO - 2018-03-31 23:59:42 --> URI Class Initialized
INFO - 2018-03-31 23:59:42 --> Router Class Initialized
INFO - 2018-03-31 23:59:42 --> Output Class Initialized
INFO - 2018-03-31 23:59:42 --> Security Class Initialized
DEBUG - 2018-03-31 23:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 23:59:42 --> Input Class Initialized
INFO - 2018-03-31 23:59:42 --> Language Class Initialized
INFO - 2018-03-31 23:59:42 --> Loader Class Initialized
INFO - 2018-03-31 23:59:42 --> Helper loaded: url_helper
INFO - 2018-03-31 23:59:42 --> Helper loaded: form_helper
INFO - 2018-03-31 23:59:42 --> Database Driver Class Initialized
DEBUG - 2018-03-31 23:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 23:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 23:59:42 --> Form Validation Class Initialized
INFO - 2018-03-31 23:59:42 --> Model Class Initialized
INFO - 2018-03-31 23:59:42 --> Controller Class Initialized
INFO - 2018-03-31 23:59:42 --> Model Class Initialized
INFO - 2018-03-31 23:59:42 --> Model Class Initialized
INFO - 2018-03-31 23:59:42 --> Model Class Initialized
INFO - 2018-03-31 23:59:42 --> Model Class Initialized
DEBUG - 2018-03-31 23:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 23:59:43 --> Final output sent to browser
DEBUG - 2018-03-31 23:59:43 --> Total execution time: 0.2898
